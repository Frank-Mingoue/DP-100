declare @numero_dossier int ;

set @numero_dossier = 1999

select * 
from  career.commun_zyes_entrees_departs 
where numero_dossier = @numero_dossier
order by 3


select * 
from  career.commun_zyco_contrat
where numero_dossier = @numero_dossier
order by 3



select * 
from  career.commun_zy38_affectation_etablissement 
where numero_dossier = @numero_dossier
order by 3



select * 
from  career.commun_zy3b_affectation 
where numero_dossier = @numero_dossier
order by 3



select * 
from  career.commun_zyca_carriere 
where numero_dossier = @numero_dossier
order by 3

--2005-07-18	2005-12-31
--2006-01-01	2020-08-31
--2020-09-01	2021-10-31
--2020-09-01	2021-10-31
--2020-09-01	2021-10-31
--2021-11-01	2999-12-31