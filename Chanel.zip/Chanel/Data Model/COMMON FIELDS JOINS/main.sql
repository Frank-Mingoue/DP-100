with t1 as (
select
	CASE 
        WHEN ZYCA.numero_dossier is not null  THEN ZYCA.numero_dossier
		 WHEN ZYES.numero_dossier is not null  THEN ZYES.numero_dossier
		 WHEN ZY38.numero_dossier is not null  THEN ZY38.numero_dossier
		 WHEN ZYCO.numero_dossier is not null  THEN ZYCO.numero_dossier
		 WHEN ZY3B.numero_dossier is not null  THEN ZY3B.numero_dossier    
	END as numero_dossier
   ,ZYCO.date_debut_contrat
   ,ZYCO.date_fin_contrat
   ,ZYCO.type_contrat
   ,ZYCO.nature as nature_contrat
   ,ZYES.date_entree  as date_entree_zyes                 
   ,ZYES.date_sortie_administrative as date_sortie_administrative_zyes 
   ,ZY38.etablissement 
   ,ZY38.date_debut as date_debut_zy38
   ,ZY38.date_fin as date_fin_zy38   
   ,ZY3B.unite_organisationnelle 
   ,ZY3B.date_effet as  date_effet_zy3b
   ,ZY3B.date_fin as date_fin_zy3b
   ,ZYCA.qualification 
   ,ZYCA.classification 
   ,ZYCA.code_convention_collective 
   ,ZYCA.date_debut AS date_debut_carriere
   ,ZYCA.date_fin AS date_fin_carriere
   , CASE WHEN ZYCA.date_debut >= ZY3B.date_effet THEN  ZY3B.date_effet 
     ELSE  ZYCA.date_debut
     END as date_min
   ,CASE WHEN ZYCA.date_fin <=  ZY3B.date_fin THEN ZYCA.date_fin
    ELSE ZY3B.date_fin
    END as date_max

from career.commun_zyes_entrees_departs ZYES 
full join career.zyco_contrat ZYCO on ZYES.numero_dossier = ZYCO.numero_dossier and ZYCO.date_debut_contrat >= ZYES.date_entree and  ZYCO.date_fin_contrat  <= ZYES.date_sortie_administrative
full join career.zy38_affectation_etablissement ZY38 on ZY38.numero_dossier = ZYCO.numero_dossier and ZY38.date_debut >= ZYCO.date_debut_contrat and ZY38.date_fin <= ZYCO.date_fin_contrat
full join career.zy3b_affectation ZY3B  on ZY3B.numero_dossier = ZY38.numero_dossier and ZY3B.date_effet >= ZY38.date_debut   and  ZY3B.date_fin <=  ZY38.date_fin
full join career.zyca_carriere ZYCA on ZYCA.numero_dossier = ZY38.numero_dossier AND ZYCA.date_debut >= ZY38.date_debut and ZYCA.date_fin <= ZY38.date_fin

--where ZYES.numero_dossier = 3421 --and ZYCO.numero_dossier is null 
--order by ZYES.date_entree, ZYCO.date_debut_contrat, ZY38.date_debut, ZY3B.date_effet, ZYCA.date_debut
)
select numero_dossier, qualification , classification , code_convention_collective , etablissement , type_contrat, nature_contrat, unite_organisationnelle , date_entree_zyes, date_sortie_administrative_zyes, min(date_min) as date_debut, max(date_max) as date_fin
from t1

--WHERE numero_dossier = '3421'

group by numero_dossier, qualification , classification , code_convention_collective , etablissement , type_contrat, nature_contrat, unite_organisationnelle, date_entree_zyes, date_sortie_administrative_zyes 
order by numero_dossier , date_debut


