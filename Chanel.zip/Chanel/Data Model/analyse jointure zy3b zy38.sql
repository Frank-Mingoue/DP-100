--(zy3b.date_effet >= zy38.date_debut and zy3b.date_fin <= zy38.date_fin) 
--OR (zy3b.date_effet < zy38.date_debut and zy3b.date_fin <= zy38.date_fin and zy3b.date_fin  > zy38.date_debut) 
--OR (zy3b.date_effet >= zy38.date_debut and zy3b.date_fin > zy38.date_fin and zy3b.date_effet < zy38.date_fin)
--OR (zy3b.date_effet <= zy38.date_debut and zy3b.date_fin >= zy38.date_fin ) 

select * 
from [career].[ZY38_affectation_etablissement] zy38 
full join [career].[ZY3B_affectation] zy3b on zy38.numero_dossier = zy3b.numero_dossier
AND zy3b.date_effet >= zy38.date_debut and zy3b.date_fin <= zy38.date_fin
where zy3b.numero_dossier is null


select * 
from [career].[ZY38_affectation_etablissement] zy38 
full join [career].[ZY3B_affectation] zy3b on zy38.numero_dossier = zy3b.numero_dossier
AND ((zy3b.date_effet >= zy38.date_debut and zy3b.date_fin <= zy38.date_fin) 
OR (zy3b.date_effet < zy38.date_debut and zy3b.date_fin <= zy38.date_fin and zy3b.date_fin  > zy38.date_debut) 
OR (zy3b.date_effet >= zy38.date_debut and zy3b.date_fin > zy38.date_fin and zy3b.date_effet < zy38.date_fin)
OR (zy3b.date_effet <= zy38.date_debut and zy3b.date_fin >= zy38.date_fin ) )
where zy3b.numero_dossier is null