with T1 as (SELECT 
case 
 when zyes.numero_dossier is not null then zyes.numero_dossier 
 else zyco.numero_dossier 
 end as numero_dossier
 ,zyes.date_entree
 ,zyes.date_sortie_administrative
 ,zyco.type_contrat
 ,zyco.nature
 ,case 
  when zyes.numero_dossier is null and zyco.numero_dossier is not null then zyco.date_debut_contrat
  when zyco.numero_dossier is null and zyes.numero_dossier is not null then zyes.date_entree
  when zyco.date_debut_contrat = zyes.date_entree then zyes.date_entree
  when zyco.date_debut_contrat < zyes.date_entree then zyes.date_entree
  when zyes.date_entree < zyco.date_debut_contrat then zyco.date_debut_contrat
  end as date_debut 

  ,case 
  when zyes.numero_dossier is null and zyco.numero_dossier is not null then zyco.date_fin_contrat
  when zyco.numero_dossier is null and zyes.numero_dossier is not null then zyes.date_sortie_administrative
  when zyco.date_fin_contrat = zyes.date_sortie_administrative then zyes.date_sortie_administrative
  when zyco.date_fin_contrat < zyes.date_sortie_administrative then zyco.date_fin_contrat
  when zyes.date_sortie_administrative < zyco.date_fin_contrat then zyes.date_sortie_administrative
  end as date_fin

FROM [career].[commun_ZYES_entrees_departs] zyes 
full join [career].[commun_ZYCO_contrat] zyco on zyes.numero_dossier = zyco.numero_dossier 
and  (
(zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative) 
OR (zyco.date_debut_contrat < zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative and zyco.date_fin_contrat  > zyes.date_entree  ) 
OR (zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat > zyes.date_sortie_administrative and zyco.date_debut_contrat <zyes.date_sortie_administrative)
OR (zyco.date_debut_contrat <= zyes.date_entree and zyco.date_fin_contrat >= zyes.date_sortie_administrative ))
),
T2 as (select 
 case 
 when T1.numero_dossier is not null then T1.numero_dossier 
 else zy38.numero_dossier 
 end as numero_dossier
 ,T1.date_entree
 ,T1.date_sortie_administrative
 ,T1.type_contrat
 ,T1.nature
 ,zy38.etablissement
 ,T1.date_debut as t1_date_debut
 ,T1.date_fin as t1_date_fin
 ,zy38.date_debut as zy38_date_debut
 ,zy38.date_fin as zy38_date_fin

 ,case 
  when zy38.numero_dossier is null and T1.numero_dossier is not null then T1.date_debut
  when T1.numero_dossier is null and zy38.numero_dossier is not null then zy38.date_debut
  when zy38.date_debut = T1.date_debut then T1.date_debut
  when zy38.date_debut < T1.date_debut then T1.date_debut
  when T1.date_debut < zy38.date_debut then zy38.date_debut
  end as date_debut 

  ,case 
  when zy38.numero_dossier is null and T1.numero_dossier is not null then T1.date_fin
  when T1.numero_dossier is null and zy38.numero_dossier is not null then zy38.date_fin
  when zy38.date_fin = T1.date_fin then T1.date_fin
  when zy38.date_fin < T1.date_fin then zy38.date_fin
  when T1.date_fin < zy38.date_fin then T1.date_fin
  end as date_fin
 
 from T1 
 full join [career].[commun_zy38_affectation_etablissement] zy38 on zy38.numero_dossier = T1.numero_dossier
 and  (
(zy38.date_debut >= T1.date_debut and zy38.date_fin <= T1.date_fin) 
OR (zy38.date_debut < T1.date_debut and zy38.date_fin <= T1.date_fin and zy38.date_fin  > T1.date_debut) 
OR (zy38.date_debut >= T1.date_debut and zy38.date_fin > T1.date_fin and zy38.date_debut < T1.date_fin)
OR (zy38.date_debut <= T1.date_debut and zy38.date_fin >= T1.date_fin ) )

),
T3 as ( select
 case 
	when T2.numero_dossier is not null then T2.numero_dossier 
	else zy3b.numero_dossier 
 end as numero_dossier
 ,T2.date_entree
 ,T2.date_sortie_administrative
 ,T2.type_contrat
 ,T2.nature
 ,T2.etablissement
 ,zy3b.unite_organisationnelle
 ,T2.date_debut as t2_date_debut
 ,T2.date_fin as t2_date_fin
 ,zy3b.date_effet as zy3b_date_effet
 ,zy3b.date_fin as zy3b_date_fin


 ,case 
  when zy3b.numero_dossier is null and T2.numero_dossier is not null then T2.date_debut
  when T2.numero_dossier is null and zy3b.numero_dossier is not null then zy3b.date_effet
  when zy3b.date_effet = T2.date_debut then T2.date_debut
  when zy3b.date_effet < T2.date_debut then T2.date_debut
  when T2.date_debut < zy3b.date_effet then zy3b.date_effet
  end as date_debut 

  ,case 
  when zy3b.numero_dossier is null and T2.numero_dossier is not null then T2.date_fin
  when T2.numero_dossier is null and zy3b.numero_dossier is not null then zy3b.date_fin
  when zy3b.date_fin = T2.date_fin then T2.date_fin
  when zy3b.date_fin < T2.date_fin then zy3b.date_fin
  when T2.date_fin < zy3b.date_fin then T2.date_fin
  end as date_fin


 from T2 
 full join [career].[commun_zy3b_affectation] zy3b ON zy3b.numero_dossier = T2.numero_dossier
  and  (
(zy3b.date_effet >= T2.date_debut and zy3b.date_fin <= T2.date_fin) 
OR (zy3b.date_effet < T2.date_debut and zy3b.date_fin <= T2.date_fin and zy3b.date_fin  > T2.date_debut) 
OR (zy3b.date_effet >= T2.date_debut and zy3b.date_fin > T2.date_fin and zy3b.date_effet < T2.date_fin)
OR (zy3b.date_effet <= T2.date_debut and zy3b.date_fin >= T2.date_fin ) )
), 
T4 as (select 
  case 
	when T3.numero_dossier is not null then T3.numero_dossier 
	else zyca.numero_dossier 
 end as numero_dossier
 ,T3.date_entree
 ,T3.date_sortie_administrative
 ,T3.type_contrat
 ,T3.nature
 ,T3.etablissement
 ,T3.unite_organisationnelle
 ,zyca.classification
 ,zyca.qualification
 ,zyca.code_convention_collective
 ,T3.date_debut as t3_date_debut
 ,T3.date_fin as t3_date_fin
 ,zyca.date_debut as zyca_date_debut
 ,zyca.date_fin as zyca_date_fin

  ,case 
  when zyca.numero_dossier is null and T3.numero_dossier is not null then T3.date_debut
  when T3.numero_dossier is null and zyca.numero_dossier is not null then zyca.date_debut
  when zyca.date_debut = T3.date_debut then T3.date_debut
  when zyca.date_debut < T3.date_debut then T3.date_debut
  when T3.date_debut < zyca.date_debut then zyca.date_debut
  end as date_debut 

  ,case 
  when zyca.numero_dossier is null and T3.numero_dossier is not null then T3.date_fin
  when T3.numero_dossier is null and zyca.numero_dossier is not null then zyca.date_fin
  when zyca.date_fin = T3.date_fin then T3.date_fin
  when zyca.date_fin < T3.date_fin then zyca.date_fin
  when T3.date_fin < zyca.date_fin then T3.date_fin
  end as date_fin

 from T3 
 full join [career].[commun_zyca_carriere] zyca on zyca.numero_dossier = T3.numero_dossier
   and  (
(zyca.date_debut >= T3.date_debut and zyca.date_fin <= T3.date_fin) 
OR (zyca.date_debut < T3.date_debut and zyca.date_fin <= T3.date_fin and zyca.date_fin  > T3.date_debut) 
OR (zyca.date_debut >= T3.date_debut and zyca.date_fin > T3.date_fin and zyca.date_debut < T3.date_fin)
OR (zyca.date_debut <= T3.date_debut and zyca.date_fin >= T3.date_fin ) )

), 
zytl as ( select 

 zytl.* 
 ,isnull (Lead(dateadd (day, -1, date_effet)) over (partition by numero_dossier order by date_effet), '2999-12-31') as date_fin
FROM [career].[commun_zytl_heures_contractuelles] zytl
) , T5 as (
SELECT 
  case 
	when T4.numero_dossier is not null then T4.numero_dossier 
	else zytl.numero_dossier 
 end as numero_dossier
 ,T4.date_entree
 ,T4.date_sortie_administrative
 ,T4.type_contrat
 ,T4.nature
 ,T4.etablissement
 ,T4.unite_organisationnelle
 ,T4.classification
 ,T4.qualification 
 ,T4.date_debut as t4_date_debut
 ,T4.date_fin as t4_date_fin
 ,zytl.date_effet as zytl_date_debut
 ,zytl.date_fin as zytl_date_fin
 ,zytl.type_temps_contractuel
 ,zytl.heures_presencemois

 ,case 
  when zytl.numero_dossier is null and T4.numero_dossier is not null then T4.date_debut
  when T4.numero_dossier is null and zytl.numero_dossier is not null then zytl.date_effet
  when zytl.date_effet = T4.date_debut then T4.date_debut
  when zytl.date_effet < T4.date_debut then T4.date_debut
  when T4.date_debut < zytl.date_effet then zytl.date_effet
  end as date_debut 

  ,case 
  when zytl.numero_dossier is null and T4.numero_dossier is not null then T4.date_fin
  when T4.numero_dossier is null and zytl.numero_dossier is not null then zytl.date_fin
  when zytl.date_fin = T4.date_fin then T4.date_fin
  when zytl.date_fin < T4.date_fin then zytl.date_fin
  when T4.date_fin < zytl.date_fin then T4.date_fin
  end as date_fin
 
 FROM T4 
 left join zytl on zytl.numero_dossier = T4.numero_dossier
 --and ( T4.date_debut >= zytl.date_effet and T4.date_fin <= zytl.date_fin_effet)
 and  (
(zytl.date_effet >= T4.date_debut and zytl.date_fin <= T4.date_fin) 
OR (zytl.date_effet < T4.date_debut and zytl.date_fin <= T4.date_fin and zytl.date_fin  > T4.date_debut) 
OR (zytl.date_effet >= T4.date_debut and zytl.date_fin > T4.date_fin and zytl.date_effet < T4.date_fin)
OR (zytl.date_effet <= T4.date_debut and zytl.date_fin >= T4.date_fin ) )
), T6 as (
SELECT 
   numero_dossier
 ,date_entree
 ,date_sortie_administrative
 ,type_contrat
 ,nature
 ,etablissement
 ,unite_organisationnelle
 ,classification
 ,qualification 
 ,type_temps_contractuel
 ,heures_presencemois
 ,date_debut
 ,date_fin
 ,ROW_NUMBER () over ( order by numero_dossier, date_debut) - ROW_NUMBER () over (order by numero_dossier ,date_entree ,date_sortie_administrative ,type_contrat ,nature ,etablissement ,unite_organisationnelle ,classification ,qualification  ,type_temps_contractuel ,heures_presencemois, date_debut) as consecutive
 FROM T5
), T7 as (
select numero_dossier
 ,date_entree
 ,date_sortie_administrative
 ,type_contrat
 ,nature
 ,etablissement
 ,unite_organisationnelle
 ,classification
 ,qualification 
 ,type_temps_contractuel
 ,heures_presencemois
 ,consecutive
 ,MIN(date_debut) as date_debut
 ,MAX(date_fin) as date_fin
 from T6
 group by numero_dossier
 ,date_entree
 ,date_sortie_administrative
 ,type_contrat
 ,nature
 ,etablissement
 ,unite_organisationnelle
 ,classification
 ,qualification 
 ,type_temps_contractuel
 ,heures_presencemois
 ,consecutive
 ) select 
 numero_dossier
 ,date_entree
 ,date_sortie_administrative
 ,type_contrat
 ,nature
 ,etablissement
 ,unite_organisationnelle
 ,classification
 ,qualification 
 ,type_temps_contractuel
 ,heures_presencemois
 ,date_debut
 ,date_fin
 from T7
 order by numero_dossier, date_debut