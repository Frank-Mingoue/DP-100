
 
 DROP TABLE IF EXISTS [absences].[compte_epargne]; 
 
 CREATE TABLE [absences].[compte_epargne] ( 
 	numero_dossier INT, 
	date_operation DATE, 
 	type_compte VARCHAR(MAX),
	type_operation VARCHAR(MAX),
	nombre_jours_temps_plein DECIMAL(7, 4), 
 	numero_ordre INT, 
 	nombre_jours_epargnes DECIMAL(7, 4), 
 	nombre_jours_ouvres_epargnes DECIMAL(7, 4), 
 	nombre_heures_epargnees INT, 
 	montant_epargne INT, 
 	solde_compte_en_heures_tps_plein_oce INT, 
 	code_origine VARCHAR(2), 
 	date_ouverture_compte DATE, 
 	date_fermeture_compte DATE, 
 	solde_compte_en_jours_ouvres DECIMAL(7, 4), 
 	solde_compte_theor_tps_pleine DECIMAL(7, 4), 
 	solde_compte_en_heures_tps_plein_ce INT,
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


 DROP TABLE IF EXISTS [career].[commun_zy38_affectation_etablissement]; 
 
 CREATE TABLE [career].[commun_zy38_affectation_etablissement] (
	
	id INT identity(1,1),
	numero_dossier INT, 
 	date_debut DATE, 
 	date_fin DATE, 
 	etablissement VARCHAR(MAX)
 
 )


 DROP TABLE IF EXISTS [career].[commun_zy3b_affectation]; 
 
 CREATE TABLE [career].[commun_zy3b_affectation] (

	id INT identity(1,1),
	numero_dossier INT, 
 	date_effet DATE, 
 	date_fin DATE,  	 
 	unite_organisationnelle VARCHAR(1) 
 
 )


 DROP TABLE IF EXISTS [career].[commun_zyca_carriere]; 
 
 CREATE TABLE [career].[commun_zyca_carriere] (

	id INT identity(1,1),
	numero_dossier INT, 
 	date_debut DATE, 
 	date_fin DATE, 
 	qualification VARCHAR(MAX), 
 	classification VARCHAR(MAX), 
 	code_convention_collective VARCHAR(MAX) 
 
 )


 DROP TABLE IF EXISTS [career].[commun_zyco_contrat]; 
 
 CREATE TABLE [career].[commun_zyco_contrat] (

	id INT identity(1,1),
	numero_dossier INT, 
 	date_debut_contrat DATE, 
 	date_fin_contrat DATE, 
 	type_contrat VARCHAR(MAX), 
 	nature VARCHAR(MAX) 
 
 )


 DROP TABLE IF EXISTS [career].[commun_zyes_entrees_departs]; 
 
 CREATE TABLE [career].[commun_zyes_entrees_departs] (

	id INT identity(1,1),
	numero_dossier INT, 
 	date_entree DATE,  
 	date_sortie_administrative DATE
 
 )

 DROP TABLE IF EXISTS [career].[commun_zytl_heures_contractuelles]; 
 
 CREATE TABLE [career].[commun_zytl_heures_contractuelles] ( 
	id INT identity(1,1),
 	numero_dossier INT, 
 	date_effet DATE, 
 	type_temps_contractuel VARCHAR(), 
 	heures_presencemois DECIMAL(5, 2) 
  
 	)


	/****** Object:  Table [career].[identification]    Script Date: 10/7/2022 11:23:30 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[career].[identification]') AND type in (N'U'))
DROP TABLE [career].[identification]
GO

/****** Object:  Table [career].[identification]    Script Date: 10/7/2022 11:23:30 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [career].[identification](
	[numero_dossier] [int] NULL,
	[matricule_hra] [varchar](19) NULL,
	[matricule_workday] [varchar](12) NULL,
	[prenom_employe] [varchar](30) NULL,
	[nom_employe] [varchar](40) NULL,
	[date_anciennete] [date] NULL,
	[anciennete] [varchar](25) NULL
) ON [PRIMARY]
GO


	