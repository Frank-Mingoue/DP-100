def get_table_query(tablename: String) : Map[String, String] = {

//var query = Map(query_record ->"", table_name -> "test" )
  
val query = tablename  match { 


//------------ZX00 
case "ZX00" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	SOCCLE as reglementation, 
 	MATRIC as identification, 
 	NUDOSP as identifiant_dossier_paie, 
 	PERPAI as periode_paie, 
 	NUMBUL as numero_bulletin, 
 	TYPAIE as type_paie, 
 	NOMSAL as nom_salarie, 
 	TILOAD as horodatage_chargement 
 	from vw_table""",
	   "table_name" -> "pay.ZX00_identification")


//------------ZX0M 
case "ZX0M" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
    PERPAI as periode_paie,
	IDCONT as identifiant_contrat, 
 	DATDEB as date_debut, 
 	DATFIN as date_fin_contrat, 
 	TYPCON as type_contrat, 
 	LIBTYC as libelle_types_contrat, 
 	NATCON as nature_contrat, 
 	LIBNAC as libelle_natures_contrat, 
 	DURANN as duree_anse, 
 	DURMOI as duree_moise, 
 	DURJOU as duree_jourse, 
 	DEBESS as debut_periode_essai, 
 	FINESS as fin_periode_essai, 
 	EMPLOI as categorie_espagnee, 
 	LIBEMP as libelle_la_categorie, 
 	CLASSI as classification, 
 	FILLC2 as filler, 
 	LIBCLA as libelle_la_classification, 
 	POSITI as position, 
 	LIBPOS as libelle_la_position, 
 	INDICE as indice, 
 	LIBIND as libelle_indice, 
 	COEFFI as coefficient, 
 	LIBCOE as libelle_coefficient, 
 	NIVECH as niveau_echelon, 
 	NIVEAU as niveau, 
 	ECHELO as echelon, 
 	CONCOV as code_convention_collective, 
 	LIBCOC as libelle_la_convention_collective, 
 	IDESTA as etablissement, 
 	LIBETA as libelle_etablissement, 
 	CODTRA as type_temps_contractuel, 
 	LIBTRA as libelle_type_temps_contractuel, 
 	NBSTHD as heures_presencejour, 
 	NBSTHW as heures_presencesemaine, 
 	NBSTHM as heures_presencemois, 
 	RTSTHR as pourc_h_presencetemps_plein, 
 	NBPDHD as heures_payeesjour, 
 	NBPDHW as heures_payeessemaine, 
 	NBPDHM as heures_payeesmois, 
 	RTPDHR as pourc_h_payeestemps_plein, 
 	DESCAU as salaires, 
 	RUBAUG as rubrique, 
 	LIBRUB as libelle_rubrique, 
 	MTSAL as montant_salaire, 
 	AMHRL as montant_horaire, 
 	AMPYP as montant_par_periode_paie, 
 	CHBASE as coefficient_base_chimie, 
 	CHPERS as coefficient_personnel_chimie, 
 	CHSPEC as coefficient_specialite_chimie, 
 	CHNIVE as niveau_chimie, 
 	CHECHL as echelon_chimie, 
 	COGRPE as groupe_couture, 
 	CONIVE as niveau_couture, 
 	FORANU as forfait_annuel_en_jours 
 	from vw_table""",
	   "table_name" -> "pay.ZX0M_description_des_contrats")


//------------ZX35 
case "ZX35" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
    PERPAI as periode_paie,
	DATENT as date_entree, 
 	DATSOR as date_sortie, 
 	PHYSOR as date_sortie_physique, 
 	CODENT as motif_entree, 
 	LIBENT as libelle_motif_entree, 
 	CODSOR as motif_sortie, 
 	LIBSOR as libelle_motif_sortie, 
 	CGSTHI as cat_situat_salarie_reeentre, 
 	LIBCGS as libelle_la_cat_sit_sal_reente, 
 	RSSTHI as motif_situation_reeentree, 
 	LIBRSS as libelle_motif_situation_reente, 
 	CGSTAT as cat_situat_salarie_suite_sortie, 
 	LIBCST as libelle_la_categ_sal_sort, 
 	RSSTAT as motif_situation_suite_a_sortie, 
 	LIBRST as libelle_motif_situation_sortie, 
 	ANCIEN as date_anciennete_1, 
 	DATEUT as date_anciennete_2, 
 	ANCIE3 as date_anciennete_3, 
 	ANCIE4 as date_anciennete_4, 
 	ANCIE5 as date_anciennete_5, 
 	ANCIE6 as date_anciennete_6 
 	from vw_table""",
	   "table_name" -> "pay.ZX35_dates")


//------------ZX37 
case "ZX37" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
    PERPAI as periode_paie,
	ETABLI as etablissement, 
 	LIBETA as libelle_etablissement, 
 	LEVEL1 as niveau_1, 
 	LEVEL2 as niveau_2, 
 	LEVEL3 as niveau_3, 
 	LEVEL4 as niveau_4 
 	from vw_table""",
	   "table_name" -> "pay.ZX37_affectations_geographiques")


//------------ZX38 
case "ZX38" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
    PERPAI as periode_paie,
	QUALIF as qualification, 
 	CLASSI as classification, 
 	LIBQUA as libelle_statut, 
 	LIBCLA as libelle_la_classification, 
 	COCONV as code_convention_collective, 
 	REGSPE as regime_special_cotisation, 
 	LIBCOC as libelle_la_convention_collective 
 	from vw_table""",
	   "table_name" -> "pay.ZX38_carriere")


//------------ZX3B 
case "ZX3B" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
    PERPAI as periode_paie,
	CODCON as code_conge, 
 	ANNEES as annee_reference, 
 	IDZYES as identifiant_entreesortie, 
 	DATDEB as date_debut_consommation, 
 	DATFIN as date_fin_consommation, 
 	DEBACQ as date_debut_acquisition, 
 	FINACQ as date_fin_acquisition, 
 	ACQUIA as droits_acquis, 
 	DRTPRI as droits_pris, 
 	RESTAN as droits_restants 
 	from vw_table""",
	   "table_name" -> "pay.ZX3B_conges_payes")


//------------ZX40 
case "ZX40" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
    PERPAI as periode_paie,
	DATEFF as date_effet, 
 	CODTRA as type_temps_contractuel, 
 	LIBTRA as libelle_type_temps_contractuel, 
 	NBSTHD as heures_presencejour, 
 	NBSTHW as heures_presencesemaine, 
 	NBSTHM as heures_presencemois, 
 	RTSTHR as pourc_h_presencetemps_plein, 
 	NBPDHD as heures_payeesjour, 
 	NBPDHW as heures_payeessemaine, 
 	NBPDHM as heures_payeesmois, 
 	RTPDHR as pourc_h_payeestemps_plein, 
 	FORANU as forfait_annuel_en_jours, 
 	FORANH as forfait_annuel_heures 
 	from vw_table""",
	   "table_name" -> "pay.ZX40_heures_contractuelles")


//------------ZX5V 
case "ZX5V" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
    PERPAI as periode_paie,
	VALIDT as temoin_validite, 
 	TIMVAL as horodatage_validite 
 	from vw_table""",
	   "table_name" -> "pay.ZX5V_statut_dossier")


//------------ZX6A 
case "ZX6A" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
    PERPAI as periode_paie,
	DEBABS as date_debut_absence, 
 	IDEREM as identifiant_element_remuneration, 
 	CODABS as code_absence, 
 	SOURCE as source_absence, 
 	LIBELL as libelle_absence, 
 	FINABS as date_fin_absence 
 	from vw_table""",
	   "table_name" -> "pay.ZX6A_absences")


//------------ZX6C 
case "ZX6C" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
    PERPAI as periode_paie,
	NUMCUM as numero_cumul, 
 	PERDEB as periode_debut_cumul, 
 	LIBCUM as libelle_cumul, 
 	MONCUM as montant_cumul 
 	from vw_table""",
	   "table_name" -> "pay.ZX6C_cumuls_paie")


//------------ZX6P 
case "ZX6P" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
    PERPAI as periode_paie,
	RUBPRE as code_rubrique, 
 	ORDPRE as numero_ordre, 
 	NUMPRE as numero_prêt, 
 	LIBPRE as libelle_la_rubrique, 
 	MONPR as montant_initial, 
 	DEBPRE as date_debut, 
 	FINPRE as date_fin, 
 	ECHPRE as nombre_echeances, 
 	MENPR as montant_une_mensualite, 
 	SOLPR as solde, 
 	TXIPRE as taux_interêt, 
 	MTINT as montants_des_interêts, 
 	DTCONC as date_concession, 
 	DTVIRC as date_virement_capital, 
 	CAPNA as capital_non_amorti, 
 	SOLAV as solde_avant_paie 
 	from vw_table""",
	   "table_name" -> "pay.ZX6P_prets_et_saisies")


//------------ZX8K 
case "ZX8K" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
    PERPAI as periode_paie,
	CODRUB as code_element_remuneration, 
 	PERVAL as periode_valorisation, 
 	DATRUB as date, 
 	CODRAP as rappel_automatique, 
 	SOURCE as source, 
 	CALCUL as code_calcul, 
 	LIBELL as libelle_element_remuneration, 
 	NBRBAS as nombre_ou_base, 
 	TAUSAL as taux_salarial, 
 	MONSAL as montant_salarial, 
 	TAUPAT as taux_patronal, 
 	MONPAT as montant_patronal, 
 	IMPUTA as imputation, 
 	ZONEUT as zone_utilisateur, 
 	CODABS as code_absence, 
 	DEBABS as date_debut_absence, 
 	FINABS as date_fin_absence, 
 	MEMO01 as memo_01, 
 	MEMO02 as memo_02, 
 	MEMO03 as memo_03, 
 	MEMO04 as memo_04, 
 	MEMO05 as memo_05, 
 	MEMO06 as memo_06, 
 	MEMO07 as memo_07, 
 	MEMO08 as memo_08, 
 	MEMO09 as memo_09, 
 	MEMO10 as memo_10, 
 	MEMO11 as memo_11, 
 	CODORG as code_organisme, 
 	LIBORG as libelle_organisme, 
 	QLPRW1 as qualifiant_numero_1, 
 	QLPRW2 as qualifiant_numero_2, 
 	QLPRW3 as qualifiant_numero_3, 
 	QLPRW4 as qualifiant_numero_4, 
 	QLPRW5 as qualifiant_numero_5, 
 	QLPRW6 as qualifiant_numero_6, 
 	QLPRW7 as qualifiant_numero_7, 
 	QLPRW8 as qualifiant_numero_8, 
 	TEJOU7 as bas_tableau, 
 	RGPOSJ as position_dans_le_journal_paie, 
 	TEBULQ as alimentation_colonne_nombre_ou_base, 
 	TEBULD as nb_decimales_colonne_nombre_ou_base, 
 	TEBULT as alimentation_la_colonne_taux, 
 	TEBULM as colonne_montant, 
 	RGPOSB as position_rubrique_sur_bulletin, 
 	RGPOSA as position_rubrique_sur_fiche_annexe, 
 	RGPOSE as position_rubrique_sur_fiche_euro 
 	from vw_table""",
	   "table_name" -> "pay.ZX8K_elements_remuneration")


//------------ZXM7 
case "ZXM7" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
    PERPAI as periode_paie,
	TYPCPT as type_compte, 
 	DATOUV as date_ouverture, 
 	DTFERM as date_fermeture, 
 	SOLCPT as solde_compte, 
 	SOLCTH as solde_temps_plein, 
 	SOLCHE as solde_en_heures_temps_plein, 
 	DTUTIL as date_utilisation, 
 	DTFIN as date_fin_utilisation 
 	from vw_table""",
	   "table_name" -> "pay.ZXM7_compte_epargne")


//------------ZXMM 
case "ZXMM" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	CPTDSN as code_compteur_n, 
 	CODRUB as code_element_remuneration, 
 	SOURCE as source, 
 	ZOCIBL as zone_cible_n, 
 	CATEGO as categorie_compteur_n, 
 	CDBLOC as code_bloc, 
 	SUICAT as suite_categorie, 
 	TYPCOD as valeur_typecode_structure_n, 
 	MONTA1 as montant_ou_mesure, 
 	MONTA2 as nbre_heures_ou_montant_assiette, 
 	MONTA3 as taux, 
 	DATE01 as date_1, 
 	DATE02 as date_2, 
 	DTDEBO as date_debut_la_periode_origine, 
 	DTFINO as date_fin_la_periode_origine, 
 	IDOPSD as id_ops_destinataire, 
 	TYPORG as type_organisme, 
 	V23002 as qualifiant_assiette, 
 	CDINSE as code_insee_commune, 
 	TAUEFF as taux_cotis_effectif_a_cumulere, 
 	CODDEC as code_affiliation_prev, 
 	PERPAI as periode_paie, 
 	TAUX as taux_applique_a_base 
 	from vw_table""",
	   "table_name" -> "pay.ZXMM_dsn_montants")


//------------ZY19 
case "ZY19" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DATAN1 as date_anciennete_1, 
 	DATAN2 as date_anciennete_2, 
 	DATAN3 as date_anciennete_3, 
 	DATAN4 as date_anciennete_4, 
 	DATAN5 as date_anciennete_5, 
 	DATAN6 as date_anciennete_6 
 	from vw_table""",
	   "table_name" -> "career.ZY19_dates_anciennete")


//------------ZY1M 
case "ZY1M" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	IMMAT as numero_immatriculation, 
 	IDCTRY as pays, 
 	DATDEB as date_debut, 
 	DATFIN as date_fin, 
 	DATIMM as date_immatriculation, 
 	PUISVH as puissance_vehicule, 
 	TYPEVH as type_vehicule, 
 	CONSTR as constructeur, 
 	MODELE as modele, 
 	CYLIND as cylindree, 
 	FUELTY as carburant, 
 	VALUE as valeur_vehicule 
 	from vw_table""",
	   "table_name" -> "career.ZY1M_vehicules")


//------------ZY1S 
case "ZY1S" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DTEF1S as date_effet_la_situation, 
 	STEMPL as situation, 
 	CGSTAT as categorie_situation, 
 	RSSTAT as motif_situation, 
 	FLABGN as occurrences_generees_par_un_conge 
 	from vw_table""",
	   "table_name" -> "career.ZY1S_statut")


//------------ZY24 
case "ZY24" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	NUDOSP as identifiant_dossier_paie, 
 	TRANST as type_transport, 
 	DATEFF as date_effet, 
 	ENDDAT as date_fin, 
 	IDCONT as identifiant_contrat 
 	from vw_table""",
	   "table_name" -> "career.ZY24_type_transport")


//------------ZY35 
case "ZY35" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DTEF00 as date_effet, 
 	IDJB00 as emploi, 
 	RTASSI as pourcentage_affectation, 
 	LBEMLG as libelle_long_reel, 
 	IDPS00 as poste, 
 	IDOU00 as unite_organisation, 
 	LBEMSH as libelle_court_reel 
 	from vw_table""",
	   "table_name" -> "career.ZY35_affectation_principale_salarie")


//------------ZY38 
case "ZY38" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DTEF00 as date_debut, 
 	DTEN00 as date_fin, 
 	IDESTA as etablissement, 
 	RSTRAN as motif_la_mutation, 
 	DTTRAN as date_effet_la_mutation 
 	from vw_table""",
	   "table_name" -> "career.ZY38_affectation_etablissement")


//------------ZY3B 
case "ZY3B" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DTEF00 as date_effet, 
 	DTEN00 as date_fin, 
 	NBASHR as horaires_affectation, 
 	NBFTES as equivalences_temps_plein, 
 	DTPSSE as date_arrivee_dans_le_poste, 
 	IDPS00 as code_poste, 
 	IDJB00 as identifiant_emploi, 
 	IDOU00 as unite_organisationnelle, 
 	RTASSI as pourcentage_affectation 
 	from vw_table""",
	   "table_name" -> "career.ZY3B_affectation")


//------------ZY4K 
case "ZY4K" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	IDPOCR as centre_cout_1, 
 	IDSUAR as souscompte_1, 
 	DTEF00 as date_effet, 
 	DTEN00 as date_fin, 
 	RTDIST as pourcentage_repartition 
 	from vw_table""",
	   "table_name" -> "career.ZY4K_repartition_comptable")


//------------ZY5G 
case "ZY5G" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	IDCONT as identifiant_contrat, 
 	DATDEB as date_debut, 
 	DATFIN as date_fin, 
 	CODE as code, 
 	INDCYC as index_zy5g 
 	from vw_table""",
	   "table_name" -> "career.ZY5G_affectations_cycle")


//------------ZYAF 
case "ZYAF" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DATAFF as date_effet, 
 	DATFIN as date_fin, 
 	LEVEL5 as niveau_5, 
 	LEVEL7 as niveau_7 
 	from vw_table""",
	   "table_name" -> "career.ZYAF_affectation_consolidee")


//------------ZYAG 
case "ZYAG" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DATDEB as date_debut, 
 	MOTIFA as motif, 
 	HRSDEB as heure_debut, 
 	DATFIN as date_fin, 
 	HRSFIN as heure_fin, 
 	TEMDEB as temoin_midi_debut, 
 	TEMFIN as temoin_midi_fin, 
 	GESTIO as temoin_gestion, 
 	PROLON as temoin_prolongation, 
 	NBHEUR as nombre_heures, 
 	IDLVSR as motif_situation_resultant, 
 	IDRTST as situation_au_retour, 
 	IDRTSC as categorie_situation_au_retour, 
 	GPRTSC as cat_situation_au_retour_redefiniee, 
 	IDRTSR as motif_situation_au_retour, 
 	NAABPD as payenon_paye 
 	from vw_table""",
	   "table_name" -> "absences.ZYAG_absences")


//------------ZYAR 
case "ZYAR" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DATCRM as date_mise_a_disposition_crm, 
 	REFCRM as numero_reference_crm, 
 	DATDEB as date_debut_validite_en_paie, 
 	DTFNJR as date_fin_validite_juridique, 
 	TAUPAS as taux_individuel_pas, 
 	TYPBAR as type_bareme_en_cas_taux_neutre, 
 	TEMBCH as temoin_injection_en_batch, 
 	TEMENR as temoin_crm_enrichi, 
 	DATDIS as date_mise_a_dispo_crm_enrichi 
 	from vw_table""",
	   "table_name" -> "career.ZYAR_taux_prelevement_source")

    


//------------ZYAU 
case "ZYAU" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DATEFF as date_effet, 
 	RUBAUG as rubrique, 
 	MTSAL as montant_salaire, 
 	CMOTIF as motif_augmentation, 
 	MTAUG as montant_augmentation, 
 	DATFIN as date_fin 
 	from vw_table""",
	   "table_name" -> "career.ZYAU_salaires")


//------------ZYCA 
case "ZYCA" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DATEFF as date_debut, 
 	DATFIN as date_fin, 
 	QUALIF as qualification, 
 	CLASSI as classification, 
 	COCONV as code_convention_collective, 
 	TYPREG as type_regime_cotisation_retraite, 
 	CHBASE as coefficient_base_chimie, 
 	CHSPEC as coefficient_specialite_chimie, 
 	COGRPE as groupe_couture, 
 	CONIVE as niveau_couture, 
 	EXTCF1 as temoin_1, 
 	CHPERS as coefficient_personnel_chimie, 
 	CHNIVE as niveau_chimie, 
 	CHECHL as echelon_chimie 
 	from vw_table""",
	   "table_name" -> "career.ZYCA_carriere")


//------------ZYCO 
case "ZYCO" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DATCON as date_debut_contrat, 
 	DATFIN as date_fin_contrat, 
 	TYPCON as type_contrat, 
 	NATCON as nature, 
 	DATPRE as date_fin_presumee, 
 	FINESS as fin_periode_essai, 
 	NBHEUC as nombre_heures_contrat, 
 	MOISCL as duree_clause_en_mois, 
 	MONTAN as montant_mensuel, 
 	POURCE as pourcentage_mensuel, 
 	CONTRA as clause_contractuelle, 
 	CLLEVE as clause_levee 
 	from vw_table""",
	   "table_name" -> "career.ZYCO_contrat")


//------------ZYCS 
case "ZYCS" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	NUDOSP as identifiant_dossier_paie, 
 	CODCAI as code_caisse, 
 	REGIME as regime_retraite, 
 	DEBCAI as date_debut, 
 	FINCAI as date_fin, 
 	NUMCAI as numero_inscription, 
 	IDCONT as identifiant_contrat, 
 	MOTRUP as motif_rupture_contrat, 
 	MOTSOR as motif_sortie, 
 	FLMAJC as temoin_mise_a_jour_manuelle 
 	from vw_table""",
	   "table_name" -> "career.ZYCS_caisses")


//------------ZYCU 
case "ZYCU" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	NUDOSP as identifiant_dossier_paie, 
 	NUMCUM as numero, 
 	IDCY00 as societe, 
 	PCUMSS as siecle, 
 	CUMANN as annee, 
 	CUMPER as periode, 
 	MONCUM as montant 
 	from vw_table""",
	   "table_name" -> "career.ZYCU_cumuls_paie")


//------------ZYDA 
case "ZYDA" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DATABS as date_debut_absence_ac, 
 	MOTABS as motif_absence, 
 	HRSDEB as heure_debut, 
 	NUMDRO as numero_droit, 
 	DATDEB as date_debuttranche, 
 	NUMTRA as numero_tranche, 
 	DATFIN as date_fin_tranche, 
 	HRSFIN as heure_fin, 
 	TEMDEB as temoin_midi_debut, 
 	TEMFIN as temoin_midi_fin, 
 	UNITE1 as duree_1, 
 	UNITE2 as duree_2, 
 	NBRJOU as nombre_jours, 
 	DATEAG as date_debut_absence_gestion 
 	from vw_table""",
	   "table_name" -> "absences.ZYDA_absences_decoupees_droits")


//------------ZYDV 
case "ZYDV" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	CODCON as code_conge, 
 	ANNEES as annee_reference, 
 	IDZYES as identifiant_entreesortie, 
 	DATDEB as date_debut_consommation, 
 	DATFIN as date_fin_consommation, 
 	DEBACQ as date_debut_acquisition, 
 	FINACQ as date_fin_acquisition, 
 	ACQUIA as droits_acquis, 
 	REPPRE as report_annee_precedente, 
 	REPECR as droits_ecretes, 
 	REPSUI as report_annee_suivante, 
 	PAYESS as droits_payes, 
 	DRTPRI as droits_pris, 
 	PRICH1 as pris_pendant_chevauchement_1, 
 	PRICH2 as pris_pendant_chevauchement_2, 
 	RESTAN as droits_restants, 
 	AJUST1 as ajustement_manuel_1, 
 	MOTIF1 as motif_ajustement_1, 
 	AJUST2 as ajustement_manuel_2, 
 	MOTIF2 as motif_ajustement_2, 
 	AJUST3 as ajustement_manuel_3, 
 	MOTIF3 as motif_ajustement_manuel_3, 
 	AJUST4 as ajustement_manuel_4, 
 	MOTIF4 as motif_ajustement_manuel_4 
 	from vw_table""",
	   "table_name" -> "absences.ZYDV_conges_payes")


//------------ZYE4 
case "ZYE4" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	TYPCPT as type_compte, 
 	DTOUV as date_ouverture_compte, 
 	DTFERM as date_fermeture_compte, 
 	SOLCPT as solde_compte_en_jours_ouvres, 
 	SOLCTH as solde_compte_theor_tps_pleine, 
 	SOLCHE as solde_compte_en_heures_tps_plein, 
 	DTUTIL as date_utilisation, 
 	DTFIN as date_fin_utilisation 
 	from vw_table""",
	   "table_name" -> "absences.ZYE4_compte_epargne")


//------------ZYE6 
case "ZYE6" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DTOPER as date_operation, 
 	TYPOPE as type_operation, 
 	TYPCPT as type_compte, 
 	NBJOTH as nombre_jours_temps_plein, 
 	NUMORD as numero_ordre, 
 	NBJOUR as nombre_jours_epargnes, 
 	NBJOUV as nombre_jours_ouvres_epargnes, 
 	NBHEUR as nombre_heures_epargnees, 
 	AMNUM as montant_epargne, 
 	SOLCHE as solde_compte_en_heures_tps_plein, 
 	CDORIG as code_origine 
 	from vw_table""",
	   "table_name" -> "absences.ZYE6_operations_compte_epargne")


//------------ZYEL 
case "ZYEL" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	NUDOSP as identifiant_dossier_paie, 
 	CODFIX as code_rubrique, 
 	DEBFIX as date_debut, 
 	FINFIX as date_fin, 
 	CFORMA as code_format_calcul, 
 	NBRBAS as nombre_ou_base, 
 	SALFIX as montant_ou_taux_salarial, 
 	PATFIX as montant_ou_taux_patronal, 
 	TESELE as temoin_selection, 
 	GLTCTR as centre_cout, 
 	MEMO01 as memo_01, 
 	MEMO02 as memo_02, 
 	DATE01 as date_1, 
 	DATE02 as date_2 
 	from vw_table""",
	   "table_name" -> "career.ZYEL_elements_fixes_paie")


//------------ZYES 
case "ZYES" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DATENT as date_entree, 
 	CODENT as motif_entree, 
 	IDZYES as identification_entree_sortie, 
 	DATSOR as date_sortie_administrative, 
 	CODSOR as motif_sortie, 
 	PHYSOR as date_sortie_physique, 
 	IDCY00 as societe, 
 	CGSTAT as statut_resultant_la_sortie, 
 	GPSTAT as cat_situation_apres_sortie_redefe 
 	from vw_table""",
	   "table_name" -> "career.ZYES_entrees_departs")


//------------ZYHB 
case "ZYHB" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DATDEB as date_debut, 
 	DTDECI as date_decision, 
 	DATFIN as date_fin, 
 	FLDUR1 as duree_decision, 
 	FLCHAU as temoin_chaumage_avant_embauche, 
 	FLCOTO as temoin_reconnu_travailleur_handicape, 
 	FLEA00 as placement_ea, 
 	FLESTA as placement_esta, 
 	FLCDTD as placement_cdtd, 
 	FLINVP as temoin_invalide_pensionne, 
 	FLSAPO as temoin_sapeur_pompier_volontaire, 
 	FLASMU as temoin_assimile_mutile_guerre, 
 	TEMAVI as temoin_handicap_permanent_a_viee, 
 	FLMUTG as temoin_mutile_guerre, 
 	FLALLO as temoin_beneficiaire_allocation, 
 	TEMCAR as temoin_titulaire_allocation, 
 	TEMHAN as temoin_malprofesacctravailtrajet, 
 	FLHPLD as temoin_handicap_lourd, 
 	POUHAN as taux_invalidite, 
 	DATPEN as date_debut_pension, 
 	CATPEN as categorie_pension, 
 	TXINCA as taux_incapacite, 
 	TEMHAT as temoin_accident_travail, 
 	FL5212 as prestation_compensation_handic, 
 	IDMCAT as catego_beneficiaire_oblig_emploi, 
 	FLMADE as temoin_mise_a_disposition_externe 
 	from vw_table""",
	   "table_name" -> "career.ZYHB_salarie_beneficiaire")


//------------ZYPR 
case "ZYPR" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	NUDOSP as ident_dossier_paie, 
 	RUBPRE as rubrique, 
 	ORDPRE as ordre_calcul, 
 	NUMPRE as numero_prêt, 
 	MONPR as montant_initial, 
 	DEBPRE as date_debut, 
 	FINPRE as date_fin, 
 	ECHPRE as nombre_echeances, 
 	MENPR as mensualite, 
 	SOLPR as solde, 
 	TXINTE as taux_interêt, 
 	MTINT as montant_interêt, 
 	DTCONC as date_concession 
 	from vw_table""",
	   "table_name" -> "career.ZYPR_prets_et_saisies")


//------------ZYRG 
case "ZYRG" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	MONT1 as somme_des_planchers, 
 	MONT2 as somme_des_plafon, 
 	MONT3 as somme_des_assiettes, 
 	MONT4 as somme_des_minima, 
 	MONT5 as regularisation_5, 
 	RESUL as somme_des_bases_cotisees 
 	from vw_table""",
	   "table_name" -> "career.ZYRG_regularisations_cotisations")


//------------ZYTL 
case "ZYTL" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DATEFF as date_effet, 
 	CODTRA as type_temps_contractuel, 
 	NBSTHW as heures_presencesemaine, 
 	NBSTHM as heures_presencemois, 
 	RTSTHR as pourc_h_presencetemps_plein, 
 	NBPDHW as heures_payeessemaine, 
 	NBPDHM as heures_payeesmois, 
 	FORANU as forfait_annuel_en_jours, 
 	MODHOR as modalite_horaire, 
 	NBSTHD as heures_presencejour, 
 	RTPDHR as pourc_h_payeestemps_plein 
 	from vw_table""",
	   "table_name" -> "career.ZYTL_heures_contractuelles")


//------------ZYWB 
case "ZYWB" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DATNOT as date_notification, 
 	PREEFF as preavis_effectue, 
 	DADEB1 as debut_preavis_effectue, 
 	DAFIN1 as fin_preavis_effectue, 
 	PREPAY as preavis_non_effectue_paye, 
 	DADEB2 as debut_preavis_non_effectue_paye, 
 	DAFIN2 as fin_preavis_non_effectue_paye, 
 	DAPHYS as date_paiement_anticipe, 
 	PRENPA as preavis_non_effectue_non_paye, 
 	DADEB3 as debut_preavis_non_effectue_non_paye, 
 	DAFIN3 as fin_preavis_non_effectue_non_paye, 
 	PRENEF as preavis_non_effectue, 
 	MOTIFS as motif_non_paiement_preavis 
 	from vw_table""",
	   "table_name" -> "career.ZYWB_preavis")


//------------ZYWV 
case "ZYWV" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	DATDEB as date_debut, 
 	DATFIN as date_fin, 
 	TYPDET as type_detachement, 
 	PAYDET as pays_detachement, 
 	SITFAM as situation_famille_sur_place, 
 	RESFIS as residant_fiscal_hors_france, 
 	NUMORD as numero_ordre_interne 
 	from vw_table""",
	   "table_name" -> "career.ZYWV_expatries_type_detachement")


//------------ZYWW 
case "ZYWW" =>
	Map( "query_record" -> """ select 
	NUDOSS as numero_dossier,
	CODREG as code_regime_cotisations, 
 	DATDEB as date_debut, 
 	DATFIN as date_fin, 
 	REPART as repartition_salariale_patronale 
 	from vw_table""",
	   "table_name" -> "career.ZYWW_regime_cotisation_expatries")



 case default => null
    }
  
   return query
}
