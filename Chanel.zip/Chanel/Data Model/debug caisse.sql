/*

select * from [career].[ZYWW_regime_cotisation_expatries] 
where numero_dossier = 3649


select * from [career].[ZYCS_caisses] 
where numero_dossier = 3649

select count(distinct numero_dossier) from [career].[ZYCS_caisses] 
where numero_dossier in (select numero_dossier from [career].[ZYWW_regime_cotisation_expatries])

select * from [career].[ZYCS_caisses] 
where numero_dossier in (select numero_dossier from [career].[ZYWW_regime_cotisation_expatries])

*/


--ALTER  VIEW career.vw_caisse AS

SELECT
	  a.code_regime_cotisations AS zyww_code_regime_cotisations
 	 ,a.date_debut AS zyww_date_debut
 	 ,a.date_fin AS zyww_date_fin
 	 ,a.repartition_salariale_patronale AS zyww_repartition_salariale_patronale
	 ,b.identifiant_dossier_paie AS zycs_identifiant_dossier_paie
 	 ,b.code_caisse AS zycs_code_caisse
 	 ,b.regime_retraite AS zycs_regime_retraite
 	 ,b.date_debut AS zycs_date_debut
 	 ,b.date_fin AS zycs_date_fin
 	 ,b.numero_inscription AS zycs_numero_inscription
	 ,b.identifiant_contrat AS zycs_identifiant_contrat
 	 ,b.motif_rupture_contrat AS zycs_motif_rupture_contrat
 	 ,b.motif_sortie AS zycs_motif_sortie
 	 ,b.temoin_mise_a_jour_manuelle AS zycs_temoin_mise_a_jour_manuelle
	 ,c.matricule_hra
	 ,c.matricule_workday
	 ,c.prenom_employe
	 ,c.nom_employe
	 ,c.date_anciennete
	 ,c.anciennete



FROM [career].[ZYWW_regime_cotisation_expatries] a
FULL JOIN [career].[ZYCS_caisses] b ON a.numero_dossier = b.numero_dossier AND a.date_debut >= b.date_debut AND a.date_fin <= b.date_fin
LEFT JOIN [career].[identification] c ON b.numero_dossier = c.numero_dossier

--where a.numero_dossier is null