SELECT
  ZYAF_affectation_consolidee.date_effet
  ,ZYAF_affectation_consolidee.date_fin
  ,ZYAF_affectation_consolidee.niveau_5
  ,ZYAF_affectation_consolidee.niveau_7
  ,commun_zy38_affectation_etablissement.etablissement
  ,commun_zy3b_affectation.unite_organisationnelle
  ,commun_zyca_carriere.code_convention_collective
  ,commun_zyca_carriere.classification
  ,commun_zyca_carriere.qualification
  ,commun_zyco_contrat.nature
  ,commun_zyco_contrat.type_contrat
  ,commun_zyes_entrees_departs.date_entree
  ,commun_zyes_entrees_departs.date_sortie_administrative
  ,identification.matricule_hra
  ,identification.matricule_workday
  ,identification.prenom_employe
  ,identification.nom_employe
  ,identification.date_anciennete
  ,identification.anciennete
FROM
  career.ZYAF_affectation_consolidee AS ZYAF_affectation_consolidee
  LEFT OUTER JOIN career.commun_zyco_contrat AS commun_zyco_contrat
    ON ZYAF_affectation_consolidee.id_zyco_contrat = commun_zyco_contrat.id
  LEFT OUTER JOIN career.commun_zyca_carriere AS commun_zyca_carriere
    ON ZYAF_affectation_consolidee.id_zyca_carriere = commun_zyca_carriere.id
  LEFT OUTER JOIN career.commun_zyes_entrees_departs AS commun_zyes_entrees_departs
    ON ZYAF_affectation_consolidee.id_zyes_entrees_departs = commun_zyes_entrees_departs.id
  LEFT OUTER JOIN career.commun_zy3b_affectation AS commun_zy3b_affectation
    ON ZYAF_affectation_consolidee.id_zy3b_unite_organisationelle = commun_zy3b_affectation.id
  LEFT OUTER JOIN career.commun_zy38_affectation_etablissement AS commun_zy38_affectation_etablissement
    ON ZYAF_affectation_consolidee.id_zy38_etablissement = commun_zy38_affectation_etablissement.id
  LEFT OUTER JOIN career.identification AS identification
    ON ZYAF_affectation_consolidee.numero_dossier = identification.numero_dossier
ORDER BY ZYAF_affectation_consolidee.numero_dossier , ZYAF_affectation_consolidee.date_effet