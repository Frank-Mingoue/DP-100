SELECT distinct c.*, b.type_contrat, b.nature,  d.classification, d.code_convention_collective, d.qualification, e.etablissement, f.unite_organisationnelle
from [absences].[compte_epargne] a
left join [career].[commun_zyco_contrat] b on b.id = a.id_zyco_contrat
left join [career].[identification] c on c.numero_dossier = a.numero_dossier
left join [career].[commun_zyca_carriere] d on d.id = a.id_zyca_carriere
left join [career].[commun_zy38_affectation_etablissement] e on e.id = a.id_zy38_etablissement
left join [career].[commun_zy3b_affectation] f on e.id  = f.id_zy38_etablissement
where c.matricule_workday in ('W00013560','W00011125', 'W00011173', 'W00011211')


