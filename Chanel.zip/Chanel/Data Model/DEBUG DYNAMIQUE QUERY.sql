select * from [career].[vw_ZYAF_affectation_consolidee]  where nom_employe = 'LARSONN'

exec dynamic_query @table ='career.vw_ZYAF_affectation_consolidee', @prenomEmploye ='ANASS',@nomEmploye='EL MADANI',@matriculeHRA='060153',@matriculeWD='GEN000010',
@etablissement='F19M - 19M PARIS',@centreDeCout='S5680CE07',@codeConventionCCN='CO - Couture',@classification='CAD - Ing�nieurs et cadres',@qualification='CAD - Cadre',
@nature='DI - Contrat � dur�e ind�termin�e (CDI)',@typeContrat='DI - Dur�e ind�termin�e',@anciennete='5 � 10 ans'

exec dynamic_query @table ='career.vw_ZYAF_affectation_consolidee', @prenomEmploye ='',@nomEmploye='',@matriculeHRA='',@matriculeWD='',
@etablissement='F19M - 19M PARIS',@centreDeCout='S5680CE07',@codeConventionCCN='CO - Couture',@classification='CAD - Ing�nieurs et cadres',@qualification='CAD - Cadre',
@nature='DI - Contrat � dur�e ind�termin�e (CDI)',@typeContrat='DI - Dur�e ind�termin�e',@anciennete='5 � 10 ans'


exec dynamic_query 'FCCV - CHANEL COORDINATION CHAMANT'

select * from #Temp
select * from #Temp
drop table #Temp

select * from [career].[identification] where prenom_employe like '%LARSONN%' or nom_employe like '%LARSONN%' 