/****** Object:  View [pay].[vw_zx8k_elements_remuneration]    Script Date: 10/11/2022 15:29:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--ALTER  VIEW [pay].[vw_zx8k_elements_remuneration] as 
SELECT
  ZX8K_elements_remuneration.numero_dossier AS [ZX8K_elements_remuneration numero_dossier]
  ,ZX8K_elements_remuneration.code_element_remuneration
  ,ZX8K_elements_remuneration.periode_valorisation
  ,ZX8K_elements_remuneration.[date]
  ,ZX8K_elements_remuneration.rappel_automatique
  ,ZX8K_elements_remuneration.source
  ,ZX8K_elements_remuneration.code_calcul
  ,ZX8K_elements_remuneration.libelle_element_remuneration
  ,ZX8K_elements_remuneration.nombre_ou_base
  ,ZX8K_elements_remuneration.taux_salarial
  ,ZX8K_elements_remuneration.montant_salarial
  ,ZX8K_elements_remuneration.taux_patronal
  ,ZX8K_elements_remuneration.montant_patronal
  ,ZX8K_elements_remuneration.imputation
  ,ZX8K_elements_remuneration.zone_utilisateur
  ,ZX8K_elements_remuneration.code_absence
  ,ZX8K_elements_remuneration.date_debut_absence
  ,ZX8K_elements_remuneration.date_fin_absence
  ,ZX8K_elements_remuneration.memo_01
  ,ZX8K_elements_remuneration.memo_02
  ,ZX8K_elements_remuneration.memo_03
  ,ZX8K_elements_remuneration.memo_04
  ,ZX8K_elements_remuneration.memo_05
  ,ZX8K_elements_remuneration.memo_06
  ,ZX8K_elements_remuneration.memo_07
  ,ZX8K_elements_remuneration.memo_08
  ,ZX8K_elements_remuneration.memo_09
  ,ZX8K_elements_remuneration.memo_10
  ,ZX8K_elements_remuneration.memo_11
  ,ZX8K_elements_remuneration.code_organisme
  ,ZX8K_elements_remuneration.libelle_organisme
  ,ZX8K_elements_remuneration.qualifiant_numero_1
  ,ZX8K_elements_remuneration.qualifiant_numero_2
  ,ZX8K_elements_remuneration.qualifiant_numero_3
  ,ZX8K_elements_remuneration.qualifiant_numero_4
  ,ZX8K_elements_remuneration.qualifiant_numero_5
  ,ZX8K_elements_remuneration.qualifiant_numero_6
  ,ZX8K_elements_remuneration.qualifiant_numero_7
  ,ZX8K_elements_remuneration.qualifiant_numero_8
  ,ZX8K_elements_remuneration.bas_tableau
  ,ZX8K_elements_remuneration.position_dans_le_journal_paie
  ,ZX8K_elements_remuneration.alimentation_colonne_nombre_ou_base
  ,ZX8K_elements_remuneration.nb_decimales_colonne_nombre_ou_base
  ,ZX8K_elements_remuneration.alimentation_la_colonne_taux
  ,ZX8K_elements_remuneration.colonne_montant
  ,ZX8K_elements_remuneration.position_rubrique_sur_bulletin
  ,ZX8K_elements_remuneration.position_rubrique_sur_fiche_annexe
  ,ZX8K_elements_remuneration.position_rubrique_sur_fiche_euro
  ,ZX8K_elements_remuneration.periode_paie AS [ZX8K_elements_remuneration periode_paie]
  ,filtres.numero_dossier AS [filtres numero_dossier]
  ,filtres.matricule_hra
  ,filtres.matricule_WD
  ,filtres.nom_salarie
  ,filtres.prenom_salarie
  ,filtres.date_entree
  ,filtres.date_sortie
  ,filtres.etablissement
  ,filtres.code_convention_CCN
  ,filtres.date_anciennete
  ,filtres.anciennete
  ,filtres.qualification
  ,filtres.classification
  ,filtres.type_contrat
  ,filtres.nature_contrat
  ,filtres.type_temps_contractuel
  ,filtres.heures_presence_mois
  ,filtres.periode_paie 
  ,filtres.identifiant_dossier_paie 
  ,filtres.numero_bulletin 
  ,filtres.type_paie 


FROM
  pay.ZX8K_elements_remuneration AS ZX8K_elements_remuneration
  LEFT OUTER JOIN pay.filtres AS filtres
    ON ZX8K_elements_remuneration.numero_dossier = filtres.numero_dossier

WHERE 
filtres.matricule_hra IN ('006976') AND 
--filtres.matricule_WD IN () AND 
--filtres.nom_salarie IN () AND
--filtres.prenom_salarie IN () AND 
--filtres.etablissement IN () AND
filtres.code_convention_CCN IN ('CH - Chimie', 'CO - Couture','HA - Habillement',' ') AND 
--filtres.anciennete IN (@anciennete) AND 
filtres.qualification IN ('AMT - Technicien & agent de ma?trise','AMT - Technicien AM','ASS - Assimil? cadre','CAD - Cadre','ENQ - Empl. non qualifi?','ENQ - Employ? non qualifi?','EQU - Employ? qualifi?','ONQ - Ouvr. non qualifi?','ONQ - Ouvrier non qualifi?','OQU - Ouvrier qualifi?','PEN - Pensionn?','STA - Stagiaire') AND 
filtres.classification IN ('CAD - Cadres','CAD - Ing?nieurs et cadres','ETA - Employ?s Techniciens et Agents de Ma?trise','ETA - ETAM','OUV - Ouvriers','PEN - Pensionn?s','STA - Stagiaires') AND 
filtres.type_contrat IN ('DD - Dur�e d�termin�e','DI - Dur�e ind�termin�e','PE - Pensionn�','ST - Stagiaire','VA - Vacataire') AND
filtres.nature_contrat IN ('AE - Auxiliaire d''�t�', 'CA - Contrat d''apprentissage', 'CO - Contrat � dur�e d�termin�e � objet d�fini', 'DD - Contrat � dur�e d�termin�e (CDD)', 'DE - D�tach�s (CDI)', 'DI - Contrat � dur�e ind�termin�e (CDI)', 'P1 - Contrat de professionnalisation dipl�me < IV', 'P2 - Contrat de professionnalisation dipl�me >= IV', 'P3 - Contrat de professionnalisation dipl�me > V', 'PE - Pensionn�', 'S1 - Sur Activ. DUREE > 1 mois et <= 3 mois', 'S2 - Sur Activ. DUREE INF ou EGALE = 1 mois', 'SA - Stagiaires de moins de 2 mois (<=)', 'SB - Stagiaires de plus de 2 mois (>)', 'SR - Surcro�t d''activit� > 3 mois', 'SX - Stagiaires �tranger de moins de 2 mois', 'SY - Stagiaires �tranger de plus de 2 mois', 'VA - Contrat saisonnier (Vacataires)') AND
filtres.periode_paie IN ('MT201501', 'MT201502')--, 'MT201503', 'MT201504', 'MT201505', 'MT201506', 'MT201507', 'MT201508', 'MT201509', 'MT201510', 'MT201511', 'MT201512', 'MT201601', 'MT201602', 'MT201603', 'MT201604', 'MT201605', 'MT201606', 'MT201607', 'MT201608', 'MT201609', 'MT201610', 'MT201611', 'MT201612', 'MT201701', 'MT201702', 'MT201703', 'MT201704', 'MT201705', 'MT201706', 'MT201707', 'MT201708', 'MT201709', 'MT201710', 'MT201711', 'MT201712', 'MT201801', 'MT201802', 'MT201803', 'MT201804', 'MT201805', 'MT201806', 'MT201807', 'MT201808', 'MT201809', 'MT201810', 'MT201811', 'MT201812', 'MT201901', 'MT201902', 'MT201903', 'MT201904', 'MT201905', 'MT201906', 'MT201907', 'MT201908', 'MT201909', 'MT201910', 'MT201911', 'MT201912', 'MT202001', 'MT202002', 'MT202003', 'MT202004', 'MT202005', 'MT202006', 'MT202007', 'MT202008', 'MT202009', 'MT202010', 'MT202011', 'MT202012', 'MT202101', 'MT202102', 'MT202103', 'MT202104', 'MT202105', 'MT202106', 'MT202107', 'MT202108', 'MT202109', 'MT202110', 'MT202111', 'MT202112', 'MT202201', 'MT202202', 'MT202203', 'MT202204', 'MT202205', 'MT202206') 


