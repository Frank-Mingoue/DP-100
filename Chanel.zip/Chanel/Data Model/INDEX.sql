CREATE CLUSTERED INDEX [ZX8K] ON [pay].[ZX8K_elements_remuneration]
(
	[numero_dossier] ASC
	
)


CREATE CLUSTERED INDEX [ZXMM] ON [pay].[ZXMM_dsn_montants]
(
	[numero_dossier] ASC
	
)


CREATE CLUSTERED INDEX [ZX6C] ON [pay].[ZX6C_cumuls_paie]
(
	[numero_dossier] ASC
	
)

CREATE CLUSTERED INDEX [ZX3B] ON [pay].[ZX3B_conges_payes]
(
	[numero_dossier] ASC
	
)