select ZXMM_dsn_montants.* from [pay].[ZXMM_dsn_montants]
JOIN [pay].[filtres] ON filtres.numero_dossier = ZXMM_dsn_montants.numero_dossier
WHERE filtres.matricule_hra = 100889 AND ZXMM_dsn_montants.periode_paie like '%2021%'

SELECT zxmm.periode_paie, count(*) FROM [pay].[ZXMM_dsn_montants] zxmm
JOIN [pay].[filtres] ON filtres.numero_dossier = zxmm.numero_dossier
WHERE filtres.matricule_hra = 100889 AND zxmm.periode_paie like '%2021%'
group by zxmm.periode_paie
order by 1


SELECT zxmm.* FROM [pay].[ZXMM_dsn_montants] zxmm
JOIN [pay].[filtres] ON filtres.numero_dossier = zxmm.numero_dossier
WHERE filtres.matricule_hra = 100889 AND zxmm.periode_paie = 'MT202112'
order by code_element_remuneration

select ZXMM_dsn_montants.* from [pay].[ZXMM_dsn_montants]
WHERE  ZXMM_dsn_montants.numero_dossier = 2474847