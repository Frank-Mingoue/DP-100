SELECT * FROM [career].[ZYES_entrees_departs]
WHERE numero_dossier NOT IN (select numero_dossier from [career].[ZYCO_contrat])

select * from [career].[ZYES_entrees_departs] zyes
full join [career].[ZYCO_contrat] zyco on zyes.numero_dossier = zyco.numero_dossier 
and  zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative


with zyes as (SELECT * FROM [career].[commun_ZYES_entrees_departs]
WHERE numero_dossier IN (select numero_dossier from [career].[commun_ZYCO_contrat])),
zyco AS (SELECT * FROM [career].[commun_ZYCO_contrat]
WHERE numero_dossier IN (select numero_dossier from [career].[commun_ZYES_entrees_departs]))
SELECT * FROM zyes 
full join zyco on zyes.numero_dossier = zyco.numero_dossier 
and zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative 
WHERE zyes.numero_dossier IS NULL




with zyes as (SELECT * FROM [career].[commun_ZYES_entrees_departs]
WHERE numero_dossier IN (select numero_dossier from [career].[commun_ZYCO_contrat])),
zyco AS (SELECT * FROM [career].[commun_ZYCO_contrat]
WHERE numero_dossier IN (select numero_dossier from [career].[commun_ZYES_entrees_departs]))
SELECT * FROM zyes 
full join zyco on zyes.numero_dossier = zyco.numero_dossier 
and  (
(zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative) 
OR (zyco.date_debut_contrat < zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative and zyco.date_fin_contrat  > zyes.date_entree  ) 
OR (zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat > zyes.date_sortie_administrative and zyco.date_debut_contrat <zyes.date_sortie_administrative))
WHERE zyco.numero_dossier IS NULL
order by 2 ,3

SELECT * FROM [career].[commun_zyco_contrat] WHERE numero_dossier = 2515 ORDER BY date_debut_contrat
SELECT * FROM [career].[commun_zyes_entrees_departs] WHERE numero_dossier = 2515 ORDER BY date_entree



--final query

with T1 as (SELECT 
case 
 when zyes.numero_dossier is not null then zyes.numero_dossier 
 else zyco.numero_dossier 
 end as numero_dossier
 ,zyes.date_entree
 ,zyes.date_sortie_administrative
 ,zyco.date_debut_contrat
 ,zyco.date_fin_contrat
 ,zyco.type_contrat
 ,zyco.nature
 
FROM [career].[commun_ZYES_entrees_departs] zyes 
full join [career].[commun_ZYCO_contrat] zyco on zyes.numero_dossier = zyco.numero_dossier 
and  (
(zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative) 
OR (zyco.date_debut_contrat < zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative and zyco.date_fin_contrat  > zyes.date_entree  ) 
OR (zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat > zyes.date_sortie_administrative and zyco.date_debut_contrat <zyes.date_sortie_administrative))
)
select * from T1 
where numero_dossier = 1999
order by 3

--(zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative) ==> zyco.date_debut_contrat as date_debut , zyco.date_fin_contrat as date_fin
--(zyco.date_debut_contrat < zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative and zyco.date_fin_contrat  > zyes.date_entree  ) ==>
--(zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat > zyes.date_sortie_administrative and zyco.date_debut_contrat <zyes.date_sortie_administrative)) ==>


with T1 as (SELECT 
case 
 when zyes.numero_dossier is not null then zyes.numero_dossier 
 else zyco.numero_dossier 
 end as numero_dossier
 ,zyes.date_entree
 ,zyes.date_sortie_administrative
 ,zyco.date_debut_contrat
 ,zyco.date_fin_contrat
 ,zyco.type_contrat
 ,zyco.nature
 ,case 
  when zyes.numero_dossier is null and zyco.numero_dossier is not null then zyco.date_debut_contrat
  when zyco.numero_dossier is null and zyes.numero_dossier is not null then zyes.date_entree
  when zyco.date_debut_contrat = zyes.date_entree then zyes.date_entree
  when zyco.date_debut_contrat < zyes.date_entree then zyes.date_entree
  when zyes.date_entree < zyco.date_debut_contrat then zyco.date_debut_contrat
  end as date_debut 

  ,case 
  when zyes.numero_dossier is null and zyco.numero_dossier is not null then zyco.date_fin_contrat
  when zyco.numero_dossier is null and zyes.numero_dossier is not null then zyes.date_sortie_administrative
  when zyco.date_fin_contrat = zyes.date_sortie_administrative then zyes.date_sortie_administrative
  when zyco.date_fin_contrat < zyes.date_sortie_administrative then zyco.date_fin_contrat
  when zyes.date_sortie_administrative < zyco.date_fin_contrat then zyes.date_sortie_administrative
  end as date_fin

FROM [career].[commun_ZYES_entrees_departs] zyes 
full join [career].[commun_ZYCO_contrat] zyco on zyes.numero_dossier = zyco.numero_dossier 
and  (
(zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative) 
OR (zyco.date_debut_contrat < zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative and zyco.date_fin_contrat  > zyes.date_entree  ) 
OR (zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat > zyes.date_sortie_administrative and zyco.date_debut_contrat <zyes.date_sortie_administrative))
)
select * from T1 
--where numero_dossier = 3497
order by 8