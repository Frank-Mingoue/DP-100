DROP TABLE IF EXISTS [career].[filtres]; 

CREATE TABLE [career].[filtres](
	[numero_dossier] [int] NULL,
	[date_entree] [date] NULL,
	[date_sortie_administrative] [date] NULL,
	[type_contrat] VARCHAR(max) NULL,
	[nature] VARCHAR(max) NULL,
	[etablissement] VARCHAR(max) NULL,
	[unite_organisationnelle] VARCHAR(max) NULL,
	[classification] VARCHAR(max) NULL,
	[qualification] VARCHAR(max) NULL,
	[type_temps_contractuel] VARCHAR(max) NULL,
	[heures_presencemois] DECIMAL(5, 2),
	[date_debut] [date] NULL,
	[date_fin] [date] NULL
) 

DROP TABLE IF EXISTS [pay].[filtres]; 
 
 CREATE TABLE [pay].[filtres] ( 
	numero_dossier INT,
	matricule_hra VARCHAR(12),
	matricule_WD VARCHAR(40),
	nom_salarie VARCHAR(40),
	prenom_salarie VARCHAR(30),
	date_entree DATE,
	date_sortie DATE,
	etablissement VARCHAR(MAX),
	code_convention_CCN VARCHAR(MAX),
	date_anciennete DATE,
	anciennete varchar(25),
	qualification VARCHAR(MAX),
	classification VARCHAR(MAX),
	type_contrat VARCHAR(MAX),
	nature_contrat VARCHAR(MAX),
	type_temps_contractuel VARCHAR(MAX),
	heures_presence_mois DECIMAL(5, 2),
	periode_paie VARCHAR(8),
	identifiant_dossier_paie INT,  
 	numero_bulletin VARCHAR(2), 
 	type_paie VARCHAR(1)
 	)



DROP TABLE IF EXISTS [pay].[ZX00_identification]; 
 
 CREATE TABLE [pay].[ZX00_identification] ( 
 	numero_dossier INT, 
 	reglementation VARCHAR(MAX), 
 	identification VARCHAR(10), 
 	identifiant_dossier_paie INT, 
 	periode_paie VARCHAR(8), 
 	numero_bulletin VARCHAR(2), 
 	type_paie VARCHAR(1), 
 	nom_salarie VARCHAR(40), 
 	horodatage_chargement DATE, 
 	)


DROP TABLE IF EXISTS [pay].[ZX0M_description_des_contrats]; 
 
 CREATE TABLE [pay].[ZX0M_description_des_contrats] ( 
 	numero_dossier INT, 
 	identifiant_contrat VARCHAR(3), 
 	date_debut DATE, 
 	date_fin_contrat DATE, 
 	type_contrat VARCHAR(MAX), 
 	libelle_types_contrat VARCHAR(45), 
 	nature_contrat VARCHAR(MAX), 
 	libelle_natures_contrat VARCHAR(45), 
 	duree_anse INT, 
 	duree_moise INT, 
 	duree_jourse INT, 
 	debut_periode_essai DATE, 
 	fin_periode_essai DATE, 
 	categorie_espagnee VARCHAR(MAX), 
 	libelle_la_categorie VARCHAR(45), 
 	classification VARCHAR(MAX), 
 	filler VARCHAR(10), 
 	libelle_la_classification VARCHAR(45), 
 	position VARCHAR(MAX), 
 	libelle_la_position VARCHAR(45), 
 	indice VARCHAR(MAX), 
 	libelle_indice VARCHAR(45), 
 	coefficient VARCHAR(MAX), 
 	libelle_coefficient VARCHAR(45), 
 	niveau_echelon VARCHAR(10), 
 	niveau VARCHAR(1), 
 	echelon VARCHAR(1), 
 	code_convention_collective VARCHAR(MAX), 
 	libelle_la_convention_collective VARCHAR(45), 
 	etablissement VARCHAR(MAX), 
 	libelle_etablissement VARCHAR(45), 
 	type_temps_contractuel VARCHAR(MAX), 
 	libelle_type_temps_contractuel VARCHAR(45), 
 	heures_presencejour DECIMAL(4, 2), 
 	heures_presencesemaine DECIMAL(4, 2), 
 	heures_presencemois DECIMAL(5, 2), 
 	pourc_h_presencetemps_plein DECIMAL(5, 2), 
 	heures_payeesjour DECIMAL(4, 2), 
 	heures_payeessemaine DECIMAL(4, 2), 
 	heures_payeesmois DECIMAL(5, 2), 
 	pourc_h_payeestemps_plein DECIMAL(5, 2), 
 	salaires VARCHAR(10), 
 	rubrique VARCHAR(MAX), 
 	libelle_rubrique VARCHAR(45), 
 	montant_salaire INT, 
 	montant_horaire INT, 
 	montant_par_periode_paie INT, 
 	coefficient_base_chimie VARCHAR(3), 
 	coefficient_personnel_chimie VARCHAR(3), 
 	coefficient_specialite_chimie VARCHAR(3), 
 	niveau_chimie VARCHAR(1), 
 	echelon_chimie VARCHAR(1), 
 	groupe_couture VARCHAR(1), 
 	niveau_couture VARCHAR(1), 
 	forfait_annuel_en_jours INT, 
	periode_paie VARCHAR(8),
 	)


DROP TABLE IF EXISTS [pay].[ZX35_dates]; 
 
 CREATE TABLE [pay].[ZX35_dates] ( 
 	numero_dossier INT, 
 	date_entree DATE, 
 	date_sortie DATE, 
 	date_sortie_physique DATE, 
 	motif_entree VARCHAR(3), 
 	libelle_motif_entree VARCHAR(45), 
 	motif_sortie VARCHAR(3), 
 	libelle_motif_sortie VARCHAR(45), 
 	cat_situat_salarie_reeentre VARCHAR(6), 
 	libelle_la_cat_sit_sal_reente VARCHAR(45), 
 	motif_situation_reeentree VARCHAR(6), 
 	libelle_motif_situation_reente VARCHAR(45), 
 	cat_situat_salarie_suite_sortie VARCHAR(6), 
 	libelle_la_categ_sal_sort VARCHAR(45), 
 	motif_situation_suite_a_sortie VARCHAR(6), 
 	libelle_motif_situation_sortie VARCHAR(45), 
 	date_anciennete_1 DATE, 
 	date_anciennete_2 DATE, 
 	date_anciennete_3 DATE, 
 	date_anciennete_4 DATE, 
 	date_anciennete_5 DATE, 
 	date_anciennete_6 DATE, 
	periode_paie VARCHAR(8),
 	)


DROP TABLE IF EXISTS [pay].[ZX37_affectations_geographiques]; 
 
 CREATE TABLE [pay].[ZX37_affectations_geographiques] ( 
 	numero_dossier INT, 
 	etablissement VARCHAR(MAX), 
 	libelle_etablissement VARCHAR(45), 
 	niveau_1 VARCHAR(10), 
 	niveau_2 VARCHAR(10), 
 	niveau_3 VARCHAR(10), 
 	niveau_4 VARCHAR(10), 
	periode_paie VARCHAR(8),
 	)


DROP TABLE IF EXISTS [pay].[ZX38_carriere]; 
 
 CREATE TABLE [pay].[ZX38_carriere] ( 
 	numero_dossier INT, 
 	qualification VARCHAR(8), 
 	classification VARCHAR(8), 
 	libelle_statut VARCHAR(45), 
 	libelle_la_classification VARCHAR(45), 
 	code_convention_collective VARCHAR(8), 
 	regime_special_cotisation VARCHAR(MAX), 
 	libelle_la_convention_collective VARCHAR(45), 
	periode_paie VARCHAR(8),
 	)


DROP TABLE IF EXISTS [pay].[ZX3B_conges_payes]; 
 
 CREATE TABLE [pay].[ZX3B_conges_payes] ( 
 	numero_dossier INT, 
 	code_conge VARCHAR(MAX), 
 	annee_reference DATE, 
 	identifiant_entreesortie INT, 
 	date_debut_consommation DATE, 
 	date_fin_consommation DATE, 
 	date_debut_acquisition DATE, 
 	date_fin_acquisition DATE, 
 	droits_acquis DECIMAL(5, 2), 
 	droits_pris DECIMAL(5, 2), 
 	droits_restants DECIMAL(5, 2), 
	periode_paie VARCHAR(8),
 	) ON myMonthlyRangePS (periode_paie)


DROP TABLE IF EXISTS [pay].[ZX40_heures_contractuelles]; 
 
 CREATE TABLE [pay].[ZX40_heures_contractuelles] ( 
 	numero_dossier INT, 
 	date_effet DATE, 
 	type_temps_contractuel VARCHAR(2), 
 	libelle_type_temps_contractuel VARCHAR(45), 
 	heures_presencejour DECIMAL(4, 2), 
 	heures_presencesemaine DECIMAL(4, 2), 
 	heures_presencemois DECIMAL(5, 2), 
 	pourc_h_presencetemps_plein DECIMAL(5, 2), 
 	heures_payeesjour DECIMAL(4, 2), 
 	heures_payeessemaine DECIMAL(4, 2), 
 	heures_payeesmois DECIMAL(5, 2), 
 	pourc_h_payeestemps_plein DECIMAL(5, 2), 
 	forfait_annuel_en_jours INT, 
 	forfait_annuel_heures DECIMAL(6, 2), 
	periode_paie VARCHAR(8),
 	)


DROP TABLE IF EXISTS [pay].[ZX5V_statut_dossier]; 
 
 CREATE TABLE [pay].[ZX5V_statut_dossier] ( 
 	numero_dossier INT, 
 	temoin_validite VARCHAR(1), 
 	horodatage_validite DATE, 
	periode_paie VARCHAR(8),
 	)


DROP TABLE IF EXISTS [pay].[ZX6A_absences]; 
 
 CREATE TABLE [pay].[ZX6A_absences] ( 
 	numero_dossier INT, 
 	date_debut_absence DATE, 
 	identifiant_element_remuneration VARCHAR(12), 
 	code_absence VARCHAR(3), 
 	source_absence VARCHAR(1), 
 	libelle_absence VARCHAR(45), 
 	date_fin_absence DATE, 
	periode_paie VARCHAR(8),
 	)


DROP TABLE IF EXISTS [pay].[ZX6C_cumuls_paie]; 
 
 CREATE TABLE [pay].[ZX6C_cumuls_paie] ( 
 	numero_dossier INT, 
 	numero_cumul VARCHAR(MAX), 
 	periode_debut_cumul VARCHAR(6), 
 	libelle_cumul VARCHAR(45), 
 	montant_cumul DECIMAL(15, 4), 
	periode_paie VARCHAR(8),
 	)ON myMonthlyRangePS (periode_paie)


DROP TABLE IF EXISTS [pay].[ZX6P_prets_et_saisies]; 
 
 CREATE TABLE [pay].[ZX6P_prets_et_saisies] ( 
 	numero_dossier INT, 
 	code_rubrique VARCHAR(3), 
 	numero_ordre INT, 
 	numero_pret VARCHAR(17), 
 	libelle_la_rubrique VARCHAR(45), 
 	montant_initial INT, 
 	date_debut DATE, 
 	date_fin DATE, 
 	nombre_echeances INT, 
 	montant_une_mensualite INT, 
 	solde INT, 
 	taux_interet DECIMAL(5, 2), 
 	montants_des_interets INT, 
 	date_concession DATE, 
 	date_virement_capital DATE, 
 	capital_non_amorti INT, 
 	solde_avant_paie INT, 
	periode_paie VARCHAR(8),
 	)


DROP TABLE IF EXISTS [pay].[ZX8K_elements_remuneration]; 
 
 CREATE TABLE [pay].[ZX8K_elements_remuneration] ( 
 	numero_dossier INT, 
 	code_element_remuneration VARCHAR(MAX), 
 	periode_valorisation INT, 
 	date DATE, 
 	rappel_automatique VARCHAR(1), 
 	source VARCHAR(1), 
 	code_calcul VARCHAR(1), 
 	libelle_element_remuneration VARCHAR(45), 
 	nombre_ou_base DECIMAL(13, 4), 
 	taux_salarial DECIMAL(13, 4), 
 	montant_salarial DECIMAL(13, 4), 
 	taux_patronal DECIMAL(13, 4), 
 	montant_patronal DECIMAL(13, 4), 
 	imputation VARCHAR(24), 
 	zone_utilisateur VARCHAR(20), 
 	code_absence VARCHAR(3), 
 	date_debut_absence DATE, 
 	date_fin_absence DATE, 
 	memo_01 VARCHAR(15), 
 	memo_02 VARCHAR(15), 
 	memo_03 VARCHAR(8), 
 	memo_04 VARCHAR(8), 
 	memo_05 VARCHAR(5), 
 	memo_06 VARCHAR(5), 
 	memo_07 VARCHAR(5), 
 	memo_08 VARCHAR(5), 
 	memo_09 VARCHAR(3), 
 	memo_10 VARCHAR(3), 
 	memo_11 VARCHAR(3), 
 	code_organisme VARCHAR(15), 
 	libelle_organisme VARCHAR(45), 
 	qualifiant_numero_1 VARCHAR(15), 
 	qualifiant_numero_2 VARCHAR(15), 
 	qualifiant_numero_3 VARCHAR(15), 
 	qualifiant_numero_4 VARCHAR(15), 
 	qualifiant_numero_5 VARCHAR(15), 
 	qualifiant_numero_6 VARCHAR(15), 
 	qualifiant_numero_7 VARCHAR(15), 
 	qualifiant_numero_8 VARCHAR(15), 
 	bas_tableau VARCHAR(1), 
 	position_dans_le_journal_paie VARCHAR(2), 
 	alimentation_colonne_nombre_ou_base VARCHAR(1), 
 	nb_decimales_colonne_nombre_ou_base INT, 
 	alimentation_la_colonne_taux VARCHAR(1), 
 	colonne_montant VARCHAR(1), 
 	position_rubrique_sur_bulletin VARCHAR(2), 
 	position_rubrique_sur_fiche_annexe VARCHAR(2), 
 	position_rubrique_sur_fiche_euro VARCHAR(2), 
	periode_paie VARCHAR(8),
 	)  ON myMonthlyRangePS (periode_paie) 


DROP TABLE IF EXISTS [pay].[ZXM7_compte_epargne]; 
 
 CREATE TABLE [pay].[ZXM7_compte_epargne] ( 
 	numero_dossier INT, 
 	type_compte VARCHAR(MAX), 
 	date_ouverture DATE, 
 	date_fermeture DATE, 
 	solde_compte DECIMAL(7, 4), 
 	solde_temps_plein DECIMAL(7, 4), 
 	solde_en_heures_temps_plein INT, 
 	date_utilisation DATE, 
 	date_fin_utilisation DATE, 
	periode_paie VARCHAR(8),
 	)


DROP TABLE IF EXISTS [pay].[ZXMM_dsn_montants]; 
 
 CREATE TABLE [pay].[ZXMM_dsn_montants] ( 
 	numero_dossier INT, 
 	code_compteur_n VARCHAR(MAX), 
 	code_element_remuneration VARCHAR(MAX), 
 	source VARCHAR(1), 
 	zone_cible_n VARCHAR(10), 
 	categorie_compteur_n VARCHAR(3), 
 	code_bloc VARCHAR(10), 
 	suite_categorie VARCHAR(10), 
 	valeur_typecode_structure_n VARCHAR(4), 
 	montant_ou_mesure DECIMAL(13, 4), 
 	nbre_heures_ou_montant_assiette DECIMAL(13, 4), 
 	taux DECIMAL(13, 4), 
 	date_1 DATE, 
 	date_2 DATE, 
 	date_debut_la_periode_origine DATE, 
 	date_fin_la_periode_origine DATE, 
 	id_ops_destinataire VARCHAR(14), 
 	type_organisme VARCHAR(MAX), 
 	qualifiant_assiette VARCHAR(3), 
 	code_insee_commune VARCHAR(5), 
 	taux_cotis_effectif_a_cumulere DECIMAL(13, 4), 
 	code_affiliation_prev VARCHAR(10), 
 	periode_paie VARCHAR(8), 
 	taux_applique_a_base VARCHAR(10), 
 	)ON myMonthlyRangePS (periode_paie)


DROP TABLE IF EXISTS [career].[ZY19_dates_anciennete]; 
 
 CREATE TABLE [career].[ZY19_dates_anciennete] ( 
 	numero_dossier INT, 
 	date_anciennete_1 DATE, 
 	date_anciennete_2 DATE, 
 	date_anciennete_3 DATE, 
 	date_anciennete_4 DATE, 
 	date_anciennete_5 DATE, 
 	date_anciennete_6 DATE, 
 	)


DROP TABLE IF EXISTS [career].[ZY1M_vehicules]; 
 
 CREATE TABLE [career].[ZY1M_vehicules] ( 
 	numero_dossier INT, 
 	numero_immatriculation VARCHAR(15), 
 	pays VARCHAR(MAX), 
 	date_debut DATE, 
 	date_fin DATE, 
 	date_immatriculation DATE, 
 	puissance_vehicule INT, 
 	type_vehicule VARCHAR(6), 
 	constructeur VARCHAR(10), 
 	modele VARCHAR(20), 
 	cylindree INT, 
 	carburant VARCHAR(MAX), 
 	valeur_vehicule INT, 
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [career].[ZY1S_statut]; 
 
 CREATE TABLE [career].[ZY1S_statut] ( 
 	numero_dossier INT, 
 	date_effet_la_situation DATE, 
 	situation VARCHAR(MAX), 
 	categorie_situation VARCHAR(MAX), 
 	motif_situation VARCHAR(MAX), 
 	occurrences_generees_par_un_conge VARCHAR(MAX), 
 	)


DROP TABLE IF EXISTS [career].[ZY24_type_transport]; 
 
 CREATE TABLE [career].[ZY24_type_transport] ( 
 	numero_dossier INT, 
 	identifiant_dossier_paie INT, 
 	type_transport VARCHAR(MAX), 
 	date_effet DATE, 
 	date_fin DATE, 
 	identifiant_contrat VARCHAR(3),
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [career].[ZY35_affectation_principale_salarie]; 
 
 CREATE TABLE [career].[ZY35_affectation_principale_salarie] ( 
 	numero_dossier INT, 
 	date_effet DATE, 
 	emploi VARCHAR(10), 
 	pourcentage_affectation VARCHAR(3), 
 	libelle_long_reel VARCHAR(60), 
 	poste VARCHAR(10), 
 	unite_organisation VARCHAR(10), 
 	libelle_court_reel VARCHAR(20), 
 	)


DROP TABLE IF EXISTS [career].[ZY38_affectation_etablissement]; 
 
 CREATE TABLE [career].[ZY38_affectation_etablissement] ( 
 	numero_dossier INT, 
 	date_debut DATE, 
 	date_fin DATE, 
 	etablissement VARCHAR(MAX), 
 	motif_la_mutation VARCHAR(MAX), 
 	date_effet_la_mutation DATE, 
 	)


DROP TABLE IF EXISTS [career].[ZY3B_affectation]; 
 
 CREATE TABLE [career].[ZY3B_affectation] ( 
 	numero_dossier INT, 
 	date_effet DATE, 
 	date_fin DATE, 
 	horaires_affectation DECIMAL(4, 2), 
 	equivalences_temps_plein DECIMAL(5, 2), 
 	date_arrivee_dans_le_poste DATE, 
 	code_poste VARCHAR(10), 
 	identifiant_emploi VARCHAR(10), 
 	unite_organisationnelle VARCHAR(10), 
 	pourcentage_affectation INT, 
 	)


DROP TABLE IF EXISTS [career].[ZY4K_repartition_comptable]; 
 
 CREATE TABLE [career].[ZY4K_repartition_comptable] ( 
 	numero_dossier INT, 
 	centre_cout_1 VARCHAR(MAX), 
 	souscompte_1 VARCHAR(MAX), 
 	date_effet DATE, 
 	date_fin DATE, 
 	pourcentage_repartition DECIMAL(5, 2), 
 	)


DROP TABLE IF EXISTS [career].[ZY5G_affectations_cycle]; 
 
 CREATE TABLE [career].[ZY5G_affectations_cycle] ( 
 	numero_dossier INT, 
 	identifiant_contrat VARCHAR(3), 
 	date_debut DATE, 
 	date_fin DATE, 
 	code VARCHAR(MAX), 
 	index_zy5g INT, 
 	)


DROP TABLE IF EXISTS [career].[ZYAF_affectation_consolidee]; 
 
 CREATE TABLE [career].[ZYAF_affectation_consolidee] ( 
 	numero_dossier INT, 
 	date_effet DATE, 
 	date_fin DATE, 
 	niveau_5 VARCHAR(10), 
 	niveau_7 VARCHAR(10),
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [absences].[ZYAG_absences]; 
 
 CREATE TABLE [absences].[ZYAG_absences] ( 
 	numero_dossier INT, 
 	date_debut DATE, 
 	motif VARCHAR(MAX), 
 	heure_debut INT, 
 	date_fin DATE, 
 	heure_fin INT, 
 	temoin_midi_debut VARCHAR(1), 
 	temoin_midi_fin VARCHAR(1), 
 	temoin_gestion VARCHAR(1), 
 	temoin_prolongation VARCHAR(1), 
 	nombre_heures INT, 
 	motif_situation_resultant VARCHAR(MAX), 
 	situation_au_retour VARCHAR(MAX), 
 	categorie_situation_au_retour VARCHAR(MAX), 
 	cat_situation_au_retour_redefiniee VARCHAR(10), 
 	motif_situation_au_retour VARCHAR(MAX), 
 	payenon_paye VARCHAR(1),
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [career].[ZYAR_taux_prelevement_source]; 
 
 CREATE TABLE [career].[ZYAR_taux_prelevement_source] ( 
 	numero_dossier INT, 
 	date_mise_a_disposition_crm DATE, 
 	numero_reference_crm VARCHAR(18), 
 	date_debut_validite_en_paie DATE, 
 	date_fin_validite_juridique DATE, 
 	taux_individuel_pas VARCHAR(5), 
 	type_bareme_en_cas_taux_neutre VARCHAR(1), 
 	temoin_injection_en_batch VARCHAR(1), 
 	temoin_crm_enrichi VARCHAR(1), 
 	date_mise_a_dispo_crm_enrichi DATE, 
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [career].[ZYAU_salaires]; 
 
 CREATE TABLE [career].[ZYAU_salaires] ( 
 	numero_dossier INT, 
 	date_effet DATE, 
 	rubrique VARCHAR(MAX), 
 	montant_salaire INT, 
 	motif_augmentation VARCHAR(MAX), 
 	montant_augmentation INT, 
 	date_fin DATE, 
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [career].[ZYCA_carriere]; 
 
 CREATE TABLE [career].[ZYCA_carriere] ( 
 	numero_dossier INT, 
 	date_debut DATE, 
 	date_fin DATE, 
 	qualification VARCHAR(MAX), 
 	classification VARCHAR(MAX), 
 	code_convention_collective VARCHAR(MAX), 
 	type_regime_cotisation_retraite VARCHAR(MAX), 
 	coefficient_base_chimie VARCHAR(3), 
 	coefficient_specialite_chimie VARCHAR(3), 
 	groupe_couture VARCHAR(1), 
 	niveau_couture VARCHAR(1), 
 	temoin_1 VARCHAR(MAX), 
 	coefficient_personnel_chimie VARCHAR(3), 
 	niveau_chimie VARCHAR(1), 
 	echelon_chimie VARCHAR(1), 
 	)


DROP TABLE IF EXISTS [career].[ZYCO_contrat]; 
 
 CREATE TABLE [career].[ZYCO_contrat] ( 
 	numero_dossier INT, 
 	date_debut_contrat DATE, 
 	date_fin_contrat DATE, 
 	type_contrat VARCHAR(MAX), 
 	nature VARCHAR(MAX), 
 	date_fin_presumee DATE, 
 	fin_periode_essai DATE, 
 	nombre_heures_contrat DECIMAL(4, 2), 
 	duree_clause_en_mois INT, 
 	montant_mensuel DECIMAL(15, 2), 
 	pourcentage_mensuel DECIMAL(5, 2), 
 	clause_contractuelle VARCHAR(MAX), 
 	clause_levee VARCHAR(MAX), 
 	)


DROP TABLE IF EXISTS [career].[ZYCS_caisses]; 
 
 CREATE TABLE [career].[ZYCS_caisses] ( 
 	numero_dossier INT, 
 	identifiant_dossier_paie INT, 
 	code_caisse VARCHAR(MAX), 
 	regime_retraite VARCHAR(MAX), 
 	date_debut DATE, 
 	date_fin DATE, 
 	numero_inscription VARCHAR(15), 
 	identifiant_contrat VARCHAR(3), 
 	motif_rupture_contrat VARCHAR(MAX), 
 	motif_sortie VARCHAR(MAX), 
 	temoin_mise_a_jour_manuelle VARCHAR(MAX), 
 	)


DROP TABLE IF EXISTS [career].[ZYCU_cumuls_paie]; 
 
 CREATE TABLE [career].[ZYCU_cumuls_paie] ( 
 	numero_dossier INT, 
 	identifiant_dossier_paie INT, 
 	numero VARCHAR(3), 
 	societe VARCHAR(3), 
 	siecle VARCHAR(2), 
 	annee VARCHAR(2), 
 	periode VARCHAR(2), 
 	montant DECIMAL(15, 4), 
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [absences].[ZYDA_absences_decoupees_droits]; 
 
 CREATE TABLE [absences].[ZYDA_absences_decoupees_droits] ( 
 	numero_dossier INT, 
 	date_debut_absence_ac DATE, 
 	motif_absence VARCHAR(MAX), 
 	heure_debut INT, 
 	numero_droit VARCHAR(3), 
 	date_debuttranche DATE, 
 	numero_tranche VARCHAR(1), 
 	date_fin_tranche DATE, 
 	heure_fin INT, 
 	temoin_midi_debut VARCHAR(1), 
 	temoin_midi_fin VARCHAR(1), 
 	duree_1 DECIMAL(5, 2), 
 	duree_2 DECIMAL(5, 2), 
 	nombre_jours DECIMAL(5, 2), 
 	date_debut_absence_gestion DATE, 
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [absences].[ZYDV_conges_payes]; 
 
 CREATE TABLE [absences].[ZYDV_conges_payes] ( 
 	numero_dossier INT, 
 	code_conge VARCHAR(MAX), 
 	annee_reference DATE, 
 	identifiant_entreesortie INT, 
 	date_debut_consommation DATE, 
 	date_fin_consommation DATE, 
 	date_debut_acquisition DATE, 
 	date_fin_acquisition DATE, 
 	droits_acquis DECIMAL(5, 2), 
 	report_annee_precedente DECIMAL(5, 2), 
 	droits_ecretes DECIMAL(5, 2), 
 	report_annee_suivante DECIMAL(5, 2), 
 	droits_payes DECIMAL(5, 2), 
 	droits_pris DECIMAL(5, 2), 
 	pris_pendant_chevauchement_1 DECIMAL(5, 2), 
 	pris_pendant_chevauchement_2 DECIMAL(5, 2), 
 	droits_restants DECIMAL(5, 2), 
 	ajustement_manuel_1 DECIMAL(5, 2), 
 	motif_ajustement_1 VARCHAR(MAX), 
 	ajustement_manuel_2 DECIMAL(5, 2), 
 	motif_ajustement_2 VARCHAR(MAX), 
 	ajustement_manuel_3 DECIMAL(5, 2), 
 	motif_ajustement_manuel_3 VARCHAR(MAX), 
 	ajustement_manuel_4 DECIMAL(5, 2), 
 	motif_ajustement_manuel_4 VARCHAR(MAX), 
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [absences].[ZYE4_compte_epargne]; 
 
 CREATE TABLE [absences].[ZYE4_compte_epargne] ( 
 	numero_dossier INT, 
 	type_compte VARCHAR(3), 
 	date_ouverture_compte DATE, 
 	date_fermeture_compte DATE, 
 	solde_compte_en_jours_ouvres DECIMAL(7, 4), 
 	solde_compte_theor_tps_pleine DECIMAL(7, 4), 
 	solde_compte_en_heures_tps_plein INT, 
 	date_utilisation DATE, 
 	date_fin_utilisation DATE, 
 	)


DROP TABLE IF EXISTS [absences].[ZYE6_operations_compte_epargne]; 
 
 CREATE TABLE [absences].[ZYE6_operations_compte_epargne] ( 
 	numero_dossier INT, 
 	date_operation DATE, 
 	type_operation VARCHAR(3), 
 	type_compte VARCHAR(3), 
 	nombre_jours_temps_plein DECIMAL(7, 4), 
 	numero_ordre INT, 
 	nombre_jours_epargnes DECIMAL(7, 4), 
 	nombre_jours_ouvres_epargnes DECIMAL(7, 4), 
 	nombre_heures_epargnees INT, 
 	montant_epargne INT, 
 	solde_compte_en_heures_tps_plein INT, 
 	code_origine VARCHAR(2), 
 	)


DROP TABLE IF EXISTS [career].[ZYEL_elements_fixes_paie]; 
 
 CREATE TABLE [career].[ZYEL_elements_fixes_paie] ( 
 	numero_dossier INT, 
 	identifiant_dossier_paie INT, 
 	code_rubrique VARCHAR(3), 
 	date_debut DATE, 
 	date_fin DATE, 
 	code_format_calcul VARCHAR(1), 
 	nombre_ou_base DECIMAL(12, 3), 
 	montant_ou_taux_salarial DECIMAL(12, 3), 
 	montant_ou_taux_patronal DECIMAL(12, 3), 
 	temoin_selection VARCHAR(1), 
 	centre_cout VARCHAR(10), 
 	memo_01 VARCHAR(15), 
 	memo_02 VARCHAR(15), 
 	date_1 DATE, 
 	date_2 DATE, 
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [career].[ZYES_entrees_departs]; 
 
 CREATE TABLE [career].[ZYES_entrees_departs] ( 
 	numero_dossier INT, 
 	date_entree DATE, 
 	motif_entree VARCHAR(MAX), 
 	identification_entree_sortie INT, 
 	date_sortie_administrative DATE, 
 	motif_sortie VARCHAR(MAX), 
 	date_sortie_physique DATE, 
 	societe VARCHAR(MAX), 
 	statut_resultant_la_sortie VARCHAR(MAX), 
 	cat_situation_apres_sortie_redefe VARCHAR(10), 
 	)


DROP TABLE IF EXISTS [career].[ZYHB_salarie_beneficiaire]; 
 
 CREATE TABLE [career].[ZYHB_salarie_beneficiaire] ( 
 	numero_dossier INT, 
 	date_debut DATE, 
 	date_decision DATE, 
 	date_fin DATE, 
 	duree_decision VARCHAR(1), 
 	temoin_chaumage_avant_embauche VARCHAR(MAX), 
 	temoin_reconnu_travailleur_handicape VARCHAR(MAX), 
 	placement_ea VARCHAR(MAX), 
 	placement_esta VARCHAR(MAX), 
 	placement_cdtd VARCHAR(MAX), 
 	temoin_invalide_pensionne VARCHAR(MAX), 
 	temoin_sapeur_pompier_volontaire VARCHAR(MAX), 
 	temoin_assimile_mutile_guerre VARCHAR(MAX), 
 	temoin_handicap_permanent_a_viee VARCHAR(MAX), 
 	temoin_mutile_guerre VARCHAR(MAX), 
 	temoin_beneficiaire_allocation VARCHAR(MAX), 
 	temoin_titulaire_allocation VARCHAR(MAX), 
 	temoin_malprofesacctravailtrajet INT, 
 	temoin_handicap_lourd VARCHAR(MAX), 
 	taux_invalidite DECIMAL(4, 2), 
 	date_debut_pension DATE, 
 	categorie_pension VARCHAR(1), 
 	taux_incapacite DECIMAL(4, 2), 
 	temoin_accident_travail INT, 
 	prestation_compensation_handic VARCHAR(MAX), 
 	catego_beneficiaire_oblig_emploi VARCHAR(2), 
 	temoin_mise_a_disposition_externe VARCHAR(2), 
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [career].[ZYPR_prets_et_saisies]; 
 
 CREATE TABLE [career].[ZYPR_prets_et_saisies] ( 
 	numero_dossier INT, 
 	ident_dossier_paie INT, 
 	rubrique VARCHAR(3), 
 	ordre_calcul INT, 
 	numero_pret VARCHAR(17), 
 	montant_initial INT, 
 	date_debut DATE, 
 	date_fin DATE, 
 	nombre_echeances INT, 
 	mensualite INT, 
 	solde INT, 
 	taux_interet DECIMAL(5, 2), 
 	montant_interet INT, 
 	date_concession DATE, 
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [career].[ZYRG_regularisations_cotisations]; 
 
 CREATE TABLE [career].[ZYRG_regularisations_cotisations] ( 
 	numero_dossier INT, 
 	somme_des_planchers INT, 
 	somme_des_plafon INT, 
 	somme_des_assiettes INT, 
 	somme_des_minima INT, 
 	regularisation_5 INT, 
 	somme_des_bases_cotisees INT, 
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [career].[ZYTL_heures_contractuelles]; 
 
 CREATE TABLE [career].[ZYTL_heures_contractuelles] ( 
 	numero_dossier INT, 
 	date_effet DATE, 
 	type_temps_contractuel VARCHAR(MAX), 
 	heures_presencesemaine DECIMAL(4, 2), 
 	heures_presencemois DECIMAL(5, 2), 
 	pourc_h_presencetemps_plein DECIMAL(5, 2), 
 	heures_payeessemaine DECIMAL(4, 2), 
 	heures_payeesmois DECIMAL(5, 2), 
 	forfait_annuel_en_jours INT, 
 	modalite_horaire VARCHAR(MAX), 
 	heures_presencejour DECIMAL(4, 2), 
 	pourc_h_payeestemps_plein DECIMAL(5, 2), 
 	)


DROP TABLE IF EXISTS [career].[ZYWB_preavis]; 
 
 CREATE TABLE [career].[ZYWB_preavis] ( 
 	numero_dossier INT, 
 	date_notification DATE, 
 	preavis_effectue VARCHAR(1), 
 	debut_preavis_effectue DATE, 
 	fin_preavis_effectue DATE, 
 	preavis_non_effectue_paye VARCHAR(1), 
 	debut_preavis_non_effectue_paye DATE, 
 	fin_preavis_non_effectue_paye DATE, 
 	date_paiement_anticipe DATE, 
 	preavis_non_effectue_non_paye VARCHAR(1), 
 	debut_preavis_non_effectue_non_paye DATE, 
 	fin_preavis_non_effectue_non_paye DATE, 
 	preavis_non_effectue VARCHAR(1), 
 	motif_non_paiement_preavis VARCHAR(30), 
	id_zyca_carriere INT,
	id_zy3b_unite_organisationelle INT,
	id_zy38_etablissement INT,
	id_zyes_entrees_departs INT,
	id_zyco_contrat INT,
	id_zytl_heures_contractuelles INT
 	)


DROP TABLE IF EXISTS [career].[ZYWV_expatries_type_detachement]; 
 
 CREATE TABLE [career].[ZYWV_expatries_type_detachement] ( 
 	numero_dossier INT, 
 	date_debut DATE, 
 	date_fin DATE, 
 	type_detachement VARCHAR(MAX), 
 	pays_detachement VARCHAR(MAX), 
 	situation_famille_sur_place VARCHAR(1), 
 	residant_fiscal_hors_france VARCHAR(1), 
 	numero_ordre_interne VARCHAR(20), 
 	)


DROP TABLE IF EXISTS [career].[ZYWW_regime_cotisation_expatries]; 
 
 CREATE TABLE [career].[ZYWW_regime_cotisation_expatries] ( 
 	numero_dossier INT, 
 	code_regime_cotisations VARCHAR(MAX), 
 	date_debut DATE, 
 	date_fin DATE, 
 	repartition_salariale_patronale INT, 
 	)
