--1234


declare @nudoss int = 717


--select * from [career].[ZYES_entrees_departs]
--where numero_dossier = @nudoss
--order by date_entree

--select * from [career].[ZYCO_contrat]
--where numero_dossier = @nudoss
--order by date_debut_contrat

--select * from [career].[ZYTL_heures_contractuelles]
--where numero_dossier = @nudoss
--order by date_effet

select * from [career].[ZY38_affectation_etablissement]
where numero_dossier = @nudoss
order by date_debut

select * from [career].[ZY3B_affectation]
where numero_dossier = @nudoss
order by date_effet

--select * from [career].[ZYCA_carriere]
--where numero_dossier = @nudoss
--order by date_debut
