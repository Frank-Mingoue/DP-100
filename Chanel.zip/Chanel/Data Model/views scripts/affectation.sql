/****** Object:  View [career].[vw_affectation]    Script Date: 10/7/2022 6:33:36 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE VIEW [career].[vw_affectation] as  SELECT DISTINCT
     zy35.date_effet as zy35_date_effet  
 	,zy35.emploi as zy35_emploi
 	,zy35.pourcentage_affectation as zy35_pourcentage_affectation
 	,zy35.libelle_long_reel as zy35_libelle_long_reel
 	,zy35.poste as zy35_poste
 	,zy35.unite_organisation as zy35_unite_organisation
 	,zy35.libelle_court_reel as zy35_libelle_court_reel
	,zy38.date_debut  as zy38_date_debut
 	,zy38.date_fin as zy38_date_fin
 	,zy38.etablissement as zy38_etablissement
 	,zy38.motif_la_mutation as zy38_motif_la_mutation
 	,zy38.date_effet_la_mutation as zy38_date_effet_la_mutation
	,zy3b.date_effet as zy3b_date_effet
 	,zy3b.date_fin  as zy3b_date_fin
 	,zy3b.horaires_affectation  as zy3b_horaires_affectation
 	,zy3b.equivalences_temps_plein  as zy3b_equivalences_temps_plein
 	,zy3b.date_arrivee_dans_le_poste as zy3b_date_arrivee_dans_le_poste
 	,zy3b.code_poste  as zy3b_code_poste
 	,zy3b.identifiant_emploi  as zy3b_identifiant_emploi
 	,zy3b.unite_organisationnelle  as zy3b_unite_organisationnelle
 	,zy3b.pourcentage_affectation as zy3b_pourcentage_affectationas
	,zy4K.centre_cout_1 as zy4k_centre_cout_1
 	,zy4K.souscompte_1 as zy4k_souscompte_1
 	,zy4K.date_effet as zy4k_date_effet
 	,zy4K.date_fin  as zy4k_date_fin
 	,zy4K.pourcentage_repartition as zy4k_pourcentage_repartition
	,identification.matricule_hra
	,identification.matricule_workday
	,identification.prenom_employe
	,identification.nom_employe
	,identification.date_anciennete
	,identification.anciennete
	--,ISNULL(zy38.etablissement, ' ') AS etablissement 
	--,ISNULL(zy3b.unite_organisationnelle, ' ') AS unite_organisationnelle
	,ISNULL(zyca.code_convention_collective, ' ') AS code_convention_collective
	,ISNULL(zyca.classification, ' ') AS classification
	,ISNULL(zyca.qualification, ' ') AS qualification
	,ISNULL(zyco.nature, ' ') AS nature
	,ISNULL(zyco.type_contrat, ' ') AS type_contrat
	,ISNULL(zyes.date_entree, ' ') AS date_entree
	,ISNULL(zyes.date_sortie_administrative, ' ') AS date_sortie_administrative

FROM [career].[ZY35_affectation_principale_salarie]  zy35
FULL JOIN [career].[ZY38_affectation_etablissement] zy38 ON zy38.numero_dossier = zy35.numero_dossier  AND zy35.date_effet >= zy38.date_debut    AND zy35.date_effet <= zy38.date_fin  
FULL JOIN [career].[ZY3B_affectation] zy3b ON zy3b.numero_dossier = zy38.numero_dossier AND zy3b.date_effet >= zy38.date_debut    AND zy3b.date_fin <= zy38.date_fin
FULL JOIN [career].[ZY4K_repartition_comptable] zy4K ON zy4K.numero_dossier = zy38.numero_dossier AND zy4K.date_effet >= zy38.date_debut    AND zy4K.date_fin <= zy38.date_fin
LEFT JOIN [career].[identification] identification ON identification.numero_dossier = zy35.numero_dossier
LEFT JOIN [career].[commun_zyes_entrees_departs] zyes ON zyes.numero_dossier = zy35.numero_dossier AND zy35.date_effet >= zyes.date_entree AND zy35.date_effet <= zyes.date_sortie_administrative
LEFT JOIN [career].[commun_zyca_carriere] zyca  ON zyca.numero_dossier = zy35.numero_dossier AND zy35.date_effet >= zyca.date_debut AND zy35.date_effet <= zyca.date_fin
LEFT JOIN [career].[commun_zyco_contrat] zyco ON zyco.numero_dossier = zy35.numero_dossier AND zy35.date_effet >= zyco.date_debut_contrat AND zy35.date_effet <= zyco.date_fin_contrat



GO

