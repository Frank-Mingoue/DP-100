/****** Object:  View [career].[vw_ZYAU_salaires]    Script Date: 10/7/2022 6:36:13 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [career].[vw_ZYAU_salaires] as 

SELECT DISTINCT
  ZYAU_salaires.date_effet
  ,ZYAU_salaires.rubrique
  ,ZYAU_salaires.montant_salaire
  ,ZYAU_salaires.motif_augmentation
  ,ZYAU_salaires.montant_augmentation
  ,ZYAU_salaires.date_fin
  ,isnull(zy38.etablissement, ' ') AS etablissement
  ,isnull(zy3b.unite_organisationnelle, ' ') AS unite_organisationnelle
  ,isnull(zyca.code_convention_collective, ' ') AS code_convention_collective
  ,isnull(zyca.classification, ' ') AS classification
  ,isnull(zyca.qualification, ' ') AS qualification
  ,isnull(zyco.nature, ' ') AS nature
  ,isnull(zyco.type_contrat, ' ') AS type_contrat
  ,isnull(zyes.date_entree, ' ') AS date_entree
  ,isnull(zyes.date_sortie_administrative, ' ') AS date_sortie_administrative
  ,identification.matricule_hra
  ,identification.matricule_workday
  ,identification.prenom_employe
  ,identification.nom_employe
  ,identification.date_anciennete
  ,identification.anciennete

FROM
  career.ZYAU_salaires AS ZYAU_salaires
 LEFT JOIN [career].[identification] identification ON ZYAU_salaires.numero_dossier = identification.numero_dossier
  LEFT JOIN [career].[commun_zyes_entrees_departs] zyes ON zyes.numero_dossier = ZYAU_salaires.numero_dossier AND ZYAU_salaires.date_effet >= zyes.date_entree AND ZYAU_salaires.date_fin <= zyes.date_sortie_administrative
  LEFT JOIN [career].[commun_zyca_carriere] zyca  ON zyca.numero_dossier = ZYAU_salaires.numero_dossier AND ZYAU_salaires.date_effet >= zyca.date_debut AND ZYAU_salaires.date_fin <= zyca.date_fin
  LEFT JOIN [career].[commun_zyco_contrat] zyco ON zyco.numero_dossier = ZYAU_salaires.numero_dossier AND ZYAU_salaires.date_effet >= zyco.date_debut_contrat AND ZYAU_salaires.date_fin <= zyco.date_fin_contrat
  LEFT JOIN [career].[commun_zy38_affectation_etablissement] zy38 ON zy38.numero_dossier = ZYAU_salaires.numero_dossier AND ZYAU_salaires.date_effet >= zy38.date_debut AND ZYAU_salaires.date_fin <= zy38.date_fin
  LEFT JOIN [career].[commun_zy3b_affectation] zy3b ON zy3b.numero_dossier = zy38.numero_dossier AND zy3b.date_effet >= zy38.date_debut   AND zy3b.date_fin <= zy38.date_fin
GO

