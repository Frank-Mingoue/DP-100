/****** Object:  View [career].[vw_caisse]    Script Date: 10/7/2022 6:37:30 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE  VIEW [career].[vw_caisse] AS

SELECT  DISTINCT
	  zyww.code_regime_cotisations AS zyww_code_regime_cotisations
 	 ,zyww.date_debut AS zyww_date_debut
 	 ,zyww.date_fin AS zyww_date_fin
 	 ,zyww.repartition_salariale_patronale AS zyww_repartition_salariale_patronale
	 ,zycs.identifiant_dossier_paie AS zycs_identifiant_dossier_paie
 	 ,zycs.code_caisse AS zycs_code_caisse
 	 ,zycs.regime_retraite AS zycs_regime_retraite
 	 ,zycs.date_debut AS zycs_date_debut
 	 ,zycs.date_fin AS zycs_date_fin
 	 ,zycs.numero_inscription AS zycs_numero_inscription
	 ,zycs.identifiant_contrat AS zycs_identifiant_contrat
 	 ,zycs.motif_rupture_contrat AS zycs_motif_rupture_contrat
 	 ,zycs.motif_sortie AS zycs_motif_sortie
 	 ,zycs.temoin_mise_a_jour_manuelle AS zycs_temoin_mise_a_jour_manuelle
	 ,identification.matricule_hra
	 ,identification.matricule_workday
	 ,identification.prenom_employe
	 ,identification.nom_employe
	 ,identification.date_anciennete
	 ,identification.anciennete
	 ,ISNULL(zy38.etablissement, ' ') AS etablissement 
	 ,ISNULL(zy3b.unite_organisationnelle, ' ') AS unite_organisationnelle
	 ,ISNULL(zyca.code_convention_collective, ' ') AS code_convention_collective
	 ,ISNULL(zyca.classification, ' ') AS classification
	 ,ISNULL(zyca.qualification, ' ') AS qualification
	 ,ISNULL(zyco.nature, ' ') AS nature
	 ,ISNULL(zyco.type_contrat, ' ') AS type_contrat
	 ,ISNULL(zyes.date_entree, ' ') AS date_entree
	 ,ISNULL(zyes.date_sortie_administrative, ' ') AS date_sortie_administrative

FROM [career].[ZYWW_regime_cotisation_expatries] zyww
FULL JOIN [career].[ZYCS_caisses] zycs ON zyww.numero_dossier = zycs.numero_dossier AND zyww.date_debut >= zycs.date_debut AND zyww.date_fin <= zycs.date_fin
LEFT JOIN [career].[identification] identification ON zycs.numero_dossier = identification.numero_dossier
LEFT JOIN [career].[commun_zyes_entrees_departs] zyes ON zyes.numero_dossier = zycs.numero_dossier AND zycs.date_debut >= zyes.date_entree AND zycs.date_fin <= zyes.date_sortie_administrative
LEFT JOIN [career].[commun_zyca_carriere] zyca  ON zyca.numero_dossier = zycs.numero_dossier AND zycs.date_debut >= zyca.date_debut AND zycs.date_fin <= zyca.date_fin
LEFT JOIN [career].[commun_zyco_contrat] zyco ON zyco.numero_dossier = zycs.numero_dossier AND zycs.date_debut >= zyco.date_debut_contrat AND zycs.date_fin <= zyco.date_fin_contrat
LEFT JOIN [career].[commun_zy38_affectation_etablissement] zy38 ON zy38.numero_dossier = zycs.numero_dossier AND zycs.date_debut >= zy38.date_debut AND zycs.date_fin <= zy38.date_fin
LEFT JOIN [career].[commun_zy3b_affectation] zy3b ON zy3b.numero_dossier = zy38.numero_dossier AND zy3b.date_effet >= zy38.date_debut   AND zy3b.date_fin <= zy38.date_fin  
--GO


GO

