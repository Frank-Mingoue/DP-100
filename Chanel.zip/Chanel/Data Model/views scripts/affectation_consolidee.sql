/****** Object:  View [career].[vw_ZYAF_affectation_consolidee]    Script Date: 10/7/2022 6:34:35 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE view [career].[vw_ZYAF_affectation_consolidee] as SELECT
   ZYAF_affectation_consolidee.date_effet
  ,ZYAF_affectation_consolidee.date_fin
  ,ZYAF_affectation_consolidee.niveau_5
  ,ZYAF_affectation_consolidee.niveau_7
  ,isnull(commun_zy38_affectation_etablissement.etablissement, ' ') AS etablissement
  ,isnull(commun_zy3b_affectation.unite_organisationnelle, ' ') AS unite_organisationnelle
  ,isnull(commun_zyca_carriere.code_convention_collective, ' ') AS code_convention_collective
  ,isnull(commun_zyca_carriere.classification, ' ') AS classification
  ,isnull(commun_zyca_carriere.qualification, ' ') AS qualification
  ,isnull(commun_zyco_contrat.nature, ' ') AS nature
  ,isnull(commun_zyco_contrat.type_contrat, ' ') AS type_contrat
  ,isnull(commun_zyes_entrees_departs.date_entree, ' ') AS date_entree
  ,isnull(commun_zyes_entrees_departs.date_sortie_administrative, ' ') AS date_sortie_administrative
  ,identification.matricule_hra
  ,identification.matricule_workday
  ,identification.prenom_employe
  ,identification.nom_employe
  ,identification.date_anciennete
  ,identification.anciennete
FROM
  career.ZYAF_affectation_consolidee AS ZYAF_affectation_consolidee
  LEFT OUTER JOIN career.commun_zyco_contrat AS commun_zyco_contrat
    ON ZYAF_affectation_consolidee.id_zyco_contrat = commun_zyco_contrat.id
  LEFT OUTER JOIN career.commun_zyca_carriere AS commun_zyca_carriere
    ON ZYAF_affectation_consolidee.id_zyca_carriere = commun_zyca_carriere.id
  LEFT OUTER JOIN career.commun_zyes_entrees_departs AS commun_zyes_entrees_departs
    ON ZYAF_affectation_consolidee.id_zyes_entrees_departs = commun_zyes_entrees_departs.id
  LEFT OUTER JOIN career.commun_zy3b_affectation AS commun_zy3b_affectation
    ON ZYAF_affectation_consolidee.id_zy3b_unite_organisationelle = commun_zy3b_affectation.id
  LEFT OUTER JOIN career.commun_zy38_affectation_etablissement AS commun_zy38_affectation_etablissement
    ON ZYAF_affectation_consolidee.id_zy38_etablissement = commun_zy38_affectation_etablissement.id
  LEFT OUTER JOIN career.identification AS identification
    ON ZYAF_affectation_consolidee.numero_dossier = identification.numero_dossier

GO

