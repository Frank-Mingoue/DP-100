
 
 DROP TABLE IF EXISTS [absences].[ZYE4_ZYE6_compte_epargne]; 
 
 CREATE TABLE [absences].[ZYE4_ZYE6_compte_epargne] ( 
 	numero_dossier INT, 
	date_operation DATE, 
 	type_compte VARCHAR(MAX),
	type_operation VARCHAR(MAX),
	nombre_jours_temps_plein DECIMAL(7, 4), 
 	numero_ordre INT, 
 	nombre_jours_epargnes DECIMAL(7, 4), 
 	nombre_jours_ouvres_epargnes DECIMAL(7, 4), 
 	nombre_heures_epargnees INT, 
 	montant_epargne INT, 
 	solde_compte_en_heures_tps_plein_oce INT, 
 	code_origine VARCHAR(2), 
 	date_ouverture_compte DATE, 
 	date_fermeture_compte DATE, 
 	solde_compte_en_jours_ouvres DECIMAL(7, 4), 
 	solde_compte_theor_tps_pleine DECIMAL(7, 4), 
 	solde_compte_en_heures_tps_plein_ce INT,
	[date_entree] [date] NULL,
	[date_sortie_administrative] [date] NULL,
	[societe] VARCHAR(max) NULL,
	[type_contrat] VARCHAR(max) NULL,
	[nature] VARCHAR(max) NULL,
	[etablissement] VARCHAR(max) NULL,
	[unite_organisationnelle] VARCHAR(max) NULL,
	[classification] VARCHAR(max) NULL,
	[qualification] VARCHAR(max) NULL,
	[code_convention_collective] VARCHAR(max) NULL,
	[type_temps_contractuel] VARCHAR(max) NULL,
	[heures_presencemois] DECIMAL(5, 2),
	[date_debut_filtre] [date] NULL,
	[date_fin_filtre] [date] NULL,
	[matricule_hra] [varchar](19) NULL,
	[matricule_workday] [varchar](12) NULL,
	[prenom_employe] [varchar](30) NULL,
	[nom_employe] [varchar](40) NULL,
	[date_anciennete] [date] NULL,
	[anciennete] [varchar](25) NULL
 	)


 DROP TABLE IF EXISTS [career].[commun_zy38_affectation_etablissement]; 
 
 CREATE TABLE [career].[commun_zy38_affectation_etablissement] (
	
	id INT identity(1,1),
	numero_dossier INT, 
 	date_debut DATE, 
 	date_fin DATE, 
 	etablissement VARCHAR(MAX)
 
 )


 DROP TABLE IF EXISTS [career].[commun_zy3b_affectation]; 
 
 CREATE TABLE [career].[commun_zy3b_affectation] (

	id INT identity(1,1),
	numero_dossier INT, 
 	date_effet DATE, 
 	date_fin DATE,  	 
 	unite_organisationnelle VARCHAR(1) 
 
 )


 DROP TABLE IF EXISTS [career].[commun_zyca_carriere]; 
 
 CREATE TABLE [career].[commun_zyca_carriere] (

	id INT identity(1,1),
	numero_dossier INT, 
 	date_debut DATE, 
 	date_fin DATE, 
 	qualification VARCHAR(MAX), 
 	classification VARCHAR(MAX), 
 	code_convention_collective VARCHAR(MAX) 
 
 )


 DROP TABLE IF EXISTS [career].[commun_zyco_contrat]; 
 
 CREATE TABLE [career].[commun_zyco_contrat] (

	id INT identity(1,1),
	numero_dossier INT, 
 	date_debut_contrat DATE, 
 	date_fin_contrat DATE, 
 	type_contrat VARCHAR(MAX), 
 	nature VARCHAR(MAX) 
 
 )


 DROP TABLE IF EXISTS [career].[commun_zyes_entrees_departs]; 
 
 CREATE TABLE [career].[commun_zyes_entrees_departs] (

	id INT identity(1,1),
	numero_dossier INT, 
 	date_entree DATE,  
 	date_sortie_administrative DATE
 
 )

 DROP TABLE IF EXISTS [career].[commun_zytl_heures_contractuelles]; 
 
 CREATE TABLE [career].[commun_zytl_heures_contractuelles] ( 
	id INT identity(1,1),
 	numero_dossier INT, 
 	date_effet DATE, 
 	type_temps_contractuel VARCHAR(), 
 	heures_presencemois DECIMAL(5, 2) 
  
 	)


	/****** Object:  Table [career].[identification]    Script Date: 10/7/2022 11:23:30 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[career].[identification]') AND type in (N'U'))
DROP TABLE [career].[identification]
GO

/****** Object:  Table [career].[identification]    Script Date: 10/7/2022 11:23:30 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [career].[identification](
	[numero_dossier] [int] NULL,
	[matricule_hra] [varchar](19) NULL,
	[matricule_workday] [varchar](12) NULL,
	[prenom_employe] [varchar](30) NULL,
	[nom_employe] [varchar](40) NULL,
	[date_anciennete] [date] NULL,
	[anciennete] [varchar](25) NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [career].[ZY35_ZY38_ZY3B_ZY4K_affectation]; 

CREATE TABLE [career].[ZY35_ZY38_ZY3B_ZY4K_affectation](
	[numero_dossier] [int] NULL,
	[zy38_date_debut] [date] NULL,
	[zy38_date_fin] [date] NULL,
	[zy38_etablissement] [varchar](60) NULL,
	[zy38_motif_la_mutation] [varchar](60) NULL,
	[zy38_date_effet_la_mutation] [date] NULL,
	[zy3b_date_effet] [date] NULL,
	[zy3b_date_fin] [date] NULL,
	[zy3b_horaires_affectation] [DECIMAL](4, 2) NULL,
	[zy3b_equivalences_temps_plein] [DECIMAL](5, 2) NULL,
	[zy3b_date_arrivee_dans_le_poste] [date] NULL,
	[zy3b_code_poste] [varchar](10) NULL,
	[zy3b_identifiant_emploi] [varchar](10) NULL,
	[zy3b_unite_organisationnelle] [varchar](10) NULL,
	[zy3b_pourcentage_affectation] [int] NULL,
	[zy35_date_effet] [date] NULL,
	[zy35_emploi] [varchar](10) NULL,
	[zy35_pourcentage_affectation] [varchar](3) NULL,
	[zy35_libelle_long_reel] [varchar](60) NULL,
	[zy35_poste] [varchar](10) NULL,
	[zy35_unite_organisation] [varchar](10) NULL,
	[zy35_libelle_court_reel] [varchar](20) NULL,
	[zy4k_centre_cout_1] [varchar](60) NULL,
	[zy4k_souscompte_1] [varchar](60) NULL,
	[zy4k_date_effet] [date] NULL,
	[zy4k_date_fin] [date] NULL,
	[zy4k_pourcentage_repartition] [DECIMAL](5, 2) NULL,
	[date_entree] [date] NULL,
	[date_sortie_administrative] [date] NULL,
	[societe] VARCHAR(45) NULL,
	[type_contrat] VARCHAR(25) NULL,
	[nature] VARCHAR(52) NULL,
	[etablissement] VARCHAR(45) NULL,
	[unite_organisationnelle] VARCHAR(12) NULL,
	[classification] VARCHAR(50) NULL,
	[qualification] VARCHAR(38) NULL,
	[code_convention_collective] VARCHAR(18) NULL,
	[type_temps_contractuel] VARCHAR(52) NULL,
	[heures_presencemois] DECIMAL(5, 2),
	[date_debut_filtre] [date] NULL,
	[date_fin_filtre] [date] NULL,
	[matricule_hra] [varchar](19) NULL,
	[matricule_workday] [varchar](12) NULL,
	[prenom_employe] [varchar](30) NULL,
	[nom_employe] [varchar](40) NULL,
)	


DROP TABLE IF EXISTS [career].[ZYCO_ZYWV_ZYES_ZYCA_ZY1S_ZY19_contrat]; 

CREATE TABLE [career].[ZYCO_ZYWV_ZYES_ZYCA_ZY1S_ZY19_contrat](
	[numero_dossier] [int] NULL,
	[zyes_date_entree] [date] NULL,
	[zyes_motif_entree] [varchar](max) NULL,
	[zyes_identification_entree_sortie] [int] NULL,
	[zyes_date_sortie_administrative] [date] NULL,
	[zyes_motif_sortie] [varchar](max) NULL,
	[zyes_date_sortie_physique] [date] NULL,
	[zyes_societe] [varchar](max) NULL,
	[zyes_statut_resultant_la_sortie] [varchar](max) NULL,
	[zyco_date_debut_contrat] [date] NULL,
	[zyco_date_fin_contrat] [date] NULL,
	[zyco_type_contrat] [varchar](max) NULL,
	[zyco_nature] [varchar](max) NULL,
	[zyco_date_fin_presumee] [date] NULL,
	[zyco_fin_periode_essai] [date] NULL,
	[zyco_nombre_heures_contrat] DECIMAL(4, 2)  NULL,
	[zyco_duree_clause_en_mois] [int] NULL,
	[zyco_montant_mensuel] DECIMAL(15, 2) NULL,
	[zyco_pourcentage_mensuel] DECIMAL(5, 2) NULL,
	[zyco_clause_contractuelle] [varchar](max) NULL,
	[zyco_clause_levee] [varchar](max) NULL,
	[zyca_date_debut] [date] NULL,
	[zyca_date_fin] [date] NULL,
	[zyca_qualification] [varchar](max) NULL,
	[zyca_classification] [varchar](max) NULL,
	[zyca_code_convention_collective] [varchar](max) NULL,
	[zyca_type_regime_cotisation_retraite] [varchar](max) NULL,
	[zyca_coefficient_base_chimie] [varchar](3) NULL,
	[zyca_coefficient_specialite_chimie] [varchar](3) NULL,
	[zyca_groupe_couture] [varchar](1) NULL,
	[zyca_niveau_couture] [varchar](1) NULL,
	[zyca_temoin_1] [varchar](max) NULL,
	[zyca_coefficient_personnel_chimie] [varchar](3) NULL,
	[zyca_niveau_chimie] [varchar](1) NULL,
	[zyca_echelon_chimie] [varchar](1) NULL,
	[zywv_date_debut] [date] NULL,
	[zywv_date_fin] [date] NULL,
	[zywv_type_detachement] [varchar](max) NULL,
	[zywv_pays_detachement] [varchar](max) NULL,
	[zywv_situation_famille_sur_place] [varchar](1) NULL,
	[zywv_residant_fiscal_hors_france] [varchar](1) NULL,
	[zywv_numero_ordre_interne] [varchar](20) NULL,
	[zy1s_date_effet_la_situation] [date] NULL,
	[zy1s_situation] [varchar](max) NULL,
	[zy1s_categorie_situation] [varchar](max) NULL,
	[zy1s_motif_situation] [varchar](max) NULL,
	[zy1s_occurrences_generees_par_un_conge] [varchar](max) NULL,
	[zy19_date_anciennete_1] [date] NULL,
	[zy19_date_anciennete_2] [date] NULL,
	[zy19_date_anciennete_3] [date] NULL,
	[zy19_date_anciennete_4] [date] NULL,
	[zy19_date_anciennete_5] [date] NULL,
	[zy19_date_anciennete_6] [date] NULL,
	[zy19_matricule_hra] [varchar](max) NULL,
	[date_entree] [date] NULL,
	[date_sortie_administrative] [date] NULL,
	[societe] VARCHAR(45) NULL,
	[type_contrat] VARCHAR(25) NULL,
	[nature] VARCHAR(52) NULL,
	[etablissement] VARCHAR(45) NULL,
	[unite_organisationnelle] VARCHAR(12) NULL,
	[classification] VARCHAR(50) NULL,
	[qualification] VARCHAR(38) NULL,
	[code_convention_collective] VARCHAR(18) NULL,
	[type_temps_contractuel] VARCHAR(52) NULL,
	[heures_presencemois] DECIMAL(5, 2),
	[date_debut_filtre] [date] NULL,
	[date_fin_filtre] [date] NULL,
	[matricule_hra] [varchar](19) NULL,
	[matricule_workday] [varchar](12) NULL,
	[prenom_employe] [varchar](30) NULL,
	[nom_employe] [varchar](40) NULL
)

DROP TABLE IF EXISTS [career].[ZYTL_ZY5G_heures_contractuelles];

CREATE TABLE [career].[ZYTL_ZY5G_heures_contractuelles](
	[numero_dossier] [int] NULL,
	[zytl_date_effet] [date] NULL,
	[zytl_date_fin] [date] NULL,
	[zytl_type_temps_contractuel] [nvarchar](max) NULL,
	[zytl_heures_presencesemaine] DECIMAL (4, 2) NULL,
	[zytl_heures_presencemois] DECIMAL(5, 2) NULL,
	[zytl_pourc_h_presencetemps_plein] DECIMAL(5, 2) NULL,
	[zytl_heures_payeessemaine] DECIMAL(4, 2) NULL,
	[zytl_heures_payeesmois] DECIMAL(5, 2) NULL,
	[zytl_forfait_annuel_en_jours] [int] NULL,
	[zytl_modalite_horaire] [nvarchar](max) NULL,
	[zytl_heures_presencejour] DECIMAL(4, 2) NULL,
	[zytl_pourc_h_payeestemps_plein] DECIMAL(5, 2) NULL,
	[zy5g_date_debut] [date] NULL,
	[zy5g_date_fin] [date] NULL,
	[zy5g_code] [nvarchar](max) NULL,
	[zy5g_index] [int] NULL,
	[date_entree] [date] NULL,
	[date_sortie_administrative] [date] NULL,
	[societe] VARCHAR(45) NULL,
	[type_contrat] VARCHAR(25) NULL,
	[nature] VARCHAR(52) NULL,
	[etablissement] VARCHAR(45) NULL,
	[unite_organisationnelle] VARCHAR(12) NULL,
	[classification] VARCHAR(50) NULL,
	[qualification] VARCHAR(38) NULL,
	[code_convention_collective] VARCHAR(18) NULL,
	[type_temps_contractuel] VARCHAR(52) NULL,
	[heures_presencemois] DECIMAL(5, 2),
	[date_debut_filtre] [date] NULL,
	[date_fin_filtre] [date] NULL,
	[matricule_hra] [varchar](19) NULL,
	[matricule_workday] [varchar](12) NULL,
	[prenom_employe] [varchar](30) NULL,
	[nom_employe] [varchar](40) NULL
)


DROP TABLE IF EXISTS [career].[ZYCS_ZYWW_caisse];

CREATE TABLE [career].[ZYCS_ZYWW_caisse](
	[numero_dossier] [int] NULL,
	[zycs_identifiant_dossier_paie] [int] NULL,
	[zycs_code_caisse] [nvarchar](max) NULL,
	[zycs_regime_retraite] [nvarchar](max) NULL,
	[zycs_date_debut] [date] NULL,
	[zycs_date_fin] [date] NULL,
	[zycs_numero_inscription] [nvarchar](15) NULL,
	[zycs_identifiant_contrat] [nvarchar](3) NULL,
	[zycs_motif_rupture_contrat] [nvarchar](max) NULL,
	[zycs_motif_sortie] [nvarchar](max) NULL,
	[zycs_temoin_mise_a_jour_manuelle] [nvarchar](max) NULL,
	[zyww_date_debut] [date] NULL,
	[zyww_date_fin] [date] NULL,
	[zyww_code_regime_cotisations] [nvarchar](max) NULL,
	[zyww_repartition_salariale_patronale] [int] NULL,
	[date_entree] [date] NULL,
	[date_sortie_administrative] [date] NULL,
	[societe] VARCHAR(45) NULL,
	[type_contrat] VARCHAR(25) NULL,
	[nature] VARCHAR(52) NULL,
	[etablissement] VARCHAR(45) NULL,
	[unite_organisationnelle] VARCHAR(12) NULL,
	[classification] VARCHAR(50) NULL,
	[qualification] VARCHAR(38) NULL,
	[code_convention_collective] VARCHAR(18) NULL,
	[type_temps_contractuel] VARCHAR(52) NULL,
	[heures_presencemois] DECIMAL(5, 2),
	[date_debut_filtre] [date] NULL,
	[date_fin_filtre] [date] NULL,
	[matricule_hra] [varchar](19) NULL,
	[matricule_workday] [varchar](12) NULL,
	[prenom_employe] [varchar](30) NULL,
	[nom_employe] [varchar](40) NULL
)