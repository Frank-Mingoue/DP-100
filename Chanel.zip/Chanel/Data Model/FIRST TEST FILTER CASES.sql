SELECT DISTINCT
  ISNULL (filtres.type_contrat ,' ') as type_contrat
FROM
  pay.filtres AS filtres
ORDER BY type_contrat  


SELECT DISTINCT
  ISNULL (filtres.qualification, ' ') as qualification
FROM
  pay.filtres AS filtres
ORDER BY qualification

SELECT DISTINCT
  filtres.periode_paie
FROM
  pay.filtres AS filtres
ORDER BY  filtres.periode_paie ASC