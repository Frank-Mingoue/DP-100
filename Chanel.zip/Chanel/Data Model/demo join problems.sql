select count (distinct numero_dossier) from [career].[commun_zyes_entrees_departs]
where numero_dossier not in (select distinct numero_dossier from [career].[commun_zyco_contrat])


select count (distinct numero_dossier) from [career].[commun_zyco_contrat]
where numero_dossier not in (select distinct numero_dossier from [career].[commun_zy38_affectation_etablissement]) 

select count (distinct numero_dossier) from [career].[commun_zy38_affectation_etablissement]
where numero_dossier not in (select distinct numero_dossier from [career].[commun_zy3b_affectation]) 

select * from [career].[commun_zy38_affectation_etablissement] zy38
FULL JOIN [career].[commun_zy3b_affectation]  zy3b ON zy3b.numero_dossier = zy38.numero_dossier 
AND ((zy3b.date_effet >= zy38.date_debut  AND zy3b.date_fin <= zy38.date_fin) 
OR (zy3b.date_effet >= zy38.date_debut AND  zy3b.date_effet <= zy38.date_fin AND zy3b.date_fin > zy38.date_fin) 
OR (zy3b.date_effet < zy38.date_debut AND  zy3b.date_fin >= zy38.date_debut AND zy3b.date_fin <= zy38.date_fin) )
--WHERE zy3b.numero_dossier = 717
ORDER BY 3

select * from [career].[commun_zy38_affectation_etablissement] zy38
FULL JOIN [career].[commun_zy3b_affectation]  zy3b ON zy3b.numero_dossier = zy38.numero_dossier 
AND ((zy3b.date_effet >= zy38.date_debut  AND zy3b.date_fin <= zy38.date_fin) 
OR (zy3b.date_effet >= zy38.date_debut AND  zy3b.date_effet <= zy38.date_fin AND zy3b.date_fin > zy38.date_fin) 
OR (zy3b.date_effet < zy38.date_debut AND  zy3b.date_fin >= zy38.date_debut AND zy3b.date_fin <= zy38.date_fin) )
WHERE zy3b.numero_dossier = 717
ORDER BY 2,3,8


select * from [career].[commun_zy38_affectation_etablissement] where numero_dossier = 717 order by date_debut
select * from [career].[commun_zy3b_affectation] where numero_dossier = 717 order by date_effet

select * from [career].[commun_zy38_affectation_etablissement] where numero_dossier = 5763 order by date_debut
select * from [career].[commun_zy3b_affectation] where numero_dossier = 5763 order by date_effet