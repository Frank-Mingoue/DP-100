/****** Object:  Table [career].[ZYCS_ZYWW_caisse]    Script Date: 07/12/2022 15:37:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [career].[ZYCS_ZYWW_caisse](
	[numero_dossier] [int] NULL,
	[zycs_identifiant_dossier_paie] [int] NULL,
	[zycs_code_caisse] [nvarchar](max) NULL,
	[zycs_regime_retraite] [nvarchar](max) NULL,
	[zycs_date_debut] [date] NULL,
	[zycs_date_fin] [date] NULL,
	[zycs_numero_inscription] [nvarchar](15) NULL,
	[zycs_identifiant_contrat] [nvarchar](3) NULL,
	[zycs_motif_rupture_contrat] [nvarchar](max) NULL,
	[zycs_motif_sortie] [nvarchar](max) NULL,
	[zycs_temoin_mise_a_jour_manuelle] [nvarchar](max) NULL,
	[zyww_date_debut] [date] NULL,
	[zyww_date_fin] [date] NULL,
	[zyww_code_regime_cotisations] [nvarchar](max) NULL,
	[zyww_repartition_salariale_patronale] [int] NULL,
	[date_entree] [date] NULL,
	[date_sortie_administrative] [date] NULL,
	[societe] VARCHAR(45) NULL,
	[type_contrat] VARCHAR(25) NULL,
	[nature] VARCHAR(52) NULL,
	[etablissement] VARCHAR(45) NULL,
	[unite_organisationnelle] VARCHAR(12) NULL,
	[classification] VARCHAR(50) NULL,
	[qualification] VARCHAR(38) NULL,
	[code_convention_collective] VARCHAR(18) NULL,
	[type_temps_contractuel] VARCHAR(52) NULL,
	[heures_presencemois] DECIMAL(5, 2),
	[date_debut_filtre] [date] NULL,
	[date_fin_filtre] [date] NULL,
	[matricule_hra] [varchar](19) NULL,
	[matricule_workday] [varchar](12) NULL,
	[prenom_employe] [varchar](30) NULL,
	[nom_employe] [varchar](40) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


