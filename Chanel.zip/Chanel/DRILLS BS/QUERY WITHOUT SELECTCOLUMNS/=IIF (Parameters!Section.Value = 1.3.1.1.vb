=IIF (Parameters!Section.Value = "1.3.1.1" ,

Parameters!common_fields.Value
		
&amp; 

"
'201 - AXE MDP - ENTREES'[MOTIF D'ENTREE BILAN SOCIAL],
"

&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
    FILTER(VALUES( '201 - AXE MDP - ENTREES'[MOTIF D'ENTREE BILAN SOCIAL]), ( '201 - AXE MDP - ENTREES'[MOTIF D'ENTREE BILAN SOCIAL]IN { _motif_embauche })),
    FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDI"")),	

    ""NOMBRE DE MOBILITES ENTRANTES PERIMETRE CDI"", [NOMBRE DE MOBILITES ENTRANTES PERIMETRE CDI] , 
    ""NOMBRE D'ENTREES"", [NOMBRE D'ENTREES]
	
)

"
, 

IIF (Parameters!Section.Value = "1.3.1.2" ,

Parameters!common_fields.Value
		
&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
    FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDI"")),

	""NOMBRE DE MOBILITES INTRA PERIMETRE CDI"", [NOMBRE DE MOBILITES INTRA PERIMETRE CDI]
	

)

"
, 

IIF (Parameters!Section.Value = "1.3.1.3" ,

Parameters!common_fields.Value
		
&amp; 

"
'201 - AXE MDP - ENTREES'[MOTIF D'ENTREE BILAN SOCIAL],
"

&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
    FILTER(VALUES('004 - AXE COM - AGE'[TRANCHE D'AGE BS - 10 ANS]), ('004 - AXE COM - AGE'[TRANCHE D'AGE BS - 10 ANS] IN { _tranche_age })),
    FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDI"")),

    	
	
    
    ""NOMBRE DE MOBILITES ENTRANTES PERIMETRE CDI"", [NOMBRE DE MOBILITES ENTRANTES PERIMETRE CDI] , 
    ""NOMBRE D'ENTREES"", [NOMBRE D'ENTREES]
	
)

"
, 

IIF (Parameters!Section.Value = "1.3.2.1" ,

Parameters!common_fields.Value
		
&amp; 

"
'201 - AXE MDP - ENTREES'[MOTIF D'ENTREE BILAN SOCIAL],
"

&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
    FILTER(VALUES( '201 - AXE MDP - ENTREES'[MOTIF D'ENTREE BILAN SOCIAL]), ( '201 - AXE MDP - ENTREES'[MOTIF D'ENTREE BILAN SOCIAL]IN { _motif_embauche })),
    FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDD"")),
	
     
    ""NOMBRE D'ENTREES"", [NOMBRE D'ENTREES]
	
)

"
, 

IIF (Parameters!Section.Value = "1.3.2.2" ,

Parameters!common_fields.Value
		
&amp; 

"
'201 - AXE MDP - ENTREES'[MOTIF D'ENTREE BILAN SOCIAL],
"

&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),	
	FILTER(VALUES('004 - AXE COM - AGE'[TRANCHE D'AGE BS - 10 ANS]), ('004 - AXE COM - AGE'[TRANCHE D'AGE BS - 10 ANS] IN { _tranche_age })),
    FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDD"")),
    
    ""NOMBRE D'ENTREES"", [NOMBRE D'ENTREES]
)

"

, Nothing




)


)


)


)


)