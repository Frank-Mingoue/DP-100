=IIF (Parameters!Section.Value = "1.1.2.1" ,

Parameters!common_fields.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
    FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDI"")),	

    ""EFFECTIF TETE"", CALCULATE([EFFECTIF TETE],  '001 - AXE COM - TEMPS'[MOIS] = ""Décembre"" )
	
)

"
, 

IIF (Parameters!Section.Value = "1.1.2.2" ,

Parameters!common_fields.Value
		
&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
    FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDI"")),

	""ETP CONTRACTUEL"", CALCULATE([ETP CONTRACTUEL],  '001 - AXE COM - TEMPS'[MOIS] = ""Décembre"")
	

)

"
, 

IIF (Parameters!Section.Value = "1.1.2.3" OR Parameters!Section.Value = "1.1.2.4",

Parameters!common_fields.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
    FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDI"")),

    	
	
    
    ""EFFECTIF PERMANENT"", [EFFECTIF PERMANENT]
	
)

"
, 

IIF (Parameters!Section.Value = "1.1.2.5" ,

Parameters!common_fields.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
    FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDI"")),
	
    ""EFFECTIF TETE"", CALCULATE([EFFECTIF TETE],  '001 - AXE COM - TEMPS'[MOIS] = ""Décembre"" )

 
)

"
, 

IIF (Parameters!Section.Value = "1.1.2.6" ,

Parameters!common_fields.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
    FILTER(VALUES('007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE]), ('007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE] IN { _nationalite })),
    FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDI"")),
	
    
    ""EFFECTIF TETE"", CALCULATE([EFFECTIF TETE],  '001 - AXE COM - TEMPS'[MOIS] = ""Décembre"" )
	
)

"
, 

IIF (Parameters!Section.Value = "1.1.2.7" ,

Parameters!common_fields.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),	
	FILTER(VALUES('004 - AXE COM - AGE'[TRANCHE D'AGE BS - 10 ANS]), ('004 - AXE COM - AGE'[TRANCHE D'AGE BS - 10 ANS] IN { _tranche_age })),
    FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDI"")),
    
    ""EFFECTIF TETE"", CALCULATE([EFFECTIF TETE],  '001 - AXE COM - TEMPS'[MOIS] = ""Décembre"" )
)

"
, 

IIF (Parameters!Section.Value = "1.1.2.8" ,

Parameters!common_fields.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
	FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDI"")),
    
    ""EFFECTIF TETE"", CALCULATE([EFFECTIF TETE],  '001 - AXE COM - TEMPS'[MOIS] = ""Décembre"" )
)

"
, 

IIF (Parameters!Section.Value = "1.1.2.9" ,

Parameters!common_fields.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
    FILTER(VALUES('005 - AXE COM - ANCIENNETE CHANEL'[TRANCHE D'ANCIENNETE CHANEL BILAN SOCIAL]), ('005 - AXE COM - ANCIENNETE CHANEL'[TRANCHE D'ANCIENNETE CHANEL BILAN SOCIAL] IN { _tranche_anciennete })),
	FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDI"")),


	
    
    ""EFFECTIF TETE"", CALCULATE([EFFECTIF TETE],  '001 - AXE COM - TEMPS'[MOIS] = ""Décembre"" )
)

"
, 

IIF (Parameters!Section.Value = "1.1.2.10" ,

Parameters!common_fields.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!common_filters.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
	FILTER(VALUES( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT]), ( '008 - AXE COM - CONTRAT'[TYPE DE CONTRAT] = ""CDI"")),


	
    
    ""EFFECTIF TETE"", CALCULATE([EFFECTIF TETE],  '001 - AXE COM - TEMPS'[MOIS] = ""Décembre"" )
)

"
, Nothing


)


)


)


)


)


)


)


)


)