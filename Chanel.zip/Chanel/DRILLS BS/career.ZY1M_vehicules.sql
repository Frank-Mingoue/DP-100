career.ZY1M_vehicules

career.ZY24_type_transport

career.ZYAF_affectation_consolidee

career.ZYAR_taux_prelevement_source

career.ZYAU_salaires

career.ZYCU_cumuls_paie

career.ZYEL_elements_fixes_paie

career.ZYHB_salarie_beneficiaire

career.ZYRG_regularisations_cotisations

career.ZYWB_preavis

career.ZYPR_prets_et_saisies