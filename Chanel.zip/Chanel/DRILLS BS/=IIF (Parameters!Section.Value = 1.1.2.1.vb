=IIF (Parameters!Section.Value = "1.1.2.1" ,

Parameters!query_part_1.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!query_part_2.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),	

    ""EFFECTIF TETE"", [EFFECTIF TETE],
	""ETP CONTRACTUEL"", BLANK()
	
"

 &amp;
 
 Parameters!query_part_3.Value
 
 &amp;  
 
" 
   ""NATIONALITE"", '007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
   ""EFFECTIF TETE"", [EFFECTIF TETE],
   ""ETP CONTRACTUEL"", [ETP CONTRACTUEL]
)

"
, 

IIF (Parameters!Section.Value = "1.1.1.2" ,

Parameters!query_part_1.Value
		
&amp; 

    Parameters!query_part_2.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),

	""NATIONALITE"", BLANK(),    
    ""EFFECTIF TETE"", BLANK(),
	""ETP CONTRACTUEL"", [ETP CONTRACTUEL]
	
"

 &amp;
 
 Parameters!query_part_3.Value
 
 &amp;  
 
" 
   ""NATIONALITE"", [NATIONALITE],
   ""EFFECTIF TETE"", [EFFECTIF TETE],
   ""ETP CONTRACTUEL"", [ETP CONTRACTUEL]
)

"
, 

IIF (Parameters!Section.Value = "1.1.1.3" ,

Parameters!query_part_1.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!query_part_2.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),	
	
    
    ""EFFECTIF TETE"", [EFFECTIF TETE],
	""ETP CONTRACTUEL"", BLANK()
	
"

 &amp;
 
 Parameters!query_part_3.Value
 
 &amp;  
 
" 
   ""NATIONALITE"", '007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
   ""EFFECTIF TETE"", [EFFECTIF TETE],
   ""ETP CONTRACTUEL"", [ETP CONTRACTUEL]
)

"
, 

IIF (Parameters!Section.Value = "1.1.1.4" ,

Parameters!query_part_1.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!query_part_2.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
    FILTER(VALUES('007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE]), ('007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE] IN { _nationalite })),	
	
    ""EFFECTIF TETE"", [EFFECTIF TETE],
	""ETP CONTRACTUEL"", BLANK()
	
"

 &amp;
 
 Parameters!query_part_3.Value
 
 &amp;  
 
" 
   ""NATIONALITE"", '007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
   ""EFFECTIF TETE"", [EFFECTIF TETE],
   ""ETP CONTRACTUEL"", [ETP CONTRACTUEL]
)

"
, 

IIF (Parameters!Section.Value = "1.1.1.5" ,

Parameters!query_part_1.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!query_part_2.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
    FILTER(VALUES('004 - AXE COM - AGE'[TRANCHE D'AGE - 10 ANS]), ('004 - AXE COM - AGE'[TRANCHE D'AGE - 10 ANS] IN { _tranche_age })),	
	
    
    ""EFFECTIF TETE"", [EFFECTIF TETE],
	""ETP CONTRACTUEL"", BLANK()
	
"

 &amp;
 
 Parameters!query_part_3.Value
 
 &amp;  
 
" 
   ""NATIONALITE"", '007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
   ""EFFECTIF TETE"", [EFFECTIF TETE],
   ""ETP CONTRACTUEL"", [ETP CONTRACTUEL]
)

"
, IIF (Parameters!Section.Value = "1.1.1.6" ,

Parameters!query_part_1.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!query_part_2.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),	
	
    
    ""EFFECTIF TETE"", [EFFECTIF TETE],
	""ETP CONTRACTUEL"", BLANK()
	
"

 &amp;
 
 Parameters!query_part_3.Value
 
 &amp;  
 
" 
   ""NATIONALITE"", '007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
   ""EFFECTIF TETE"", [EFFECTIF TETE],
   ""ETP CONTRACTUEL"", [ETP CONTRACTUEL]
)

"
, 

IIF (Parameters!Section.Value = "1.1.1.7" ,

Parameters!query_part_1.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!query_part_2.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
    FILTER(VALUES('005 - AXE COM - ANCIENNETE CHANEL'[TRANCHE D'ANCIENNETE CHANEL]), ('005 - AXE COM - ANCIENNETE CHANEL'[TRANCHE D'ANCIENNETE CHANEL] IN { _tranche_anciennete })),	
	
    
    ""EFFECTIF TETE"", [EFFECTIF TETE],
	""ETP CONTRACTUEL"", BLANK()
	
"

 &amp;
 
 Parameters!query_part_3.Value
 
 &amp;  
 
" 
   ""NATIONALITE"", '007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
   ""EFFECTIF TETE"", [EFFECTIF TETE],
   ""ETP CONTRACTUEL"", [ETP CONTRACTUEL]
)

"
, 

IIF (Parameters!Section.Value = "1.1.1.8" ,

Parameters!query_part_1.Value
		
&amp; 

"
'007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
"

&amp; 

    Parameters!query_part_2.Value 
	
&amp; 

"   
    RSCustomDaxFilter(@A1,EqualToCondition,[001 - AXE COM - TEMPS].[ANNEE],Int64),
    FILTER(VALUES('002 - AXE COM - INFO SALARIE'[GENRE]), ('002 - AXE COM - INFO SALARIE'[GENRE] IN { _genre })),
    FILTER(VALUES('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP]), ('010 - AXE COM - CATEGORIE SOCIO PROFESSIONNELLE'[CSP] IN { _csp })),
	
    
    ""EFFECTIF TETE"", [EFFECTIF TETE],
	""ETP CONTRACTUEL"", BLANK()
	
"

 &amp;
 
 Parameters!query_part_3.Value
 
 &amp;  
 
" 
   ""NATIONALITE"", '007 - AXE COM - NATIONALITE'[NATIONALITE - UE / HORS UE / FRANCE],
   ""EFFECTIF TETE"", [EFFECTIF TETE],
   ""ETP CONTRACTUEL"", [ETP CONTRACTUEL]
)

"
, Nothing


)


)


)


)


)


)


)


)