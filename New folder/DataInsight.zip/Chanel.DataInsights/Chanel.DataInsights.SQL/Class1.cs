﻿namespace Chanel.DataInsights.SQL
{
    public class Class1
    {

    }
}