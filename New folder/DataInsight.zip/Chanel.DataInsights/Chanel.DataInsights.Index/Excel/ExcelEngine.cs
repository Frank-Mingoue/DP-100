﻿using Chanel.DataInsights.Index.Common;
using Chanel.DataInsights.Index.Model;
using Chanel.DataInsights.Excel.Model;
using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Chanel.DataInsights.Index.Excel
{
    public static class ExcelEngine
    {
        public static XLWorkbook ApplyDataToExcelTemplate(MemoryStream templateFile, List<CellConfig> excelModel, List<DataProperty> dataProperties, BodyModel body, DataMappingProperties dataMappingProperties)
        {
            var wb = new XLWorkbook(templateFile);

            foreach (CellConfig cellConfig in excelModel)
            {
                if (dataProperties.Exists(c => c.TagName.Replace("É", "E").Replace("È", "E").Replace("__", "_") == cellConfig.TagName.Replace("É", "E").Replace("È", "E").Replace("__","_").Replace("\n", "")))
                {
                    DataProperty bsValue = dataProperties.FirstOrDefault(c => c.TagName.Replace("É", "E").Replace("È", "E").Replace("__", "_") == cellConfig.TagName.Replace("É", "E").Replace("È", "E").Replace("__", "_").Replace("\n", ""));

                    wb.Worksheets.ElementAt(cellConfig.SheetID).Cell(cellConfig.RowID, cellConfig.CellID).Value = bsValue.Value;
                }
                else
                {
                    if (!dataMappingProperties.DebugMode)
                    {
                        wb.Worksheets.ElementAt(cellConfig.SheetID).Cell(cellConfig.RowID, cellConfig.CellID).Value = "";
                    }
                }
            }

            wb.Save();

            return wb;
        }

        ///// <summary>
        ///// Get Value for specific cell or cell contains text (string and tags)
        ///// </summary>
        ///// <param name="cellValue"> Cell value </param>
        ///// <returns> Value </returns>
        //private static string GetValueForSpecificCell(string cellValue, bool debugMode)
        //{
        //    string defaultValue = string.Empty;
        //    if (!debugMode)
        //    {
        //        defaultValue = "0";
        //    }
        //    if (!string.IsNullOrEmpty(cellValue) && !Regex.IsMatch(cellValue, @"^##") && !Regex.IsMatch(cellValue, @"[$,]"))
        //    {
        //        return cellValue.Replace(TagsConstants.YearN, Properties.FirstOrDefault(x => x.Tag == TagsConstants.YearN).Value).Replace(TagsConstants.YearN1, Properties.FirstOrDefault(x => x.Tag == TagsConstants.YearN1).Value).Replace(TagsConstants.YearN2, Properties.FirstOrDefault(x => x.Tag == TagsConstants.YearN2).Value);
        //    }
        //    return defaultValue;
        //}

    }
}
