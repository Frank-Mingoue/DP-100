﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chanel.DataInsights.Index.Model
{
    public class DataProperty
    {
        public string Value { get; set; }
        public string TagName { get; set; }
        public string? Type { get; set; }
        public string? Link { get; set; }

        public DataProperty()
        {
            Value = String.Empty;
            TagName = String.Empty;
        }
        public DataProperty(string value, string tagName, string type, string link)
        {
            Value = value;
            TagName = tagName;
            Type = type;
            Link = link;
        }
    }
}
