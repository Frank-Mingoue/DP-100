﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chanel.DataInsights.Index.Model
{
    public class BodyModel
    {
        public String TemplateID { get; set; }
        public int Year { get; set; }
        public int Year2 { get; set; }
        public int Month { get; set; }
        public string[] ContractTypes { get; set; }
        public string? Filter { get; set; }
        public string? Vision { get; set; }
        public string? Size { get; set; }
        public string[] Value { get; set; }
        public string[] Societes { get; set; }
        public string[] Cses { get; set; }
        public string[] Etablissements { get; set; }
        public string[] Divisions { get; set; }
        public string[] DivisionsDetailed { get; set; }
    }
}
