﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chanel.DataInsights.Index.Common
{
    enum EnumFiltersTag
    {
        CSP,
        Coef,
        Grade
    }
}
