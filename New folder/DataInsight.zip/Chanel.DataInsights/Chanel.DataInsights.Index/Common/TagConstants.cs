﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chanel.DataInsights.Index.Common
{
    public static class TagsConstants
    {
        public const string YearA = "##ANNEE_1##";
        public const string YearB = "##ANNEE_2##";
        public const string YearN = "##YEAR_N##";
        public const string Month = "##MONTH##";
        public const string Contract = "##CONTRAT##";
        public const string Scenario = "##SCENARIO##";
        public const string CSP = "##CSP##";
        public const string YearN1 = "##YEAR_N-1##";
        public const string YearN2 = "##YEAR_N-2##";
        public const string YearCompare = "EVOLUTION ##YEAR_N##/##YEAR_N-1##";
        public const string NameYearN = "YEAR_N";
        public const string NameYearN1 = "YEAR_N-1";
        public const string NameYearN2 = "YEAR_N-2";
        public const string Societes = "##SOCIETES##";
        public const string Cses = "##CSES##";
        public const string Etablissements = "##ETABLISSEMENTS##";
        public const string Divisions = "##DIVISIONS##";
        public const string DivisionsDetailed = "##DIVISIONSDETAILED##";
    }
}
