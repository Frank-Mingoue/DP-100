﻿using Azure.Core;
using Azure.Identity;
using Chanel.DataInsights.Azure.Common;
using Chanel.DataInsights.Index.Common;
using Chanel.DataInsights.Index.Model;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Chanel.DataInsights.Index.Connector
{
    public class DataConnector
    {
        private readonly IFLogger _Log;
        private string _SqlConnectionString { get; set; }
        private BodyModel _BodyModel { get; set; }
        private DataMappingProperties _DataMappingProperties { get; set; }
        private List<DataProperty> _DataProperties { get; set; }
        private readonly string _PowerBiUrl;

        /// <summary>
        /// Create a DataConnector to get data from SQL Server
        /// </summary>
        /// <param name="configuration">Azure Function configuration</param>
        /// <param name="dataMapping">Data Mapping between Excel Sheet and SQL SP</param>
        /// <param name="body">HTTP Body (json)</param>
        /// <param name="logger">Azure logger</param>
        public DataConnector(ConfigurationProperties configuration, DataMappingProperties dataMapping, string body, IFLogger logger)
        {
            _Log = logger;
            _SqlConnectionString = $"Server={configuration.ServerSql}; Database={configuration.DatabaseSql};";
            _DataMappingProperties = dataMapping;

            // Retrieve data from json
            var data = JObject.Parse(body);            
            var template = data.SelectToken("$.template").Value<string>() ?? string.Empty;
            var year = data.SelectToken("$.year").Value<string>() ?? string.Empty;
            var year2 = data.SelectToken("$.year2").Value<string>() ?? string.Empty;
            var month = data.SelectToken("$.month").Value<string>() ?? string.Empty;
            var contractTypeList = data.SelectTokens("$.ContractType").Values<string>().ToList() ?? null;
            var costCenterList = data.SelectTokens("$.body.Table1[0:].Cost_Center").Values<string>().ToList() ?? null;

            var divisionFilters = data.SelectToken("DivisionFilters").Value<string>() ?? string.Empty;
            var detailedDivisionFilters = data.SelectToken("DetailedDivisionFilters").Value<string>() ?? string.Empty;
            var societeFilters = data.SelectToken("SocietesFilters").Value<string>() ?? string.Empty;
            var establishmentFilters = data.SelectToken("EstablishmentFilters").Value<string>() ?? string.Empty;
            var size = data.SelectToken("$.size").Value<string>() ?? string.Empty;
            var filter = data.SelectToken("$.filter").Value<string>() ?? string.Empty;
            var vision = data.SelectToken("$.vision").Value<string>() ?? string.Empty;



            // Set Data to BodyProperty from input data request
            // @TODO : To refactor in a single method
            //
            _BodyModel = new BodyModel();

            if (template != null && !String.IsNullOrEmpty(template))
            {
                _BodyModel.TemplateID = template;
                _Log.LogInformation("Template : " + template);
            }
            if (month != null && !String.IsNullOrEmpty(month))
            {
                _BodyModel.Month = Int32.Parse(month);
                _Log.LogInformation("Month : " + month);
            }
            if (year != null && !String.IsNullOrEmpty(year))
            {
                _BodyModel.Year = Int32.Parse(year);
                _Log.LogInformation("Year : " + year);
            }
            if (year2 != null && !String.IsNullOrEmpty(year2))
            {
                _BodyModel.Year2 = Int32.Parse(year2);
                _Log.LogInformation("Year2 : " + year2);
            }
            if (divisionFilters != null && !String.IsNullOrEmpty(divisionFilters))
            {
                _BodyModel.Divisions = divisionFilters.Split("/");
                _Log.LogInformation("Division : " + divisionFilters);
            }
            if (detailedDivisionFilters != null && !String.IsNullOrEmpty(detailedDivisionFilters))
            {
                _BodyModel.DivisionsDetailed = detailedDivisionFilters.Split("/");
                _Log.LogInformation("Detailed Division : " + detailedDivisionFilters);
            }
            if (societeFilters != null && !String.IsNullOrEmpty(societeFilters))
            {
                _BodyModel.Societes = societeFilters.Split("/");
                _Log.LogInformation("Societe : " + societeFilters);
            }
            if (establishmentFilters != null && !String.IsNullOrEmpty(establishmentFilters))
            {
                _BodyModel.Etablissements = establishmentFilters.Split("/");
                _Log.LogInformation("Establishment : " + establishmentFilters);
            }
            if (filter != null && !String.IsNullOrEmpty(filter))
            {
                _BodyModel.Filter = filter.Replace("\"", "");
                _Log.LogInformation("Filter : " + filter);
            }
            if (size != null && !String.IsNullOrEmpty(size))
            {
                _BodyModel.Size = size.Replace("\"", "");
                _Log.LogInformation("Size : " + size);
            }
            if (vision != null && !String.IsNullOrEmpty(vision))
            {
                _BodyModel.Vision = vision.Replace("\"", "");
                _Log.LogInformation("Vision : " + vision);
            }

            if (contractTypeList != null)
                _BodyModel.ContractTypes = contractTypeList.ToArray<string>();

            if (costCenterList != null) 
                _BodyModel.Value = costCenterList.ToArray<string>();

        }

        public BodyModel GetBodyModel()
        {           
            return _BodyModel;
        }


        public async Task<List<DataProperty>> GetDataFromSQL()
        {
            _DataProperties = new List<DataProperty>();

            AddCustomTags();

            try
            {
                if (_DataMappingProperties != null && _DataMappingProperties.DataProperties != null)
                {
                    foreach (ExcelSheetProperties item in _DataMappingProperties.DataProperties)
                    {
                        if (item.StoredProcedure != null)
                        {
                            foreach (string storedProcedure in item.StoredProcedure)
                            {
                                JArray jArray = await RunSQLSP(storedProcedure);

                                if (jArray != null)
                                    foreach (JToken jToken in jArray)
                                    {
                                        DataProperty data = new DataProperty();
                                        data.Value = jToken.Value<string?>("effectif") ?? string.Empty;
                                        data.TagName = ((JValue)jToken["effectif_id"]).Value.ToString().ToUpper().Replace("É", "E").Replace("È", "E").Replace(_BodyModel.Year.ToString(), TagsConstants.NameYearN).Replace((_BodyModel.Year - 1).ToString(), TagsConstants.NameYearN1).Replace((_BodyModel.Year - 2).ToString(), TagsConstants.NameYearN2);
                                        data.Type = long.TryParse(jToken.Value<string?>("effectif") ?? string.Empty, out long value) ? TypeConstants.Number : TypeConstants.String;
                                        data.Link = CreateUrl(((JValue)jToken["effectif_id"]).Value.ToString().ToUpper().Replace("É", "E").Replace("È", "E").Replace(_BodyModel.Year.ToString(), TagsConstants.NameYearN).Replace((_BodyModel.Year - 1).ToString(), TagsConstants.NameYearN1).Replace((_BodyModel.Year - 2).ToString(), TagsConstants.NameYearN2));

                                        _DataProperties.Add(data);
                                    }
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                _Log.LogError($"Something went wrong during CreateDataProperties: {ex.Message}");
            }
            return _DataProperties;
        }

        private void AddCustomTags()
        {
            if (_BodyModel.TemplateID.Equals("7"))
            {
                DataProperty year1 = new DataProperty();
                year1.Value = _BodyModel.Year.ToString();
                year1.TagName = TagsConstants.YearA;
                year1.Type = TypeConstants.String;
                year1.Link = null;
                _DataProperties.Add(year1);

                DataProperty year2 = new DataProperty();
                year2.Value = _BodyModel.Year2.ToString();
                year2.TagName = TagsConstants.YearB;
                year2.Type = TypeConstants.String;
                year2.Link = null;
                _DataProperties.Add(year2);
            }


            if (_BodyModel.TemplateID.Equals("3"))
            {
                _DataProperties.Add(new DataProperty(_BodyModel.Year.ToString(), TagsConstants.YearN, TypeConstants.String, null));
                _DataProperties.Add(new DataProperty(_BodyModel.Month.ToString(), TagsConstants.Month, TypeConstants.String, null));
                _DataProperties.Add(new DataProperty(string.Join(" / ", _BodyModel.ContractTypes), TagsConstants.Contract, TypeConstants.String, null));
                _DataProperties.Add(new DataProperty(string.Join(" / ", _BodyModel.Filter), TagsConstants.CSP, TypeConstants.String, null));
                _DataProperties.Add(new DataProperty(string.Join(" / ", _BodyModel.Vision), TagsConstants.Scenario, TypeConstants.String, null));


                _DataProperties.Add(new DataProperty(string.Join(" / ", _BodyModel.Societes), TagsConstants.Societes, TypeConstants.String, null));
                _DataProperties.Add(new DataProperty(string.Join(" / ", _BodyModel.Etablissements), TagsConstants.Etablissements, TypeConstants.String, null));
                _DataProperties.Add(new DataProperty(string.Join(" / ", _BodyModel.Divisions), TagsConstants.Divisions, TypeConstants.String, null));
                _DataProperties.Add(new DataProperty(string.Join(" / ", _BodyModel.DivisionsDetailed), TagsConstants.DivisionsDetailed, TypeConstants.String, null));
            }
        }



        /// <summary>
        /// Create URL with Filter Variable
        /// </summary>
        /// <param name="tag"></param>
        /// <returns></returns>
        private string? CreateUrl(string tagName)
        {

            // Initialize all variables
            string divisions = string.Empty;
            string divisionsDetailed = string.Empty;
            string societes = string.Empty;
            string cses = string.Empty;
            string etablissements = string.Empty;

            // Create Divisions URL
            if (!string.IsNullOrEmpty(tagName))
            {
                if (_BodyModel.Divisions != null)
                {
                    divisions = string.Join("&rp:Division=", _BodyModel.Divisions);

                }

                // Create Divisions Detailed URL 

                if (_BodyModel.DivisionsDetailed != null)
                {
                    divisionsDetailed = string.Join("&rp:Division_Detaillee=", _BodyModel.DivisionsDetailed);

                }

                // Create Societes

                if (_BodyModel.Societes != null)
                {
                    societes = string.Join("&rp:Societe=", _BodyModel.Societes);

                }

                // Create CSES 

                if (_BodyModel.Cses != null)
                {
                    cses = string.Join("&rp:CSE=", _BodyModel.Cses);

                }

                // Create Etablissements

                if (_BodyModel.Etablissements != null)
                {
                    etablissements = string.Join("&rp:Etablissement=", _BodyModel.Etablissements);

                }

                /*return $"{_PowerBiUrl}?rp:Annee={_BodyModel.Year}&rp:LegalIndicatorTag={HttpUtility.UrlEncode(tagName)}{HttpUtility.UrlEncode(divisions)}{HttpUtility.UrlEncode(divisionsDetailed)}{HttpUtility.UrlEncode(societes)}{HttpUtility.UrlEncode(cses)}{HttpUtility.UrlEncode(etablissements)}";*/
                return _PowerBiUrl;

            }
            return null;
        }





        private async Task<JArray> RunSQLSP(string storedProcedure)
        {
                if (_BodyModel.TemplateID.Equals("7"))
                    return await QueryDataIndex6(storedProcedure, _BodyModel.Year, _BodyModel.Year2, _BodyModel.Value);
                if (_BodyModel.TemplateID.Equals("6"))
                    return await QueryDataIndex(storedProcedure, _BodyModel.Month, _BodyModel.Year, _BodyModel.ContractTypes, _BodyModel.Value);
                else
                    return await QueryDataIndex(storedProcedure, _BodyModel.Month, _BodyModel.Year, _BodyModel.ContractTypes, _BodyModel.Value);
        }

        #region Set Stored Procedure Parameters
        private SqlParameter[] SetParameters(int yearA, int yearB, string[] costCenters)
        {
            // Init Cost Centers
            _Log.LogInformation("Init SQL Cost Centers in UDT and year");
            DataTable costCenter = new DataTable();
            costCenter.Columns.Add("costcentercode", typeof(string));

            foreach (String cc in costCenters)
            {
                DataRow row = costCenter.NewRow();
                row.ItemArray = new String[] { cc };
                costCenter.Rows.Add(row);
            }

            SqlParameter[] parameters = {
                new SqlParameter("@YearA", yearA)
                {
                    SqlDbType = SqlDbType.Int,
                },
                new SqlParameter("@YearB", yearB)
                {
                    SqlDbType = SqlDbType.Int,
                },
                new SqlParameter("@CostCenterCode", costCenter)
                {
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "[index].[Parameter_List]"
                }
            };
            return parameters;
        }

        private SqlParameter[] SetParameters(int month, int year, string[] contractTypes, string[] costCenters)
        {
            // Init Cost Centers
            _Log.LogInformation("Init SQL Cost Centers in UDT and year");
            DataTable costCenter = new DataTable();
            costCenter.Columns.Add("costcentercode", typeof(string));

            DataTable contractType = new DataTable();
            contractType.Columns.Add("contracttype", typeof(string));

            foreach (String cc in costCenters)
            {
                DataRow row = costCenter.NewRow();
                row.ItemArray = new String[] { cc };
                costCenter.Rows.Add(row);
            }

            foreach (String ct in contractTypes)
            {
                DataRow row = contractType.NewRow();
                row.ItemArray = new String[] { ct };
                contractType.Rows.Add(row);
            }


            SqlParameter[] parameters = {
                new SqlParameter("@CurrentYear", year)
                {
                    SqlDbType = SqlDbType.Int,
                },
                new SqlParameter("@CurrentMonth", month)
                {
                    SqlDbType = SqlDbType.Int,
                },
                new SqlParameter("@ContractType", contractType)
                {
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "[index].[Parameter_List]"
                },
                new SqlParameter("@CostCenterCode", costCenter)
                {
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "[index].[Parameter_List]"
                }
            };
            return parameters;
        }

        #endregion


        /// <summary>
        /// Query Data by calling Procedure Stored
        /// </summary>
        /// <param name="spName"> Name of Procedure Stored </param>
        /// <param name="year"> Current Year </param>
        /// <param name="costCenters"> List of Cost Center </param>
        /// <returns>A JArray contains data </returns>
        private async Task<JArray> QueryDataIndex6(string spName, int year1, int year2, string[] costCenters)
        {
            #region Connection SQL

            _Log.LogInformation("Getting Access Token...");
            var accessToken = await new DefaultAzureCredential().GetTokenAsync(new TokenRequestContext(new string[] { "https://database.windows.net//.default" }));
            _Log.LogInformation("Access Token retrieved !");

            _Log.LogInformation("Init SQL Connection");
            using SqlConnection connection = new SqlConnection(_SqlConnectionString)
            {
                AccessToken = accessToken.Token
            };


            #endregion

            #region Initialize Parameters 
            _Log.LogInformation("Init SQL Param : " + spName);
            string sp = $"[index].[{spName}]";
            SqlCommand cmd = new SqlCommand(sp.ToString(), connection);
            SqlDataReader dataReader = null;

            StringBuilder JSONContent = new StringBuilder();

            _Log.LogInformation("Year 1 : " + year1);
            _Log.LogInformation("Year 2 : " + year2);
            string contractDebug = String.Empty;


            string ccDebug = String.Empty;
            foreach (var cc in costCenters)
            {
                ccDebug = ccDebug + cc.ToString() + " | ";

            }
            _Log.LogInformation("Cost Center : " + ccDebug);

            // Set SQL Parameters
            SqlParameter[] parameters = SetParameters(year1, year2, costCenters);

            //add the parameter to the SqlCommand object
            foreach (var parameter in parameters)
            {
                cmd.Parameters.Add(parameter);
            }
            #endregion

            #region Execute SP
            try
            {
                _Log.LogInformation("Execute SQL SP");
                //await connection.OpenAsync();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 900;
                await connection.OpenAsync();
                dataReader = cmd.ExecuteReader();


                while (dataReader.Read())
                {
                    JSONContent.Append((String)dataReader.GetValue(0));
                }
            }
            catch (Exception ex)
            {
                _Log.LogError(ex.Message);
            }


            _Log.LogInformation("Get JSON content from SQL : " + JSONContent.ToString());
            //Parse JSON content and extract the data Array
            if (String.IsNullOrEmpty(JSONContent.ToString()))
            {
                connection.Close();
                return null;
            }
            else
            {
                var data = JObject.Parse(JSONContent.ToString());

                connection.Close();
                _Log.LogInformation("Return JSON content");
                return (JArray)data["data"];
            }
            #endregion

        }




        /// <summary>
        /// Query Data by calling Procedure Stored
        /// </summary>
        /// <param name="spName"> Name of Procedure Stored </param>
        /// <param name="year"> Current Year </param>
        /// <param name="costCenters"> List of Cost Center </param>
        /// <returns>A JArray contains data </returns>
        private async Task<JArray> QueryDataIndex(string spName, int month, int year, string[] contractTypes, string[] costCenters)
        {
            #region Connection SQL

            _Log.LogInformation("Getting Access Token...");
            var accessToken = await new DefaultAzureCredential().GetTokenAsync(new TokenRequestContext(new string[] { "https://database.windows.net//.default" }));
            _Log.LogInformation("Access Token retrieved !");

            _Log.LogInformation("Init SQL Connection");
            using SqlConnection connection = new SqlConnection(_SqlConnectionString)
            {
                AccessToken = accessToken.Token
            };


            #endregion

            #region Initialize Parameters 
            _Log.LogInformation("Init SQL Param : " + spName);
            string sp = $"[index].[{spName}]";
            SqlCommand cmd = new SqlCommand(sp.ToString(), connection);
            SqlDataReader dataReader = null;

            StringBuilder JSONContent = new StringBuilder();

            _Log.LogInformation("Month : " + month);
            _Log.LogInformation("Year : " + year);
            string contractDebug = String.Empty;
            foreach (var contractType in contractTypes)
            {
                contractDebug = contractDebug + contractType.ToString() + " | ";
            }
            _Log.LogInformation("Contract : " + contractDebug);

            string ccDebug = String.Empty;
            foreach (var cc in costCenters)
            {
                ccDebug = ccDebug + cc.ToString() + " | ";
                
            }
            _Log.LogInformation("Cost Center : " + ccDebug);

            // Set SQL Parameters
            SqlParameter[] parameters = SetParameters(month, year, contractTypes, costCenters);

            //add the parameter to the SqlCommand object
            foreach (var parameter in parameters)
            {
                cmd.Parameters.Add(parameter);
            }
            #endregion

            #region Execute SP
            try
            {
                _Log.LogInformation("Execute SQL SP");
                //await connection.OpenAsync();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 960;
                await connection.OpenAsync();
                dataReader = cmd.ExecuteReader();


                while (dataReader.Read())
                {
                    JSONContent.Append((String)dataReader.GetValue(0));
                }
            }
            catch (Exception ex)
            {
                _Log.LogError(ex.Message);
            }
            

            _Log.LogInformation("Get JSON content from SQL : " + JSONContent.ToString());
            //Parse JSON content and extract the data Array
            if (String.IsNullOrEmpty(JSONContent.ToString()))
            {
                connection.Close();
                return null;
            }
            else
            {
                var data = JObject.Parse(JSONContent.ToString());

                connection.Close();
                _Log.LogInformation("Return JSON content");
                return (JArray)data["data"];
            }
            #endregion

        }
    }
}
