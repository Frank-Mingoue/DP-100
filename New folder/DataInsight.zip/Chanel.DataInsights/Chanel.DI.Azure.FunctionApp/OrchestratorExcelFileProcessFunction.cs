using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Chanel.DataInsights.Azure.Common;
using Chanel.DataInsights.BilanSocial.Connector;
using Chanel.DataInsights.BilanSocial.Excel;
using Chanel.DataInsights.BilanSocial.Model;
using Chanel.DataInsights.Excel.Connector;
using Chanel.DI.Azure.FunctionApp.Reference;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using static System.Net.WebRequestMethods;

namespace BilanSocial.Functions
{
    public static class OrchestratorExcelFileProcessFunction
    {
        [FunctionName("MonitorExcelFileProcessFunction")]
        public static async Task<byte[]> RunOrchestrator(
            [OrchestrationTrigger] IDurableOrchestrationContext context,
            ILogger log)
        {

            byte[] returnBytes = null;

            // Binding Variables
            string content = context.GetInput<Input>()?.Content;

            log.LogInformation($"Start Monitoring...");
            if (!string.IsNullOrEmpty(content))
            {
                returnBytes = await context.CallActivityAsync<byte[]>("ExcelFileProcessFunction", content);

            }
            return returnBytes;
        }

        [FunctionName("ExcelFileProcessFunction")]
        public static async Task<byte[]> Run([ActivityTrigger] string content, ILogger log)
        {
            try
            {
                log.LogInformation($"Execute ExcelFileProcessFunction ...");
                byte[] returnBytes = null;

                if (!string.IsNullOrEmpty(content))
                {

                    ConfigurationProperties? configurationProperties = new ConfigurationProperties();


                    #region Get SQL connection string from KeyVault
                    log.LogInformation("Set Connection String SQL...");

                    String serverSQL = String.Empty;
                    String sqlDB = String.Empty;
                    String connectionString;

                    try
                    {
                        serverSQL = Environment.GetEnvironmentVariable("SQLServerName", EnvironmentVariableTarget.Process);
                        sqlDB = Environment.GetEnvironmentVariable("SQLServerDBName", EnvironmentVariableTarget.Process);


                        if (String.IsNullOrEmpty(serverSQL) || String.IsNullOrEmpty(sqlDB))
                            log.LogInformation($"SQL connection info not found, please check Environment Variable and KeyVault");
                        else
                            log.LogInformation($"SQL connection info retrieved");
                    }
                    catch (Exception ex)
                    {
                        log.LogInformation("Something wrong happens while retrieving data from KeyVault : " + ex.Message);
                    }
                    connectionString = $"Server={serverSQL}; Database={sqlDB};";
                    #endregion

                    configurationProperties.ServerSql = serverSQL;
                    configurationProperties.DatabaseSql = sqlDB;   


                    #region Get blob connection string from KeyVault
                    var blobConnectionString = String.Empty;

                    try
                    {
                        blobConnectionString = Environment.GetEnvironmentVariable("BlobConnectionString", EnvironmentVariableTarget.Process);
                        if (String.IsNullOrEmpty(blobConnectionString))
                            log.LogInformation($"Blob connection string not found, please check Environment Variable and KeyVault");
                        else
                            log.LogInformation($"Blob connection string retrieved");

                    }
                    catch (Exception ex)
                    {
                        log.LogInformation("Something wrong happens while retrieving data from KeyVault : " + ex.Message);
                    }
                    #endregion

                    configurationProperties.StorageAccountConnectionString = blobConnectionString;


                    #region Get Config file from blobstorage
                    BlobServiceClient blobServiceClient = null;
                    BlobContainerClient containerClient = null;
                    BlobClient blobClient = null;

                    try
                    {

                        log.LogInformation("Connect to Blob Service...");
                        blobServiceClient = new BlobServiceClient(blobConnectionString);
                        log.LogInformation($"Get File from Blob Container");
                        containerClient = blobServiceClient.GetBlobContainerClient(Environment.GetEnvironmentVariable("BlobContainer", EnvironmentVariableTarget.Process));
                        log.LogInformation($"Get Config File from Blob Client");
                        blobClient = containerClient.GetBlobClient("Config.json");
                        log.LogInformation(blobClient.Name);
                    }
                    catch (Exception)
                    {
                        log.LogInformation("Error while creating BlobServiceClient");
                    }
                    #endregion

                    #region Get Power BI Link

                    log.LogInformation("Get Power BI URL...");

                    String powerBIUrl = String.Empty;
                    try
                    {
                        powerBIUrl = Environment.GetEnvironmentVariable("PowerBIUrl", EnvironmentVariableTarget.Process);


                        if (String.IsNullOrEmpty(powerBIUrl))
                            log.LogInformation($"PowerBI Url info not found, please check Environment Variable and KeyVault");
                        else
                        {
                            configurationProperties.PowerBIUrl = powerBIUrl;
                            log.LogInformation($"PowerBI Url info retrieved");
                        }
                    }
                    catch (Exception ex)
                    {
                        log.LogInformation("Something wrong happens while retrieving data from KeyVault : " + ex.Message);
                    }

                    #endregion

                    // *********************************************
                    //
                    // @TODO : ADD LOGIC TO MANAGE DIFFERENT EXCEL FILE FORMAT AND CONFIG FILE
                    // THIS CHANGE WILL BE REQUIRED FOR FUTURE FILE PROCESSING
                    //
                    // *********************************************

                    #region Get Config.json

                    //Get Mapping Between Excel Sheet en SQL SP
                    DataMappingProperties? dataMapping = null;
                    if (await blobClient.ExistsAsync())
                    {
                        using (var stream = await blobClient.OpenReadAsync())
                        using (var streamReader = new StreamReader(stream))
                        using (var json = new JsonTextReader(streamReader))
                        {
                            dataMapping = JsonSerializer.CreateDefault().Deserialize<DataMappingProperties>(json);
                        }

                        foreach (var item in dataMapping.DataProperties)
                        {
                            log.LogInformation(item.SheetName);
                            foreach (var sp in item.StoredProcedure)
                            {
                                log.LogInformation(sp);
                            }
                        }
                    }
                    else
                        log.LogError("Cannot load Config.json");
                    #endregion

                    // Get Excel File
                    log.LogInformation($"Get Template File from Blob Client : CHANEL_Tags.xlsx");
                    blobClient = containerClient.GetBlobClient("CHANEL_Tags.xlsx");

                    // Replace Values in Excel
                    log.LogInformation($"Start Replace Values in Excel File...");
                    IFLogger logger = new FLogger(log);
                    if (await blobClient.ExistsAsync())
                    {
                        using (var streamReader = await blobClient.OpenReadAsync())
                        using (var ms = new MemoryStream())
                        {
                            streamReader.CopyTo(ms);
                            //Load ExcelConnector with Excel Template
                            ExcelConnector excelConnector = new ExcelConnector(ms, true, logger);
                            DataConnector dataConnector = new DataConnector(configurationProperties, dataMapping, content, logger);
                            var SQLData = await dataConnector.GetDataFromSQL();
                            XLWorkbook xLWorkbook = ExcelEngine.ApplyDataToExcelTemplate(ms, excelConnector.cellsList, SQLData, dataConnector, dataMapping);

                            xLWorkbook.Save();
                            returnBytes = ms.ToArray();
                        }
                    }
                }

                log.LogInformation("Done...");

                return returnBytes;
            }
            catch (Exception ex)
            {
                log.LogError(ex.Message, "Unhandled exception occurred during ExcelFileProcessFunction request body");
                throw (ex);
            }
          
        }
        [FunctionName("StartExcelFileProcessFunction")]
        public static async Task<HttpResponseMessage> HttpStart(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestMessage req,
            [DurableClient] IDurableOrchestrationClient starter,
            ILogger log)
        {
            try
            {
                string instanceId = string.Empty;

                // Retrieve content from the request POST
                var contentStream = await req.Content.ReadAsStreamAsync();
                log.LogInformation("Start Process...");
                var content = await new StreamReader(contentStream).ReadToEndAsync();
                log.LogInformation("Retrieved HTTP Body...");
                log.LogInformation(content);

                if (!string.IsNullOrEmpty(content))
                {
                    // Function input comes from the request content.
                    instanceId = await starter.StartNewAsync("MonitorExcelFileProcessFunction", new Input { Content = content });
                }

                log.LogInformation($"Started orchestration with ID = '{instanceId}'.");

                return starter.CreateCheckStatusResponse(req, instanceId);
            }
            catch (Exception ex)
            {
                log.LogError(ex.Message);
                return new HttpResponseMessage(HttpStatusCode.BadGateway);
            }

        }
    }
}