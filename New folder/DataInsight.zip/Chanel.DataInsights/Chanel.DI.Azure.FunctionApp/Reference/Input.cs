﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chanel.DI.Azure.FunctionApp.Reference
{
    public class Input
    {
        public string Content { get; set; }
    }
}
