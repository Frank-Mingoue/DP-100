﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chanel.DataInsights.Excel.Model
{
    public class CellConfig
    {
        public string SheetName { get; set; }
        public int SheetID { get; set; }
        public string? TagName { get; set; }
        public int CellID { get; set; }
        public int RowID { get; set; }

        public string ValueType { get; set; }

        public CellConfig()
        {

        }

    }
}
