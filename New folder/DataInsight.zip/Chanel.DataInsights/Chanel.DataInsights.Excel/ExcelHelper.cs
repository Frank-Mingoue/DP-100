﻿using Chanel.DataInsights.Azure.Common;
using Chanel.DataInsights.Excel.Model;
using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Chanel.DataInsights.Excel
{
    public static class ExcelHelper
    {

        /// <summary>
        /// Check the tag pattern
        /// </summary>
        /// <param name="value"> Value of the cell </param>
        /// <returns> True / False </returns>
        public static bool IsTag(string value)
        {
            if (!string.IsNullOrEmpty(value) && Regex.IsMatch(value, @"##"))
            {
                return true;

            }
            return false;
        }


        public static List<CellConfig> GetExcelCells(MemoryStream templateFile, IFLogger log)
        {
            List<CellConfig> cellConfigs = new List<CellConfig>();

            try
            {
                var ms = new MemoryStream();
                
                    ms.Flush();
                    ms.Position = 0;
                    templateFile.Position = 0;
                    templateFile.CopyToAsync(ms).Wait();

                    ms.Position = 0;

                    
                    var wb = new XLWorkbook(ms);


                    foreach (IXLWorksheet ws in wb.Worksheets)
                    {
                        foreach (IXLCell cell in ws.CellsUsed())
                        {
                            try
                            {
                                if (cell.CachedValue != null && !String.IsNullOrEmpty(cell.CachedValue.ToString()) && ExcelHelper.IsTag(cell.CachedValue.ToString()))
                                {
                                    CellConfig cellconfig = new CellConfig();
                                    cellconfig.SheetID = ws.Position - 1;
                                    cellconfig.TagName = cell.CachedValue.ToString();
                                    cellconfig.SheetName = ws.Name;
                                    cellconfig.CellID = cell.Address.ColumnNumber;
                                    cellconfig.RowID = cell.Address.RowNumber;
                                    cellConfigs.Add(cellconfig);
                                }
                            }
                            catch (Exception ex)
                            {
                                log.LogError(ex.Message);
                            }
                        }
                    }
                
            }
            catch(Exception ex)
            {
                log.LogError(ex.Message);
            }
            
            return cellConfigs;

        }
    }
}
