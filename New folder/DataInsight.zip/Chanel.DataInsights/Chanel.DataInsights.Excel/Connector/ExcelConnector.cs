﻿using Chanel.DataInsights.Azure.Common;
using Chanel.DataInsights.Excel.Model;
using DocumentFormat.OpenXml.EMMA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chanel.DataInsights.Excel.Connector
{
    public class ExcelConnector
    {
        private MemoryStream _TemplateFile;
        private IFLogger _Log;
        private bool _DebugMode;
        public List<CellConfig> cellsList;
        public ExcelConnector(MemoryStream templateFile, bool debugMode, IFLogger log)
        {
            _TemplateFile = templateFile;
            _Log = log;
            _DebugMode = debugMode;

            cellsList = ExcelHelper.GetExcelCells(templateFile, log);
        }
    }
}
