﻿// See https://aka.ms/new-console-template for more information
using Chanel.DataInsights.Azure.Common;
using Chanel.DataInsights.Index.Connector;
using Chanel.DataInsights.Index.Excel;
using Chanel.DataInsights.Index.Model;
using Chanel.DataInsights.Excel.Connector;
using ClosedXML.Excel;
using Newtonsoft.Json;
using System.IO;
using Newtonsoft.Json.Linq;

Console.WriteLine("Hello, World!");




Console.WriteLine("Start Processing Excel File...");

//Mock Azure Function Logger
IFLogger log = new FLogger();

string solutionPath = Path.Combine(Directory.GetCurrentDirectory(), "MockData");

//Mock Azure Function App Configuration
ConfigurationProperties? configurationProperties = null;
using (var streamReader = new StreamReader(Path.Combine(solutionPath, "local.settings.json")))
using (var json = new JsonTextReader(streamReader))
{
    if (json != null)
        configurationProperties = JsonSerializer.CreateDefault().Deserialize<ConfigurationProperties>(json);
}

// Get SQL Configuration
//string connectionString = $"Server={configurationProperties.ServerSql}; Database={configurationProperties.DatabaseSql};";

// Get Mock HTTP Body
var body = await new StreamReader(Path.Combine(solutionPath, "PowerAppsParameters.json")).ReadToEndAsync();




var data = JObject.Parse(body);
var size = data.SelectToken("$.size").Value<string>();
var filter = data.SelectToken("$.filter").Value<string>(); 
var template = data.SelectToken("$.template").Value<string>();

//cleanup " and +
if (template != null)
    template = template.Replace("\"", "");
if (size != null)
    size = size.Replace("\"", "").Replace("+", "").Replace("/", "");
if (filter != null)
    filter = filter.Replace("\"", "").ToUpper();


string configFileName = $"Config_Index{template}_FH{size}_{filter}.json";
string templateFileName = $"Index{template}_FH{size}_{filter}.xlsx";







//Get Mapping Between Excel Sheet en SQL SP
Console.WriteLine("Get Config File...");
DataMappingProperties? dataMapping = null;
//if (configurationProperties != null && !String.IsNullOrEmpty(configurationProperties.BlobConfigName))
if (configurationProperties != null && !String.IsNullOrEmpty(configFileName))
{
    using (var streamReader = new StreamReader(Path.Combine(solutionPath, configFileName)))
    //using (var streamReader = new StreamReader(Path.Combine(solutionPath, configurationProperties.BlobConfigName)))
    using (var json = new JsonTextReader(streamReader))
    {
        dataMapping = JsonSerializer.CreateDefault().Deserialize<DataMappingProperties>(json);
    }
}
else
{
    throw new Exception("Blob configuration null or empty");
}


//Get Excel template file
Console.WriteLine("Get Template File..."); 

//using (FileStream file = new FileStream(Path.Combine(solutionPath, configurationProperties.BlobClientName), FileMode.Open, FileAccess.Read))
using (FileStream file = new FileStream(Path.Combine(solutionPath, templateFileName), FileMode.Open, FileAccess.Read))
{
    //using (var ms = new MemoryStream())
    //{

    MemoryStream ms = new MemoryStream();

    file.CopyTo(ms);
    var wb = new XLWorkbook(file);
    //Load ExcelConnector with Excel Template
    ExcelConnector excelConnector = new ExcelConnector(ms, true, log);
    DataConnector dataConnector = new DataConnector(configurationProperties, dataMapping, body, log);
    var SQLData = await dataConnector.GetDataFromSQL();
    XLWorkbook xLWorkbook = ExcelEngine.ApplyDataToExcelTemplate(ms, excelConnector.cellsList, SQLData, dataConnector.GetBodyModel(), dataMapping);

    xLWorkbook.SaveAs(Path.Combine(solutionPath, "MyFiles.xlsx"));
    //}
}






// Retrieve Data
Console.WriteLine("Retrieve Data...");
//DataConnector dataConnector = new DataConnector(body, connectionString, parserProps, null, log);
//await dataConnector.CreateDataProperties(excelConnector.GetListSheets());
//Console.WriteLine("Number of Data Collected : " + dataConnector.DataProperties.Count);

// Create Config Properties
Console.WriteLine("Collect Config Info...");
//excelConnector.CreatePropertiesObject(dataConnector.DataProperties);
//Console.WriteLine("Number of Properties : " + excelConnector.Properties.Count);

Console.WriteLine("Replace Value in Excel File...");
//excelConnector.InsertValues(Path.Combine(solutionPath, "CHANEL - Processed.xlsx"));
