﻿// See https://aka.ms/new-console-template for more information
using Azure.Core;
using Azure.Identity;
using Chanel.DataInsights.Azure.Common;
using Chanel.DataInsights.BilanSocial.Connector;
using Chanel.DataInsights.BilanSocial.Excel;
using Chanel.DataInsights.BilanSocial.Model;
using Chanel.DataInsights.Excel.Connector;
using ClosedXML.Excel;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.IO;


Console.WriteLine("Start Processing Excel File...");

//Mock Azure Function Logger
IFLogger log = new FLogger();

string solutionPath = Path.Combine(Directory.GetCurrentDirectory(), "MockData");

//Mock Azure Function App Configuration
ConfigurationProperties? configurationProperties = null;
using (var streamReader = new StreamReader(Path.Combine(solutionPath, "local.settings.json")))
using (var json = new JsonTextReader(streamReader))
{
    if (json != null)
        configurationProperties = JsonSerializer.CreateDefault().Deserialize<ConfigurationProperties>(json);
}

// Get SQL Configuration
//string connectionString = $"Server={configurationProperties.ServerSql}; Database={configurationProperties.DatabaseSql};";

// Get Mock HTTP Body
var body = await new StreamReader(Path.Combine(solutionPath, "PowerAppsParameters.json")).ReadToEndAsync();

//Get Mapping Between Excel Sheet en SQL SP
Console.WriteLine("Get Config File..." + configurationProperties.BlobConfigName);
DataMappingProperties? dataMapping = null;
if (configurationProperties != null && !String.IsNullOrEmpty(configurationProperties.BlobConfigName))
{    
    using (var streamReader = new StreamReader(Path.Combine(solutionPath, configurationProperties.BlobConfigName)))
    using (var json = new JsonTextReader(streamReader))
    {
        dataMapping = JsonSerializer.CreateDefault().Deserialize<DataMappingProperties>(json);
    }
}
else
{
    throw new Exception("Blob configuration null or empty");
}


//Get Excel template file
Console.WriteLine("Get Template File...");

using (FileStream file = new FileStream(Path.Combine(solutionPath, configurationProperties.BlobClientName), FileMode.Open, FileAccess.Read))
{
    //using (var ms = new MemoryStream())
    //{
    Console.WriteLine("Start processing file : " + configurationProperties.BlobClientName);
    MemoryStream ms = new MemoryStream();

    file.CopyTo(ms);
    var wb = new XLWorkbook(file);
    //Load ExcelConnector with Excel Template
    Console.WriteLine("Load Excel File...");
    ExcelConnector excelConnector = new ExcelConnector(ms, true, log);
    Console.WriteLine("Get data from SQL...");
    DataConnector dataConnector = new DataConnector(configurationProperties, dataMapping, body, log);
    Console.WriteLine(configurationProperties.DatabaseSql + " / " + configurationProperties.ServerSql);

    var SQLData = await dataConnector.GetDataFromSQL();
    Console.WriteLine(SQLData.Count);
    Console.WriteLine("Apply Data to Excel Template...");
    XLWorkbook xLWorkbook = ExcelEngine.ApplyDataToExcelTemplate(ms, excelConnector.cellsList, SQLData, dataConnector, dataMapping);
    Console.WriteLine("Save file as MyFiles.xlsx...");
    xLWorkbook.SaveAs(Path.Combine(solutionPath, "MyFiles.xlsx"));
    //}
}




Console.ReadLine();

