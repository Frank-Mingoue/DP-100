namespace ClosedXML.Excel
{
    public interface IXLNumberFormatBase
    {
        int NumberFormatId { get; set; }

        string Format { get; set; }
    }
}
