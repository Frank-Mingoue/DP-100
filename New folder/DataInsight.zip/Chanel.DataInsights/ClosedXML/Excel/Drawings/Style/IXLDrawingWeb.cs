namespace ClosedXML.Excel
{
    public interface IXLDrawingWeb
    {
        string AlternateText { get; set; }
        IXLDrawingStyle SetAlternateText(string value);

    }
}
