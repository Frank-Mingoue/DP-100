namespace ClosedXML.Excel
{
    public interface IXLSheetProtection : IXLElementProtection<XLSheetProtectionElements>
    {
    }
}
