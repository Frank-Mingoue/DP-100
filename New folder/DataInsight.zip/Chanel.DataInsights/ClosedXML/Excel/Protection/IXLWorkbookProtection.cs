﻿namespace ClosedXML.Excel
{
    public interface IXLWorkbookProtection : IXLElementProtection<XLWorkbookProtectionElements>
    {
    }
}
