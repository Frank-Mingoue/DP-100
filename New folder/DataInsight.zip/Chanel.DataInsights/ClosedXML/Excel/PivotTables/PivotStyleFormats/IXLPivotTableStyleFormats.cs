﻿// Keep this file CodeMaid organised and cleaned
namespace ClosedXML.Excel
{
    public interface IXLPivotTableStyleFormats
    {
        IXLPivotStyleFormats ColumnGrandTotalFormats { get; }
        IXLPivotStyleFormats RowGrandTotalFormats { get; }
    }
}
