﻿namespace ClosedXML.Excel
{
    internal enum XLPivotAreaValues
    {
        None = 0,
        Normal = 1,
        Data = 2,
        All = 3,
        Origin = 4,
        Button = 5,
        TopRight = 6,
        TopEnd = 7
    }
}
