namespace ClosedXML.Excel
{
    public interface IXLRichText : IXLFormattedText<IXLRichText>
    {
    }
}
