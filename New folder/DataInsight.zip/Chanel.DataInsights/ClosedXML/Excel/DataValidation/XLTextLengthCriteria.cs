// Keep this file CodeMaid organised and cleaned

namespace ClosedXML.Excel
{
    public class XLTextLengthCriteria : XLWholeNumberCriteriaBase
    {
        public XLTextLengthCriteria(IXLDataValidation dataValidation)
            : base(dataValidation)
        {
        }
    }
}
