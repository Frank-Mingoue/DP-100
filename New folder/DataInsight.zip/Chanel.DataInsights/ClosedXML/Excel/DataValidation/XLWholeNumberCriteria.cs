// Keep this file CodeMaid organised and cleaned
namespace ClosedXML.Excel
{
    public class XLWholeNumberCriteria : XLWholeNumberCriteriaBase
    {
        public XLWholeNumberCriteria(IXLDataValidation dataValidation)
            : base(dataValidation)
        {
        }
    }
}
