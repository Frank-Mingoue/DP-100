﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chanel.DataInsights.Azure.Common
{
    public class FLogger : IFLogger
    {
        ILogger _log;

        public FLogger(ILogger log)
        {
            if (log != null)
                _log = log;
        }

        public FLogger()
        {

        }

        public void LogError(string v)
        {
            if(_log != null)  
                _log.LogError(v);
        }

        public void LogInformation(string v)
        {
            if (_log != null)
                _log.LogInformation(v);
        }
    }
}
