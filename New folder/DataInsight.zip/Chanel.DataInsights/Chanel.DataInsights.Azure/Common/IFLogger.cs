﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chanel.DataInsights.Azure.Common
{
    public interface IFLogger
    {
        void LogError(string v);
        void LogInformation(string v);
    }
}
