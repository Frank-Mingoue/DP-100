﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chanel.DataInsights.Azure.Common
{
    [JsonObject(MemberSerialization.OptIn)]
    public class ConfigurationProperties
    {
        [JsonProperty("StorageAccountConnectionString")]
        public string? StorageAccountConnectionString { get; set; }
        [JsonProperty("BlobContainerName")]
        public string? BlobContainerName { get; set; }
        [JsonProperty("BlobClientName")]
        public string? BlobClientName { get; set; }
        [JsonProperty("BlobConfigName")]
        public string? BlobConfigName { get; set; }
        [JsonProperty("ServerSql")]
        public string? ServerSql { get; set; }
        [JsonProperty("DatabaseSql")]
        public string? DatabaseSql { get; set; }
        [JsonProperty("User")]
        public string? User { get; set; }
        [JsonProperty("Password")]
        public string? Password { get; set; }
        [JsonProperty("PowerBIUrl")]
        public string? PowerBIUrl { get; set; }
    }
}
