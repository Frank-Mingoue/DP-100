﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chanel.DataInsights.BilanSocial.Model
{
    public class DataMappingProperties
    {
        [JsonProperty("DataProperties")]
        public IEnumerable<ExcelSheetProperties>? DataProperties { get; set; }
        [JsonProperty("DebugMode")]
        public bool DebugMode { get; set; }
    }

    public class ExcelSheetProperties
    {
        [JsonProperty("SheetName")]
        public string? SheetName { get; set; }

        [JsonProperty("StoredProcedure")]
        public List<string>? StoredProcedure { get; set; }

        [JsonProperty("TagsWithURL_Regex")]
        public string? TagsWithURL_Regex { get; set; }

        [JsonProperty("TagsWithURL_Forced")]
        public List<string>? TagsWithURL_Forced { get; set; }

        [JsonProperty("TagsWithoutURL_Forced")]
        public List<string>? TagsWithoutURL_Forced { get; set; }

    }
}
