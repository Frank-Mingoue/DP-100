﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chanel.DataInsights.BilanSocial.Model
{
    public class BodyModel
    {
        public int Year { get; set; }
        public string[] Value { get; set; }
        public string[] Societes { get; set; }
        public string[] Cses { get; set; }
        public string[] Etablissements { get; set; }
        public string[] Divisions { get; set; }
        public string[] DivisionsDetailed { get; set; }
    }
}
