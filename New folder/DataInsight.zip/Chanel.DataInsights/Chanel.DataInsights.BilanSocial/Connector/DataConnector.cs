﻿using Azure.Core;
using Azure.Identity;
using Chanel.DataInsights.Azure.Common;
using Chanel.DataInsights.BilanSocial.Common;
using Chanel.DataInsights.BilanSocial.Model;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Chanel.DataInsights.BilanSocial.Connector
{
    public class DataConnector
    {
        private readonly IFLogger _Log;
        private string _SqlConnectionString { get; set; }
        private BodyModel _BodyModel { get; set; }
        private DataMappingProperties _DataMappingProperties { get; set; }
        private List<DataProperty> _DataProperties { get; set; }
        private readonly string _PowerBiUrl;

        /// <summary>
        /// Create a DataConnector to get data from SQL Server
        /// </summary>
        /// <param name="configuration">Azure Function configuration</param>
        /// <param name="dataMapping">Data Mapping between Excel Sheet and SQL SP</param>
        /// <param name="body">HTTP Body (json)</param>
        /// <param name="logger">Azure logger</param>
        public DataConnector(ConfigurationProperties configuration, DataMappingProperties dataMapping, string body, IFLogger logger)
        {
            _Log = logger;
            _SqlConnectionString = $"Server={configuration.ServerSql}; Database={configuration.DatabaseSql};";
            _DataMappingProperties = dataMapping;

            if (!String.IsNullOrEmpty(configuration.PowerBIUrl))
                _PowerBiUrl = configuration.PowerBIUrl;


            // Retrieve data from input json
            var data = JObject.Parse(body);
            var year = data.SelectToken("$.year").Value<string>();
            var costCenterList = data.SelectTokens("$.body.Table1[0:].Cost_Center").Values<string>().ToList();
            var societeList = data.SelectTokens("$.SocietesFilters").FirstOrDefault().ToString();
            var cseList = data.SelectTokens("$.CSEFilters").FirstOrDefault().ToString();
            var etablissementList = data.SelectTokens("$.EstablishmentFilters").FirstOrDefault().ToString();
            var divisionList = data.SelectTokens("$.DivisionFilters").FirstOrDefault().ToString();
            var divisionDetailedList = data.SelectTokens("$.DetailedDivisionFilters").FirstOrDefault().ToString();

            // Set Data to BodyProperty from input data request
            // @TODO : A revoir pour gérer le ALL
            //
            _BodyModel = new BodyModel();
            _BodyModel.Year = Int32.Parse(year);
            _Log.LogInformation("Year : " + year);

            _BodyModel.Value = costCenterList.ToArray<string>();
            _Log.LogInformation("Number of Cost Center  : " + costCenterList.Count());

            _BodyModel.Societes = societeList.Split(" / ");
            _Log.LogInformation("Societes  : " + _BodyModel.Societes.Count());

            _BodyModel.Etablissements = etablissementList.Split(" / ");
            _Log.LogInformation("Etablissements  : " + _BodyModel.Etablissements.Count());

            _BodyModel.Cses = cseList.Split(" / ");
            _Log.LogInformation("CSES  : " + _BodyModel.Cses.Count());

            _BodyModel.Divisions = divisionList.Split(" / ");
            _Log.LogInformation("Divisions  : " + _BodyModel.Divisions.Count());

            _BodyModel.DivisionsDetailed = divisionDetailedList.Split(" / ");
            _Log.LogInformation("Divisions Detailed : " + _BodyModel.DivisionsDetailed.Count());


        }

        public BodyModel GetBodyModel()
        {           
            return _BodyModel;
        }

        public string GetPowerBIUrl()
        {
            return _PowerBiUrl;
        }


        public async Task<List<DataProperty>> GetDataFromSQL()
        {
            _DataProperties = new List<DataProperty>();

            // Set Year / Filter data properties from the input request
            _DataProperties.Add(new DataProperty(_BodyModel.Year.ToString(), TagsConstants.YearN, TypeConstants.String, null));
            _DataProperties.Add(new DataProperty((_BodyModel.Year - 1).ToString(), TagsConstants.YearN1, TypeConstants.String, null));
            _DataProperties.Add(new DataProperty((_BodyModel.Year - 2).ToString(), TagsConstants.YearN2, TypeConstants.String, null));
            DataProperty dateCompare = new DataProperty();
                dateCompare.Value = TagsConstants.YearCompare.Replace(TagsConstants.YearN, _BodyModel.Year.ToString()).Replace(TagsConstants.YearN1, (_BodyModel.Year - 1).ToString());
                dateCompare.TagName = TagsConstants.YearCompare;
                dateCompare.Type = TypeConstants.String;
                dateCompare.Link = null;
            _DataProperties.Add(dateCompare);
            _DataProperties.Add(new DataProperty(string.Join(" / ", _BodyModel.Societes), TagsConstants.Societes, TypeConstants.String, null));
            _DataProperties.Add(new DataProperty(string.Join(" / ", _BodyModel.Etablissements), TagsConstants.Etablissements, TypeConstants.String, null));
            _DataProperties.Add(new DataProperty(string.Join(" / ", _BodyModel.Cses), TagsConstants.Cses, TypeConstants.String, null));
            _DataProperties.Add(new DataProperty(string.Join(" / ", _BodyModel.Divisions), TagsConstants.Divisions, TypeConstants.String, null));
            _DataProperties.Add(new DataProperty(string.Join(" / ", _BodyModel.DivisionsDetailed), TagsConstants.DivisionsDetailed, TypeConstants.String, null));

            DataProperty chart = new DataProperty();
            chart.Value = TagsConstants.ChartD.Replace(TagsConstants.YearN, _BodyModel.Year.ToString());
            chart.TagName = TagsConstants.ChartD;
            chart.Type = TypeConstants.String;
            chart.Link = null;
            _DataProperties.Add(chart);

            DataProperty chart2 = new DataProperty();
            chart2.Value = TagsConstants.ChartD2.Replace(TagsConstants.YearN, _BodyModel.Year.ToString());
            chart2.TagName = TagsConstants.ChartD2;
            chart2.Type = TypeConstants.String;
            chart2.Link = null;
            _DataProperties.Add(chart2);



            try
            {
                if (_DataMappingProperties != null && _DataMappingProperties.DataProperties != null)
                {
                    foreach (ExcelSheetProperties item in _DataMappingProperties.DataProperties)
                    {
                        foreach (string storeProcedure in item.StoredProcedure)
                        {
                            JArray jArray = await QueryData(storeProcedure, _BodyModel.Year, _BodyModel.Value);

                            if (jArray != null)
                                foreach (JToken jToken in jArray)
                                {
                                    DataProperty data = new DataProperty();
                                    data.Value = jToken.Value<string?>("effectif") ?? string.Empty;
                                    data.TagName = ((JValue)jToken["effectif_id"]).Value.ToString().ToUpper().Replace("É", "E").Replace("È", "E").Replace(_BodyModel.Year.ToString(), TagsConstants.NameYearN).Replace((_BodyModel.Year - 1).ToString(), TagsConstants.NameYearN1).Replace((_BodyModel.Year - 2).ToString(), TagsConstants.NameYearN2);
                                    data.Type = long.TryParse(jToken.Value<string?>("effectif") ?? string.Empty, out long value) ? TypeConstants.Number : TypeConstants.String;
                                    data.Link = CreateUrl(((JValue)jToken["effectif_id"]).Value.ToString().ToUpper().Replace("É", "E").Replace("È", "E").Replace(_BodyModel.Year.ToString(), TagsConstants.NameYearN).Replace((_BodyModel.Year - 1).ToString(), TagsConstants.NameYearN1).Replace((_BodyModel.Year - 2).ToString(), TagsConstants.NameYearN2));

                                    _DataProperties.Add(data);
                                }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                _Log.LogError($"Something went wrong during CreateDataProperties: {ex.Message}");
            }
            return _DataProperties;
        }

        /// <summary>
        /// Create URL with Filter Variable
        /// </summary>
        /// <param name="tag"></param>
        /// <returns></returns>
        private string? CreateUrl(string tagName)
        {

            // Initialize all variables
            string divisions = string.Empty;
            string divisionsDetailed = string.Empty;
            string societes = string.Empty;
            string cses = string.Empty;
            string etablissements = string.Empty;

            // Create Divisions URL
            if (!string.IsNullOrEmpty(tagName))
            {
                if (_BodyModel.Divisions != null)
                {
                    divisions = string.Join("&rp:Division=", _BodyModel.Divisions);

                }

                // Create Divisions Detailed URL 

                if (_BodyModel.DivisionsDetailed != null)
                {
                    divisionsDetailed = string.Join("&rp:Division_Detaillee=", _BodyModel.DivisionsDetailed);

                }

                // Create Societes

                if (_BodyModel.Societes != null)
                {
                    societes = string.Join("&rp:Societe=", _BodyModel.Societes);

                }

                // Create CSES 

                if (_BodyModel.Cses != null)
                {
                    cses = string.Join("&rp:CSE=", _BodyModel.Cses);

                }

                // Create Etablissements

                if (_BodyModel.Etablissements != null)
                {
                    etablissements = string.Join("&rp:Etablissement=", _BodyModel.Etablissements);

                }

                /*return $"{_PowerBiUrl}?rp:Annee={_BodyModel.Year}&rp:LegalIndicatorTag={HttpUtility.UrlEncode(tagName)}{HttpUtility.UrlEncode(divisions)}{HttpUtility.UrlEncode(divisionsDetailed)}{HttpUtility.UrlEncode(societes)}{HttpUtility.UrlEncode(cses)}{HttpUtility.UrlEncode(etablissements)}";*/
                return _PowerBiUrl;

            }
            return null;
        }


        /// <summary>
        /// Set list of SQL Parameters
        /// </summary>
        /// <param name="year"> Current Year </param>
        /// <param name="costCenters"> List of Cost Centers </param>
        /// <returns> List of SQL Parameters </returns>
        private SqlParameter[] SetParameters(int year, string[] costCenters)
        {
            // Init Cost Centers
            _Log.LogInformation("Init SQL Cost Centers in UDT and year");
            DataTable costCenter = new DataTable();
            costCenter.Columns.Add("costcentercode", typeof(string));

            foreach (String cc in costCenters)
            {
                DataRow row = costCenter.NewRow();
                row.ItemArray = new String[] { cc };
                costCenter.Rows.Add(row);
            }


            SqlParameter[] parameters = {
                new SqlParameter("@CostCenterCode", costCenter)
                {
                    SqlDbType = SqlDbType.Structured,
                    TypeName = "[bs].[Employee_Cost_Centre_Type]"
                },
                new SqlParameter("@CurrentYear", year)
                {
                    SqlDbType = SqlDbType.Int,
                }
            };
            return parameters;
        }

        /// <summary>
        /// Query Data by calling Procedure Stored
        /// </summary>
        /// <param name="spName"> Name of Procedure Stored </param>
        /// <param name="year"> Current Year </param>
        /// <param name="costCenters"> List of Cost Center </param>
        /// <returns>A JArray contains data </returns>
        private async Task<JArray> QueryData(string spName, int year, string[] costCenters)
        {
            try
            {
                #region Connection SQL

                _Log.LogInformation("Getting Access Token...");
                var accessToken = await new DefaultAzureCredential().GetTokenAsync(new TokenRequestContext(new string[] { "https://database.windows.net//.default" }));
                _Log.LogInformation("Access Token retrieved !");

                _Log.LogInformation("Init SQL Connection");
                using SqlConnection connection = new SqlConnection(_SqlConnectionString)
                {
                    AccessToken = accessToken.Token
                };

                SqlDataReader dataReader;
                #endregion

                #region Initialize Parameters 
                _Log.LogInformation("Init SQL Param : " + spName);
                string sp = $"bs.[{spName}]";
                SqlCommand cmd = new SqlCommand(sp, connection);

                // Set SQL Parameters
                SqlParameter[] parameters = SetParameters(year, costCenters);

                //add the parameter to the SqlCommand object
                foreach (var parameter in parameters)
                {
                    cmd.Parameters.Add(parameter);
                }
                #endregion

                #region Execute SP
                _Log.LogInformation("Execute SQL SP");
                await connection.OpenAsync();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 900;
                dataReader = cmd.ExecuteReader();

                StringBuilder JSONContent = new StringBuilder();

                while (dataReader.Read())
                {
                    JSONContent.Append((String)dataReader.GetValue(0));
                }
                _Log.LogInformation("Get JSON content from SQL : " + JSONContent.ToString());
                //Parse JSON content and extract the data Array
                if (String.IsNullOrEmpty(JSONContent.ToString()))
                {
                    connection.Close();
                    return null;
                }
                else
                {
                    var data = JObject.Parse(JSONContent.ToString());

                    connection.Close();
                    _Log.LogInformation("Return JSON content");
                    return (JArray)data["data"];
                }
                #endregion
            }
            catch (Exception ex)
            {
                _Log.LogError("An error occured in QueryData method : " + ex.Message);
                throw;
            }
        }
    }
}
