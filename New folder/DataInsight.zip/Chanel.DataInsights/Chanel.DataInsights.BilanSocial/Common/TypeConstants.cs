﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chanel.DataInsights.BilanSocial.Common
{
    public static class TypeConstants
    {
        public const string String = "String";
        public const string Number = "Number";
    }
}
