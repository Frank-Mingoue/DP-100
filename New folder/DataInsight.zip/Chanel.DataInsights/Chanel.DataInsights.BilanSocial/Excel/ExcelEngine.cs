﻿using Chanel.DataInsights.BilanSocial.Common;
using Chanel.DataInsights.BilanSocial.Connector;
using Chanel.DataInsights.BilanSocial.Model;
using Chanel.DataInsights.Excel.Model;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;

namespace Chanel.DataInsights.BilanSocial.Excel
{
    public static class ExcelEngine
    {
        public static XLWorkbook ApplyDataToExcelTemplate(MemoryStream templateFile, List<CellConfig> excelModel, List<DataProperty> dataProperties, DataConnector dataConnector, DataMappingProperties dataMappingProperties)
        {
            var wb = new XLWorkbook(templateFile);

            BodyModel body = dataConnector.GetBodyModel();

            foreach (CellConfig cellConfig in excelModel)
            {
                if (dataProperties.Exists(c => c.TagName.Replace("É", "E").Replace("È", "E").Replace("__", "_") == cellConfig.TagName.Replace("É", "E").Replace("È", "E").Replace("__","_").Replace("\n","") ))
                {
                    DataProperty bsValue = dataProperties.FirstOrDefault(c => c.TagName.Replace("É", "E").Replace("È", "E").Replace("__", "_") == cellConfig.TagName.Replace("É", "E").Replace("È", "E").Replace("__", "_").Replace("\n", ""));

                    wb.Worksheets.ElementAt(cellConfig.SheetID).Cell(cellConfig.RowID, cellConfig.CellID).Value = bsValue.Value;

                    //if ((dataMappingProperties.DataProperties.ToList<ExcelSheetProperties>().FirstOrDefault(e => e.SheetName == cellConfig.SheetName) != null) 
                    //    && (dataMappingProperties.DataProperties.ToList<ExcelSheetProperties>().FirstOrDefault(e => e.SheetName == cellConfig.SheetName).TagsWithURL != null))
                    //{
                        //if(dataMappingProperties.DataProperties.ToList<ExcelSheetProperties>().FirstOrDefault(e => e.SheetName == cellConfig.SheetName).TagsWithURL.Exists(c => c == cellConfig.TagName) == true)
                        
                            if (IsHyperlinkRequired(cellConfig, dataMappingProperties) && !String.IsNullOrEmpty(dataConnector.GetPowerBIUrl()))
                                wb.Worksheets.ElementAt(cellConfig.SheetID).Cell(cellConfig.RowID, cellConfig.CellID).SetHyperlink(new XLHyperlink(BuildPowerBIURL(dataConnector.GetPowerBIUrl(),bsValue.TagName, dataConnector.GetBodyModel())));
                    //}
                }
                else
                {
                    if (!dataMappingProperties.DebugMode)
                    {
                        wb.Worksheets.ElementAt(cellConfig.SheetID).Cell(cellConfig.RowID, cellConfig.CellID).Value = "";
                    }
                }
            }

            wb.Save();

            return wb;
        }


        public static bool IsHyperlinkRequired(CellConfig cellConfig, DataMappingProperties dataMappingProperties)
        {
            if (IsTagsFieldExists(cellConfig.SheetName, dataMappingProperties))
            {
                if (dataMappingProperties.DataProperties.ToList<ExcelSheetProperties>().FirstOrDefault(e => e.SheetName == cellConfig.SheetName).TagsWithoutURL_Forced.Exists(c => c == cellConfig.TagName) == true)
                    return false;

                if (dataMappingProperties.DataProperties.ToList<ExcelSheetProperties>().FirstOrDefault(e => e.SheetName == cellConfig.SheetName).TagsWithURL_Forced.Exists(c => c == cellConfig.TagName) == true)
                    return true;


                string regexPattern = dataMappingProperties.DataProperties.ToList<ExcelSheetProperties>().FirstOrDefault(e => e.SheetName == cellConfig.SheetName).TagsWithURL_Regex;
                Regex regex = new Regex(regexPattern);

                if (regex.IsMatch(cellConfig.TagName))
                    return true;
                
            }

            return false;
        }

        /// <summary>
        /// Check if TagsWithURL_Forced / TagsWithoutURL_Forced / TagsWithURL_Regex are set
        /// </summary>
        /// <param name="sheetName"></param>
        /// <param name="dataMappingProperties"></param>
        /// <returns></returns>
        public static bool IsTagsFieldExists(string sheetName, DataMappingProperties dataMappingProperties)
        {
            bool res = false;

            if (IsPropertiesExistForSheet(sheetName, dataMappingProperties))
            {
                res = (dataMappingProperties.DataProperties.ToList<ExcelSheetProperties>().FirstOrDefault(e => e.SheetName == sheetName).TagsWithURL_Regex != null);
                res = res && (dataMappingProperties.DataProperties.ToList<ExcelSheetProperties>().FirstOrDefault(e => e.SheetName == sheetName).TagsWithURL_Forced != null);
                res = res && (dataMappingProperties.DataProperties.ToList<ExcelSheetProperties>().FirstOrDefault(e => e.SheetName == sheetName).TagsWithoutURL_Forced != null);
            }

            return res;
        }

        /// <summary>
        /// Check if properties exist in config.json for given Sheet
        /// </summary>
        /// <param name="sheetName"></param>
        /// <param name="dataMappingProperties"></param>
        /// <returns></returns>
        public static bool IsPropertiesExistForSheet(string sheetName, DataMappingProperties dataMappingProperties)
        {
            bool res = false;
            if (!String.IsNullOrEmpty(sheetName) && dataMappingProperties != null && dataMappingProperties.DataProperties != null)
                res = (dataMappingProperties.DataProperties.ToList<ExcelSheetProperties>().FirstOrDefault(e => e.SheetName == sheetName) != null);

            return res;
        }


        private static string ReplaceYearTag(string tag, BodyModel bodyModel)
        {
            return tag.Replace(TagsConstants.YearN, bodyModel.Year.ToString()).Replace(TagsConstants.YearN1, (bodyModel.Year -1).ToString()).Replace(TagsConstants.YearN2, (bodyModel.Year-2).ToString());
        }

        private static string GetYearByTag(string tag, BodyModel bodyModel)
        {
            Regex regex = new Regex("##[YEAR_]{5}\\w(\\W\\w){0,1}##");
            Match match = regex.Match(tag);
            if (match.Success)
            {
                string year = match.Groups[0].Value.Replace(TagsConstants.YearN, (bodyModel.Year).ToString()).Replace(TagsConstants.YearN1, (bodyModel.Year - 1).ToString()).Replace(TagsConstants.YearN2, (bodyModel.Year - 2).ToString());
                return year;
            }

            return String.Empty;
            //"##[YEAR_]{5}\w(\W\w){0,1}##"
        }


        public static string BuildPowerBIURL(string baseURL, string tag, BodyModel bodyModel)
        {
            String url = baseURL;
            StringBuilder sb = new StringBuilder();
            bool filter = false;

            sb.Append(baseURL);
            //sb.AppendFormat("?rp:Annee={0}",bodyModel.Year);
            sb.AppendFormat("?rp:Annee={0}", GetYearByTag(tag, bodyModel));
            sb.AppendFormat("&rp:LegalIndicatorTag={0}", ReplaceYearTag(tag,bodyModel).Replace("#","%23"));
            

            if (bodyModel.Societes.Count<string>() == 1)
            {
                sb.AppendFormat("&rp:Societe={0}", HttpUtility.HtmlEncode(bodyModel.Societes[0].ToString().Replace(" ", "+")));
                filter = true;
                if (bodyModel.Etablissements.Count<string>() == 1)
                {
                    sb.AppendFormat("&rp:Etablissement={0}", HttpUtility.HtmlEncode(bodyModel.Etablissements[0].ToString().Replace(" ","+")));
                }
            }

            if (!filter && (bodyModel.Divisions.Count<string>() == 1))
            {
                sb.AppendFormat("&rp:Division={0}", HttpUtility.HtmlEncode(bodyModel.Divisions[0].ToString()));

                if (bodyModel.DivisionsDetailed.Count<string>() == 1)
                {
                    sb.AppendFormat("&rp:Division_Detaillee={0}", HttpUtility.HtmlEncode(bodyModel.DivisionsDetailed[0].ToString()));
                }
            }

            url = sb.ToString();

            //Excel limit to 256 chars for hyperlink...
            //if (url.Length > 256)
            //{
            //    return String.Format("{0}?rp:Annee={1}&rp:LegalIndicatorTag={2}", baseURL, bodyModel.Year, tag);
            //}

            return url;
        }

        ///// <summary>
        ///// Get Value for specific cell or cell contains text (string and tags)
        ///// </summary>
        ///// <param name="cellValue"> Cell value </param>
        ///// <returns> Value </returns>
        //private static string GetValueForSpecificCell(string cellValue, bool debugMode)
        //{
        //    string defaultValue = string.Empty;
        //    if (!debugMode)
        //    {
        //        defaultValue = "0";
        //    }
        //    if (!string.IsNullOrEmpty(cellValue) && !Regex.IsMatch(cellValue, @"^##") && !Regex.IsMatch(cellValue, @"[$,]"))
        //    {
        //        return cellValue.Replace(TagsConstants.YearN, Properties.FirstOrDefault(x => x.Tag == TagsConstants.YearN).Value).Replace(TagsConstants.YearN1, Properties.FirstOrDefault(x => x.Tag == TagsConstants.YearN1).Value).Replace(TagsConstants.YearN2, Properties.FirstOrDefault(x => x.Tag == TagsConstants.YearN2).Value);
        //    }
        //    return defaultValue;
        //}

    }
}
