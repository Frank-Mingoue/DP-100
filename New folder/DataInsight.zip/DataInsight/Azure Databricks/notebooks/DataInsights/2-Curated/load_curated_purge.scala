// Databricks notebook source
// DBTITLE 1,Include notebook containing functions to connect to adls container, get database url and properties
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

// DBTITLE 1,Delete get_workers parquet files
dbutils.fs.rm("/mnt/curated_container/employee/workday/get_workers",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_carriere parquet files
dbutils.fs.rm("/mnt/curated_container/employee/hra/hra_carriere",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_contrat parquet files
dbutils.fs.rm("/mnt/curated_container/employee/hra/hra_contrat",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_emploi parquet files
dbutils.fs.rm("/mnt/curated_container/employee/hra/hra_emploi",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_enfants parquet files
dbutils.fs.rm("/mnt/curated_container/employee/hra/hra_enfants",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_etp parquet files
dbutils.fs.rm("/mnt/curated_container/employee/hra/hra_etp",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_natio_sec parquet files
dbutils.fs.rm("/mnt/curated_container/employee/hra/hra_natio_sec",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_salaire parquet files
dbutils.fs.rm("/mnt/curated_container/employee/hra/hra_salaire",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_salaries parquet files
dbutils.fs.rm("/mnt/curated_container/employee/hra/hra_salaries",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_suspension parquet files
dbutils.fs.rm("/mnt/curated_container/employee/hra/hra_suspension",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_tempstravail parquet files
dbutils.fs.rm("/mnt/curated_container/employee/hra/hra_tempstravail",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_typeheure parquet files
dbutils.fs.rm("/mnt/curated_container/employee/hra/hra_typeheure",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_cet parquet files
dbutils.fs.rm("/mnt/curated_container/employee/hra/hra_cet",true)

// COMMAND ----------

// DBTITLE 1,Delete pa_histograde parquet files
dbutils.fs.rm("/mnt/curated_container/employee/pa/pa_histograde",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_centrecout parquet files
dbutils.fs.rm("/mnt/curated_container/organization/hra/hra_centrecout",true)

// COMMAND ----------

// DBTITLE 1,Delete sap_cc parquet files
dbutils.fs.rm("/mnt/curated_container/organization/sap/sap_cc",true)

// COMMAND ----------

// DBTITLE 1,Delete action_logement parquet files
dbutils.fs.rm("/mnt/curated_container/pay/business/action_logement",true)

// COMMAND ----------

// DBTITLE 1,Delete eligibilite psb parquet files
dbutils.fs.rm("/mnt/curated_container/pay/business/eligibilite_psb",true)

// COMMAND ----------

// DBTITLE 1,Delete montant_lti parquet files
dbutils.fs.rm("/mnt/curated_container/pay/business/montant_lti",true)

// COMMAND ----------

// DBTITLE 1,Delete montant prime objectif theorique parquet files
dbutils.fs.rm("/mnt/curated_container/pay/business/montant_prime_objectif_theorique",true)

// COMMAND ----------

// DBTITLE 1,Delete percol_peb_ccb parquet files
dbutils.fs.rm("/mnt/curated_container/pay/business/percol_peb_ccb",true)

// COMMAND ----------

// DBTITLE 1,Delete voiture_mobilite parquet files
dbutils.fs.rm("/mnt/curated_container/pay/business/politique_voiture_mobilite",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_rubr_paie parquet files
dbutils.fs.rm("/mnt/curated_container/pay/hra/hra_rubr_paie",true)

// COMMAND ----------

// DBTITLE 1,Delete hra_paie parquet files
dbutils.fs.rm("/mnt/curated_container/pay/hra/hra_paie",true)

// COMMAND ----------

// DBTITLE 1,Delete sap_natures_comptables parquet files
dbutils.fs.rm("/mnt/curated_container/pay/sap/sap_natures_comptables",true)

// COMMAND ----------

// DBTITLE 1,Delete absprev parquet files
dbutils.fs.rm("/mnt/curated_container/absenteism/gestor/absprev",true)

// COMMAND ----------

// DBTITLE 1,Delete codeevt parquet files
dbutils.fs.rm("/mnt/curated_container/absenteism/gestor/codeevt",true)

// COMMAND ----------

// DBTITLE 1,Delete compteurj parquet files
dbutils.fs.rm("/mnt/curated_container/absenteism/gestor/compteurj",true)

// COMMAND ----------

// DBTITLE 1,Delete compteurs parquet files
dbutils.fs.rm("/mnt/curated_container/absenteism/gestor/compteurs",true)

// COMMAND ----------

// DBTITLE 1,Delete Detchamps parquet files
dbutils.fs.rm("/mnt/curated_container/absenteism/gestor/detchamps",true)

// COMMAND ----------

// DBTITLE 1,Delete indicateurs parquet files
dbutils.fs.rm("/mnt/curated_container/absenteism/gestor/indicateurs",true)

// COMMAND ----------

// DBTITLE 1,Delete PersoDroit parquet files
dbutils.fs.rm("/mnt/curated_container/absenteism/gestor/perso_droit",true)

// COMMAND ----------

// DBTITLE 1,Delete PersoDroitJ parquet files
dbutils.fs.rm("/mnt/curated_container/absenteism/gestor/perso_droitj",true)

// COMMAND ----------

// DBTITLE 1,Delete Referentiel 
dbutils.fs.rm("/mnt/curated_container/absenteism/business/referentiel_absences",true)

// COMMAND ----------

// DBTITLE 1,Delete Organisation CHANEL Italie parquet files
dbutils.fs.rm("/mnt/curated_container/organization/business/organisation_chanel_italie",true)

// COMMAND ----------

// DBTITLE 1,Delete business Rubriques Paie parquet files
dbutils.fs.rm("/mnt/curated_container/pay/business/rubriques_paie",true)

// COMMAND ----------

// DBTITLE 1,Delete AG Etablissement parquet files
dbutils.fs.rm("/mnt/curated_container/pay/business/ag_etablissement",true)

// COMMAND ----------

// DBTITLE 1,Delete Histo Grade
dbutils.fs.rm("/mnt/curated_container/employee/workday/histo_grade",true)

// COMMAND ----------

// DBTITLE 1,Delete Histo Job Pofile 
dbutils.fs.rm("/mnt/curated_container/employee/workday/histo_job_profile",true)

// COMMAND ----------

// DBTITLE 1,Delete histo Management Level
dbutils.fs.rm("/mnt/curated_container/employee/workday/histo_management_level",true)

// COMMAND ----------

// DBTITLE 1,Delete Histo site
dbutils.fs.rm("/mnt/curated_container/employee/workday/histo_site",true)

// COMMAND ----------

// DBTITLE 1,Delete Job requisition
dbutils.fs.rm("/mnt/curated_container/recruitment/workday/get_job_requisitions",true)

// COMMAND ----------

// DBTITLE 1,Delete Job Postings
dbutils.fs.rm("/mnt/curated_container/recruitment/workday/get_jobpostings",true)

// COMMAND ----------

// DBTITLE 1,Delete Candidates
dbutils.fs.rm("/mnt/curated_container/recruitment/workday/get_candidates",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_carriere parquet files
dbutils.fs.rm("/mnt/curated_container/employee/adp/adp_carriere",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_contrat parquet files
dbutils.fs.rm("/mnt/curated_container/employee/adp/adp_contrat",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_emploi parquet files
dbutils.fs.rm("/mnt/curated_container/employee/adp/adp_emploi",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_enfants parquet files
dbutils.fs.rm("/mnt/curated_container/employee/adp/adp_enfants",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_etp parquet files
dbutils.fs.rm("/mnt/curated_container/employee/adp/adp_etp",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_natio_sec parquet files
dbutils.fs.rm("/mnt/curated_container/employee/adp/adp_natio_sec",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_salaire parquet files
dbutils.fs.rm("/mnt/curated_container/employee/adp/adp_salaire",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_salaries parquet files
dbutils.fs.rm("/mnt/curated_container/employee/adp/adp_salaries",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_suspension parquet files
dbutils.fs.rm("/mnt/curated_container/employee/adp/adp_suspension",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_tempstravail parquet files
dbutils.fs.rm("/mnt/curated_container/employee/adp/adp_tempstravail",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_typeheure parquet files
dbutils.fs.rm("/mnt/curated_container/employee/adp/adp_typeheure",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_cet parquet files
dbutils.fs.rm("/mnt/curated_container/employee/adp/adp_cet",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_centrecout parquet files
dbutils.fs.rm("/mnt/curated_container/organization/adp/adp_centrecout",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_rubr_paie parquet files
dbutils.fs.rm("/mnt/curated_container/pay/adp/adp_rubr_paie",true)

// COMMAND ----------

// DBTITLE 1,Delete adp_paie parquet files
dbutils.fs.rm("/mnt/curated_container/pay/adp/adp_paie",true)