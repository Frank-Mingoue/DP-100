// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source system, object name and entity
val source_folder = dbutils.widgets.get("source_folder");
val dest_folder = dbutils.widgets.get("dest_folder");
val last_load_date = dbutils.widgets.get("last_load_date");
val runid = dbutils.widgets.get("runid");
val partition_column = dbutils.widgets.get("partition_column").replace(" ","").split(",").toSeq;
val file_extension = dbutils.widgets.get("file_extension");
val file_separator = dbutils.widgets.get("file_separator");

// COMMAND ----------

// DBTITLE 1,Include notebook containing functions to read directory and process files inside the directory
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// MAGIC %run /DataInsights/1-Raw/get_file_structure

// COMMAND ----------

spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

// COMMAND ----------

// DBTITLE 1,Define variables to read csv files from source and write parquet files to destination
//get object_name
val object_name = getvalueposition(source_folder,1, "/")

//build the path to read raw data
val source_path = get_container("raw") + "/" + source_folder

//define vaaiable for file extension to read
val extension = file_extension

//define variable for row separator
val delimiter = file_separator

//build the folder to write on curated data
val dest_path = get_container("curated") + "/" + dest_folder

val file_schema = get_file_structure(object_name)


// COMMAND ----------

// DBTITLE 1,Get the list of directories to read uploaded since the last_load_date
var strDirectories = List[String]() //Set an empty list of string to store the files list
strDirectories = getdirectories(source_path,last_load_date).filter(_ != null).sortWith(_ < _)

// COMMAND ----------

// DBTITLE 1,Read all the files in the list parse each row in each file, insert file in the curated layer and set a summary for read, inserted and rejected records
var read_records  =  0 //init number of read records
var rejected_records  = 0 //init number of rejected records
var inserted_records  = 0 //init number of inserted records
var return_value = "" // init return value
var message="" //init message to return
var num_partitions=""
var last_load_file = ""

/**************loop on each file in the list**********************/

//Test if the files list is empty
if(strDirectories.isEmpty)
{
  last_load_file = last_load_date
  message = "WAR-10 - the directory raw/" + source_folder + " is empty or doesn't exist or the file extension is not csv"
  return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + rejected_records + ";message:" + message

}

//Test if the schema of object name is empty
if(file_schema==null)
{
  last_load_file = last_load_date
  message = message + "ERR-11 the schema of the file " + object_name + " is not defined"
  return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + rejected_records + ";message:" + message
}

else
{
  /**************loop on each file in the list**********************/
  for(d <- strDirectories) {
    if(!isEmptyFolder(d,extension))
    {
      println(d)
      var filenameDF = spark.read.format(extension) 
                  .option("sep", delimiter)
                  .option("header", "true")
                  .option("quote", "\"")
                  .option("escape", "\"")
                  .option("multiline",true)
                  .load(d+"/*")
                  .withColumn("filepath", input_file_name())
    
    //Test if dataframe contains data
    if(filenameDF.isEmpty)
    {
      last_load_file = last_load_date
      message = message + "ERR-12 the filenames in directory " + d + " is empty;"
    }
    
    
    else
    {
      filenameDF.cache() // put the dataframe in the cache
      read_records = read_records + filenameDF.count().toInt //increment the number of read dat

      //Calculate the size of file
      var size = calcRDDSize(filenameDF.rdd.map(_.toString()))

      //Define the number of partitions to write
      num_partitions = scala.math.round(size*(9.31*scala.math.pow(10, -10))).toString

      if(num_partitions < "1") { num_partitions="1" } //if the variable num_paritions is 0 => we should write one partiton

      //specify the shuffle of partitions
      sqlContext.setConf("spark.sql.shuffle.partitions", num_partitions)
    
  
      //parse each row in the file by skipping the column filepath on header check
      var df_read_records = parse_file(filenameDF,delimiter,extension,file_schema,"filepath") 

 
      var date_raw_load_file = getvalueposition(d,5,"/") + getvalueposition(d,6,"/") + getvalueposition(d,7,"/") //get the file generation date on the filename

      
    
      /**************Filter on rows to insert and add some metadata columns**********************/
      var df_inserted_records = df_read_records.filter(df_read_records("error_log") === "")
                          .drop("error_log") //drop the error_log column created during the file parsing
      /**************write the file in the destination filet**********************/
      if (df_inserted_records.count().toInt > 0)
      {
         last_load_file = date_raw_load_file  //date of last file loaded
        
         df_inserted_records = get_dataframe_schema(df_inserted_records,file_schema)        
                              .withColumn("version",split($"filepath","/").getItem(8).cast("integer")) //add column for the version
                              .withColumn("date_raw_load_file",to_date(concat(split($"filepath","/").getItem(5), split($"filepath","/").getItem(6), split($"filepath","/").getItem(7)),"yyyyMMdd")) // add column for the file generation
                              .withColumn("filename",split($"filepath","/").getItem(9)) // add column for the filename
                              .withColumn("curated_ingested_date",current_timestamp()) //add column for the ingestion date
                              .withColumn("runid",lit(runid)) //add column for the ingestion date
                              .withColumn("year_file",split($"filepath","/").getItem(5).cast("integer")) //add column year of the file generation date
                              .withColumn("month_file",split($"filepath","/").getItem(6).cast("integer")) //add column month of the file generation date
                              .withColumn("day_file",split($"filepath","/").getItem(7).cast("integer")) //add column day of the file generation date*/

        df_inserted_records.cache() // put the dataframe in the cache
        inserted_records = inserted_records + df_inserted_records.count().toInt //increment the number of inserted data

        //wrie into adls
        writeadls(df_inserted_records,dest_path,object_name,"parquet","overwrite", partition_column ) 
     }   

   
    
     /**************Filter on rows to reject and add some metadata columns**********************/
      var df_rejected_records = df_read_records.filter(df_read_records("error_log") =!= "") 

       if (df_rejected_records.count().toInt > 0)
       {
          var df_rejected_records = df_read_records.filter(df_read_records("error_log") =!= "") // get records where column error_log is not empty 
                                    .withColumn("version",split($"filepath","/").getItem(8).cast("integer")) //add column for the version
                                    .withColumn("date_raw_load_file",to_date(concat(split($"filepath","/").getItem(5), split($"filepath","/").getItem(6), split($"filepath","/").getItem(7)),"yyyyMMdd")) // add column for the file generation
                                    .withColumn("filename",split($"filepath","/").getItem(9)) // add column for the filename
                                    .withColumn("curated_ingested_date",current_timestamp()) //add column for the ingestion date
                                    .withColumn("runid",lit(runid)) //add column for the ingestion date
                                    .withColumn("year_file",split($"filepath","/").getItem(5).cast("integer")) //add column year of the file generation date
                                    .withColumn("month_file",split($"filepath","/").getItem(6).cast("integer")) //add column month of the file generation date
                                    .withColumn("day_file",split($"filepath","/").getItem(7).cast("integer")) //add column day of the file generation date*/

         df_rejected_records.cache() // put the dataframe in the cache
         rejected_records = rejected_records + df_rejected_records.count().toInt //increment the number of inserted data 

         
         /**************write the erro file in the destination filet**********************/
         var error_object_name = object_name + "/rejected"
         writeadls(df_rejected_records,dest_path ,error_object_name,"parquet","overwrite" , partition_column)
      }

   
    // df_inserted_data.select("filepath","version","date_raw_load_file","filename","curated_ingested_date").show()


    //remove dataframe from cache
    df_read_records.unpersist
    df_rejected_records.unpersist
    df_inserted_records.unpersist
    filenameDF.unpersist
  
   } 
    } 
    else
    {
      message = message + "ERR-12 the directory " + d + " is empty;"
    }
  }
 /**************set up the return value with the number of lines read, rejected and inserted**********************/
  if(last_load_file.isEmpty==true || last_load_file=="")
  {
    last_load_file = last_load_date
  }
 /*************messsage********************/
  if(rejected_records>0)
  {
    message = message + "ERR-13 file or some lines have been rejected due to mismathing between column type and values or bad file header structure or mandatory columns are empty;"
  }
  
 return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + rejected_records + ";message:" + message +";last_load_file:" + last_load_file
}

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)

// COMMAND ----------

spark.sql("MSCK REPAIR TABLE employee.get_workers_rejected")