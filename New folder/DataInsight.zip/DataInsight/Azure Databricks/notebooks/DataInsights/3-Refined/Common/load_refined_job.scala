// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include Notebook Containing Common Functions and Librairies
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Refresh table get_workers
if(spark.catalog.tableExists("employee.get_workers")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.get_workers")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source after test if it exists and count number of read records
val byjob_code = Window.partitionBy("employee_id","france_payroll_id","job_title","management_level","professional_category_reference","job_profile_reference").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_job_read = spark.table("employee.get_workers").filter("date_raw_load_file = '" + load_date + "'")
                                                     .withColumn("rank",rank() over byjob_code).filter(col("rank")==="1")   
                                                     .withColumn("employee_code",concat_ws("|",$"employee_id",$"france_payroll_id"))//read parquet file
df_job_read.createOrReplaceTempView("vw_job") // create a temp view
df_job_read.cache()  //put the dataframe ont he cache


// COMMAND ----------

// DBTITLE 1,Read Grade Data
val bygrade_code = Window.partitionBy("employee_id","france_payroll_id","grade").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_grade_read = spark.table("employee.get_workers").filter("date_raw_load_file = '" + load_date + "'")
                                                     .withColumn("rank",rank() over byjob_code).filter(col("rank")==="1")  
                                                     .withColumn("employee_code",concat_ws("|",$"employee_id",$"france_payroll_id"))//read parquet file
df_grade_read.createOrReplaceTempView("vw_grade") // create a temp view
df_grade_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Query to select only job data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select distinct 
                             getconcatenedstring(array ( lower(j.job_title)
                                                             ,g.grade
                                                             ,j.management_level
                                                             ,j.professional_category_reference
                                                             ,j.job_profile_reference)) as job_key
                            ,sha2(getconcatenedstring(array(
                                                             lower(j.job_title)
                                                            ,g.grade
                                                            ,j.management_level
                                                            ,j.job_profile_reference)),256) as job_code
                            
                            ,max(upper(j.job_title)) as job_title
                            ,g.grade
                            ,max(g.grade_label) as grade_label                
                            ,j.management_level
                            ,max(j.management_level_label) as management_level_label
                            ,j.professional_category_reference
                            ,max(j.professional_category_name) as professional_category_name
                            ,max(j.job_profile_name) as job_profile_name
                            ,j.job_profile_reference
                            ,max(j.job_profile_reference_label) as job_profile_reference_label
                            ,max(j.job_category) as job_category
                            ,max(j.job_family) as job_family
                            ,max(j.job_family_group) as job_family_group
                            ,max(j.version) as version
                            ,max(j.date_raw_load_file) as date_raw_load_file
                            ,max(j.filepath) as filepath
                            ,max(j.filename) as filename
                            ,max(j.curated_ingested_date) as curated_ingested_date
                            ,true as current_record
                            ,max(j.date_raw_load_file) as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(                                                            
                                                             max(g.grade_label)
                                                            ,max(j.management_level_label)
                                                            ,max(j.professional_category_name)
                                                            ,max(j.job_profile_name)
                                                            ,max(j.job_profile_reference_label)
                                                            ,max(j.job_category)
                                                            ,max(j.job_family)
                                                            ,max(j.job_family_group)
                                                           )) as hashkey 
                           ,'""" + runid + """' as runid
                           ,lower(trim(split(max(j.filepath),"/")[3])) as system_source
               from    vw_job j
                       inner join vw_grade g on j.employee_code = g.employee_code
               where   1=1
                 and   (j.job_title is not null or g.grade is not null or j.coefficient is not null or j.management_level is not null or j.job_profile_reference is not null )
               
               group by  lower(j.job_title)
                        ,g.grade
                        ,j.management_level
                        ,j.professional_category_reference
                        ,j.job_profile_reference
               """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source).cache

// COMMAND ----------

// DBTITLE 1,Refresh table Common Job
if(spark.catalog.tableExists("common.job")) 
{ 
try {
    spark.sql("FSCK REPAIR TABLE common.job")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the table job after drop the table if exists and store data and table structure on job_table
val job_table = DeltaTable.forName("common.job")
job_table.toDF.count

// COMMAND ----------

// DBTITLE 1,Rows for job updated
val newjob = df_results.as("job_updated")
  .join(job_table.toDF.as("job"), Seq("job_key"))
  .where("""job.current_record = true and (job_updated.hashkey <> job.hashkey) and job_updated.date_raw_load_file >= job.date_raw_load_file """)

// COMMAND ----------

// DBTITLE 1,Union of dataframes between jobs updated from existing employees and new jobs from new employees
// Stage the update by unioning two sets of rows
// 1. Rows that will be inserted in the `whenNotMatched` clause
// 2. Rows that will either UPDATE the current contracts of existing employees or insert the new contracts of new employees
val job_upsert = newjob
  .selectExpr("null as mergekey", "job_updated.*")    // Rows for 1.
  .union(
    df_results.as("df_results").selectExpr("df_results.job_key as mergekey","*")  // Rows for 2.
  )
//remove duplicate
val job_upsert_distinct = job_upsert.distinct()

// COMMAND ----------

// DBTITLE 1,Merge on table Job
job_table.alias("t")
  .merge(
    job_upsert_distinct.alias("s"),
    """ t.job_key = s.mergekey """)

  .whenMatched("""t.current_record = true and (t.hashkey <> s.hashkey) and s.date_raw_load_file >= t.date_raw_load_file """)
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "case when date_add(s.record_start_date,-1)< t.record_start_date then t.record_start_date else date_add(s.record_start_date,-1) end ",
    "record_modification_date" -> "s.record_modification_date",
    "runid" -> "s.runid")
  )
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE common.job")

// COMMAND ----------

// DBTITLE 1,Get Statistics
val read_records = df_job_read.count().toInt //count the number of read records
val inserted_records = job_upsert_distinct.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update common.job 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_job_read.unpersist
df_grade_read.unpersist
df_results.unpersist

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)