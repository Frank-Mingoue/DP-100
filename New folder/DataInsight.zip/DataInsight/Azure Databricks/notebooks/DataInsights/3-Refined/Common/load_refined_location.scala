// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include notebook containing common functions and librairies
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Refresh Table get_workers
if(spark.catalog.tableExists("employee.get_workers")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.get_workers")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source and count number of read records
val bylocation = Window.partitionBy("location").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc, $"location_code".desc)
val df_location_read = spark.table("employee.get_workers").filter("date_raw_load_file = '" + load_date + "'")
                                                          .withColumn("rank",rank() over bylocation).filter(col("rank")==="1")   //read parquet file
df_location_read.createOrReplaceTempView("vw_location") // create a temp view
df_location_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Query to select only location data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select distinct 
                            l.location as location_key
                            ,sha2(getconcatenedstring(array(l.location,l.location_type)), 256) as location_code
                            ,l.location
                            ,l.location_type           
                            ,coalesce(l.location_country,'NC') as location_country
                            ,coalesce(l.location_code, 'NC') as location_reference
                            ,l.version
                            ,l.date_raw_load_file
                            ,l.filepath
                            ,l.filename
                            ,l.curated_ingested_date
                            ,true as current_record
                            ,l.date_raw_load_file as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array( l.location_type           
                                                       ,coalesce(l.location_country,'NC')
                                                       ,coalesce(l.location_code, 'NC')
                                                           )) as hashkey 
                           ,'""" + runid + """' as runid
                           ,lower(trim(split(l.filepath,"/")[3])) as system_source
               from    vw_location l
               where   1=1
                 and   l.location is not null"""

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source).cache

// COMMAND ----------

// DBTITLE 1,Refresh Table Location
if(spark.catalog.tableExists("common.location")) 
{ 
try {
    spark.sql("FSCK REPAIR TABLE common.location")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the table location after drop the table if exists and store data and table structure on location_table
val location_table = DeltaTable.forName("common.location")

// COMMAND ----------

// DBTITLE 1,Rows for location updated
val newlocation = df_results.as("location_updated")
  .join(location_table.toDF.as("location"), Seq("location_key"))
  .where("""location.current_record = true and (location_updated.hashkey <> location.hashkey) and location_updated.date_raw_load_file >= location.date_raw_load_file """)

// COMMAND ----------

// DBTITLE 1,Union of dataframes between location updated from existing employees and new jobs from new employees
// Stage the update by unioning two sets of rows
// 1. Rows that will be inserted in the `whenNotMatched` clause
// 2. Rows that will either UPDATE the current contracts of existing employees or insert the new contracts of new employees
val location_upsert = newlocation
  .selectExpr("null as mergekey", "location_updated.*")   // Rows for 1.
  .union(
    df_results.as("df_results").selectExpr("df_results.location_key as mergekey","*")  // Rows for 2.
  )
//remove duplicate
val location_upsert_distinct = location_upsert.distinct()

// COMMAND ----------

// DBTITLE 1,Merge on table location
location_table.alias("t")
  .merge(
    location_upsert_distinct.alias("s"),
    """ t.location_key = s.mergekey """)
  .whenMatched("""t.current_record = true and (t.hashkey <> s.hashkey) and  s.date_raw_load_file >= t.date_raw_load_file """)
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "case when date_add(s.record_start_date,-1)< t.record_start_date then t.record_start_date else date_add(s.record_start_date,-1) end ",
    "record_modification_date" -> "s.record_modification_date",
    "runid" -> "s.runid")
  )
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE common.location")

// COMMAND ----------

// DBTITLE 1,Get Statistics
val read_records = df_location_read.count().toInt //count the number of read records
val inserted_records = location_upsert_distinct.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_location_read.unpersist
df_results.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update common.location 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)