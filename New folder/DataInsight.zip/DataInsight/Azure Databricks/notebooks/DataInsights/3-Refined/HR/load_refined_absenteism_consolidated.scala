// Databricks notebook source
// DBTITLE 1,Get Parameters
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Import Librairies and Functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.sql.execution.arrow.enabled","true")


// COMMAND ----------

// MAGIC %md ##1 - Read Data

// COMMAND ----------

// DBTITLE 1,Refresh table referential absences
if(spark.catalog.tableExists("absenteism.referentiel_absences")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.referentiel_absences")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded
val partition_ref_absences = get_last_partition_file("/absenteism/business/referentiel_absences",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Get referential absence data
val byref_abs = Window.partitionBy("code_absence").orderBy($"filename".desc,$"date_raw_load_file".desc, $"version".desc)
val df_ref_abs_read =  spark.table("absenteism.referentiel_absences").filter("date_raw_load_file = '" + partition_ref_absences + "'")
                                                        .withColumn("rank",rank() over byref_abs)
                                                        .filter(col("rank")==="1")
                                                        .withColumn("absence_code",col("code_absence"))//read parquet file
df_ref_abs_read.createOrReplaceTempView("vw_ref_abs") // create a temp view	
df_ref_abs_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism
if(spark.catalog.tableExists("hr.absenteism")) 
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Read absences data
val df_absenteism_read = spark.table("hr.absenteism").filter("current_record=true")//.filter("type<>9")
                                                     .withColumnRenamed("dateval","dateval_start") 
                                                     .withColumn("old_employee_hra", $"employee_hra")
                                                     .withColumn("employee_hra", substring_index($"employee_hra", "_", 1))

// COMMAND ----------

// MAGIC %md #### Join

// COMMAND ----------

// DBTITLE 1,Get absence with Motif
val window = Window.partitionBy("employee_hra").orderBy($"dateval_start".asc)

val df_absenteism_motif = df_absenteism_read.as("e").join(broadcast(df_ref_abs_read),
                              $"code" === $"absence_code","inner")
                                  .select("e.old_employee_hra","e.employee_hra","e.dateval_start","e.h_start","e.h_end","e.code","e.duration_days","e.duration_hours","flag_prolongation","e.version","e.date_raw_load_file","e.filepath","e.filename","e.curated_ingested_date","e.type_absence", "type", "e.runid","system_source")
                                    .distinct
                                  
                                  .withColumn("type_absence_new", when($"duration_days"===0,"heure").otherwise($"type_absence"))
                                  .withColumn("date_before_1", lag($"dateval_start", 1, null).over(window))
                                  .withColumn("date_after_1", lead($"dateval_start", 1, null).over(window))  
                                  .withColumn("code_before_1", lag($"code",1,null).over(window))
                                  .withColumn("code_after_1", lead($"code",1,null).over(window))

                                  .withColumn("type_absence_new_before_1", lag($"type_absence_new",1,null).over(window))
                                  .withColumn("type_absence_new_after_1", lead($"type_absence_new",1,null).over(window))

                                  .withColumn("flag_prolongation",when($"flag_prolongation"==="Oui",1).otherwise(0))
                                  .withColumn("days", date_format(col("dateval_start"), "EEEE"))
                                  .withColumn("h_code_2",concat_ws("|",$"h_start",$"h_end"))
                                  .withColumn("h_code",sha2($"h_code_2",256))
                                  .withColumn("duration_hours_old", $"duration_hours")
                                  .withColumn("duration_hours", when($"duration_days" === 0 && $"duration_hours" > 7, 7).otherwise($"duration_hours"))

// COMMAND ----------

// MAGIC %md #### 2- Transform Data - Start - Nothing - end

// COMMAND ----------

// DBTITLE 1,Build for each employee, absence by classifying by absence and date absence
val window = Window.partitionBy("employee_hra").orderBy($"dateval_start")
val window2 = Window.partitionBy("employee_hra","code","group_rank_of_ID").orderBy($"dateval_start")

val df_absenteism_motif_2 = df_absenteism_motif.withColumn("flag",
                                               //first row
                                               when($"code_before_1".isNull and $"type_absence_new" =!= "heure"
                                                    ,"start")
                                                           
                                               .when($"code" === $"code_before_1" and 
                                                     $"code" === $"code_after_1" and 
                                                     $"type_absence_new" === $"type_absence_new_before_1" and 
                                                     $"type_absence_new" === $"type_absence_new_after_1" and
                                                     date_add($"dateval_start",1) === $"date_after_1" and
                                                     date_add($"dateval_start",-1) === $"date_before_1" and $"type_absence_new" =!= "heure"
                                                     ,"nothing")
                                                           
                                               .when($"code" =!= $"code_before_1",
                                                    "start")
                                               
                                               .when($"code" === $"code_before_1"
                                                     and $"type_absence_new" =!= $"type_absence_new_before_1" and $"type_absence_new" =!= "heure",
                                                    "start")
                                                           
                                               .when($"flag_prolongation"===1 and
                                                    $"code" === $"code_after_1" and $"type_absence_new" =!= "heure"
                                                    ,"nothing")
                                                           
                                               .when($"flag_prolongation"===1 and $"type_absence_new" =!= "heure",
                                                    "end")
                                                           
                                               .when($"code" === $"code_before_1" and
                                                    date_add($"dateval_start",-1) =!= $"date_before_1" and $"type_absence_new" =!= "heure",
                                                    "start")
                                                           
                                               .when($"code" === $"code_before_1" and
                                                    date_add($"dateval_start",-1) === $"date_before_1" and
                                                    $"type_absence_new" =!= $"type_absence_new_before_1" and $"type_absence_new" =!= "heure",
                                                    "start" )
                                                           
                                               .when($"code" === $"code_before_1" and
                                                     $"code" =!= $"code_after_1" and
                                                    date_add($"dateval_start",-1) === $"date_before_1" and $"type_absence_new" =!= "heure",
                                                    "end")
                                               
                                               .when($"code" === $"code_before_1" and
                                                     $"code" === $"code_after_1" and
                                                     $"type_absence_new" === $"type_absence_new_before_1" and
                                                     $"type_absence_new" =!= $"type_absence_new_after_1" and
                                                    date_add($"dateval_start",-1) === $"date_before_1" and $"type_absence_new" =!= "heure",
                                                    "end")
                                                           
                                                           
                                               .when($"code" === $"code_before_1" and
                                                     $"code" === $"code_after_1" and
                                                     $"type_absence_new" === $"type_absence_new_before_1" and
                                                     $"type_absence_new" === $"type_absence_new_after_1" and
                                                     date_add($"dateval_start",-1) === $"date_before_1" and
                                                     date_add($"dateval_start",1) =!= $"date_after_1" and $"type_absence_new" =!= "heure",
                                                    "end")
                                                           
                                               .when($"code" =!= $"code_before_1" and
                                                     $"code" =!= $"code_after_1" and $"type_absence_new" =!= "heure",
                                                    "start") 
                                               
                                               .when($"code" =!= $"code_before_1" and
                                                     $"code" =!= $"code_after_1" and
                                                     $"type_absence_new" =!= $"type_absence_new_before_1" and
                                                     $"type_absence_new" =!= $"type_absence_new_after_1" and $"type_absence_new" =!= "heure",
                                                    "start")
                                                           
                                               .when($"code_after_1".isNull and
                                                    $"code" === $"code_before_1" and
                                                    $"type_absence_new" === $"type_absence_new_before_1" and 
                                                    date_add($"dateval_start",-1) === $"date_before_1" and $"type_absence_new" =!= "heure",
                                                    "end")
                                               .otherwise("start"))

                                        //compute duree
                                        .withColumn("flag_after_1",lead($"flag",1,null).over(window))
                                        .withColumn("group",when($"flag" =!= "start", true))
                                    // .withColumn("group2",when($"flag_after_1"==="nothing",lead($"group",1).over(window)).otherwise($"group"))
                                      //define unique situation
                                        .withColumn("group_rank_of_ID",sum(when($"group",lit(0)).otherwise(lit(1))).over(window))

val df_absenteism_motif_duree   =  df_absenteism_motif_2
                              .withColumn("duration_days",sum($"duration_days").over(window2))
                              .withColumn("duration_hours",sum($"duration_hours").over(window2))
                            //drop columns
                            .drop("date_before_1","date_after_1","code_before_1","code_after_1","flag_after_1","group","group_rank_of_ID")
                            .distinct

// COMMAND ----------

// DBTITLE 1,Set the dates for absence and build the id absence
val window = Window.partitionBy("employee_hra","type_absence").orderBy($"dateval_start".asc)

val byDateValStart  = Window.partitionBy("employee_hra","id_absence").orderBy($"dateval_start".asc)
val byDateValEnd  = Window.partitionBy("employee_hra","id_absence").orderBy($"dateval_end".desc)


val df_absenteism_filter =df_absenteism_motif_duree.where($"flag"=!="nothing")
                                .withColumn("flag_1", lead($"flag", 1, null).over(window))
                                .withColumn("dateval_end",when ($"flag_1"==="end",lead($"dateval_start",1,null).over(window)).otherwise($"dateval_start"))
                                .withColumn("duration_days_2",when($"flag_1"==="end", lead($"duration_days",1,null).over(window)).otherwise($"duration_days"))
                                .withColumn("duration_hours_2",when($"flag_1"==="end", lead($"duration_hours",1,null).over(window)).otherwise($"duration_hours"))
                                .where($"flag"==="start")                      

                                .withColumn("code_pro_before_1",when($"flag_prolongation"===1, lag($"code",1,null).over(window)).otherwise($"code"))

                                .withColumn("code_pro_before_2", when($"flag_prolongation"===1 and lag($"flag_prolongation",1,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"code",1,null).over(window))
                                                                .when($"flag_prolongation"===1 and lag($"flag_prolongation",2,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"code",2,null).over(window))
                                                                .when($"flag_prolongation"===1 and lag($"flag_prolongation",3,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"code",3,null).over(window))
                                                                .when($"flag_prolongation"===1 and lag($"flag_prolongation",4,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"code",4,null).over(window))
                                                                .when($"flag_prolongation"===1 and lag($"flag_prolongation",5,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"code",5,null).over(window))
                                                                .when($"flag_prolongation"===1 and lag($"flag_prolongation",6,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"code",6,null).over(window))
                                                                .when($"flag_prolongation"===1 and lag($"flag_prolongation",7,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"code",7,null).over(window))
                                                                .when($"flag_prolongation"===1 and lag($"flag_prolongation",8,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"code",8,null).over(window))
                                                                .when($"flag_prolongation"===1 and lag($"flag_prolongation",9,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"code",9,null).over(window))
                                                                .when($"flag_prolongation"===1 and lag($"flag_prolongation",10,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"code",10,null).over(window))                                           
                                                                .otherwise($"code"))                                 

                                .withColumn("dateval_pro_before_code_1",when($"flag_prolongation"===1, lag($"dateval_start",1,null).over(window)).otherwise($"dateval_start"))
                                
                                .withColumn("dateval_pro_before_code_2", when($"flag_prolongation"===1 and lag($"flag_prolongation",1,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"dateval_start",1,null).over(window))
                                                                        .when($"flag_prolongation"===1 and lag($"flag_prolongation",2,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"dateval_start",2,null).over(window))
                                                                        .when($"flag_prolongation"===1 and lag($"flag_prolongation",3,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"dateval_start",3,null).over(window))
                                                                        .when($"flag_prolongation"===1 and lag($"flag_prolongation",4,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"dateval_start",4,null).over(window))
                                                                        .when($"flag_prolongation"===1 and lag($"flag_prolongation",5,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"dateval_start",5,null).over(window))
                                                                        .when($"flag_prolongation"===1 and lag($"flag_prolongation",6,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"dateval_start",6,null).over(window))
                                                                        .when($"flag_prolongation"===1 and lag($"flag_prolongation",7,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"dateval_start",7,null).over(window))
                                                                        .when($"flag_prolongation"===1 and lag($"flag_prolongation",8,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"dateval_start",8,null).over(window))
                                                                        .when($"flag_prolongation"===1 and lag($"flag_prolongation",9,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"dateval_start",9,null).over(window))
                                                                        .when($"flag_prolongation"===1 and lag($"flag_prolongation",10,null).over(window) === 0 and datediff($"dateval_start", lag($"dateval_end",1,null).over(window)) === 1, lag($"dateval_start",10,null).over(window))
                                            
                                                                        .otherwise($"dateval_start")) 

                                .withColumn("dateval_start_prol",when(($"flag_prolongation"===1 || $"flag_prolongation"===0) && lead($"flag_prolongation",1,null).over(window) === 1 && datediff(lead($"dateval_start",1,null).over(window),$"dateval_end") === 1, lead($"dateval_start",1,null).over(window)))
                                .withColumn("dateval_end_prol",when(($"flag_prolongation"===1 || $"flag_prolongation"===0) && lead($"flag_prolongation",1,null).over(window) === 1 && datediff(lead($"dateval_start",1,null).over(window),$"dateval_end") === 1, lead($"dateval_end",1,null).over(window)))

                                .withColumn("id_absence",concat_ws("|",$"employee_hra",$"code_pro_before_2",$"dateval_pro_before_code_2"))
                                .withColumn("id_absence_2",concat_ws("|",$"employee_hra",$"code_pro_before_2",$"dateval_pro_before_code_2",$"code"))
                                
                                .withColumn("dateval_start_prol_first",when($"dateval_start_prol".isNotNull,first($"dateval_start").over(byDateValStart))
                                                                      .when($"flag_prolongation"===1 && (lag($"dateval_start_prol",1,null).over(window)).isNotNull,first($"dateval_start").over(byDateValStart))
                                                                      .otherwise(null))
                                .withColumn("dateval_end_prol_last", when($"dateval_end_prol".isNotNull ,first($"dateval_end").over(byDateValEnd))
                                                                    .when($"flag_prolongation"===1 && (lag($"dateval_start_prol",1,null).over(window)).isNotNull,first($"dateval_end").over(byDateValEnd))
                                                                    .otherwise(null))

                                .drop("duration_days")
                                .drop("duration_hours")
                                .withColumnRenamed("duration_days_2","duration_days")
                                .withColumnRenamed("duration_hours_2","duration_hours")
                                .withColumn("duration_days_abs", $"duration_days")
                                .withColumn("dates_code",sha2(concat_ws("|",$"dateval_start",$"dateval_end"
                                                                           ,$"dateval_start_prol"
                                                                           ,$"dateval_end_prol"
                                                                           ,$"dateval_start_prol_first"
                                                                           ,$"dateval_end_prol_last"),256))

                                .withColumn("curated_ingested_date", $"curated_ingested_date".cast(TimestampType)) 

                                .select("old_employee_hra"
                                        ,"employee_hra"
                                        ,"dateval_start"
                                        ,"dateval_end"
                                        ,"dateval_start_prol"
                                        ,"dateval_end_prol"
                                        ,"dateval_start_prol_first"
                                        ,"dateval_end_prol_last"
                                        ,"h_start"
                                        ,"h_end"
                                        ,"code"
                                        ,"duration_days"
                                        ,"duration_days_abs"
                                        ,"duration_hours"
                                        ,"id_absence"
                                        ,"id_absence_2"
                                        ,"h_code"
                                        ,"dates_code"
                                        ,"version"
                                        ,"date_raw_load_file"
                                        ,"filepath"
                                        ,"filename"
                                        ,"curated_ingested_date"
                                        ,"runid"
                                        ,"system_source")
                                  .distinct
                               // .dropDuplicates("id_absence_2")

// COMMAND ----------

// MAGIC %md #### 4- Save Data

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism consolidated
try {
  spark.sql("FSCK REPAIR TABLE hr.absenteism_consolidated")
}
catch {
  case e: FileNotFoundException => println("Couldn't find that file.")
  case e: IOException => println("Had an IOException trying to read that file")
}

// COMMAND ----------

// DBTITLE 1,Write Data on absenteism consolidated
df_absenteism_filter.write.format("delta")
                .mode("overwrite")
                .partitionBy("code")
                .saveAsTable("hr.absenteism_consolidated")

// COMMAND ----------

// DBTITLE 1,Optimize absenteism consolidated
spark.sql("OPTIMIZE hr.absenteism_consolidated")

// COMMAND ----------

// MAGIC %md #### 4- Second Dataset

// COMMAND ----------

// DBTITLE 1,Get Absenteism Consolidated Data
val window = Window.partitionBy("id_absence").orderBy($"dateval_start".asc)
val df_absenteism_filter_uni = df_absenteism_filter.withColumn("dateval_end_2",lead($"dateval_end",1,null).over(window))
                                      .withColumn("duree_prolongation_abs",when($"dateval_end_2".isNotNull, lead($"duration_days_abs",1,null).over(window)+$"duration_days_abs")
                                                  .otherwise($"duration_days_abs"))
                                      .withColumn("dateval_end_2",when($"dateval_end_2".isNull,$"dateval_end").otherwise($"dateval_end_2"))
                                      .drop("duration_days_abs","dateval_end")
                                      .withColumnRenamed("duree_prolongation_abs","duration_days_abs")
                                      .withColumnRenamed("dateval_end_2","dateval_end")
                                      .select("employee_hra","dateval_start","dateval_end","h_start","h_end","h_code","code","duration_days_abs","id_absence",
                                              "id_absence_2","version","date_raw_load_file","filepath","filename","curated_ingested_date")
                                      .dropDuplicates("id_absence")
                                      .withColumn("duration_days_abs",$"duration_days_abs".cast(IntegerType))

// COMMAND ----------

// DBTITLE 1,Refresh Table Absenteism Consolidated Extended
try {
  spark.sql("FSCK REPAIR TABLE hr.absenteism_consolidated_extended")
}
catch {
  case e: FileNotFoundException => println("Couldn't find that file.")
  case e: IOException => println("Had an IOException trying to read that file")
}

// COMMAND ----------

// DBTITLE 1,Write data on absenteism consolidated Extended
df_absenteism_filter_uni.write.format("delta")
                .mode("overwrite")
                .partitionBy("code")
                .saveAsTable("hr.absenteism_consolidated_extended")

// COMMAND ----------

// DBTITLE 1,Optimize absenteism consolidated extended
spark.sql("OPTIMIZE hr.absenteism_consolidated_extended")

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_absenteism_filter_uni.count().toInt //count the number of read records
val return_value = "read_records:" + read_records

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_ref_abs_read.unpersist

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return Value
dbutils.notebook.exit(return_value)