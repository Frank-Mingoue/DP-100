// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include Notebook Containing Common Functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760 ")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Test if the source path exists
if(spark.catalog.tableExists("pay.ag_etablissement")) 
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.ag_etablissement")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val partition_date = get_last_partition_file("/pay/business/ag_etablissement",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source after test if it exists and count number of read records
val byag_etablissement = Window.partitionBy("code_etablissement","year").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)

val df_ag_etablissement_read = spark.table("pay.ag_etablissement")
                                        //.filter("date_raw_load_file = '" + partition_date + "'") 
                                        .withColumn("year", regexp_replace(col("periode"), "-","").substr(0, 4))   //read parquet file
                                        .withColumn("period_month", regexp_replace(col("periode"), "-","").substr(0, 6))   //read parquet file
                                        .withColumn("pourcentage_ag_clean", (regexp_replace($"pourcentage_ag" , "%", "" ))/100)
                                        .withColumn("rank",rank() over byag_etablissement).filter(col("rank")==="1") //path to read parquet files
//read parquet file

df_ag_etablissement_read.cache()  //put the dataframe ont he cache
df_ag_etablissement_read.createOrReplaceTempView("vw_ag_etablissement") // create a temp view

// COMMAND ----------

// DBTITLE 1,Refresh table ag_establishment
if(spark.catalog.tableExists("hr.ag_establishment")) 
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.ag_establishment")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Existing period,year and date_raw_load_file
val ag_establishment_table = DeltaTable.forName("hr.ag_establishment").toDF.select("period_month","year","date_raw_load_file").distinct
ag_establishment_table.createOrReplaceTempView("vw_ag_establishment_table")

// COMMAND ----------

// DBTITLE 1,Query to select only job data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select distinct 
                            getconcatenedstring(array(lower(r.libelle_etablissement)
                                                            ,lower(r.code_etablissement)
                                                            ,r.periode
                                                           )) as ag_establishment_key                  
                            ,r.libelle_etablissement as label_establishment
                            ,r.code_etablissement as code_establishment
                            ,to_date(r.periode)      as  period      
                            ,r.period_month
                            ,r.year
                            ,r.pourcentage_ag_clean as percent_ag
                            ,r.filepath
                            ,r.date_raw_load_file
                            ,r.version
                            ,r.filename
                            ,to_date(r.curated_ingested_date) as curated_ingested_date
                            ,true as current_record
                            ,r.date_raw_load_file as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(r.libelle_etablissement,r.code_etablissement, r.periode)) as hashkey 
                           ,'""" + runid + """' as runid
                           ,lower(trim(split(r.filepath,"/")[3])) as system_source
                   from    vw_ag_etablissement r 
                           left join vw_ag_establishment_table at on at.year = r.year
                   where   1=1
                           and r.code_etablissement is not null
                           and (r.date_raw_load_file > at.date_raw_load_file or at.date_raw_load_file is null)
            
            """

// COMMAND ----------

// DBTITLE 1,Read Data
val df_results = spark.sql(query_source).cache
df_results.createOrReplaceTempView("vw_ag_establishment_source")
val inserted_records = df_results.count().toInt //count the number of records to upsert

// COMMAND ----------

// DBTITLE 1,Delete Old Data
spark.sql( """DELETE FROM hr.ag_establishment as t
WHERE EXISTS(
SELECT 1 FROM vw_ag_establishment_source
WHERE t.year = vw_ag_establishment_source.year)""")

// COMMAND ----------

// DBTITLE 1,Add new data
df_results.write.format("delta")
                .mode("append")
                .partitionBy("year")
                .saveAsTable("hr.ag_establishment")

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE hr.ag_establishment")

// COMMAND ----------

// DBTITLE 1,Statistics on rows read and inserted
val read_records = df_ag_etablissement_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_ag_etablissement_read.unpersist
df_results.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.ag_establishment 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)