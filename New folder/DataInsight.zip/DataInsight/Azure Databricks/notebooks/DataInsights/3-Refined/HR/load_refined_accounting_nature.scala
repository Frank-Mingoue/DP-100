// Databricks notebook source
// DBTITLE 1,Get Parameters: load_date, runid
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include notebooks
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Optimize Spark Query
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.sap_natures_comptables
if(spark.catalog.tableExists("pay.sap_natures_comptables")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE pay.sap_natures_comptables")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Last Partition file loaded for SAP Natures Comptable
val partition_nat_comp = get_last_partition_file("/pay/sap/sap_natures_comptables",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Create the windowing function
val bynat_comp = Window.partitionBy("cost_center_code","wage_type_code").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_nat_comp_read = spark.table("pay.sap_natures_comptables").where($"date_raw_load_file"===partition_nat_comp)
                                                                     .withColumn("rank", rank().over(bynat_comp))
                                                                     .where($"rank"===1)
                                                                     .withColumn("year_month", concat($"year", lpad($"month",2,"0")))
                                                                     .distinct
df_nat_comp_read.createOrReplaceTempView("vw_nat_comp")

// COMMAND ----------

// DBTITLE 1,Refresh Table hr.accounting_nature
  try {
    spark.sql("FSCK REPAIR TABLE hr.accounting_nature")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }

// COMMAND ----------

// DBTITLE 1,Get Existing partitions from table hr.accounting_nature
val accounting_nature_table = DeltaTable.forName("hr.accounting_nature").toDF.select("year_month","date_raw_load_file").distinct
accounting_nature_table.createOrReplaceTempView("vw_accounting_nature_table")

// COMMAND ----------

// DBTITLE 1,Query to select only accounting nature data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select distinct                             
                             getconcatenedstring(array( c.wage_type_code
                                                       ,c.cost_center_code
                                                           )) as accounting_nature_key 
                            ,sha2(getconcatenedstring(array(c.wage_type_code
                                                           ,c.cost_center_code)),256) as accounting_nature_code
                            ,c.wage_type_code 
                            ,c.cost_center_code
                            ,c.country
                            ,c.currency
                            ,c.amount 
                            ,c.month
                            ,c.year
                            ,c.year_month
                            ,c.filename
                            ,c.date_raw_load_file
                            ,c.version
                            ,c.filepath
                            ,to_date(c.curated_ingested_date) as curated_ingested_date
                            ,true as current_record
                            ,c.date_raw_load_file as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(
                                                       c.country
                                                      ,c.currency
                                                      ,c.amount 
                                                      ,c.month
                                                      ,c.year
                                                      )) as hashkey
                            ,'""" + runid + """' as runid
                            ,lower(trim(split(c.filepath,"/")[3])) as system_source

                            from vw_nat_comp c 
                                 left join vw_accounting_nature_table a on a.year_month = c.year_month
               
               where   1 = 1
                 and   c.wage_type_code is not null
                 and   c.cost_center_code is not null
                 and   (c.date_raw_load_file > a.date_raw_load_file or a.date_raw_load_file is null)
                            """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source).cache
df_results.createOrReplaceTempView("vw_df_results")
val inserted_records = df_results.count().toInt //count the number of records to upsert

// COMMAND ----------

// DBTITLE 1,Delete Data where partitions are present in the df_results dataframe
spark.sql("""
delete from hr.accounting_nature as t1
  where exists (select year_month from vw_df_results where t1.year_month = year_month)
""")

// COMMAND ----------

// DBTITLE 1,Overwrite on table account_nature
df_results.write.format("delta")
                .mode("append")
                .partitionBy("year_month")
                .saveAsTable("hr.accounting_nature")

// COMMAND ----------

// DBTITLE 1,Script to optimize hr natures comptables
spark.sql("OPTIMIZE hr.accounting_nature")

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_nat_comp_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0
df_results.unpersist()

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.accounting_nature 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return Value
dbutils.notebook.exit(return_value)