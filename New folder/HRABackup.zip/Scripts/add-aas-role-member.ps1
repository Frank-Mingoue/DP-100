<#
    .Synopsis 
        add-aas-role-member.ps1
    .Description
        function to add a member to a role.
    .Notes
        Connect to AAS Resource and add member to role
    .Parameter Region
        Reference of the region the databricks is in. For example westeurope
    .Parameter ApplicationId
        Azure Active Directory Service Principal Client ID (also known as Application ID)
    .Parameter Secret
        Secret for given Client ID
    .Parameter TenantId
        Tenant Id (Directory ID) for the AAD owning the ApplicationId
	.Parameter AASDatabase
        AAS Database where to add member to role
	.Parameter AASServer
        AAS Server where database is hosted
	.Parameter MemberName
        Member to add to the role
	.Parameter RoleName
        Role where to add memeber
    .Functionality 
        Used to add role member to an existing role
    .Example
        
    #>  

param(
    [Parameter(Mandatory = $false)]
    [String] $Region = "westeurope",
    [Parameter(Mandatory = $false)]
    [String] $SpnId = "",
    [Parameter (Mandatory = $false)]
    [String] $Secret = "",
    [Parameter(Mandatory = $false)]
    [String] $TenantId = "",
	[Parameter(Mandatory = $false)]
    [String] $AASDatabase = "",
	[Parameter(Mandatory = $false)]
    [String] $AASServer = "",
	[Parameter(Mandatory = $false)]
    [String] $MemberName = "",
	[Parameter(Mandatory = $false)]
    [String] $RoleName = ""
)


$RolloutEnvironment = $Region + ".asazure.windows.net"

#Config Credential
$PWord = ConvertTo-SecureString -String $Secret -AsPlainText -Force
$Credential = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $SpnId, $PWord

#Connect to AAS Resource
Login-AzureAsAccount -Credential $Credential -ServicePrincipal -TenantId $TenantId -RolloutEnvironment $RolloutEnvironment

#add role member
Add-RoleMember -MemberName $MemberName -Database $AASDatabase -RoleName $RoleName -server $AASServer -Credential $Credential -ServicePrincipal -TenantId $TenantId



