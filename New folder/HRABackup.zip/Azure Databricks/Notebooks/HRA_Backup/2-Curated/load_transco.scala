// Databricks notebook source
// MAGIC %run ../Include/read_write_parse_file

// COMMAND ----------

//build the path to read raw data
val source_path = get_container("raw") + "/backup_hra"
val dest_path = get_container("curated") + "/backup_hra/common"

// COMMAND ----------

var referentielDF = spark.read.format("csv") 
                  .option("sep", ",")
                  .option("header", "true")
                  .option("quote", "\"")
                  .option("escape", "\"")
                  .load("/mnt/raw_container/backup_hra/common/referentiel.csv")

var referentielTrim = referentielDF
      for(col <- referentielDF.columns){
        referentielTrim = referentielTrim.withColumn(col,trim(referentielDF(col)))
      }

var referentielDistinct = referentielTrim.distinct

// COMMAND ----------

referentielDistinct.createOrReplaceTempView("vw_ref")

// COMMAND ----------

// MAGIC %sql
// MAGIC select count(*)
// MAGIC from vw_ref

// COMMAND ----------

// MAGIC %sql
// MAGIC select repertoire , code, count(*)
// MAGIC from vw_ref 
// MAGIC group by repertoire , code
// MAGIC having count(*) > 1

// COMMAND ----------

// MAGIC %sql 
// MAGIC CREATE OR REPLACE TEMPORARY VIEW vw_ref_dup AS (
// MAGIC with  t1 as (
// MAGIC select repertoire , code, count(*)
// MAGIC from vw_ref 
// MAGIC group by repertoire , code
// MAGIC having count(*) > 1) 
// MAGIC Select t2.* 
// MAGIC from vw_ref t2 
// MAGIC inner join t1 on t1.code = t2.code and t1.repertoire = t2.repertoire
// MAGIC where t2.reglementaire not in ("FRD" , "FDP")
// MAGIC order by repertoire, code)

// COMMAND ----------

// MAGIC %sql 
// MAGIC select * from vw_ref_dup

// COMMAND ----------

// MAGIC %sql
// MAGIC CREATE OR REPLACE TEMPORARY VIEW vw_final_ref AS (
// MAGIC select * from vw_ref 
// MAGIC minus 
// MAGIC select * from vw_ref_dup)

// COMMAND ----------

// MAGIC %sql
// MAGIC select repertoire , code, count(*)
// MAGIC from vw_final_ref 
// MAGIC group by repertoire , code
// MAGIC having count(*) > 1

// COMMAND ----------

// MAGIC %sql
// MAGIC select count(*)
// MAGIC from vw_final_ref  

// COMMAND ----------

var columnsReferentielDF = spark.read.format("csv") 
                  .option("sep", ";")
                  .option("header", "true")
                  .option("quote", "\"")
                  .option("escape", "\"")
                  .load("/mnt/raw_container/backup_hra/common/tables_referentiel.csv")

var  columnsReferentielTrim = columnsReferentielDF
      for(col <- columnsReferentielDF.columns){
        columnsReferentielTrim = columnsReferentielTrim.withColumn(col,trim(columnsReferentielDF(col)))
      }

var columnsReferentielDistinct = columnsReferentielTrim.distinct

// COMMAND ----------

display(columnsReferentielDistinct)

// COMMAND ----------

// var final_ref_df = columnsReferentielDistinct.join(referentielDistinct, columnsReferentielDistinct.col("repertoire") === referentielDistinct.col("repertoire"), "inner").

// COMMAND ----------

columnsReferentielDistinct.createOrReplaceTempView("vw_ref_columns")

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select 
// MAGIC   --ref.reglementaire
// MAGIC  ref.repertoire as code_repertoire
// MAGIC  ,ref.libelle_long 
// MAGIC  ,ref.libelle_court 
// MAGIC  ,ref.code
// MAGIC  ,refcol.libelle_repertoire
// MAGIC  ,refcol.column_name as nom_colonne
// MAGIC  ,refcol.tables as table_name
// MAGIC  
// MAGIC from vw_final_ref ref inner join vw_ref_columns refcol  on ref.repertoire = refcol.repertoire
// MAGIC order by code

// COMMAND ----------

val query = """ 
         select
         ref.repertoire as code_repertoire
         ,ref.libelle_long
         ,ref.libelle_court
         ,ref.code
         ,refcol.libelle_repertoire
         ,refcol.column_name as nom_colonne
         ,refcol.tables as nom_table

        from vw_final_ref ref inner join vw_ref_columns refcol  on ref.repertoire = refcol.repertoire

"""

// COMMAND ----------

val final_ref_df = spark.sql(query)

// COMMAND ----------

display(final_ref_df)

// COMMAND ----------

final_ref_df.write.format("parquet").mode("overwrite").save(dest_path + "/referentiel")

// COMMAND ----------


