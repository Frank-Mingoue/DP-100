// Databricks notebook source
import java.io.File
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SparkSession
import spark.implicits._ //so that you could use .toDF
import org.joda.time.DateTime
import org.apache.spark.sql.DataFrame
import scala.util.control.Exception._
import java.util.Properties
import org.apache.spark.sql.types._
import io.delta.tables._
import java.time.{LocalDate, Period}
import java.sql.DriverManager
import org.apache.spark.sql.expressions.Window
import java.io.FileReader
import java.io.FileNotFoundException
import java.io.IOException
import java.sql.ResultSet
import java.time._
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import collection.JavaConverters._
import java.time.temporal.ChronoUnit
import org.joda.time.format.DateTimeFormat
import scala.util.Try
import org.apache.commons.lang3.StringUtils

// COMMAND ----------

dbutils.notebook.getContext.notebookPath
