// Databricks notebook source
// MAGIC %run ../Include/read_write_parse_file

// COMMAND ----------

// MAGIC %run ./get_table_structure

// COMMAND ----------

//build the path to read curated data
val source_path = get_container("curated") + "/backup_hra/"

// source folders
val domain_list = dbutils.widgets.get("domain").split(",").toList

// table list to not load
// val generic_table_list = List("ZYWO", "ZY00", "ZX33", "ZX31")
val generic_table_list = List("")


val file = dbutils.widgets.get("file")
  

// COMMAND ----------

// DBTITLE 1,QUERIES GROUP 1

var final_list = List("")
var df_query_1 = spark.sql("select 'nom_table', 'count'").filter(col("nom_table") =!= "nom_table")
var df_query_2 = spark.sql("select 'nom_table', 'matricule_hra', 'matricule_WD',  'count'").filter(col("nom_table") =!= "nom_table")
var df_query_4 = spark.sql("select 'nom_table', 'matricule_hra', 'matricule_WD', 'perpai',  'count'").filter(col("nom_table") =!= "nom_table")
var df_query_3 = spark.sql("select 'nom_table', 'perpai', 'count'").filter(col("nom_table") =!= "nom_table")




for(domain <- domain_list) {
  
  
   val database = "hrabackup_" + domain
  
   val folder_path = source_path  + domain
  
   val tablelist = getcuratedtables(folder_path)
  
   if(!tablelist.isEmpty){
     
     //Create database 
     spark.sql(s""" create database if not exists ${database}; """)
     
     for(table <- tablelist){
       
       if (file.isEmpty){
           final_list = List(table)
         }
       else {      
          final_list = List(file)
         }
       
       if (!generic_table_list.contains(table) && final_list.contains(table)) {
         
         println(table)
         
                 
         
         
         //val query_1 = s""" select count(*) from ${database}.${table}; """
         val df_count_1 = spark.sql(s""" select '${table}',  count(*) from ${database}.${table}; """)

         df_query_1 = df_query_1.union(df_count_1)
         
         
         if (domain == "career" || domain == "absences" ){
           
         // query_2 = s"select matcle, matwor, count(*) from hrabackup_career.zy00 a, hrabackup_career.zywo b,  ${database}.${table} c where a.nudoss = b.nudoss and a.nudoss = c.nudoss    group by a.matcle, b.matwor order by 1;"
         val df_count_2 = spark.sql(s""" select '${table}', a.MATCLE, b.MATWOR, count(*) from hrabackup_career.zy00 a, hrabackup_career.zywo b,  ${database}.${table} c where a.NUDOSS = b.NUDOSS and a.NUDOSS = c.NUDOSS    group by a.MATCLE, b.MATWOR order by 1; """)
         df_query_2 = df_query_2.union(df_count_2)
           
         }
         else{
           
          
          // query_3 = s"select c.perpai, count(*) from hrabackup_pay.zy00 a,  hrabackup_career.zywo b, hrabackup_pay.zx00 c, ${database}.${table} d where a.nudoss = b.nudoss and a.nudoss = c.nugest  and c.nudoss = d.nudoss group by c.perpai order by 1"

           val df_coun_3 = spark.sql(s"""select '${table}', c.perpai, count(*) from hrabackup_career.zy00 a,  hrabackup_career.zywo b, hrabackup_pay.zx00 c, ${database}.${table} d where a.nudoss = b.nudoss and a.nudoss = c.nugest  and c.nudoss = d.nudoss group by c.perpai order by 1 """)
           df_query_3 = df_query_3.union(df_coun_3)
           
           
         
           // query_4 = select '${table}', a.MATCLE, b.MATWOR, c.PERPAI, count(*) from hrabackup_career.zy00 a, hrabackup_career.zywo b, hrabackup_pay.zx00 c,  ${database}.${table} d where a.nudoss = b.nudoss and a.nudoss = c.nugest  and c.nudoss = d.nudoss group by a.matcle,b.matwor,c.perpai order by 1"

           val df_count_4 = spark.sql(s""" select '${table}', a.MATCLE, b.MATWOR, c.PERPAI, count(*) from hrabackup_career.zy00 a, hrabackup_career.zywo b, hrabackup_pay.zx00 c,  ${database}.${table} d where a.nudoss = b.nudoss and a.nudoss = c.nugest  and c.nudoss = d.nudoss group by a.matcle,b.matwor,c.perpai order by 1; """)

           df_query_4 = df_query_4.union(df_count_4)
           
           
         }
         
      
         
       }
     }
   }  
   
  
}
val dest_folder = LocalDateTime.now().toString().replace("T", "").replace("-", "").replace(":", "").replace(".", "-").split("-")(0)

df_query_1.coalesce(1).write.format("csv").mode("overwrite").option("header", true).save(s"/mnt/curated_container/backup_hra/hra_stats/${dest_folder}/query_1.csv")
df_query_2.coalesce(1).write.format("csv").mode("overwrite").option("header", true).save(s"/mnt/curated_container/backup_hra/hra_stats/${dest_folder}/query_2.csv")
df_query_3.coalesce(1).write.format("csv").mode("overwrite").option("header", true).save(s"/mnt/curated_container/backup_hra/hra_stats/${dest_folder}/query_3.csv")
df_query_4.coalesce(1).write.format("csv").mode("overwrite").option("header", true).save(s"/mnt/curated_container/backup_hra/hra_stats/${dest_folder}/query_4.csv")

// COMMAND ----------

display(df_query_1)

// COMMAND ----------

// DBTITLE 1,QUERIES GROUP 2

var final_list = List("")
var df_query_1 = spark.sql("select 'nom_table', 'count'").filter(col("nom_table") =!= "nom_table")
var df_query_2 = spark.sql("select 'nom_table', 'matricule_hra', 'matricule_WD',  'count'").filter(col("nom_table") =!= "nom_table")
var df_query_4 = spark.sql("select 'nom_table', 'matricule_hra', 'matricule_WD', 'perpai',  'count'").filter(col("nom_table") =!= "nom_table")
var df_query_3 = spark.sql("select 'nom_table', 'perpai', 'count'").filter(col("nom_table") =!= "nom_table")




for(domain <- domain_list) {
  
  
   val database = "hrabackup_" + domain
  
   val folder_path = source_path  + domain
  
   val tablelist = getcuratedtables(folder_path)
  
   if(!tablelist.isEmpty){
     
     //Create database 
     spark.sql(s""" create database if not exists ${database}; """)
     
     for(table <- tablelist){
       
       if (file.isEmpty){
           final_list = List(table)
         }
       else {      
          final_list = List(file)
         }
       
       if (!generic_table_list.contains(table) && final_list.contains(table)) {
         
         println(table)
         
                 
         
         
         //val query_1 = s""" select count(*) from ${database}.${table}; """
         val df_count_1 = spark.sql(s""" select '${table}',  count(*) from ${database}.${table}; """)

         df_query_1 = df_query_1.union(df_count_1)
         
         
         if (domain == "career" || domain == "absences" ){
           
         // query_2 = s"select matcle, matwor, count(*) from hrabackup_career.zy00 a, hrabackup_career.zywo b,  ${database}.${table} c where a.nudoss = b.nudoss and a.nudoss = c.nudoss    group by a.matcle, b.matwor order by 1;"
         val df_count_2 = spark.sql(s""" select '${table}', a.MATCLE, b.MATWOR, count(*) from hrabackup_career.zy00 a left join hrabackup_career.zywo b on a.NUDOSS = b.NUDOSS  join ${database}.${table} c on a.NUDOSS = c.NUDOSS    group by a.MATCLE, b.MATWOR order by 1; """)
         df_query_2 = df_query_2.union(df_count_2)
           
         }
         else{
           
          
          // query_3 = s"select c.perpai, count(*) from hrabackup_pay.zy00 a,  hrabackup_career.zywo b, hrabackup_pay.zx00 c, ${database}.${table} d where a.nudoss = b.nudoss and a.nudoss = c.nugest  and c.nudoss = d.nudoss group by c.perpai order by 1"

           val df_coun_3 = spark.sql(s"""select '${table}', c.perpai, count(*) from hrabackup_career.zy00 a left join  hrabackup_career.zywo b on  a.nudoss = b.nudoss join hrabackup_pay.zx00 c on a.nudoss = c.nugest join ${database}.${table} d on c.nudoss = d.nudoss group by c.perpai order by 1 """)
           df_query_3 = df_query_3.union(df_coun_3)
           
           
         
           // query_4 = select '${table}', a.MATCLE, b.MATWOR, c.PERPAI, count(*) from hrabackup_career.zy00 a, hrabackup_career.zywo b, hrabackup_pay.zx00 c,  ${database}.${table} d where a.nudoss = b.nudoss and a.nudoss = c.nugest  and c.nudoss = d.nudoss group by a.matcle,b.matwor,c.perpai order by 1"

           val df_count_4 = spark.sql(s""" select '${table}', a.MATCLE, b.MATWOR, c.PERPAI, count(*) from hrabackup_career.zy00 a left join  hrabackup_career.zywo b on  a.nudoss = b.nudoss join hrabackup_pay.zx00 c on a.nudoss = c.nugest join ${database}.${table} d on c.nudoss = d.nudoss group by a.matcle,b.matwor,c.perpai order by 1; """)

           df_query_4 = df_query_4.union(df_count_4)
           
           
         }
         
      
         
       }
     }
   }  
   
  
}



// COMMAND ----------

val dest_folder = LocalDateTime.now().toString().replace("T", "").replace("-", "").replace(":", "").replace(".", "-").split("-")(0)

df_query_1.coalesce(1).write.format("csv").mode("overwrite").option("header", true).save(s"/mnt/curated_container/backup_hra/hra_stats/${dest_folder}/query_1.csv")
df_query_2.coalesce(1).write.format("csv").mode("overwrite").option("header", true).save("/mnt/curated_container/backup_hra/hra_stats/${dest_folder}/query_2.csv")
df_query_3.coalesce(1).write.format("csv").mode("overwrite").option("header", true).save("/mnt/curated_container/backup_hra/hra_stats/${dest_folder}/query_3.csv")
df_query_4.coalesce(1).write.format("csv").mode("overwrite").option("header", true).save("/mnt/curated_container/backup_hra/hra_stats/${dest_folder}/query_4.csv")

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select count(*) from hrabackup_pay.ZXMM

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_pay.ZX8K where PERPAI is null

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select PERPAI, count(*) from hrabackup_pay.ZXMM
// MAGIC group by PERPAI
// MAGIC order by PERPAI

// COMMAND ----------


var final_list = List("")
var df_query_1 = spark.sql("select 'nom_table', 'count'").filter(col("nom_table") =!= "nom_table")
var df_query_2 = spark.sql("select 'nom_table', 'matricule_hra', 'matricule_WD',  'count'").filter(col("nom_table") =!= "nom_table")
var df_query_4 = spark.sql("select 'nom_table','matricule_hra', 'matricule_WD', 'perpai',  'count'").filter(col("nom_table") =!= "nom_table")
var df_query_3 = spark.sql("select 'nom_table', 'perpai', 'count'").filter(col("nom_table") =!= "nom_table")




for(domain <- domain_list) {
  
  
   val database = "hrabackup_" + domain
  
   val folder_path = source_path  + domain
  
   val tablelist = getcuratedtables(folder_path)
  
   if(!tablelist.isEmpty){
     
     //Create database 
     spark.sql(s""" create database if not exists ${database}; """)
     
     for(table <- tablelist){
       
       if (file.isEmpty){
           final_list = List(table)
         }
       else {      
          final_list = List(file)
         }
       
       if (!generic_table_list.contains(table) && final_list.contains(table)) {
         
         println(table)
         
                 
         
         
         //query_1 = s""" select count(*) from ${database}.${table}; """
         val df_count = spark.sql(s""" select '${table}',  count(*) from ${database}.${table} where NUDOSS IS NULL; """)

         df_query_1 = df_query_1.union(df_count)
         
         
//          if (domain == "career" || domain == "absences" ){
//          // query_2 = s"select matcle, matwor, count(*) from hrabackup_career.zy00 a, hrabackup_career.zywo b,  ${database}.${table} c where a.nudoss = b.nudoss and a.nudoss = c.nudoss    group by a.matcle, b.matwor order by 1;"
//          val df_count = spark.sql(s""" select '${table}', a.MATCLE, b.MATWOR, count(*) from hrabackup_career.zy00 a, hrabackup_career.zywo b,  ${database}.${table} c where a.NUDOSS = b.NUDOSS and a.NUDOSS = c.NUDOSS    group by a.MATCLE, b.MATWOR order by 1; """)
//          df_query_2 = df_query_2.union(df_count)
           
//          }
//          else{
           
//           // QUERY 3
//           //query_3 = s"select c.perpai, count(*) from hrabackup_pay.zy00 a,  hrabackup_career.zywo b, hrabackup_pay.zx00 c, ${database}.${table} d where a.nudoss = b.nudoss and a.nudoss = c.nugest  and c.nudoss = d.nudoss group by c.perpai order by 1"

//            val df_count = spark.sql(s"""select '${table}', c.perpai, count(*) from hrabackup_career.zy00 a,  hrabackup_career.zywo b, hrabackup_pay.zx00 c, ${database}.${table} d where a.nudoss = b.nudoss and a.nudoss = c.nugest  and c.nudoss = d.nudoss group by c.perpai order by 1 """)
//            df_query_3 = df_query_3.union(df_count)
           
           
           

//            // query_4 = s"select c.perpai, count(*) from hrabackup_pay.zy00 a,  hrabackup_career.zywo b, hrabackup_pay.zx00 c, ${database}.${table} d where a.nudoss = b.nudoss and a.nudoss = c.nugest  and c.nudoss = d.nudoss group by c.perpai order by 1"

//            val df_count = spark.sql(s""" select '${table}', a.MATCLE, b.MATWOR, c.PERPAI, count(*) from hrabackup_career.zy00 a, hrabackup_career.zywo b, hrabackup_pay.zx00 c,  ${database}.${table} d where a.nudoss = b.nudoss and a.nudoss = c.nugest  and c.nudoss = d.nudoss group by a.matcle,b.matwor,c.perpai order by 1; """)

//            df_query_4 = df_query_4.union(df_count)
           
           
//          }
         
      
         
       }
     }
   }  
   
  
}

// df_query_1.coalesce(1).write.format("csv").mode("overwrite").option("header", true).save("/mnt/curated_container/backup_hra/hra_stats/query_1.csv")
// df_query_2.coalesce(1).write.format("csv").mode("overwrite").option("header", true).save("/mnt/curated_container/backup_hra/hra_stats/query_2.csv")
// df_query_3.coalesce(1).write.format("csv").mode("overwrite").option("header", true).save("/mnt/curated_container/backup_hra/hra_stats/query_3.csv")
// df_query_4.coalesce(1).write.format("csv").mode("overwrite").option("header", true).save("/mnt/curated_container/backup_hra/hra_stats/query_4.csv")

// COMMAND ----------

display(df_query_1)

// COMMAND ----------

// MAGIC %sql
// MAGIC REFRESH hrabackup_pay.zx35;
// MAGIC 
// MAGIC select count(*) from hrabackup_pay.zx35 where nudoss is null

// COMMAND ----------

//val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0 + ";message: Init database"

// COMMAND ----------

//dbutils.notebook.exit(return_value)

// COMMAND ----------


