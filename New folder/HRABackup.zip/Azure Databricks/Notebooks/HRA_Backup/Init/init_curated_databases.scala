// Databricks notebook source
// MAGIC %python
// MAGIC # dbutils.widgets.multiselect("domain", "career", ["career", "absences", "pay", "common"])

// COMMAND ----------

// MAGIC %run ../Include/read_write_parse_file

// COMMAND ----------

// MAGIC %run ./get_table_structure

// COMMAND ----------

//build the path to read curated data
val source_path = get_container("curated") + "/backup_hra/"

// source folders
val domain_list = dbutils.widgets.get("domain").split(",").toList

// table list to not load
// val generic_table_list = List("ZYWO", "ZY00", "ZX33", "ZX31")
val generic_table_list = List("")


val file = dbutils.widgets.get("file")
  

// COMMAND ----------

var final_list = List("")

for(domain <- domain_list) {
  
  
   val database = "hrabackup_" + domain
  
   val folder_path = source_path  + domain
  
   val tablelist = getcuratedtables(folder_path)
  
   if(!tablelist.isEmpty){
     
     //Create database 
     spark.sql(s""" create database if not exists ${database}; """)
     
     for(table <- tablelist){
       
       if (file.isEmpty){
           final_list = List(table)
         }
       else {      
          final_list = List(file)
         }
       
       if (!generic_table_list.contains(table) && final_list.contains(table)) {
         
         println(table)
         
         //get table creation script 
         val table_sql = get_table_structure(table, domain)
         
         
         //Create parquet table
         spark.sql(s""" drop table if exists ${database}.${table}; """)
         spark.sql(table_sql)
         
   
         spark.catalog.refreshTable(s"""${database}.${table}""")
      
         
       }
     }
   }  
   
  
}

// COMMAND ----------

//val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0 + ";message: Init database"

// COMMAND ----------

//dbutils.notebook.exit(return_value)
