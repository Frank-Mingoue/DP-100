// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read common.referentiel table
val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read absences.ZYAG table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZYAG_read = spark.table("hrabackup_absences.ZYAG")

//find and get column labels
df_ZYAG_read = gettranscoHRA(df_ZYAG_read, df_ref_read, "ZYAG")
                                                      
df_ZYAG_read.createOrReplaceTempView("vw_ZYAG")
df_ZYAG_read.cache()  //cache the dataframe

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.filtres", connectionproperties).createOrReplaceTempView("filtres")


// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.identification", connectionproperties).createOrReplaceTempView("identification")

// COMMAND ----------

// %sql
// --create or replace temporary view absences as 
// select 
//      a.NUDOSS as numero_dossier
//     ,a.DATDEB as date_debut
//     ,a.MOTIFA as motif
//     ,a.HRSDEB as heure_debut
//     ,a.DATFIN as date_fin
//     ,a.HRSFIN as heure_fin
//     ,a.TEMDEB as temoin_midi_debut
//     ,a.TEMFIN as temoin_midi_fin
//     ,a.GESTIO as temoin_gestion
//     ,a.PROLON as temoin_prolongation
//     ,a.NBHEUR as nombre_heures
//     ,a.IDLVSR as motif_situation_resultant
//     ,a.IDRTST as situation_au_retour
//     ,a.IDRTSC as categorie_situation_au_retour
//     ,a.IDRTSR as motif_situation_au_retour
//     ,a.NAABPD as payenon_paye
//     ,b.date_entree
//     ,b.date_sortie_administrative
//     ,b.societe
//     ,b.type_contrat
//     ,b.nature
//     ,b.etablissement
//     ,b.unite_organisationnelle
//     ,b.classification
//     ,b.qualification 
//     ,b.code_convention_collective
//     ,b.type_temps_contractuel
//     ,b.heures_presencemois
//     ,c.matricule_hra
//     ,c.matricule_workday
//     ,c.prenom_employe
//     ,c.nom_employe
//     ,c.date_anciennete
//     ,c.anciennete
//     ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
//     ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre
    

  
//   from vw_ZYAG a
//   left join filtres b on b.numero_dossier = a.NUDOSS 
//   and join_conditionHRA(a.DATDEB, a.DATFIN, b.date_debut_filtre, b.date_fin_filtre)
//     left join identification c on c.numero_dossier = a.NUDOSS

  
//   order by 1, 2
  

// COMMAND ----------

val query_record = """
     select 
     a.NUDOSS as numero_dossier
    ,a.DATDEB as date_debut
    ,a.MOTIFA as motif
    ,a.HRSDEB as heure_debut
    ,a.DATFIN as date_fin
    ,a.HRSFIN as heure_fin
    ,a.TEMDEB as temoin_midi_debut
    ,a.TEMFIN as temoin_midi_fin
    ,a.GESTIO as temoin_gestion
    ,a.PROLON as temoin_prolongation
    ,a.NBHEUR as nombre_heures
    ,a.IDLVSR as motif_situation_resultant
    ,a.IDRTST as situation_au_retour
    ,a.IDRTSC as categorie_situation_au_retour
    ,a.IDRTSR as motif_situation_au_retour
    ,a.NAABPD as payenon_paye
    ,b.date_entree
    ,b.date_sortie_administrative
    ,b.societe
    ,b.type_contrat
    ,b.nature
    ,b.etablissement
    ,b.unite_organisationnelle
    ,b.classification
    ,b.qualification 
    ,b.code_convention_collective
    ,b.type_temps_contractuel
    ,b.heures_presencemois
    ,c.matricule_hra
    ,c.matricule_workday
    ,c.prenom_employe
    ,c.nom_employe
    ,c.date_anciennete
    ,c.anciennete
    ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
    ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre

  
    from vw_ZYAG a
    left join filtres b on b.numero_dossier = a.NUDOSS 
    and join_conditionHRA(a.DATDEB, a.DATFIN, b.date_debut_filtre, b.date_fin_filtre)
    left join identification c on c.numero_dossier = a.NUDOSS
    order by 1, 2

 """ 

// COMMAND ----------

val ZYAG_inserted = spark.sql(query_record)
ZYAG_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table absences.ZYAG_absences """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

ZYAG_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "absences.ZYAG_absences", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
ZYAG_inserted.unpersist
df_ZYAG_read.unpersist
df_ref_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)
