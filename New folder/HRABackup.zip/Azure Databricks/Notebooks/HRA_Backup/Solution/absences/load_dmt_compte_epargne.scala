// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read common.referentiel table
val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read absences.ZYE4 table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZYE4_read = spark.table("hrabackup_absences.ZYE4")

//find and get column labels
df_ZYE4_read = gettranscoHRA(df_ZYE4_read, df_ref_read, "ZYE4")
                                                      
df_ZYE4_read.createOrReplaceTempView("vw_ZYE4")
df_ZYE4_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read absences.ZYE6 table
///dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE6", "domain" -> "absences"))

var df_ZYE6_read = spark.table("hrabackup_absences.ZYE6")

//find and get column labels
df_ZYE6_read = gettranscoHRA(df_ZYE6_read, df_ref_read, "ZYE6")
                                                      
df_ZYE6_read.createOrReplaceTempView("vw_ZYE6")
df_ZYE6_read.cache()  //cache the dataframe


// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.filtres", connectionproperties).createOrReplaceTempView("filtres")


// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.identification", connectionproperties).createOrReplaceTempView("identification")

// COMMAND ----------

// MAGIC %sql
// MAGIC CREATE OR REPLACE TEMPORARY VIEW compte_epargne as select 
// MAGIC   CASE
// MAGIC     WHEN zye6.NUDOSS IS NULL THEN zye4.NUDOSS
// MAGIC     ELSE zye6.NUDOSS
// MAGIC   END as numero_dossier,
// MAGIC   --zye6.NUDOSS as numero_dossier, 
// MAGIC   zye6.DTOPER as date_operation,
// MAGIC   CASE
// MAGIC     WHEN zye6.TYPCPT IS NULL THEN zye4.TYPCPT 
// MAGIC     ELSE zye6.TYPCPT 
// MAGIC   END as type_compte
// MAGIC   ,zye6.TYPOPE  AS type_operation
// MAGIC   --,zye6.TYPOPE as type_operation
// MAGIC   --,zye6.TYPCPT as type_compte
// MAGIC   ,zye6.NBJOTH AS nombre_jours_temps_plein
// MAGIC   ,zye6.NUMORD AS numero_ordre
// MAGIC   ,zye6.NBJOUR AS nombre_jours_epargnes
// MAGIC   ,zye6.NBJOUV AS nombre_jours_ouvres_epargnes
// MAGIC   ,zye6.NBHEUR AS nombre_heures_epargnees
// MAGIC   ,zye6.AMNUM AS montant_epargne
// MAGIC   ,zye6.SOLCHE AS solde_compte_en_heures_tps_plein_oce
// MAGIC   ,zye6.CDORIG AS code_origine
// MAGIC   --,zye4.TYPCPT as type_compte
// MAGIC   ,zye4.DTOUV AS date_ouverture_compte 
// MAGIC   ,zye4.DTFERM AS date_fermeture_compte 
// MAGIC   ,zye4.SOLCPT AS solde_compte_en_jours_ouvres
// MAGIC   ,zye4.SOLCTH AS solde_compte_theor_tps_pleine
// MAGIC   ,zye4.SOLCHE AS solde_compte_en_heures_tps_plein_ce
// MAGIC  
// MAGIC 
// MAGIC         
// MAGIC   
// MAGIC   FROM vw_ZYE6 zye6 
// MAGIC   FULL JOIN vw_ZYE4 zye4 ON zye4.NUDOSS = zye6.NUDOSS 
// MAGIC   AND zye6.TYPCPT = zye4.TYPCPT   --AND  zye6.DTOPER >= zye4.DTOUV AND  zye6.DTOPER <=  zye4.DTFERM 
// MAGIC  
// MAGIC   
// MAGIC 
// MAGIC   order by zye6.NUDOSS , zye6.TYPCPT, zye6.DTOPER 
// MAGIC   

// COMMAND ----------

// MAGIC %sql
// MAGIC select  compte_epargne.*
// MAGIC      ,date_entree
// MAGIC      ,date_sortie_administrative
// MAGIC      ,societe
// MAGIC      ,type_contrat
// MAGIC      ,nature
// MAGIC      ,etablissement
// MAGIC      ,unite_organisationnelle
// MAGIC      ,classification
// MAGIC      ,qualification 
// MAGIC      ,code_convention_collective
// MAGIC      ,type_temps_contractuel
// MAGIC      ,heures_presencemois
// MAGIC      ,date_debut_filtre
// MAGIC      ,date_fin_filtre
// MAGIC      ,matricule_hra
// MAGIC      ,matricule_workday
// MAGIC      ,prenom_employe
// MAGIC      ,nom_employe
// MAGIC      ,date_anciennete
// MAGIC      ,anciennete
// MAGIC from compte_epargne
// MAGIC left join identification on identification.numero_dossier = compte_epargne.numero_dossier
// MAGIC left join filtres on filtres.numero_dossier = compte_epargne.numero_dossier 
// MAGIC and compte_epargne.date_operation >=  filtres.date_debut_filtre  and  compte_epargne.date_operation <= filtres.date_fin_filtre
// MAGIC order by numero_dossier, date_operation, type_compte

// COMMAND ----------

val query_record = """

      select  compte_epargne.*
     ,date_entree
     ,date_sortie_administrative
     ,societe
     ,type_contrat
     ,nature
     ,etablissement
     ,unite_organisationnelle
     ,classification
     ,qualification 
     ,code_convention_collective
     ,type_temps_contractuel
     ,heures_presencemois
     ,date_debut_filtre
     ,date_fin_filtre
     ,matricule_hra
     ,matricule_workday
     ,prenom_employe
     ,nom_employe
     ,date_anciennete
     ,anciennete
     
from compte_epargne
left join identification on identification.numero_dossier = compte_epargne.numero_dossier
left join filtres on filtres.numero_dossier = compte_epargne.numero_dossier 
and compte_epargne.date_operation >=  filtres.date_debut_filtre  and  compte_epargne.date_operation <= filtres.date_fin_filtre
order by numero_dossier, date_operation, type_compte 
  
  """ 

// COMMAND ----------

val compte_epargne_inserted = spark.sql(query_record)
compte_epargne_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table absences.ZYE4_ZYE6_compte_epargne """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

compte_epargne_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "absences.ZYE4_ZYE6_compte_epargne", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
compte_epargne_inserted.unpersist
df_ZYE4_read.unpersist
df_ZYE6_read.unpersist
df_ref_read.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)
