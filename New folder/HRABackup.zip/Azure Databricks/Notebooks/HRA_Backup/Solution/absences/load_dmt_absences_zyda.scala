// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read common.referentiel table
val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read absences.ZYDA table
///dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE6", "domain" -> "absences"))

var df_ZYDA_read = spark.table("hrabackup_absences.ZYDA")

//find and get column labels
df_ZYDA_read = gettranscoHRA(df_ZYDA_read, df_ref_read, "ZYDA")
                                                      
df_ZYDA_read.createOrReplaceTempView("vw_ZYDA")
df_ZYDA_read.cache()  //cache the dataframe

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.filtres", connectionproperties).createOrReplaceTempView("filtres")


// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.identification", connectionproperties).createOrReplaceTempView("identification")

// COMMAND ----------

// %sql

// select 
//     a.NUDOSS as numero_dossier
//     ,a.DATABS as date_debut_absence_ac 
//     ,a.MOTABS as motif_absence 
//     ,a.HRSDEB as heure_debut 
//     ,a.NUMDRO as numero_droit 
//     ,a.DATDEB as date_debuttranche 
//     ,a.NUMTRA as numero_tranche 
//     ,a.DATFIN as date_fin_tranche 
//     ,a.HRSFIN as heure_fin 
//     ,a.TEMDEB as temoin_midi_debut 
//     ,a.TEMFIN as temoin_midi_fin 
//     ,a.UNITE1 as duree_1 
//     ,a.UNITE2 as duree_2 
//     ,a.NBRJOU as nombre_jours 
//     ,a.DATEAG as date_debut_absence_gestion
//     ,b.date_entree
//     ,b.date_sortie_administrative
//     ,b.socete
//     ,b.type_contrat
//     ,b.nature
//     ,b.etablissement
//     ,b.unite_organisationnelle
//     ,b.classification
//     ,b.qualification 
//     ,b.code_convention_collective
//     ,b.type_temps_contractuel
//     ,b.heures_presencemois
//     ,c.matricule_hra
//     ,c.matricule_workday
//     ,c.prenom_employe
//     ,c.nom_employe
//     ,c.date_anciennete
//     ,c.anciennete
//     ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
//     ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre
  
//   from vw_ZYDA a
//   left join filtres b on b.numero_dossier = a.NUDOSS 
//   and join_conditionHRA(a.DATDEB, a.DATFIN, b.date_debut_filtre, b.date_fin_filtre)
//   left join identification c on c.numero_dossier = a.NUDOSS
  
// order by numero_dossier , date_debut_filtre

// COMMAND ----------

val query_record = """
  select 
    a.NUDOSS as numero_dossier
    ,a.DATABS as date_debut_absence_ac 
    ,a.MOTABS as motif_absence 
    ,a.HRSDEB as heure_debut 
    ,a.NUMDRO as numero_droit 
    ,a.DATDEB as date_debuttranche 
    ,a.NUMTRA as numero_tranche 
    ,a.DATFIN as date_fin_tranche 
    ,a.HRSFIN as heure_fin 
    ,a.TEMDEB as temoin_midi_debut 
    ,a.TEMFIN as temoin_midi_fin 
    ,a.UNITE1 as duree_1 
    ,a.UNITE2 as duree_2 
    ,a.NBRJOU as nombre_jours 
    ,a.DATEAG as date_debut_absence_gestion
    ,b.date_entree
    ,b.date_sortie_administrative
    ,b.societe
    ,b.type_contrat
    ,b.nature
    ,b.etablissement
    ,b.unite_organisationnelle
    ,b.classification
    ,b.qualification 
    ,b.code_convention_collective
    ,b.type_temps_contractuel
    ,b.heures_presencemois
    ,c.matricule_hra
    ,c.matricule_workday
    ,c.prenom_employe
    ,c.nom_employe
    ,c.date_anciennete
    ,c.anciennete
    ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
    ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre
  
  from vw_ZYDA a
  left join filtres b on b.numero_dossier = a.NUDOSS 
  and join_conditionHRA(a.DATDEB, a.DATFIN, b.date_debut_filtre, b.date_fin_filtre)
  left join identification c on c.numero_dossier = a.NUDOSS
  
  order by numero_dossier , date_debut_filtre
  """ 

// COMMAND ----------

val ZYDA_inserted = spark.sql(query_record)
ZYDA_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table absences.ZYDA_absences_decoupees_droits """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

ZYDA_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "absences.ZYDA_absences_decoupees_droits", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
ZYDA_inserted.unpersist
df_ZYDA_read.unpersist
df_ref_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)

// COMMAND ----------


