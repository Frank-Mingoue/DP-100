// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zy24  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_table_read = spark.table("hrabackup_career.ZY24")

//find and get column labels
df_table_read = gettranscoHRA(df_table_read, df_ref_read, "ZY24")
                                                      
df_table_read.createOrReplaceTempView("vw_table")
df_table_read.cache()  //cache the dataframe

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.filtres", connectionproperties).createOrReplaceTempView("filtres")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.identification", connectionproperties).createOrReplaceTempView("identification")


// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select  
// MAGIC    a.NUDOSS as numero_dossier
// MAGIC   ,a.NUDOSP as identifiant_dossier_paie 
// MAGIC   ,a.TRANST as type_transport
// MAGIC   ,a.DATEFF as date_effet
// MAGIC   ,a.ENDDAT as date_fin
// MAGIC   ,a.IDCONT as identifiant_contrat 
// MAGIC   ,b.date_entree
// MAGIC   ,b.date_sortie_administrative  
// MAGIC   ,b.societe  
// MAGIC   ,b.type_contrat
// MAGIC   ,b.nature
// MAGIC   ,b.etablissement
// MAGIC   ,b.unite_organisationnelle
// MAGIC   ,b.classification
// MAGIC   ,b.qualification 
// MAGIC   ,b.code_convention_collective
// MAGIC   ,b.type_temps_contractuel
// MAGIC   ,b.heures_presencemois
// MAGIC   ,c.matricule_hra
// MAGIC   ,c.matricule_workday
// MAGIC   ,c.prenom_employe
// MAGIC   ,c.nom_employe
// MAGIC   ,get_dateHRA(a.DATEFF, a.ENDDAT, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
// MAGIC   ,get_dateHRA(a.DATEFF, a.ENDDAT, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre
// MAGIC   
// MAGIC   
// MAGIC   
// MAGIC   from vw_table a
// MAGIC   
// MAGIC   left join filtres b on b.numero_dossier = a.NUDOSS 
// MAGIC   and join_conditionHRA(a.DATEFF, a.ENDDAT, b.date_debut_filtre, b.date_fin_filtre)
// MAGIC   left join identification c on c.numero_dossier = a.NUDOSS
// MAGIC   
// MAGIC   order by numero_dossier, date_debut_filtre
// MAGIC   

// COMMAND ----------

val query_record = """

  select  
   a.NUDOSS as numero_dossier
  ,a.NUDOSP as identifiant_dossier_paie 
  ,a.TRANST as type_transport
  ,a.DATEFF as date_effet
  ,a.ENDDAT as date_fin
  ,a.IDCONT as identifiant_contrat 
  ,b.date_entree
  ,b.date_sortie_administrative  
  ,b.societe  
  ,b.type_contrat
  ,b.nature
  ,b.etablissement
  ,b.unite_organisationnelle
  ,b.classification
  ,b.qualification 
  ,b.code_convention_collective
  ,b.type_temps_contractuel
  ,b.heures_presencemois
  ,c.matricule_hra
  ,c.matricule_workday
  ,c.prenom_employe
  ,c.nom_employe
  ,get_dateHRA(a.DATEFF, a.ENDDAT, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
  ,get_dateHRA(a.DATEFF, a.ENDDAT, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre
  
  
  
  from vw_table a
  
  left join filtres b on b.numero_dossier = a.NUDOSS 
  and join_conditionHRA(a.DATEFF, a.ENDDAT, b.date_debut_filtre, b.date_fin_filtre)
  left join identification c on c.numero_dossier = a.NUDOSS
  
  order by numero_dossier, date_debut_filtre
  
  
 """ 

// COMMAND ----------

val table_inserted = spark.sql(query_record)
table_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.ZY24_type_transport """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

table_inserted.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.ZY24_type_transport", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
table_inserted.unpersist
df_table_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)
