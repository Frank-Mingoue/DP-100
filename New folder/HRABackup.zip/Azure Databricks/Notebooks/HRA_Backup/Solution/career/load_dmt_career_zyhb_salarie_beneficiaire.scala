// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zy24  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_table_read = spark.table("hrabackup_career.ZYHB")

//find and get column labels
df_table_read = gettranscoHRA(df_table_read, df_ref_read, "ZYHB")
                                                      
df_table_read.createOrReplaceTempView("vw_table")
df_table_read.cache()  //cache the dataframe

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.filtres", connectionproperties).createOrReplaceTempView("filtres")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.identification", connectionproperties).createOrReplaceTempView("identification")


// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select   
// MAGIC    a.NUDOSS as numero_dossier
// MAGIC   ,a.DATDEB as date_debut 
// MAGIC   ,a.DTDECI as date_decision 
// MAGIC   ,a.DATFIN as date_fin 
// MAGIC   ,a.FLDUR1 as duree_decision 
// MAGIC   ,a.FLCHAU as temoin_chaumage_avant_embauche 
// MAGIC   ,a.FLCOTO as temoin_reconnu_travailleur_handicape 
// MAGIC   ,a.FLEA00 as placement_ea 
// MAGIC   ,a.FLESTA as placement_esta 
// MAGIC   ,a.FLCDTD as placement_cdtd 
// MAGIC   ,a.FLINVP as temoin_invalide_pensionne 
// MAGIC   ,a.FLSAPO as temoin_sapeur_pompier_volontaire 
// MAGIC   ,a.FLASMU as temoin_assimile_mutile_guerre 
// MAGIC   ,a.TEMAVI as temoin_handicap_permanent_a_viee 
// MAGIC   ,a.FLMUTG as temoin_mutile_guerre 
// MAGIC   ,a.FLALLO as temoin_beneficiaire_allocation 
// MAGIC   ,a.TEMCAR as temoin_titulaire_allocation 
// MAGIC   ,a.TEMHAN as temoin_malprofesacctravailtrajet 
// MAGIC   ,a.FLHPLD as temoin_handicap_lourd 
// MAGIC   ,a.POUHAN as taux_invalidite 
// MAGIC   ,a.DATPEN as date_debut_pension 
// MAGIC   ,a.CATPEN as categorie_pension 
// MAGIC   ,a.TXINCA as taux_incapacite 
// MAGIC   ,a.TEMHAT as temoin_accident_travail 
// MAGIC   ,a.FL5212 as prestation_compensation_handic 
// MAGIC   ,a.IDMCAT as catego_beneficiaire_oblig_emploi 
// MAGIC   ,a.FLMADE as temoin_mise_a_disposition_externe 
// MAGIC   ,b.date_entree
// MAGIC   ,b.date_sortie_administrative  
// MAGIC   ,b.type_contrat
// MAGIC   ,b.nature
// MAGIC   ,b.etablissement
// MAGIC   ,b.unite_organisationnelle
// MAGIC   ,b.classification
// MAGIC   ,b.qualification 
// MAGIC   ,b.code_convention_collective
// MAGIC   ,b.type_temps_contractuel
// MAGIC   ,b.heures_presencemois
// MAGIC   ,b.societe
// MAGIC   ,c.matricule_hra
// MAGIC   ,c.matricule_workday
// MAGIC   ,c.prenom_employe
// MAGIC   ,c.nom_employe
// MAGIC   ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
// MAGIC   ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre
// MAGIC   
// MAGIC   
// MAGIC   
// MAGIC   from vw_table a
// MAGIC   
// MAGIC   left join filtres b on b.numero_dossier = a.NUDOSS 
// MAGIC   and join_conditionHRA(a.DATDEB, a.DATFIN, b.date_debut_filtre, b.date_fin_filtre)  
// MAGIC   left join identification c on c.numero_dossier = a.NUDOSS
// MAGIC 
// MAGIC   order by numero_dossier, date_debut_filtre
// MAGIC   

// COMMAND ----------

val query_record = """

  select   
   a.NUDOSS as numero_dossier
  ,a.DATDEB as date_debut 
  ,a.DTDECI as date_decision 
  ,a.DATFIN as date_fin 
  ,a.FLDUR1 as duree_decision 
  ,a.FLCHAU as temoin_chaumage_avant_embauche 
  ,a.FLCOTO as temoin_reconnu_travailleur_handicape 
  ,a.FLEA00 as placement_ea 
  ,a.FLESTA as placement_esta 
  ,a.FLCDTD as placement_cdtd 
  ,a.FLINVP as temoin_invalide_pensionne 
  ,a.FLSAPO as temoin_sapeur_pompier_volontaire 
  ,a.FLASMU as temoin_assimile_mutile_guerre 
  ,a.TEMAVI as temoin_handicap_permanent_a_viee 
  ,a.FLMUTG as temoin_mutile_guerre 
  ,a.FLALLO as temoin_beneficiaire_allocation 
  ,a.TEMCAR as temoin_titulaire_allocation 
  ,a.TEMHAN as temoin_malprofesacctravailtrajet 
  ,a.FLHPLD as temoin_handicap_lourd 
  ,a.POUHAN as taux_invalidite 
  ,a.DATPEN as date_debut_pension 
  ,a.CATPEN as categorie_pension 
  ,a.TXINCA as taux_incapacite 
  ,a.TEMHAT as temoin_accident_travail 
  ,a.FL5212 as prestation_compensation_handic 
  ,a.IDMCAT as catego_beneficiaire_oblig_emploi 
  ,a.FLMADE as temoin_mise_a_disposition_externe 
  ,b.date_entree
  ,b.date_sortie_administrative  
  ,b.type_contrat
  ,b.nature
  ,b.etablissement
  ,b.unite_organisationnelle
  ,b.classification
  ,b.qualification 
  ,b.code_convention_collective
  ,b.type_temps_contractuel
  ,b.heures_presencemois
  ,b.societe
  ,c.matricule_hra
  ,c.matricule_workday
  ,c.prenom_employe
  ,c.nom_employe
  ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
  ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre
  
  
  
  from vw_table a
  
  left join filtres b on b.numero_dossier = a.NUDOSS 
  and join_conditionHRA(a.DATDEB, a.DATFIN, b.date_debut_filtre, b.date_fin_filtre)  
  left join identification c on c.numero_dossier = a.NUDOSS

  order by numero_dossier, date_debut_filtre  
  
 """ 

// COMMAND ----------

val table_inserted = spark.sql(query_record)
table_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.zyhb_salarie_beneficiaire """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

table_inserted.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.zyhb_salarie_beneficiaire", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
table_inserted.unpersist
df_table_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)
