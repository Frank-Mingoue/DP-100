// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zywv  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZYWV_read = spark.table("hrabackup_career.ZYWV")

//find and get column labels
df_ZYWV_read = gettranscoHRA(df_ZYWV_read, df_ref_read, "ZYWV")
                                                      
df_ZYWV_read.createOrReplaceTempView("vw_ZYWV")
df_ZYWV_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zyco  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZYCO_read = spark.table("hrabackup_career.ZYCO")

//find and get column labels
df_ZYCO_read = gettranscoHRA(df_ZYCO_read, df_ref_read, "ZYCO")
                                                      
df_ZYCO_read.createOrReplaceTempView("vw_ZYCO")
df_ZYCO_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zyca  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZYCA_read = spark.table("hrabackup_career.ZYCA")

//find and get column labels
df_ZYCA_read = gettranscoHRA(df_ZYCA_read, df_ref_read, "ZYCA")
                                                      
df_ZYCA_read.createOrReplaceTempView("vw_ZYCA")
df_ZYCA_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zyes  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZYES_read = spark.table("hrabackup_career.ZYES")

//find and get column labels
df_ZYES_read = gettranscoHRA(df_ZYES_read, df_ref_read, "ZYES")
                                                      
df_ZYES_read.createOrReplaceTempView("vw_ZYES")
df_ZYES_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zy19  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZY19_read = spark.table("hrabackup_career.ZY19")

//find and get column labels
df_ZY19_read = gettranscoHRA(df_ZY19_read, df_ref_read, "ZY19")
                                                      
df_ZY19_read.createOrReplaceTempView("vw_ZY19")
df_ZY19_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from vw_ZY19 
// MAGIC -- WHERE NUDOSS = 1
// MAGIC ORDER BY NUDOSS , DATAN5

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from vw_ZY1S 
// MAGIC WHERE NUDOSS = 1
// MAGIC ORDER BY NUDOSS , DTEF00

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from vw_ZYWV 
// MAGIC -- WHERE NUDOSS = 3769
// MAGIC ORDER BY NUDOSS , DATDEB

// COMMAND ----------

// DBTITLE 1,JOIN ZYCO AND ZYES
val query = """create or replace temporary view T1 as SELECT 
        case 
          when zyes.NUDOSS is not null then zyes.NUDOSS 
          else zyco.NUDOSS 
        end as T1_numero_dossier
        ,zyes.DATENT as zyes_date_entree
        ,zyes.CODENT as zyes_motif_entree
        ,zyes.IDZYES as zyes_identification_entree_sortie
        ,zyes.DATSOR as zyes_date_sortie_administrative
        ,zyes.CODSOR as zyes_motif_sortie
        ,zyes.PHYSOR as zyes_date_sortie_physique
        ,zyes.IDCY00 as zyes_societe
        ,zyes.CGSTAT as zyes_statut_resultant_la_sortie
        ,zyco.DATCON as zyco_date_debut_contrat 
        ,zyco.DATFIN as zyco_date_fin_contrat 
        ,zyco.TYPCON as zyco_type_contrat 
        ,zyco.NATCON as zyco_nature 
        ,zyco.DATPRE as zyco_date_fin_presumee 
        ,zyco.FINESS as zyco_fin_periode_essai 
        ,zyco.NBHEUC as zyco_nombre_heures_contrat 
        ,zyco.MOISCL as zyco_duree_clause_en_mois 
        ,zyco.MONTAN as zyco_montant_mensuel 
        ,zyco.POURCE as zyco_pourcentage_mensuel 
        ,zyco.CONTRA as zyco_clause_contractuelle 
        ,zyco.CLLEVE as zyco_clause_levee
        ,get_dateHRA(zyes.DATENT, zyes.DATSOR, zyes.NUDOSS, zyco.DATCON, zyco.DATFIN, zyco.NUDOSS, "start" ) as T1_date_debut
        ,get_dateHRA(zyes.DATENT, zyes.DATSOR, zyes.NUDOSS, zyco.DATCON, zyco.DATFIN, zyco.NUDOSS, "end" ) as T1_date_fin


        FROM  vw_ZYES zyes 
        full join vw_ZYCO zyco on zyes.NUDOSS = zyco.NUDOSS 
        and join_conditionHRA(zyes.DATENT, zyes.DATSOR, zyco.DATCON, zyco.DATFIN)
        """

spark.sql(query)

// COMMAND ----------

// DBTITLE 1,ADD TABLE ZYCA
val query = """create or replace temporary view T2 as SELECT 
        case 
          when T1.T1_numero_dossier is not null then T1.T1_numero_dossier 
          else zyca.NUDOSS 
        end as T2_numero_dossier
        ,T1.*
        ,zyca.DATEFF as zyca_date_debut 
        ,zyca.DATFIN as zyca_date_fin 
        ,zyca.QUALIF as zyca_qualification 
        ,zyca.CLASSI as zyca_classification 
        ,zyca.COCONV as zyca_code_convention_collective 
        ,zyca.TYPREG as zyca_type_regime_cotisation_retraite 
        ,zyca.CHBASE as zyca_coefficient_base_chimie 
        ,zyca.CHSPEC as zyca_coefficient_specialite_chimie 
        ,zyca.COGRPE as zyca_groupe_couture 
        ,zyca.CONIVE as zyca_niveau_couture 
        ,zyca.EXTCF1 as zyca_temoin_1 
        ,zyca.CHPERS as zyca_coefficient_personnel_chimie 
        ,zyca.CHNIVE as zyca_niveau_chimie 
        ,zyca.CHECHL as zyca_echelon_chimie 
        ,get_dateHRA(T1.T1_date_debut, T1.T1_date_fin, T1.T1_numero_dossier, zyca.DATEFF, zyca.DATFIN, zyca.NUDOSS, "start" ) as T2_date_debut
        ,get_dateHRA(T1.T1_date_debut, T1.T1_date_fin, T1.T1_numero_dossier, zyca.DATEFF, zyca.DATFIN, zyca.NUDOSS, "end" ) as T2_date_fin


        FROM  T1
        full join vw_ZYCA zyca on zyca.NUDOSS = T1.T1_numero_dossier 
        and join_conditionHRA(T1.T1_date_debut, T1.T1_date_fin, zyca.DATEFF, zyca.DATFIN)
        """

spark.sql(query)

// COMMAND ----------

// DBTITLE 1,ADD TABLE ZYWV
val query = """create or replace temporary view T3 as SELECT 
        case 
          when T2.T2_numero_dossier is not null then T2.T2_numero_dossier 
          else zywv.NUDOSS 
        end as T3_numero_dossier
        ,T2.*
        ,zywv.DATDEB as zywv_date_debut
        ,zywv.DATFIN as zywv_date_fin
        ,zywv.TYPDET as zywv_type_detachement
        ,zywv.PAYDET as zywv_pays_detachement
        ,zywv.SITFAM as zywv_situation_famille_sur_place
        ,zywv.RESFIS as zywv_residant_fiscal_hors_france
        ,zywv.NUMORD as zywv_numero_ordre_interne        
        ,get_dateHRA(T2.T2_date_debut, T2.T2_date_fin, T2.T2_numero_dossier, zywv.DATDEB, zywv.DATFIN, zywv.NUDOSS, "start" ) as T3_date_debut
        ,get_dateHRA(T2.T2_date_debut, T2.T2_date_fin, T2.T2_numero_dossier, zywv.DATDEB, zywv.DATFIN, zywv.NUDOSS, "end" ) as T3_date_fin


        FROM  T2
        full join vw_ZYWV zywv on zywv.NUDOSS = T2.T2_numero_dossier 
        and join_conditionHRA(T2.T2_date_debut, T2.T2_date_fin, zywv.DATDEB, zywv.DATFIN)
        """

spark.sql(query)

// COMMAND ----------

// DBTITLE 1,init and read career.zy1s  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZY1S_read = spark.table("hrabackup_career.ZY1S")

//find and get column labels
df_ZY1S_read = gettranscoHRA(df_ZY1S_read, df_ref_read, "ZY1S")
                                                      
df_ZY1S_read.createOrReplaceTempView("ZY1S")

spark.sql(""" create or replace temporary view vw_ZY1S as select *,             
                        coalesce (Lead(date_add (DTEF1S, -1)) over (partition by NUDOSS order by DTEF1S), '2999-12-31') as DATFIN
                        FROM ZY1S
                      """ )

df_ZY1S_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,ADD TABLE ZY1S
val query = """create or replace temporary view T4 as SELECT 
        case 
          when T3.T3_numero_dossier is not null then T3.T3_numero_dossier 
          else zy1s.NUDOSS 
        end as T4_numero_dossier
        ,T3.*
        ,zy1s.DTEF1S as zy1s_date_effet_la_situation 
        ,zy1s.STEMPL as zy1s_situation 
        ,zy1s.CGSTAT as zy1s_categorie_situation 
        ,zy1s.RSSTAT as zy1s_motif_situation 
        ,zy1s.FLABGN as zy1s_occurrences_generees_par_un_conge 
        ,get_dateHRA(T3.T3_date_debut, T3.T3_date_fin, T3.T3_numero_dossier, zy1s.DTEF1S, zy1S.DATFIN, zy1s.NUDOSS, "start" ) as T4_date_debut
        ,get_dateHRA(T3.T3_date_debut, T3.T3_date_fin, T3.T3_numero_dossier, zy1s.DTEF1S, zy1S.DATFIN, zy1s.NUDOSS, "end" ) as T4_date_fin


        FROM  T3
        full join vw_ZY1S zy1s on zy1s.NUDOSS = T3.T3_numero_dossier 
        and join_conditionHRA(T3.T3_date_debut, T3.T3_date_fin, zy1s.DTEF1S, zy1S.DATFIN)
        """

spark.sql(query)

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from T4

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.filtres", connectionproperties).createOrReplaceTempView("filtres")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.identification", connectionproperties).createOrReplaceTempView("identification")


// COMMAND ----------

// DBTITLE 1,add filters, identification and ZY19
val query = """create or replace temporary view T5 as SELECT 
         T4.T4_numero_dossier as numero_dossier
        ,T4.zyes_date_entree
        ,T4.zyes_motif_entree
        ,T4.zyes_identification_entree_sortie
        ,T4.zyes_date_sortie_administrative
        ,T4.zyes_motif_sortie
        ,T4.zyes_date_sortie_physique
        ,T4.zyes_societe
        ,T4.zyes_statut_resultant_la_sortie
        ,T4.zyco_date_debut_contrat 
        ,T4.zyco_date_fin_contrat 
        ,T4.zyco_type_contrat 
        ,T4.zyco_nature 
        ,T4.zyco_date_fin_presumee 
        ,T4.zyco_fin_periode_essai 
        ,T4.zyco_nombre_heures_contrat 
        ,T4.zyco_duree_clause_en_mois 
        ,T4.zyco_montant_mensuel 
        ,T4.zyco_pourcentage_mensuel 
        ,T4.zyco_clause_contractuelle 
        ,T4.zyco_clause_levee
        ,T4.zyca_date_debut 
        ,T4.zyca_date_fin 
        ,T4.zyca_qualification 
        ,T4.zyca_classification 
        ,T4.zyca_code_convention_collective 
        ,T4.zyca_type_regime_cotisation_retraite 
        ,T4.zyca_coefficient_base_chimie 
        ,T4.zyca_coefficient_specialite_chimie 
        ,T4.zyca_groupe_couture 
        ,T4.zyca_niveau_couture 
        ,T4.zyca_temoin_1 
        ,T4.zyca_coefficient_personnel_chimie 
        ,T4.zyca_niveau_chimie 
        ,T4.zyca_echelon_chimie 
        ,T4.zywv_date_debut
        ,T4.zywv_date_fin
        ,T4.zywv_type_detachement
        ,T4.zywv_pays_detachement
        ,T4.zywv_situation_famille_sur_place
        ,T4.zywv_residant_fiscal_hors_france
        ,T4.zywv_numero_ordre_interne
        ,T4.zy1s_date_effet_la_situation 
        ,T4.zy1s_situation 
        ,T4.zy1s_categorie_situation 
        ,T4.zy1s_motif_situation 
        ,T4.zy1s_occurrences_generees_par_un_conge
        ,zy19.DATAN1 as zy19_date_anciennete_1
        ,zy19.DATAN2 as zy19_date_anciennete_2 
        ,zy19.DATAN3 as zy19_date_anciennete_3 
        ,zy19.DATAN4 as zy19_date_anciennete_4 
        ,zy19.DATAN5 as zy19_date_anciennete_5 
        ,zy19.DATAN6 as zy19_date_anciennete_6
        ,identification.matricule_hra
        ,identification.matricule_workday
        ,identification.prenom_employe
        ,identification.nom_employe
        ,filtres.date_entree
        ,filtres.date_sortie_administrative  
        ,filtres.type_contrat
        ,filtres.nature
        ,filtres.etablissement
        ,filtres.unite_organisationnelle
        ,filtres.classification
        ,filtres.qualification 
        ,filtres.code_convention_collective
        ,filtres.type_temps_contractuel
        ,filtres.heures_presencemois
        ,filtres.societe
        
        ,get_dateHRA(T4.T4_date_debut, T4.T4_date_fin, T4.T4_numero_dossier, filtres.date_debut_filtre, filtres.date_fin_filtre, filtres.numero_dossier, "start" ) as date_debut_filtre
        ,get_dateHRA(T4.T4_date_debut, T4.T4_date_fin, T4.T4_numero_dossier, filtres.date_debut_filtre, filtres.date_fin_filtre, filtres.numero_dossier, "end" ) as date_fin_filtre


        FROM  T4
        left join vw_ZY19 zy19 on zy19.NUDOSS = T4.T4_numero_dossier
        left join identification on identification.numero_dossier = T4.T4_numero_dossier
        left join filtres  on filtres.numero_dossier = T4.T4_numero_dossier 
        and join_conditionHRA(T4.T4_date_debut, T4.T4_date_fin, filtres.date_debut_filtre, filtres.date_fin_filtre)
        
        order by T4_numero_dossier, date_debut_filtre
        """

spark.sql(query)

// COMMAND ----------

// %sql

// select * from T5

// COMMAND ----------

val query_record = """

  select * 
  from T5   
  order by numero_dossier, date_debut_filtre
  
  
 """ 

// COMMAND ----------

val table_inserted = spark.sql(query_record)
table_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.ZYCO_ZYWV_ZYES_ZYCA_ZY1S_ZY19_contrat """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

table_inserted.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.ZYCO_ZYWV_ZYES_ZYCA_ZY1S_ZY19_contrat", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
table_inserted.unpersist
df_table_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)
