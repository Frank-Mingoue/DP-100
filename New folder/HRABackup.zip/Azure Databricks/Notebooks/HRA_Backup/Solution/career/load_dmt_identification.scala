// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read ZY00 table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZY00", "domain" -> "career"))

val df_ZY00_read = spark.table("hrabackup_career.ZY00")
                                                      
df_ZY00_read.createOrReplaceTempView("vw_ZY00")
df_ZY00_read.cache()  //cache the dataframe

// COMMAND ----------

//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYWO", "domain" -> "career"))

val df_ZYWO_read = spark.table("hrabackup_career.ZYWO")
                                                      
df_ZYWO_read.createOrReplaceTempView("vw_ZYWO")
df_ZYWO_read.cache()  //cache the dataframe

// COMMAND ----------

//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZY19", "domain" -> "career"))

val df_ZY19_read = spark.table("hrabackup_career.ZY19")
                                                      
df_ZY19_read.createOrReplaceTempView("vw_ZY19")
df_ZY19_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZYWO

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZY00

// COMMAND ----------

// %sql
// select CASE
//     WHEN DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 6 NULL THEN "Moins de 6 mois"
//     WHEN DATEDIFF(CURRENT_DATE(), DATAN5) / 30 >= 6 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 12  THEN "Entre 6 mois et 1 an"
//     WHEN DATEDIFF(CURRENT_DATE(), DATAN5) / 30 >= 12 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 36  THEN "1 à 3 ans"
//     WHEN DATEDIFF(CURRENT_DATE(), DATAN5) / 30 >= 36 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 60  THEN "3 à 5 ans"
//     WHEN DATEDIFF(CURRENT_DATE(), DATAN5) / 30 >= 60 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 120  THEN "5 à 10 ans"
//     WHEN DATEDIFF(CURRENT_DATE(), DATAN5) / 30 >= 120 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 240  THEN "10 à 20 ans"
//     ELSE "Plus de 20 ans"
//   END as anciennete, 
// from vw_ZY19

// COMMAND ----------

//spark.read.jdbc(jdbcurl, "dbo.vw_ref_degree_level", connectionproperties).createOrReplaceTempView("vw_ref_degree_level")

// COMMAND ----------

val query_record = """ select 
                      a.NUDOSS as numero_dossier,
                      a.MATCLE  as matricule_hra,
                      b.MATWOR as matricule_workday,
                      a.PRENOM as prenom_employe,
                      a.NOMUSE as nom_employe,
                      c.DATAN5 as date_anciennete,
                      CASE
                          WHEN DATEDIFF(CURRENT_DATE(), c.DATAN5) / 30 < 6  THEN "Moins de 6 mois"
                          WHEN DATEDIFF(CURRENT_DATE(), c.DATAN5) / 30 >= 6 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 12  THEN "Entre 6 mois et 1 an"
                          WHEN DATEDIFF(CURRENT_DATE(), c.DATAN5) / 30 >= 12 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 36  THEN "1 à 3 ans"
                          WHEN DATEDIFF(CURRENT_DATE(), c.DATAN5) / 30 >= 36 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 60  THEN "3 à 5 ans"
                          WHEN DATEDIFF(CURRENT_DATE(), c.DATAN5) / 30 >= 60 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 120  THEN "5 à 10 ans"
                          WHEN DATEDIFF(CURRENT_DATE(), c.DATAN5) / 30 >= 120 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 240  THEN "10 à 20 ans"
                          ELSE "Plus de 20 ans"
                       END as anciennete
                      FROM vw_ZY00 a JOIN vw_ZYWO b on a.NUDOSS = b.NUDOSS
                      JOIN vw_ZY19 c ON a.NUDOSS = c.NUDOSS             
                      """ 

// COMMAND ----------

// MAGIC %sql
// MAGIC --create database hrabackup_dmt_career

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC drop table if exists hrabackup_dmt_career.identification

// COMMAND ----------

// MAGIC %sql
// MAGIC --CREATE TABLE hrabackup_dmt_career.identification as 
// MAGIC select 
// MAGIC a.NUDOSS as numero_dossier,
// MAGIC a.MATCLE  as matricule_hra,
// MAGIC b.MATWOR as matricule_workday,
// MAGIC a.PRENOM as prenom_employe,
// MAGIC a.NOMUSE as nom_employe,
// MAGIC c.DATAN5 as date_anciennete,
// MAGIC CASE
// MAGIC     WHEN DATEDIFF(CURRENT_DATE(), c.DATAN5) / 30 < 6  THEN "Moins de 6 mois"
// MAGIC     WHEN DATEDIFF(CURRENT_DATE(), c.DATAN5) / 30 >= 6 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 12  THEN "Entre 6 mois et 1 an"
// MAGIC     WHEN DATEDIFF(CURRENT_DATE(), c.DATAN5) / 30 >= 12 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 36  THEN "1 à 3 ans"
// MAGIC     WHEN DATEDIFF(CURRENT_DATE(), c.DATAN5) / 30 >= 36 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 60  THEN "3 à 5 ans"
// MAGIC     WHEN DATEDIFF(CURRENT_DATE(), c.DATAN5) / 30 >= 60 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 120  THEN "5 à 10 ans"
// MAGIC     WHEN DATEDIFF(CURRENT_DATE(), c.DATAN5) / 30 >= 120 and  DATEDIFF(CURRENT_DATE(), DATAN5) / 30 < 240  THEN "10 à 20 ans"
// MAGIC     ELSE "Plus de 20 ans"
// MAGIC   END as anciennete
// MAGIC FROM vw_ZY00 a JOIN vw_ZYWO b on a.NUDOSS = b.NUDOSS
// MAGIC JOIN vw_ZY19 c ON a.NUDOSS = c.NUDOSS

// COMMAND ----------

val identification_inserted = spark.sql(query_record)
identification_inserted.cache()  //put the dataframe ont he cache 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.identification """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

identification_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.identification", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_ZY00_read.unpersist
df_ZYWO_read.unpersist
df_ZY19_read.unpersist
identification_inserted.unpersist

// COMMAND ----------

/*dbutils.notebook.exit(return_value)
