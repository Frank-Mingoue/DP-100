// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Read table Referentiel
val df_ref = spark.table("hrabackup_common.referentiel")
                                                      
df_ref.createOrReplaceTempView("vw_ref")
df_ref.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,read table ZYES
var df_zyes_read = spark.table(""" hrabackup_career.zyes """ )

df_zyes_read = gettranscoHRA(df_zyes_read, df_ref, "ZYES")  //get columns transco

df_zyes_read = df_zyes_read.select(col("NUDOSS").alias("numero_dossier"),
                                  col("DATENT").alias("date_entree"), 
                                  col("DATSOR").alias("date_sortie_administrative"), 
                                  col("IDCY00").alias("societe"))
                      
df_zyes_read.createOrReplaceTempView("zyes")
df_zyes_read.cache()

// COMMAND ----------

// DBTITLE 1,read table ZYCO
var df_zyco_read = spark.table("hrabackup_career.zyco" )

 df_zyco_read = gettranscoHRA(df_zyco_read, df_ref, "ZYCO")  //get columns transco

val df_zyco = df_zyco_read.select(col("NUDOSS").alias("numero_dossier"),
                                  col("DATCON").alias("date_debut_contrat"), 
                                  col("DATFIN").alias("date_fin_contrat"), 
                                  col("TYPCON").alias("type_contrat"), 
                                  col("NATCON").alias("nature"))
                      
df_zyco.createOrReplaceTempView("zyco") 
df_zyco.cache()

// COMMAND ----------

df_zyco.count()

// COMMAND ----------

// DBTITLE 1,Join ZYCO and ZYES
val query = """create or replace temporary view T1 as SELECT 
           case 
             when zyes.numero_dossier is not null then zyes.numero_dossier 
             else zyco.numero_dossier 
           end as numero_dossier
           ,zyes.date_entree
           ,zyes.date_sortie_administrative
           ,zyes.societe
           ,zyco.type_contrat
           ,zyco.nature
           ,case 
              when zyes.numero_dossier is null and zyco.numero_dossier is not null then zyco.date_debut_contrat
              when zyco.numero_dossier is null and zyes.numero_dossier is not null then zyes.date_entree
              when zyco.date_debut_contrat = zyes.date_entree then zyes.date_entree
              when zyco.date_debut_contrat < zyes.date_entree then zyes.date_entree
              when zyes.date_entree < zyco.date_debut_contrat then zyco.date_debut_contrat
            end as date_debut 

            ,case 
              when zyes.numero_dossier is null and zyco.numero_dossier is not null then zyco.date_fin_contrat
              when zyco.numero_dossier is null and zyes.numero_dossier is not null then zyes.date_sortie_administrative
              when zyco.date_fin_contrat = zyes.date_sortie_administrative then zyes.date_sortie_administrative
              when zyco.date_fin_contrat < zyes.date_sortie_administrative then zyco.date_fin_contrat
              when zyes.date_sortie_administrative < zyco.date_fin_contrat then zyes.date_sortie_administrative
            end as date_fin

          FROM  zyes 
          full join  zyco on zyes.numero_dossier = zyco.numero_dossier 
          and  (
          (zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative) 
          OR (zyco.date_debut_contrat < zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative and zyco.date_fin_contrat  > zyes.date_entree  ) 
          OR (zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat > zyes.date_sortie_administrative and zyco.date_debut_contrat <zyes.date_sortie_administrative)
          OR (zyco.date_debut_contrat <= zyes.date_entree and zyco.date_fin_contrat >= zyes.date_sortie_administrative ))
        """

spark.sql(query)

// COMMAND ----------

// DBTITLE 1,read table ZY38
var df_zy38 = spark.table("hrabackup_career.zy38" )

df_zy38 = gettranscoHRA(df_zy38, df_ref, "ZY38") //get columns transco  

df_zy38.createOrReplaceTempView("zy38")                      

spark.sql(""" create or replace temporary view zy38 as select              
                        NUDOSS as numero_dossier,
                        DTEF00 as date_debut, 
                        DTEN00 as date_fin, 
                        IDESTA as etablissement
                        FROM zy38
                      """ ) // rename columns 

df_zy38.cache() // cache dataframe

// COMMAND ----------

// DBTITLE 1,Add table ZY38
val query = """create or replace temporary view T2 as SELECT 
           case 
               when T1.numero_dossier is not null then T1.numero_dossier 
               else zy38.numero_dossier 
           end as numero_dossier
           ,T1.date_entree
           ,T1.date_sortie_administrative
           ,T1.societe
           ,T1.type_contrat
           ,T1.nature
           ,zy38.etablissement
           ,T1.date_debut as t1_date_debut
           ,T1.date_fin as t1_date_fin
           ,zy38.date_debut as zy38_date_debut
           ,zy38.date_fin as zy38_date_fin

           ,case 
                when zy38.numero_dossier is null and T1.numero_dossier is not null then T1.date_debut
                when T1.numero_dossier is null and zy38.numero_dossier is not null then zy38.date_debut
                when zy38.date_debut = T1.date_debut then T1.date_debut
                when zy38.date_debut < T1.date_debut then T1.date_debut
                when T1.date_debut < zy38.date_debut then zy38.date_debut
            end as date_debut 

            ,case 
                when zy38.numero_dossier is null and T1.numero_dossier is not null then T1.date_fin
                when T1.numero_dossier is null and zy38.numero_dossier is not null then zy38.date_fin
                when zy38.date_fin = T1.date_fin then T1.date_fin
                when zy38.date_fin < T1.date_fin then zy38.date_fin
                when T1.date_fin < zy38.date_fin then T1.date_fin
            end as date_fin

           from T1 
           full join  zy38 on zy38.numero_dossier = T1.numero_dossier
           and  (
          (zy38.date_debut >= T1.date_debut and zy38.date_fin <= T1.date_fin) 
          OR (zy38.date_debut < T1.date_debut and zy38.date_fin <= T1.date_fin and zy38.date_fin  > T1.date_debut) 
          OR (zy38.date_debut >= T1.date_debut and zy38.date_fin > T1.date_fin and zy38.date_debut < T1.date_fin)
          OR (zy38.date_debut <= T1.date_debut and zy38.date_fin >= T1.date_fin ) )
        """

spark.sql(query)

// COMMAND ----------

// DBTITLE 1,read table ZY3B
var df_zy3b = spark.table("hrabackup_career.zy3b")

df_zy3b = gettranscoHRA(df_zy3b, df_ref, "ZY3B")   //get  transco

df_zy3b.createOrReplaceTempView("zy3b")

spark.sql(""" create or replace temporary view zy3b as select              
                        NUDOSS as numero_dossier,
                        DTEF00 as date_effet, 
                        DTEN00 as date_fin,                     
                        IDOU00 as unite_organisationnelle
                        FROM zy3b
                      """ ) // rename columns
                      
df_zy3b.cache() 

// COMMAND ----------

// DBTITLE 1,JOIN table ZY3B
val query = """create or replace temporary view T3 as SELECT 
            case 
              when T2.numero_dossier is not null then T2.numero_dossier 
              else zy3b.numero_dossier 
           end as numero_dossier
           ,T2.date_entree
           ,T2.date_sortie_administrative
           ,T2.societe
           ,T2.type_contrat
           ,T2.nature
           ,T2.etablissement
           ,zy3b.unite_organisationnelle
           ,T2.date_debut as t2_date_debut
           ,T2.date_fin as t2_date_fin
           ,zy3b.date_effet as zy3b_date_effet
           ,zy3b.date_fin as zy3b_date_fin


           ,case 
            when zy3b.numero_dossier is null and T2.numero_dossier is not null then T2.date_debut
            when T2.numero_dossier is null and zy3b.numero_dossier is not null then zy3b.date_effet
            when zy3b.date_effet = T2.date_debut then T2.date_debut
            when zy3b.date_effet < T2.date_debut then T2.date_debut
            when T2.date_debut < zy3b.date_effet then zy3b.date_effet
            end as date_debut 

            ,case 
            when zy3b.numero_dossier is null and T2.numero_dossier is not null then T2.date_fin
            when T2.numero_dossier is null and zy3b.numero_dossier is not null then zy3b.date_fin
            when zy3b.date_fin = T2.date_fin then T2.date_fin
            when zy3b.date_fin < T2.date_fin then zy3b.date_fin
            when T2.date_fin < zy3b.date_fin then T2.date_fin
            end as date_fin


           from T2 
           full join  zy3b ON zy3b.numero_dossier = T2.numero_dossier
            and  (
          (zy3b.date_effet >= T2.date_debut and zy3b.date_fin <= T2.date_fin) 
          OR (zy3b.date_effet < T2.date_debut and zy3b.date_fin <= T2.date_fin and zy3b.date_fin  > T2.date_debut) 
          OR (zy3b.date_effet >= T2.date_debut and zy3b.date_fin > T2.date_fin and zy3b.date_effet < T2.date_fin)
          OR (zy3b.date_effet <= T2.date_debut and zy3b.date_fin >= T2.date_fin ) )
        """

spark.sql(query)

// COMMAND ----------

// DBTITLE 1,read table ZYCA
var df_zyca = spark.table("""hrabackup_career.zyca""" )

df_zyca = gettranscoHRA(df_zyca, df_ref, "ZYCA")  //get  transco

df_zyca.createOrReplaceTempView("zyca")

spark.sql(""" create or replace temporary view zyca as select              
                        NUDOSS as numero_dossier,
                        DATEFF as date_debut, 
                        DATFIN as date_fin,
                        QUALIF as qualification, 
                        CLASSI as classification,
                        COCONV as code_convention_collective
                        FROM zyca
                      """ )

df_zyca.cache()

// COMMAND ----------

// DBTITLE 1,Join table ZYCA
val query = """create or replace temporary view T4 as SELECT 
           case 
              when T3.numero_dossier is not null then T3.numero_dossier 
              else zyca.numero_dossier 
           end as numero_dossier
           ,T3.date_entree
           ,T3.date_sortie_administrative
           ,T3.societe
           ,T3.type_contrat
           ,T3.nature
           ,T3.etablissement
           ,T3.unite_organisationnelle
           ,zyca.classification
           ,zyca.qualification
           ,zyca.code_convention_collective
           ,T3.date_debut as t3_date_debut
           ,T3.date_fin as t3_date_fin
           ,zyca.date_debut as zyca_date_debut
           ,zyca.date_fin as zyca_date_fin

            ,case 
              when zyca.numero_dossier is null and T3.numero_dossier is not null then T3.date_debut
              when T3.numero_dossier is null and zyca.numero_dossier is not null then zyca.date_debut
              when zyca.date_debut = T3.date_debut then T3.date_debut
              when zyca.date_debut < T3.date_debut then T3.date_debut
              when T3.date_debut < zyca.date_debut then zyca.date_debut
            end as date_debut 

            ,case 
              when zyca.numero_dossier is null and T3.numero_dossier is not null then T3.date_fin
              when T3.numero_dossier is null and zyca.numero_dossier is not null then zyca.date_fin
              when zyca.date_fin = T3.date_fin then T3.date_fin
              when zyca.date_fin < T3.date_fin then zyca.date_fin
              when T3.date_fin < zyca.date_fin then T3.date_fin
            end as date_fin

           from T3 
           full join  zyca on zyca.numero_dossier = T3.numero_dossier
             and  (
          (zyca.date_debut >= T3.date_debut and zyca.date_fin <= T3.date_fin) 
          OR (zyca.date_debut < T3.date_debut and zyca.date_fin <= T3.date_fin and zyca.date_fin  > T3.date_debut) 
          OR (zyca.date_debut >= T3.date_debut and zyca.date_fin > T3.date_fin and zyca.date_debut < T3.date_fin)
          OR (zyca.date_debut <= T3.date_debut and zyca.date_fin >= T3.date_fin ) )
        """

spark.sql(query)

// COMMAND ----------

// DBTITLE 1,read table ZYTL
var df_zytl = spark.table(""" hrabackup_career.zytl """ )

df_zytl = gettranscoHRA(df_zytl, df_ref, "ZYTL")  //get  transco

df_zytl.createOrReplaceTempView("zytl")

spark.sql(""" create or replace temporary view zytl as select              
                        NUDOSS as numero_dossier,
                        DATEFF as date_effet, 
                        CODTRA as type_temps_contractuel,  
                        NBSTHM as heures_presencemois,
                        coalesce (Lead(date_add (DATEFF, -1)) over (partition by NUDOSS order by DATEFF), '2999-12-31') as date_fin
                        FROM zytl
                      """ )                      
 
df_zytl.cache()

// COMMAND ----------

// DBTITLE 1,Join table ZYTL
val query = """create or replace temporary view T5 as SELECT 
            case 
              when T4.numero_dossier is not null then T4.numero_dossier 
              else zytl.numero_dossier 
            end as numero_dossier
           ,T4.date_entree
           ,T4.date_sortie_administrative
           ,T4.societe
           ,T4.type_contrat
           ,T4.nature
           ,T4.etablissement
           ,T4.unite_organisationnelle
           ,T4.classification
           ,T4.qualification 
           ,T4.code_convention_collective 
           ,T4.date_debut as t4_date_debut
           ,T4.date_fin as t4_date_fin
           ,zytl.date_effet as zytl_date_debut
           ,zytl.date_fin as zytl_date_fin
           ,zytl.type_temps_contractuel
           ,zytl.heures_presencemois

           ,case 
            when zytl.numero_dossier is null and T4.numero_dossier is not null then T4.date_debut
            when T4.numero_dossier is null and zytl.numero_dossier is not null then zytl.date_effet
            when zytl.date_effet = T4.date_debut then T4.date_debut
            when zytl.date_effet < T4.date_debut then T4.date_debut
            when T4.date_debut < zytl.date_effet then zytl.date_effet
            end as date_debut 

            ,case 
            when zytl.numero_dossier is null and T4.numero_dossier is not null then T4.date_fin
            when T4.numero_dossier is null and zytl.numero_dossier is not null then zytl.date_fin
            when zytl.date_fin = T4.date_fin then T4.date_fin
            when zytl.date_fin < T4.date_fin then zytl.date_fin
            when T4.date_fin < zytl.date_fin then T4.date_fin
            end as date_fin

           FROM T4 
           left join zytl on zytl.numero_dossier = T4.numero_dossier
           and  (
          (zytl.date_effet >= T4.date_debut and zytl.date_fin <= T4.date_fin) 
          OR (zytl.date_effet < T4.date_debut and zytl.date_fin <= T4.date_fin and zytl.date_fin  > T4.date_debut) 
          OR (zytl.date_effet >= T4.date_debut and zytl.date_fin > T4.date_fin and zytl.date_effet < T4.date_fin)
          OR (zytl.date_effet <= T4.date_debut and zytl.date_fin >= T4.date_fin ) )
        """

spark.sql(query)

// COMMAND ----------

// DBTITLE 1,check consecutives rows 
val query = """create or replace temporary view filtres as ( 
                       select                      
                         numero_dossier
                       ,date_entree
                       ,date_sortie_administrative 
                       ,societe
                       ,type_contrat
                       ,nature
                       ,etablissement
                       ,unite_organisationnelle
                       ,classification
                       ,qualification 
                       ,code_convention_collective
                       ,type_temps_contractuel
                       ,heures_presencemois
                       ,date_debut
                       ,date_fin
                       ,ROW_NUMBER () over ( order by numero_dossier, date_debut) - ROW_NUMBER () over (order by numero_dossier ,date_entree ,date_sortie_administrative, societe ,type_contrat ,nature ,etablissement ,unite_organisationnelle ,classification ,qualification  ,type_temps_contractuel ,heures_presencemois, date_debut) as consecutive
                       FROM T5  )                    
        """

spark.sql(query)

// COMMAND ----------

// DBTITLE 1,group consecutives rows
val query = """create or replace temporary view filtres as ( 
                       select
                        numero_dossier
                       ,date_entree
                       ,date_sortie_administrative
                       ,societe
                       ,type_contrat
                       ,nature
                       ,etablissement
                       ,unite_organisationnelle
                       ,classification
                       ,qualification 
                       ,code_convention_collective
                       ,type_temps_contractuel
                       ,heures_presencemois
                       ,consecutive
                       ,MIN(date_debut) as date_debut
                       ,MAX(date_fin) as date_fin
                       from filtres
                       group by numero_dossier
                       ,date_entree
                       ,date_sortie_administrative
                       ,societe
                       ,type_contrat
                       ,nature
                       ,etablissement
                       ,unite_organisationnelle
                       ,classification
                       ,qualification 
                       ,code_convention_collective
                       ,type_temps_contractuel
                       ,heures_presencemois
                       ,consecutive)                    
        """

spark.sql(query)

// COMMAND ----------

// DBTITLE 1,final table 
val query = """create or replace temporary view filtres as ( 
                       select
                        numero_dossier
                       ,date_entree
                       ,date_sortie_administrative
                       ,coalesce (societe,' ') as societe
                       ,coalesce (type_contrat,' ') as type_contrat
                       ,coalesce (nature,' ') as nature
                       ,coalesce (etablissement,' ') as etablissement
                       ,coalesce (unite_organisationnelle,' ') as unite_organisationnelle
                       ,coalesce (classification,' ') as classification
                       ,coalesce (qualification,' ') as qualification
                       ,coalesce (code_convention_collective,' ') as code_convention_collective
                       ,coalesce (type_temps_contractuel,' ') as type_temps_contractuel
                       ,heures_presencemois
                       ,date_debut as date_debut_filtre
                       ,date_fin as date_fin_filtre
                       from filtres
                       )                    
        """

spark.sql(query)

// COMMAND ----------

var df_filtres = spark.sql("select * from filtres")

// COMMAND ----------

// MAGIC %sql 
// MAGIC select * 
// MAGIC from  filtres 
// MAGIC order by numero_dossier, date_debut_filtre 

// COMMAND ----------

// MAGIC %sql 
// MAGIC select count(*)
// MAGIC from  filtres 
// MAGIC -- order by numero_dossier, date_debut_filtre 

// COMMAND ----------

// MAGIC %sql 
// MAGIC  select 
// MAGIC   max(length(societe)) 
// MAGIC  ,max(length(type_contrat)) 
// MAGIC  ,max(length(etablissement)) 
// MAGIC  ,max(length(unite_organisationnelle)) 
// MAGIC  ,max(length(classification)) 
// MAGIC  ,max(length(qualification)) 
// MAGIC  ,max(length(code_convention_collective))  
// MAGIC  ,max(length(nature))  
// MAGIC  ,max(length(type_temps_contractuel))  
// MAGIC  from  filtres 
// MAGIC  -- order by numero_dossier, date_debut_filtre// %sql 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.filtres """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

df_filtres.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.filtres", connectionproperties)

// COMMAND ----------

df_zyes.unpersist
df_zyco.unpersist
df_zy38.unpersist
df_zy3b.unpersist
df_zyca.unpersist
df_zytl.unpersist
df_ref.unpersist

// COMMAND ----------


