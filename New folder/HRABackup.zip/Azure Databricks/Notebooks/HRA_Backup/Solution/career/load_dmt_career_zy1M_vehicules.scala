// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")  
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.ZY1M table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZY1M_read = spark.table("hrabackup_career.ZY1M")

//find and get column labels
df_ZY1M_read = gettranscoHRA(df_ZY1M_read, df_ref_read, "ZY1M")
                                                      
df_ZY1M_read.createOrReplaceTempView("vw_ZY1M")
df_ZY1M_read.cache()  //cache the dataframe

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.filtres", connectionproperties).createOrReplaceTempView("filtres")


// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.identification", connectionproperties).createOrReplaceTempView("identification")


// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC    select 
// MAGIC    a.NUDOSS as numero_dossier
// MAGIC   ,a.IMMAT as numero_immatriculation
// MAGIC   ,a.IDCTRY as pays 
// MAGIC   ,a.DATDEB as date_debut 
// MAGIC   ,a.DATFIN as date_fin 
// MAGIC   ,a.DATIMM as date_immatriculation 
// MAGIC   ,a.PUISVH as puissance_vehicule 
// MAGIC   ,a.TYPEVH as type_vehicule 
// MAGIC   ,a.CONSTR as constructeur 
// MAGIC   ,a.MODELE as modele 
// MAGIC   ,a.CYLIND as cylindree 
// MAGIC   ,a.FUELTY as carburant
// MAGIC   ,a.VALUE as valeur_vehicule 
// MAGIC   ,b.date_entree
// MAGIC   ,b.date_sortie_administrative  
// MAGIC   ,b.type_contrat
// MAGIC   ,b.nature
// MAGIC   ,b.etablissement
// MAGIC   ,b.unite_organisationnelle
// MAGIC   ,b.classification
// MAGIC   ,b.qualification 
// MAGIC   ,b.code_convention_collective
// MAGIC   ,b.type_temps_contractuel
// MAGIC   ,b.heures_presencemois
// MAGIC   ,b.societe
// MAGIC   ,c.matricule_hra
// MAGIC   ,c.matricule_workday
// MAGIC   ,c.prenom_employe
// MAGIC   ,c.nom_employe
// MAGIC   ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
// MAGIC   ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre
// MAGIC   
// MAGIC   from vw_ZY1M a
// MAGIC   left join filtres b on b.numero_dossier = a.NUDOSS 
// MAGIC   and join_conditionHRA(a.DATDEB, a.DATFIN, b.date_debut_filtre, b.date_fin_filtre)
// MAGIC   left join identification c on c.numero_dossier = a.NUDOSS
// MAGIC  
// MAGIC   order by numero_dossier, date_debut_filtre
// MAGIC   

// COMMAND ----------

val query_record = """

  select 
   a.NUDOSS as numero_dossier
  ,a.IMMAT as numero_immatriculation
  ,a.IDCTRY as pays 
  ,a.DATDEB as date_debut 
  ,a.DATFIN as date_fin 
  ,a.DATIMM as date_immatriculation 
  ,a.PUISVH as puissance_vehicule 
  ,a.TYPEVH as type_vehicule 
  ,a.CONSTR as constructeur 
  ,a.MODELE as modele 
  ,a.CYLIND as cylindree 
  ,a.FUELTY as carburant
  ,a.VALUE as valeur_vehicule 
  ,b.date_entree
  ,b.date_sortie_administrative  
  ,b.type_contrat
  ,b.nature
  ,b.etablissement
  ,b.unite_organisationnelle
  ,b.classification
  ,b.qualification 
  ,b.code_convention_collective
  ,b.type_temps_contractuel
  ,b.heures_presencemois
  ,b.societe
  ,c.matricule_hra
  ,c.matricule_workday
  ,c.prenom_employe
  ,c.nom_employe
  ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
  ,get_dateHRA(a.DATDEB, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre
  
  from vw_ZY1M a
  left join filtres b on b.numero_dossier = a.NUDOSS 
  and join_conditionHRA(a.DATDEB, a.DATFIN, b.date_debut_filtre, b.date_fin_filtre)
  left join identification c on c.numero_dossier = a.NUDOSS
 
  order by numero_dossier, date_debut_filtre
  
 """ 

// COMMAND ----------

val ZY1M_inserted = spark.sql(query_record)
ZY1M_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.ZY1M_vehicules """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

ZY1M_inserted.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.ZY1M_vehicules", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
ZY1M_inserted.unpersist
df_ZY1M_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)
