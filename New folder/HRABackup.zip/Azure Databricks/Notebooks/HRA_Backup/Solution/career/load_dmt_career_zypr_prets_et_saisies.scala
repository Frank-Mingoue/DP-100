// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zy24  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_table_read = spark.table("hrabackup_career.ZYPR")

//find and get column labels
df_table_read = gettranscoHRA(df_table_read, df_ref_read, "ZYPR")
                                                      
df_table_read.createOrReplaceTempView("vw_table")
df_table_read.cache()  //cache the dataframe

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.filtres", connectionproperties).createOrReplaceTempView("filtres")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.identification", connectionproperties).createOrReplaceTempView("identification")


// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select   
// MAGIC    a.NUDOSS as numero_dossier
// MAGIC   ,a.NUDOSP as ident_dossier_paie 
// MAGIC   ,a.RUBPRE as rubrique 
// MAGIC   ,a.ORDPRE as ordre_calcul 
// MAGIC   ,a.NUMPRE as numero_pret 
// MAGIC   ,a.MONPR as montant_initial 
// MAGIC   ,a.DEBPRE as date_debut 
// MAGIC   ,a.FINPRE as date_fin 
// MAGIC   ,a.ECHPRE as nombre_echeances 
// MAGIC   ,a.MENPR as mensualite 
// MAGIC   ,a.SOLPR as solde 
// MAGIC   ,a.TXINTE as taux_interet
// MAGIC   ,a.MTINT as montant_interet
// MAGIC   ,a.DTCONC as date_concession
// MAGIC   ,b.date_entree
// MAGIC   ,b.date_sortie_administrative  
// MAGIC   ,b.type_contrat
// MAGIC   ,b.nature
// MAGIC   ,b.etablissement
// MAGIC   ,b.unite_organisationnelle
// MAGIC   ,b.classification
// MAGIC   ,b.qualification 
// MAGIC   ,b.code_convention_collective
// MAGIC   ,b.type_temps_contractuel
// MAGIC   ,b.heures_presencemois
// MAGIC   ,b.societe
// MAGIC   ,c.matricule_hra
// MAGIC   ,c.matricule_workday
// MAGIC   ,c.prenom_employe
// MAGIC   ,c.nom_employe
// MAGIC   ,get_dateHRA(a.DEBPRE, coalesce(a.FINPRE,a.DEBPRE), a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
// MAGIC   ,get_dateHRA(a.DEBPRE, coalesce(a.FINPRE,a.DEBPRE), a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre
// MAGIC   
// MAGIC   
// MAGIC   
// MAGIC   from vw_table a
// MAGIC   
// MAGIC   left join filtres b on b.numero_dossier = a.NUDOSS 
// MAGIC   and join_conditionHRA(a.DEBPRE, coalesce(a.FINPRE,a.DEBPRE), b.date_debut_filtre, b.date_fin_filtre)  
// MAGIC   left join identification c on c.numero_dossier = a.NUDOSS
// MAGIC 
// MAGIC   order by numero_dossier, date_debut_filtre
// MAGIC   

// COMMAND ----------

val query_record = """

  select   
   a.NUDOSS as numero_dossier
  ,a.NUDOSP as ident_dossier_paie 
  ,a.RUBPRE as rubrique 
  ,a.ORDPRE as ordre_calcul 
  ,a.NUMPRE as numero_pret 
  ,a.MONPR as montant_initial 
  ,a.DEBPRE as date_debut 
  ,a.FINPRE as date_fin 
  ,a.ECHPRE as nombre_echeances 
  ,a.MENPR as mensualite 
  ,a.SOLPR as solde 
  ,a.TXINTE as taux_interet
  ,a.MTINT as montant_interet
  ,a.DTCONC as date_concession
  ,b.date_entree
  ,b.date_sortie_administrative  
  ,b.type_contrat
  ,b.nature
  ,b.etablissement
  ,b.unite_organisationnelle
  ,b.classification
  ,b.qualification 
  ,b.code_convention_collective
  ,b.type_temps_contractuel
  ,b.heures_presencemois
  ,b.societe
  ,c.matricule_hra
  ,c.matricule_workday
  ,c.prenom_employe
  ,c.nom_employe
  ,get_dateHRA(a.DEBPRE, coalesce(a.FINPRE,a.DEBPRE), a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
  ,get_dateHRA(a.DEBPRE, coalesce(a.FINPRE,a.DEBPRE), a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre
  
  
  
  from vw_table a
  
  left join filtres b on b.numero_dossier = a.NUDOSS 
  and join_conditionHRA(a.DEBPRE, coalesce(a.FINPRE,a.DEBPRE), b.date_debut_filtre, b.date_fin_filtre)  
  left join identification c on c.numero_dossier = a.NUDOSS

  order by numero_dossier, date_debut_filtre
 """ 

// COMMAND ----------

val table_inserted = spark.sql(query_record)
table_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.ZYPR_prets_et_saisies """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

table_inserted.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.ZYPR_prets_et_saisies", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
table_inserted.unpersist
df_table_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)
