﻿CREATE TABLE [pay].[ZX37_affectations_geographiques] (
    [numero_dossier]        INT           NULL,
    [etablissement]         VARCHAR (MAX) NULL,
    [libelle_etablissement] VARCHAR (45)  NULL,
    [direction]             VARCHAR (10)  NULL,
    [service]               VARCHAR (10)  NULL,
    [section]               VARCHAR (10)  NULL,
    [sous_section]          VARCHAR (10)  NULL,
    [periode_paie]          VARCHAR (8)   NULL
);





