﻿CREATE TABLE [pay].[ZX38_carriere] (
    [numero_dossier]                   INT           NULL,
    [qualification]                    VARCHAR (8)   NULL,
    [classification]                   VARCHAR (8)   NULL,
    [libelle_statut]                   VARCHAR (45)  NULL,
    [libelle_la_classification]        VARCHAR (45)  NULL,
    [code_convention_collective]       VARCHAR (8)   NULL,
    [regime_special_cotisation]        VARCHAR (MAX) NULL,
    [libelle_la_convention_collective] VARCHAR (45)  NULL,
    [periode_paie]                     VARCHAR (8)   NULL
);



