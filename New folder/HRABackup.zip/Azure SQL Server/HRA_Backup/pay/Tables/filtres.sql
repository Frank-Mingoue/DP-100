﻿CREATE TABLE [pay].[filtres] (
    [numero_dossier]           INT            NULL,
    [matricule_hra]            VARCHAR (12)   NULL,
    [matricule_WD]             VARCHAR (40)   NULL,
    [nom_salarie]              VARCHAR (40)   NULL,
    [prenom_salarie]           VARCHAR (30)   NULL,
    [date_entree]              DATE           NULL,
    [date_sortie]              DATE           NULL,
    [etablissement]            VARCHAR (MAX)  NULL,
    [code_convention_CCN]      VARCHAR (MAX)  NULL,
    [date_anciennete]          DATE           NULL,
    [anciennete]               VARCHAR (25)   NULL,
    [qualification]            VARCHAR (MAX)  NULL,
    [classification]           VARCHAR (MAX)  NULL,
    [type_contrat]             VARCHAR (MAX)  NULL,
    [nature_contrat]           VARCHAR (MAX)  NULL,
    [type_temps_contractuel]   VARCHAR (MAX)  NULL,
    [heures_presence_mois]     DECIMAL (5, 2) NULL,
    [periode_paie]             VARCHAR (8)    NULL,
    [identifiant_dossier_paie] INT            NULL,
    [numero_bulletin]          VARCHAR (2)    NULL,
    [type_paie]                VARCHAR (1)    NULL,
    [societe]                  VARCHAR (MAX)  NULL
);







