﻿CREATE TABLE [pay].[ZXMM_dsn_montants] (
    [numero_dossier]                  INT             NULL,
    [code_compteur_n]                 VARCHAR (MAX)   NULL,
    [code_element_remuneration]       VARCHAR (MAX)   NULL,
    [source]                          VARCHAR (1)     NULL,
    [zone_cible_n]                    VARCHAR (10)    NULL,
    [categorie_compteur_n]            VARCHAR (3)     NULL,
    [valeur_typecode_structure_n]     VARCHAR (4)     NULL,
    [montant_ou_mesure]               DECIMAL (13, 4) NULL,
    [nbre_heures_ou_montant_assiette] DECIMAL (13, 4) NULL,
    [taux]                            DECIMAL (13, 4) NULL,
    [date_1]                          DATE            NULL,
    [date_2]                          DATE            NULL,
    [date_debut_la_periode_origine]   DATE            NULL,
    [date_fin_la_periode_origine]     DATE            NULL,
    [id_ops_destinataire]             VARCHAR (14)    NULL,
    [type_organisme]                  VARCHAR (MAX)   NULL,
    [qualifiant_assiette]             VARCHAR (3)     NULL,
    [code_insee_commune]              VARCHAR (5)     NULL,
    [taux_cotis_effectif_a_cumulere]  DECIMAL (13, 4) NULL,
    [code_affiliation_prev]           VARCHAR (10)    NULL,
    [periode_paie]                    VARCHAR (8)     NULL
) ON [myMonthlyRangePS] ([periode_paie]);








GO
CREATE CLUSTERED INDEX [ZXMM]
    ON [pay].[ZXMM_dsn_montants]([numero_dossier] ASC)
    ON [myMonthlyRangePS] ([periode_paie]);

