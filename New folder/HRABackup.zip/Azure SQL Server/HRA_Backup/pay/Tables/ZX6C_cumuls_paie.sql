CREATE TABLE [pay].[ZX6C_cumuls_paie] (
    [numero_dossier]      INT             NULL,
    [numero_cumul]        VARCHAR (MAX)   NULL,
    [periode_debut_cumul] VARCHAR (6)     NULL,
    [libelle_cumul]       VARCHAR (45)    NULL,
    [montant_cumul]       DECIMAL (15, 4) NULL,
    [periode_paie]        VARCHAR (8)     NULL
) ON [myMonthlyRangePS] ([periode_paie]);






GO
CREATE CLUSTERED INDEX [ZX6C]
    ON [pay].[ZX6C_cumuls_paie]([numero_dossier] ASC)
    ON [myMonthlyRangePS] ([periode_paie]);

