﻿CREATE TABLE [pay].[ZX40_heures_contractuelles] (
    [numero_dossier]                 INT            NULL,
    [date_effet]                     DATE           NULL,
    [type_temps_contractuel]         VARCHAR (2)    NULL,
    [libelle_type_temps_contractuel] VARCHAR (45)   NULL,
    [heures_presencejour]            DECIMAL (4, 2) NULL,
    [heures_presencesemaine]         DECIMAL (4, 2) NULL,
    [heures_presencemois]            DECIMAL (5, 2) NULL,
    [pourc_h_presencetemps_plein]    DECIMAL (5, 2) NULL,
    [heures_payeesjour]              DECIMAL (4, 2) NULL,
    [heures_payeessemaine]           DECIMAL (4, 2) NULL,
    [heures_payeesmois]              DECIMAL (5, 2) NULL,
    [pourc_h_payeestemps_plein]      DECIMAL (5, 2) NULL,
    [forfait_annuel_en_jours]        INT            NULL,
    [forfait_annuel_heures]          DECIMAL (6, 2) NULL,
    [periode_paie]                   VARCHAR (8)    NULL
);

