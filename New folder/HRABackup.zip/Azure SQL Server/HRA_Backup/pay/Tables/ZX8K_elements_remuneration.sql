CREATE TABLE [pay].[ZX8K_elements_remuneration] (
    [numero_dossier]                      INT             NULL,
    [code_element_remuneration]           VARCHAR (3)     NULL,
    [periode_valorisation]                INT             NULL,
    [date]                                DATE            NULL,
    [rappel_automatique]                  VARCHAR (1)     NULL,
    [source]                              VARCHAR (1)     NULL,
    [code_calcul]                         VARCHAR (1)     NULL,
    [libelle_element_remuneration]        VARCHAR (45)    NULL,
    [nombre_ou_base]                      DECIMAL (13, 4) NULL,
    [taux_salarial]                       DECIMAL (13, 4) NULL,
    [montant_salarial]                    DECIMAL (13, 4) NULL,
    [taux_patronal]                       DECIMAL (13, 4) NULL,
    [montant_patronal]                    DECIMAL (13, 4) NULL,
    [imputation]                          VARCHAR (24)    NULL,
    [zone_utilisateur]                    VARCHAR (20)    NULL,
    [code_absence]                        VARCHAR (3)     NULL,
    [date_debut_absence]                  DATE            NULL,
    [date_fin_absence]                    DATE            NULL,
    [memo_01]                             VARCHAR (15)    NULL,
    [memo_02]                             VARCHAR (15)    NULL,
    [memo_03]                             VARCHAR (8)     NULL,
    [memo_04]                             VARCHAR (8)     NULL,
    [memo_05]                             VARCHAR (5)     NULL,
    [memo_06]                             VARCHAR (5)     NULL,
    [memo_07]                             VARCHAR (5)     NULL,
    [memo_08]                             VARCHAR (5)     NULL,
    [memo_09]                             VARCHAR (3)     NULL,
    [memo_10]                             VARCHAR (3)     NULL,
    [memo_11]                             VARCHAR (3)     NULL,
    [code_organisme]                      VARCHAR (15)    NULL,
    [libelle_organisme]                   VARCHAR (45)    NULL,
    [qualifiant_numero_1]                 VARCHAR (15)    NULL,
    [qualifiant_numero_2]                 VARCHAR (15)    NULL,
    [qualifiant_numero_3]                 VARCHAR (15)    NULL,
    [qualifiant_numero_4]                 VARCHAR (15)    NULL,
    [qualifiant_numero_5]                 VARCHAR (15)    NULL,
    [qualifiant_numero_6]                 VARCHAR (15)    NULL,
    [qualifiant_numero_7]                 VARCHAR (15)    NULL,
    [qualifiant_numero_8]                 VARCHAR (15)    NULL,
    [bas_tableau]                         VARCHAR (1)     NULL,
    [position_dans_le_journal_paie]       VARCHAR (2)     NULL,
    [alimentation_colonne_nombre_ou_base] VARCHAR (1)     NULL,
    [nb_decimales_colonne_nombre_ou_base] INT             NULL,
    [alimentation_la_colonne_taux]        VARCHAR (1)     NULL,
    [colonne_montant]                     VARCHAR (1)     NULL,
    [position_rubrique_sur_bulletin]      VARCHAR (2)     NULL,
    [position_rubrique_sur_fiche_annexe]  VARCHAR (2)     NULL,
    [position_rubrique_sur_fiche_euro]    VARCHAR (2)     NULL,
    [periode_paie]                        VARCHAR (8)     NULL
);








GO
CREATE CLUSTERED INDEX [ZX8K_nudoss_codrub]
    ON [pay].[ZX8K_elements_remuneration]([numero_dossier] ASC, [code_element_remuneration] ASC);

