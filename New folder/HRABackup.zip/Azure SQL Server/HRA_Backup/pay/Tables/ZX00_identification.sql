﻿CREATE TABLE [pay].[ZX00_identification] (
    [numero_dossier]           INT           NULL,
    [reglementation]           VARCHAR (MAX) NULL,
    [identification]           VARCHAR (10)  NULL,
    [identifiant_dossier_paie] INT           NULL,
    [periode_paie]             VARCHAR (8)   NULL,
    [numero_bulletin]          VARCHAR (2)   NULL,
    [type_paie]                VARCHAR (1)   NULL,
    [nom_salarie]              VARCHAR (40)  NULL,
    [horodatage_chargement]    DATE          NULL
);



