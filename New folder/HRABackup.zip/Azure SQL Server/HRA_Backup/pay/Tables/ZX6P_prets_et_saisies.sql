﻿CREATE TABLE [pay].[ZX6P_prets_et_saisies] (
    [numero_dossier]         INT            NULL,
    [code_rubrique]          VARCHAR (3)    NULL,
    [numero_ordre]           INT            NULL,
    [numero_pret]            VARCHAR (17)   NULL,
    [libelle_la_rubrique]    VARCHAR (45)   NULL,
    [montant_initial]        INT            NULL,
    [date_debut]             DATE           NULL,
    [date_fin]               DATE           NULL,
    [nombre_echeances]       INT            NULL,
    [montant_une_mensualite] INT            NULL,
    [solde]                  INT            NULL,
    [taux_interet]           DECIMAL (5, 2) NULL,
    [montants_des_interets]  INT            NULL,
    [date_concession]        DATE           NULL,
    [date_virement_capital]  DATE           NULL,
    [capital_non_amorti]     INT            NULL,
    [solde_avant_paie]       INT            NULL,
    [periode_paie]           VARCHAR (8)    NULL
);

