CREATE TABLE [pay].[ZX3B_conges_payes] (
    [numero_dossier]           INT            NULL,
    [code_conge]               VARCHAR (MAX)  NULL,
    [annee_reference]          DATE           NULL,
    [identifiant_entreesortie] INT            NULL,
    [date_debut_consommation]  DATE           NULL,
    [date_fin_consommation]    DATE           NULL,
    [date_debut_acquisition]   DATE           NULL,
    [date_fin_acquisition]     DATE           NULL,
    [droits_acquis]            DECIMAL (5, 2) NULL,
    [droits_pris]              DECIMAL (5, 2) NULL,
    [droits_restants]          DECIMAL (5, 2) NULL,
    [periode_paie]             VARCHAR (8)    NULL
) ON [myMonthlyRangePS] ([periode_paie]);






GO
CREATE CLUSTERED INDEX [ZX3B]
    ON [pay].[ZX3B_conges_payes]([numero_dossier] ASC)
    ON [myMonthlyRangePS] ([periode_paie]);

