﻿CREATE TABLE [pay].[ZXM7_compte_epargne] (
    [numero_dossier]              INT            NULL,
    [type_compte]                 VARCHAR (MAX)  NULL,
    [date_ouverture]              DATE           NULL,
    [date_fermeture]              DATE           NULL,
    [solde_compte]                DECIMAL (7, 4) NULL,
    [solde_temps_plein]           DECIMAL (7, 4) NULL,
    [solde_en_heures_temps_plein] INT            NULL,
    [date_utilisation]            DATE           NULL,
    [date_fin_utilisation]        DATE           NULL,
    [periode_paie]                VARCHAR (8)    NULL
);



