﻿CREATE TABLE [pay].[ZX5V_statut_dossier] (
    [numero_dossier]      INT         NULL,
    [temoin_validite]     VARCHAR (1) NULL,
    [horodatage_validite] DATE        NULL,
    [periode_paie]        VARCHAR (8) NULL
);

