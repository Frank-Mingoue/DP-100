﻿CREATE TABLE [pay].[ZX6A_absences] (
    [numero_dossier]                   INT          NULL,
    [date_debut_absence]               DATE         NULL,
    [identifiant_element_remuneration] VARCHAR (12) NULL,
    [code_absence]                     VARCHAR (3)  NULL,
    [source_absence]                   VARCHAR (1)  NULL,
    [libelle_absence]                  VARCHAR (45) NULL,
    [date_fin_absence]                 DATE         NULL,
    [periode_paie]                     VARCHAR (8)  NULL
);

