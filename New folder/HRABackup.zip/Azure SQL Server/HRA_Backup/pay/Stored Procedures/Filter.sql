﻿




-- =============================================
-- Author:  Frank Mingoué
-- Create Date: 17-10-2022
-- Description: generate filter based on fields 
-- =============================================
CREATE PROCEDURE [pay].[Filter]
( 
  @prenom_employe varchar(50),
  @nom_employe varchar(50),
  @matricule_hra varchar(50),  
  @matricule_wd varchar(50)
)
    
AS

BEGIN 

  

 

  IF @prenom_employe = '' AND  @nom_employe != '' AND @matricule_hra = '' AND @matricule_wd = '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [nom_salarie] LIKE '%'+ @nom_employe +'%' 
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe = '' AND  @nom_employe = '' AND @matricule_hra != '' AND @matricule_wd = '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [matricule_hra] LIKE '%'+ @matricule_hra +'%' 
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe = '' AND  @nom_employe = '' AND @matricule_hra = '' AND @matricule_wd != '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [matricule_WD] LIKE '%'+ @matricule_wd +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe = '' AND @matricule_hra = '' AND @matricule_wd = '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [prenom_salarie]  LIKE '%'+ @prenom_employe +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe != '' AND @matricule_hra = '' AND @matricule_wd = '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [prenom_salarie]  LIKE '%'+ @prenom_employe +'%' AND [nom_salarie] LIKE '%'+ @nom_employe +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe != '' AND @matricule_hra != '' AND @matricule_wd = '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [prenom_salarie]  LIKE '%'+ @prenom_employe +'%' AND [nom_salarie] LIKE '%'+ @nom_employe +'%' 
	  AND [matricule_hra] LIKE '%'+ @matricule_hra +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe = '' AND @matricule_hra != '' AND @matricule_wd = '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [prenom_salarie]  LIKE '%'+ @prenom_employe +'%' AND [matricule_hra] LIKE '%'+ @matricule_hra +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe = '' AND @matricule_hra = '' AND @matricule_wd != '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [prenom_salarie]  LIKE '%'+ @prenom_employe +'%' AND [matricule_WD] LIKE '%'+ @matricule_wd +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe = '' AND  @nom_employe = '' AND @matricule_hra != '' AND @matricule_wd != '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [matricule_hra] LIKE '%'+ @matricule_hra +'%' AND [matricule_WD] LIKE '%'+ @matricule_wd +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe = '' AND @matricule_hra != '' AND @matricule_wd != '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [matricule_hra] LIKE '%'+ @matricule_hra +'%' AND [matricule_WD] LIKE '%'+ @matricule_wd +'%'
	  AND [prenom_salarie]  LIKE '%'+ @prenom_employe +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe = '' AND  @nom_employe != '' AND @matricule_hra != '' AND @matricule_wd != '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [matricule_hra] LIKE '%'+ @matricule_hra +'%' AND [matricule_WD] LIKE '%'+ @matricule_wd +'%'
	  AND [nom_salarie] LIKE '%'+ @nom_employe +'%' 
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe = '' AND  @nom_employe != '' AND @matricule_hra != '' AND @matricule_wd = '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [matricule_hra] LIKE '%'+ @matricule_hra +'%' AND [nom_salarie] LIKE '%'+ @nom_employe +'%' 
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe != '' AND @matricule_hra = '' AND @matricule_wd != '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [prenom_salarie]  LIKE '%'+ @prenom_employe +'%' AND [matricule_WD] LIKE '%'+ @matricule_wd +'%'
	  AND [nom_salarie] LIKE '%'+ @nom_employe +'%' 
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe != '' AND @matricule_hra != '' AND @matricule_wd = '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [prenom_salarie]  LIKE '%'+ @prenom_employe +'%' AND [matricule_hra] LIKE '%'+ @matricule_hra +'%'
	  AND [nom_salarie] LIKE '%'+ @nom_employe +'%' 
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe != '' AND @matricule_hra != '' AND @matricule_wd != '' 
      SELECT DISTINCT [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	  FROM [pay].[filtres] WHERE [prenom_salarie]  LIKE '%'+ @prenom_employe +'%' AND [matricule_hra] LIKE '%'+ @matricule_hra +'%'
	  AND [nom_salarie] LIKE '%'+ @nom_employe +'%' AND [matricule_WD] LIKE '%'+ @matricule_wd +'%'

  ELSE IF @prenom_employe = '' AND  @nom_employe = '' AND @matricule_hra = '' AND @matricule_wd = ''
     SELECT DISTINCT ISNULL ([matricule_WD], '') as [matricule_WD] , [matricule_hra] , [nom_salarie] , [prenom_salarie] 
	 FROM [pay].[filtres] 
	 WHERE 1=2
	 UNION
	 SELECT '-', '-','-','-' 
END