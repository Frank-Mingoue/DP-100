﻿







-- =============================================
-- Author:     Frank Mingoué
-- Create Date: 10102022
-- Description: DYNAMIC FILTER IN REPORTS 
-- =============================================
CREATE PROCEDURE [pay].[dynamic_query_zx8k] 
(
  @table varchar(50),
  @prenomEmploye varchar(MAX),
  @nomEmploye varchar(MAX),
  @matriculeHRA varchar(MAX),  
  @matriculeWD varchar(MAX),
  @etablissement varchar(MAX),
  --@centreDeCout varchar(MAX),
  --@codeConventionCCN varchar(MAX),
  @classification varchar(MAX),
  @qualification varchar(MAX),
  @nature_contrat varchar(MAX),
  @typeContrat varchar(MAX),
  --@anciennete varchar(MAX),
  @periode_paie varchar(MAX),
  @societe varchar(MAX),
  @codrubpaie varchar(MAX)
  --@tables_selection varchar (MAX)

)
AS
BEGIN
 declare @query varchar(MAX)
 declare @matriculeWD_cond varchar(MAX) = ''
 declare @matriculeHRA_cond varchar(MAX) = ''
 declare @prenomEmploye_cond varchar(MAX)= ''
 declare @nomEmploye_cond varchar(MAX)= ''
 declare @codrubpaie_cond varchar(MAX)= ''

 declare @var_prenomEmploye varchar(MAX) = Replace(@prenomEmploye,',',''',''')
 declare @var_nomEmploye varchar(MAX) = Replace(@nomEmploye,',',''',''')
 declare @var_matriculeHRA varchar(MAX) = Replace(@matriculeHRA,',',''',''')
 declare @var_matriculeWD varchar(MAX) = Replace(@matriculeWD,',',''',''')
 declare @var_etablissement varchar(MAX) = Replace(@etablissement,',',''',''')
 --declare @var_centreDeCout varchar(MAX) = Replace(@centreDeCout,',',''',''')
 --declare @var_codeConventionCCN varchar(MAX) = Replace(@codeConventionCCN,',',''',''')
 declare @var_classification varchar(MAX) = Replace(@classification,',',''',''')
 declare @var_qualification varchar(MAX) = Replace(@qualification,',',''',''')
 declare @var_nature_contrat varchar(MAX) = Replace(@nature_contrat,',',''',''')
 declare @var_typeContrat varchar(MAX) = Replace(@typeContrat,',',''',''')
 --declare @var_anciennete varchar(MAX) = Replace(@anciennete,',',''',''')
 declare @var_periode_paie varchar(MAX) = Replace(@periode_paie,',',''',''')
 declare @var_societe varchar(MAX) = Replace(@societe,',',''',''')
 declare @var_codrubpaie varchar(MAX) = Replace(@codrubpaie,',',''',''')
 --declare @var_tables_selection varchar(Max) = Replace(@tables_selection,',',''',''')
  declare @var_temp_table varchar(50) = (select SUBSTRING(@table, 8, 4) + replace(replace(cast (CURRENT_TIMESTAMP as varchar),' ',''),':',''))


 IF @codrubpaie != '' BEGIN SET @codrubpaie_cond = 'AND code_element_remuneration IN ('''+@var_codrubpaie+''') ' END
 IF @matriculeWD != '-' BEGIN SET @matriculeWD_cond = 'AND matricule_WD IN ('''+@var_matriculeWD+''') ' END 
 IF @matriculeHRA != '-' BEGIN SET @matriculeHRA_cond = 'AND matricule_hra IN ('''+@var_matriculeHRA+''') ' END 
 IF @nomEmploye != '-' BEGIN SET @nomEmploye_cond = 'AND nom_salarie  IN ('''+@var_nomEmploye+''') ' END 
 IF @prenomEmploye != '-' BEGIN SET @prenomEmploye_cond = 'AND prenom_salarie IN ('''+@var_prenomEmploye+''') ' END 

 

exec ('drop table if exists ##'+@var_temp_table)

SET  @query = 'SELECT * INTO ##'+@var_temp_table+' FROM '+@table+' 
 where etablissement IN ('''+@var_etablissement+''') 
AND classification IN ('''+@var_classification+''') 
AND qualification IN ('''+@var_qualification+''') 
AND type_contrat IN ('''+@var_typeContrat+''') 
AND nature_contrat IN ('''+@var_nature_contrat+''')  
AND societe IN ('''+@var_societe+''')    
AND periode_paie IN ('''+@var_periode_paie+''')'+ @codrubpaie_cond + @matriculeWD_cond + @matriculeHRA_cond + @prenomEmploye_cond + @nomEmploye_cond 



exec (@query)

exec ('select * from ##'+@var_temp_table)
exec ('drop table ##'+@var_temp_table)


END