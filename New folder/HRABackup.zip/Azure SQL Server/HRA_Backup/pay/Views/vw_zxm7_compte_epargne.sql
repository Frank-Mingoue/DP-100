﻿
CREATE  VIEW [pay].[vw_zxm7_compte_epargne] as 
SELECT
  ZXM7_compte_epargne.numero_dossier AS [ZXM7_compte_epargne numero_dossier]
  ,ZXM7_compte_epargne.type_compte
  ,ZXM7_compte_epargne.date_ouverture
  ,ZXM7_compte_epargne.date_fermeture
  ,ZXM7_compte_epargne.solde_compte
  ,ZXM7_compte_epargne.solde_temps_plein
  ,ZXM7_compte_epargne.solde_en_heures_temps_plein
  ,ZXM7_compte_epargne.date_utilisation
  ,ZXM7_compte_epargne.date_fin_utilisation
  ,ZXM7_compte_epargne.periode_paie AS [ZXM7_compte_epargne periode_paie]
  ,filtres.numero_dossier AS [filtres numero_dossier]
  ,filtres.matricule_hra
  ,filtres.matricule_WD
  ,filtres.nom_salarie
  ,filtres.prenom_salarie
  ,filtres.date_entree
  ,filtres.date_sortie
  ,filtres.etablissement
  ,filtres.code_convention_CCN
  ,filtres.date_anciennete
  ,filtres.societe
  ,filtres.anciennete
  ,filtres.qualification
  ,filtres.classification
  ,filtres.type_contrat
  ,filtres.nature_contrat
  ,filtres.type_temps_contractuel
  ,filtres.heures_presence_mois
  ,filtres.periode_paie 
  ,filtres.identifiant_dossier_paie 
  ,filtres.numero_bulletin 
  ,filtres.type_paie 

FROM
  pay.ZXM7_compte_epargne AS ZXM7_compte_epargne
  LEFT OUTER JOIN pay.filtres AS filtres
    ON ZXM7_compte_epargne.numero_dossier = filtres.numero_dossier