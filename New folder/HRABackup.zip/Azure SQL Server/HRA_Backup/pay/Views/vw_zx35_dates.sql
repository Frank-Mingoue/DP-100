﻿
CREATE VIEW [pay].[vw_zx35_dates] as 
SELECT
  ZX35_dates.numero_dossier AS [ZX35_dates numero_dossier]
  ,ZX35_dates.date_entree AS [ZX35_dates date_entree]
  ,ZX35_dates.date_sortie AS [ZX35_dates date_sortie]
  ,ZX35_dates.date_sortie_physique
  ,ZX35_dates.motif_entree
  ,ZX35_dates.libelle_motif_entree
  ,ZX35_dates.motif_sortie
  ,ZX35_dates.libelle_motif_sortie
  ,ZX35_dates.cat_situat_salarie_reeentre
  ,ZX35_dates.libelle_la_cat_sit_sal_reente
  ,ZX35_dates.motif_situation_reeentree
  ,ZX35_dates.libelle_motif_situation_reente
  ,ZX35_dates.cat_situat_salarie_suite_sortie
  ,ZX35_dates.libelle_la_categ_sal_sort
  ,ZX35_dates.motif_situation_suite_a_sortie
  ,ZX35_dates.libelle_motif_situation_sortie
  ,ZX35_dates.date_anciennete_1
  ,ZX35_dates.date_anciennete_2
  ,ZX35_dates.date_anciennete_3
  ,ZX35_dates.date_anciennete_4
  ,ZX35_dates.date_anciennete_5
  ,ZX35_dates.date_anciennete_6
  ,ZX35_dates.periode_paie AS [ZX35_dates periode_paie]
  ,filtres.numero_dossier AS [filtres numero_dossier]
  ,filtres.matricule_hra
  ,filtres.matricule_WD
  ,filtres.nom_salarie
  ,filtres.prenom_salarie
  ,filtres.date_entree 
  ,filtres.date_sortie 
  ,filtres.etablissement
  ,filtres.societe
  ,filtres.code_convention_CCN
  ,filtres.date_anciennete
  ,filtres.anciennete
  ,filtres.qualification
  ,filtres.classification
  ,filtres.type_contrat
  ,filtres.nature_contrat
  ,filtres.type_temps_contractuel
  ,filtres.heures_presence_mois
  ,filtres.periode_paie 
  ,filtres.identifiant_dossier_paie 
  ,filtres.numero_bulletin 
  ,filtres.type_paie 

FROM
  pay.ZX35_dates AS ZX35_dates
  LEFT OUTER JOIN pay.filtres AS filtres
    ON ZX35_dates.numero_dossier = filtres.numero_dossier