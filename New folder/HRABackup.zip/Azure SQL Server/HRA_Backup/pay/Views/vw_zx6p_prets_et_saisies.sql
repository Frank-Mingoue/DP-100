﻿
CREATE  VIEW [pay].[vw_zx6p_prets_et_saisies] as 
SELECT
  ZX6P_prets_et_saisies.numero_dossier AS [ZX6P_prets_et_saisies numero_dossier]
  ,ZX6P_prets_et_saisies.code_rubrique
  ,ZX6P_prets_et_saisies.numero_ordre
  ,ZX6P_prets_et_saisies.numero_pret
  ,ZX6P_prets_et_saisies.libelle_la_rubrique
  ,ZX6P_prets_et_saisies.montant_initial
  ,ZX6P_prets_et_saisies.date_debut
  ,ZX6P_prets_et_saisies.date_fin
  ,ZX6P_prets_et_saisies.nombre_echeances
  ,ZX6P_prets_et_saisies.montant_une_mensualite
  ,ZX6P_prets_et_saisies.solde
  ,ZX6P_prets_et_saisies.taux_interet
  ,ZX6P_prets_et_saisies.montants_des_interets
  ,ZX6P_prets_et_saisies.date_concession
  ,ZX6P_prets_et_saisies.date_virement_capital
  ,ZX6P_prets_et_saisies.capital_non_amorti
  ,ZX6P_prets_et_saisies.solde_avant_paie
  ,ZX6P_prets_et_saisies.periode_paie AS [ZX6P_prets_et_saisies periode_paie]
  ,filtres.numero_dossier AS [filtres numero_dossier]
  ,filtres.matricule_hra
  ,filtres.matricule_WD
  ,filtres.nom_salarie
  ,filtres.prenom_salarie
  ,filtres.date_entree
  ,filtres.date_sortie
  ,filtres.etablissement
  ,filtres.societe
  ,filtres.code_convention_CCN
  ,filtres.date_anciennete
  ,filtres.anciennete
  ,filtres.qualification
  ,filtres.classification
  ,filtres.type_contrat
  ,filtres.nature_contrat
  ,filtres.type_temps_contractuel
  ,filtres.heures_presence_mois
  ,filtres.periode_paie 
  ,filtres.identifiant_dossier_paie 
  ,filtres.numero_bulletin 
  ,filtres.type_paie 

FROM
  pay.ZX6P_prets_et_saisies AS ZX6P_prets_et_saisies
  LEFT OUTER JOIN pay.filtres AS filtres
    ON ZX6P_prets_et_saisies.numero_dossier = filtres.numero_dossier