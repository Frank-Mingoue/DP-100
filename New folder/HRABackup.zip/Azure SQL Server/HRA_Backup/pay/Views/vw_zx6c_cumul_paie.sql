﻿
CREATE  VIEW [pay].[vw_zx6c_cumul_paie] as 
SELECT
  ZX6C_cumuls_paie.numero_dossier AS [ZX6C_cumuls_paie numero_dossier]
  ,ZX6C_cumuls_paie.numero_cumul
  ,ZX6C_cumuls_paie.periode_debut_cumul
  ,ZX6C_cumuls_paie.libelle_cumul
  ,ZX6C_cumuls_paie.montant_cumul
  ,ZX6C_cumuls_paie.periode_paie AS [ZX6C_cumuls_paie periode_paie]
  ,filtres.numero_dossier AS [filtres numero_dossier]
  ,filtres.matricule_hra
  ,filtres.matricule_WD
  ,filtres.nom_salarie
  ,filtres.prenom_salarie
  ,filtres.date_entree
  ,filtres.date_sortie
  ,filtres.etablissement
  ,filtres.code_convention_CCN
  ,filtres.date_anciennete
  ,filtres.societe
  ,filtres.anciennete
  ,filtres.qualification
  ,filtres.classification
  ,filtres.type_contrat
  ,filtres.nature_contrat
  ,filtres.type_temps_contractuel
  ,filtres.heures_presence_mois
  ,filtres.periode_paie 
  ,filtres.identifiant_dossier_paie 
  ,filtres.numero_bulletin 
  ,filtres.type_paie 

FROM
  pay.ZX6C_cumuls_paie AS ZX6C_cumuls_paie
  LEFT OUTER JOIN pay.filtres AS filtres
    ON ZX6C_cumuls_paie.numero_dossier = filtres.numero_dossier