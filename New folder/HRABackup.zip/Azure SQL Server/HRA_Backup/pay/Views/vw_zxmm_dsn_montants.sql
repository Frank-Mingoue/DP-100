﻿
CREATE  VIEW [pay].[vw_zxmm_dsn_montants]  as 
SELECT
  ZXMM_dsn_montants.numero_dossier AS [ZXMM_dsn_montants numero_dossier]
  ,ZXMM_dsn_montants.code_compteur_n
  ,ZXMM_dsn_montants.code_element_remuneration
  ,ZXMM_dsn_montants.source
  ,ZXMM_dsn_montants.zone_cible_n
  ,ZXMM_dsn_montants.categorie_compteur_n
  ,ZXMM_dsn_montants.valeur_typecode_structure_n
  ,ZXMM_dsn_montants.montant_ou_mesure
  ,ZXMM_dsn_montants.nbre_heures_ou_montant_assiette
  ,ZXMM_dsn_montants.taux
  ,ZXMM_dsn_montants.date_1
  ,ZXMM_dsn_montants.date_2
  ,ZXMM_dsn_montants.date_debut_la_periode_origine
  ,ZXMM_dsn_montants.date_fin_la_periode_origine
  ,ZXMM_dsn_montants.id_ops_destinataire
  ,ZXMM_dsn_montants.type_organisme
  ,ZXMM_dsn_montants.qualifiant_assiette
  ,ZXMM_dsn_montants.code_insee_commune
  ,ZXMM_dsn_montants.taux_cotis_effectif_a_cumulere
  ,ZXMM_dsn_montants.code_affiliation_prev
  ,ZXMM_dsn_montants.periode_paie AS [ZXMM_dsn_montants periode_paie]
  ,filtres.numero_dossier AS [filtres numero_dossier]
  ,filtres.matricule_hra
  ,filtres.matricule_WD
  ,filtres.nom_salarie
  ,filtres.prenom_salarie
  ,filtres.date_entree
  ,filtres.date_sortie
  ,filtres.etablissement
  ,filtres.code_convention_CCN
  ,filtres.date_anciennete
  ,filtres.anciennete
  ,filtres.societe
  ,filtres.qualification
  ,filtres.classification
  ,filtres.type_contrat
  ,filtres.nature_contrat
  ,filtres.type_temps_contractuel
  ,filtres.heures_presence_mois
  ,filtres.periode_paie 
  ,filtres.identifiant_dossier_paie 
  ,filtres.numero_bulletin 
  ,filtres.type_paie 


FROM
  pay.ZXMM_dsn_montants AS ZXMM_dsn_montants
  LEFT OUTER JOIN pay.filtres AS filtres
    ON ZXMM_dsn_montants.numero_dossier = filtres.numero_dossier