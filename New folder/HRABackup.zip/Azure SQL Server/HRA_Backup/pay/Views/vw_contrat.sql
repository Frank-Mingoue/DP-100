﻿
CREATE  VIEW [pay].[vw_contrat]  as 
SELECT
  ZX40_heures_contractuelles.numero_dossier AS [ZX40_heures_contractuelles numero_dossier]
  ,ZX40_heures_contractuelles.date_effet
  ,ZX40_heures_contractuelles.type_temps_contractuel AS [ZX40_heures_contractuelles type_temps_contractuel]
  ,ZX40_heures_contractuelles.libelle_type_temps_contractuel AS [ZX40_heures_contractuelles libelle_type_temps_contractuel]
  ,ZX40_heures_contractuelles.heures_presencejour AS [ZX40_heures_contractuelles heures_presencejour]
  ,ZX40_heures_contractuelles.heures_presencesemaine AS [ZX40_heures_contractuelles heures_presencesemaine]
  ,ZX40_heures_contractuelles.heures_presencemois AS [ZX40_heures_contractuelles heures_presencemois]
  ,ZX40_heures_contractuelles.pourc_h_presencetemps_plein AS [ZX40_heures_contractuelles pourc_h_presencetemps_plein]
  ,ZX40_heures_contractuelles.heures_payeesjour AS [ZX40_heures_contractuelles heures_payeesjour]
  ,ZX40_heures_contractuelles.heures_payeessemaine AS [ZX40_heures_contractuelles heures_payeessemaine]
  ,ZX40_heures_contractuelles.heures_payeesmois AS [ZX40_heures_contractuelles heures_payeesmois]
  ,ZX40_heures_contractuelles.pourc_h_payeestemps_plein AS [ZX40_heures_contractuelles pourc_h_payeestemps_plein]
  ,ZX40_heures_contractuelles.forfait_annuel_en_jours AS [ZX40_heures_contractuelles forfait_annuel_en_jours]
  ,ZX40_heures_contractuelles.forfait_annuel_heures
  ,ZX40_heures_contractuelles.periode_paie AS [ZX40_heures_contractuelles periode_paie]
  ,ZX0M_description_des_contrats.numero_dossier AS [ZX0M_description_des_contrats numero_dossier]
  ,ZX0M_description_des_contrats.identifiant_contrat
  ,ZX0M_description_des_contrats.date_debut
  ,ZX0M_description_des_contrats.date_fin_contrat
  ,ZX0M_description_des_contrats.type_contrat AS [ZX0M_description_des_contrats type_contrat]
  ,ZX0M_description_des_contrats.libelle_types_contrat
  ,ZX0M_description_des_contrats.nature_contrat AS [ZX0M_description_des_contrats nature_contrat]
  ,ZX0M_description_des_contrats.libelle_natures_contrat
  ,ZX0M_description_des_contrats.duree_anse
  ,ZX0M_description_des_contrats.duree_moise
  ,ZX0M_description_des_contrats.duree_jourse
  ,ZX0M_description_des_contrats.debut_periode_essai
  ,ZX0M_description_des_contrats.fin_periode_essai
  ,ZX0M_description_des_contrats.qualification  AS [ZX0M_qualification]
  ,ZX0M_description_des_contrats.libelle_la_categorie
  ,ZX0M_description_des_contrats.classification AS [ZX0M_description_des_contrats classification]
  ,ZX0M_description_des_contrats.libelle_la_classification AS [ZX0M_description_des_contrats libelle_la_classification]
  ,ZX0M_description_des_contrats.[position]
  ,ZX0M_description_des_contrats.libelle_la_position
  ,ZX0M_description_des_contrats.indice
  ,ZX0M_description_des_contrats.libelle_indice
  ,ZX0M_description_des_contrats.coefficient
  ,ZX0M_description_des_contrats.libelle_coefficient
  ,ZX0M_description_des_contrats.niveau
  ,ZX0M_description_des_contrats.echelon
  ,ZX0M_description_des_contrats.code_convention_collective AS [ZX0M_description_des_contrats code_convention_collective]
  ,ZX0M_description_des_contrats.libelle_la_convention_collective AS [ZX0M_description_des_contrats libelle_la_convention_collective]
  ,ZX0M_description_des_contrats.etablissement AS [ZX0M_description_des_contrats etablissement]
  ,ZX0M_description_des_contrats.libelle_etablissement AS [ZX0M_description_des_contrats libelle_etablissement]
  ,ZX0M_description_des_contrats.type_temps_contractuel AS [ZX0M_description_des_contrats type_temps_contractuel]
  ,ZX0M_description_des_contrats.libelle_type_temps_contractuel AS [ZX0M_description_des_contrats libelle_type_temps_contractuel]
  ,ZX0M_description_des_contrats.heures_presencejour AS [ZX0M_description_des_contrats heures_presencejour]
  ,ZX0M_description_des_contrats.heures_presencesemaine AS [ZX0M_description_des_contrats heures_presencesemaine]
  ,ZX0M_description_des_contrats.heures_presencemois AS [ZX0M_description_des_contrats heures_presencemois]
  ,ZX0M_description_des_contrats.pourc_h_presencetemps_plein AS [ZX0M_description_des_contrats pourc_h_presencetemps_plein]
  ,ZX0M_description_des_contrats.heures_payeesjour AS [ZX0M_description_des_contrats heures_payeesjour]
  ,ZX0M_description_des_contrats.heures_payeessemaine AS [ZX0M_description_des_contrats heures_payeessemaine]
  ,ZX0M_description_des_contrats.heures_payeesmois AS [ZX0M_description_des_contrats heures_payeesmois]
  ,ZX0M_description_des_contrats.pourc_h_payeestemps_plein AS [ZX0M_description_des_contrats pourc_h_payeestemps_plein]
  ,ZX0M_description_des_contrats.salaires
  ,ZX0M_description_des_contrats.rubrique
  ,ZX0M_description_des_contrats.libelle_rubrique
  ,ZX0M_description_des_contrats.montant_salaire
  ,ZX0M_description_des_contrats.montant_horaire
  ,ZX0M_description_des_contrats.montant_par_periode_paie
  ,ZX0M_description_des_contrats.coefficient_base_chimie
  ,ZX0M_description_des_contrats.coefficient_personnel_chimie
  ,ZX0M_description_des_contrats.coefficient_specialite_chimie
  ,ZX0M_description_des_contrats.niveau_chimie
  ,ZX0M_description_des_contrats.echelon_chimie
  ,ZX0M_description_des_contrats.groupe_couture
  ,ZX0M_description_des_contrats.niveau_couture
  ,ZX0M_description_des_contrats.forfait_annuel_en_jours AS [ZX0M_description_des_contrats forfait_annuel_en_jours]
  ,ZX0M_description_des_contrats.periode_paie AS [ZX0M_description_des_contrats periode_paie]
  ,ZX5V_statut_dossier.numero_dossier AS [ZX5V_statut_dossier numero_dossier]
  ,ZX5V_statut_dossier.temoin_validite
  ,ZX5V_statut_dossier.horodatage_validite
  ,ZX5V_statut_dossier.periode_paie AS [ZX5V_statut_dossier periode_paie]
  ,ZX37_affectations_geographiques.numero_dossier AS [ZX37_affectations_geographiques numero_dossier]
  ,ZX37_affectations_geographiques.etablissement AS [ZX37_affectations_geographiques etablissement]
  ,ZX37_affectations_geographiques.libelle_etablissement AS [ZX37_affectations_geographiques libelle_etablissement]
  ,ZX37_affectations_geographiques.direction
  ,ZX37_affectations_geographiques.service
  ,ZX37_affectations_geographiques.section
  ,ZX37_affectations_geographiques.sous_section
  ,ZX37_affectations_geographiques.periode_paie AS [ZX37_affectations_geographiques periode_paie]
  ,ZX38_carriere.numero_dossier AS [ZX38_carriere numero_dossier]
  ,ZX38_carriere.qualification AS [ZX38_carriere qualification]
  ,ZX38_carriere.classification AS [ZX38_carriere classification]
  ,ZX38_carriere.libelle_statut
  ,ZX38_carriere.libelle_la_classification AS [ZX38_carriere libelle_la_classification]
  ,ZX38_carriere.code_convention_collective AS [ZX38_carriere code_convention_collective]
  ,ZX38_carriere.regime_special_cotisation
  ,ZX38_carriere.libelle_la_convention_collective AS [ZX38_carriere libelle_la_convention_collective]
  ,ZX38_carriere.periode_paie AS [ZX38_carriere periode_paie]
  ,filtres.numero_dossier AS [filtres numero_dossier]
  ,filtres.matricule_hra
  ,filtres.matricule_WD
  ,filtres.nom_salarie
  ,filtres.prenom_salarie
  ,filtres.date_entree
  ,filtres.date_sortie
  ,filtres.etablissement 
  ,filtres.code_convention_CCN
  ,filtres.date_anciennete
  ,filtres.societe
  ,filtres.anciennete
  ,filtres.qualification 
  ,filtres.classification 
  ,filtres.type_contrat 
  ,filtres.nature_contrat 
  ,filtres.type_temps_contractuel 
  ,filtres.heures_presence_mois
  ,filtres.periode_paie  
  ,filtres.identifiant_dossier_paie 
  ,filtres.numero_bulletin 
  ,filtres.type_paie 

FROM
  pay.ZX40_heures_contractuelles AS ZX40_heures_contractuelles
  LEFT OUTER JOIN pay.ZX0M_description_des_contrats AS ZX0M_description_des_contrats
    ON ZX40_heures_contractuelles.numero_dossier = ZX0M_description_des_contrats.numero_dossier
  LEFT OUTER JOIN pay.ZX5V_statut_dossier AS ZX5V_statut_dossier
    ON ZX40_heures_contractuelles.numero_dossier = ZX5V_statut_dossier.numero_dossier
  LEFT OUTER JOIN pay.ZX38_carriere AS ZX38_carriere
    ON ZX40_heures_contractuelles.numero_dossier = ZX38_carriere.numero_dossier
  LEFT OUTER JOIN pay.ZX37_affectations_geographiques AS ZX37_affectations_geographiques
    ON ZX40_heures_contractuelles.numero_dossier = ZX37_affectations_geographiques.numero_dossier
  LEFT OUTER JOIN pay.filtres AS filtres
    ON ZX40_heures_contractuelles.numero_dossier = filtres.numero_dossier