﻿
CREATE  VIEW [pay].[vw_absences]  as 
SELECT DISTINCT
  ZX3B_conges_payes.numero_dossier AS [ZX3B_conges_payes numero_dossier]
  ,ZX3B_conges_payes.code_conge
  ,ZX3B_conges_payes.annee_reference
  ,ZX3B_conges_payes.identifiant_entreesortie
  ,ZX3B_conges_payes.date_debut_consommation
  ,ZX3B_conges_payes.date_fin_consommation
  ,ZX3B_conges_payes.date_debut_acquisition
  ,ZX3B_conges_payes.date_fin_acquisition
  ,ZX3B_conges_payes.droits_acquis
  ,ZX3B_conges_payes.droits_pris
  ,ZX3B_conges_payes.droits_restants
  ,ZX3B_conges_payes.periode_paie AS [ZX3B_conges_payes periode_paie]
  ,ZX6A_absences.numero_dossier AS [ZX6A_absences numero_dossier]
  ,ZX6A_absences.date_debut_absence
  ,ZX6A_absences.identifiant_element_remuneration
  ,ZX6A_absences.code_absence
  ,ZX6A_absences.source_absence
  ,ZX6A_absences.libelle_absence
  ,ZX6A_absences.date_fin_absence
  ,ZX6A_absences.periode_paie AS [ZX6A_absences periode_paie]
  ,filtres.numero_dossier AS [filtres numero_dossier]
  ,filtres.matricule_hra
  ,filtres.matricule_WD
  ,filtres.nom_salarie
  ,filtres.prenom_salarie
  ,filtres.date_entree
  ,filtres.date_sortie
  ,filtres.etablissement
  ,filtres.code_convention_CCN
  ,filtres.date_anciennete
  ,filtres.societe
  ,filtres.anciennete
  ,filtres.qualification
  ,filtres.classification
  ,filtres.type_contrat
  ,filtres.nature_contrat
  ,filtres.type_temps_contractuel
  ,filtres.heures_presence_mois
  ,filtres.periode_paie 
  ,filtres.identifiant_dossier_paie 
  ,filtres.numero_bulletin 
  ,filtres.type_paie 

FROM
  pay.ZX3B_conges_payes AS ZX3B_conges_payes
  INNER JOIN pay.ZX6A_absences AS ZX6A_absences
    ON ZX3B_conges_payes.numero_dossier = ZX6A_absences.numero_dossier
  LEFT OUTER JOIN pay.filtres AS filtres
    ON ZX3B_conges_payes.numero_dossier = filtres.numero_dossier