﻿
CREATE  VIEW [pay].[vw_zx8k_elements_remuneration] as 
SELECT
  ZX8K_elements_remuneration.numero_dossier AS [ZX8K_elements_remuneration numero_dossier]
  ,ZX8K_elements_remuneration.code_element_remuneration
  ,ZX8K_elements_remuneration.periode_valorisation
  ,ZX8K_elements_remuneration.[date]
  ,ZX8K_elements_remuneration.rappel_automatique
  ,ZX8K_elements_remuneration.source
  ,ZX8K_elements_remuneration.code_calcul
  ,ZX8K_elements_remuneration.libelle_element_remuneration
  ,ZX8K_elements_remuneration.nombre_ou_base
  ,ZX8K_elements_remuneration.taux_salarial
  ,ZX8K_elements_remuneration.montant_salarial
  ,ZX8K_elements_remuneration.taux_patronal
  ,ZX8K_elements_remuneration.montant_patronal
  ,ZX8K_elements_remuneration.imputation
  ,ZX8K_elements_remuneration.zone_utilisateur
  ,ZX8K_elements_remuneration.code_absence
  ,ZX8K_elements_remuneration.date_debut_absence
  ,ZX8K_elements_remuneration.date_fin_absence
  ,ZX8K_elements_remuneration.memo_01
  ,ZX8K_elements_remuneration.memo_02
  ,ZX8K_elements_remuneration.memo_03
  ,ZX8K_elements_remuneration.memo_04
  ,ZX8K_elements_remuneration.memo_05
  ,ZX8K_elements_remuneration.memo_06
  ,ZX8K_elements_remuneration.memo_07
  ,ZX8K_elements_remuneration.memo_08
  ,ZX8K_elements_remuneration.memo_09
  ,ZX8K_elements_remuneration.memo_10
  ,ZX8K_elements_remuneration.memo_11
  ,ZX8K_elements_remuneration.code_organisme
  ,ZX8K_elements_remuneration.libelle_organisme
  ,ZX8K_elements_remuneration.qualifiant_numero_1
  ,ZX8K_elements_remuneration.qualifiant_numero_2
  ,ZX8K_elements_remuneration.qualifiant_numero_3
  ,ZX8K_elements_remuneration.qualifiant_numero_4
  ,ZX8K_elements_remuneration.qualifiant_numero_5
  ,ZX8K_elements_remuneration.qualifiant_numero_6
  ,ZX8K_elements_remuneration.qualifiant_numero_7
  ,ZX8K_elements_remuneration.qualifiant_numero_8
  ,ZX8K_elements_remuneration.bas_tableau
  ,ZX8K_elements_remuneration.position_dans_le_journal_paie
  ,ZX8K_elements_remuneration.alimentation_colonne_nombre_ou_base
  ,ZX8K_elements_remuneration.nb_decimales_colonne_nombre_ou_base
  ,ZX8K_elements_remuneration.alimentation_la_colonne_taux
  ,ZX8K_elements_remuneration.colonne_montant
  ,ZX8K_elements_remuneration.position_rubrique_sur_bulletin
  ,ZX8K_elements_remuneration.position_rubrique_sur_fiche_annexe
  ,ZX8K_elements_remuneration.position_rubrique_sur_fiche_euro
  ,ZX8K_elements_remuneration.periode_paie AS [ZX8K_elements_remuneration periode_paie]
  ,filtres.numero_dossier AS [filtres numero_dossier]
  ,filtres.matricule_hra
  ,filtres.matricule_WD
  ,filtres.nom_salarie
  ,filtres.prenom_salarie
  ,filtres.date_entree
  ,filtres.date_sortie
  ,filtres.etablissement
  ,filtres.code_convention_CCN
  ,filtres.date_anciennete
  ,filtres.societe
  ,filtres.anciennete
  ,filtres.qualification
  ,filtres.classification
  ,filtres.type_contrat
  ,filtres.nature_contrat
  ,filtres.type_temps_contractuel
  ,filtres.heures_presence_mois
  ,filtres.periode_paie 
  ,filtres.identifiant_dossier_paie 
  ,filtres.numero_bulletin 
  ,filtres.type_paie 


FROM
  pay.ZX8K_elements_remuneration AS ZX8K_elements_remuneration
  LEFT OUTER JOIN pay.filtres AS filtres
    ON ZX8K_elements_remuneration.numero_dossier = filtres.numero_dossier