﻿CREATE TABLE [absences].[ZYAG_absences] (
    [numero_dossier]                INT            NULL,
    [date_debut]                    DATE           NULL,
    [motif]                         VARCHAR (MAX)  NULL,
    [heure_debut]                   INT            NULL,
    [date_fin]                      DATE           NULL,
    [heure_fin]                     INT            NULL,
    [temoin_midi_debut]             VARCHAR (1)    NULL,
    [temoin_midi_fin]               VARCHAR (1)    NULL,
    [temoin_gestion]                VARCHAR (1)    NULL,
    [temoin_prolongation]           VARCHAR (1)    NULL,
    [nombre_heures]                 INT            NULL,
    [motif_situation_resultant]     VARCHAR (MAX)  NULL,
    [situation_au_retour]           VARCHAR (MAX)  NULL,
    [categorie_situation_au_retour] VARCHAR (MAX)  NULL,
    [motif_situation_au_retour]     VARCHAR (MAX)  NULL,
    [payenon_paye]                  VARCHAR (1)    NULL,
    [date_entree]                   DATE           NULL,
    [date_sortie_administrative]    DATE           NULL,
    [societe]                       VARCHAR (MAX)  NULL,
    [type_contrat]                  VARCHAR (MAX)  NULL,
    [nature]                        VARCHAR (MAX)  NULL,
    [etablissement]                 VARCHAR (MAX)  NULL,
    [unite_organisationnelle]       VARCHAR (MAX)  NULL,
    [classification]                VARCHAR (MAX)  NULL,
    [qualification]                 VARCHAR (MAX)  NULL,
    [code_convention_collective]    VARCHAR (MAX)  NULL,
    [type_temps_contractuel]        VARCHAR (MAX)  NULL,
    [heures_presencemois]           DECIMAL (5, 2) NULL,
    [date_debut_filtre]             DATE           NULL,
    [date_fin_filtre]               DATE           NULL,
    [matricule_hra]                 VARCHAR (19)   NULL,
    [matricule_workday]             VARCHAR (12)   NULL,
    [prenom_employe]                VARCHAR (30)   NULL,
    [nom_employe]                   VARCHAR (40)   NULL,
    [date_anciennete]               DATE           NULL,
    [anciennete]                    VARCHAR (25)   NULL
);









