﻿CREATE TABLE [absences].[ZYDV_conges_payes] (
    [numero_dossier]               INT            NULL,
    [code_conge]                   VARCHAR (MAX)  NULL,
    [annee_reference]              DATE           NULL,
    [identifiant_entreesortie]     INT            NULL,
    [date_debut_consommation]      DATE           NULL,
    [date_fin_consommation]        DATE           NULL,
    [date_debut_acquisition]       DATE           NULL,
    [date_fin_acquisition]         DATE           NULL,
    [droits_acquis]                DECIMAL (5, 2) NULL,
    [report_annee_precedente]      DECIMAL (5, 2) NULL,
    [droits_ecretes]               DECIMAL (5, 2) NULL,
    [report_annee_suivante]        DECIMAL (5, 2) NULL,
    [droits_payes]                 DECIMAL (5, 2) NULL,
    [droits_pris]                  DECIMAL (5, 2) NULL,
    [pris_pendant_chevauchement_1] DECIMAL (5, 2) NULL,
    [pris_pendant_chevauchement_2] DECIMAL (5, 2) NULL,
    [droits_restants]              DECIMAL (5, 2) NULL,
    [ajustement_manuel_1]          DECIMAL (5, 2) NULL,
    [motif_ajustement_1]           VARCHAR (MAX)  NULL,
    [ajustement_manuel_2]          DECIMAL (5, 2) NULL,
    [motif_ajustement_2]           VARCHAR (MAX)  NULL,
    [ajustement_manuel_3]          DECIMAL (5, 2) NULL,
    [motif_ajustement_manuel_3]    VARCHAR (MAX)  NULL,
    [ajustement_manuel_4]          DECIMAL (5, 2) NULL,
    [motif_ajustement_manuel_4]    VARCHAR (MAX)  NULL,
    [date_entree]                  DATE           NULL,
    [date_sortie_administrative]   DATE           NULL,
    [societe]                      VARCHAR (MAX)  NULL,
    [type_contrat]                 VARCHAR (MAX)  NULL,
    [nature]                       VARCHAR (MAX)  NULL,
    [etablissement]                VARCHAR (MAX)  NULL,
    [unite_organisationnelle]      VARCHAR (MAX)  NULL,
    [classification]               VARCHAR (MAX)  NULL,
    [qualification]                VARCHAR (MAX)  NULL,
    [code_convention_collective]   VARCHAR (MAX)  NULL,
    [type_temps_contractuel]       VARCHAR (MAX)  NULL,
    [heures_presencemois]          DECIMAL (5, 2) NULL,
    [date_debut_filtre]            DATE           NULL,
    [date_fin_filtre]              DATE           NULL,
    [matricule_hra]                VARCHAR (19)   NULL,
    [matricule_workday]            VARCHAR (12)   NULL,
    [prenom_employe]               VARCHAR (30)   NULL,
    [nom_employe]                  VARCHAR (40)   NULL,
    [date_anciennete]              DATE           NULL,
    [anciennete]                   VARCHAR (25)   NULL
);









