﻿CREATE TABLE [absences].[ZYDA_absences_decoupees_droits] (
    [numero_dossier]             INT            NULL,
    [date_debut_absence_ac]      DATE           NULL,
    [motif_absence]              VARCHAR (MAX)  NULL,
    [heure_debut]                INT            NULL,
    [numero_droit]               VARCHAR (3)    NULL,
    [date_debuttranche]          DATE           NULL,
    [numero_tranche]             VARCHAR (1)    NULL,
    [date_fin_tranche]           DATE           NULL,
    [heure_fin]                  INT            NULL,
    [temoin_midi_debut]          VARCHAR (1)    NULL,
    [temoin_midi_fin]            VARCHAR (1)    NULL,
    [duree_1]                    DECIMAL (5, 2) NULL,
    [duree_2]                    DECIMAL (5, 2) NULL,
    [nombre_jours]               DECIMAL (5, 2) NULL,
    [date_debut_absence_gestion] DATE           NULL,
    [date_entree]                DATE           NULL,
    [date_sortie_administrative] DATE           NULL,
    [societe]                    VARCHAR (MAX)  NULL,
    [type_contrat]               VARCHAR (MAX)  NULL,
    [nature]                     VARCHAR (MAX)  NULL,
    [etablissement]              VARCHAR (MAX)  NULL,
    [unite_organisationnelle]    VARCHAR (MAX)  NULL,
    [classification]             VARCHAR (MAX)  NULL,
    [qualification]              VARCHAR (MAX)  NULL,
    [code_convention_collective] VARCHAR (MAX)  NULL,
    [type_temps_contractuel]     VARCHAR (MAX)  NULL,
    [heures_presencemois]        DECIMAL (5, 2) NULL,
    [date_debut_filtre]          DATE           NULL,
    [date_fin_filtre]            DATE           NULL,
    [matricule_hra]              VARCHAR (19)   NULL,
    [matricule_workday]          VARCHAR (12)   NULL,
    [prenom_employe]             VARCHAR (30)   NULL,
    [nom_employe]                VARCHAR (40)   NULL,
    [date_anciennete]            DATE           NULL,
    [anciennete]                 VARCHAR (25)   NULL
);









