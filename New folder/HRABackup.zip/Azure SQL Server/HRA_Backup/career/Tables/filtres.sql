﻿CREATE TABLE [career].[filtres] (
    [numero_dossier]             INT            NULL,
    [date_entree]                DATE           NULL,
    [date_sortie_administrative] DATE           NULL,
    [societe]                    VARCHAR (45)   NULL,
    [type_contrat]               VARCHAR (25)   NULL,
    [nature]                     VARCHAR (52)   NULL,
    [etablissement]              VARCHAR (45)   NULL,
    [unite_organisationnelle]    VARCHAR (12)   NULL,
    [classification]             VARCHAR (50)   NULL,
    [qualification]              VARCHAR (38)   NULL,
    [code_convention_collective] VARCHAR (18)   NULL,
    [type_temps_contractuel]     VARCHAR (52)   NULL,
    [heures_presencemois]        DECIMAL (5, 2) NULL,
    [date_debut_filtre]          DATE           NULL,
    [date_fin_filtre]            DATE           NULL
);



