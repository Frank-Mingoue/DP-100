﻿CREATE TABLE [career].[ZYWB_preavis] (
    [numero_dossier]                      INT            NULL,
    [date_notification]                   DATE           NULL,
    [preavis_effectue]                    VARCHAR (1)    NULL,
    [debut_preavis_effectue]              DATE           NULL,
    [fin_preavis_effectue]                DATE           NULL,
    [preavis_non_effectue_paye]           VARCHAR (1)    NULL,
    [debut_preavis_non_effectue_paye]     DATE           NULL,
    [fin_preavis_non_effectue_paye]       DATE           NULL,
    [date_paiement_anticipe]              DATE           NULL,
    [preavis_non_effectue_non_paye]       VARCHAR (1)    NULL,
    [debut_preavis_non_effectue_non_paye] DATE           NULL,
    [fin_preavis_non_effectue_non_paye]   DATE           NULL,
    [preavis_non_effectue]                VARCHAR (1)    NULL,
    [motif_non_paiement_preavis]          VARCHAR (30)   NULL,
    [date_entree]                         DATE           NULL,
    [date_sortie_administrative]          DATE           NULL,
    [societe]                             VARCHAR (45)   NULL,
    [type_contrat]                        VARCHAR (25)   NULL,
    [nature]                              VARCHAR (52)   NULL,
    [etablissement]                       VARCHAR (45)   NULL,
    [unite_organisationnelle]             VARCHAR (12)   NULL,
    [classification]                      VARCHAR (50)   NULL,
    [qualification]                       VARCHAR (38)   NULL,
    [code_convention_collective]          VARCHAR (18)   NULL,
    [type_temps_contractuel]              VARCHAR (52)   NULL,
    [heures_presencemois]                 DECIMAL (5, 2) NULL,
    [date_debut_filtre]                   DATE           NULL,
    [date_fin_filtre]                     DATE           NULL,
    [matricule_hra]                       VARCHAR (19)   NULL,
    [matricule_workday]                   VARCHAR (12)   NULL,
    [prenom_employe]                      VARCHAR (30)   NULL,
    [nom_employe]                         VARCHAR (40)   NULL
);





