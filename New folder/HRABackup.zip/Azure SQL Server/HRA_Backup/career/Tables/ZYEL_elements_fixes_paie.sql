﻿CREATE TABLE [career].[ZYEL_elements_fixes_paie] (
    [numero_dossier]             INT             NULL,
    [identifiant_dossier_paie]   INT             NULL,
    [code_rubrique]              VARCHAR (3)     NULL,
    [date_debut]                 DATE            NULL,
    [date_fin]                   DATE            NULL,
    [code_format_calcul]         VARCHAR (1)     NULL,
    [nombre_ou_base]             DECIMAL (12, 3) NULL,
    [montant_ou_taux_salarial]   DECIMAL (12, 3) NULL,
    [montant_ou_taux_patronal]   DECIMAL (12, 3) NULL,
    [temoin_selection]           VARCHAR (1)     NULL,
    [centre_cout]                VARCHAR (10)    NULL,
    [memo_01]                    VARCHAR (15)    NULL,
    [memo_02]                    VARCHAR (15)    NULL,
    [date_1]                     DATE            NULL,
    [date_2]                     DATE            NULL,
    [date_entree]                DATE            NULL,
    [date_sortie_administrative] DATE            NULL,
    [societe]                    VARCHAR (45)    NULL,
    [type_contrat]               VARCHAR (25)    NULL,
    [nature]                     VARCHAR (52)    NULL,
    [etablissement]              VARCHAR (45)    NULL,
    [unite_organisationnelle]    VARCHAR (12)    NULL,
    [classification]             VARCHAR (50)    NULL,
    [qualification]              VARCHAR (38)    NULL,
    [code_convention_collective] VARCHAR (18)    NULL,
    [type_temps_contractuel]     VARCHAR (52)    NULL,
    [heures_presencemois]        DECIMAL (5, 2)  NULL,
    [date_debut_filtre]          DATE            NULL,
    [date_fin_filtre]            DATE            NULL,
    [matricule_hra]              VARCHAR (19)    NULL,
    [matricule_workday]          VARCHAR (12)    NULL,
    [prenom_employe]             VARCHAR (30)    NULL,
    [nom_employe]                VARCHAR (40)    NULL
);







