﻿CREATE TABLE [career].[ZYAF_affectation_consolidee] (
    [numero_dossier]             INT            NULL,
    [date_effet]                 DATE           NULL,
    [date_fin]                   DATE           NULL,
    [niveau_5]                   VARCHAR (10)   NULL,
    [niveau_7]                   VARCHAR (10)   NULL,
    [date_entree]                DATE           NULL,
    [date_sortie_administrative] DATE           NULL,
    [societe]                    VARCHAR (45)   NULL,
    [type_contrat]               VARCHAR (25)   NULL,
    [nature]                     VARCHAR (52)   NULL,
    [etablissement]              VARCHAR (45)   NULL,
    [unite_organisationnelle]    VARCHAR (12)   NULL,
    [classification]             VARCHAR (50)   NULL,
    [qualification]              VARCHAR (38)   NULL,
    [code_convention_collective] VARCHAR (18)   NULL,
    [type_temps_contractuel]     VARCHAR (52)   NULL,
    [heures_presencemois]        DECIMAL (5, 2) NULL,
    [date_debut_filtre]          DATE           NULL,
    [date_fin_filtre]            DATE           NULL,
    [matricule_hra]              VARCHAR (19)   NULL,
    [matricule_workday]          VARCHAR (12)   NULL,
    [prenom_employe]             VARCHAR (30)   NULL,
    [nom_employe]                VARCHAR (40)   NULL
);





