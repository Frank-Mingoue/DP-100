﻿CREATE TABLE [career].[ZYHB_salarie_beneficiaire] (
    [numero_dossier]                       INT            NULL,
    [date_debut]                           DATE           NULL,
    [date_decision]                        DATE           NULL,
    [date_fin]                             DATE           NULL,
    [duree_decision]                       VARCHAR (1)    NULL,
    [temoin_chaumage_avant_embauche]       VARCHAR (MAX)  NULL,
    [temoin_reconnu_travailleur_handicape] VARCHAR (MAX)  NULL,
    [placement_ea]                         VARCHAR (MAX)  NULL,
    [placement_esta]                       VARCHAR (MAX)  NULL,
    [placement_cdtd]                       VARCHAR (MAX)  NULL,
    [temoin_invalide_pensionne]            VARCHAR (MAX)  NULL,
    [temoin_sapeur_pompier_volontaire]     VARCHAR (MAX)  NULL,
    [temoin_assimile_mutile_guerre]        VARCHAR (MAX)  NULL,
    [temoin_handicap_permanent_a_viee]     VARCHAR (MAX)  NULL,
    [temoin_mutile_guerre]                 VARCHAR (MAX)  NULL,
    [temoin_beneficiaire_allocation]       VARCHAR (MAX)  NULL,
    [temoin_titulaire_allocation]          VARCHAR (MAX)  NULL,
    [temoin_malprofesacctravailtrajet]     INT            NULL,
    [temoin_handicap_lourd]                VARCHAR (MAX)  NULL,
    [taux_invalidite]                      DECIMAL (4, 2) NULL,
    [date_debut_pension]                   DATE           NULL,
    [categorie_pension]                    VARCHAR (1)    NULL,
    [taux_incapacite]                      DECIMAL (4, 2) NULL,
    [temoin_accident_travail]              INT            NULL,
    [prestation_compensation_handic]       VARCHAR (MAX)  NULL,
    [catego_beneficiaire_oblig_emploi]     VARCHAR (2)    NULL,
    [temoin_mise_a_disposition_externe]    VARCHAR (2)    NULL,
    [date_entree]                          DATE           NULL,
    [date_sortie_administrative]           DATE           NULL,
    [societe]                              VARCHAR (45)   NULL,
    [type_contrat]                         VARCHAR (25)   NULL,
    [nature]                               VARCHAR (52)   NULL,
    [etablissement]                        VARCHAR (45)   NULL,
    [unite_organisationnelle]              VARCHAR (12)   NULL,
    [classification]                       VARCHAR (50)   NULL,
    [qualification]                        VARCHAR (38)   NULL,
    [code_convention_collective]           VARCHAR (18)   NULL,
    [type_temps_contractuel]               VARCHAR (52)   NULL,
    [heures_presencemois]                  DECIMAL (5, 2) NULL,
    [date_debut_filtre]                    DATE           NULL,
    [date_fin_filtre]                      DATE           NULL,
    [matricule_hra]                        VARCHAR (19)   NULL,
    [matricule_workday]                    VARCHAR (12)   NULL,
    [prenom_employe]                       VARCHAR (30)   NULL,
    [nom_employe]                          VARCHAR (40)   NULL
);







