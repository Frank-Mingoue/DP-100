﻿CREATE TABLE [career].[identification] (
    [numero_dossier]    INT          NULL,
    [matricule_hra]     VARCHAR (19) NULL,
    [matricule_workday] VARCHAR (12) NULL,
    [prenom_employe]    VARCHAR (30) NULL,
    [nom_employe]       VARCHAR (40) NULL,
    [date_anciennete]   DATE         NULL,
    [anciennete]        VARCHAR (25) NULL
);



