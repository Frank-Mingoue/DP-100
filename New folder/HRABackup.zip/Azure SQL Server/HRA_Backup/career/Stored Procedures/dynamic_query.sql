﻿






-- =============================================
-- Author:     Frank Mingoué
-- Create Date: 10102022
-- Description: DYNAMIC FILTER IN REPORTS 
-- =============================================
CREATE PROCEDURE [career].[dynamic_query] 
(
  @table varchar(50),
  @prenomEmploye varchar(MAX),
  @nomEmploye varchar(MAX),
  @matriculeHRA varchar(MAX),  
  @matriculeWD varchar(MAX),
  @etablissement varchar(MAX),
  @centreDeCout varchar(MAX),
  @codeConventionCCN varchar(MAX),
  @classification varchar(MAX),
  @qualification varchar(MAX),
  @nature varchar(MAX),
  @typeContrat varchar(MAX),
  @societe varchar(MAX)
  --@anciennete varchar(MAX)
  --@tables_selection varchar (MAX)

)
AS
BEGIN
 declare @query varchar(MAX)
 declare @matriculeWD_cond varchar(MAX) = ''
 declare @matriculeHRA_cond varchar(MAX) = ''
 declare @prenomEmploye_cond varchar(MAX)= ''
 declare @nomEmploye_cond varchar(MAX)= ''

 declare @var_prenomEmploye varchar(MAX) = Replace(@prenomEmploye,',',''',''')
 declare @var_nomEmploye varchar(MAX) = Replace(@nomEmploye,',',''',''')
 declare @var_matriculeHRA varchar(MAX) = Replace(@matriculeHRA,',',''',''')
 declare @var_matriculeWD varchar(MAX) = Replace(@matriculeWD,',',''',''')
 declare @var_etablissement varchar(MAX) = Replace(@etablissement,',',''',''')
 declare @var_centreDeCout varchar(MAX) = Replace(@centreDeCout,',',''',''')
 declare @var_codeConventionCCN varchar(MAX) = Replace(@codeConventionCCN,',',''',''')
 declare @var_classification varchar(MAX) = Replace(@classification,',',''',''')
 declare @var_qualification varchar(MAX) = Replace(@qualification,',',''',''')
 declare @var_nature varchar(MAX) = Replace(@nature,',',''',''')
 declare @var_typeContrat varchar(MAX) = Replace(@typeContrat,',',''',''')
 declare @var_societe varchar(MAX) = Replace(@societe,',',''',''')
 --declare @var_anciennete varchar(MAX) = Replace(@anciennete,',',''',''')
 --declare @var_tables_selection varchar(Max) = Replace(@tables_selection,',',''',''')
 declare @var_temp_table varchar(50) = (select replace(@table, '.', '') + replace(replace(cast (CURRENT_TIMESTAMP as varchar),' ',''),':',''))



 IF @matriculeWD != '-' BEGIN SET @matriculeWD_cond = 'AND matricule_workday IN ('''+@var_matriculeWD+''') ' END 
 IF @matriculeHRA != '-' BEGIN SET @matriculeHRA_cond = 'AND matricule_hra IN ('''+@var_matriculeHRA+''') ' END 
 IF @nomEmploye != '-' BEGIN SET @nomEmploye_cond = 'AND nom_employe IN ('''+@var_nomEmploye+''') ' END 
 IF @prenomEmploye != '-' BEGIN SET @prenomEmploye_cond = 'AND prenom_employe IN ('''+@var_prenomEmploye+''') ' END 

 

exec ('drop table if exists ##'+@var_temp_table)

SET  @query = 'SELECT * INTO ##'+@var_temp_table+' FROM '+@table+' 
 where etablissement IN ('''+@var_etablissement+''') 
AND unite_organisationnelle IN ('''+@var_centreDeCout+''') 
AND code_convention_collective IN ('''+@var_codeConventionCCN+''') 
AND classification IN ('''+@var_classification+''') 
AND qualification IN ('''+@var_qualification+''') 
AND type_contrat IN ('''+@var_typeContrat+''') 
AND nature IN ('''+@var_nature+''')  
AND societe IN ('''+@var_societe+''') '+ @matriculeWD_cond + @matriculeHRA_cond + @prenomEmploye_cond + @nomEmploye_cond



exec (@query)

exec ('select * from ##'+@var_temp_table)
exec ('drop table ##'+@var_temp_table)


END