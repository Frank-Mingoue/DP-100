﻿




-- =============================================
-- Author:  Frank Mingoué
-- Create Date: 17-10-2022
-- Description: generate filter based on fields 
-- =============================================
CREATE PROCEDURE [career].[Filter]
( 
  @prenom_employe varchar(50),
  @nom_employe varchar(50),
  @matricule_hra varchar(50),  
  @matricule_workday varchar(50)
)
    
AS

BEGIN 

  

 

  IF @prenom_employe = '' AND  @nom_employe != '' AND @matricule_hra = '' AND @matricule_workday = '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe]
	  FROM [career].[identification] WHERE [nom_employe] LIKE '%'+ @nom_employe +'%' 
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe = '' AND  @nom_employe = '' AND @matricule_hra != '' AND @matricule_workday = '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [matricule_hra] LIKE '%'+ @matricule_hra +'%' 
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe = '' AND  @nom_employe = '' AND @matricule_hra = '' AND @matricule_workday != '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [matricule_workday] LIKE '%'+ @matricule_workday+'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe = '' AND @matricule_hra = '' AND @matricule_workday = '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [prenom_employe]  LIKE '%'+ @prenom_employe +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe != '' AND @matricule_hra = '' AND @matricule_workday = '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [prenom_employe]  LIKE '%'+ @prenom_employe +'%' AND [nom_employe] LIKE '%'+ @nom_employe +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe != '' AND @matricule_hra != '' AND @matricule_workday = '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [prenom_employe]  LIKE '%'+ @prenom_employe +'%' AND [nom_employe] LIKE '%'+ @nom_employe +'%' 
	  AND [matricule_hra] LIKE '%'+ @matricule_hra +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe = '' AND @matricule_hra != '' AND @matricule_workday = '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [prenom_employe]  LIKE '%'+ @prenom_employe +'%' AND [matricule_hra] LIKE '%'+ @matricule_hra +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe = '' AND @matricule_hra = '' AND @matricule_workday != '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [prenom_employe]  LIKE '%'+ @prenom_employe +'%' AND [matricule_workday] LIKE '%'+ @matricule_workday +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe = '' AND  @nom_employe = '' AND @matricule_hra != '' AND @matricule_workday != '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [matricule_hra] LIKE '%'+ @matricule_hra +'%' AND [matricule_workday] LIKE '%'+ @matricule_workday +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe = '' AND @matricule_hra != '' AND @matricule_workday != '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [matricule_hra] LIKE '%'+ @matricule_hra +'%' AND [matricule_workday] LIKE '%'+ @matricule_workday +'%'
	  AND [prenom_employe]  LIKE '%'+ @prenom_employe +'%'
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe = '' AND  @nom_employe != '' AND @matricule_hra != '' AND @matricule_workday != '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [matricule_hra] LIKE '%'+ @matricule_hra +'%' AND [matricule_workday] LIKE '%'+ @matricule_workday +'%'
	  AND [nom_employe] LIKE '%'+ @nom_employe +'%' 
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe = '' AND  @nom_employe != '' AND @matricule_hra != '' AND @matricule_workday = '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [matricule_hra] LIKE '%'+ @matricule_hra +'%' AND [nom_employe] LIKE '%'+ @nom_employe +'%' 
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe != '' AND @matricule_hra = '' AND @matricule_workday != '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [prenom_employe]  LIKE '%'+ @prenom_employe +'%' AND [matricule_workday] LIKE '%'+ @matricule_workday +'%'
	  AND [nom_employe] LIKE '%'+ @nom_employe +'%' 
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe != '' AND @matricule_hra != '' AND @matricule_workday = '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [prenom_employe]  LIKE '%'+ @prenom_employe +'%' AND [matricule_hra] LIKE '%'+ @matricule_hra +'%'
	  AND [nom_employe] LIKE '%'+ @nom_employe +'%' 
	  UNION
	  SELECT '-', '-','-','-' 

  ELSE IF @prenom_employe != '' AND  @nom_employe != '' AND @matricule_hra != '' AND @matricule_workday != '' 
      SELECT DISTINCT [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	  FROM [career].[identification] WHERE [prenom_employe]  LIKE '%'+ @prenom_employe +'%' AND [matricule_hra] LIKE '%'+ @matricule_hra +'%'
	  AND [nom_employe] LIKE '%'+ @nom_employe +'%' AND [matricule_workday] LIKE '%'+ @matricule_workday +'%'

  ELSE IF @prenom_employe = '' AND  @nom_employe = '' AND @matricule_hra = '' AND @matricule_workday = ''
     SELECT DISTINCT ISNULL ([matricule_workday], '') as [matricule_workday] , [matricule_hra] , [nom_employe] , [prenom_employe] 
	 FROM [career].[identification] 
	 WHERE 1=2
	 UNION
	 SELECT '-', '-','-','-' 
END