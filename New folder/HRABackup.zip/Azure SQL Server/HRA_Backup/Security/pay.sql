﻿CREATE SCHEMA [pay]
    AUTHORIZATION [dbo];

















