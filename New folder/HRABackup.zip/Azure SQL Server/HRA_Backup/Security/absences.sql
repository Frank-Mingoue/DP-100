﻿CREATE SCHEMA [absences]
    AUTHORIZATION [dbo];















