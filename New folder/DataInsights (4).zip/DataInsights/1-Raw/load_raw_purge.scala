// Databricks notebook source
// DBTITLE 1,Include notebook containing functions to connect to adls container, get database url and properties
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

/*for(f <- dbutils.fs.mounts())
{
 if(f.source.contains("wasbs") )
{
   dbutils.fs.unmount(f.mountPoint)
}
 
}*/

// COMMAND ----------

/*for(f <- dbutils.fs.mounts())
{
 if(f.source.contains("abfss") )
{
   dbutils.fs.unmount(f.mountPoint)
}
 
}*/

// COMMAND ----------

// DBTITLE 1,Remove business csv files
dbutils.fs.rm("/mnt/raw_container/business",true)

// COMMAND ----------

// DBTITLE 1,Remove gestor csv files
dbutils.fs.rm("/mnt/raw_container/gestor",true)

// COMMAND ----------

// DBTITLE 1,Remove hra csv files
dbutils.fs.rm("/mnt/raw_container/hra",true)


// COMMAND ----------

// DBTITLE 1,Remove sap csv files
dbutils.fs.rm("/mnt/raw_container/sap",true)

// COMMAND ----------

// DBTITLE 1,Remove pa csv files
dbutils.fs.rm("/mnt/raw_container/pa",true)

// COMMAND ----------

// DBTITLE 1,Remove workday csv files
dbutils.fs.rm("/mnt/raw_container/workday",true)

// COMMAND ----------

// DBTITLE 1,Remove cornerstone csv files
dbutils.fs.rm("/mnt/raw_container/cornerstone",true)