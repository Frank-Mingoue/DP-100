// Databricks notebook source
// MAGIC %run /DataInsights/Include/import_library

// COMMAND ----------

def get_file_structure(filename: String) : StructType = {

var struct: StructType = null
  
struct = filename  match {

  
/*************************WORKDAY*************************************/

    //------------Get Workers
    case "get_workers" =>
    StructType( List(
            StructField("last_name",StringType,false),
            StructField("first_name",StringType,false),
            StructField("birth_name",StringType,false),
            StructField("prefix",StringType,false),
            StructField("gender",StringType,true),
            StructField("birth_date",DateType,false),
            StructField("city_of_birth",StringType,false),
            StructField("department_of_birth",StringType,false),
            StructField("country_of_birth",StringType,false),
            StructField("primary_nationality",StringType,false),
            StructField("additional_nationalities",StringType,false),
            StructField("primary_work_email",StringType,false),
            StructField("primary_home_email",StringType,false),
            StructField("street_number",StringType,false),
            StructField("street_number_extension",StringType,false),
            StructField("street_name",StringType,false),
            StructField("additional_address",StringType,false),
            StructField("postal_code",StringType,false),
            StructField("city",StringType,false),
            StructField("marital_status",StringType,false),
            StructField("marital_status_label",StringType,false),
            StructField("national_identifier",StringType,false),
            StructField("employee_id",StringType,true),
            StructField("france_payroll_id",StringType,false),
            StructField("user_name",StringType,false),
            StructField("igi_identification",StringType,false),
            StructField("spouse_first_name",StringType,false),
            StructField("spouse_last_name",StringType,false),
            StructField("children_order_number",StringType,false),
            StructField("children_gender",StringType,false),
            StructField("children_date_of_birth",DateType,false),
            StructField("children_first_name",StringType,false),
            StructField("children_last_name",StringType,false),
            StructField("children_dependent",StringType,false),
            StructField("manager_reference",StringType,false),
            StructField("manager_last_name",StringType,false),
            StructField("manager_first_name",StringType,false),
            StructField("position_start_date",DateType,false),
            StructField("hire_date",DateType,false),
            StructField("job_title",StringType,false),
            StructField("business_line_reference",StringType,false),
            StructField("business_line_name",StringType,false),
            StructField("worker_type",StringType,false),
            StructField("grade",StringType,false),
            StructField("grade_label",StringType,false),
            StructField("coefficient",StringType,false),
            StructField("coefficient_label",StringType,false),
            StructField("management_level",StringType,false),
            StructField("management_level_label",StringType,false),
            StructField("location",StringType,false),
            StructField("location_country",StringType,false),
            StructField("location_type",StringType,false),
            StructField("cost_center_code",StringType,true),
            StructField("cost_center_name",StringType,false),
            StructField("company_id",StringType,false),
            StructField("company",StringType,false),
            StructField("first_contract_type",StringType,false),
            StructField("first_contract_type_label",StringType,false),
            StructField("continous_service_date",DateType,false),
            StructField("collective_agreement_reference",StringType,false),
            StructField("collective_agreement_reference_label",StringType,false),
            StructField("collective_agreement_group",StringType,false),
            StructField("collective_agreement_level",StringType,false),
            StructField("lt_leader_last_name_n_1",StringType,false),
            StructField("lt_leader_first_name_n_1",StringType,false),
            StructField("lt_leader_reference_n_1",StringType,false),
            StructField("lt_leader_last_name",StringType,false),
            StructField("lt_leader_first_name",StringType,false),
            StructField("lt_leader_reference",StringType,false),
            StructField("supervisory_organization_name",StringType,false),
            StructField("supervisory_organization_reference",StringType,false),
            StructField("original_hire_date",DateType,false),
            StructField("contract_start_date",DateType,true),
            StructField("contract_end_date",DateType,false),
            StructField("contract_type",StringType,true),
            StructField("contract_type_label",StringType,true),
            StructField("event_classification_subcategory",StringType,false),
            StructField("event_classification_subcategory_label",StringType,false),
            StructField("local_termination_reason",StringType,false),
            StructField("job_profile_name",StringType,false),
            StructField("job_profile_reference",StringType,false),
            StructField("job_profile_reference_label",StringType,false),
            StructField("job_category",StringType,false),
            StructField("job_family",StringType,false),
            StructField("job_family_group",StringType,false),
            StructField("fte",DoubleType,false),
            StructField("time_type",StringType,false),
            StructField("time_type_label",StringType,false),
            StructField("professional_category_reference",StringType,false),
            StructField("professional_category_name",StringType,false),
            StructField("paidfte",DoubleType,false),
            StructField("total_base_pay",DoubleType,false),
            StructField("primary_comp_basis_amount",DoubleType,false),
            StructField("period_salary",StringType,false),
            StructField("period_salary_label",StringType,false),
            StructField("period_salary_amount",DoubleType,false),
            StructField("compensation_merit_plan",StringType,false),
            StructField("compensation_merit_plan_label",StringType,false),
            StructField("compensation_change_reason",StringType,false),
            StructField("compensation_change_subreason",StringType,false),
            StructField("compensation_bonus_plan",StringType,false),
            StructField("bonus_target",DoubleType,false),
            StructField("bonus_plan_name",StringType,false),
            StructField("additional_job_classifications",StringType,false),
            StructField("additional_job_classifications_label",StringType,false),
            StructField("compensation_currency",StringType,false),
            StructField("default_weekly_hours",DoubleType,false),
            StructField("scheduled_weekly_hours",DoubleType,false),
            StructField("effective_hire_date",DateType,false),
            StructField("effective_job_change_date",DateType,false),
            StructField("effective_organization_change_date",DateType,false),
            StructField("effective_compensation_change_date",DateType,false),
            StructField("effective_suporg_change_date",DateType,false),
            StructField("foreign_travel_indemnity_percent",DoubleType,false),
            StructField("foreign_travel_indemnity_amount",DoubleType,false),
            StructField("children_date_of_death",DateType,false),
            StructField("local_pb_hierarchy_code",StringType,false),
            StructField("local_pb_hierarchy_name",StringType,false),
            StructField("bonus_target_default",DoubleType,false),
      
            StructField("review_type_reference",StringType,false),
            StructField("review_reference",StringType,false),
            StructField("review_initiated_date",DateType,false),
            StructField("review_end_date",DateType,false),
            StructField("review_period_start_date",DateType,false),
            StructField("review_period_end_date",DateType,false),
            StructField("review_status",StringType,false),
            StructField("goal_id",StringType,false),
            StructField("goal_due_date",DateType,false),
            StructField("goal_completion_date",DateType,false),
            StructField("relocation_long_term_area",StringType,false),
            StructField("relocation_long_term_willing",StringType,false),
            StructField("relocation_short_term_area",StringType,false),
            StructField("relocation_short_term_willing",StringType,false),
            
            StructField("location_code",StringType,false),
            StructField("probation_start_date",DateType,false),
            StructField("probation_end_date",DateType,false),
            StructField("contract_reason",StringType,false),
            StructField("my_review_end_date",DateType,false),
            StructField("my_review_status",StringType,false),
            StructField("employee_visibility_date",DateType,false),
            StructField("prime_co_percent",DoubleType,false),
            StructField("prime_exp_percent",DoubleType,false),
            StructField("effective_collective_agreement_date",DateType,false),
      
            StructField("filepath",StringType,false)
    ))


    
    //------------Histo Grade
    case "histo_grade" =>
    StructType( List(
            StructField("employee_id",StringType,true), 
            StructField("compensation_grade_reference_label",StringType,false), 
            StructField("compensation_grade_reference_label_2",StringType,false), 
            StructField("effective_date_from_comp",DateType,false),
      
            StructField("filepath",StringType,false)
    ))
  
    //------------Histo Job Profile
  case "histo_job_profile" =>
    StructType( List(
            StructField("employee_id",StringType,true), 
            StructField("job_profile_name",StringType,false), 
            StructField("job_profile_reference",StringType,false), 
            StructField("effective_date_from_job_change",DateType,false),
            StructField("job_category",StringType,false),
            StructField("job_family",StringType,false),
            StructField("job_family_group",StringType,false),
      
            StructField("filepath",StringType,false)
    ))
  
    //------------Histo Band (Management Level)
  case "histo_management_level" =>
    StructType( List(
            StructField("employee_id",StringType,true), 
            StructField("management_level_reference",StringType,false), 
            StructField("management_level_label",StringType,false), 
            StructField("effective_date_from_job_change",DateType,false), 
            StructField("statut_actif",StringType,false),
      
            StructField("filepath",StringType,false)
    ))
  
    //------------Histo Site
  case "histo_site" =>
    StructType( List(
            StructField("employee_id",StringType,true), 
            StructField("business_site_summary_data_name",StringType,false), 
            StructField("effective_date_from_location_change",DateType,false),
            StructField("location_type",StringType,false),
      
            StructField("filepath",StringType,false)
    ))  
  
    
/************************ Recruitment **************************************/
  
  //------------get_candidates
  case "get_candidates" =>
    StructType( List(
            StructField("candidate_id",StringType,true), 
            StructField("candidate_first_name",StringType,false), 
            StructField("candidate_last_name",StringType,false), 
            StructField("worker_reference",StringType,false), 
            StructField("source_reference",StringType,false), 
            StructField("job_requisition_reference",StringType,true), 
            StructField("job_application_date",DateType,true), 
            StructField("stage_reference",StringType,false), 
            StructField("status_timestamp",DateType,false), 
            StructField("school_name",StringType,false), 
            StructField("degree_reference",StringType,false), 
            StructField("first_year_attended",StringType,false), 
            StructField("last_year_attended",StringType,false), 
            StructField("disposition_reference",StringType,false), 
            StructField("disposition_reference_id",StringType,false),
      
            StructField("filepath",StringType,false)
    )) 
  
    //------------get_jobpostings
    case "get_jobpostings" =>
    StructType( List(
            StructField("job_requisition_reference",StringType,true), 
            StructField("job_posting_start_date",DateType,false), 
            StructField("job_posting_site_reference",StringType,false),
      
            StructField("filepath",StringType,false)
    ))
  
    //------------get_jobrequisitions
    case "get_jobrequisitions" =>
      StructType( List(
              StructField("job_requisition_reference",StringType,true), 
              StructField("job_requisition_status",StringType,false), 
              StructField("job_posting_title",StringType,false), 
              StructField("recruiting_instruction_data",StringType,false), 
              StructField("recruiting_start_date",DateType,false), 
              StructField("target_hire_date",DateType,false), 
              StructField("target_end_date",DateType,false), 
              StructField("worker_type_reference",StringType,false), 
              StructField("position_worker_type_reference",StringType,false), 
              StructField("primary_location_reference",StringType,false), 
              StructField("primary_location_label",StringType,false), 
              StructField("primary_job_posting_location_reference",StringType,false),
              StructField("primary_job_posting_location_label",StringType,false),
              StructField("time_type_reference",StringType,false), 
              StructField("position_reference",StringType,false),
              StructField("position_label",StringType,false),
              StructField("hiring_manager",StringType,false), 
              StructField("effective_date",DateType,false), 
              StructField("primary_recruiter",StringType,false),
      
              StructField("filepath",StringType,false)
      )) 
 
  //------------get_positions
  case "get_positions" =>
    StructType( List(
            StructField("position_reference",StringType,true), 
            StructField("earliest_hire_date",DateType,false), 
            StructField("job_profile",StringType,false), 
            StructField("job_category",StringType,false), 
            StructField("job_family",StringType,false), 
            StructField("cost_center_reference",StringType,true), 
            StructField("cost_center",StringType,false), 
            StructField("location",StringType,false), 
            StructField("effective_date",DateType,false),
      
            StructField("filepath",StringType,false)
    )) 
  
/*************************SAP*************************************/
  
    //------------SAP Centre de couts
    case "sap_cc" =>
    StructType( List(
            StructField("costcentercode",StringType,true), 
            StructField("costcentername",StringType,true), 
            StructField("centertype",StringType,false), 
            StructField("companycode",StringType,true), 
            StructField("company",StringType,true), 
            StructField("marketsegment",StringType,false), 
            StructField("activitydomain",StringType,false), 
            StructField("standardcostcenter",StringType,false), 
            StructField("essbasefunction",StringType,false), 
            StructField("profitcenter",StringType,false),
      
            StructField("filepath",StringType,false)
    ))

    //------------SAP Natures Comptables
    case "sap_natures_comptables" =>
    StructType( List(
            StructField("wage_type_code",StringType,true), 
            StructField("cost_center_code",StringType,true), 
            StructField("month",IntegerType,true), 
            StructField("year",IntegerType,true), 
            StructField("country",StringType,true), 
            StructField("currency",StringType,false), 
            StructField("amount",DoubleType,false),
      
            StructField("filepath",StringType,false)
    ))
  
/*************************HRA*************************************/
  
    //------------HRA Salaries
     case "hra_salaries" =>
     StructType( List(
            StructField("matricule_hr_access",StringType,true), 
            StructField("matricule_wd",StringType,false), 
            StructField("compte_ad",StringType,false), 
            StructField("qualite",StringType,false), 
            StructField("nom_usuel",StringType,false), 
            StructField("nom_patronymique",StringType,false), 
            StructField("prenom",StringType,false), 
            StructField("sexe",StringType,false), 
            StructField("nir",StringType,false), 
            StructField("etat_civil",StringType,false), 
            StructField("libelle_etat_civil",StringType,false), 
            StructField("date_naissance",DateType,false), 
            StructField("ville_naissance",StringType,false), 
            StructField("pays_naissance",StringType,false), 
            StructField("dept_naissance",StringType,false), 
            StructField("nationalite_princ",StringType,false), 
            StructField("pays_adresse",StringType,false), 
            StructField("no_adresse",StringType,false), 
            StructField("bis_ter_adresse",StringType,false), 
            StructField("nature_voie",StringType,false), 
            StructField("nom_voie",StringType,false), 
            StructField("complement_adresse",StringType,false), 
            StructField("code_insee_commune",StringType,false), 
            StructField("commune",StringType,false), 
            StructField("code_postal",StringType,false), 
            StructField("bureau_distributeur",StringType,false), 
            StructField("email_pro",StringType,false), 
            StructField("email_perso",StringType,false), 
            StructField("prenom_conjoint",StringType,false), 
            StructField("nom_conjoint",StringType,false), 
            StructField("entree_groupe",DateType,false), 
            StructField("anciennete_groupe",DateType,false), 
            StructField("derniere_embauche",DateType,false), 
            StructField("anciennete_poste",DateType,false),
            StructField("population_particuliere",StringType,false),
      
            StructField("filepath",StringType,false)
     )) 
 
    //------------HRA Contrat
      case "hra_contrat" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_contrat",DateType,true),
            StructField("date_fin_contrat",DateType,false),
            StructField("type_contrat",StringType,true),
            StructField("libelle_type_contrat",StringType,true),
            StructField("nature_contrat",StringType,true),
            StructField("libelle_nature_contrat",StringType,true),
            StructField("date_fin_previsionnelle",DateType,false),
            StructField("date_fin_periode_essai",DateType,false),
            StructField("motif_entree",StringType,false),
            StructField("libelle_motif_entree",StringType,false),
            StructField("motif_sortie",StringType,false),
            StructField("libelle_motif_sortie",StringType,false),
      
            StructField("filepath",StringType,false)
      )) 

    //-----------HRA Emploi
       case "hra_emploi" =>
       StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_effet_emploi",DateType,true),
            StructField("date_fin_emploi",DateType,false),
            StructField("code_emploi",StringType,false),
            StructField("libelle_emploi",StringType,false),
            StructField("taux_emploi",DoubleType,false),
      
            StructField("filepath",StringType,false)
       )) 

    //------------HRA Centre Cout
      case "hra_centrecout" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_centre_cout",DateType,true),
            StructField("date_fin_centre_cout",DateType,false),
            StructField("centre_cout",StringType,true),
            StructField("libelle_centre_cout",StringType,false),
            StructField("sous_compte",StringType,false),
            StructField("taux_repartition",StringType,false),
            StructField("date_deb_etablissement",DateType,true),
            StructField("date_fin_etablissement",DateType,false),
            StructField("code_etablissement",StringType,true),
            StructField("libelle_etablissement",StringType,false),
            StructField("date_deb_societe",DateType,true),
            StructField("date_fin_societe",DateType,false),
            StructField("code_societe",StringType,true),
            StructField("libelle_societe",StringType,false),
            StructField("motif_entree",StringType,false),
            StructField("date_deb_org",DateType,true),
            StructField("date_fin_org",DateType,false),
            StructField("code_direction",StringType,true),
            StructField("libelle_direction",StringType,false),
            StructField("code_departement",StringType,true),
            StructField("libelle_departement",StringType,false),
      
            StructField("filepath",StringType,false)
      )) 

    //------------HRA Temps Travail
      case "hra_tempstravail" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_effet_tps_contractuel",DateType,false),
            StructField("date_fin_tps_contractuel",DateType,false),
            StructField("type_temps_contractuel",StringType,false),
            StructField("libelle_type_temps_contractuel",StringType,false),
            StructField("code_modalite_horaire",StringType,false),
            StructField("nb_heure_presence_sem",DoubleType,false),
            StructField("nb_heure_presence_mois",DoubleType,false),
            StructField("nb_heure_payes_sem",DoubleType,false),
            StructField("nb_heure_payes_mois",DoubleType,false),
            StructField("nb_jours_travailles_an",DoubleType,false),
            StructField("taux_travail",DoubleType,false),
      
            StructField("filepath",StringType,false)
      )) 

    //------------HRA Etp
      case "hra_etp" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_etp",DateType,false),
            StructField("date_fin_etp",DateType,false),
            StructField("horaire_affectation",StringType,false),
            StructField("etp",DoubleType,false),
      
            StructField("filepath",StringType,false)
      ))

    //------------HRA TypeHeure
      case "hra_typeheure" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_affection_cycle",DateType,false),
            StructField("date_fin_affectation_cycle",DateType,false),
            StructField("code_affection_cycle",StringType,false),
            StructField("libelle_type_heure",StringType,false),
      
            StructField("filepath",StringType,false)
      ))
  
      //------------HRA TypeHeure
      case "hra_type_heure" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_affection_cycle",DateType,false),
            StructField("date_fin_affectation_cycle",DateType,false),
            StructField("code_affection_cycle",StringType,false),
            StructField("libelle_type_heure",StringType,false),
      
            StructField("filepath",StringType,false)
      ))
  
    //------------HRA Enfants
      case "hra_enfants" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("numero_ordre",StringType,false),
            StructField("date_naissance",DateType,false),
            StructField("prenom",StringType,false),
            StructField("nom",StringType,false),
            StructField("sexe",StringType,false),
            StructField("date_deces",StringType,false),
            StructField("enfant_a_charge",StringType,false),
            StructField("date_deb_prise_en_charge",DateType,false),
            StructField("date_fin_prise_en_charge",DateType,false),
            StructField("enfant_a_charge_secu",StringType,false),
            StructField("date_deb_prise_en_charge_secu",DateType,false),
            StructField("date_fin_prise_en_charge_secu",DateType,false),
      
            StructField("filepath",StringType,false)
      ))
 
    //------------HRA Natio Sec
      case "hra_natio_sec" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("nationalite_secondaire",StringType,false),
      
            StructField("filepath",StringType,false)
      ))

    //------------HRA Suspension
      case "hra_suspension" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_situation",DateType,false),
            StructField("date_fin_situation",DateType,false),
            StructField("situation",StringType,false),        
            StructField("categorie",StringType,false),        
            StructField("libelle_categorie",StringType,false),
            StructField("motif",StringType,false),
            StructField("libelle_motif",StringType,false),
            StructField("flag_conges",StringType,false),
      
            StructField("filepath",StringType,false)
      ))
  
    //------------HRA Carriere
      case "hra_carriere" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_carriere",DateType,false),
            StructField("date_fin_carriere",DateType,false),
            StructField("qualification",StringType,false),
            StructField("libelle_qualification",StringType,false),
            StructField("classification",StringType,false),
            StructField("libelle_classification",StringType,false),
            StructField("coefficient_base",StringType,false),
            StructField("coefficient_spe",StringType,false),
            StructField("convention_collective",StringType,false),
            StructField("regime_cotis_retraite",StringType,false),
            StructField("groupe_couture",StringType,false),
            StructField("niveau_couture",StringType,false),
      
            StructField("filepath",StringType,false)
      ))
 
    //------------HRA Salaire
      case "hra_salaire" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_effet_remu",DateType,false),
            StructField("date_fin_remu",DateType,false),
            StructField("montant_remu_base",DoubleType,false),
            StructField("montant_horaire",DoubleType,false),
            StructField("montant_periode_paie",DoubleType,false),
            StructField("montant_annuel",DoubleType,false),
      
            StructField("filepath",StringType,false)
      ))

    //------------HRA Paie
      case "hra_paie" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("period_paie",StringType,false),
            StructField("periode_valorisation",StringType,false),
            StructField("code_rubr",StringType,false),
            StructField("compte_comptable",StringType,false),
            StructField("base",DoubleType,false),
            StructField("montant_salarial",DoubleType,false),
            StructField("montant_patronal",DoubleType,false),
      
            StructField("filepath",StringType,false)
      ))
  
    //------------HRA Rubriques paie
      case "hra_rubr_paie" =>
      StructType( List(
            StructField("code_rubr",StringType,false),
            StructField("libelle_rubr",StringType,false),
            StructField("flag_salarial",StringType,false),
            StructField("flag_debit",StringType,false),
            StructField("compte_comptable",StringType,false),
      
            StructField("filepath",StringType,false)
      ))  
  
    //------------HRA Cet
      case "hra_cet" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_operation",DateType,false),
            StructField("type_operation",StringType,false),
            StructField("libelle_type_operation",StringType,false),
            StructField("compte_operation",StringType,false),
            StructField("libelle_compte",StringType,false),
            StructField("jour",DoubleType,false),
      
            StructField("filepath",StringType,false)
      ))  
  
   //------------HRA Ref Centre cout
      case "hra_ref_centrecout" =>
      StructType( List(
            StructField("centre_cout",StringType,true),
            StructField("libelle_centre_cout",StringType,false),
            StructField("code_departement",StringType,false),
            StructField("libelle_departement",StringType,false),
            StructField("code_direction",StringType,false),
            StructField("libelle_direction",StringType,false),
            StructField("code_etablissement",StringType,false),
            StructField("libelle_etablissement",StringType,false),
            StructField("code_societe",StringType,false),
            StructField("libelle_societe",StringType,false),
      
            StructField("filepath",StringType,false)
      ))  
  
/*************************GESTOR*************************************/
  
    //------------Absprev
    case "absprev" =>
    StructType( List(
            StructField("nummat",IntegerType,false), 
            StructField("dateval",DateType,true), 
            StructField("hdeb",DoubleType,false), 
            StructField("hfin",DoubleType,false), 
            StructField("duree",DoubleType,false), 
            StructField("nbrvac",DoubleType,false), 
            StructField("code",StringType,true), 
            StructField("type",IntegerType,false), 
            StructField("signature",IntegerType,false), 
            StructField("matricule",StringType,true),
            StructField("signature_desc",StringType,false),
            StructField("type_libelle",StringType,false),
      
            StructField("filepath",StringType,false)
    ))
  
  //------------Codeevt
    case "codeevt" =>
    StructType( List(
            StructField("numero",IntegerType,false), 
            StructField("code",StringType,true), 
            StructField("libelle",StringType,true), 
            StructField("heure",IntegerType,false), 
            StructField("famregroup",IntegerType,false), 
            StructField("type",IntegerType,false), 
            StructField("type_libelle",StringType,false),
            StructField("famregroup_libelle",StringType,false),
      
            StructField("filepath",StringType,false)
    ))  
  
    //------------Compteusj
    case "compteurj" =>
    StructType( List(
            StructField("nummat",IntegerType,false),
            StructField("datej",DateType,false),
            StructField("cpt111",DoubleType,false),
            StructField("cpt113",DoubleType,false),
            StructField("cpt115",DoubleType,false),
            StructField("cpt117",DoubleType,false),
            StructField("cpt135",DoubleType,false),
            StructField("cpt155",DoubleType,false),
            StructField("cpt163",DoubleType,false),
            StructField("cpt171",DoubleType,false),
            StructField("cpt175",DoubleType,false),
            StructField("cpt179",DoubleType,false),
            StructField("cpt183",DoubleType,false),
            StructField("cpt185",DoubleType,false),
            StructField("cpt187",DoubleType,false),
            StructField("cpt189",DoubleType,false),
            StructField("cpt203",DoubleType,false),
            StructField("cpt245",DoubleType,false),
            StructField("cpt247",DoubleType,false),
            StructField("cpt249",DoubleType,false),
            StructField("cpt257",DoubleType,false),
            StructField("cpt275",DoubleType,false),
            StructField("cpt281",DoubleType,false),
            StructField("cpt285",DoubleType,false),
            StructField("matricule",StringType,true),
      
            StructField("filepath",StringType,false)
    ))

    //------------Compteurs
    case "compteurs" =>
    StructType( List(
            StructField("numero",IntegerType,false), 
            StructField("libcourt",StringType,false), 
            StructField("liblong",StringType,false), 
            StructField("heurejour",IntegerType,false), 
            StructField("famille",IntegerType,false), 
            StructField("libelle",StringType,false),
      
            StructField("filepath",StringType,false)
    ))

    //------------Detchamps
    case "detchamps" =>
    StructType( List(
            StructField("nummat",StringType,false),
            StructField("datedebut",DateType,false),
            StructField("datefin",DateType,false),
            StructField("cl_drtrtt",StringType,false),
            StructField("cl_drtlibre",StringType,false),
            StructField("cl_drcaptl",StringType,false),
            StructField("cl_ticket",StringType,false),
            StructField("cl_hcontnuit",StringType,false),
            StructField("cl_drhsup",StringType,false),
            StructField("cl_hssem",StringType,false),
            StructField("cl_hsnuit",StringType,false),
            StructField("cl_hssam",StringType,false),
            StructField("cl_hsdimjf",StringType,false),
            StructField("cl_indicpaye",StringType,false),
            StructField("cl_maxrdc",StringType,false),
            StructField("cl_ctrctclosure",StringType,false),
            StructField("cl_multi_contra",StringType,false),
            StructField("cl_teletra",StringType,false),
            StructField("cl_trav_dim",StringType,false),
            StructField("cl_zone_tour",StringType,false),
            StructField("cl_tele_int",StringType,false),
            StructField("sop_charte",StringType,false),
            StructField("matricule",StringType,true),
            StructField("valeur",StringType,false),
      
            StructField("filepath",StringType,false)
    ))

    //------------Indicateurs
    case "indicateurs" =>
    StructType( List(
             StructField("ind_num",IntegerType,false),
             StructField("ind_type",IntegerType,false),
             StructField("ind_code",StringType,false),
             StructField("ind_date_deb",DateType,false),
             StructField("ind_date_fin",DateType,false),
             StructField("pl_jour",StringType,false),
             StructField("pl_partiel",StringType,false),
             StructField("dispo",StringType,false),
             StructField("evt_pres",StringType,false),
             StructField("drt_crea_period",StringType,false),
             StructField("drt_periode_sui",StringType,false),
             StructField("drt_code_imp",StringType,false),
             StructField("drt_cpt_imp",StringType,false),
             StructField("drt_conso_cpt",StringType,false),
             StructField("drt_conso_code",StringType,false),
             StructField("ph_primeq",StringType,false),
             StructField("ph_primhab",StringType,false),
             StructField("ph_drttl",StringType,false),
             StructField("ph_drtrtt",StringType,false),
             StructField("ev_jtrav",StringType,false),
             StructField("ev_prod",StringType,false),
             StructField("ev_tpslib",StringType,false),
             StructField("ev_tpsrtt",StringType,false),
             StructField("ev_ticket",StringType,false),
             StructField("ev_panier",StringType,false),
             StructField("ev_habill",StringType,false),
             StructField("ev_typeabs",StringType,false),
             StructField("ev_tteleg",StringType,false),
             StructField("ev_tteconv",StringType,false),
             StructField("ph_panier",StringType,false),
             StructField("ph_derog",StringType,false),
             StructField("ev_chance",StringType,false),
             StructField("ev_prime_douche",StringType,false),
             StructField("ph_prime_douche",StringType,false),
             StructField("ph_rert",StringType,false),
             StructField("ev_teletra",StringType,false),
             StructField("ph_paspause",StringType,false),
             StructField("ph_absduree",StringType,false),
             StructField("ev_presd",StringType,false),
             StructField("ph_sol",StringType,false),
             StructField("ph_nuit",StringType,false),
             StructField("ph_hs",StringType,false),
             StructField("ev_prolon",StringType,false),
      
             StructField("filepath",StringType,false)
    ))

    //------------Perso Droit
    case "perso_droit" =>
    StructType( List(
            StructField("nummat",IntegerType,false),
            StructField("pedr_code",StringType,false),
            StructField("pedr_datedeb",DateType,false),
            StructField("pedr_datefin",DateType,false),
            StructField("pedr_classe",IntegerType,false),
            StructField("pedr_unit",IntegerType,false),
            StructField("pedr_typectrl",IntegerType,false),
            StructField("pedr_acquis",DoubleType,false),
            StructField("pedr_principal",DoubleType,false),
            StructField("pedr_sup",DoubleType,false),
            StructField("pedr_sup1",DoubleType,false),
            StructField("pedr_sup2",DoubleType,false),
            StructField("pedr_reliquat",DoubleType,false),
            StructField("pedr_dtreliquat",DateType,false),
            StructField("pedr_relperdu",DoubleType,false),
            StructField("pedr_anticipe",DoubleType,false),
            StructField("pedr_consomme",DoubleType,false),
            StructField("pedr_prvalide",DoubleType,false),
            StructField("pedr_prattente",DoubleType,false),
            StructField("pedr_seuil_solde",DoubleType,false),
            StructField("matricule",StringType,true),
            StructField("refd_valeur",StringType,false),
            StructField("pedr_typectrl_libelle",StringType,false),
      
            StructField("filepath",StringType,false)
    ))

    //------------Perso Droitj
    case "perso_droitj" =>
    StructType( List(
            StructField("nummat",IntegerType,false), 
            StructField("pedr_code",StringType,false), 
            StructField("pedr_dateval",DateType,false), 
            StructField("pedr_valeur",DoubleType,false), 
            StructField("pedr_prev",DoubleType,false), 
            StructField("matricule",StringType,true),
      
            StructField("filepath",StringType,false)
    ))
  
/*************************BUSINESS*************************************/
  
    //------------Action Logement
    case "action_logement" =>
    StructType( List(
            StructField("periode",DateType,true), 
            StructField("matricule_hra",StringType,true), 
            StructField("matricule_workday",StringType,false), 
            StructField("nom",StringType,false), 
            StructField("prenom",StringType,false), 
            StructField("thematique_action_logement",StringType,false),
      
            StructField("filepath",StringType,false)
    ))

    //------------Eligibilite PSB
    case "eligibilite_psb" =>
    StructType( List(
            StructField("periode",DateType,true), 
            StructField("matricule_hra",StringType,true), 
            StructField("matricule_workday",StringType,false), 
            StructField("nom",StringType,false), 
            StructField("prenom",StringType,false),
      
            StructField("filepath",StringType,false)
    ))
 
    //------------Montant LTI
    case "montant_lti" =>
    StructType( List(
            StructField("periode",DateType,true), 
            StructField("annee",IntegerType,true), 
            StructField("matricule_hra",StringType,true), 
            StructField("matricule_workday",StringType,false), 
            StructField("nom",StringType,false), 
            StructField("prenom",StringType,false), 
            StructField("montant_lti_annuel",DoubleType,false),
      
            StructField("filepath",StringType,false)
    ))
  
    //------------Montant Prime Objectif Theorique
    case "montant_prime_objectif_theorique" =>
    StructType( List(
            StructField("periode",DateType,true), 
            StructField("annee_mois",IntegerType,true), 
            StructField("matricule_hra",StringType,true), 
            StructField("matricule_workday",StringType,true), 
            StructField("nom",StringType,false), 
            StructField("prenom",StringType,false), 
            StructField("montant_prime_objectif_theorique",DoubleType,false),
      
            StructField("filepath",StringType,false)
    ))  

    //------------Percol PEB CCB
    case "percol_peb_ccb" =>
    StructType( List(
            StructField("periode",DateType,true), 
            StructField("matricule_hra",StringType,true), 
            StructField("matricule_workday",StringType,true), 
            StructField("nom",StringType,false), 
            StructField("prenom",StringType,false), 
            StructField("flag_amundi_per_col",IntegerType,false),
            StructField("flag_amundi_peg",IntegerType,false),
            StructField("flag_amundi_ccb",IntegerType,false),
      
            StructField("filepath",StringType,false)
    ))  

    //------------Politique voiture et mobilite
    case "politique_voiture_mobilite" =>
    StructType( List(
            StructField("periode",DateType,true), 
            StructField("matricule_hra",StringType,true), 
            StructField("nom",StringType,false), 
            StructField("prenom",StringType,false), 
            StructField("date_debut_avantage",DateType,false), 
            StructField("date_fin_avantage",DateType,false),
            StructField("categorie_avantage",StringType,false),
            StructField("type_avantage",StringType,false),
      
            StructField("filepath",StringType,false)
    ))

    //------------Referentiel absences
    case "referentiel_absences" =>
    StructType( List(
            StructField("periode",DateType,false), 
            StructField("code_absence",StringType,true), 
            StructField("libelle_code_absence",StringType,true), 
            StructField("motif_absence",StringType,false), 
            StructField("famille_absence",StringType,false), 
            StructField("absence_taux_absenteisme",StringType,false), 
            StructField("absence_previsible_imprevisible",StringType,false),
			StructField("flag_etp_productif",StringType,false),
			StructField("flag_taux_absenteisme",StringType,false),
			StructField("flag_prolongation",StringType,false),
            StructField("type_absence",StringType,false),
      
            StructField("filepath",StringType,false)
    ))
  
  //------------AG Etablissement  
  case "ag_etablissement" =>
  StructType ( List(
             StructField("periode",StringType,false),
             StructField("libelle_etablissement",StringType,false),
             StructField("code_etablissement",StringType,false),
             StructField("pourcentage_ag",StringType,false),
      
            StructField("filepath",StringType,false)
  ))

  //------------Rubriques de paie
  case "rubriques_paie" =>
  StructType ( List(
             StructField("code_rubrique_paie_hra",StringType,false),
             StructField("nature_comptable",StringType,false),
             StructField("code_rubrique_paie",StringType,false),
             StructField("libelle_rubrique_paie",StringType,false),
             StructField("code_rubrique_paie_niveau_4",StringType,false),
             StructField("libelle_rubrique_paie_niveau_4",StringType,false),
             StructField("code_rubrique_paie_niveau_3",StringType,false),
             StructField("libelle_rubrique_paie_niveau_3",StringType,false),
             StructField("code_rubrique_paie_niveau_2",StringType,false),
             StructField("libelle_rubrique_paie_niveau_2",StringType,false),
             StructField("code_rubrique_paie_niveau_1",StringType,false),
             StructField("libelle_rubrique_paie_niveau_1",StringType,false),
             StructField("flag_montant_masse_salariale_brute",StringType,false),
             StructField("flag_montant_aw4",StringType,false),
             StructField("flag_montant_aw6",StringType,false),
             StructField("flag_montant_rem_nao",StringType,false),
             StructField("flag_montant_rem_bs",StringType,false),
             StructField("flag_montant_rem_benchmark",StringType,false),
             StructField("flag_montant_rem_cible",StringType,false),
             StructField("flag_montant_rem_reelle",StringType,false),
      
             StructField("filepath",StringType,false)
  ))

  //------------Organisation Italie
  case "organisation_chanel_italie" =>
  StructType ( List(
             StructField("niveau_1",StringType,false),
             StructField("niveau_2_division_consolidee",StringType,false),
             StructField("niveau_3_division_detaillee",StringType,false),
             StructField("niveau_4_direction",StringType,false),
             StructField("niveau_5_departement",StringType,false),
             StructField("cost_center_code",StringType,false),
             StructField("cost_center_name",StringType,false),
      
             StructField("filepath",StringType,false)
  ))
  
    //------------Hierachie Pb
  case "hierarchy_pb" =>
  StructType ( List(
             StructField("cost_center_code",StringType,false),
             StructField("cost_center_name",StringType,false),
             StructField("dird_direction_detail_code",StringType,false),
             StructField("dird_direction_detail_name",StringType,false),
             StructField("dirr_direction_code",StringType,false),
             StructField("dirr_direction_name",StringType,false),
             StructField("dirb_direction_psb_budget_code",StringType,false),
             StructField("dirb_direction_psb_budget_name",StringType,false),
             StructField("dirp_direction_presentation_code",StringType,false),
             StructField("dirp_direction_presentation_name",StringType,false),
      
             StructField("filepath",StringType,false)
  ))
  
     //------------source_recruitment
    case "source_recruitment" =>
    StructType ( List (
           StructField("periode",StringType,true),
           StructField("valeur_wd",StringType,true),
           StructField("source_de_recrutement",StringType,false),
           StructField("source_de_recrutement_consolide",StringType,false),
           StructField("type_de_recrutement",StringType,false),
      
           StructField("filepath",StringType,false)
    ))  
                
/*************************PA HISTO GRADE*************************************/
    case "pa_histograde" =>
    StructType( List(
            StructField("matricule_hr_access",StringType,true), 
            StructField("matricule_wd",StringType,false), 
            StructField("manager_reference",StringType,true), 
            StructField("manager_last_name",StringType,false), 
            StructField("manager_first_name",StringType,false), 
            StructField("grade",StringType,false), 
            StructField("effective_compensation_change_date",DateType,false), 
            StructField("end_compensation_change_date",DateType,false),
      
            StructField("filepath",StringType,false)
    ))  

/*************************ADP*************************************/
  
    //------------HRA Salaries
     case "adp_salaries" =>
     StructType( List(
            StructField("matricule_hr_access",StringType,true), 
            StructField("matricule_wd",StringType,false), 
            StructField("compte_ad",StringType,false), 
            StructField("qualite",StringType,false), 
            StructField("nom_usuel",StringType,false), 
            StructField("nom_patronymique",StringType,false), 
            StructField("prenom",StringType,false), 
            StructField("sexe",StringType,false), 
            StructField("nir",StringType,false), 
            StructField("etat_civil",StringType,false), 
            StructField("libelle_etat_civil",StringType,false), 
            StructField("date_naissance",DateType,false), 
            StructField("ville_naissance",StringType,false), 
            StructField("pays_naissance",StringType,false), 
            StructField("dept_naissance",StringType,false), 
            StructField("nationalite_princ",StringType,false), 
            StructField("pays_adresse",StringType,false), 
            StructField("no_adresse",StringType,false), 
            StructField("bis_ter_adresse",StringType,false), 
            StructField("nature_voie",StringType,false), 
            StructField("nom_voie",StringType,false), 
            StructField("complement_adresse",StringType,false), 
            StructField("code_insee_commune",StringType,false), 
            StructField("commune",StringType,false), 
            StructField("code_postal",StringType,false), 
            StructField("bureau_distributeur",StringType,false), 
            StructField("email_pro",StringType,false), 
            StructField("email_perso",StringType,false), 
            StructField("prenom_conjoint",StringType,false), 
            StructField("nom_conjoint",StringType,false), 
            StructField("entree_groupe",DateType,false), 
            StructField("anciennete_groupe",DateType,false), 
            StructField("derniere_embauche",DateType,false), 
            StructField("anciennete_poste",DateType,false),
            StructField("population_particuliere",StringType,false),
      
            StructField("filepath",StringType,false)
     )) 
 
    //------------HRA Contrat
      case "adp_contrat" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_contrat",DateType,true),
            StructField("date_fin_contrat",DateType,false),
            StructField("type_contrat",StringType,true),
            StructField("libelle_type_contrat",StringType,true),
            StructField("nature_contrat",StringType,true),
            StructField("libelle_nature_contrat",StringType,true),
            StructField("date_fin_previsionnelle",DateType,false),
            StructField("date_fin_periode_essai",DateType,false),
            StructField("motif_entree",StringType,false),
            StructField("libelle_motif_entree",StringType,false),
            StructField("motif_sortie",StringType,false),
            StructField("libelle_motif_sortie",StringType,false),
            StructField("code_recours",StringType,false),
            StructField("libelle_recours",StringType,false),
      
            StructField("filepath",StringType,false)
      )) 

    //-----------HRA Emploi
       case "adp_emploi" =>
       StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_effet_emploi",DateType,true),
            StructField("date_fin_emploi",DateType,false),
            StructField("code_emploi",StringType,false),
            StructField("libelle_emploi",StringType,false),
            StructField("taux_emploi",DoubleType,false),
      
            StructField("filepath",StringType,false)
       )) 

    //------------HRA Centre Cout
      case "adp_centrecout" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_centre_cout",DateType,true),
            StructField("date_fin_centre_cout",DateType,false),
            StructField("centre_cout",StringType,true),
            StructField("libelle_centre_cout",StringType,false),
            StructField("sous_compte",StringType,false),
            StructField("taux_repartition",StringType,false),
            StructField("date_deb_etablissement",DateType,true),
            StructField("date_fin_etablissement",DateType,false),
            StructField("code_etablissement",StringType,true),
            StructField("libelle_etablissement",StringType,false),
            StructField("date_deb_societe",DateType,true),
            StructField("date_fin_societe",DateType,false),
            StructField("code_societe",StringType,true),
            StructField("libelle_societe",StringType,false),
            StructField("motif_entree",StringType,false),
            StructField("date_deb_org",DateType,true),
            StructField("date_fin_org",DateType,false),
            StructField("code_direction",StringType,true),
            StructField("libelle_direction",StringType,false),
            StructField("code_departement",StringType,true),
            StructField("libelle_departement",StringType,false),
      
            StructField("filepath",StringType,false)
      )) 

    //------------HRA Temps Travail
      case "adp_tempstravail" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_effet_tps_contractuel",DateType,false),
            StructField("date_fin_tps_contractuel",DateType,false),
            StructField("type_temps_contractuel",StringType,false),
            StructField("libelle_type_temps_contractuel",StringType,false),
            StructField("code_modalite_horaire",StringType,false),
            StructField("nb_heure_presence_sem",DoubleType,false),
            StructField("nb_heure_presence_mois",DoubleType,false),
            StructField("nb_heure_payes_sem",DoubleType,false),
            StructField("nb_heure_payes_mois",DoubleType,false),
            StructField("nb_jours_travailles_an",DoubleType,false),
            StructField("taux_travail",DoubleType,false),
      
            StructField("filepath",StringType,false)
      )) 

    //------------HRA Etp
      case "adp_etp" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_etp",DateType,false),
            StructField("date_fin_etp",DateType,false),
            StructField("horaire_affectation",StringType,false),
            StructField("etp",DoubleType,false),
      
            StructField("filepath",StringType,false)
      ))

    //------------HRA TypeHeure
      case "adp_typeheure" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_affection_cycle",DateType,false),
            StructField("date_fin_affectation_cycle",DateType,false),
            StructField("code_affection_cycle",StringType,false),
            StructField("libelle_type_heure",StringType,false),
      
            StructField("filepath",StringType,false)
      ))
  
      //------------HRA TypeHeure
      case "adp_type_heure" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_affection_cycle",DateType,false),
            StructField("date_fin_affectation_cycle",DateType,false),
            StructField("code_affection_cycle",StringType,false),
            StructField("libelle_type_heure",StringType,false),
      
            StructField("filepath",StringType,false)
      ))
  
    //------------HRA Enfants
      case "adp_enfants" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("numero_ordre",StringType,false),
            StructField("date_naissance",DateType,false),
            StructField("prenom",StringType,false),
            StructField("nom",StringType,false),
            StructField("sexe",StringType,false),
            StructField("date_deces",StringType,false),
            StructField("enfant_a_charge",StringType,false),
            StructField("date_deb_prise_en_charge",DateType,false),
            StructField("date_fin_prise_en_charge",DateType,false),
            StructField("enfant_a_charge_secu",StringType,false),
            StructField("date_deb_prise_en_charge_secu",DateType,false),
            StructField("date_fin_prise_en_charge_secu",DateType,false),
      
            StructField("filepath",StringType,false)
      ))
 
    //------------HRA Natio Sec
      case "adp_natio_sec" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("nationalite_secondaire",StringType,false),
      
            StructField("filepath",StringType,false)
      ))

    //------------HRA Suspension
      case "adp_suspension" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_situation",DateType,false),
            StructField("date_fin_situation",DateType,false),
            StructField("situation",StringType,false),        
            StructField("categorie",StringType,false),        
            StructField("libelle_categorie",StringType,false),
            StructField("motif",StringType,false),
            StructField("libelle_motif",StringType,false),
            StructField("flag_conges",StringType,false),
      
            StructField("filepath",StringType,false)
      ))
  
    //------------HRA Carriere
      case "adp_carriere" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_deb_carriere",DateType,false),
            StructField("date_fin_carriere",DateType,false),
            StructField("qualification",StringType,false),
            StructField("libelle_qualification",StringType,false),
            StructField("classification",StringType,false),
            StructField("libelle_classification",StringType,false),
            StructField("coefficient_base",StringType,false),
            StructField("coefficient_spe",StringType,false),
            StructField("convention_collective",StringType,false),
            StructField("regime_cotis_retraite",StringType,false),
            StructField("groupe_couture",StringType,false),
            StructField("niveau_couture",StringType,false),
      
            StructField("filepath",StringType,false)
      ))
 
    //------------HRA Salaire
      case "adp_salaire" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_effet_remu",DateType,false),
            StructField("date_fin_remu",DateType,false),
            StructField("montant_remu_base",DoubleType,false),
            StructField("montant_horaire",DoubleType,false),
            StructField("montant_periode_paie",DoubleType,false),
            StructField("montant_annuel",DoubleType,false),
      
            StructField("filepath",StringType,false)
      ))

    //------------HRA Paie
      case "adp_paie" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("period_paie",StringType,false),
            StructField("periode_valorisation",StringType,false),
            StructField("code_rubr",StringType,false),
            StructField("compte_comptable",StringType,false),
            StructField("base",DoubleType,false),
            StructField("montant_salarial",DoubleType,false),
            StructField("montant_patronal",DoubleType,false),
            StructField("paiezad",StringType,false),
            StructField("num_pac",StringType,false),
      
            StructField("filepath",StringType,false)
      ))
  
    //------------HRA Rubriques paie
      case "adp_rubr_paie" =>
      StructType( List(
            StructField("code_rubr",StringType,false),
            StructField("libelle_rubr",StringType,false),
            StructField("flag_salarial",StringType,false),
            StructField("flag_debit",StringType,false),
      
            StructField("filepath",StringType,false)
      ))  
  
    //------------HRA Cet
      case "adp_cet" =>
      StructType( List(
            StructField("matricule_hr_access",StringType,true),
            StructField("matricule_wd",StringType,false),
            StructField("date_operation",DateType,false),
            StructField("type_operation",StringType,false),
            StructField("libelle_type_operation",StringType,false),
            StructField("compte_operation",StringType,false),
            StructField("libelle_compte",StringType,false),
            StructField("jour",DoubleType,false),
      
            StructField("filepath",StringType,false)
      ))  
  
   //------------HRA Ref Centre cout
      case "adp_ref_centre_cout" =>
      StructType( List(
            StructField("centre_cout",StringType,true),
            StructField("libelle_centre_cout",StringType,false),
            StructField("code_departement",StringType,false),
            StructField("libelle_departement",StringType,false),
            StructField("code_direction",StringType,false),
            StructField("libelle_direction",StringType,false),
            StructField("code_etablissement",StringType,false),
            StructField("libelle_etablissement",StringType,false),
            StructField("code_societe",StringType,false),
            StructField("libelle_societe",StringType,false),
      
            StructField("filepath",StringType,false)
      ))  

  /*************************CORNERSTONE*************************************/
  
   //------------FORMATION
      case "cornerstone_formation" =>
      StructType( List(
            StructField("id_utilisateur",StringType,true),
            StructField("fournisseur_formation",StringType,false),
            StructField("perimetre_rh",StringType,false),
            StructField("titre_formation",StringType,true),
            StructField("organisme_formation",StringType,false),
            StructField("action_formation",StringType,false),
            StructField("formation_obligatoire",StringType,false),
            StructField("habilitation_certification_diplome",StringType,false),
            StructField("matiere_formation_parent",StringType,false),
            StructField("matiere_formation",StringType,false),
            StructField("axe",StringType,false),
            StructField("id_objet_formation",StringType,false),
            StructField("numero_repere_formation",IntegerType,false),
            StructField("type_stage",StringType,false),
            StructField("budget_developement_talents",StringType,false),
            StructField("interieur_parcours",StringType,false),
            StructField("reconversion",StringType,false),
            StructField("modalite",StringType,false),
            StructField("type_conges_formation",StringType,false),
            StructField("coaching",StringType,false),
            StructField("realisation",StringType,false),
            StructField("type_formation",StringType,false),
            StructField("statut_recapitulatif",StringType,false),
            StructField("nombre_stagiaire_previsionnel",IntegerType,false),
            StructField("budget_previsionnel",DoubleType,false),
            StructField("heures_formation",DoubleType,false),
            StructField("prix_formation",DoubleType,false),
            StructField("date_debut_formation",TimestampType,false),
            StructField("date_fin_formation",TimestampType,false),
            StructField("facture",StringType,false),
            StructField("feuille_emargement",StringType,false),
            StructField("montant_abondement_cpf_entreprise",DoubleType,false),
            StructField("montant_salarie_cpf_autre",DoubleType,false),
            StructField("frais_reprographie_materiel_pedagogique",StringType,false),
            StructField("duree_partie",IntegerType,false),
            StructField("duree_pause_partie",IntegerType,false),
            StructField("utilisateur_assiste_partie",StringType,false),
            StructField("frais_ingenierie",DoubleType,false),
            StructField("frais_deplacement_hebergement_repas_formateur",DoubleType,false),
            StructField("frais_deplacement_hebergement_repas_participant",DoubleType,false),
            StructField("montant_charge_opca",DoubleType,false),
            StructField("date_creation_formation",TimestampType,false),
            StructField("date_derniere_modification",TimestampType,false),
            StructField("date_debut_partie",TimestampType,false),
            StructField("date_fin_partie",TimestampType,false),
            StructField("date_achevement_recapitulatif",TimestampType,false),
            StructField("date_inscription_recapitulatif",TimestampType,false),
            StructField("date_dernier_changement_statut_recapitulatif",TimestampType,false),
            StructField("supprime_recapitulatif",StringType,false),
            StructField("categorie_action",StringType,false),
      
            StructField("filepath",StringType,false)
          ))
  
   //------------EVALUATION
      case "cornerstone_evaluation_formation" =>
      StructType( List(
            StructField("id_utilisateur",StringType,true),
            StructField("type_formation",StringType,true),
            StructField("id_objet_formation",StringType,true),
            StructField("titre_formation",StringType,true),
            StructField("question",StringType,true),
            StructField("reponse",StringType,false),
      
            StructField("filepath",StringType,false)
          ))
  
  
  case default => null
  }
  
   return struct
}