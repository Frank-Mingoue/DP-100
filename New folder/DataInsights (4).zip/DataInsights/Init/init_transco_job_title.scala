// Databricks notebook source
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// MAGIC %md ## 1- Read Transco Data from datalake

// COMMAND ----------

val df_path = "dbfs:/mnt/raw_container/business/job_title/*/*/*/*/"
val df_libelle_poste = spark.read.format("csv").option("sep",";").option("header",true).load(df_path).distinct
display(df_libelle_poste)

// COMMAND ----------

val df_path = "dbfs:/mnt/raw_container/hra/hra_emploi/*/*/*/*/"
val df_hra_emploi = spark.read.format("csv").option("sep",";").option("header",true).load(df_path).distinct
display(df_hra_emploi)

// COMMAND ----------

// DBTITLE 1,2- Transco
val df_transco_emploi = df_hra_emploi.as("a").join(df_libelle_poste.as("b"),
                                          $"a.MATRICULE_WD" === $"b.matricule_wd" and
                                          $"a.LIBELLE_EMPLOI" === $"b.libelle_poste_init",
                                          "left")
val df_transco_emploi_filter = df_transco_emploi.withColumn("libelle_poste_new", when($"libelle_poste_new".isNull,$"LIBELLE_EMPLOI")
                                                                                    .otherwise($"libelle_poste_new"))
                                       .drop("LIBELLE_EMPLOI")
                                      .withColumnRenamed("libelle_poste_new","LIBELLE_EMPLOI")
                                      .select("MATRICULE_HR_ACCESS","a.MATRICULE_WD","DATE_EFFET_EMPLOI","DATE_FIN_EMPLOI","CODE_EMPLOI","LIBELLE_EMPLOI","TAUX_EMPLOI"
                                             )
display(df_transco_emploi_filter)

// COMMAND ----------

val save_path = "dbfs:/mnt/raw_container/hra/hra_emploi/2021/01/01/1/HRA_emploi_20210429_1020_transco"
save_df(df_transco_emploi_filter,save_path)