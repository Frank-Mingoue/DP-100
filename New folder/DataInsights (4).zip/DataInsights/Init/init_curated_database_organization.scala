// Databricks notebook source
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

// DBTITLE 1,Create database organization
spark.sql(""" create database if not exists organization; """)

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.sap_cc
spark.sql(""" drop table if exists organization.sap_cc; """)
spark.sql(""" 
create table if not exists organization.sap_cc (
costcentercode string not null,
costcentername string not null,
centertype string,
companycode string not null,
company string not null,
marketsegment string,
activitydomain string,
standardcostcenter string,
essbasefunction string,
profitcenter string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/sap/sap_cc/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.sap_cc
if(spark.catalog.tableExists("organization.sap_cc")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.sap_cc")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.sap_cc_rejected
spark.sql(""" drop table if exists organization.sap_cc_rejected; """)
spark.sql(""" 
CREATE TABLE organization.sap_cc_rejected (
costcentercode string,
costcentername string,
centertype string,
companycode string,
company string,
marketsegment string,
activitydomain string,
standardcostcenter string,
essbasefunction string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/sap/sap_cc/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.sap_cc_rejected
if(spark.catalog.tableExists("organization.sap_cc_rejected"))// test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.sap_cc_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.hra_centrecout
spark.sql(""" drop table if exists organization.hra_centrecout; """)
spark.sql(""" 
create table if not exists organization.hra_centrecout (
matricule_hr_access string not null,
matricule_wd string,
date_deb_centre_cout date not null,
date_fin_centre_cout date,
centre_cout string not null,
libelle_centre_cout string,
sous_compte string,
taux_repartition string,
date_deb_etablissement date not null,
date_fin_etablissement date,
code_etablissement string not null,
libelle_etablissement string,
date_deb_societe date not null,
date_fin_societe date,
code_societe string not null,
libelle_societe string,
motif_entree string,
date_deb_org date,
date_fin_org date,
code_direction string not null,
libelle_direction string,
code_departement string not null,
libelle_departement string, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/hra/hra_centrecout";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.hra_centrecout
if(spark.catalog.tableExists("organization.hra_centrecout")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.hra_centrecout")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.hra_centrecout_rejected
spark.sql(""" drop table if exists organization.hra_centrecout_rejected; """)
spark.sql(""" 
create table if not exists organization.hra_centrecout_rejected (
matricule_hr_access string,
matricule_wd string,
date_deb_centre_cout string,
date_fin_centre_cout string,
centre_cout string,
libelle_centre_cout string,
sous_compte string,
taux_repartition string,
date_deb_etablissement string,
date_fin_etablissement string,
code_etablissement string,
libelle_etablissement string,
date_deb_societe string,
date_fin_societe string,
code_societe string,
libelle_societe string,
motif_entree string,
date_deb_org string,
date_fin_org string,
code_direction string,
libelle_direction string,
code_departement string,
libelle_departement string, 
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/hra/hra_centrecout/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.hra_centrecout_rejected
if(spark.catalog.tableExists("organization.hra_centrecout_rejected"))// test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.hra_centrecout_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.hra_ref_centrecout
spark.sql(""" drop table if exists organization.hra_ref_centrecout; """)
spark.sql(""" 
create table if not exists organization.hra_ref_centrecout (
centre_cout string not null,
libelle_centre_cout string,
code_departement string not null,
libelle_departement string,
code_direction string not null,
libelle_direction string,
code_etablissement string not null,
libelle_etablissement string,
code_societe string not null,
libelle_societe string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/hra/hra_ref_centrecout";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.hra_ref_centre
if(spark.catalog.tableExists("organization.hra_ref_centrecout")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.hra_ref_centrecout")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.hra_ref_centrecout_rejected
spark.sql(""" drop table if exists organization.hra_ref_centrecout_rejected; """)
spark.sql(""" 
create table if not exists organization.hra_ref_centrecout_rejected (
centre_cout string not null,
libelle_centre_cout string,
code_departement string not null,
libelle_departement string,
code_direction string not null,
libelle_direction string,
code_etablissement string not null,
libelle_etablissement string,
code_societe string not null,
libelle_societe string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/hra/hra_ref_centrecout/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.hra_ref_centrecout_rejected
if(spark.catalog.tableExists("organization.hra_ref_centrecout_rejected"))// test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.hra_ref_centrecout_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.organisation_chanel_italie
spark.sql(""" drop table if exists organization.organisation_chanel_italie; """)
spark.sql(""" 
create table if not exists organization.organisation_chanel_italie(
niveau_1 string,
niveau_2_division_consolidee string,
niveau_3_division_detaillee string,
niveau_4_direction string,
niveau_5_departement string,
cost_center_code string,
cost_center_name string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/business/organisation_chanel_italie";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.organisation_chanel_italie
if(spark.catalog.tableExists("organization.organisation_chanel_italie")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.organisation_chanel_italie")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.organisation_chanel_italie_rejected
spark.sql(""" drop table if exists organization.organisation_chanel_italie_rejected; """)
spark.sql(""" 
create table if not exists organization.organisation_chanel_italie_rejected(
niveau_1 string,
niveau_2_division_consolidee string,
niveau_3_division_detaillee string,
niveau_4_direction string,
niveau_5_departement string,
cost_center_code string,
cost_center_name string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/business/organisation_chanel_italie/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.organisation_chanel_italie_rejected
if(spark.catalog.tableExists("organization.organisation_chanel_italie_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.organisation_chanel_italie_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.hierarchy_pb
spark.sql(""" drop table if exists organization.hierarchy_pb; """)
spark.sql(""" 
create table if not exists organization.hierarchy_pb(
cost_center_code string,
cost_center_name string,
dird_direction_detail_code string,
dird_direction_detail_name string,
dirr_direction_code string,
dirr_direction_name string,
dirb_direction_psb_budget_code string,
dirb_direction_psb_budget_name string,
dirp_direction_presentation_code string,
dirp_direction_presentation_name string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/business/hierarchy_pb";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.hierarchy_pb
if(spark.catalog.tableExists("organization.hierarchy_pb")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.hierarchy_pb")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.hierarchy_pb_rejected
spark.sql(""" drop table if exists organization.hierarchy_pb_rejected; """)
spark.sql(""" 
create table if not exists organization.hierarchy_pb_rejected(
cost_center_code string,
cost_center_name string,
dird_direction_detail_code string,
dird_direction_detail_name string,
dirr_direction_code string,
dirr_direction_name string,
dirb_direction_psb_budget_code string,
dirb_direction_psb_budget_name string,
dirp_direction_presentation_code string,
dirp_direction_presentation_name string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/business/hierarchy_pb/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.hierarchy_pb_rejected
if(spark.catalog.tableExists("organization.hierarchy_pb_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.hierarchy_pb_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}