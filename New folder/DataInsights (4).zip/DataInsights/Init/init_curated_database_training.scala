// Databricks notebook source
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

// DBTITLE 1,Create database training
spark.sql(""" create database if not exists training; """)

// COMMAND ----------

// DBTITLE 1,Create parquet table training.formation
spark.sql(""" drop table if exists training.formation; """)
spark.sql(""" 
create table if not exists training.formation (

id_utilisateur string,
fournisseur_formation string  ,
perimetre_rh string  ,
titre_formation string,
organisme_formation string  ,
action_formation string  ,
formation_obligatoire string  ,
habilitation_certification_diplome string  ,
matiere_formation_parent string  ,
matiere_formation string  ,
axe string  ,
id_objet_formation string  ,
numero_repere_formation int  ,
type_stage string  ,
budget_developement_talents string  ,
interieur_parcours string  ,
reconversion string  ,
modalite string  ,
type_conges_formation string  ,
coaching string  ,
realisation string  ,
type_formation string  ,
statut_recapitulatif string  ,
nombre_stagiaire_previsionnel int  ,
budget_previsionnel double  ,
heures_formation double  ,
prix_formation double  ,
date_debut_formation timestamp  ,
date_fin_formation timestamp  ,
facture string  ,
feuille_emargement string  ,
montant_abondement_cpf_entreprise double  ,
montant_salarie_cpf_autre double  ,
frais_reprographie_materiel_pedagogique string  ,
duree_partie int  ,
duree_pause_partie int  ,
utilisateur_assiste_partie string  ,
frais_ingenierie double  ,
frais_deplacement_hebergement_repas_formateur double  ,
frais_deplacement_hebergement_repas_participant double  ,
montant_charge_opca double  ,
date_creation_formation timestamp  ,
date_derniere_modification timestamp  ,
date_debut_partie timestamp  ,
date_fin_partie timestamp  ,
date_achevement_recapitulatif timestamp  ,
date_inscription_recapitulatif timestamp  ,
date_dernier_changement_statut_recapitulatif timestamp  ,
supprime_recapitulatif string  ,
categorie_action string  ,
  filepath string not null,
  version int not null,
  date_raw_load_file date not null,
  filename string not null,
  curated_ingested_date timestamp not null,
  runid string not null,
  year_file int not null,
  month_file int not null,
  day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/training/cornerstone/cornerstone_formation/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table training.formation
if(spark.catalog.tableExists("training.formation")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE training.formation")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table training.formation_rejected
spark.sql(""" drop table if exists training.formation_rejected; """)
spark.sql(""" 
create table if not exists training.formation_rejected (

id_utilisateur string,
fournisseur_formation string  ,
perimetre_rh string  ,
titre_formation string,
organisme_formation string  ,
action_formation string  ,
formation_obligatoire string  ,
habilitation_certification_diplome string  ,
matiere_formation_parent string  ,
matiere_formation string  ,
axe string  ,
id_objet_formation string  ,
numero_repere_formation string  ,
type_stage string  ,
budget_developement_talents string  ,
interieur_parcours string  ,
reconversion string  ,
modalite string  ,
type_conges_formation string  ,
coaching string  ,
realisation string  ,
type_formation string  ,
statut_recapitulatif string  ,
nombre_stagiaire_previsionnel string  ,
budget_previsionnel string  ,
heures_formation string  ,
prix_formation string  ,
date_debut_formation string  ,
date_fin_formation string  ,
facture string  ,
feuille_emargement string  ,
montant_abondement_cpf_entreprise string  ,
montant_salarie_cpf_autre string  ,
frais_reprographie_materiel_pedagogique string  ,
duree_partie string  ,
duree_pause_partie string  ,
utilisateur_assiste_partie string  ,
frais_ingenierie string  ,
frais_deplacement_hebergement_repas_formateur string  ,
frais_deplacement_hebergement_repas_participant string  ,
montant_charge_opca string  ,
date_creation_formation string  ,
date_derniere_modification string  ,
date_debut_partie string  ,
date_fin_partie string  ,
date_achevement_recapitulatif string  ,
date_inscription_recapitulatif string  ,
date_dernier_changement_statut_recapitulatif string  ,
supprime_recapitulatif string  ,
categorie_action string  ,

error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/training/cornerstone/cornerstone_formation/rejected/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table training.formation_rejected
if(spark.catalog.tableExists("training.formation_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE training.formation_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table training.evaluation
spark.sql(""" drop table if exists training.evaluation; """)
spark.sql(""" 
create table if not exists training.evaluation (
id_utilisateur string not null,
type_formation string not null,
id_objet_formation string not null,
titre_formation string not null,
question string not null,
reponse string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/training/cornerstone/cornerstone_evaluation_formation/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table training.evaluation
if(spark.catalog.tableExists("training.evaluation")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE training.evaluation")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table training.evaluation_rejected
spark.sql(""" drop table if exists training.evaluation_rejected; """)
spark.sql(""" 
create table if not exists training.evaluation_rejected (
id_utilisateur string not null,
type_formation string not null,
id_objet_formation string not null,
titre_formation string not null,
question string not null,
reponse string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/training/cornerstone/cornerstone_evaluation_formation/rejected/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table training.evaluation_rejected
if(spark.catalog.tableExists("training.evaluation_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE training.evaluation_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}