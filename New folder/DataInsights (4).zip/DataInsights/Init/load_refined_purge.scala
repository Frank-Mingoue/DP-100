// Databricks notebook source
// DBTITLE 1,Include notebook containing functions to connect to adls container, get database url and properties
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

// DBTITLE 1,Delete employee delta files
dbutils.fs.rm("/mnt/refined_container/hr/employee",true)

// COMMAND ----------

// DBTITLE 1,Delete contract delta files
dbutils.fs.rm("/mnt/refined_container/hr/contract",true)

// COMMAND ----------

// DBTITLE 1,Delete job delta files
dbutils.fs.rm("/mnt/refined_container/common/job",true)

// COMMAND ----------

// DBTITLE 1,Delete location delta files
dbutils.fs.rm("/mnt/refined_container/common/location",true)

// COMMAND ----------

// DBTITLE 1,Delete Organization
dbutils.fs.rm("/mnt/refined_container/common/organization",true)

// COMMAND ----------

// DBTITLE 1,Delete Payroll
dbutils.fs.rm("/mnt/refined_container/hr/payroll",true)

// COMMAND ----------

// DBTITLE 1,Delete absenteism
dbutils.fs.rm("/mnt/refined_container/hr/absenteism",true)


// COMMAND ----------

// DBTITLE 1,Delete Pay
dbutils.fs.rm("/mnt/refined_container/hr/pay",true)


// COMMAND ----------

// DBTITLE 1,Delete absenteism consolidated
dbutils.fs.rm("/mnt/refined_container/hr/absenteism_consolidated",true)


// COMMAND ----------

dbutils.fs.rm("/mnt/refined_container/hr/job_application",true)


// COMMAND ----------

dbutils.fs.rm("/mnt/refined_container/hr/job_requisition",true)

// COMMAND ----------

dbutils.fs.rm("/mnt/refined_container/hr/degree",true)

// COMMAND ----------

dbutils.fs.rm("/mnt/refined_container/hr/training",true)

// COMMAND ----------

dbutils.fs.rm("/mnt/refined_container/hr/training_evaluation",true)

// COMMAND ----------

// DBTITLE 1,Init Database Common
// MAGIC %run /DataInsights/Init/init_refined_database_common

// COMMAND ----------

// DBTITLE 1,Init Database HR
// MAGIC %run /DataInsights/Init/init_refined_database_hr