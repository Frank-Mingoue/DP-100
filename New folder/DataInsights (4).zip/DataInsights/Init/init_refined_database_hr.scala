// Databricks notebook source
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true") 

// COMMAND ----------

// DBTITLE 1,Create database hr
spark.sql(""" create database if not exists hr; """)

// COMMAND ----------

// DBTITLE 1,Add news columns to existing table hr.contract
if(spark.catalog.tableExists("hr.contract") && pathexists("/mnt/refined_container/hr/contract")) // test if path exists
{
  try {


val df_contract_schema = spark.sql("describe table hr.contract")

//Add column probation_start_date on hr.contract
if(!df_contract_schema.isEmpty && df_contract_schema.filter("col_name = 'probation_start_date'").count == 0)
{
  spark.sql("alter table hr.contract add columns (probation_start_date date after special_population)")
}

//Add column probation_end_date on hr.contract
if(!df_contract_schema.isEmpty && df_contract_schema.filter("col_name = 'probation_end_date'").count == 0)
{
  spark.sql("alter table hr.contract add columns (probation_end_date date after probation_start_date)")
}
    
//Add column contract_reason on hr.contract
if(!df_contract_schema.isEmpty && df_contract_schema.filter("col_name = 'contract_reason'").count == 0)
{
  spark.sql("alter table hr.contract add columns (contract_reason string after probation_end_date)")
}
    
//Add column employee_visibility_date on hr.contract
if(!df_contract_schema.isEmpty && df_contract_schema.filter("col_name = 'employee_visibility_date'").count == 0)
{
  spark.sql("alter table hr.contract add columns (employee_visibility_date date after contract_reason)")
}

//Add column prime_co_percent on hr.contract
if(!df_contract_schema.isEmpty && df_contract_schema.filter("col_name = 'prime_co_percent'").count == 0)
{
  spark.sql("alter table hr.contract add columns (prime_co_percent double after employee_visibility_date)")
}

//Add column prime_exp_percent on hr.contract
if(!df_contract_schema.isEmpty && df_contract_schema.filter("col_name = 'prime_exp_percent'").count == 0)
{
  spark.sql("alter table hr.contract add columns (prime_exp_percent double after prime_co_percent)")
}

//Add column probabation_dates_code on hr.contract
if(!df_contract_schema.isEmpty && df_contract_schema.filter("col_name = 'probation_dates_code'").count == 0)
{
  spark.sql("alter table hr.contract add columns (probation_dates_code string after prime_exp_percent)")
}

//Add column contract_reason_code on hr.contract
if(!df_contract_schema.isEmpty && df_contract_schema.filter("col_name = 'contract_reason_code'").count == 0)
{
  spark.sql("alter table hr.contract add columns (contract_reason_code string after probation_dates_code)")
}

//Add column system_source on hr.contract
if(!df_contract_schema.isEmpty && df_contract_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.contract add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.contract
spark.sql(""" drop table if exists hr.contract; """)
spark.sql(""" 
create table if not exists hr.contract ( 
contract_key string
,employee_id string
,france_payroll_id string
,employee_code string
,worker_type string
,position_start_date date
,hire_date date
,continous_service_date date
,original_hire_date date
,effective_hire_date date
,effective_job_change_date date
,first_contract_type string
,first_contract_type_label string
,collective_agreement_reference string
,collective_agreement_reference_label string
,collective_agreement_group string
,collective_agreement_level string
,contract_start_date date
,contract_end_date date
,contract_type string
,contract_type_label string
,coefficient string
,coefficient_label string
,event_classification_subcategory string
,event_classification_subcategory_label string
,local_termination_reason string
,fte double
,time_type string
,time_type_label string
,paidfte double
,total_base_pay double
,primary_comp_basis_amount double
,period_salary string
,period_salary_label string
,period_salary_amount double
,compensation_merit_plan string
,compensation_merit_plan_label string
,compensation_change_reason string
,compensation_change_subreason string
,compensation_bonus_plan string
,bonus_target double
,bonus_plan_name string
,additional_job_classifications string
,additional_job_classifications_label string
,compensation_currency string
,default_weekly_hours string
,scheduled_weekly_hours string
,effective_compensation_change_date date
,foreign_travel_indemnity_percent double
,foreign_travel_indemnity_amount double
,effective_suporg_change_date date   
,csp string
,job_title string
,grade string
,management_level string
,job_profile_reference string
,job_code string
,csp_code string
,contract_code string
,worker_rate_code string
,mobility_in_code string
,mobility_out_code string
,compensation_change_code string
,compensation_merit_plan_code string
,compensation_bonus_plan_code string
,info_dates_code string
,in_out_dates_code string
,contract_dates_code string
,company_dates_code string
,contract_type_code string
,collective_agreement_code string
,grade_code string
,job_title_code string
,special_population string
,probation_start_date date
,probation_end_date date
,contract_reason string
,employee_visibility_date date
,prime_co_percent double
,prime_exp_percent double
,probation_dates_code string
,contract_reason_code string
,version int
,date_raw_load_file date
,filepath string
,filename string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string) 
USING DELTA
PARTITIONED BY (contract_type)
LOCATION "/mnt/refined_container/hr/contract";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.contract
if(spark.catalog.tableExists("hr.contract")) // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Column is_payroll_di
if(spark.catalog.tableExists("hr.payroll") && pathexists("/mnt/refined_container/hr/payroll")) // test if path exists
{
  try {

val df_payroll_schema = spark.sql("describe table hr.payroll")

//Add column is_code_rubr_di on pay.payroll
if(!df_payroll_schema.isEmpty && df_payroll_schema.filter("col_name = 'is_payroll_di'").count == 0)
{
  spark.sql("alter table hr.payroll add columns (is_payroll_di boolean after flag_amount_rem_real)")
}

//Add column system_source on pay.payroll
if(!df_payroll_schema.isEmpty && df_payroll_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.payroll add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.payroll
spark.sql(""" drop table if exists hr.payroll; """)
spark.sql(""" 
create table if not exists hr.payroll (
payroll_key string
,payroll_code string
,code_rubr string
,label_rubr string
,flag_salary string
,flag_debit string
,accounting_account string
,code_payroll_level_4 string
,label_payroll_level_4 string
,code_payroll_level_3 string
,label_payroll_level_3 string
,code_payroll_level_2 string
,label_payroll_level_2 string
,code_payroll_level_1 string
,label_payroll_level_1 string
,flag_amount_wage_gross string
,flag_amount_aw4 string
,flag_amount_aw6 string
,flag_amount_rem_nao string
,flag_amount_rem_bs string
,flag_amount_rem_benchmark string
,flag_amount_rem_target string
,flag_amount_rem_real string
,is_payroll_di boolean
,version int
,date_raw_load_file date
,filepath string
,filename string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string) 
USING DELTA
LOCATION "/mnt/refined_container/hr/payroll";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.payroll
if(spark.catalog.tableExists("hr.payroll")) // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.payroll")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.pay
if(spark.catalog.tableExists("hr.pay") && pathexists("/mnt/refined_container/hr/pay")) // test if path exists
{
  try {

val df_pay_schema = spark.sql("describe table hr.pay")

//Add column payzad on hr.pay
if(!df_pay_schema.isEmpty && df_pay_schema.filter("col_name = 'payzad'").count == 0)
{
  spark.sql("alter table hr.pay add columns (payzad string after company_amount)")
}

    //Add column num_pac on hr.pay
if(!df_pay_schema.isEmpty && df_pay_schema.filter("col_name = 'num_pac'").count == 0)
{
  spark.sql("alter table hr.pay add columns (num_pac string after payzad)")
}
    
    //Add column system_source on hr.pay
if(!df_pay_schema.isEmpty && df_pay_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.pay add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.pay
spark.sql(""" drop table if exists hr.pay; """)
spark.sql(""" 
create table if not exists hr.pay (
pay_key string
,employee_code string
,employee_id string
,france_payroll_id string
,period_pay string
,period_valorisation string
,period_pay_month string
,code_rubr string
,accounting_account string
,base double
,salary_amount double
,company_amount double
,payzad string
,num_pac string
,payroll_code string
,version int
,date_raw_load_file date
,filepath string
,filename string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string) 
USING DELTA
PARTITIONED BY (period_pay_month)
LOCATION "/mnt/refined_container/hr/pay";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.pay
if(spark.catalog.tableExists("hr.pay")) // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.pay")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.absenteism
if(spark.catalog.tableExists("hr.absenteism") && pathexists("/mnt/refined_container/hr/absenteism")) // test if path exists
{
  try {

val df_absenteism_schema = spark.sql("describe table hr.absenteism")
    
    //Add column system_source on hr.absenteism
if(!df_absenteism_schema.isEmpty && df_absenteism_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.absenteism add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.absenteism
spark.sql(""" drop table if exists hr.absenteism; """)
spark.sql(""" 
create table if not exists hr.absenteism (
abs_key string
,emp_num string
,dateval date
,h_start double
,h_end double
,duration_hours double
,duration_days double
,code string
,label string
,label_type_code string
,famregroup_label string
,type int
,signature int
,employee_hra string
,label_type string
,type_absence string
,is_added_day int
,period_abs_month string
,version int
,date_raw_load_file date
,filepath string
,filename string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string) 
USING DELTA
PARTITIONED BY (period_abs_month)
LOCATION "/mnt/refined_container/hr/absenteism";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.absenteism
if(spark.catalog.tableExists("hr.absenteism"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.contract_suspension
if(spark.catalog.tableExists("hr.contract_suspension") && pathexists("/mnt/refined_container/hr/contract_suspension")) // test if path exists
{
  try {

val df_contract_suspension_schema = spark.sql("describe table hr.contract_suspension")
    
    //Add column system_source on hr.contract_suspension
if(!df_contract_suspension_schema.isEmpty && df_contract_suspension_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.contract_suspension add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.contract_suspension
spark.sql(""" drop table if exists hr.contract_suspension; """)
spark.sql(""" 
create table if not exists hr.contract_suspension(
contract_suspension_key string not null,
employee_id string not null,
france_payroll_id string,
employee_code string not null,
contract_suspension_key_sha string not null,
contract_suspension_start_date date,
contract_suspension_end_date date,
contract_suspension_dates_code string not null,
category string,
label_category string,
reason string,
label_reason string,
suspension_contrat_code string not null,
flag_conges string,
version int not null,
date_raw_load_file date not null,
filepath string not null,
filename string not null,
curated_ingested_date timestamp not null,
record_creation_date timestamp,
record_modification_date timestamp,
hashkey string,
runid string not null,
system_source string)
USING DELTA
LOCATION "/mnt/refined_container/hr/contract_suspension";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.contract_suspension
if(spark.catalog.tableExists("hr.contract_suspension"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract_suspension")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.employee
if(spark.catalog.tableExists("hr.employee") && pathexists("/mnt/refined_container/hr/employee")) // test if path exists
{
  try {

val df_employee_schema = spark.sql("describe table hr.employee")
    
    //Add column system_source on hr.employee
if(!df_employee_schema.isEmpty && df_employee_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.employee add columns (system_source string after runid)")
}
    //Add column effective_organization_change_date on hr.employee
if(!df_employee_schema.isEmpty && df_employee_schema.filter("col_name = 'effective_organization_hierarchy_change_date'").count == 0)
{
  spark.sql("alter table hr.employee add columns (effective_organization_hierarchy_change_date date after effective_organization_change_date)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.employee
spark.sql(""" drop table if exists hr.employee; """)
spark.sql(""" create table if not exists hr.employee ( 
employee_key string
,employee_code string
,employee_id string
,france_payroll_id string
,last_name string
,first_name string
,birth_name string
,prefix string
,gender string
,birth_date date
,city_of_birth string
,department_of_birth string
,country_of_birth string
,primary_nationality string
,additional_nationalities string
,primary_work_email string
,primary_home_email string
,street_number string
,street_number_extension string
,street_name string
,additional_address string
,postal_code string
,city string
,marital_status string
,marital_status_label string
,national_identifier string
,user_name string
,igi_identification string
,spouse_first_name string
,spouse_last_name string
,manager_reference string
,manager_last_name string
,manager_first_name string
,cost_center_code string
,company_id string
,code_establishment string
,code_direction string
,code_department string
,cost_center_start_date date
,cost_center_end_date date
,establishment_start_date date
,establishment_end_date date
,company_start_date date
,company_end_date date
,organization_start_date date
,organization_end_date date
,lt_leader_last_name_n_1 string
,lt_leader_first_name_n_1  string
,lt_leader_reference_n_1  string
,lt_leader_last_name string
,lt_leader_first_name string
,lt_leader_reference string
,supervisory_organization_name string
,supervisory_organization_reference string
,effective_organization_change_date date
,effective_organization_hierarchy_change_date date
,effective_suporg_change_date date    
,location_code string
,nationality_code string
,manager_code string
,supervisory_organization_code string
,business_line_code string
,legal_organization_code string
,operational_organization_code string
,org_in_out_dates_code string
,local_pb_hierarchy_code string
,local_pb_hierarchy_name string
,special_population string
,version int
,date_raw_load_file date
,filepath string
,filename string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string)
USING DELTA
LOCATION "/mnt/refined_container/hr/employee";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.employee
if(spark.catalog.tableExists("hr.employee"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.absenteism
if(spark.catalog.tableExists("hr.employee_children") && pathexists("/mnt/refined_container/hr/employee_children")) // test if path exists
{
  try {

val df_employee_children_schema = spark.sql("describe table hr.employee_children")
    
    //Add column system_source on hr.employee_children
if(!df_employee_children_schema.isEmpty && df_employee_children_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.employee_children add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.employee_children
spark.sql(""" drop table if exists hr.employee_children; """)
spark.sql(""" 
create table if not exists hr.employee_children ( 
employee_key string
,employee_key_wd string
,employee_key_hra string
,employee_code string
,employee_id string
,france_payroll_id string
,children_order_number string
,children_gender string
,children_date_of_birth date
,children_first_name string
,children_last_name string
,children_dependent string
,children_date_of_death date
,version int
,date_raw_load_file date
,filepath string
,filename string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string)
USING DELTA
LOCATION "/mnt/refined_container/hr/employee_children";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.employee_children
if(spark.catalog.tableExists("hr.employee_children"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee_children")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.absenteism
if(spark.catalog.tableExists("hr.ag_establishment") && pathexists("/mnt/refined_container/hr/ag_establishment")) // test if path exists
{
  try {

val df_ag_establishment_schema = spark.sql("describe table hr.ag_establishment")
    
    //Add column system_source on hr.absenteism
if(!df_ag_establishment_schema.isEmpty && df_ag_establishment_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.ag_establishment add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.ag_establishment
spark.sql(""" drop table if exists hr.ag_establishment; """)
spark.sql(""" 
create table if not exists hr.ag_establishment(
ag_establishment_key string
,label_establishment string
,code_establishment string
,period date
,period_month string
,year string
,percent_ag double
,filepath string
,version int
,date_raw_load_file date
,filename string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string)
USING DELTA
PARTITIONED BY (year)
LOCATION "/mnt/refined_container/hr/ag_establishment";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.ag_establishment
if(spark.catalog.tableExists("hr.ag_establishment"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.ag_establishment")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.absenteism
if(spark.catalog.tableExists("hr.eligibility_psb") && pathexists("/mnt/refined_container/hr/eligibility_psb")) // test if path exists
{
  try {

val df_eligibility_psb_schema = spark.sql("describe table hr.eligibility_psb")
    
    //Add column system_source on hr.eligibility_psb
if(!df_eligibility_psb_schema.isEmpty && df_eligibility_psb_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.eligibility_psb add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.eligibility_psb
spark.sql(""" drop table if exists hr.eligibility_psb; """)
spark.sql(""" 
create table if not exists hr.eligibility_psb(
eligibility_psb_key string
,employee_id string
,france_payroll_id string
,employee_code string
,last_name string
,first_name string
,period date
,year string
,is_eligible string
,filename string
,date_raw_load_file date
,version int
,filepath string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string)
USING DELTA
PARTITIONED BY (year)
LOCATION "/mnt/refined_container/hr/eligibility_psb";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.eligibility_psb
if(spark.catalog.tableExists("hr.eligibility_psb"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.eligibility_psb")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.absenteism
if(spark.catalog.tableExists("hr.housing_action") && pathexists("/mnt/refined_container/hr/housing_action")) // test if path exists
{
  try {

val df_housing_action_schema = spark.sql("describe table hr.housing_action")
    
    //Add column system_source on hr.absenteism
if(!df_housing_action_schema.isEmpty && df_housing_action_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.housing_action add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.housing action
spark.sql(""" drop table if exists hr.housing_action; """)
spark.sql(""" 
create table if not exists hr.housing_action(
 housing_action_key string
,employee_id string
,france_payroll_id string
,employee_code string
,last_name string
,first_name string
,period date
,year string
,thematic_action_housing string
,action_housing_code string
,filename string
,date_raw_load_file date
,version int
,filepath string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string)
USING DELTA
PARTITIONED BY (year)
LOCATION "/mnt/refined_container/hr/housing_action";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.housing_action
if(spark.catalog.tableExists("hr.housing_action"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.housing_action")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.absenteism
if(spark.catalog.tableExists("hr.percol_peb_ccb") && pathexists("/mnt/refined_container/hr/percol_peb_ccb")) // test if path exists
{
  try {

val df_percol_peb_ccb_schema = spark.sql("describe table hr.percol_peb_ccb")
    
    //Add column system_source on hr.percol_peb_ccb
if(!df_percol_peb_ccb_schema.isEmpty && df_percol_peb_ccb_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.percol_peb_ccb add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.percol_peb_ccb
spark.sql(""" drop table if exists hr.percol_peb_ccb; """)
spark.sql(""" 
create table if not exists hr.percol_peb_ccb(
percol_peb_ccb_key string
,employee_id string
,france_payroll_id string
,employee_code string
,last_name string
,first_name string
,flag_amundi_per_col int
,flag_amundi_peg int
,flag_amundi_ccb int
,period date
,year string
,filename string
,date_raw_load_file date
,version int
,filepath string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string)
USING DELTA
PARTITIONED BY (year)
LOCATION "/mnt/refined_container/hr/percol_peb_ccb";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.percol_peb_ccb
if(spark.catalog.tableExists("hr.percol_peb_ccb"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.percol_peb_ccb")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.theoric_target_bonus_amount
if(spark.catalog.tableExists("hr.theoric_target_bonus_amount") && pathexists("/mnt/refined_container/hr/theoric_target_bonus_amount")) // test if path exists
{
  try {

val df_theoric_target_bonus_amount_schema = spark.sql("describe table hr.theoric_target_bonus_amount")
    
    //Add column system_source on hr.theoric_target_bonus_amount
if(!df_theoric_target_bonus_amount_schema.isEmpty && df_theoric_target_bonus_amount_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.theoric_target_bonus_amount add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.theoric_target_bonus_amount
spark.sql(""" drop table if exists hr.theoric_target_bonus_amount; """)
spark.sql(""" 
create table if not exists hr.theoric_target_bonus_amount(
theoric_target_bonus_amount_key string
,employee_id string
,france_payroll_id string
,employee_code string
,last_name string
,first_name string
,period date
,period_month string
,theoric_target_bonus_amount double
,filename string
,date_raw_load_file date
,version int
,filepath string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string)
USING DELTA
PARTITIONED BY (period_month)
LOCATION "/mnt/refined_container/hr/theoric_target_bonus_amount";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.theoretic_target_bonus_amount
if(spark.catalog.tableExists("hr.theoric_target_bonus_amount"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.theoric_target_bonus_amount")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.car_mobility_policy
if(spark.catalog.tableExists("hr.car_mobility_policy") && pathexists("/mnt/refined_container/hr/car_mobility_policy")) // test if path exists
{
  try {

val df_car_mobility_policy_schema = spark.sql("describe table hr.car_mobility_policy")
    
    //Add column system_source on hr.car_mobility_policy
if(!df_car_mobility_policy_schema.isEmpty && df_car_mobility_policy_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.car_mobility_policy add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.car_mobility_policy
spark.sql(""" drop table if exists hr.car_mobility_policy; """)
spark.sql(""" 
create table if not exists hr.car_mobility_policy(
car_mobility_policy_key string
,france_payroll_id string
,last_name string
,first_name string
,benefits_start_date date
,benefits_end_date date
,benefits_category string
,benefits_type string
,period date
,period_month string
,filename string
,date_raw_load_file date
,version int
,filepath string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string)
USING DELTA
PARTITIONED BY (period_month)
LOCATION "/mnt/refined_container/hr/car_mobility_policy";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.car_mobility_policy
if(spark.catalog.tableExists("hr.car_mobility_policy"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.car_mobility_policy")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.amount_lti
if(spark.catalog.tableExists("hr.amount_lti") && pathexists("/mnt/refined_container/hr/amount_lti")) // test if path exists
{
  try {

val df_amount_lti_schema = spark.sql("describe table hr.amount_lti")
    
    //Add column system_source on hr.amount_lti
if(!df_amount_lti_schema.isEmpty && df_amount_lti_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.amount_lti add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.montant_lti
spark.sql(""" drop table if exists hr.amount_lti; """)
spark.sql(""" 
create table if not exists hr.amount_lti(
amount_lti_key string
,employee_id string
,france_payroll_id string
,employee_code string
,first_name string
,last_name string
,amount_lti_annual double
,period date
,period_month string
,filename string
,date_raw_load_file date
,version int
,filepath string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string)
USING DELTA
PARTITIONED BY (period_month)
LOCATION "/mnt/refined_container/hr/amount_lti";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.montant_lti
if(spark.catalog.tableExists("hr.amount_lti"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.amount_lti")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.absenteism_consolidated
if(spark.catalog.tableExists("hr.absenteism_consolidated") && pathexists("/mnt/refined_container/hr/absenteism_consolidated")) // test if path exists
{
  try {

val df_absenteism_consolidated_schema = spark.sql("describe table hr.absenteism_consolidated")

        //Add column runid on hr.absenteism_consolidated
if(!df_absenteism_consolidated_schema.isEmpty && df_absenteism_consolidated_schema.filter("col_name = 'runid'").count == 0)
{
  spark.sql("alter table hr.absenteism_consolidated add columns (runid string after curated_ingested_date)")
}
    //Add column system_source on hr.absenteism_consolidated
if(!df_absenteism_consolidated_schema.isEmpty && df_absenteism_consolidated_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.absenteism_consolidated add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.absenteism_consolidated
spark.sql(""" drop table if exists hr.absenteism_consolidated; """)
spark.sql(""" 
create table if not exists hr.absenteism_consolidated(
old_employee_hra string not null,
employee_hra string not null,
dateval_start date,
dateval_end date,
dateval_start_prol date,
dateval_end_prol date,
dateval_start_prol_first date,
dateval_end_prol_last date,
h_start double,
h_end double,
code string not null ,
duration_days double not null,
duration_days_abs double not null,
duration_hours double not null,
id_absence string not null,
id_absence_2 string not null,
h_code string,
dates_code string,
version int not null,
date_raw_load_file date not null,
filepath string not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string,
system_source string)
USING DELTA
PARTITIONED BY (code)
LOCATION "/mnt/refined_container/hr/absenteism_consolidated";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.absenteism_consolidated
if(spark.catalog.tableExists("hr.absenteism_consolidated"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism_consolidated")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.absenteism_consolidated_extended
if(spark.catalog.tableExists("hr.absenteism_consolidated_extended") && pathexists("/mnt/refined_container/hr/absenteism_consolidated_extended")) // test if path exists
{
  try {

val df_absenteism_consolidated_extended_schema = spark.sql("describe table hr.absenteism_consolidated_extended")

    //Add column system_source on hr.absenteism
if(!df_absenteism_consolidated_extended_schema.isEmpty && df_absenteism_consolidated_extended_schema.filter("col_name = 'runid'").count == 0)
{
  spark.sql("alter table hr.absenteism_consolidated_extended add columns (runid string after curated_ingested_date)")
}
    
    //Add column system_source on hr.absenteism
if(!df_absenteism_consolidated_extended_schema.isEmpty && df_absenteism_consolidated_extended_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.absenteism_consolidated_extended add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.absenteism_consolidated_extended
spark.sql(""" drop table if exists hr.absenteism_consolidated_extended; """)
spark.sql(""" create table if not exists hr.absenteism_consolidated_extended(
employee_hra string not null,
dateval_start date,
dateval_end date,
h_start double,
h_end double,
h_code string,
code string not null ,
duration_days_abs int not null,
id_absence string not null,
id_absence_2 string not null,
version int not null,
date_raw_load_file date not null,
filepath string not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string,
system_source string)
USING DELTA
PARTITIONED BY (code)
LOCATION "/mnt/refined_container/hr/absenteism_consolidated_extended";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.absenteism_consolidated_extended
if(spark.catalog.tableExists("hr.absenteism_consolidated_extended"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism_consolidated_extended")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.referential_absences
if(spark.catalog.tableExists("hr.referential_absences") && pathexists("/mnt/refined_container/hr/referential_absences")) // test if path exists
{
  try {

val df_referential_absences_schema = spark.sql("describe table hr.referential_absences")
    
    //Add column system_source on hr.referential_absences
if(!df_referential_absences_schema.isEmpty && df_referential_absences_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.referential_absences add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.referential_absences
spark.sql(""" drop table if exists hr.referential_absences; """)
spark.sql(""" create table if not exists hr.referential_absences(
 ref_absences_key string
,period date
,absence_code string
,absence_label_code string
,absence_reason string
,absence_family string
,absence_rate string 
,absence_predictable_unpredictable string
,flag_productive_etp string
,flag_absence_rate string
,flag_prolongation string
,absence_type string
,filepath string
,version int
,date_raw_load_file date
,filename string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string)
USING DELTA
LOCATION "/mnt/refined_container/hr/referential_absences";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.referential_absences
if(spark.catalog.tableExists("hr.referential_absences"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.referential_absences")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.absenteism
if(spark.catalog.tableExists("hr.cet") && pathexists("/mnt/refined_container/hr/cet")) // test if path exists
{
  try {

val df_cet_schema = spark.sql("describe table hr.cet")

    //Add column system_source on hr.cet
if(!df_cet_schema.isEmpty && df_cet_schema.filter("col_name = 'runid'").count == 0)
{
  spark.sql("alter table hr.cet add columns (runid string after hashkey)")
}
    //Add column system_source on hr.cet
if(!df_cet_schema.isEmpty && df_cet_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.cet add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.cet
spark.sql(""" drop table if exists hr.cet; """)
spark.sql(""" create table if not exists hr.cet(
employee_code string
,matricule_hr_access string
,matricule_wd string
,date_operation date
,date_operation_2 date
,date_operation_month string
,nb_cet_solded_days double
,nb_cet_taken_days double 
,nb_cet_consumed_days double
,nb_cet_beneficiary_days double
,percent_cet double
,filepath string
,version string
,date_raw_load_file date
,filename string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string
)
USING DELTA
LOCATION "/mnt/refined_container/hr/cet";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.cet
if(spark.catalog.tableExists("hr.cet"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.cet")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.job_application
if(spark.catalog.tableExists("hr.job_application") && pathexists("/mnt/refined_container/hr/job_application")) // test if path exists
{
  try {

val df_job_application_schema = spark.sql("describe table hr.job_application")
    
    //Add column system_source on hr.job_application
if(!df_job_application_schema.isEmpty && df_job_application_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.job_application add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.job_application
spark.sql(""" drop table if exists hr.job_application; """)
spark.sql(""" create table if not exists hr.job_application(
application_key string
,candidate_id string
,candidate_first_name string
,candidate_last_name string
,job_requisition_reference string
,job_application_date date
,job_application_month string
,first_degree_reference string 
,last_degree_reference string
,worker_reference string 
,source_reference string
,stage_reference string
,status_timestamp date
,disposition_reference string
,disposition_reference_id string
,candidate_response_date date
,duration_trial_period double
,validation_trial_period string
,source_reference_code string
,job_application_code string
,filename string
,date_raw_load_file date
,version int
,filepath string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string
)
USING DELTA
PARTITIONED BY (job_application_month)
LOCATION "/mnt/refined_container/hr/job_application";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.application
if(spark.catalog.tableExists("hr.job_application"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.job_application")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.job_requisition
if(spark.catalog.tableExists("hr.job_requisition") && pathexists("/mnt/refined_container/hr/job_requisition")) // test if path exists
{
  try {

val df_job_requisition_schema = spark.sql("describe table hr.job_requisition")

        //Add column job_requisition_code on hr.job_requisition
if(!df_job_requisition_schema.isEmpty && df_job_requisition_schema.filter("col_name = 'job_requisition_code'").count == 0)
{
  spark.sql("alter table hr.job_requisition add columns (job_requisition_code string after job_requisition_key)")
}
    //Add column system_source on hr.job_requisition
if(!df_job_requisition_schema.isEmpty && df_job_requisition_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.job_requisition add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.job_requisition
spark.sql(""" drop table if exists hr.job_requisition; """)
spark.sql(""" create table if not exists hr.job_requisition(
job_requisition_key string
,job_requisition_code string
,job_requisition_reference string
,job_requisition_status string
,job_posting_title string
,recruiting_instruction_data string
,recruiting_start_date date
,target_hire_date date 
,target_end_date date
,worker_type_reference string
,position_worker_type_reference string
,primary_location_reference string
,primary_location_label string
,primary_job_posting_location_reference string
,primary_job_posting_location_label string
,time_type_reference string
,position_reference string
,position_label string
,primary_recruiter string
,hiring_manager string
,effective_date date
,job_posting_start_date date
,job_posting_site_reference string
,job_contract_nature string
,earliest_hire_date date
,job_profile string
,job_category string
,job_family string
,cost_center_reference string
,cost_center string
,effective_date_posting date
,filename string
,date_raw_load_file date
,version int
,filepath string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string
)
USING DELTA
PARTITIONED BY (job_requisition_status)
LOCATION "/mnt/refined_container/hr/job_requisition";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.job_requisition
if(spark.catalog.tableExists("hr.job_requisition"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.job_requisition")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.degree
if(spark.catalog.tableExists("hr.degree") && pathexists("/mnt/refined_container/hr/degree")) // test if path exists
{
  try {

val df_degree_schema = spark.sql("describe table hr.degree")
    
    //Add column system_source on hr.degree
if(!df_degree_schema.isEmpty && df_degree_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.degree add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.degree
spark.sql(""" drop table if exists hr.degree; """)
spark.sql(""" create table if not exists hr.degree(
degree_key string
,candidate_id string
,first_name string
,last_name string
,degree_reference string
,school_name string
,first_year_attended string 
,last_year_attended string
,filename string
,date_raw_load_file date
,version int
,filepath string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string
)
USING DELTA
PARTITIONED BY (degree_reference)
LOCATION "/mnt/refined_container/hr/degree";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.degree
if(spark.catalog.tableExists("hr.degree"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.degree")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.accounting_nature
if(spark.catalog.tableExists("hr.accounting_nature") && pathexists("/mnt/refined_container/hr/accounting_nature")) // test if path exists
{
  try {

val df_accounting_nature_schema = spark.sql("describe table hr.accounting_nature")
    
    //Add column system_source on hr.accounting_nature
if(!df_accounting_nature_schema.isEmpty && df_accounting_nature_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.accounting_nature add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.accounting_nature
spark.sql(""" drop table if exists hr.accounting_nature; """)
spark.sql(""" create table if not exists hr.accounting_nature(
 accounting_nature_key string
,accounting_nature_code string
,wage_type_code string
,cost_center_code string
,country string
,currency string
,amount double
,month int
,year int
,year_month string
,filename string
,date_raw_load_file date
,version int
,filepath string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string
)
USING DELTA
PARTITIONED BY (year_month)
LOCATION "/mnt/refined_container/hr/accounting_nature";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.accounting_nature
if(spark.catalog.tableExists("hr.accounting_nature"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.accounting_nature")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

if(spark.catalog.tableExists("hr.career") && pathexists("/mnt/refined_container/hr/career")) // test if path exists
{
  try {


val df_career_schema = spark.sql("describe table hr.career")

//Add column review_status_code on hr.career
if(!df_career_schema.isEmpty && df_career_schema.filter("col_name = 'review_status_code'").count == 0)
{
  spark.sql("alter table hr.career add columns (review_status_code string after review_code)")
}

//Add column my_review_end_date on hr.career
if(!df_career_schema.isEmpty && df_career_schema.filter("col_name = 'my_review_end_date'").count == 0)
{
  spark.sql("alter table hr.career add columns (my_review_end_date date after relocation_short_term_willing)")
}
    
//Add column my_review_status on hr.career
if(!df_career_schema.isEmpty && df_career_schema.filter("col_name = 'my_review_status'").count == 0)
{
  spark.sql("alter table hr.career add columns (my_review_status string after my_review_end_date)")
}
    
//Add column my_review_status_code on hr.career
if(!df_career_schema.isEmpty && df_career_schema.filter("col_name = 'my_review_status_code'").count == 0)
{
  spark.sql("alter table hr.career add columns (my_review_status_code string after review_status_code)")
}    

 //Add column system_source on hr.career
if(!df_career_schema.isEmpty && df_career_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.career add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.career
spark.sql(""" drop table if exists hr.career; """)
spark.sql(""" create table if not exists hr.career(
 career_key string
,employee_id string
,france_payroll_id string   
,employee_code string                         
,review_type_reference string
,review_reference string
,review_initiated_date date
,review_end_date date
,review_period_start_date date
,review_period_end_date date
,review_status string
,goal_id string
,goal_due_date date
,goal_completion_date date
,relocation_long_term_area string
,relocation_long_term_willing string
,relocation_short_term_area string
,relocation_short_term_willing string
,my_review_end_date date
,my_review_status string
,review_code string
,review_status_code string
,my_review_status_code string
,career_goal_code string
,career_mobility_code string
,career_campaign_code string
,version string
,date_raw_load_file date
,filepath string
,filename string
,curated_ingested_date date
,current_record string
,record_start_date date
,record_end_date date
,record_creation_date date
,record_modification_date date
,hashkey string
,runid string
,system_source string
)
USING DELTA
PARTITIONED BY (review_type_reference)
LOCATION "/mnt/refined_container/hr/career";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.career
if(spark.catalog.tableExists("hr.career"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.career")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.training
if(spark.catalog.tableExists("hr.training") && pathexists("/mnt/refined_container/hr/training")) // test if path exists
{
  try {

val df_training_schema = spark.sql("describe table hr.training")
    
    //Add column system_source on hr.training
if(!df_training_schema.isEmpty && df_training_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.training add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.training
spark.sql(""" drop table if exists hr.training; """)
spark.sql(""" create table if not exists hr.training(
  training_key string,
  employee_id string,
  training_provider string,
  training_object_id string,
  training_landmark_number int,
  training_label string,
  training_organization string,
  training_mode string,
  authorization_certification_diploma string,
  training_action boolean,
  mandatory_training string,
  hr_scope string,
  training_subject string,
  parent_training_subject string,
  training_axis string,
  trainingship_type string,
  talent_development_budget boolean,
  inside_training_path boolean,
  reskilling boolean,
  coaching string,
  training_recap_working_hours string,
  training_hours double,
  training_session_duration int,
  training_session_break_duration int,
  training_estimated_participants int,
  training_estimated_budget double,
  invoice boolean,
  training_presence_sheet boolean,
  attended_to_training_session boolean,
  training_price double,
  CPF_company_funding_amount double,
  CPF_other_employee_amount double,
  training_materials_fees double,
  training_preparation_fees double,
  trainer_fees double,
  trainee_fees double,
  OPCA_amount double,
  training_creation_date timestamp,
  training_modification_date timestamp,
  training_start_date timestamp,
  training_end_date timestamp,
  training_session_start_date timestamp,
  training_session_end_date timestamp,
  recap_completion_date timestamp,
  recap_registration_date timestamp,
  last_recap_status_modification_date timestamp,
  removed_from_recap boolean,
  legal_category string,
  training_leave_type string,
  training_type string,
  training_recap_status string,
  training_type_code string,
  training_status_code string,
  training_code string,
  training_plan_date_id date,
  training_plan_year_id int

  ,version int
  ,date_raw_load_file date
  ,filepath string
  ,filename string
  ,curated_ingested_date date
  ,current_record boolean
  ,record_start_date date
  ,record_end_date date
  ,record_creation_date timestamp
  ,record_modification_date timestamp
  ,hashkey string
  ,runid string
  ,system_source string
)
USING DELTA
PARTITIONED BY (training_plan_year_id)
LOCATION "/mnt/refined_container/hr/training";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.training
if(spark.catalog.tableExists("hr.training"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.training")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns to hr.training_evaluation
if(spark.catalog.tableExists("hr.training_evaluation") && pathexists("/mnt/refined_container/hr/training_evaluation")) // test if path exists
{
  try {

val df_training_evaluation_schema = spark.sql("describe table hr.training_evaluation")
    
    //Add column system_source on hr.training_evaluation
if(!df_training_evaluation_schema.isEmpty && df_training_evaluation_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table hr.training_evaluation add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table hr.training_evaluation
spark.sql(""" drop table if exists hr.training_evaluation; """)
spark.sql(""" create table if not exists hr.training_evaluation(
  training_evaluation_key string,
  employee_id string,
  training_type string,
  training_object_id string,
  training_label string,
  evaluation_question string,
  evaluation_response string

    ,version int
  ,date_raw_load_file date
  ,filepath string
  ,filename string
  ,curated_ingested_date date
  ,current_record boolean
  ,record_start_date date
  ,record_end_date date
  ,record_creation_date timestamp
  ,record_modification_date timestamp
  ,hashkey string
  ,runid string
  ,system_source string
)
USING DELTA
PARTITIONED BY (training_object_id)
LOCATION "/mnt/refined_container/hr/training_evaluation";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table hr.training_evaluation
if(spark.catalog.tableExists("hr.training_evaluation"))  // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.training_evaluation")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}