// Databricks notebook source
// MAGIC %run /DataInsights/Include/import_library

// COMMAND ----------

spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true") 

// COMMAND ----------

// DBTITLE 1,Delete Refined Table Employee
dbutils.fs.rm("/mnt/refined_container/hr/employee",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Table Employee Children
dbutils.fs.rm("/mnt/refined_container/hr/employee_children",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Table Contract
dbutils.fs.rm("/mnt/refined_container/hr/contract",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Table Contract Suspension
dbutils.fs.rm("/mnt/refined_container/hr/contract_suspension",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Table Pay
dbutils.fs.rm("/mnt/refined_container/hr/pay",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Table Payroll
dbutils.fs.rm("/mnt/refined_container/hr/payroll",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Table AG Etablissement
dbutils.fs.rm("/mnt/refined_container/hr/ag_establishment",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined cet
dbutils.fs.rm("/mnt/refined_container/hr/cet",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Table Job
dbutils.fs.rm("/mnt/refined_container/common/job",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Table Location
dbutils.fs.rm("/mnt/refined_container/common/location",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Table Organization
dbutils.fs.rm("/mnt/refined_container/common/organization",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Table Ref_Organization
dbutils.fs.rm("/mnt/refined_container/common/ref_organization",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Table Absenteism
dbutils.fs.rm("/mnt/refined_container/hr/absenteism",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Abstenteism_consolidated
dbutils.fs.rm("/mnt/refined_container/hr/absenteism_consolidated",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Abstenteism_consolidated_extended
dbutils.fs.rm("/mnt/refined_container/hr/absenteism_consolidated_extended",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined referential_absences
dbutils.fs.rm("/mnt/refined_container/hr/referential_absences",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined application
dbutils.fs.rm("/mnt/refined_container/hr/job_application",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined Job Requisiton
dbutils.fs.rm("/mnt/refined_container/hr/job_requisition",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined degree
dbutils.fs.rm("/mnt/refined_container/hr/degree",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined eligibility_psb
dbutils.fs.rm("/mnt/refined_container/hr/eligibility_psb",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined housing_action
dbutils.fs.rm("/mnt/refined_container/hr/housing_action",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined percol_peb_ccb
dbutils.fs.rm("/mnt/refined_container/hr/percol_peb_ccb",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined theoretical_target_bonus_amount
dbutils.fs.rm("/mnt/refined_container/hr/theoretical_target_bonus_amount",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined car_mobility_policy
dbutils.fs.rm("/mnt/refined_container/hr/car_mobility_policy",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined amount_lti
dbutils.fs.rm("/mnt/refined_container/hr/amount_lti",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined source_recruitment
dbutils.fs.rm("/mnt/refined_container/hr/source_recruitment",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined absence_counters
dbutils.fs.rm("/mnt/refined_container/hr/absence_counters",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined natures_comptables
dbutils.fs.rm("/mnt/refined_container/hr/natures_comptables",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined career
dbutils.fs.rm("/mnt/refined_container/hr/career",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined training
dbutils.fs.rm("/mnt/refined_container/hr/training",true)

// COMMAND ----------

// DBTITLE 1,Delete Refined training
dbutils.fs.rm("/mnt/refined_container/hr/training_evaluation",true)