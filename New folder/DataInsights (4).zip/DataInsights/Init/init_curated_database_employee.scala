// Databricks notebook source
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

// DBTITLE 1,Create database employee
spark.sql(""" create database if not exists employee; """)

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.get_workers
spark.sql(""" drop table if exists employee.get_workers; """)
spark.sql(""" 
create table if not exists employee.get_workers (
last_name string,
first_name string,
birth_name string,
prefix string,
gender string,
birth_date date,
city_of_birth string,
department_of_birth string,
country_of_birth string,
primary_nationality string,
additional_nationalities string,
primary_work_email string,
primary_home_email string,
street_number string,
street_number_extension string,
street_name string,
additional_address string,
postal_code string,
city string,
marital_status string,
marital_status_label string,
national_identifier string,
employee_id string not null,
france_payroll_id string not null,
user_name string,
igi_identification string,
spouse_first_name string,
spouse_last_name string,
children_order_number string,
children_gender string,
children_date_of_birth date,
children_first_name string,
children_last_name string,
children_dependent string,
manager_reference string,
manager_last_name string,
manager_first_name string,
position_start_date date,
hire_date date,
job_title string,
business_line_reference string,
business_line_name string,
worker_type string,
grade string,
grade_label string,
coefficient string,
coefficient_label string,
management_level string,
management_level_label string,
location string,
location_country string,
location_type string,
cost_center_code string,
cost_center_name string,
company_id string,
company string,
first_contract_type string,
first_contract_type_label string,
continous_service_date date,
collective_agreement_reference string,
collective_agreement_reference_label string,
collective_agreement_group string,
collective_agreement_level string,
lt_leader_last_name_n_1 string,
lt_leader_first_name_n_1 string,
lt_leader_reference_n_1 string,
lt_leader_last_name string,
lt_leader_first_name string,
lt_leader_reference string,
supervisory_organization_name string,
supervisory_organization_reference string,
original_hire_date date,
contract_start_date date,
contract_end_date date,
contract_type string,
contract_type_label string,
event_classification_subcategory string,
event_classification_subcategory_label string,
local_termination_reason string,
job_profile_name string,
job_profile_reference string,
job_profile_reference_label string,
job_category string,
job_family string,
job_family_group string,
fte double,
time_type string,
time_type_label string,
professional_category_reference string,
professional_category_name string,
paidfte double,
total_base_pay double,
primary_comp_basis_amount double,
period_salary string,
period_salary_label string,
period_salary_amount double,
compensation_merit_plan string,
compensation_merit_plan_label string,
compensation_change_reason string,
compensation_change_subreason string,
compensation_bonus_plan string,
bonus_target double,
bonus_plan_name string,
additional_job_classifications string,
additional_job_classifications_label string,
compensation_currency string,
default_weekly_hours double,
scheduled_weekly_hours double,
effective_hire_date date,
effective_job_change_date date,
effective_organization_change_date date,
effective_compensation_change_date date,
effective_suporg_change_date date,
foreign_travel_indemnity_percent double,
foreign_travel_indemnity_amount double,
children_date_of_death date,
local_pb_hierarchy_code string,
local_pb_hierarchy_name string,
bonus_target_default double,
review_type_reference string,
review_reference string,
review_initiated_date date,
review_end_date date,
review_period_start_date date,
review_period_end_date date,
review_status string,
goal_id string,
goal_due_date date,
goal_completion_date date,
relocation_long_term_area string,
relocation_long_term_willing string,
relocation_short_term_area string,
relocation_short_term_willing string,
location_code string,
probation_start_date date,
probation_end_date date,
contract_reason string,
my_review_end_date date,
my_review_status string,
employee_visibility_date date,
prime_co_percent double,
prime_exp_percent double,

filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/workday/get_workers/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.get_workers
if(spark.catalog.tableExists("employee.get_workers")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.get_workers")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
    
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.get_workers_rejected
spark.sql(""" drop table if exists employee.get_workers_rejected; """)
spark.sql(""" create table if not exists employee.get_workers_rejected (
last_name string,
first_name string,
birth_name string,
prefix string,
gender string,
birth_date string,
city_of_birth string,
department_of_birth string,
country_of_birth string,
primary_nationality string,
additional_nationalities string,
primary_work_email string,
primary_home_email string,
street_number string,
street_number_extension string,
street_name string,
additional_address string,
postal_code string,
city string,
marital_status string,
marital_status_label string,
national_identifier string,
employee_id string,
france_payroll_id string,
user_name string,
igi_identification string,
spouse_first_name string,
spouse_last_name string,
children_order_number string,
children_gender string,
children_date_of_birth string,
children_first_name string,
children_last_name string,
children_dependent string,
manager_reference string,
manager_last_name string,
manager_first_name string,
position_start_date string,
hire_date string,
job_title string,
business_line_reference string,
business_line_name string,
worker_type string,
grade string,
grade_label string,
coefficient string,
coefficient_label string,
management_level string,
management_level_label string,
location string,
location_country string,
location_type string,
cost_center_code string,
cost_center_name string,
company_id string,
company string,
first_contract_type string,
first_contract_type_label string,
continous_service_date string,
collective_agreement_reference string,
collective_agreement_reference_label string,
collective_agreement_group string,
collective_agreement_level string,
lt_leader_last_name_n_1 string,
lt_leader_first_name_n_1 string,
lt_leader_reference_n_1 string,
lt_leader_last_name string,
lt_leader_first_name string,
lt_leader_reference string,
supervisory_organization_name string,
supervisory_organization_reference string,
original_hire_date string,
contract_start_date string,
contract_end_date string,
contract_type string,
contract_type_label string,
event_classification_subcategory string,
event_classification_subcategory_label string,
local_termination_reason string,
job_profile_name string,
job_profile_reference string,
job_profile_reference_label string,
job_category string,
job_family string,
job_family_group string,
fte string,
time_type string,
time_type_label string,
professional_category_reference string,
professional_category_name string,
paidfte string,
total_base_pay string,
primary_comp_basis_amount string,
period_salary string,
period_salary_label string,
period_salary_amount string,
compensation_merit_plan string,
compensation_merit_plan_label string,
compensation_change_reason string,
compensation_change_subreason string,
compensation_bonus_plan string,
bonus_target string,
bonus_plan_name string,
additional_job_classifications string,
additional_job_classifications_label string,
compensation_currency string,
default_weekly_hours string,
scheduled_weekly_hours string,
effective_hire_date string,
effective_job_change_date string,
effective_organization_change_date string,
effective_compensation_change_date string,
effective_suporg_change_date string,
children_date_of_death string,
local_pb_hierarchy_code string,
local_pb_hierarchy_name string,
bonus_target_default string,
review_type_reference string,
review_reference string,
review_initiated_date string,
review_end_date string,
review_period_start_date string,
review_period_end_date string,
review_status string,
goal_id string,
goal_due_date string,
goal_completion_date string,
relocation_long_term_area string,
relocation_long_term_willing string,
relocation_short_term_area string,
relocation_short_term_willing string,
location_code string,
probation_start_date string,
probation_end_date string,
contract_reason string,
my_review_end_date string,
my_review_status string,
employee_visibility_date string,
prime_co_percent string,
prime_exp_percent string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null
)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/workday/get_workers/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.get_workers_rejected
if(spark.catalog.tableExists("employee.get_workers_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.get_workers_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_salaries
spark.sql(""" drop table if exists employee.hra_salaries; """)
spark.sql(""" create table if not exists employee.hra_salaries (
matricule_hr_access string not null, 
matricule_wd string, 
compte_ad string, 
qualite string, 
nom_usuel string, 
nom_patronymique string, 
prenom string, 
sexe string, 
nir string, 
etat_civil string, 
libelle_etat_civil string, 
date_naissance date, 
ville_naissance string, 
pays_naissance string, 
dept_naissance string, 
nationalite_princ string, 
pays_adresse string, 
no_adresse string, 
bis_ter_adresse string, 
nature_voie string, 
nom_voie string, 
complement_adresse string, 
code_insee_commune string, 
commune string, 
code_postal string, 
bureau_distributeur string, 
email_pro string, 
email_perso string, 
prenom_conjoint string, 
nom_conjoint string, 
entree_groupe date, 
anciennete_groupe date, 
derniere_embauche date, 
anciennete_poste date,
population_particuliere string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_salaries/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_salaries
if(spark.catalog.tableExists("employee.hra_salaries")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_salaries")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_salaries_rejected
spark.sql(""" drop table if exists employee.hra_salaries_rejected; """)
spark.sql(""" create table if not exists employee.hra_salaries_rejected (
matricule_hr_access string, 
matricule_wd string, 
compte_ad string, 
qualite string, 
nom_usuel string, 
nom_patronymique string, 
prenom string, 
sexe string, 
nir string, 
etat_civil string, 
libelle_etat_civil string, 
date_naissance string, 
ville_naissance string, 
pays_naissance string, 
dept_naissance string, 
nationalite_princ string, 
pays_adresse string, 
no_adresse string, 
bis_ter_adresse string, 
nature_voie string, 
nom_voie string, 
complement_adresse string, 
code_insee_commune string, 
commune string, 
code_postal string, 
bureau_distributeur string, 
email_pro string, 
email_perso string, 
prenom_conjoint string, 
nom_conjoint string, 
entree_groupe string, 
anciennete_groupe string, 
derniere_embauche string, 
anciennete_poste string,
population_particuliere string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_salaries/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_salaries_rejected
if(spark.catalog.tableExists("employee.hra_salaries_rejected"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_salaries_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_contrat
spark.sql(""" drop table if exists employee.hra_contrat; """)
spark.sql(""" create table if not exists employee.hra_contrat (
matricule_hr_access string not null,
matricule_wd string,
date_deb_contrat date not null,
date_fin_contrat date,
type_contrat string not null,
libelle_type_contrat string not null,
nature_contrat string not null,
libelle_nature_contrat string not null,
date_fin_previsionnelle date,
date_fin_periode_essai date,
motif_entree string,
libelle_motif_entree string,
motif_sortie string,
libelle_motif_sortie string, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_contrat/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_contrat
if(spark.catalog.tableExists("employee.hra_contrat"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_contrat")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_contrat_rejected
spark.sql(""" drop table if exists employee.hra_contrat_rejected; """)
spark.sql(""" create table if not exists employee.hra_contrat_rejected (
matricule_hr_access string,
matricule_wd string,
date_deb_contrat string,
date_fin_contrat string,
type_contrat string,
libelle_type_contrat string,
nature_contrat string,
libelle_nature_contrat string,
date_fin_previsionnelle string,
date_fin_periode_essai string,
motif_entree string,
libelle_motif_entree string,
motif_sortie string,
libelle_motif_sortie string, 
error_log string, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_contrat/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_contrat_rejected
if(spark.catalog.tableExists("employee.hra_contrat_rejected"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_contrat_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_salaire
spark.sql(""" drop table if exists employee.hra_salaire; """)
spark.sql(""" create table if not exists employee.hra_salaire(
matricule_hr_access string not null,
matricule_wd string,
date_effet_remu date,
date_fin_remu date,
montant_remu_base double,
montant_horaire double,
montant_periode_paie double,
montant_annuel double,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_salaire/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_salaire
if(spark.catalog.tableExists("employee.hra_salaire"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_salaire")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_salaire_rejected
spark.sql(""" drop table if exists employee.hra_salaire_rejected; """)
spark.sql(""" create table if not exists employee.hra_salaire_rejected(
matricule_hr_access string,
matricule_wd string,
date_effet_remu string,
date_fin_remu string,
montant_remu_base string,
montant_horaire string,
montant_periode_paie string,
montant_annuel string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_salaire/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_salaire_rejected
if(spark.catalog.tableExists("employee.hra_salaire_rejected"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_salaire_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_emploi
spark.sql(""" drop table if exists employee.hra_emploi; """)
spark.sql(""" create table if not exists employee.hra_emploi (
matricule_hr_access string not null,
matricule_wd string,
date_effet_emploi date not null,
date_fin_emploi date,
code_emploi string not null,
libelle_emploi string,
taux_emploi double,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_emploi/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_emploi
if(spark.catalog.tableExists("employee.hra_emploi")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_emploi")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_emploi_rejected
spark.sql(""" drop table if exists employee.hra_emploi_rejected; """)
spark.sql(""" create table if not exists employee.hra_emploi_rejected (
matricule_hr_access string,
matricule_wd string,
date_effet_emploi string,
date_fin_emploi string,
code_emploi string,
libelle_emploi string,
taux_emploi double,
error_log string,
filepath string not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_emploi/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_emploi_rejected
if(spark.catalog.tableExists("employee.hra_emploi_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_emploi_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_tempstravail
spark.sql(""" drop table if exists employee.hra_tempstravail; """)
spark.sql(""" create table if not exists employee.hra_tempstravail (
matricule_hr_access string not null,
matricule_wd string,
date_effet_tps_contractuel date,
date_fin_tps_contractuel date,
type_temps_contractuel string,
libelle_type_temps_contractuel string,
code_modalite_horaire string,
nb_heure_presence_sem double,
nb_heure_presence_mois double,
nb_heure_payes_sem double,
nb_heure_payes_mois double,
nb_jours_travailles_an double,
taux_travail double,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_tempstravail/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_tempstravail
if(spark.catalog.tableExists("employee.hra_tempstravail")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_tempstravail")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_tempstravail_rejected
spark.sql(""" drop table if exists employee.hra_tempstravail_rejected; """)
spark.sql(""" create table if not exists employee.hra_tempstravail_rejected (
matricule_hr_access string,
matricule_wd string,
date_effet_tps_contractuel string,
date_fin_tps_contractuel string,
type_temps_contractuel string,
libelle_type_temps_contractuel string,
code_modalite_horaire string,
nb_heure_presence_sem string,
nb_heure_presence_mois string,
nb_heure_payes_sem string,
nb_heure_payes_mois string,
nb_jours_travailles_an string,
taux_travail double,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_tempstravail/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_tempstravail_rejected
if(spark.catalog.tableExists("employee.hra_tempstravail_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_tempstravail_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_etp
spark.sql(""" drop table if exists employee.hra_etp; """)
spark.sql(""" create table if not exists employee.hra_etp (
matricule_hr_access string not null,
matricule_wd string,
date_deb_etp date,
date_fin_etp date,
horaire_affectation string,
etp double,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_etp/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_etp
if(spark.catalog.tableExists("employee.hra_etp")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_etp")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_etp_rejected
spark.sql(""" drop table if exists employee.hra_etp_rejected; """)
spark.sql(""" create table if not exists employee.hra_etp_rejected (
matricule_hr_access string,
matricule_wd string,
date_deb_etp string,
date_fin_etp string,
horaire_affectation string,
etp string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_etp/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_etp_rejected
if(spark.catalog.tableExists("employee.hra_etp_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_etp_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_typeheure
spark.sql(""" drop table if exists employee.hra_typeheure; """)
spark.sql(""" create table if not exists employee.hra_typeheure (
matricule_hr_access string not null,
matricule_wd string,
date_deb_affection_cycle date,
date_fin_affectation_cycle date,
code_affection_cycle string,
libelle_type_heure string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_type_heure/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_typeheure
if(spark.catalog.tableExists("employee.hra_typeheure")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_typeheure")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_typeheure_rejected
spark.sql(""" drop table if exists employee.hra_typeheure_rejected; """)
spark.sql(""" create table if not exists employee.hra_typeheure_rejected (
matricule_hr_access string,
matricule_wd string,
date_deb_affection_cycle string,
date_fin_affectation_cycle string,
code_affection_cycle string,
libelle_type_heure string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_type_heure/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_typeheure_rejected
if(spark.catalog.tableExists("employee.hra_typeheure_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_typeheure_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_enfants
spark.sql(""" drop table if exists employee.hra_enfants; """)
spark.sql(""" create table if not exists employee.hra_enfants (
matricule_hr_access string not null,
matricule_wd string,
numero_ordre string,
date_naissance date,
prenom string,
nom string,
sexe string,
date_deces string,
enfant_a_charge string,
date_deb_prise_en_charge date,
date_fin_prise_en_charge date,
enfant_a_charge_secu string,
date_deb_prise_en_charge_secu date,
date_fin_prise_en_charge_secu date,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_enfants/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_enfants
if(spark.catalog.tableExists("employee.hra_enfants"))// test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_enfants")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_enfants_rejected
spark.sql(""" drop table if exists employee.hra_enfants_rejected; """)
spark.sql(""" create table if not exists employee.hra_enfants_rejected (
matricule_hr_access string,
matricule_wd string,
numero_ordre string,
date_naissance string,
prenom string,
nom string,
sexe string,
date_deces string,
enfant_a_charge string,
date_deb_prise_en_charge string,
date_fin_prise_en_charge string,
enfant_a_charge_secu string,
date_deb_prise_en_charge_secu string,
date_fin_prise_en_charge_secu string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_enfants/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_enfants_rejected
if(spark.catalog.tableExists("employee.hra_enfants_rejected"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_enfants_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_natio_sec
spark.sql(""" drop table if exists employee.hra_natio_sec; """)
spark.sql(""" create table if not exists employee.hra_natio_sec(
matricule_hr_access string not null,
matricule_wd string,
nationalite_secondaire string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_natio_sec/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_natio_sec
if(spark.catalog.tableExists("employee.hra_natio_sec")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_natio_sec")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_natio_sec_rejected
spark.sql(""" drop table if exists employee.hra_natio_sec_rejected; """)
spark.sql(""" create table if not exists employee.hra_natio_sec_rejected(
matricule_hr_access string,
matricule_wd string,
nationalite_secondaire string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_natio_sec/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_natio_sec_rejected
if(spark.catalog.tableExists("employee.hra_natio_sec_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_natio_sec_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_suspension
spark.sql(""" drop table if exists employee.hra_suspension; """)
spark.sql(""" create table if not exists employee.hra_suspension(
matricule_hr_access string not null,
matricule_wd string,
date_deb_situation date,
date_fin_situation date,
categorie string,
libelle_categorie string,
motif string,
libelle_motif string,
flag_conges string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_suspension/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_suspension
if(spark.catalog.tableExists("employee.hra_suspension")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_suspension")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_suspension_rejected
spark.sql(""" drop table if exists employee.hra_suspension_rejected; """)
spark.sql(""" create table if not exists employee.hra_suspension_rejected(
matricule_hr_access string,
matricule_wd string,
date_deb_situation string,
date_fin_situation string,
categorie string,
libelle_categorie string,
motif string,
libelle_motif string,
flag_conges string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_suspension/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_suspension_rejected
if(spark.catalog.tableExists("employee.hra_suspension_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_suspension_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_carriere
spark.sql(""" drop table if exists employee.hra_carriere; """)
spark.sql(""" create table if not exists employee.hra_carriere(
matricule_hr_access string not null,
matricule_wd string,
date_deb_carriere date,
date_fin_carriere date,
qualification string,
libelle_qualification string,
classification string,
libelle_classification string,
coefficient_base string,
coefficient_spe string,
convention_collective string,
regime_cotis_retraite string,
groupe_couture string,
niveau_couture string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_carriere";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_carriere
if(spark.catalog.tableExists("employee.hra_carriere")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_carriere")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_carriere_rejected
spark.sql(""" drop table if exists employee.hra_carriere_rejected; """)
spark.sql(""" create table if not exists employee.hra_carriere_rejected(
matricule_hr_access string,
matricule_wd string,
date_deb_carriere string,
date_fin_carriere string,
qualification string,
libelle_qualification string,
classification string,
libelle_classification string,
coefficient_base string,
coefficient_spe string,
convention_collective string,
regime_cotis_retraite string,
groupe_couture string,
niveau_couture string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_carriere/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_carriere_rejected
if(spark.catalog.tableExists("employee.hra_carriere_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_carriere_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.pa_histograde
spark.sql(""" drop table if exists employee.pa_histograde; """)
spark.sql(""" create table if not exists employee.pa_histograde(
matricule_hr_access string not null,
matricule_wd string,
manager_reference string,
manager_last_name string,
manager_first_name string,
grade string,
effective_compensation_change_date date,
end_compensation_change_date date,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/pa/pa_histograde";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.pa_histograde
if(spark.catalog.tableExists("employee.pa_histograde")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.pa_histograde")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.pa_histograde_rejected
spark.sql(""" drop table if exists employee.pa_histograde_rejected; """)
spark.sql(""" create table if not exists employee.pa_histograde_rejected(
matricule_hr_access string not null,
matricule_wd string,
manager_reference string,
manager_last_name string,
manager_first_name string,
grade string,
effective_compensation_change_date string,
end_compensation_change_date string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/pa/pa_histograde/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.pa_histograde_rejected
if(spark.catalog.tableExists("employee.pa_histograde_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.pa_histograde_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_cet
spark.sql(""" drop table if exists employee.hra_cet; """)
spark.sql(""" create table if not exists employee.hra_cet(
matricule_hr_access string not null,
matricule_wd string,
date_operation date,
type_operation string,
libelle_type_operation string,
compte_operation string,
libelle_compte string,
jour double,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_cet";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_cet
if(spark.catalog.tableExists("employee.hra_cet")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_cet")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.hra_cet_rejected
spark.sql(""" drop table if exists employee.hra_cet_rejected; """)
spark.sql(""" create table if not exists employee.hra_cet_rejected(
matricule_hr_access string not null,
matricule_wd string,
date_operation date,
type_operation string,
libelle_type_operation string,
compte_operation string,
libelle_compte string,
jour string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/hra/hra_cet/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.hra_cet_rejected
if(spark.catalog.tableExists("employee.hra_cet_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.hra_cet_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.histo_grade
spark.sql(""" drop table if exists employee.histo_grade; """)
spark.sql(""" create table if not exists employee.histo_grade(
employee_id string not null,
compensation_grade_reference_label string,
compensation_grade_reference_label_2 string,
effective_date_from_comp date,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/workday/histo_grade";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.histo_grade
if(spark.catalog.tableExists("employee.histo_grade")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.histo_grade")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.histo_grade_rejected
spark.sql(""" drop table if exists employee.histo_grade_rejected; """)
spark.sql(""" create table if not exists employee.histo_grade_rejected(
employee_id string not null,
compensation_grade_reference_label string,
compensation_grade_reference_label_2 string,
effective_date_from_comp string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/workday/histo_grade/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.histo_grade_rejected
if(spark.catalog.tableExists("employee.histo_grade_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.histo_grade_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.histo_job_profile
spark.sql(""" drop table if exists employee.histo_job_profile; """)
spark.sql(""" create table if not exists employee.histo_job_profile(
employee_id string not null,
job_profile_name string,
job_profile_reference string,
effective_date_from_job_change date,
job_category string,
job_family string,
job_family_group string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/workday/histo_job_profile";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.histo_job_profile
if(spark.catalog.tableExists("employee.histo_job_profile")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.histo_job_profile")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.histo_job_profile_rejected
spark.sql(""" drop table if exists employee.histo_job_profile_rejected; """)
spark.sql(""" create table if not exists employee.histo_job_profile_rejected(
employee_id string not null,
job_profile_name string,
job_profile_reference string,
effective_date_from_job_change string,
job_category string,
job_family string,
job_family_group string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/workday/histo_job_profile/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.histo_job_profile_rejected
if(spark.catalog.tableExists("employee.histo_job_profile_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.histo_job_profile_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.histo_management_level
spark.sql(""" drop table if exists employee.histo_management_level; """)
spark.sql(""" create table if not exists employee.histo_management_level(
employee_id string not null,
management_level_reference string,
management_level_label string,
effective_date_from_job_change date,
statut_actif string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/workday/histo_management_level";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.histo_management_level
if(spark.catalog.tableExists("employee.histo_management_level")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.histo_management_level")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.histo_management_level_rejected
spark.sql(""" drop table if exists employee.histo_management_level_rejected; """)
spark.sql(""" create table if not exists employee.histo_management_level_rejected(
employee_id string not null,
management_level_reference string,
management_level_label string,
effective_date_from_job_change string,
statut_actif string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/workday/histo_management_level/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.histo_management_level_rejected
if(spark.catalog.tableExists("employee.histo_management_level_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.histo_management_level_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.histo_site
spark.sql(""" drop table if exists employee.histo_site; """)
spark.sql(""" create table if not exists employee.histo_site(
employee_id string not null,
business_site_summary_data_name string,
effective_date_from_location_change date,
location_type string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/workday/histo_site";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.histo_site
if(spark.catalog.tableExists("employee.histo_site")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.histo_site")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.histo_site_rejected
spark.sql(""" drop table if exists employee.histo_site_rejected; """)
spark.sql(""" create table if not exists employee.histo_site_rejected(
employee_id string not null,
business_site_summary_data_name string,
effective_date_from_location_change string,
location_type string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/workday/histo_site/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.histo_site_rejected
if(spark.catalog.tableExists("employee.histo_site_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.histo_site_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}