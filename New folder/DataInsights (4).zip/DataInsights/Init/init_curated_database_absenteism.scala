// Databricks notebook source
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

// DBTITLE 1,Create database absenteism
spark.sql(""" create database if not exists absenteism; """)

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.absprev
spark.sql(""" drop table if exists absenteism.absprev; """)
spark.sql(""" 
create table if not exists absenteism.absprev (
nummat int, 
dateval date not null, 
hdeb double, 
hfin double, 
duree double, 
nbrvac double, 
code string not null, 
type int, 
signature int, 
matricule string not null,
signature_desc string,
type_libelle string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,version)
LOCATION "/mnt/curated_container/absenteism/gestor/absprev/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.absprev
if(spark.catalog.tableExists("absenteism.absprev"))
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.absprev")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.absprev_rejected
spark.sql(""" drop table if exists absenteism.absprev_rejected; """)
spark.sql(""" 
create table if not exists absenteism.absprev_rejected (
nummat string, 
dateval string, 
hdeb string, 
hfin string, 
duree string, 
nbrvac string, 
code string, 
type string, 
signature string, 
matricule string,
signature_desc string,
type_libelle string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,version)
LOCATION "/mnt/curated_source_file_absenteism_container/absenteism/gestor/absprev/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.absprev_rejected
if(spark.catalog.tableExists("absenteism.absprev_rejected"))
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.absprev_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.codeevt
spark.sql(""" drop table if exists absenteism.codeevt; """)
spark.sql(""" 
create table if not exists absenteism.codeevt (
numero int, 
code string not null, 
libelle string not null, 
heure int, 
famregroup int, 
type int, 
type_libelle string,
famregroup_libelle string, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/codeevt/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.codeevt
if(spark.catalog.tableExists("absenteism.codeevt")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.codeevt")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.codeevt_rejected
spark.sql(""" drop table if exists absenteism.codeevt_rejected; """)
spark.sql(""" 
create table if not exists absenteism.codeevt_rejected (
numero int, 
code string, 
libelle string, 
heure string, 
famregroup string, 
type string, 
type_libelle string,
famregroup_libelle string, 
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/codeevt/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.codeevt_rejected
if(spark.catalog.tableExists("absenteism.codeevt_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.codeevt_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.compteurs
spark.sql(""" drop table if exists absenteism.compteurs; """)
spark.sql(""" 
create table if not exists absenteism.compteurs (
numero int, 
libcourt string, 
liblong string, 
heurejour int, 
famille int, 
libelle string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/compteurs/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.compteurs
if(spark.catalog.tableExists("absenteism.compteurs")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.compteurs")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.compteurs_rejected
spark.sql(""" drop table if exists absenteism.compteurs_rejected; """)
spark.sql(""" 
create table if not exists absenteism.compteurs_rejected (
numero string, 
libcourt string, 
liblong string, 
heurejour string, 
famille string, 
libelle string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/compteurs/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.compteurs_rejected
if(spark.catalog.tableExists("absenteism.compteurs_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.compteurs_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.detchamps
spark.sql(""" drop table if exists absenteism.detchamps; """)
spark.sql(""" 
create table if not exists absenteism.detchamps (
nummat string,
datedebut date,
datefin date,
cl_drtrtt string,
cl_drtlibre string,
cl_drcaptl string,
cl_ticket string,
cl_hcontnuit string,
cl_drhsup string,
cl_hssem string,
cl_hsnuit string,
cl_hssam string,
cl_hsdimjf string,
cl_indicpaye string,
cl_maxrdc string,
cl_ctrctclosure string,
cl_multi_contra string,
cl_teletra string,
cl_trav_dim string,
cl_zone_tour string,
cl_tele_int string,
cl_tele_int_libelle double,
sop_charte string,
matricule string not null,
valeur string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/detchamps/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.detchamps
if(spark.catalog.tableExists("absenteism.detchamps")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.detchamps")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.detchamps_rejected
spark.sql(""" drop table if exists absenteism.detchamps_rejected; """)
spark.sql(""" 
create table if not exists absenteism.detchamps_rejected (
nummat string,
datedebut string,
datefin string,
cl_drtrtt string,
cl_drtlibre string,
cl_drcaptl string,
cl_ticket string,
cl_hcontnuit string,
cl_drhsup string,
cl_hssem string,
cl_hsnuit string,
cl_hssam string,
cl_hsdimjf string,
cl_indicpaye string,
cl_maxrdc string,
cl_ctrctclosure string,
cl_multi_contra string,
cl_teletra string,
cl_trav_dim string,
cl_zone_tour string,
cl_tele_int string,
cl_tele_int_libelle string,
sop_charte string,
matricule string,
valeur string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/detchamps/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.detchamps_rejected
if(spark.catalog.tableExists("absenteism.detchamps_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.detchamps_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.indicateurs
spark.sql(""" drop table if exists absenteism.indicateurs; """)
spark.sql(""" 
create table if not exists absenteism.indicateurs (
ind_num int,
ind_type int,
ind_code string,
ind_date_deb date,
ind_date_fin date,
pl_jour string,
pl_partiel string,
dispo string,
evt_pres string,
drt_crea_period string,
drt_periode_sui string,
drt_code_imp string,
drt_cpt_imp string,
drt_conso_cpt string,
drt_conso_code string,
ph_primeq string,
ph_primhab string,
ph_drttl string,
ph_drtrtt string,
ev_jtrav string,
ev_prod string,
ev_tpslib string,
ev_tpsrtt string,
ev_ticket string,
ev_panier string,
ev_habill string,
ev_typeabs string,
ev_tteleg string,
ev_tteconv string,
ph_panier string,
ph_derog string,
ev_chance string,
ev_prime_douche string,
ph_prime_douche string,
ph_rert string,
ev_teletra string,
ph_paspause string,
ph_absduree string,
ev_presd string,
ph_sol string,
ph_nuit string,
ph_hs string,
ev_prolon string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/indicateurs/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.indicateurs
if(spark.catalog.tableExists("absenteism.indicateurs")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.indicateurs")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.indicateurs_rejected
spark.sql(""" drop table if exists absenteism.indicateurs_rejected; """)
spark.sql(""" 
create table if not exists absenteism.indicateurs_rejected (
ind_num string,
ind_type string,
ind_code string,
ind_date_deb string,
ind_date_fin string,
pl_jour string,
pl_partiel string,
dispo string,
evt_pres string,
drt_crea_period string,
drt_periode_sui string,
drt_code_imp string,
drt_cpt_imp string,
drt_conso_cpt string,
drt_conso_code string,
ph_primeq string,
ph_primhab string,
ph_drttl string,
ph_drtrtt string,
ev_jtrav string,
ev_prod string,
ev_tpslib string,
ev_tpsrtt string,
ev_ticket string,
ev_panier string,
ev_habill string,
ev_typeabs string,
ev_tteleg string,
ev_tteconv string,
ph_panier string,
ph_derog string,
ev_chance string,
ev_prime_douche string,
ph_prime_douche string,
ph_rert string,
ev_teletra string,
ph_paspause string,
ph_absduree string,
ev_presd string,
ph_sol string,
ph_nuit string,
ph_hs string,
ev_prolon string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/indicateurs/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.indicateurs_rejected
if(spark.catalog.tableExists("absenteism.indicateurs_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.indicateurs_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.perso_droit
spark.sql(""" drop table if exists absenteism.perso_droit; """)
spark.sql(""" 
create table if not exists absenteism.perso_droit (
nummat int,
pedr_code int,
pedr_datedeb date,
pedr_datefin date,
pedr_classe int,
pedr_unit int,
pedr_typectrl int,
pedr_acquis double,
pedr_principal double,
pedr_sup double,
pedr_sup1 double,
pedr_sup2 double,
pedr_reliquat double,
pedr_dtreliquat date,
pedr_relperdu double,
pedr_anticipe double,
pedr_consomme double,
pedr_prvalide double,
pedr_prattente double,
pedr_seuil_solde double,
matricule string not null,
refd_valeur int,
pedr_typectrl_libelle int,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/perso_droit/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.perso_droit
if(spark.catalog.tableExists("absenteism.perso_droit")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.perso_droit")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.perso_droit_rejected
spark.sql(""" drop table if exists absenteism.perso_droit_rejected; """)
spark.sql(""" 
create table if not exists absenteism.perso_droit_rejected (
nummat string,
pedr_code string,
pedr_datedeb string,
pedr_datefin string,
pedr_classe string,
pedr_unit string,
pedr_typectrl string,
pedr_acquis string,
pedr_principal string,
pedr_sup string,
pedr_sup1 string,
pedr_sup2 string,
pedr_reliquat string,
pedr_dtreliquat string,
pedr_relperdu string,
pedr_anticipe string,
pedr_consomme string,
pedr_prvalide string,
pedr_prattente string,
pedr_seuil_solde string,
matricule string,
refd_valeur string,
pedr_typectrl_libelle string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/perso_droit/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.perso_droit_rejected
if(spark.catalog.tableExists("absenteism.perso_droit_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.perso_droit_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.perso_droitj
spark.sql(""" drop table if exists absenteism.perso_droitj; """)
spark.sql(""" 
create table if not exists absenteism.perso_droitj (
nummat int, 
pedr_code string, 
pedr_dateval date, 
pedr_valeur int, 
pedr_prev double, 
matricule string not null,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/perso_droitj/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.perso_droitj
if(spark.catalog.tableExists("absenteism.perso_droitj")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.perso_droitj")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.perso_droitj_rejected
spark.sql(""" drop table if exists absenteism.perso_droitj_rejected; """)
spark.sql(""" 
create table if not exists absenteism.perso_droitj_rejected (
nummat string, 
pedr_code string, 
pedr_dateval string, 
pedr_valeur string, 
pedr_prev string, 
matricule string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/perso_droitj/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.perso_droitj_rejected
if(spark.catalog.tableExists("absenteism.perso_droitj_rejected"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.perso_droitj_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.compteurj
spark.sql(""" drop table if exists absenteism.compteurj; """)
spark.sql(""" 
create table if not exists absenteism.compteurj (
nummat int,
datej date,
cpt111 double,
cpt113 double,
cpt115 double,
cpt117 double,
cpt135 double,
cpt155 double,
cpt163 double,
cpt171 double,
cpt175 double,
cpt179 double,
cpt183 double,
cpt185 double,
cpt187 double,
cpt189 double,
cpt203 double,
cpt245 double,
cpt247 double,
cpt249 double,
cpt257 double,
cpt275 double,
cpt281 double,
cpt285 double,
matricule string not null,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/compteurj/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.compteurj
if(spark.catalog.tableExists("absenteism.compteurj"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.compteurj")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.compteurj_rejected
spark.sql(""" drop table if exists absenteism.compteurj_rejected;""")
spark.sql(""" 
create table if not exists absenteism.compteurj_rejected (
nummat string,
datej string,
cpt111 double,
cpt113 double,
cpt115 double,
cpt117 double,
cpt135 double,
cpt155 double,
cpt163 double,
cpt171 double,
cpt175 double,
cpt179 double,
cpt183 double,
cpt185 double,
cpt187 double,
cpt189 double,
cpt203 double,
cpt245 double,
cpt247 double,
cpt249 double,
cpt257 double,
cpt275 double,
cpt281 double,
cpt285 double,
matricule string not null,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/gestor/compteurj/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.compteurj_rejected
if(spark.catalog.tableExists("absenteism.compteurj_rejected"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.compteurj_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.referentiel_absences
spark.sql(""" drop table if exists absenteism.referentiel_absences;""")
spark.sql(""" 
create table if not exists absenteism.referentiel_absences (
periode date,
code_absence string, 
libelle_code_absence string, 
motif_absence string, 
famille_absence string, 
absence_taux_absenteisme string, 
absence_previsible_imprevisible string, 
flag_etp_productif string,
flag_taux_absenteisme string, 
flag_prolongation string, 
type_absence string, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/business/referentiel_absences/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.referentiel_absences
if(spark.catalog.tableExists("absenteism.referentiel_absences"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.referentiel_absences")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table absenteism.referentiel_absences_rejected
spark.sql(""" drop table if exists absenteism.referentiel_absences_rejected;""")
spark.sql(""" 
create table if not exists absenteism.referentiel_absences_rejected (
periode date,
code_absence string, 
libelle_code_absence string, 
motif_absence string, 
famille_absence string, 
absence_taux_absenteisme string, 
absence_previsible_imprevisible string, 
flag_etp_productif string,
flag_taux_absenteisme string, 
flag_prolongation string, 
type_absence string, 
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/absenteism/business/referentiel_absences/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.referentiel_absences_rejected
if(spark.catalog.tableExists("absenteism.referentiel_absences_rejected"))
{
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.referentiel_absences_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}