// Databricks notebook source
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true") 

// COMMAND ----------

// DBTITLE 1,Create database common
spark.sql(""" create database if not exists common; """)

// COMMAND ----------

// DBTITLE 1,Add news columns to existing table common.location
if(spark.catalog.tableExists("common.location") && pathexists("/mnt/refined_container/common/location")) // test if path exists
{
  try {


val df_location_schema = spark.sql("describe table common.location")

//Add column location_reference on common.location
if(!df_location_schema.isEmpty && df_location_schema.filter("col_name = 'location_reference'").count == 0)
{
  spark.sql("alter table common.location add columns (location_reference string after location_country)")
}

//Add column system_soure on common.location
if(!df_location_schema.isEmpty && df_location_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table common.location add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table common.location
spark.sql(""" drop table if exists common.location; """)
spark.sql("""
create table if not exists common.location (
location_key string
,location_code string
,location string
,location_type string
,location_country string
,location_reference string
,version int
,date_raw_load_file date
,filepath string
,filename string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string)
USING DELTA
LOCATION "/mnt/refined_container/common/location";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table common.location 
if(spark.catalog.tableExists("common.location")) // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE common.location")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add news columns to existing table common.location
if(spark.catalog.tableExists("common.job") && pathexists("/mnt/refined_container/common/job")) // test if path exists
{
  try {


val df_job_schema = spark.sql("describe table common.job")


//Add column system_soure on common.job
if(!df_job_schema.isEmpty && df_job_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table common.job add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table common.job
spark.sql("""drop table if exists common.job;""")
spark.sql("""
create table if not exists common.job (
job_key string    
,job_code string 
,job_title string
,grade string
,grade_label string
,management_level string
,management_level_label string
,professional_category_reference string
,professional_category_name string
,job_profile_name string
,job_profile_reference string
,job_profile_reference_label string
,job_category string
,job_family string
,job_family_group string
,version int
,date_raw_load_file date
,filepath string
,filename string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string) 
USING DELTA
LOCATION "/mnt/refined_container/common/job";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table common.job
if(spark.catalog.tableExists("common.job")) // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE common.job")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add Columns for Hierarchy PB on common.organization
if(spark.catalog.tableExists("common.organization") && pathexists("/mnt/refined_container/common/organization")) // test if path exists
{
  try {


val df_orga_schema = spark.sql("describe table common.organization")

//Add column direction_detail_code on common.organization
if(!df_orga_schema.isEmpty && df_orga_schema.filter("col_name = 'direction_detail_code'").count == 0)
{
  spark.sql("alter table common.organization add columns (direction_detail_code string after business_line_name)")
}

//Add column direction_detail_name on common.organization
if( !df_orga_schema.isEmpty && df_orga_schema.filter("col_name = 'direction_detail_name'").count == 0)
{
  spark.sql("alter table common.organization add columns (direction_detail_name string after direction_detail_code)")
}

//Add column direction_code on common.organization
if(df_orga_schema.filter("col_name = 'direction_code'").count == 0)
{
  spark.sql("alter table common.organization add columns (direction_code string after direction_detail_name)")
}

//Add column direction_name on common.organization
if(!df_orga_schema.isEmpty && df_orga_schema.filter("col_name = 'direction_name'").count == 0)
{
  spark.sql("alter table common.organization add columns (direction_name string after direction_code)")
}

//Add column direction_psb_budget_code on common.organization
if(!df_orga_schema.isEmpty && df_orga_schema.filter("col_name = 'direction_psb_budget_code'").count == 0)
{
  spark.sql("alter table common.organization add columns (direction_psb_budget_code string after direction_name)")
}

//Add column direction_psb_budget_name on common.organization
if(!df_orga_schema.isEmpty && df_orga_schema.filter("col_name = 'direction_psb_budget_name'").count == 0)
{
  spark.sql("alter table common.organization add columns (direction_psb_budget_name string after direction_psb_budget_code)")
}

//Add column direction_presentation_code on common.organization
if(!df_orga_schema.isEmpty && df_orga_schema.filter("col_name = 'direction_presentation_code'").count == 0)
{
  spark.sql("alter table common.organization add columns (direction_presentation_code string after direction_psb_budget_name)")
}

//Add column direction_presentation_name on common.organization
if(!df_orga_schema.isEmpty && df_orga_schema.filter("col_name = 'direction_presentation_name'").count == 0)
{
  spark.sql("alter table common.organization add columns (direction_presentation_name string after direction_presentation_code)")
}

//Add column system_soure on common.organization
if(!df_orga_schema.isEmpty && df_orga_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table common.organization add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table common.organization
spark.sql(""" drop table if exists common.organization; """)
spark.sql("""
create table if not exists common.organization (
orga_code string
,cost_center_code string
,cost_center_label string
,centertype string
,companycode string
,company string
,marketsegment string
,activitydomain string
,standardcostcenter string
,essbasefunction string
,profitcenter string
,code_establishment string
,label_establishment string
,code_direction string
,label_direction string
,code_department string
,label_department string
,business_line_reference string
,business_line_name string
,direction_detail_code string
,direction_detail_name string 
,direction_code string
,direction_name string
,direction_psb_budget_code string
,direction_psb_budget_name string
,direction_presentation_code string
,direction_presentation_name string
,current_hierarchy boolean
,version int
,date_raw_load_file date
,filepath string
,filename string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string) 
USING DELTA
LOCATION "/mnt/refined_container/common/organization";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table common.organization
if(spark.catalog.tableExists("common.organization")) // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE common.organization")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Add news columns to existing table common.ref_organization
if(spark.catalog.tableExists("common.ref_organization") && pathexists("/mnt/refined_container/common/ref_organization")) // test if path exists
{
  try {


val df_ref_orga_schema = spark.sql("describe table common.ref_organization")

//Add column system_soure on common.organization
if(!df_ref_orga_schema.isEmpty && df_ref_orga_schema.filter("col_name = 'system_source'").count == 0)
{
  spark.sql("alter table common.ref_organization add columns (system_source string after runid)")
}
      }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create delta table common.ref_organization
spark.sql(""" drop table if exists common.ref_organization; """)
spark.sql("""
create table if not exists common.ref_organization (
ref_orga_code string
,cost_center_code string
,cost_center_label string
,companycode string
,company string
,code_establishment string
,label_establishment string
,code_direction string
,label_direction string
,code_department string
,label_department string
,year_file int
,month_file int
,day_file int
,current_hierarchy boolean
,version int
,date_raw_load_file date
,filepath string
,filename string
,curated_ingested_date date
,current_record boolean
,record_start_date date
,record_end_date date
,record_creation_date timestamp
,record_modification_date timestamp
,hashkey string
,runid string
,system_source string) 
USING DELTA
LOCATION "/mnt/refined_container/common/ref_organization";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table common.ref_organization
if(spark.catalog.tableExists("common.ref_organization")) // test if path exists
{
  try {
    spark.sql("FSCK REPAIR TABLE common.ref_organization")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}