// Databricks notebook source
//%run /DataInsights/Init/init_database

// COMMAND ----------

dbutils.notebook.exit("Cluster started")