// Databricks notebook source
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

// DBTITLE 1,Create database recruitment
spark.sql(""" create database if not exists recruitment; """)

// COMMAND ----------

// DBTITLE 1,Create parquet table recruitment.get_candidates
spark.sql(""" drop table if exists recruitment.get_candidates; """)
spark.sql(""" 
create table if not exists recruitment.get_candidates (
candidate_id string not null,
candidate_first_name string,
candidate_last_name string, 
worker_reference string,
source_reference string,
job_requisition_reference string,
job_application_date date,
stage_reference string,
status_timestamp date, 
school_name string,
degree_reference string,
first_year_attended string,
last_year_attended string,
disposition_reference string, 
disposition_reference_id string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/recruitment/workday/get_candidates/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table recruitment.get_candidates
if(spark.catalog.tableExists("recruitment.get_candidates")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_candidates")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table recruitment.get_candidates_rejected
spark.sql(""" drop table if exists recruitment.get_candidates_rejected; """)
spark.sql(""" 
create table if not exists recruitment.get_candidates_rejected (
candidate_id string,
candidate_first_name string,
candidate_last_name string, 
worker_reference string,
source_reference string,
job_requisition_reference string,
job_application_date string,
stage_reference string,
status_timestamp string, 
school_name string,
degree_reference string,
first_year_attended string,
last_year_attended string,
disposition_reference string, 
disposition_reference_id string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/recruitment/workday/get_candidates/rejected/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table recruitment.get_candidates_rejected
if(spark.catalog.tableExists("recruitment.get_candidates_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_candidates_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table recruitment.get_job_postings
spark.sql(""" drop table if exists recruitment.get_jobpostings; """)
spark.sql(""" 
create table if not exists recruitment.get_jobpostings (
job_requisition_reference string not null,
job_posting_start_date date,
job_posting_site_reference string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/recruitment/workday/get_jobpostings/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table recruitment.get_jobpostings
if(spark.catalog.tableExists("recruitment.get_jobpostings")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_jobpostings")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table recruitment.get_jobpostings_rejected
spark.sql(""" drop table if exists recruitment.get_jobpostings_rejected; """)
spark.sql(""" 
create table if not exists recruitment.get_jobpostings_rejected (
job_requisition_reference string,
job_posting_start_date string,
job_posting_site_reference string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/recruitment/workday/get_jobpostings/rejected/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table recruitment.get_jobpostings_rejected
if(spark.catalog.tableExists("recruitment.get_jobpostings_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_jobpostings_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table recruitment.get_jobrequisitions
spark.sql(""" drop table if exists recruitment.get_jobrequisitions; """)
spark.sql(""" 
create table if not exists recruitment.get_jobrequisitions (
job_requisition_reference string not null,
job_requisition_status string, 
job_posting_title string,
recruiting_instruction_data string, 
recruiting_start_date date, 
target_hire_date date, 
target_end_date date, 
worker_type_reference string, 
position_worker_type_reference string,
primary_location_reference string,
primary_location_label string, 
primary_job_posting_location_reference string,
primary_job_posting_location_label string, 
time_type_reference string, 
position_reference string,
position_label string,
hiring_manager string, 
effective_date date,
primary_recruiter string, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/recruitment/workday/get_jobrequisitions/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table recruitment.get_job_requisitions
if(spark.catalog.tableExists("recruitment.get_jobrequisitions")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_jobrequisitions")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table recruitment.get_job_requisitions_rejected
spark.sql(""" drop table if exists recruitment.get_jobrequisitions_rejected; """)
spark.sql(""" 
create table if not exists recruitment.get_jobrequisitions_rejected (
job_requisition_reference string not null,
job_requisition_status string, 
job_posting_title string,
recruiting_instruction_data string, 
recruiting_start_date string, 
target_hire_date string, 
target_end_date string, 
worker_type_reference string, 
primary_location_reference string, 
primary_location_label string, 
primary_job_posting_location_reference string, 
primary_job_posting_location_label string, 
time_type_reference string, 
position_reference string, 
position_label string, 
primary_recruiter string, 
hiring_manager string, 
effective_date string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/recruitment/workday/get_jobrequisitions/rejected/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table recruitment.get_job_requisitions_rejected
if(spark.catalog.tableExists("recruitment.get_jobrequisitions_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_jobrequisitions_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table recruitment.get_postings
spark.sql(""" drop table if exists recruitment.get_positions; """)
spark.sql(""" 
create table if not exists recruitment.get_positions (
position_reference string not null,
earliest_hire_date date not null,
job_profile string, 
job_category string,
job_family string, 
cost_center_reference string,
cost_center string,
effective_date date,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/recruitment/workday/get_positions/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table recruitment.get_postings
if(spark.catalog.tableExists("recruitment.get_positions")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_positions")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table recruitment.get_postings_rejected
spark.sql(""" drop table if exists recruitment.get_positions_rejected; """)
spark.sql(""" 
create table if not exists recruitment.get_positions_rejected (
position_reference string  ,
earliest_hire_date string  ,
job_profile string, 
job_category string,
job_family string, 
cost_center_reference string,
cost_center string,
effective_date string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/recruitment/workday/get_positions/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table recruitment.get_postings_rejected
if(spark.catalog.tableExists("recruitment.get_positions_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_positions_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}