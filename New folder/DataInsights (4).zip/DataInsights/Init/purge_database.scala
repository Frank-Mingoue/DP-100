// Databricks notebook source
val database = dbutils.widgets.get("database").split(",").toList;
val layer = dbutils.widgets.get("layer").split(",").toList;
val table = dbutils.widgets.get("table").split(",").toList;

// COMMAND ----------

// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

val database_lower = database.map(a => a.toLowerCase())
val layer_lower = layer.map(a => a.toLowerCase())
val table_lower = table.map(a => a.toLowerCase())

val connection = getMonitoringSQLconnection()
val stmt = connection.createStatement()


// COMMAND ----------

if(layer_lower.contains("curated") || layer_lower.contains("all") )
{
   var query_delete = """ delete from monitoring.param_lastgoodrun where pipeline_name like 'pip_load_curated%' """
   var res_delete = stmt.execute(query_delete)
  
  if((database_lower.contains("all") || database_lower.contains("employee")) && table_lower.contains("all"))
  {
    dbutils.fs.rm("/mnt/curated_container/employee",true)
  }
  
  if((database_lower.contains("all") || database_lower.contains("organization")) && table_lower.contains("all"))
  {
    dbutils.fs.rm("/mnt/curated_container/organization",true)
  }
  
  if((database_lower.contains("all") || database_lower.contains("pay")) && table_lower.contains("all"))
  {
    dbutils.fs.rm("/mnt/curated_container/pay",true)
  }
  
  if((database_lower.contains("all") || database_lower.contains("absenteism")) && table_lower.contains("all"))
  {
    dbutils.fs.rm("/mnt/curated_container/absenteism",true)
  }
     
  if((database_lower.contains("all") || database_lower.contains("recruitment")) && table_lower.contains("all"))
  {
    dbutils.fs.rm("/mnt/curated_container/recruitment",true)
  }
    
  if((database_lower.contains("all") || database_lower.contains("training")) && table_lower.contains("all"))
  {
    dbutils.fs.rm("/mnt/curated_container/training",true)
  }
  
}

// COMMAND ----------

if(layer_lower.contains("refined") || layer_lower.contains("all") )
{

   var query_delete = """ delete from monitoring.param_lastgoodrun where pipeline_name like 'pip_load_refined%' """
   var res_delete = stmt.execute(query_delete)
  
  if((database_lower.contains("all") || database_lower.contains("common")) && table_lower.contains("all"))
  {
    dbutils.fs.rm("/mnt/refined_container/common/",true)
  }
  
  if((database_lower.contains("all") || database_lower.contains("hr")) && table_lower.contains("all"))
  {
    dbutils.fs.rm("/mnt/refined_container/hr/",true)
  }
  
}

// COMMAND ----------

val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0 + ";message: Purge database"

// COMMAND ----------

dbutils.notebook.exit(return_value)