// Databricks notebook source
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

// DBTITLE 1,Create database pay
spark.sql(""" create database if not exists pay; """)

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.hra_paie
spark.sql(""" drop table if exists pay.hra_paie; """)
spark.sql(""" 
create table if not exists pay.hra_paie(
matricule_hr_access string not null,
matricule_wd string,
period_paie string,
periode_valorisation string,
code_rubr string,
compte_comptable string,
base double,
montant_salarial double,
montant_patronal double,
paiezad string,
num_pac string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file , period_paie)
LOCATION "/mnt/curated_container/pay/hra/hra_paie/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.hra_paie
if(spark.catalog.tableExists("pay.hra_paie"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.hra_paie")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.hra_paie_rejected
spark.sql(""" drop table if exists pay.hra_paie_rejected; """)
spark.sql(""" 
create table if not exists pay.hra_paie_rejected(
matricule_hr_access string not null,
matricule_wd string,
period_paie string,
periode_valorisation string,
code_rubr string,
compte_comptable string,
base string,
montant_salarial string,
montant_patronal string,
paiezad string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file, period_paie)
LOCATION "/mnt/curated_container/pay/hra/hra_paie/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.hra_paie_rejected
if(spark.catalog.tableExists("pay.hra_paie_rejected"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.hra_paie_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.hra_rubr_paie
spark.sql(""" drop table if exists pay.hra_rubr_paie; """)
spark.sql(""" 
create table if not exists pay.hra_rubr_paie(
code_rubr string not null,
libelle_rubr string not null,
flag_salarial string,
flag_debit string,
compte_comptable string, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/pay/hra/hra_rubr_paie/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.hra_rubr_paie
if(spark.catalog.tableExists("pay.hra_rubr_paie")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.hra_rubr_paie")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.hra_rubr_paie_rejected
spark.sql(""" drop table if exists pay.hra_rubr_paie_rejected; """)
spark.sql(""" 
create table if not exists pay.hra_rubr_paie_rejected(
code_rubr string not null,
libelle_rubr string not null,
flag_salarial string,
flag_debit string,
compte_comptable string, 
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/pay/hra/hra_rubr_paie/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.hra_rubr_paie_rejected
if(spark.catalog.tableExists("pay.hra_rubr_paie_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.hra_rubr_paie_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.sap_natures_comptables
spark.sql(""" drop table if exists pay.sap_natures_comptables; """)
spark.sql(""" 
create table if not exists pay.sap_natures_comptables(
wage_type_code string not null, 
cost_center_code string not null, 
month int not null, 
year int not null, 
country string not null, 
currency string, 
amount double,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,year,month)
LOCATION "/mnt/curated_container/pay/sap/sap_natures_comptables/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.sap_natures_comptables
if(spark.catalog.tableExists("pay.sap_natures_comptables")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.sap_natures_comptables")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.sap_natures_comptables_rejected
spark.sql(""" drop table if exists pay.sap_natures_comptables_rejected; """)
spark.sql(""" 
create table if not exists pay.sap_natures_comptables_rejected(
wage_type_code string, 
cost_center_code string, 
month string, 
year string, 
country string, 
currency string, 
amount string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,year,month)
LOCATION "/mnt/curated_container/pay/sap/sap_natures_comptables/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.sap_natures_comptables_rejected
if(spark.catalog.tableExists("pay.sap_natures_comptables_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.sap_natures_comptables_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.action_logement
spark.sql(""" drop table if exists pay.action_logement; """)
spark.sql(""" 
create table if not exists pay.action_logement(
periode date, 
matricule_hra string, 
matricule_workday string, 
nom string, 
prenom string, 
thematique_action_logement string, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/action_logement";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.action_logement
if(spark.catalog.tableExists("pay.action_logement")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.action_logement")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.action_logement_rejected
spark.sql(""" drop table if exists pay.action_logement_rejected; """)
spark.sql(""" 
create table if not exists pay.action_logement_rejected(
periode date, 
matricule_hra string, 
matricule_workday string, 
nom string, 
prenom string, 
thematique_action_logement string, 
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/action_logement/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.action_logement_rejected
if(spark.catalog.tableExists("pay.action_logement_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.action_logement_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.eligibilite_psb
spark.sql(""" drop table if exists pay.eligibilite_psb; """)
spark.sql(""" 
create table if not exists pay.eligibilite_psb(
periode string, 
matricule_hra string, 
matricule_workday string, 
nom string, 
prenom string, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/eligibilite_psb";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.eligibilite_psb
if(spark.catalog.tableExists("pay.eligibilite_psb")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.eligibilite_psb")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.eligibilite_psb_rejected
spark.sql(""" drop table if exists pay.eligibilite_psb_rejected; """)
spark.sql(""" 
create table if not exists pay.eligibilite_psb_rejected(
periode string, 
matricule_hra string, 
matricule_workday string, 
nom string, 
prenom string, 
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/eligibilite_psb/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.eligibilite_psb_rejected
if(spark.catalog.tableExists("pay.eligibilite_psb_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.eligibilite_psb_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.percol_peb_ccb
spark.sql(""" drop table if exists pay.percol_peb_ccb; """)
spark.sql(""" 
create table if not exists pay.percol_peb_ccb(
periode string, 
matricule_hra string, 
matricule_workday string, 
nom string, 
prenom string, 
flag_amundi_per_col int, 
flag_amundi_peg int, 
flag_amundi_ccb int, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/percol_peb_ccb";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.percol_peb_ccb
if(spark.catalog.tableExists("pay.percol_peb_ccb")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.percol_peb_ccb")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.percol_peb_ccb_rejected
spark.sql(""" drop table if exists pay.percol_peb_ccb_rejected; """)
spark.sql(""" 
create table if not exists pay.percol_peb_ccb_rejected(
periode string, 
matricule_hra string, 
matricule_workday string, 
nom string, 
prenom string, 
flag_amundi_per_col string, 
flag_amundi_peg string, 
flag_amundi_ccb string, 
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/percol_peb_ccb/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.percol_peb_ccb_rejected
if(spark.catalog.tableExists("pay.percol_peb_ccb_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.percol_peb_ccb_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.montant_lti
spark.sql(""" drop table if exists pay.montant_lti; """)
spark.sql(""" 
create table if not exists pay.montant_lti(
periode string, 
annee int,
matricule_hra string, 
matricule_workday string, 
nom string, 
prenom string, 
montant_lti_annuel double, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/montant_lti";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.montant_lti
if(spark.catalog.tableExists("pay.montant_lti"))// test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.montant_lti")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.montant_lti_rejected
spark.sql(""" drop table if exists pay.montant_lti_rejected; """)
spark.sql(""" 
create table if not exists pay.montant_lti_rejected(
periode string, 
annee string,
matricule_hra string, 
matricule_workday string, 
nom string, 
prenom string, 
montant_lti_annuel string, 
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/montant_lti/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.montant_lti_rejected
if(spark.catalog.tableExists("pay.montant_lti_rejected"))// // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.montant_lti_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.montant_prime_objectif_theorique
spark.sql(""" drop table if exists pay.montant_prime_objectif_theorique; """)
spark.sql(""" 
create table if not exists pay.montant_prime_objectif_theorique(
periode string, 
annee_mois int,
matricule_hra string, 
matricule_workday string, 
nom string, 
prenom string, 
montant_prime_objectif_theorique double, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/montant_prime_objectif_theorique";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.montant_prime_objectif_theorique
if(spark.catalog.tableExists("pay.montant_prime_objectif_theorique"))//// test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.montant_prime_objectif_theorique")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.montant_prime_objectif_theorique_rejected
spark.sql(""" drop table if exists pay.montant_prime_objectif_theorique_rejected; """)
spark.sql(""" 
create table if not exists pay.montant_prime_objectif_theorique_rejected(
periode string, 
annee_mois string,
matricule_hra string, 
matricule_workday string, 
nom string, 
prenom string, 
montant_prime_objectif_theorique string, 
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/montant_prime_objectif_theorique/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.montant_prime_objectif_theorique_rejected
if(spark.catalog.tableExists("pay.montant_prime_objectif_theorique_rejected"))//// test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.montant_prime_objectif_theorique_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.politique_voiture_mobilite
spark.sql(""" drop table if exists pay.politique_voiture_mobilite; """)
spark.sql(""" 
create table if not exists pay.politique_voiture_mobilite(
periode string, 
matricule_hra string,  
nom string, 
prenom string, 
date_debut_avantage date, 
date_fin_avantage date, 
categorie_avantage string,
type_avantage string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/politique_voiture_mobilite";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.politique_voiture_mobilite
if(spark.catalog.tableExists("pay.politique_voiture_mobilite")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.politique_voiture_mobilite")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.politique_voiture_mobilite_rejected
spark.sql(""" drop table if exists pay.politique_voiture_mobilite_rejected; """)
spark.sql(""" 
create table if not exists pay.politique_voiture_mobilite_rejected(
periode string, 
matricule_hra string,  
nom string, 
prenom string, 
date_debut_avantage string, 
date_fin_avantage string, 
categorie_avantage string,
type_avantage string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/politique_voiture_mobilite/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.politique_voiture_mobilite_rejected
if(spark.catalog.tableExists("pay.politique_voiture_mobilite_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.politique_voiture_mobilite_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.ag_etablissement
spark.sql(""" drop table if exists pay.ag_etablissement; """)
spark.sql(""" 
create table if not exists pay.ag_etablissement(
periode string, 
libelle_etablissement string,  
code_etablissement string, 
pourcentage_ag string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/ag_etablissement";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.ag_etablissement
if(spark.catalog.tableExists("pay.ag_etablissement")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.ag_etablissement")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.ag_etablissement_rejected
spark.sql(""" drop table if exists pay.ag_etablissement_rejected; """)
spark.sql(""" 
create table if not exists pay.ag_etablissement_rejected(
periode string, 
libelle_etablissement string,  
code_etablissement string, 
pourcentage_ag string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file,periode)
LOCATION "/mnt/curated_container/pay/business/ag_etablissement/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.ag_etablissement_rejected
if(spark.catalog.tableExists("pay.ag_etablissement_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.ag_etablissement_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.rubriques_paie
spark.sql(""" drop table if exists pay.rubriques_paie; """)
spark.sql(""" 
create table if not exists pay.rubriques_paie(
code_rubrique_paie_hra string,
nature_comptable string,
code_rubrique_paie string,
libelle_rubrique_paie string,
code_rubrique_paie_niveau_4 string,
libelle_rubrique_paie_niveau_4 string,
code_rubrique_paie_niveau_3 string,
libelle_rubrique_paie_niveau_3 string,
code_rubrique_paie_niveau_2 string,
libelle_rubrique_paie_niveau_2 string,
code_rubrique_paie_niveau_1 string,
libelle_rubrique_paie_niveau_1 string,
flag_montant_masse_salariale_brute string,
flag_montant_aw4 string,
flag_montant_aw6 string,
flag_montant_rem_nao string,
flag_montant_rem_bs string,
flag_montant_rem_benchmark string,
flag_montant_rem_cible string,
flag_montant_rem_reelle string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/pay/business/rubriques_paie";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.rubriques_paie
if(spark.catalog.tableExists("pay.rubriques_paie")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.rubriques_paie")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.rubriques_paie_rejected
spark.sql(""" drop table if exists pay.rubriques_paie_rejected; """)
spark.sql(""" 
create table if not exists pay.rubriques_paie_rejected(
code_rubrique_paie_hra string,
nature_comptable string,
code_rubrique_paie string,
libelle_rubrique_paie string,
code_rubrique_paie_niveau_4 string,
libelle_rubrique_paie_niveau_4 string,
code_rubrique_paie_niveau_3 string,
libelle_rubrique_paie_niveau_3 string,
code_rubrique_paie_niveau_2 string,
libelle_rubrique_paie_niveau_2 string,
code_rubrique_paie_niveau_1 string,
libelle_rubrique_paie_niveau_1 string,
flag_montant_masse_salariale_brute string,
flag_montant_aw4 string,
flag_montant_aw6 string,
flag_montant_rem_nao string,
flag_montant_rem_bs string,
flag_montant_rem_benchmark string,
flag_montant_rem_cible string,
flag_montant_rem_reelle string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/pay/business/rubriques_paie/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.rubriques_paie_rejected
if(spark.catalog.tableExists("pay.rubriques_paie_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.rubriques_paie_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}