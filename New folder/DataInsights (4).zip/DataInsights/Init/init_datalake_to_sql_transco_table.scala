// Databricks notebook source
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// MAGIC %md ## 1- Read Transco Data from datalake

// COMMAND ----------

val df_path = "dbfs:/mnt/raw_container/business/transco/*/*/*/*/"
val df_transco = spark.read.format("csv").option("sep",";").option("header",true).load(df_path).distinct

// COMMAND ----------

// MAGIC %md ##2 - Csv to SQl Database 

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table dbo.param_transco_ref """
val res = stmt.execute(query_delete)

// COMMAND ----------

df_transco.distinct.write.mode(SaveMode.Overwrite).jdbc(jdbcurl, "dbo.param_transco_ref", connectionproperties)

// COMMAND ----------

df_transco.unpersist