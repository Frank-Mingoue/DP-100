// Databricks notebook source
val database = dbutils.widgets.get("database").split(",").toList;
val layer = dbutils.widgets.get("layer").split(",").toList;

// COMMAND ----------

// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

val database_lower = database.map(a => a.toLowerCase())
val layer_lower = layer.map(a => a.toLowerCase())
val timeoutSeconds=0 

// COMMAND ----------

if(layer_lower.contains("curated") || layer_lower.contains("all") )
{
  if(database_lower.contains("all") || database_lower.contains("employee"))
  {
    dbutils.notebook.run("/DataInsights/Init/init_curated_database_employee",timeoutSeconds)
  }
  
  if(database_lower.contains("all") || database_lower.contains("organization"))
  {
    dbutils.notebook.run("/DataInsights/Init/init_curated_database_organization",timeoutSeconds)
  }
  
  if(database_lower.contains("all") || database_lower.contains("pay"))
  {
    dbutils.notebook.run("/DataInsights/Init/init_curated_database_pay",timeoutSeconds)
  }
  
  if(database_lower.contains("all") || database_lower.contains("absenteism"))
  {
    dbutils.notebook.run("/DataInsights/Init/init_curated_database_absenteism",timeoutSeconds)
  }
     
  if(database_lower.contains("all") || database_lower.contains("recruitment"))
  {
    dbutils.notebook.run("/DataInsights/Init/init_curated_database_recruitment",timeoutSeconds)
  }
  
  if(database_lower.contains("all") || database_lower.contains("training"))
  {
    dbutils.notebook.run("/DataInsights/Init/init_curated_database_training",timeoutSeconds)
  }
  
  if(database_lower.contains("all") || database_lower.contains("adp"))
  {
    dbutils.notebook.run("/DataInsights/Init/init_curated_database_adp",timeoutSeconds)
  }
  
}

// COMMAND ----------

if(layer_lower.contains("refined") || layer_lower.contains("all") )
{
  if(database_lower.contains("all") || database_lower.contains("common"))
  {
    dbutils.notebook.run("/DataInsights/Init/init_refined_database_common",timeoutSeconds)
  }
  
  if(database_lower.contains("all") || database_lower.contains("hr"))
  {
    dbutils.notebook.run("/DataInsights/Init/init_refined_database_hr",timeoutSeconds)
  }
  
}

// COMMAND ----------

val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0 + ";message: Init database"

// COMMAND ----------

dbutils.notebook.exit(return_value)