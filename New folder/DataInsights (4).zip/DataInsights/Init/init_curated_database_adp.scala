// Databricks notebook source
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_salaries
spark.sql(""" drop table if exists employee.adp_salaries; """)
spark.sql(""" create table if not exists employee.adp_salaries (
matricule_hr_access string not null, 
matricule_wd string, 
compte_ad string, 
qualite string, 
nom_usuel string, 
nom_patronymique string, 
prenom string, 
sexe string, 
nir string, 
etat_civil string, 
libelle_etat_civil string, 
date_naissance date, 
ville_naissance string, 
pays_naissance string, 
dept_naissance string, 
nationalite_princ string, 
pays_adresse string, 
no_adresse string, 
bis_ter_adresse string, 
nature_voie string, 
nom_voie string, 
complement_adresse string, 
code_insee_commune string, 
commune string, 
code_postal string, 
bureau_distributeur string, 
email_pro string, 
email_perso string, 
prenom_conjoint string, 
nom_conjoint string, 
entree_groupe date, 
anciennete_groupe date, 
derniere_embauche date, 
anciennete_poste date,
population_particuliere string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_salaries/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_salaries
if(spark.catalog.tableExists("employee.adp_salaries")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_salaries")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_salaries_rejected
spark.sql(""" drop table if exists employee.adp_salaries_rejected; """)
spark.sql(""" create table if not exists employee.adp_salaries_rejected (
matricule_hr_access string, 
matricule_wd string, 
compte_ad string, 
qualite string, 
nom_usuel string, 
nom_patronymique string, 
prenom string, 
sexe string, 
nir string, 
etat_civil string, 
libelle_etat_civil string, 
date_naissance string, 
ville_naissance string, 
pays_naissance string, 
dept_naissance string, 
nationalite_princ string, 
pays_adresse string, 
no_adresse string, 
bis_ter_adresse string, 
nature_voie string, 
nom_voie string, 
complement_adresse string, 
code_insee_commune string, 
commune string, 
code_postal string, 
bureau_distributeur string, 
email_pro string, 
email_perso string, 
prenom_conjoint string, 
nom_conjoint string, 
entree_groupe string, 
anciennete_groupe string, 
derniere_embauche string, 
anciennete_poste string,
population_particuliere string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_salaries/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_salaries_rejected
if(spark.catalog.tableExists("employee.adp_salaries_rejected"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_salaries_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_contrat
spark.sql(""" drop table if exists employee.adp_contrat; """)
spark.sql(""" create table if not exists employee.adp_contrat (
matricule_hr_access string not null,
matricule_wd string,
date_deb_contrat date not null,
date_fin_contrat date,
type_contrat string not null,
libelle_type_contrat string not null,
nature_contrat string not null,
libelle_nature_contrat string not null,
date_fin_previsionnelle date,
date_fin_periode_essai date,
motif_entree string,
libelle_motif_entree string,
motif_sortie string,
libelle_motif_sortie string, 
code_recours string,
libelle_recours string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_contrat/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_contrat
if(spark.catalog.tableExists("employee.adp_contrat"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_contrat")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_contrat_rejected
spark.sql(""" drop table if exists employee.adp_contrat_rejected; """)
spark.sql(""" create table if not exists employee.adp_contrat_rejected (
matricule_hr_access string,
matricule_wd string,
date_deb_contrat string,
date_fin_contrat string,
type_contrat string,
libelle_type_contrat string,
nature_contrat string,
libelle_nature_contrat string,
date_fin_previsionnelle string,
date_fin_periode_essai string,
motif_entree string,
libelle_motif_entree string,
motif_sortie string,
libelle_motif_sortie string, 
code_recours string,
libelle_recours string,
error_log string, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_contrat/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_contrat_rejected
if(spark.catalog.tableExists("employee.adp_contrat_rejected"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_contrat_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_salaire
spark.sql(""" drop table if exists employee.adp_salaire; """)
spark.sql(""" create table if not exists employee.adp_salaire(
matricule_hr_access string not null,
matricule_wd string,
date_effet_remu date,
date_fin_remu date,
montant_remu_base double,
montant_horaire double,
montant_periode_paie double,
montant_annuel double,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_salaire/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_salaire
if(spark.catalog.tableExists("employee.adp_salaire"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_salaire")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_salaire_rejected
spark.sql(""" drop table if exists employee.adp_salaire_rejected; """)
spark.sql(""" create table if not exists employee.adp_salaire_rejected(
matricule_hr_access string,
matricule_wd string,
date_effet_remu string,
date_fin_remu string,
montant_remu_base string,
montant_horaire string,
montant_periode_paie string,
montant_annuel string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_salaire/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_salaire_rejected
if(spark.catalog.tableExists("employee.adp_salaire_rejected"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_salaire_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_emploi
spark.sql(""" drop table if exists employee.adp_emploi; """)
spark.sql(""" create table if not exists employee.adp_emploi (
matricule_hr_access string not null,
matricule_wd string,
date_effet_emploi date not null,
date_fin_emploi date,
code_emploi string not null,
libelle_emploi string,
taux_emploi double,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_emploi/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_emploi
if(spark.catalog.tableExists("employee.adp_emploi")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_emploi")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_emploi_rejected
spark.sql(""" drop table if exists employee.adp_emploi_rejected; """)
spark.sql(""" create table if not exists employee.adp_emploi_rejected (
matricule_hr_access string,
matricule_wd string,
date_effet_emploi string,
date_fin_emploi string,
code_emploi string,
libelle_emploi string,
taux_emploi string,
error_log string,
filepath string not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_emploi/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_emploi_rejected
if(spark.catalog.tableExists("employee.adp_emploi_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_emploi_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_tempstravail
spark.sql(""" drop table if exists employee.adp_tempstravail; """)
spark.sql(""" create table if not exists employee.adp_tempstravail (
matricule_hr_access string not null,
matricule_wd string,
date_effet_tps_contractuel date,
date_fin_tps_contractuel date,
type_temps_contractuel string,
libelle_type_temps_contractuel string,
code_modalite_horaire string,
nb_heure_presence_sem double,
nb_heure_presence_mois double,
nb_heure_payes_sem double,
nb_heure_payes_mois double,
nb_jours_travailles_an double,
taux_travail double,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_tempstravail/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_tempstravail
if(spark.catalog.tableExists("employee.adp_tempstravail")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_tempstravail")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_tempstravail_rejected
spark.sql(""" drop table if exists employee.adp_tempstravail_rejected; """)
spark.sql(""" create table if not exists employee.adp_tempstravail_rejected (
matricule_hr_access string,
matricule_wd string,
date_effet_tps_contractuel string,
date_fin_tps_contractuel string,
type_temps_contractuel string,
libelle_type_temps_contractuel string,
code_modalite_horaire string,
nb_heure_presence_sem string,
nb_heure_presence_mois string,
nb_heure_payes_sem string,
nb_heure_payes_mois string,
nb_jours_travailles_an string,
taux_travail string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_tempstravail/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_tempstravail_rejected
if(spark.catalog.tableExists("employee.adp_tempstravail_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_tempstravail_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_etp
spark.sql(""" drop table if exists employee.adp_etp; """)
spark.sql(""" create table if not exists employee.adp_etp (
matricule_hr_access string not null,
matricule_wd string,
date_deb_etp date,
date_fin_etp date,
horaire_affectation string,
etp double,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_etp/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_etp
if(spark.catalog.tableExists("employee.adp_etp")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_etp")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_etp_rejected
spark.sql(""" drop table if exists employee.adp_etp_rejected; """)
spark.sql(""" create table if not exists employee.adp_etp_rejected (
matricule_hr_access string,
matricule_wd string,
date_deb_etp string,
date_fin_etp string,
horaire_affectation string,
etp string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_etp/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_etp_rejected
if(spark.catalog.tableExists("employee.adp_etp_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_etp_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_typeheure
spark.sql(""" drop table if exists employee.adp_typeheure; """)
spark.sql(""" create table if not exists employee.adp_typeheure (
matricule_hr_access string not null,
matricule_wd string,
date_deb_affection_cycle date,
date_fin_affectation_cycle date,
code_affection_cycle string,
libelle_type_heure string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_typeheure/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_typeheure
if(spark.catalog.tableExists("employee.adp_typeheure")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_typeheure")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_typeheure_rejected
spark.sql(""" drop table if exists employee.adp_typeheure_rejected; """)
spark.sql(""" create table if not exists employee.adp_typeheure_rejected (
matricule_hr_access string,
matricule_wd string,
date_deb_affection_cycle string,
date_fin_affectation_cycle string,
code_affection_cycle string,
libelle_type_heure string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_typeheure/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_typeheure_rejected
if(spark.catalog.tableExists("employee.adp_typeheure_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_typeheure_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_enfants
spark.sql(""" drop table if exists employee.adp_enfants; """)
spark.sql(""" create table if not exists employee.adp_enfants (
matricule_hr_access string not null,
matricule_wd string,
numero_ordre string,
date_naissance date,
prenom string,
nom string,
sexe string,
date_deces string,
enfant_a_charge string,
date_deb_prise_en_charge date,
date_fin_prise_en_charge date,
enfant_a_charge_secu string,
date_deb_prise_en_charge_secu date,
date_fin_prise_en_charge_secu date,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_enfants/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_enfants
if(spark.catalog.tableExists("employee.adp_enfants"))// test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_enfants")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_enfants_rejected
spark.sql(""" drop table if exists employee.adp_enfants_rejected; """)
spark.sql(""" create table if not exists employee.adp_enfants_rejected (
matricule_hr_access string,
matricule_wd string,
numero_ordre string,
date_naissance string,
prenom string,
nom string,
sexe string,
date_deces string,
enfant_a_charge string,
date_deb_prise_en_charge string,
date_fin_prise_en_charge string,
enfant_a_charge_secu string,
date_deb_prise_en_charge_secu string,
date_fin_prise_en_charge_secu string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_enfants/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_enfants_rejected
if(spark.catalog.tableExists("employee.adp_enfants_rejected"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_enfants_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_natio_sec
spark.sql(""" drop table if exists employee.adp_natio_sec; """)
spark.sql(""" create table if not exists employee.adp_natio_sec(
matricule_hr_access string not null,
matricule_wd string,
nationalite_secondaire string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_natio_sec/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_natio_sec
if(spark.catalog.tableExists("employee.adp_natio_sec")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_natio_sec")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_natio_sec_rejected
spark.sql(""" drop table if exists employee.adp_natio_sec_rejected; """)
spark.sql(""" create table if not exists employee.adp_natio_sec_rejected(
matricule_hr_access string,
matricule_wd string,
nationalite_secondaire string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee_adp/adp/adp_natio_sec/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_natio_sec_rejected
if(spark.catalog.tableExists("employee.adp_natio_sec_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_natio_sec_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_suspension
spark.sql(""" drop table if exists employee.adp_suspension; """)
spark.sql(""" create table if not exists employee.adp_suspension(
matricule_hr_access string not null,
matricule_wd string,
date_deb_situation date,
date_fin_situation date,
categorie string,
libelle_categorie string,
motif string,
libelle_motif string,
flag_conges string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_suspension/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_suspension
if(spark.catalog.tableExists("employee.adp_suspension")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_suspension")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_suspension_rejected
spark.sql(""" drop table if exists employee.adp_suspension_rejected; """)
spark.sql(""" create table if not exists employee.adp_suspension_rejected(
matricule_hr_access string,
matricule_wd string,
date_deb_situation string,
date_fin_situation string,
categorie string,
libelle_categorie string,
motif string,
libelle_motif string,
flag_conges string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_suspension/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_suspension_rejected
if(spark.catalog.tableExists("employee.adp_suspension_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_suspension_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_carriere
spark.sql(""" drop table if exists employee.adp_carriere; """)
spark.sql(""" create table if not exists employee.adp_carriere(
matricule_hr_access string not null,
matricule_wd string,
date_deb_carriere date,
date_fin_carriere date,
qualification string,
libelle_qualification string,
classification string,
libelle_classification string,
coefficient_base string,
coefficient_spe string,
convention_collective string,
regime_cotis_retraite string,
groupe_couture string,
niveau_couture string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_carriere";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_carriere
if(spark.catalog.tableExists("employee.adp_carriere")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_carriere")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_carriere_rejected
spark.sql(""" drop table if exists employee.adp_carriere_rejected; """)
spark.sql(""" create table if not exists employee.adp_carriere_rejected(
matricule_hr_access string,
matricule_wd string,
date_deb_carriere string,
date_fin_carriere string,
qualification string,
libelle_qualification string,
classification string,
libelle_classification string,
coefficient_base string,
coefficient_spe string,
convention_collective string,
regime_cotis_retraite string,
groupe_couture string,
niveau_couture string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_carriere/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_carriere_rejected
if(spark.catalog.tableExists("employee.adp_carriere_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_carriere_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_cet
spark.sql(""" drop table if exists employee.adp_cet; """)
spark.sql(""" create table if not exists employee.adp_cet(
matricule_hr_access string not null,
matricule_wd string,
date_operation date,
type_operation string,
libelle_type_operation string,
compte_operation string,
libelle_compte string,
jour double,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_cet";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_cet
if(spark.catalog.tableExists("employee.adp_cet")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_cet")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table employee.adp_cet_rejected
spark.sql(""" drop table if exists employee.adp_cet_rejected; """)
spark.sql(""" create table if not exists employee.adp_cet_rejected(
matricule_hr_access string not null,
matricule_wd string,
date_operation string,
type_operation string,
libelle_type_operation string,
compte_operation string,
libelle_compte string,
jour string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/employee/adp/adp_cet/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table employee.adp_cet_rejected
if(spark.catalog.tableExists("employee.adp_cet_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE employee.adp_cet_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.adp_centrecout
spark.sql(""" drop table if exists organization.adp_centrecout; """)
spark.sql(""" 
create table if not exists organization.adp_centrecout (
matricule_hr_access string not null,
matricule_wd string,
date_deb_centre_cout date not null,
date_fin_centre_cout date,
centre_cout string not null,
libelle_centre_cout string,
sous_compte string,
taux_repartition string,
date_deb_etablissement date not null,
date_fin_etablissement date,
code_etablissement string not null,
libelle_etablissement string,
date_deb_societe date not null,
date_fin_societe date,
code_societe string not null,
libelle_societe string,
motif_entree string,
date_deb_org date,
date_fin_org date,
code_direction string not null,
libelle_direction string,
code_departement string not null,
libelle_departement string, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/adp/adp_centrecout";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.adp_centrecout
if(spark.catalog.tableExists("organization.adp_centrecout")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.adp_centrecout")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.adp_centrecout_rejected
spark.sql(""" drop table if exists organization.adp_centrecout_rejected; """)
spark.sql(""" 
create table if not exists organization.adp_centrecout_rejected (
matricule_hr_access string,
matricule_wd string,
date_deb_centre_cout string,
date_fin_centre_cout string,
centre_cout string,
libelle_centre_cout string,
sous_compte string,
taux_repartition string,
date_deb_etablissement string,
date_fin_etablissement string,
code_etablissement string,
libelle_etablissement string,
date_deb_societe string,
date_fin_societe string,
code_societe string,
libelle_societe string,
motif_entree string,
date_deb_org string,
date_fin_org string,
code_direction string,
libelle_direction string,
code_departement string,
libelle_departement string, 
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/adp/adp_centrecout/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.adp_centrecout_rejected
if(spark.catalog.tableExists("organization.adp_centrecout_rejected"))// test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.adp_centrecout_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.adp_ref_centrecout
spark.sql(""" drop table if exists organization.adp_ref_centrecout; """)
spark.sql(""" 
create table if not exists organization.adp_ref_centrecout (
centre_cout string not null,
libelle_centre_cout string,
code_departement string not null,
libelle_departement string,
code_direction string not null,
libelle_direction string,
code_etablissement string not null,
libelle_etablissement string,
code_societe string not null,
libelle_societe string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/adp/adp_ref_centre_cout";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.adp_ref_centre
if(spark.catalog.tableExists("organization.adp_ref_centrecout")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.adp_ref_centrecout")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table organization.adp_ref_centrecout_rejected
spark.sql(""" drop table if exists organization.adp_ref_centrecout_rejected; """)
spark.sql(""" 
create table if not exists organization.adp_ref_centrecout_rejected (
centre_cout string not null,
libelle_centre_cout string,
code_departement string not null,
libelle_departement string,
code_direction string not null,
libelle_direction string,
code_etablissement string not null,
libelle_etablissement string,
code_societe string not null,
libelle_societe string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/organization/adp/adp_ref_centre_cout/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.adp_ref_centrecout_rejected
if(spark.catalog.tableExists("organization.adp_ref_centrecout_rejected"))// test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE organization.adp_ref_centrecout_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.adp_paie
spark.sql(""" drop table if exists pay.adp_paie; """)
spark.sql(""" 
create table if not exists pay.adp_paie(
matricule_hr_access string not null,
matricule_wd string,
period_paie string,
periode_valorisation string,
code_rubr string,
compte_comptable string,
base double,
montant_salarial double,
montant_patronal double,
paiezad string,
num_pac string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file , period_paie)
LOCATION "/mnt/curated_container/pay/adp/adp_paie/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.adp_paie
if(spark.catalog.tableExists("pay.adp_paie"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.adp_paie")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.adp_paie_rejected
spark.sql(""" drop table if exists pay.adp_paie_rejected; """)
spark.sql(""" 
create table if not exists pay.adp_paie_rejected(
matricule_hr_access string not null,
matricule_wd string,
period_paie string,
periode_valorisation string,
code_rubr string,
compte_comptable string,
base string,
montant_salarial string,
montant_patronal string,
paiezad string,
num_pac string,
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file, period_paie)
LOCATION "/mnt/curated_container/pay/adp/adp_paie/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.adp_paie_rejected
if(spark.catalog.tableExists("pay.adp_paie_rejected"))  // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.adp_paie_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.adp_rubr_paie
spark.sql(""" drop table if exists pay.adp_rubr_paie; """)
spark.sql(""" 
create table if not exists pay.adp_rubr_paie(
code_rubr string not null,
libelle_rubr string not null,
flag_salarial string,
flag_debit string,
compte_comptable string, 
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/pay/adp/adp_rubr_paie/";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.adp_rubr_paie
if(spark.catalog.tableExists("pay.adp_rubr_paie")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.adp_rubr_paie")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create parquet table pay.adp_rubr_paie_rejected
spark.sql(""" drop table if exists pay.adp_rubr_paie_rejected; """)
spark.sql(""" 
create table if not exists pay.adp_rubr_paie_rejected(
code_rubr string not null,
libelle_rubr string not null,
flag_salarial string,
flag_debit string,
compte_comptable string, 
error_log string,
filepath string not null,
version int not null,
date_raw_load_file date not null,
filename string not null,
curated_ingested_date timestamp not null,
runid string not null,
year_file int not null,
month_file int not null,
day_file int not null)
USING PARQUET
PARTITIONED BY (date_raw_load_file)
LOCATION "/mnt/curated_container/pay/adp/adp_rubr_paie/rejected";
""")

// COMMAND ----------

// DBTITLE 1,Refresh table pay.adp_rubr_paie_rejected
if(spark.catalog.tableExists("pay.adp_rubr_paie_rejected")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.adp_rubr_paie_rejected")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}