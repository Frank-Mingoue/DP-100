// Databricks notebook source
val export_date = dbutils.widgets.get("export_date");

// COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val df = Seq(export_date).toDF("export_date")
val curDate = df.withColumn("first_day_month",trunc($"export_date", "month"))
                .withColumn("last_day_month",last_day($"export_date"))
                .withColumn("period_paie",date_format($"export_date","yyyyMM"))
                .withColumn("heure_saisi",date_format(current_timestamp(),"HHmmss"))
                
val first_day_month = curDate.select("first_day_month").first().getDate(0)
val last_day_month = curDate.select("last_day_month").first().getDate(0)
val period_paie = curDate.select("period_paie").first().get(0)
val date_saisie = DateTimeFormatter.ofPattern("yyyyMMdd").format(java.time.LocalDate.now())
val heure_saisie = curDate.select("heure_saisi").first().get(0)

// COMMAND ----------

// DBTITLE 1,Read Refined Data
 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

 if(spark.catalog.tableExists("hr.absenteism")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Read Parameters Table
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

val parameters = spark.read.jdbc(jdbcurl,"param_gestor_cartes", connectionproperties).where($"carte" === "40")
                                                                                     .withColumnRenamed("type","type_parametres")

// COMMAND ----------

val bycontract = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)

val df_contract = spark.table("hr.contract")   
                                                .withColumn("rank",rank() over bycontract)
                                                .withColumn("present_in_month",when(($"contract_start_date" <= last_day_month) and (($"contract_end_date" >= first_day_month) or expr("contract_end_date is null") ) ,true).otherwise(false))
                                                .withColumn("employee_id_sub",expr("substring(employee_id, 2, length(employee_id))"))
                                                .withColumn("date_effet",when($"contract_end_date" === "2999-12-31",$"contract_start_date").otherwise(trunc(current_date(), "month")))
                                                .filter(col("rank")==="1")
                                                .filter("present_in_month = true")

// COMMAND ----------

val df_absenteism = spark.table("hr.absenteism")

val join_expr = df_contract.col("france_payroll_id") === df_absenteism.col("employee_hra")

val df_inter = df_contract.join(df_absenteism,join_expr).join(parameters,$"code" === parameters.col("code_gestor") )
                                                      .withColumn("date_effet",when($"contract_end_date" === "2999-12-31",$"contract_start_date").otherwise(trunc(current_date(), "month")))
                                                      .withColumn("heure_incident",when(($"type_parametres" === "jour ou demi") and ($"duration_days" < "1" ),"00050").when(($"type_parametres" === "jour ou demi") and ($"duration_days" === "1" ),"00100").otherwise(expr("concat('0',cast((floor(duration_hours)*1000 + (round(duration_hours,2) - floor(duration_hours))*100) as integer))")))
                                                      .withColumn("code_incident",$"code_hra")
                                                      .selectExpr("substring(employee_id, 2, length(employee_id)) as matricule_wd"
                                                                  ,"dateval as date_debut_pointage"
                                                                  ,"dateval as date_fin_pointage"
                                                                  ,"date_effet"
                                                                  ,"heure_incident"
                                                                  ,"code_incident")
                                                      
display(df_inter)

// COMMAND ----------

val df_carte40 = df_inter.select(concat(lit("806932"),lit("40"), expr("REPEAT(char(160),1)"), $"matricule_wd", expr("REPEAT(char(160),3)"), date_format($"date_debut_pointage","yyyyMMdd"), date_format($"date_fin_pointage","yyyyMMdd"), expr("REPEAT(char(160),18)"), lit("1"), $"heure_incident", lit("1"),  expr("substring(code_incident, 2, length(code_incident))"), expr("REPEAT(char(160),117)"), lit("S"), expr("REPEAT(char(160),9)"),lit(date_saisie), lit(heure_saisie), date_format($"date_effet","yyyyMMdd"), lit(period_paie), expr("REPEAT(char(160),8)"), lit("TT"), expr("REPEAT(char(160),6)"), lit("N"), lit ("E"), expr("REPEAT(char(160),4)")).alias("sortie"))
display(df_carte40)

// COMMAND ----------

// DBTITLE 1,Generate and Save Files
val save_path = "dbfs:/mnt/raw_container/gestor/carte_absentiesm/carte_40" + export_date 

df_carte40.coalesce(1).write.format("text").option("header",false).option("treatEmptyValuesAsNulls","true").option("nullValue", null).save(save_path)


val files = dbutils.fs.ls(save_path).filter(file =>file.name.endsWith(".txt")).toDF.select("name").head.getString(0)
    dbutils.fs.mv(save_path+"/"+files,save_path.split("/").dropRight(1).mkString("/")+"/"+save_path.split("/").last+".txt")
    dbutils.fs.rm(save_path,true)

dbutils.notebook.exit("saved_in_"+save_path+"")