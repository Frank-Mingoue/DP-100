// Databricks notebook source
val export_date = dbutils.widgets.get("export_date");
val timeoutSeconds=0

// COMMAND ----------

// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

var extract_date = LocalDate.parse(export_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
for( i <- 0 to 2){
        println(extract_date)
        var notebook_date = extract_date.toString
        dbutils.notebook.run("/DataInsights/Export/Gestor_Paie/DI_carte_30_annulation_mois", timeoutSeconds, Map("export_date" -> notebook_date))
        extract_date = extract_date.minusMonths(1)
      }