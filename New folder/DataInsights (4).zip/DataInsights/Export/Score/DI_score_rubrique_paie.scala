// Databricks notebook source
val load_date = dbutils.widgets.get("load_date");

// COMMAND ----------

// DBTITLE 1,Include functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set parameters dates for export
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_start_month = date_value.withDayOfMonth(1)
val date_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + ("%02d".format(date_value.getDayOfMonth))
val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))
var time_id = DateTimeFormatter.ofPattern("HHmm").format(java.time.LocalTime.now.plusHours(2))
val year_id = date_value.getYear()
val date_export = DateTimeFormatter.ofPattern("yyyyMMdd").format(java.time.LocalDate.now())

// COMMAND ----------

// DBTITLE 1,Set connection to database
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Read Data
//Dimensions
val df_hr_pay_read = spark.read.jdbc(jdbcurl,"pay.f_pay", connectionproperties).filter($"date_id" === date_id).select("payroll_id").distinct

val bycode_rubr = Window.partitionBy("code_rubrique_paie").orderBy($"record_creation_date".desc, $"record_modification_date".desc,$"compte_comptable".asc)
spark.read.jdbc(jdbcurl,"pay.d_payroll", connectionproperties).select("code_rubrique_paie","libelle_rubrique_paie","compte_comptable","record_creation_date","record_modification_date","payroll_id")
                                                              //filter on existing payroll code for the current month
                                                              .as("d").join(df_hr_pay_read.as("p"),$"d.payroll_id" === $"p.payroll_id")

                                                              .withColumn("is_valid_code_rubr", when(substring($"compte_comptable",0,1) === "6",true))
                                                              .filter($"is_valid_code_rubr" === true)
                                                              .withColumn("rank",rank() over bycode_rubr)
                                                              .filter(col("rank")==="1")
                                                              .createOrReplaceTempView("vw_d_payroll")


// COMMAND ----------

// DBTITLE 1,Query
val query = """ select distinct
                       p.code_rubrique_paie as `ID RUBRIQUE DE PAIE`
                      ,p.libelle_rubrique_paie as DESCRIPTION
                      ,p.compte_comptable as `ID NATURE COMPTABLE`
                    
               from   vw_d_payroll p             
               where  1=1
               and    (p.code_rubrique_paie LIKE '%S' or p.code_rubrique_paie LIKE '%P') 
               and    p.compte_comptable IS NOT NULL 
               
               and    p.compte_comptable NOT LIKE '625%'
               and    p.compte_comptable NOT LIKE '628%'
               and    p.compte_comptable NOT LIKE '671%'
               
 """

// COMMAND ----------

// DBTITLE 1,Get result
val df_results = spark.sql(query)


// COMMAND ----------

// DBTITLE 1,Generate and Save File
val save_path = "dbfs:/mnt/raw_container/score/rubrique_de_paie/" + date_id + "/SCORE_DI_R_rubrique_de_paie_"+month_id+"_"+date_export+time_id
save_df(df_results,save_path)

// COMMAND ----------

// DBTITLE 1,Save file to score_retro folder
val save_path_retro = "dbfs:/mnt/raw_container/score_out/SCORE_DI_R_rubrique_de_paie_"+month_id+"_"+date_export+time_id
save_df(df_results,save_path_retro)

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")
dbutils.notebook.exit("saved_in_"+save_path+"")