// Databricks notebook source
val load_date = dbutils.widgets.get("load_date");

// COMMAND ----------

// DBTITLE 1,Include functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set parameters dates for export
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_start_month = date_value.withDayOfMonth(1)
val date_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + ("%02d".format(date_value.getDayOfMonth))
val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))
var time_id = DateTimeFormatter.ofPattern("HHmm").format(java.time.LocalTime.now.plusHours(2))
val year_id = date_value.getYear()
val date_export = DateTimeFormatter.ofPattern("yyyyMMdd").format(java.time.LocalDate.now())

// COMMAND ----------

// DBTITLE 1,Set connection to database
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Read Data
//Dimensions
spark.read.jdbc(jdbcurl,"staff.d_operational_organization", connectionproperties).select("cost_center_code","top_level","division_detailed","division_consolidated","current_hierarchy")
                                                                                 .where($"current_hierarchy"===1)
                                                                                 .createOrReplaceTempView("vw_d_operational_organization")

spark.read.jdbc(jdbcurl, "dbo.vw_ref_operational_organization", connectionproperties)
                                                                                 .select("direction", "division_detailed", "division_consolidated",
                                                                                  "top_level")       
                                                                                 .createOrReplaceTempView("vw_ref_operational_organization")

//Refined
val bycostcenter = Window.partitionBy("cost_center_code").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_common_ref_organization = spark.table("common.ref_organization").withColumn("rank",rank() over bycostcenter)
                                                                       .filter(col("rank")==="1")
                                                                       .select("cost_center_code","cost_center_label","code_department","label_department","code_direction","label_direction","companycode")
                                                                       .where(
                                                                        $"code_direction" =!= "Firenze Osmannoro" and
                                                                        $"code_direction" =!= "Vittuone Headquarters" and 
                                                                        $"code_direction" =!= "Vittuone Distribution Center" and $"companycode" =!= "0082")
                                                                       .createOrReplaceTempView("vw_common_ref_organization")


// COMMAND ----------

// DBTITLE 1,Query to extract data
val query = """ select   
                       co.cost_center_code AS `CODE CENTRE DE COUT`
                      ,last(co.cost_center_label) AS `CENTRE DE COUT`

                      ,coalesce(last(co.code_department),'Non Affecte') AS `CODE DEPARTEMENT`
                      ,coalesce(last(co.label_department),'Non Affecte') AS DEPARTEMENT

                      ,coalesce(last(co.code_direction),'Non Affecte') AS `CODE DIRECTION`
                      ,coalesce(last(co.label_direction),'Non Affecte') AS DIRECTION

                      ,concat('DDET_',coalesce(last(roo.division_detailed), last(oo.division_detailed), 'Non Affecte')) AS `CODE DIVISION DETAILLEE`
                      ,coalesce(last(roo.division_detailed), last(oo.division_detailed),'Non Affecte') AS `DIVISION DETAILLEE`

                      ,concat('DCON_',coalesce(last(roo.division_consolidated), last(oo.division_consolidated),'Non Affecte')) AS `CODE DIVISION CONSOLIDEE`
                      ,coalesce(last(roo.division_consolidated), last(oo.division_consolidated),'Non Affecte') AS `DIVISION CONSOLIDEE`

                      ,concat('ORGA_',coalesce(last(roo.top_level), last(oo.top_level), 'Non Affecte')) AS `CODE CHANEL FRANCE / VERNEUIL / CHANEL ITALIE MODE`
                      ,coalesce(last(roo.top_level), last(oo.top_level),'Non Affecte') AS `CHANEL FRANCE / VERNEUIL / CHANEL ITALIE MODE`
                      ,last(co.companycode)
               from   vw_common_ref_organization co
                      left join vw_ref_operational_organization roo on co.code_direction = roo.direction
                      left join vw_d_operational_organization oo on co.cost_center_code = oo.cost_center_code
                      
               where 1=1
                 and co.companycode not in ('F40', 'F13', 'F08')
                 and co.code_direction != 'DIR40'
                        
                     
              group by co.cost_center_code
               
                    """             

// COMMAND ----------

// DBTITLE 1,Read Query
val df_results = spark.sql(query)


// COMMAND ----------

// DBTITLE 1,Generate and Save File
// test 
val save_path = "dbfs:/mnt/raw_container/score/cost_center_hr/" + date_id + "/SCORE_DI_R_Cost_center_HR_"+month_id+"_"+date_export+time_id
save_df(df_results,save_path)

// COMMAND ----------

// DBTITLE 1,Save file to score_retro folder
// test 
val save_path_retro = "dbfs:/mnt/raw_container/score_out/SCORE_DI_R_Cost_center_HR_"+month_id+"_"+date_export+time_id
save_df(df_results,save_path_retro)

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")
dbutils.notebook.exit("saved_in_"+save_path+"")