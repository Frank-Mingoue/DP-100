// Databricks notebook source
val load_date = dbutils.widgets.get("load_date");

// COMMAND ----------

// DBTITLE 1,Include functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set parameters dates for export
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_start_month = date_value.withDayOfMonth(1)
val date_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + ("%02d".format(date_value.getDayOfMonth))
val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))
var time_id = DateTimeFormatter.ofPattern("HHmm").format(java.time.LocalTime.now.plusHours(2))
val year_id = date_value.getYear()
val date_export = DateTimeFormatter.ofPattern("yyyyMMdd").format(java.time.LocalDate.now())

// COMMAND ----------

// DBTITLE 1,Set connection to database
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Read Data
//Dimensions
spark.read.jdbc(jdbcurl,"staff.d_operational_organization", connectionproperties).select("cost_center_code","top_level")
                                                                                 .where($"current_hierarchy"===1)         
                                                                                 .createOrReplaceTempView("vw_d_operational_organization")                                                
                                                                            
spark.read.jdbc(jdbcurl, "dbo.vw_ref_legal_organization", connectionproperties).select("source_value", "company","top_level")
                                                                               .createOrReplaceTempView("vw_ref_legal_organization")

//Refined

val bycostcenter = Window.partitionBy("cost_center_code").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_common_ref_organization = spark.table("common.ref_organization").withColumn("rank",rank() over bycostcenter)
                                                                       .filter(col("rank")==="1")
                                                                       .where(
                                                                              $"code_direction" =!= "Firenze Osmannoro" and
                                                                              $"code_direction" =!= "Vittuone Headquarters" and 
                                                                              $"code_direction" =!= "Vittuone Distribution Center" and $"companycode" =!= "0082")

                                                                      // Manual correction: missing establishment and establishment code information for 1380DIGE and X320C312 cost centers
                                                                      .withColumn("code_establishment", when(col("cost_center_code") === "1380DIGE", "FPFF").otherwise(col("code_establishment")))
                                                                      .withColumn("label_establishment", when(col("cost_center_code") === "1380DIGE", "PARAFFECTION DUPHOT").otherwise(col("label_establishment")))
                                                                      .withColumn("code_establishment", when(col("cost_center_code") === "X320C312", "FCHX").otherwise(col("code_establishment")))
                                                                      .withColumn("label_establishment", when(col("cost_center_code") === "X320C312", "CHANEL VENDOME").otherwise(col("label_establishment")))
                                                                      .createOrReplaceTempView("vw_common_ref_organization")
                                                                     

//transco
spark.read.jdbc(jdbcurl,"dbo.param_transco_ref",connectionproperties).na.fill("Nothing")
                                                                     .withColumnRenamed("axe","field_di")
                                                                     .createOrReplaceTempView("vw_dbo_param_transco_ref")

// COMMAND ----------

// DBTITLE 1,Query
val query = """ select                     
                       co.cost_center_code as `CODE CENTRE DE COUT`

                      ,coalesce(last(co.code_establishment),'Non Affecté') as `CODE ETABLISSEMENT`
                      ,coalesce(last(co.label_establishment),'Non Affecté') as ETABLISSEMENT

                      ,coalesce(last(co.companycode),'Non Affecté') as `CODE SOCIETE`
                      ,coalesce(last(rlo.company), last(co.company),'Non Affecté') as SOCIETE

                      ,coalesce(last(rlo.top_level),'Non Affecté') as `CODE CHANEL FRANCE/VERNEUIL/CHANEL ITALIE MODE`
                      ,coalesce(last(rlo.top_level),'Non Affecté') as `CHANEL FRANCE/VERNEUIL/CHANEL ITALIE MODE`
                      
                    
                from  vw_common_ref_organization co 
                      left join vw_ref_legal_organization rlo on (lower(rlo.company) = lower(co.company) or lower(co.company) = lower(rlo.source_value))
                      
                where 1=1
                  and co.companycode not in ('F40', 'F13', 'F08')
                  and lower(coalesce(rlo.company, co.company)) not in ('paraffection','ceries')
                                                                
               group by co.cost_center_code
               
                    """             

// COMMAND ----------

// DBTITLE 1,Get Result
val df_results = spark.sql(query)

// COMMAND ----------

// DBTITLE 1,Transo Fields
val df_results_transco= df_results.select("CODE CENTRE DE COUT","CODE ETABLISSEMENT","ETABLISSEMENT","CODE SOCIETE","SOCIETE","CODE CHANEL FRANCE/VERNEUIL/CHANEL ITALIE MODE","CHANEL FRANCE/VERNEUIL/CHANEL ITALIE MODE")


// COMMAND ----------

// DBTITLE 1,Generate and Save File
val save_path = "dbfs:/mnt/raw_container/score/etablissement_hr/" + date_id + "/SCORE_DI_R_etablissement_hr_"+month_id+"_"+date_export+time_id
save_df(df_results_transco,save_path)

// COMMAND ----------

// DBTITLE 1,Save file to score_retro folder
val save_path_retro = "dbfs:/mnt/raw_container/score_out/SCORE_DI_R_etablissement_hr_"+month_id+"_"+date_export+time_id
save_df(df_results_transco,save_path_retro)

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")
dbutils.notebook.exit("saved_in_"+save_path+"")