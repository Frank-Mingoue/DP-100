// Databricks notebook source
// DBTITLE 1,Create load date widget
val load_date = dbutils.widgets.get("load_date");

// COMMAND ----------

// DBTITLE 1,Set configuration
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Include functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set parameters dates for export
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val date_month_minus = date_value.minusMonths(1)
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_start_month = date_value.withDayOfMonth(1)
val last_day_previous_month = date_month_minus.withDayOfMonth(date_month_minus.getMonth().length(date_month_minus.isLeapYear()));
val date_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + ("%02d".format(date_value.getDayOfMonth))
val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))
var time_id = DateTimeFormatter.ofPattern("HHmm").format(java.time.LocalTime.now.plusHours(2))
val previous_month_id = date_month_minus.getYear() + ("%02d".format(date_month_minus.getMonth.getValue()))
val previous_date_id = date_month_minus.getYear() + ("%02d".format(date_month_minus.getMonth.getValue())) + ("%02d".format(last_day_previous_month.getDayOfMonth))

val year_id = date_value.getYear()
val date_export = DateTimeFormatter.ofPattern("yyyyMMdd").format(java.time.LocalDate.now())

// COMMAND ----------

// DBTITLE 1,Set connection to database
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Read Dimensions Data
spark.read.jdbc(jdbcurl,"staff.d_employee", connectionproperties).select("employee_id","matricule_workday","matricule_hra","last_name","first_name","gender","birth_date", "employee_code")
                                                                 .createOrReplaceTempView("vw_d_employee")

spark.read.jdbc(jdbcurl,"staff.d_info_dates", connectionproperties).select("info_dates_id","contract_start_date","contract_end_date","hire_date")
                                                                    .withColumn("contract_end_date_2",concat(split($"contract_end_date","-").getItem(0),
                                                                                                 split($"contract_end_date","-").getItem(1)))
                                                                 
                                                                    .createOrReplaceTempView("vw_d_info_dates")
spark.read.jdbc(jdbcurl, "staff.d_contract_type", connectionproperties).select("contract_type_id", "contract_type_code","precarity","contract_type","contract_type_detailed"
                                                                               ,"worker_type", "collective_agreement_reference_label", "collective_agreement_group", 
                                                                               "collective_agreement_level","classification_collective_agreement","contract_nature","contract_nature_label")
                                                                        .createOrReplaceTempView("vw_d_contract_type")
spark.read.jdbc(jdbcurl,"staff.d_operational_organization", connectionproperties).select("operational_organization_id","cost_center_code","top_level")
                                                                    .where($"top_level" === "CHANEL FRANCE" or $"top_level"==="VERNEUIL")
                                                                    .createOrReplaceTempView("vw_d_operational_organization")
spark.read.jdbc(jdbcurl,"staff.d_csp", connectionproperties).select("csp_id","professional_category_name","professional_category_reference")
                                                                    .createOrReplaceTempView("vw_d_csp")
spark.read.jdbc(jdbcurl,"staff.d_worker_rate", connectionproperties).select("worker_rate_id","fte","paidfte")
                                                                    .createOrReplaceTempView("vw_d_worker_rate")
spark.read.jdbc(jdbcurl,"staff.d_seniority_company", connectionproperties).select("seniority_company_id","range_seniority_company_age")
                                                                    .createOrReplaceTempView("vw_d_seniority_company")
spark.read.jdbc(jdbcurl,"staff.d_job_architecture", connectionproperties).select("job_architecture_id","job_title","grade_label","job_profile_reference")
                                                                    .createOrReplaceTempView("vw_d_job_architecture")
spark.read.jdbc(jdbcurl,"staff.d_location", connectionproperties).select("location_id","location","location_type", "location_reference")
                                                                    .createOrReplaceTempView("vw_d_location")
spark.read.jdbc(jdbcurl, "dbo.d_date", connectionproperties).filter(col("month_id") === lit(month_id)).createOrReplaceTempView("vw_d_date")

//transco
spark.read.jdbc(jdbcurl, "dbo.param_transco_ref",connectionproperties).na.fill("Nothing").createOrReplaceTempView("vw_dbo_param_transco_ref")


// COMMAND ----------

// DBTITLE 1,Read Facts Data
//Facts
val byemployee = Window.partitionBy("employee_id").orderBy($"date_id".desc)
spark.read.jdbc(jdbcurl,"staff.f_staff_monthly", connectionproperties).select("employee_id","info_dates_id","contract_type_id","operational_organization_id","csp_id",
                                                                               "worker_rate_id","seniority_company_id","job_architecture_id","location_id","date_id","effectif_etp_contractuel")
                                                                      .where($"date_id"===date_id || $"date_id"===previous_date_id)
                                                                      .filter("effectif_etp_contractuel>0")
                                                                      .withColumn("rank", rank() over byemployee)
                                                                      .filter(col("rank") === 1)
                                                                      .distinct
                                                                      .createOrReplaceTempView("vw_f_staff")



spark.read.jdbc(jdbcurl,"staff.f_staff", connectionproperties).select("employee_id","info_dates_id","contract_type_id","operational_organization_id","csp_id",
                                                                               "worker_rate_id","seniority_company_id","job_architecture_id","location_id","date_id","effectif_etp_contractuel")
                                                                      .where($"date_id"===date_id || $"date_id"===previous_date_id)
                                                                      .filter("effectif_etp_contractuel>0")
                                                                      .withColumn("rank", rank() over byemployee)
                                                                      .filter(col("rank") === 1)
                                                                      .distinct
                                                                      .createOrReplaceTempView("vw_f_staff_current")


spark.read.jdbc(jdbcurl,"pay.f_pay_monthly", connectionproperties).select("employee_id","info_dates_id","contract_type_id","operational_organization_id","csp_id",
                                                                               "worker_rate_id","seniority_company_id","job_architecture_id","location_id","date_id","annual_contractual_pay_amount","bonus_target","foreign_travel_indemnity_amount","payroll_amount")
                                                                      .where($"date_id"===date_id && ($"payroll_amount_all".isNotNull))
                                                                      .distinct
                                                                      .withColumn("rank", rank() over byemployee)
                                                                      .filter(col("rank") === 1)
                                                                      .createOrReplaceTempView("vw_f_pay")


spark.read.jdbc(jdbcurl,"pay.f_compensation_monthly", connectionproperties).select("employee_id","info_dates_id","contract_type_id","operational_organization_id","csp_id",
                                                                               "worker_rate_id","seniority_company_id","job_architecture_id","location_id","date_id","annual_contractual_pay_amount","bonus_target","foreign_travel_indemnity_amount")
                                                                      .where($"date_id"===date_id)
                                                                      .distinct
                                                                      .withColumn("rank", rank() over byemployee)
                                                                      .filter(col("rank") === 1)
                                                                      .createOrReplaceTempView("vw_f_compensation")
//Dimensions


// COMMAND ----------

// DBTITLE 1,Get Data For Commercial Bonus
val byCompensationChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date_valid".desc)
val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date","effective_job_change_date","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)

val df_effective_change_valid = spark.table("hr.contract").filter($"prime_co_percent".isNotNull or $"prime_exp_percent".isNotNull)
                                                          .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                          .withColumn("effective_compensation_change_date_valid", when($"effective_compensation_change_date" > lit(date_end_month),null).otherwise($"effective_compensation_change_date"))
                                                          .withColumn("effective_compensation_change_date_valid_last", first($"effective_compensation_change_date").over(byCompensationChangeDateLast))
                                                          .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date_valid".isNotNull,$"effective_compensation_change_date_valid")
                                                                                                           .when($"effective_compensation_change_date_valid_last".isNull, $"contract_start_date")
                                                                                                           .otherwise($"effective_compensation_change_date_valid_last"))  

                                                          .withColumn("rank_month",rank() over bycontract_month)
                                                          .filter(col("rank_month")==="1")  
                                                          .filter("""date_format(contract_start_date,'yyyyMM') = '""" + month_id + """' or 
                                                                      date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                                      (date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                                  )
                                                         .select("employee_code",
                                                                 "employee_id",
                                                                 "france_payroll_id",
                                                                 "contract_start_date",
                                                                 "contract_end_date",
                                                                 "effective_compensation_change_date").distinct

val bycontract_compensation_month = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val df_contract_effective_compensation_change_date_read =spark.table("hr.contract").filter($"prime_co_percent".isNotNull or $"prime_exp_percent".isNotNull)
                                                                                   .filter("""contract_start_date <= '""" + date_end_month + """'""")    
                                                                                   .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                                                   .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date".isNotNull,$"effective_compensation_change_date").otherwise($"contract_start_date"))                                         
                                                                                   .filter("""effective_compensation_change_date <= '""" + date_end_month + """'""")   
                                                                                   .withColumn("rank_month",rank() over bycontract_compensation_month)
                                                                                   .filter(col("rank_month")==="1")  
                                                                                   .distinct

val df_contract_join = df_effective_change_valid.as("e")
                                        .join(df_contract_effective_compensation_change_date_read.as("o"), $"e.employee_code" === $"o.employee_code" && $"e.effective_compensation_change_date" === $"o.effective_compensation_change_date", "inner")
                                        .selectExpr(
                                                "e.employee_code"
                                               ,"e.employee_id"
                                               ,"e.france_payroll_id"
                                               ,"e.contract_start_date"
                                               ,"e.contract_end_date"
                                               ,"o.prime_co_percent as prime_co_percent"
                                               ,"o.prime_exp_percent as prime_exp_percent"
                                               ,"e.effective_compensation_change_date"
                                          )

                                          .distinct

df_contract_join.createOrReplaceTempView("vw_contract_bonus_com") 


// COMMAND ----------

// DBTITLE 1,Query Staff Current
val query_staff = """ Select distinct
                     CASE WHEN e.matricule_workday IS NULL THEN e.matricule_hra ELSE e.matricule_workday END as `MATRICULE WD`
                    ,e.matricule_hra as `MATRICULE HRA`
                    ,e.last_name as NOM
                    ,e.first_name as PRENOM
                    ,e.birth_date as `DATE DE NAISSANCE`
                    ,f.effectif_etp_contractuel as ETP_CONTRACTUEL
                    ,coalesce(transco1.di_value, e.gender) as GENRE
                    ,date_format(i.contract_start_date, 'yyyy-MM-dd') as `DATE DEBUT DE CONTRAT`
                    ,date_format(i.contract_end_date, 'yyyy-MM-dd') as `DATE FIN DE CONTRAT` 
                    ,date_format(i.hire_date, 'yyyy-MM-dd') as `DATE ANCIENNETE CHANEL`
                    
                    ,coalesce(transco4.di_value,c.collective_agreement_reference_label,'NC' ) as `CONVENTION COLLECTIVE`
                    ,case when c.classification_collective_agreement in ('0', '0000000', '000') then 'NC' else coalesce(c.classification_collective_agreement, 'NC') end as `CLASSIFICATION CONVENTION COLLECTIVE`
                    ,coalesce(c.contract_nature, transco.di_value, 'NC') as `NATURE DE CONTRAT`
                    
                    ,coalesce(o.cost_center_code, 'NC') as `CODE CENTRE DE COUT`
                    
                    ,replace(coalesce(csp.professional_category_reference, transco2.di_value, 'NC'), 'Autre statut', 'AUT') as `CSP DETAILLEE`
                                        
                    ,replace(round(w.fte,2), '.', ',') as `TAUX DE TRAVAIL CONTRACTUEL`
                    ,case when w.paidfte = 0 then null else replace(round(w.paidfte,2), '.', ',') end as `TAUX DE TRAVAIL PAYE`
                    
                    ,replace(round(s.range_seniority_company_age/365.25,2), '.', ',') as ANCIENNETE
                    
                    ,coalesce(j.job_title, 'NC') as POSTE
                    ,coalesce(j.job_profile_reference, 'NC') as `CODE PROFIL EMPLOI`
                    ,coalesce(j.grade_label, 'NC') as GRADE
                    
                    ,coalesce(l.location_reference, 'NC') as `CODE SITE`
                    ,coalesce(l.location , 'NC') as SITE
                    ,coalesce(transco3.di_value,l.location_type, 'NC') as `TYPE DE SITE`
                    
                    ,replace(round(p.annual_contractual_pay_amount,2), '.', ',') as `SALAIRE CONTRACTUEL ANNUEL`
                    ,replace(round(p.foreign_travel_indemnity_amount,2), '.', ',') as `INDEMNITES ETRANGER THEORIQUES`
                    ,replace(round(p.bonus_target,7), '.', ',') as `POURCENTAGE DE VARIABLE INDIVIDUEL THEORIQUE` 
                    
                    ,case when coalesce(prime_co_percent, 0) + coalesce(prime_co_percent, 0) = 0 then '0,0000000' else replace(round((coalesce(prime_co_percent, 0.0) + coalesce(prime_co_percent, 0.0)),7), ".", ",") end as `PRIMES COMMERCIALES`
                    
                    ,e.employee_code
                    ,rank() over (partition by e.employee_code order by  f.date_id desc) as rank
                 
                    from vw_f_staff f                                      
                    left join vw_d_employee e on f.employee_id = e.employee_id
                    left join (vw_f_staff_current fc left join vw_d_employee e3 on fc.employee_id = e3.employee_id) sc
                            on f.date_id = sc.date_id and e.employee_code = sc.employee_code    
                    
                    left join (vw_f_compensation pa left join vw_d_employee e2 on pa.employee_id = e2.employee_id) as p
                              on f.date_id = p.date_id and e.employee_code = p.employee_code    
                              
                    
                    
                    left join vw_d_info_dates i on coalesce(sc.info_dates_id, f.info_dates_id) = i.info_dates_id
                    left join vw_d_contract_type c on f.contract_type_id = c.contract_type_id
                    left join vw_d_operational_organization o on f.operational_organization_id = o.operational_organization_id
                    left join vw_d_csp csp on f.csp_id = csp.csp_id
                    left join vw_d_worker_rate w on f.worker_rate_id = w.worker_rate_id
                    left join vw_d_seniority_company s on f.seniority_company_id = s.seniority_company_id
                    left join vw_d_job_architecture j on f.job_architecture_id = j.job_architecture_id
                    left join vw_d_location l on f.location_id = l.location_id
                    left join vw_dbo_param_transco_ref transco on ((lower(c.contract_nature_label) = lower(transco.workday_value)
                                                                or lower(c.contract_nature_label) = lower(transco.hra_value)
                                                                or lower(c.contract_nature_label) = lower(transco.sap_value))
                                                                and (transco.axe = 'NATURE_DE_CONTRAT'))
                                                                
                    left join vw_dbo_param_transco_ref transco4 on ((lower(c.collective_agreement_reference_label) = lower(transco4.workday_value)
                                                                or lower(c.collective_agreement_reference_label) = lower(transco4.hra_value)
                                                                or lower(c.collective_agreement_reference_label) = lower(transco4.sap_value))
                                                                and (transco4.axe = 'CONVENTION_COLLECTIVE'))
                                                                
                    left join vw_dbo_param_transco_ref transco1 on ((lower(e.gender) = lower(transco1.workday_value)
                                                                or lower(e.gender) = lower(transco1.hra_value)
                                                                or lower(e.gender) = lower(transco1.sap_value))
                                                                and (transco1.axe = 'GENRE'))
                                                                
                    left join vw_dbo_param_transco_ref transco2 on ((lower(csp.professional_category_name) = lower(transco2.workday_value)
                                                                or lower(csp.professional_category_name) = lower(transco2.hra_value)
                                                                or lower(csp.professional_category_name) = lower(transco2.sap_value))
                                                                and (transco2.axe = 'QUALIFICATION'))
                                                                
                    left join vw_dbo_param_transco_ref transco3 on ((lower(l.location_type) = lower(transco3.workday_value)
                                                                or lower(l.location_type) = lower(transco3.hra_value)
                                                                or lower(l.location_type) = lower(transco3.sap_value))
                                                                and (transco3.axe = 'TYPE_DE_SITE'))
            
                   
                   left join vw_contract_bonus_com  b on e.employee_code = b.employee_code
                   
                   where e.matricule_hra is not null 
                   
                  """

// COMMAND ----------

// DBTITLE 1,Get Staff Results Current Month
val df_results_staff = spark.sql(query_staff).filter(col("rank") === 1)
df_results_staff.createOrReplaceTempView("vw_df_results_staff")


// COMMAND ----------

// DBTITLE 1,Query Pay by Excluding Employee inside Staff
val query_pay = """ Select distinct
                     CASE WHEN e.matricule_workday IS NULL THEN e.matricule_hra ELSE e.matricule_workday END as `MATRICULE WD`
                    ,e.matricule_hra as `MATRICULE HRA`
                    ,e.last_name as NOM
                    ,e.first_name as PRENOM
                    ,e.birth_date as `DATE DE NAISSANCE`
                    ,NULL as ETP_CONTRACTUEL
                    ,coalesce(transco1.di_value, e.gender) as GENRE
                    ,date_format(i.contract_start_date, 'yyyy-MM-dd') as `DATE DEBUT DE CONTRAT`
                    ,date_format(i.contract_end_date, 'yyyy-MM-dd') as `DATE FIN DE CONTRAT` 
                    ,date_format(i.hire_date, 'yyyy-MM-dd') as `DATE ANCIENNETE CHANEL`
                    
                    ,coalesce(transco4.di_value,c.collective_agreement_reference_label,'NC' ) as `CONVENTION COLLECTIVE`
                    ,case when c.classification_collective_agreement in ('0', '0000000', '000') then 'NC' else coalesce(c.classification_collective_agreement, 'NC') end as `CLASSIFICATION CONVENTION COLLECTIVE`
                    ,coalesce(c.contract_nature, transco.di_value, 'NC') as `NATURE DE CONTRAT`
                    
                    ,coalesce(o.cost_center_code, 'NC') as `CODE CENTRE DE COUT`
                    
                    ,replace(coalesce(csp.professional_category_reference, transco2.di_value, 'NC'), 'Autre statut', 'AUT') as `CSP DETAILLEE`
                                      
                    
                    ,replace(round(w.fte,2), '.', ',') as `TAUX DE TRAVAIL CONTRACTUEL`
                    ,case when w.paidfte = 0 then null else replace(round(w.paidfte,2), '.', ',') end as `TAUX DE TRAVAIL PAYE`
                    
                    ,replace(round(s.range_seniority_company_age/365.25,2), '.', ',') as ANCIENNETE
                    
                    ,coalesce(j.job_title, 'NC') as POSTE
                    ,coalesce(j.job_profile_reference, 'NC') as `CODE PROFIL EMPLOI`
                    ,coalesce(j.grade_label, 'NC') as GRADE
                    
                    ,coalesce(l.location_reference, 'NC') as `CODE SITE`
                    ,coalesce(l.location , 'NC') as SITE
                    ,coalesce(transco3.di_value,l.location_type, 'NC') as `TYPE DE SITE`
                    
                    ,replace(round(f.annual_contractual_pay_amount,2), '.', ',') as `SALAIRE CONTRACTUEL ANNUEL`
                    ,replace(round(f.foreign_travel_indemnity_amount,2), '.', ',') as `INDEMNITES ETRANGER THEORIQUES`
                    ,replace(round(f.bonus_target,2), '.', ',') as `POURCENTAGE DE VARIABLE INDIVIDUEL THEORIQUE` 
                    
                    ,case when coalesce(prime_co_percent, 0) + coalesce(prime_co_percent, 0) = 0 then '0,0000000' else replace(round((coalesce(prime_co_percent, 0.0) + coalesce(prime_co_percent, 0.0)),7), ".", ",") end as `PRIMES COMMERCIALES`
                    
                    ,e.employee_code
                    ,rank() over (partition by e.employee_code order by  f.date_id desc) as rank
                    
                    from vw_f_pay f                                      
                    left join vw_d_employee e on f.employee_id = e.employee_id           
                    
                    left join vw_df_results_staff st on st.employee_code = e.employee_code
                    
                    left join vw_d_info_dates i on f.info_dates_id = i.info_dates_id
                    left join vw_d_contract_type c on f.contract_type_id = c.contract_type_id
                    left join vw_d_operational_organization o on f.operational_organization_id = o.operational_organization_id
                    left join vw_d_csp csp on f.csp_id = csp.csp_id
                    left join vw_d_worker_rate w on f.worker_rate_id = w.worker_rate_id
                    left join vw_d_seniority_company s on f.seniority_company_id = s.seniority_company_id
                    left join vw_d_job_architecture j on f.job_architecture_id = j.job_architecture_id
                    left join vw_d_location l on f.location_id = l.location_id
                    left join vw_dbo_param_transco_ref transco on ((lower(c.contract_nature_label) = lower(transco.workday_value)
                                                                or lower(c.contract_nature_label) = lower(transco.hra_value)
                                                                or lower(c.contract_nature_label) = lower(transco.sap_value))
                                                                and (transco.axe = 'NATURE_DE_CONTRAT'))
                                                                
                    left join vw_dbo_param_transco_ref transco4 on ((lower(c.collective_agreement_reference_label) = lower(transco4.workday_value)
                                                                or lower(c.collective_agreement_reference_label) = lower(transco4.hra_value)
                                                                or lower(c.collective_agreement_reference_label) = lower(transco4.sap_value))
                                                                and (transco4.axe = 'CONVENTION_COLLECTIVE'))
                                                                
                    left join vw_dbo_param_transco_ref transco1 on ((lower(e.gender) = lower(transco1.workday_value)
                                                                or lower(e.gender) = lower(transco1.hra_value)
                                                                or lower(e.gender) = lower(transco1.sap_value))
                                                                and (transco1.axe = 'GENRE'))
                                                                
                    left join vw_dbo_param_transco_ref transco2 on ((lower(csp.professional_category_name) = lower(transco2.workday_value)
                                                                or lower(csp.professional_category_name) = lower(transco2.hra_value)
                                                                or lower(csp.professional_category_name) = lower(transco2.sap_value))
                                                                and (transco2.axe = 'QUALIFICATION'))
                                                                
                    left join vw_dbo_param_transco_ref transco3 on ((lower(l.location_type) = lower(transco3.workday_value)
                                                                or lower(l.location_type) = lower(transco3.hra_value)
                                                                or lower(l.location_type) = lower(transco3.sap_value))
                                                                and (transco3.axe = 'TYPE_DE_SITE'))
            
                   
                   left join vw_contract_bonus_com  b on e.employee_code = b.employee_code
                   
                   where 1=1
                     and e.matricule_hra is not null 
                     and st.employee_code is null 
                   
                  """

// COMMAND ----------

// DBTITLE 1,Get Pay Results
val df_results_pay = spark.sql(query_pay)

// COMMAND ----------

// DBTITLE 1,Union between Staff and Pay
val df_results = df_results_staff.union(df_results_pay).distinct

// COMMAND ----------

// DBTITLE 1,Transo Fields
val df_results_transco= df_results.select("MATRICULE WD","MATRICULE HRA","NOM","PRENOM","GENRE","DATE DEBUT DE CONTRAT","DATE FIN DE CONTRAT",
                                                           "DATE DE NAISSANCE","NATURE DE CONTRAT","CODE CENTRE DE COUT","CONVENTION COLLECTIVE"
                                                            ,"CLASSIFICATION CONVENTION COLLECTIVE","CSP DETAILLEE","TAUX DE TRAVAIL CONTRACTUEL",
                                                           "TAUX DE TRAVAIL PAYE","DATE ANCIENNETE CHANEL","ANCIENNETE","SALAIRE CONTRACTUEL ANNUEL",
                                                           "INDEMNITES ETRANGER THEORIQUES","POURCENTAGE DE VARIABLE INDIVIDUEL THEORIQUE","CODE PROFIL EMPLOI","POSTE","GRADE",
                                                           "CODE SITE","SITE","TYPE DE SITE","PRIMES COMMERCIALES")

// COMMAND ----------

// DBTITLE 1,Generate and Save File
val save_path = "dbfs:/mnt/raw_container/score/employe/" + date_export + "/" + year_id + "/SCORE_DI_employe_"+month_id+"_"+date_export+time_id
save_df(df_results_transco,save_path)

// COMMAND ----------

// DBTITLE 1,Save file to score_retro folder
val save_path_retro = "dbfs:/mnt/raw_container/score_out/SCORE_DI_employe_"+month_id+"_"+date_export+time_id
save_df(df_results_transco,save_path_retro)

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")
dbutils.notebook.exit("saved_in_"+save_path+"")