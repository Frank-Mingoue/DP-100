// Databricks notebook source
// DBTITLE 1,Create load date widget
val load_date = dbutils.widgets.get("load_date");

// COMMAND ----------

// DBTITLE 1,Include functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set configuration
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Set parameters dates for export

val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_start_month = date_value.withDayOfMonth(1)
val date_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + ("%02d".format(date_value.getDayOfMonth))
val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))
var time_id = DateTimeFormatter.ofPattern("HHmm").format(java.time.LocalTime.now.plusHours(2))
val date_id_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth()).toString.replace("-","")
val date_id_start_month = date_value.withDayOfMonth(1).toString.replace("-","")

val year_id = date_value.getYear()
val date_export = DateTimeFormatter.ofPattern("yyyyMMdd").format(java.time.LocalDate.now())

// COMMAND ----------

// DBTITLE 1,Set connection to database
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Read Data
//Dimensions
val df_emp = spark.read.jdbc(jdbcurl,"staff.d_employee", connectionproperties).select("matricule_workday", "matricule_hra", "employee_id")
df_emp.createOrReplaceTempView("vw_d_employee")

spark.read.jdbc(jdbcurl,"dbo.d_date", connectionproperties).select("date_id","month_id")
                                                                      .createOrReplaceTempView("vw_d_date")

//facts
val byemployee = Window.partitionBy("matricule_workday","matricule_hra").orderBy($"date_id".desc)
spark.read.jdbc(jdbcurl,"staff.f_staff_monthly", connectionproperties).select("effectif","effectif_etp_contractuel","effectif_etp_productive","employee_id","date_id").as("f")
                                                                      .join(df_emp.as("e"),$"f.employee_id" === $"e.employee_id")
                                                                      .filter(col("date_id") >= date_id_start_month and col("date_id") <= date_id_end_month)
                                                                        .filter("effectif_etp_contractuel>0")
                                                                      .withColumn("rank", rank() over byemployee)
                                                                      .filter(col("rank") === 1)
                                                                      .select("effectif","effectif_etp_contractuel","effectif_etp_productive","f.employee_id","date_id")
                                                                      .createOrReplaceTempView("vw_f_staff_monthly")



// COMMAND ----------

// DBTITLE 1,Query
val query = """ Select distinct
                       d.month_id as PERIODE
                      ,coalesce(e.matricule_workday, e.matricule_hra) as `MATRICULE WD`                        
                      ,sm.effectif as `EFFECTIF TETE`
                      ,case when sm.effectif_etp_contractuel = 0 then '0,0000000' else replace(round((sm.effectif_etp_contractuel/100),7), '.', ',') end as `ETP CONTRACTUEL`
                      ,case when sm.effectif_etp_productive = 0 then '0,0000000' else replace(round((sm.effectif_etp_productive/100),7), '.', ',') end as `ETP PRODUCTIVE`
                      ,case when (sm.effectif_etp_contractuel - sm.effectif_etp_productive) = 0 then '0,0000000' else replace(round((sm.effectif_etp_contractuel - sm.effectif_etp_productive)/100,7), '.', ',') end as `ETP ABSENCE`
                     
                from  vw_f_staff_monthly sm             
                      left join vw_d_date d on sm.date_id = d.date_id
                      left join vw_d_employee e on sm.employee_id = e.employee_id
                where 1=1
                  and e.matricule_hra is not null   
                  
                  """
                    

// COMMAND ----------

// DBTITLE 1,Get Result
val df_results = spark.sql(query)

// COMMAND ----------

// DBTITLE 1,Generate and Save File
val save_path = "dbfs:/mnt/raw_container/score/effectif/" + date_export + "/" + year_id + "/SCORE_DI_effectif_"+month_id+"_"+date_export+time_id
save_df(df_results,save_path)

// COMMAND ----------

// DBTITLE 1,Save file to score_retro folder
val save_path_retro = "dbfs:/mnt/raw_container/score_out/SCORE_DI_effectif_"+month_id+"_"+date_export+time_id
save_df(df_results,save_path_retro)

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")
dbutils.notebook.exit("saved_in_"+save_path+"")