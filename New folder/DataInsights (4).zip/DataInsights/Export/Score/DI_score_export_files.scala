// Databricks notebook source
// DBTITLE 1,Get Parameters
val flux = dbutils.widgets.get("flux");
val start_date = dbutils.widgets.get("start_date");
val limit_date = dbutils.widgets.get("limit_date");
val filename = dbutils.widgets.get("filename").split(",").toList;

// COMMAND ----------

// DBTITLE 1,Include functions
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

// DBTITLE 1,Set Connection to database
val connection = getSQLconnection()
val stmt = connection.createStatement()
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Script to generate historic files
//- loop historique
if(flux == "historique"){
    //- loop score
  var filename_lower = filename.map(a => a.toLowerCase())
  var timeoutSeconds=0
  
     /*******************facts data********************/ 
  if(filename_lower.contains("all") | filename_lower.contains("effectif")) //Staff
  {
      var intro_date = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
      intro_date = intro_date.withDayOfMonth(intro_date.getMonth().length(intro_date.isLeapYear()))
                                         
      while (intro_date.toString <= limit_date) 
      {
        dbutils.notebook.run("/DataInsights/Export/Score/DI_score_effectif", timeoutSeconds, Map("load_date" -> intro_date.toString)) //Staff
        intro_date = intro_date.plusMonths(1)
        intro_date = intro_date.withDayOfMonth(intro_date.getMonth().length(intro_date.isLeapYear()))
      }
      
  }
    
  if(filename_lower.contains("all") | filename_lower.contains("paie"))
  {
      var intro_date = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
      intro_date = intro_date.withDayOfMonth(intro_date.getMonth().length(intro_date.isLeapYear()))
                                         
      while (intro_date.toString <= limit_date) 
      {
        dbutils.notebook.run("/DataInsights/Export/Score/DI_score_paie", timeoutSeconds, Map("load_date" -> intro_date.toString))  //pay
        intro_date = intro_date.plusMonths(1)
        intro_date = intro_date.withDayOfMonth(intro_date.getMonth().length(intro_date.isLeapYear()))
      }
    
  }
  
  if(filename_lower.contains("all") | filename_lower.contains("employe"))
  {
      var intro_date = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
      intro_date = intro_date.withDayOfMonth(intro_date.getMonth().length(intro_date.isLeapYear()))
                                         
      while (intro_date.toString <= limit_date) 
      {
        dbutils.notebook.run("/DataInsights/Export/Score/DI_score_employe", timeoutSeconds, Map("load_date" -> intro_date.toString)) //employee
        intro_date = intro_date.plusMonths(1)
        intro_date = intro_date.withDayOfMonth(intro_date.getMonth().length(intro_date.isLeapYear()))
      }
       
  }
  
  
  /*******************Referential data********************/ 
  if(filename_lower.contains("all") | filename_lower.contains("rubrique_paie"))
  {
    dbutils.notebook.run("/DataInsights/Export/Score/DI_score_rubrique_paie", timeoutSeconds) //payroll
  }
  
  if(filename_lower.contains("all") | filename_lower.contains("etablissement_hr"))
  {
    dbutils.notebook.run("/DataInsights/Export/Score/DI_score_etablissement_hr", timeoutSeconds)  //establishment
  }
  
  if(filename_lower.contains("all") | filename_lower.contains("cost_center_hr"))
  {
    dbutils.notebook.run("/DataInsights/Export/Score/DI_score_cost_center_hr", timeoutSeconds)  //cost_center
  }

}

// COMMAND ----------

// DBTITLE 1,Generate monthly files
//- loop quotidien
if(flux == "quotidien"){
  
  var snapshot_month_id = ""
  var load_date = ""
  var filename_lower = filename.map(a => a.toLowerCase())
  var timeoutSeconds=0
  var date_value = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
  var date_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + ("%02d".format(date_value.getDayOfMonth))

  val df_snapshot_month_id = spark.read.jdbc(jdbcurl, "dbo.param_monthly_calendar", connectionproperties).filter("snapshot_date_id = '" + date_id + "'").select("snapshot_month_id")
  df_snapshot_month_id.createOrReplaceTempView("vw_snapshot_month_id")

  if(df_snapshot_month_id.isEmpty == false)
  {
     snapshot_month_id = spark.sql(""" select snapshot_month_id from vw_snapshot_month_id """).head().getInt(0).toString  
     load_date = LocalDate.parse(snapshot_month_id, DateTimeFormatter.ofPattern("yyyyMMdd")).toString
    
     /*******************facts data****************************/
    if(filename_lower.contains("all") | filename_lower.contains("effectif")) //Staff
    {
       dbutils.notebook.run("/DataInsights/Export/Score/DI_score_effectif", timeoutSeconds, Map("load_date" -> load_date)) //Staff
    }
    
    if(filename_lower.contains("all") | filename_lower.contains("paie")) //pay
    {
       dbutils.notebook.run("/DataInsights/Export/Score/DI_score_paie", timeoutSeconds, Map("load_date" -> load_date))  //pay
    }
    
    if(filename_lower.contains("all") | filename_lower.contains("employe"))
    {
       dbutils.notebook.run("/DataInsights/Export/Score/DI_score_employe", timeoutSeconds, Map("load_date" -> load_date)) //employee
    }
      
    /*******************Referential data********************/
    if(filename_lower.contains("all") | filename_lower.contains("rubrique_paie"))
    {
       dbutils.notebook.run("/DataInsights/Export/Score/DI_score_rubrique_paie", timeoutSeconds, Map("load_date" -> load_date)) //payroll
    }
  
    if(filename_lower.contains("all") | filename_lower.contains("etablissement_hr"))
    {
       dbutils.notebook.run("/DataInsights/Export/Score/DI_score_etablissement_hr", timeoutSeconds, Map("load_date" -> load_date))  //establishment
    }
  
    if(filename_lower.contains("all") | filename_lower.contains("cost_center_hr"))
    {
       dbutils.notebook.run("/DataInsights/Export/Score/DI_score_cost_center_hr", timeoutSeconds, Map("load_date" -> load_date))  //cost_center
    }

  }
  
  if(filename_lower.contains("all") | filename_lower.contains("employe_retro"))
  {
     var date_value = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd")).plusMonths(-1)
     var date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
     dbutils.notebook.run("/DataInsights/Export/Score/DI_score_employe_retro", timeoutSeconds, Map("load_date" -> date_end_month.toString)) //employee
  }
  
    if(filename_lower.contains("all") | filename_lower.contains("paie_retro"))
  {
     var date_value = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd")).plusMonths(-1)
     var date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
     dbutils.notebook.run("/DataInsights/Export/Score/DI_score_paie_retro", timeoutSeconds, Map("load_date" -> date_end_month.toString)) //employee
  }
}

// COMMAND ----------

val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0

// COMMAND ----------

dbutils.notebook.exit(return_value)