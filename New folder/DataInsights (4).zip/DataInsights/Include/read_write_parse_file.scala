// Databricks notebook source
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

def checkschemaheader(df_source: DataFrame, schema: StructType) : String = {
  
  //Get columns names present on both dataframes
  val schema_source = df_source.schema.fields.map(f => (f.name))
  val schema_target = schema.fields.map(f => (f.name))
  
  //Compare schema by checking if columns name on schema_source are present in schema_target columns
  val diff_schema=schema_source.diff(schema_target)
  
  var i = 0
  var res="";
  
  //Case where columns on source schema are present in the target schema
  if(diff_schema.isEmpty)
  {
    while( i < schema_source.length && schema_source(i)==schema_target(i))
    {
      i = i+1
    }
    
    if(i<schema_source.length)
    {
      res = "ERR-001| The columns order are not respected: | " + schema_source(i) + " vs " + schema_target(i) 
    }
 
  }
  
  else
  {
    res = "ERR-002| The unknown columns have been found in the file : | " + diff_schema.mkString(",")
  }
  
  return res
}

// COMMAND ----------

def getdirectoryfiles(path: String, extension: String, listfiles: List[String]): List[String] = {
 
  var strlistfiles = listfiles
  
  if(pathexists(path))
  {
    val files = dbutils.fs.ls(path)
  
    if(files.isEmpty)
    {
      return strlistfiles
    }
    for(dir <- files) {    
      if((!dir.isDir) && (dir.name.endsWith(extension) || dir.name.endsWith(extension.toUpperCase()))) {
        strlistfiles=dir.path::strlistfiles

      }
      if((!dir.isDir) && (!dir.name.endsWith(extension) || !dir.name.endsWith(extension.toUpperCase()))) {
        strlistfiles=null::strlistfiles

      }
      else
      {
      //  println(strlistfiles)
        strlistfiles =  getdirectoryfiles(dir.path,extension,strlistfiles)
      }
    }
  }
  
return strlistfiles
  
}

// COMMAND ----------

def getdirectories(path: String, last_load_date: String): List[String] = {
 
  var strlistdirectories = List[String]()
  var partition_path = ""
  var full_path = ""
  
  var start_date = LocalDate.parse(last_load_date, DateTimeFormatter.ofPattern("yyyyMMdd")).plusDays(1)
  var current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  
  val numberOfDays =  ChronoUnit.DAYS.between(start_date, current_date)
  
  for (d<- 0 to numberOfDays.toInt) 
  {
    partition_path = start_date.plusDays(d).getYear().toString + "/" + ("%02d".format(start_date.plusDays(d).getMonth.getValue())) + "/" + ("%02d".format(start_date.plusDays(d).getDayOfMonth()))
    
    full_path = path + "/" + partition_path
    
    if(pathexists(full_path))
    {
       
       strlistdirectories = full_path::strlistdirectories
         
     }
   
  }

  return strlistdirectories.distinct
  
}

// COMMAND ----------

def getfiles(path: String, extension: String, listfiles: List[String], last_load_date: String): List[String] = {
 
  var strlistfiles = listfiles
  var partition_path = ""
  var full_path = ""
  
  var start_date = LocalDate.parse(last_load_date, DateTimeFormatter.ofPattern("yyyyMMdd")).plusDays(1)
  var current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  
  val numberOfDays =  ChronoUnit.DAYS.between(start_date, current_date)
  
  for (d<- 0 to numberOfDays.toInt) 
  {
    partition_path = start_date.plusDays(d).getYear().toString + "/" + ("%02d".format(start_date.plusDays(d).getMonth.getValue())) + "/" + ("%02d".format(start_date.plusDays(d).getDayOfMonth()))
    
    full_path = path + "/" + partition_path
    
    if(pathexists(full_path))
    {
       var strlist= List[String]()
       strlistfiles = strlistfiles++getdirectoryfiles(full_path,extension,strlist)
    }
   
  }

  return strlistfiles.distinct
  
}

// COMMAND ----------

def isEmptyFolder(path: String, extension: String): Boolean = { 
  try 
  {
      var strDirectoriesFiles = List[String]()  
      strDirectoriesFiles = getdirectoryfiles(path,extension,strDirectoriesFiles).filter(_ != null).sortWith(_ < _)
      if(strDirectoriesFiles.isEmpty)
      {
        return true
      }
      else
      {
        return false
      }
        
   }
   catch 
    {
       case ex: FileNotFoundException => {
        return true
       }
  
    }
   return false
}

// COMMAND ----------

def getrow (row: Row, listfields: Array[String], listfieldsnotnullable: Array[String], listfieldstype: Array[String]) :Row = {
  var temprow = Row.apply()
  var values = Seq[Any]()
  var error = ""
  var row_value = ""
   var i = 0
  while(i<(listfields.length-1))
  {
     if( row.getAs(listfields(i)) != null && (row.getAs(listfields(i))).toString.isEmpty==false)
     {       
       row_value = getWellFormat((row.getAs(listfields(i))).toString, listfieldstype(i))
       values = values :+ coalesceString(row_value,(row.getAs(listfields(i))).toString)
      
       if(row_value == null || row_value == "" || row_value.isEmpty) 
       {
          error = error.concat("|") + "ERR-003: the value of column " + listfields(i) + " is not a " + listfieldstype(i) + " "
       }
     }
    
     else
     {
        values = values :+ row.getAs(listfields(i))
     }
    
     
    
     var j = 0
      for( j <- 0 to listfieldsnotnullable.length-1)
      {
        if(listfields(i) == listfieldsnotnullable(j) && (row.getAs(listfields(i))==null || (row.getAs(listfields(i))).toString.isEmpty))
        {
          error = error.concat("|") + "ERR-004: the mandatory column " + listfields(i) + " is empty "
        }
           
      }
     i = i+1
  }
  values = values :+ row.getAs(listfields((listfields.length-1)))
  values = values :+ error
  //println(values)
  // temprow=Row(row.getDouble(0),row.getString(1),row.getString(2),row.getString(3),row.getString(4),row.getDouble(5),row.getInt(6),row.getDouble(7),row.getDouble(8),row.getDouble(9))
  //temprow=Row(row.getAs("carat"),row(1),row(2),row(3),row(4),row(5),row(6),row(7),row(8),row(9))
  temprow=Row.fromSeq(values)
  return temprow
}

// COMMAND ----------



// COMMAND ----------


def parse_file(filenameDF: DataFrame, delimiter: String, extension: String, schema: StructType, lastColumn: String) : DataFrame = {
   
 //Remove_Character on columns
  val CleanColumnsDF = filenameDF
                      .columns
                      .foldLeft(filenameDF){(newdf, colname) => newdf.withColumnRenamed(colname, colname.trim.replace(" ", "_").replace(".", "").replace("'","").replace(")","").replace("(","").replace("%_","").replace("-","_").toLowerCase)}
  
  //Trim
  var TrimDf = CleanColumnsDF
  for(col <- CleanColumnsDF.columns){
    TrimDf = TrimDf.withColumn(col,trim(CleanColumnsDF(col)))
  }
  
  //delete duplicate value
  val df_source = TrimDf.distinct()
    
  //val df_target = spark.table(tablename)
  
  var res = checkschemaheader(df_source.drop(lastColumn),schema)
  
  if(res!=null && res != "")
  {
    var newRdd = df_source.withColumn("error_log",lit(res))
    return  newRdd
  }
  
  
  else
  {
      val schema_source_fields=df_source.schema.fields.map(f => (f.name, f.dataType, f.nullable)).map(x => x._1) 
      val schema_target_dtype=schema.fields.map(f => (f.name, f.dataType, f.nullable)).map(x => x._2.simpleString) 
      val not_nullable_columns=schema.fields.map(f => (f.name, f.dataType, f.nullable)).filter(x => x._3 == true).map(x => x._1) 

      val final_struc = StructType(df_source.schema.fields).add(StructField("error_log", StringType, true))

      val newRdd = df_source.rdd.map(row => getrow(row,schema_source_fields,not_nullable_columns,schema_target_dtype))
      val newDf = spark.createDataFrame(newRdd,final_struc)
    
    return newDf
  }
  
}

// COMMAND ----------

def writeadls(df: DataFrame, dest_folder: String, object_name: String, format: String, mode: String, partition_column : Seq[String]) {

  val dest_path = dest_folder + "/" + object_name + "/"
  //val dest_path = dest_folder + "/" + object_name + "/"

  ///df.repartition($"date_raw_load_file").write.format(format).mode(mode).partitionBy("partition_id").save(dest_path)
  df.write.format(format).mode(mode).partitionBy(partition_column: _*).save(dest_path)
}

// COMMAND ----------

def makeCustomSchema(originalStruct: StructType, updColumns:Set[String]): StructType = {
  updColumns match {
    case s if s.isEmpty => originalStruct
    case _ => originalStruct.copy(
       fields = originalStruct.fields.filter( 
          f => updColumns.contains(f.name)))
  }
}

// COMMAND ----------

def get_dataframe_schema(df: DataFrame, schema: StructType): DataFrame = {
 
  if(schema == null)
  {
    return df
  }
  else
  {
    
    var schema_source_fields=df.schema.fields.map(f => (f.name, f.dataType, f.nullable)).map(x => x._1) 
    var new_schema = makeCustomSchema(schema,schema_source_fields.toSet)
    var emptyDF = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], new_schema)
    val fieldsDiffType = (emptyDF.schema.fields zip df.schema.fields).collect{
      case (a: StructField, b: StructField) if a.dataType != b.dataType =>
      (a.name, a.dataType)
    }

    val finalDF = fieldsDiffType.foldLeft(df)( (accDF, field) =>
    accDF.withColumn(field._1, col(field._1).cast(field._2))
    )
    return finalDF
  }
    
}

// COMMAND ----------

/*def get_most_recent_path_in(path: String) : String = {
  //Helper function to get the most recent version of data in path
  val date = [_.name for _ in dbutils.fs.ls(path)]
  val most_recent_year = max(years)

  val months = [_.name for _ in dbutils.fs.ls(path+('/'+most_recent_year))]
  val most_recent_month = max(months)

  val days = [_.name for _ in dbutils.fs.ls(path+('/'+most_recent_year+'/'+most_recent_month))]
  val most_recent_day = max(days)

  return path+'/'+most_recent_year+most_recent_month+most_recent_day
}
*/

// COMMAND ----------

def get_last_partition_file(path: String, last_load_date: String, source:String) : String = {
  //Helper function to get the most recent version of data in path
  var strList = List[String]()  //init empty list of string
  var last_date = "" //init the return value to null
  val curated_container = get_container(source)
  
  val full_path = curated_container + path
  
  if(pathexists(full_path))
  {
    val files = dbutils.fs.ls(full_path)
    
    if(!files.isEmpty)
    {
      for(dir <- files)
      {    
         if(dir.name.contains("date_raw_load_file"))
         {
            var partition = dir.path.split("=")(1).replace("/","")
            strList=partition::strList
          }

      }
      if(!strList.isEmpty)
      {
         strList = strList.sortWith(_ < _)
        
        
        if(last_load_date <= strList.min)
        {
          last_date = strList.min
        }
        
        if(last_load_date >= strList.max)
        {
          last_date = strList.max
        }
        
        if(last_load_date > strList.min && last_load_date < strList.max)
        {
         // last_date = last_load_date
          var start_date = LocalDate.parse(strList.min, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
          var target_date = LocalDate.parse(last_load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
          
          while(target_date.toString >= start_date.toString)
          {
            var date_string = start_date.toString
            if(strList.contains(date_string))
            {
              last_date = date_string
            }
            
            start_date = start_date.plusDays(1)
          }
        }
      }
    } 
  }  

  return last_date
}


// COMMAND ----------

def save_df (df:DataFrame, folder_path: String) : Boolean = {
  try{
    df.coalesce(1).write.format("csv").option("sep",";").option("header",true).option("encoding","utf-8").option("treatEmptyValuesAsNulls","true").option("nullValue", null).save(folder_path)
    val files = dbutils.fs.ls(folder_path).filter(file =>file.name.endsWith(".csv")).toDF.select("name").head.getString(0)
    dbutils.fs.mv(folder_path+"/"+files,folder_path.split("/").dropRight(1).mkString("/")+"/"+folder_path.split("/").last+".csv")
    dbutils.fs.rm(folder_path,true)
    return true 
    }
   catch 
    {
       case ex: FileNotFoundException => {
        return false
       }
  
    }
}