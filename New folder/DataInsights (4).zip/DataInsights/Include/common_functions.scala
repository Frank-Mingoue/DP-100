// Databricks notebook source
// DBTITLE 1,Include notebook containing Library
// MAGIC %run /DataInsights/Include/import_library

// COMMAND ----------

// DBTITLE 1,Function which returns a concatened string from an array string
def getconcatenedstring(colList: Seq[String]) : String = {
  var concatenatedstring = ""
  var i=0

  for(col <- colList) 
  {  
    concatenatedstring = concatenatedstring + col
    if(i<(colList.length-1))
    {
       concatenatedstring = concatenatedstring + "|"
    }
       
     i = i + 1
  }
 
 return  concatenatedstring
}

// COMMAND ----------

// DBTITLE 1,Define an UDF Fonction to use it inside query
spark.udf.register("getconcatenedstring", getconcatenedstring _)

// COMMAND ----------

// DBTITLE 1,Function which returns the age between the date in parameter and the current day in years
def getcurrentage (dob: java.sql.Date) : Int = {
   Period.between(dob.toLocalDate, LocalDate.now).getYears
}


// COMMAND ----------

// DBTITLE 1,Define an UDF Fonction to use it inside query
spark.udf.register("getcurrentage", getcurrentage _)

// COMMAND ----------

// DBTITLE 1,Function which returns a string value at the position in parameter inside string containing the separator in parameter
def getvalueposition(input: String, position: Integer, separator: String) : String = {

  if (input == null) //test if the input string if null
    return null 
  else
  {
    if(input.contains(separator) && position<input.split(separator).length && position>=0) //test if the input string contains the separator and the position is superior to 0 and position is inferieur to array length
      return input.split(separator)(position)
    else
      return input
  }

}

// COMMAND ----------

// DBTITLE 1,Define an UDF Fonction to use it inside query
spark.udf.register("getvalueposition", getvalueposition _)

// COMMAND ----------

// DBTITLE 1,Function with allows to test if the value in parameter corresponds to the type in parameter
def iswellformatted(value: String, dtype: String): Boolean = {

  val fmt_timestamp_1 = DateTimeFormat forPattern "yyyy-MM-dd HH:mm:ss"
  val fmt_timestamp_2 = DateTimeFormat forPattern "yyyy-MM-dd HH:mm:ss.SSS"
  val fmt_timestamp_3 = DateTimeFormat forPattern "yyyy-MM-dd HH:mm"
  val fmt_timestamp_4 = DateTimeFormat forPattern "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
  val fmt_timestamp_5 = DateTimeFormat forPattern "yyyy-MM-dd'T'HH:mm:ss.SSS-mm:ss"
  
  val fmt_timestamp_6 = DateTimeFormat forPattern "dd/MM/yyyy HH:mm:ss"
  val fmt_timestamp_7 = DateTimeFormat forPattern "dd/MM/yyyy HH:mm:ss.SSS"
  val fmt_timestamp_8 = DateTimeFormat forPattern "dd/MM/yyyy HH:mm"
  val fmt_timestamp_9 = DateTimeFormat forPattern "dd/MM/yyyy'T'HH:mm:ss.SSS'Z'"
  val fmt_timestamp_10 = DateTimeFormat forPattern "dd/MM/yyyy'T'HH:mm:ss.SSS-mm:ss"
  
  val fmt_date_1 = DateTimeFormat forPattern "yyyy-MM-dd"
  val fmt_date_2 = DateTimeFormat forPattern "dd/MM/yyyy"
  
  dtype match {
    case "short" => Try(value.trim.toShort).isSuccess
    case "int" =>  Try(value.trim.toInt).isSuccess
    case "double" =>  Try(value.trim.replace(",",".").toDouble).isSuccess
    case "float" =>  Try(value.trim.replace(",",".").toFloat).isSuccess
    case "long" =>  Try(value.trim.toLong).isSuccess
    case "string" =>  Try(value.toString).isSuccess
    case "boolean" =>  Try(value.trim.toBoolean).isSuccess
    case "timestamp" =>  (Try(fmt_date_1.parseDateTime(value)).isSuccess || 
                          Try(fmt_date_2.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_1.parseDateTime(value)).isSuccess ||  
                          Try(fmt_timestamp_2.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_3.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_4.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_5.parseDateTime(value)).isSuccess ||
                          Try(fmt_timestamp_6.parseDateTime(value)).isSuccess ||  
                          Try(fmt_timestamp_7.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_8.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_9.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_10.parseDateTime(value)).isSuccess
                          )
    case "date" =>  (Try(fmt_date_1.parseDateTime(value)).isSuccess || 
                          Try(fmt_date_2.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_1.parseDateTime(value)).isSuccess ||  
                          Try(fmt_timestamp_2.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_3.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_4.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_5.parseDateTime(value)).isSuccess ||
                          Try(fmt_timestamp_6.parseDateTime(value)).isSuccess ||  
                          Try(fmt_timestamp_7.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_8.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_9.parseDateTime(value)).isSuccess || 
                          Try(fmt_timestamp_10.parseDateTime(value)).isSuccess
                          )
    
  }
 
}

// COMMAND ----------

def getWellFormat(value: String, dtype: String): String = {
  
  val pattern_timestamp_1 = "yyyy-MM-dd HH:mm:ss"
  val pattern_timestamp_2 = "yyyy-MM-dd HH:mm:ss.SSS"
  val pattern_timestamp_3 = "yyyy-MM-dd HH:mm"
  val pattern_timestamp_4 = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
  val pattern_timestamp_5 = "yyyy-MM-dd'T'HH:mm:ss.SSS-mm:ss"
  
  val pattern_timestamp_6 = "dd/MM/yyyy HH:mm:ss"
  val pattern_timestamp_7 = "dd/MM/yyyy HH:mm:ss.SSS"
  val pattern_timestamp_8 = "dd/MM/yyyy HH:mm"
  val pattern_timestamp_9 = "dd/MM/yyyy'T'HH:mm:ss.SSS'Z'"
  val pattern_timestamp_10 = "dd/MM/yyyy'T'HH:mm:ss.SSS-mm:ss"
  
  val fmt_timestamp_1 = DateTimeFormat forPattern pattern_timestamp_1
  val fmt_timestamp_2 = DateTimeFormat forPattern pattern_timestamp_2
  val fmt_timestamp_3 = DateTimeFormat forPattern pattern_timestamp_3
  val fmt_timestamp_4 = DateTimeFormat forPattern pattern_timestamp_4
  val fmt_timestamp_5 = DateTimeFormat forPattern pattern_timestamp_5
  
  val fmt_timestamp_6 = DateTimeFormat forPattern pattern_timestamp_6
  val fmt_timestamp_7 = DateTimeFormat forPattern pattern_timestamp_7
  val fmt_timestamp_8 = DateTimeFormat forPattern pattern_timestamp_8
  val fmt_timestamp_9 = DateTimeFormat forPattern pattern_timestamp_9
  val fmt_timestamp_10 = DateTimeFormat forPattern pattern_timestamp_10
  
  val pattern_date_1 = "yyyy-MM-dd"  
  val pattern_date_2 = "dd/MM/yyyy"  
  
  val fmt_date_1 = DateTimeFormat forPattern pattern_date_1
  val fmt_date_2 = DateTimeFormat forPattern pattern_date_2

     dtype match {

      case "boolean" =>  if(Try(value.trim.toBoolean).isSuccess) {value.trim}
                         else {""}

      case "int" =>  if(Try(value.trim.toInt).isSuccess) {value.trim}
                     else {""}

      case "long" =>  if(Try(value.trim.toLong).isSuccess) {value.trim}
                      else {""}

      case "short" =>  if(Try(value.trim.toShort).isSuccess) {value.trim}
                      else {""}

      case "double" =>  if(Try(value.trim.replace(",",".").toDouble).isSuccess) {value.trim.replace(",",".")}
                        else {""} 

      case "float" =>  if(Try(value.trim.replace(",",".").toFloat).isSuccess) {value.trim.replace(",",".")}
                       else {""}

      case "timestamp" =>  if(Try(fmt_date_1.parseDateTime(value)).isSuccess) { value } 
                           else if(Try(fmt_date_2.parseDateTime(value)).isSuccess) { LocalDateTime.parse(value, DateTimeFormatter.ofPattern(pattern_date_2)).toString() } 
                           else if(Try(fmt_timestamp_1.parseDateTime(value)).isSuccess) { value }
                           else if(Try(fmt_timestamp_2.parseDateTime(value)).isSuccess) { value }
                           else if(Try(fmt_timestamp_3.parseDateTime(value)).isSuccess) { value }
                           else if(Try(fmt_timestamp_4.parseDateTime(value)).isSuccess) { value }
                           else if(Try(fmt_timestamp_5.parseDateTime(value)).isSuccess) { value }       
                           else if(Try(fmt_timestamp_6.parseDateTime(value)).isSuccess) { LocalDateTime.parse(value, DateTimeFormatter.ofPattern(pattern_timestamp_6)).toString() } 
                           else if(Try(fmt_timestamp_7.parseDateTime(value)).isSuccess) { LocalDateTime.parse(value, DateTimeFormatter.ofPattern(pattern_timestamp_7)).toString() }
                           else if(Try(fmt_timestamp_8.parseDateTime(value)).isSuccess) { LocalDateTime.parse(value, DateTimeFormatter.ofPattern(pattern_timestamp_8)).toString() }
                           else if(Try(fmt_timestamp_9.parseDateTime(value)).isSuccess) { LocalDateTime.parse(value, DateTimeFormatter.ofPattern(pattern_timestamp_9)).toString() }
                           else if(Try(fmt_timestamp_10.parseDateTime(value)).isSuccess) { LocalDateTime.parse(value, DateTimeFormatter.ofPattern(pattern_timestamp_10)).toString() }
                           else {""}

      case "date" => if(Try(fmt_date_1.parseDateTime(value)).isSuccess) { value } 
                     else if(Try(fmt_date_2.parseDateTime(value)).isSuccess) { LocalDate.parse(value, DateTimeFormatter.ofPattern(pattern_date_2)).toString() } 
                     else if(Try(fmt_timestamp_1.parseDateTime(value)).isSuccess) { value }
                     else if(Try(fmt_timestamp_2.parseDateTime(value)).isSuccess) { value }
                     else if(Try(fmt_timestamp_3.parseDateTime(value)).isSuccess) { value }
                     else if(Try(fmt_timestamp_4.parseDateTime(value)).isSuccess) { value }
                     else if(Try(fmt_timestamp_5.parseDateTime(value)).isSuccess) { value }  
                     else if(Try(fmt_timestamp_6.parseDateTime(value)).isSuccess) { LocalDate.parse(value, DateTimeFormatter.ofPattern(pattern_timestamp_6)).toString() } 
                     else if(Try(fmt_timestamp_7.parseDateTime(value)).isSuccess) { LocalDate.parse(value, DateTimeFormatter.ofPattern(pattern_timestamp_7)).toString() }
                     else if(Try(fmt_timestamp_8.parseDateTime(value)).isSuccess) { LocalDate.parse(value, DateTimeFormatter.ofPattern(pattern_timestamp_8)).toString() }
                     else if(Try(fmt_timestamp_9.parseDateTime(value)).isSuccess) { LocalDate.parse(value, DateTimeFormatter.ofPattern(pattern_timestamp_9)).toString() }
                     else if(Try(fmt_timestamp_10.parseDateTime(value)).isSuccess) { LocalDate.parse(value, DateTimeFormatter.ofPattern(pattern_timestamp_10)).toString() }
                     else {""}

       case "string" => value
       
       case default => value
     }
   
} 

// COMMAND ----------

def coalesceString(value_1: String, value_2: String) : String = {
  
  if(value_1.isEmpty == false && value_1 != null && value_1 != "")
  {
    return value_1
  }
  else
  {
    return value_2
  }
}

// COMMAND ----------

def pathexists(path: String): Boolean = { 
  try 
  {
      if(path == null)
      {
        return false
      }
      else
      {
        val list = dbutils.fs.ls(path)
      }
        
   }
   catch 
    {
       case ex: FileNotFoundException => {
        return false
       }
  
    }
   return true
}


// COMMAND ----------

def pathempty(path: String): Boolean = { 
  try 
  {
      if(path == null || (path != null && dbutils.fs.ls(path).isEmpty))
      {
        return true
      }
      else
      {
        return false
      }
        
   }
   catch 
    {
       case ex: FileNotFoundException => {
        return true
       }
  
    }
   return false
}

// COMMAND ----------

// DBTITLE 1,Function that transforms a resulset  object as an iterator object
def results[T](resultSet: ResultSet)(f: ResultSet => T) = {
  new Iterator[T] {
    def hasNext = resultSet.next()
    def next() = f(resultSet)
  }
}
//val dates =  results(rs)(_.getString(1)).max

// COMMAND ----------

// DBTITLE 1,Calculate the size of file
def calcRDDSize(rdd: RDD[String]): Long = {
  rdd.map(_.getBytes("UTF-8").length.toLong)
     .reduce(_+_) //add the sizes together
}

// COMMAND ----------

def get_most_recent_path_in(path: String) : String = {
  //Helper function to get the most recent version of data in path
  var strList = List[String]()  //init empty list of string
  var last_load_date ="" //init the return value to null
  
  if(pathexists(path))
  {
    val files = dbutils.fs.ls(path)
    if(!files.isEmpty)
    {
      for(dir <- files)
      {    
         if(dir.name.contains("date_raw_load_file"))
         {
            var partition = dir.path.split("=")(1).replace("/","")
            strList=partition::strList
          }

      }
      if(!strList.isEmpty)
      {
        last_load_date = strList.sortWith(_ > _).head
      }
    } 
  }  
  
  return last_load_date
}

// COMMAND ----------

// MAGIC %md Function for Transco 

// COMMAND ----------

def gettransco2(df_transco :DataFrame, df: DataFrame, input_axe: String, output_axe: String): (DataFrame, List[String],List[String]) = {
  
  var df_new  = df
  var old_columns  = List[String]()
  var new_columns = List[String]()
  //columns df
  val l_df_columns = df_new.columns.toList.map(a => a.toLowerCase())
  val df_transco_new = df_transco.selectExpr("lower(field_"+output_axe+") as field_"+output_axe+"", ""+output_axe+"_value as "+output_axe+"_value","lower(field_"+input_axe+") as field_"+input_axe+"","lower("+input_axe+"_value) as "+input_axe+"_value")
  //columns transco
  val l_transco = df_transco_new.select(col("field_"+input_axe)).distinct.rdd.map(r => r(0).toString.toLowerCase).collect()

  for (ele <-  l_transco){
      val ele_lower = ele.toString().toLowerCase()
      if (l_df_columns.contains(ele_lower)){     
        val df_transco_filter = df_transco_new.where(col("field_"+input_axe)===ele)
        val column_rename = df_transco_filter.select(col("field_"+output_axe)).where(col("field_"+output_axe)=!="Nothing")//
        if(column_rename.isEmpty==false){

          df_new = df_new.join(broadcast(df_transco_filter),
                                df_new.col(ele_lower) === df_transco_filter.col(input_axe+"_value"),"left")
                                .withColumn(output_axe+"_value",when(col(output_axe+"_value")==="Nothing",col(ele_lower))
                                                          .when(col(output_axe+"_value").isNull,col(ele_lower))
                                                          .otherwise(col(output_axe+"_value")))
                             .withColumnRenamed(output_axe+"_value",column_rename.first.getString(0))
                            .drop(ele_lower,"field_"+input_axe,"field_"+output_axe,input_axe+"_value")

          old_columns = ele_lower :: old_columns
          new_columns = column_rename.first.getString(0) :: new_columns
        }
      }
  }
  return(df_new,old_columns,new_columns)
}


// COMMAND ----------

val stringNormalizer = udf((s: String) => StringUtils.stripAccents(s))

// COMMAND ----------

sqlContext.udf.register("stringNormalizer", (s: String) => StringUtils.stripAccents(s))