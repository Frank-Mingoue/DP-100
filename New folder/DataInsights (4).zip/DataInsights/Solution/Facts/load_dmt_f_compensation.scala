// Databricks notebook source
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val historical_data_end_date = dbutils.widgets.get("historical_data_end_date");
val limit_date_histo = dbutils.widgets.get("limit_date_histo");
val system_source = dbutils.widgets.get("system_source");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.databricks.optimizer.rangeJoin.binSize", "5")

// COMMAND ----------

// DBTITLE 1,Refresh table contract
 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh table employee
 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh table ag_establishment
 if(spark.catalog.tableExists("hr.ag_establishment")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.ag_establishment")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh table eligibility psb
 if(spark.catalog.tableExists("hr.eligibility_psb")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.eligibility_psb")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table absenteism
 if(spark.catalog.tableExists("hr.absenteism")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table absenteism consolidated
 if(spark.catalog.tableExists("hr.absenteism_consolidated")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism_consolidated")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh Delta Table Pay
 if(spark.catalog.tableExists("hr.pay")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.pay")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Set Variables
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd")).plusMonths(-1)
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_id = date_end_month.toString.replace("-","")
val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))
val year_id = date_value.getYear()
val last_year_id = date_value.getYear()-1
val last_month = date_end_month.plusMonths(-1).getYear() + ("%02d".format(date_end_month.plusMonths(-1).getMonth.getValue()))
val last_month_id =date_end_month.plusMonths(-1).withDayOfMonth(date_end_month.plusMonths(-1).lengthOfMonth()).toString.replace("-","")
val first_month_id = date_value.getYear() + "01"
val last_month_previous_year = (date_value.getYear() -1) + "12"
val december_previous_year = (date_value.getYear() -1) + "1231"
val march_month_id = date_value.getYear() + "03"
val pourcentage_pi = 0.2
val holidays_bonus = 1500
val bonus_agreement_amount_CHANEL_France = 1090
val bonus_agreement_amount_Verneuil = 1225
val bonus_defile_collection_Verneuil = 1320
val bonus_defile_collection_CHANEL_France_CDD_4 = 1640
val bonus_defile_collection_CHANEL_France_CDD_3 = 1207
val bonus_defile_collection_CHANEL_France_CDD_2B = 966
val bonus_defile_collection_CHANEL_France_CDD_2A = 691
val bonus_defile_collection_CHANEL_France_CDI_4 = 1810
val bonus_defile_collection_CHANEL_France_CDI_3 = 1432
val bonus_defile_collection_CHANEL_France_CDI_2B = 1152
val bonus_defile_collection_CHANEL_France_CDI_2A = 837
val daymonth_PSBN1 = 1130

val date_next_month = date_end_month.plusDays(1)
val month_next_id = date_next_month.getYear() + ("%02d".format(date_next_month.getMonth.getValue()))

val date_start_month = date_value.withDayOfMonth(1)
val date_end_last_month = date_start_month.plusDays(-1)

val limit_date_value = LocalDate.parse(limit_date_histo, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val filter_file_current_month = if (date_end_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}
val filter_file_previous_month = if (date_end_last_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}


// COMMAND ----------

val dvalue = LocalDate.parse("2022-04-01", DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val system_source = if (date_end_month.isBefore (dvalue)) {"hra"} else {"adp"}

// COMMAND ----------

// DBTITLE 1,Get C&B Parameters
val df_param_value = spark.read.jdbc(jdbcurl, "dbo.param_value", connectionproperties).select("parameter_name", "parameter_value")
val plafond_pi = df_param_value.filter($"parameter_name" === "PLAFOND_PI").select("parameter_value").first().getString(0).toDouble
val pourcentage_pi = df_param_value.filter($"parameter_name" === "POURCENTAGE_PI").select("parameter_value").first().getString(0).toDouble
val holiday_bonus = df_param_value.filter($"parameter_name" === "PRIME_VACANCES").select("parameter_value").first().getString(0).toDouble
val bonus_agreement_amount_CHANEL_France = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_ACCORD_SALARIAL_CHANEL_FRANCE").select("parameter_value").first().getString(0).toDouble
val bonus_agreement_amount_Verneuil = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_ACCORD_SALARIAL_VERNEUIL").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_Verneuil = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_VERNEUIL").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDD_4 = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDD_4").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDD_3 = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDD_3").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDD_2B = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDD_2B").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDD_2A = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDD_2A").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDI_4 = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDI_4").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDI_3 = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDI_3").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDI_2B = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDI_2B").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDI_2A = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDI_2A").select("parameter_value").first().getString(0).toDouble
val daymonth_PSBN1 = df_param_value.filter($"parameter_name" === "MONTHDAY_PSBN1").select("parameter_value").first().getString(0).toDouble.toInt 

val taux_charges_patronales_cadre = df_param_value.filter($"parameter_name" === "TAUX_CHARGES_PATRONALES_CADRE").select("parameter_value").first().getString(0).toDouble
val taux_charges_patronales_non_cadre = df_param_value.filter($"parameter_name" === "TAUX_CHARGES_PATRONALES_NON_CADRE").select("parameter_value").first().getString(0).toDouble

// COMMAND ----------

// DBTITLE 1,Set up date delta salary histo
val historical_date_end_date_value = LocalDate.parse(historical_data_end_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
//delta for pay increase
val delta_histo = if (historical_date_end_date_value.isAfter(date_value)) {1.0} else { 0}
//check to filter only on historical data
val is_histo = if (historical_date_end_date_value.isAfter(date_value)) {1} else { 0}


// COMMAND ----------

// DBTITLE 1,Get Dimensions data
spark.read.jdbc(jdbcurl, "dbo.d_date", connectionproperties).filter(col("month_id") === lit(month_id)).createOrReplaceTempView("vw_d_date")
spark.read.jdbc(jdbcurl, "staff.d_employee", connectionproperties).select("employee_id", "employee_code", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_employee")
spark.read.jdbc(jdbcurl, "staff.d_worker_rate", connectionproperties).select("worker_rate_id", "worker_rate_code", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_worker_rate")
spark.read.jdbc(jdbcurl, "staff.d_csp", connectionproperties).select("csp_id", "csp_code", "cadre_non_cadre","professional_category_reference").filter("current_version = 1").createOrReplaceTempView("vw_d_csp")
spark.read.jdbc(jdbcurl, "staff.d_nationality", connectionproperties).select("nationality_id", "nationality_code").filter("current_version = 1").createOrReplaceTempView("vw_d_nationality")
spark.read.jdbc(jdbcurl, "staff.d_range_age", connectionproperties).select("range_age_id", "range_age").filter("current_version = 1").createOrReplaceTempView("vw_d_range_age")
spark.read.jdbc(jdbcurl, "staff.d_seniority_company", connectionproperties).select("seniority_company_id", "range_seniority_company_age").filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_company")
spark.read.jdbc(jdbcurl, "staff.d_hierarchy_pb", connectionproperties).filter("current_version = 1").select("hierarchy_pb_id", "cost_center_code").createOrReplaceTempView("vw_d_hierarchy_pb")

// COMMAND ----------

// DBTITLE 1,Get Dimensions data
spark.read.jdbc(jdbcurl, "staff.d_seniority_position", connectionproperties).select("seniority_position_id", "range_seniority_position_age").filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_position")
spark.read.jdbc(jdbcurl, "staff.d_location", connectionproperties).select("location_id", "location_code").filter("current_version = 1").createOrReplaceTempView("vw_d_location")
spark.read.jdbc(jdbcurl, "staff.d_job_architecture", connectionproperties).select("job_architecture_id", "job_architecture_code","job_title_code","grade_code").filter("current_version = 1").createOrReplaceTempView("vw_d_job_architecture")
spark.read.jdbc(jdbcurl, "staff.d_manager", connectionproperties).select("manager_id", "manager_code").filter("current_version = 1").createOrReplaceTempView("vw_d_manager")
spark.read.jdbc(jdbcurl, "staff.d_supervisory_organization", connectionproperties).select("supervisory_organization_id", "supervisory_organization_code").filter("current_version = 1").createOrReplaceTempView("vw_d_supervisory_organization")
spark.read.jdbc(jdbcurl, "staff.d_contract_suspension", connectionproperties).select("contract_suspension_id", "contract_suspension_code").filter("current_version = 1").createOrReplaceTempView("vw_d_contract_suspension")
spark.read.jdbc(jdbcurl, "staff.d_legal_organization", connectionproperties).select("legal_organization_id", "legal_organization_code", "company", "libelle_etablissement","code_etablissement","hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_legal_organization")
spark.read.jdbc(jdbcurl, "staff.d_operational_organization", connectionproperties).select("operational_organization_id", "operational_organization_code", "division_consolidated","top_level","libelle_departement", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_operational_organization")
spark.read.jdbc(jdbcurl, "pay.d_payroll", connectionproperties).select("payroll_id", "payroll_code", "libelle_rubrique_paie_niv1", "libelle_rubrique_paie_niv2", "libelle_rubrique_paie_niv4", "libelle_rubrique_paie_niv3", "flag_montant_masse_salariale_brute", "flag_montant_aw4", "flag_montant_rem_bs","flag_montant_aw6","flag_montant_rem_nao","flag_montant_rem_reelle","flag_montant_rem_benchmark", "code_rubrique_paie").filter("current_version = 1").createOrReplaceTempView("vw_d_payroll")

val df_contract_type = spark.read.jdbc(jdbcurl, "staff.d_contract_type", connectionproperties).select("contract_type_id", "contract_type_code","precarity","contract_type","contract_type_detailed","classification_collective_agreement","contract_nature","collective_agreement_code","contract_code","contract_nature_label").filter("current_version = 1")
df_contract_type.createOrReplaceTempView("vw_d_contract_type")

// COMMAND ----------

// DBTITLE 1,Get Dimensions data
spark.read.jdbc(jdbcurl, "mobility.d_mobility_in", connectionproperties).select("mobility_in_id", "mobility_in_code").filter("current_version = 1").createOrReplaceTempView("vw_d_mobility_in")
spark.read.jdbc(jdbcurl, "mobility.d_mobility_out", connectionproperties).select("mobility_out_id", "mobility_out_code").filter("current_version = 1").createOrReplaceTempView("vw_d_mobility_out")

spark.read.jdbc(jdbcurl, "staff.d_info_dates", connectionproperties).select("info_dates_id", "info_dates_code", "position_start_date", "hire_date", "contract_start_date", "contract_end_date","contract_dates_code","company_dates_code").filter("current_version = 1").createOrReplaceTempView("vw_d_info_dates")
spark.read.jdbc(jdbcurl, "mobility.d_in_out_dates", connectionproperties).select("in_out_dates_id", "in_out_dates_code","org_in_out_dates_code").filter("current_version = 1").createOrReplaceTempView("vw_d_in_out_dates")

// use view to filter on transcoded value
spark.read.jdbc(jdbcurl, "pay.vw_d_compensation_change", connectionproperties).select("compensation_change_id", "compensation_change_code","compensation_change_reason","compensation_change_subreason").filter("current_version = 1").createOrReplaceTempView("vw_d_compensation_change")
spark.read.jdbc(jdbcurl, "pay.vw_d_compensation_merit_plan", connectionproperties).select("compensation_merit_plan_id", "compensation_merit_plan_code","compensation_merit_plan_label").filter("current_version = 1").createOrReplaceTempView("vw_d_compensation_merit_plan")
spark.read.jdbc(jdbcurl, "pay.d_compensation_bonus_plan", connectionproperties).select("compensation_bonus_plan_id", "compensation_bonus_plan_code").filter("current_version = 1").createOrReplaceTempView("vw_d_compensation_bonus_plan")
spark.read.jdbc(jdbcurl, "pay.d_action_housing", connectionproperties).select("action_housing_id", "action_housing_code").filter("current_version = 1").createOrReplaceTempView("vw_d_action_housing")
spark.read.jdbc(jdbcurl, "pay.d_homeoffice", connectionproperties).select("homeoffice_id", "code").filter("current_version = 1").createOrReplaceTempView("vw_d_homeoffice")
spark.read.jdbc(jdbcurl, "pay.d_increase_type", connectionproperties).select("increase_type_id", "increase_type_detailed").createOrReplaceTempView("vw_d_increase_type")

spark.read.jdbc(jdbcurl, "pay.d_range_payout", connectionproperties).select("range_payout_id", "range_payout_percent", "range_payout_min", "range_payout_max").filter("current_version = 1").createOrReplaceTempView("vw_d_range_payout")
spark.read.jdbc(jdbcurl, "pay.d_range_payout_detailed", connectionproperties).select("range_payout_detailed_id", "range_payout_percent_detailed", "range_payout_min_detailed", "range_payout_max_detailed").filter("current_version = 1").createOrReplaceTempView("vw_d_range_payout_detailed")
spark.read.jdbc(jdbcurl, "pay.d_range_percol", connectionproperties).select("range_percol_id", "range_percol_min", "range_percol_max", "range_percol").filter("current_version = 1").createOrReplaceTempView("vw_d_range_percol")

spark.read.jdbc(jdbcurl, "dbo.vw_ref_seniority_company", connectionproperties).createOrReplaceTempView("vw_ref_seniority_company")

// COMMAND ----------

// DBTITLE 1,Get Vacataire CSP Id and borne one year and 6 months
val vacataire_csp_id = spark.sql("""select cast(sum(csp_id) as int) as vacataire_csp_id from vw_d_csp where lower(professional_category_reference) = 'autre statut'""").head().getInt(0)
val borne_1_year = spark.sql("""select distinct range_seniority_company_max as borne_1_year from vw_ref_seniority_company where range_seniority_company = 'Entre 6 mois et 1 an'""").head().getInt(0) //Borne min for seniority superior to 6 months
val borne_6_month = spark.sql("""select distinct range_seniority_company_min as borne_6_month from vw_ref_seniority_company where range_seniority_company = 'Entre 6 mois et 1 an'""").head().getInt(0) //Borne min for seniority superior to 6 months
val opendays = spark.sql("""select cast(sum(business_day_fr) as int) as opendays from vw_d_date where month_id = '""" + month_id + """'""").head().getInt(0) // Get Nb Opened Days in the load date month
val calendardays = spark.sql("""select cast(count(distinct date_id) as int) as calendardays from vw_d_date where month_id = '""" + month_id + """'""").head().getInt(0) // Get Nb Calendar Days in the load date month

// COMMAND ----------

// DBTITLE 1,Flat Files
// PSB
val df_is_eligible_psb_read = spark.sql("""
  select 
    employee_code,  employee_id, france_payroll_id,
    """+month_id+""" as period_pay_month, 1 as is_eligible
  from hr.eligibility_psb where year(period) = """ + year_id
)
df_is_eligible_psb_read.createOrReplaceTempView("vw_psb")


// Amount LTI
val byltimonth = Window.partitionBy("employee_id","france_payroll_id").orderBy($"period_month".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_amount_lti_read = spark.table("hr.amount_lti").filter("""period_month = '""" + month_id + """'"""
                                                        )                                                         
                                                .withColumn("rank_month",rank() over byltimonth)
                                                .filter(col("rank_month")==="1")
                                                .select("employee_code","amount_lti_annual")
.withColumnRenamed("employee_code","empl_code")
.withColumnRenamed("amount_lti_annual","montant_lti_annuel")
df_amount_lti_read.createOrReplaceTempView("vw_amount_lti")

// Housing
val df_housing_read = spark.table("hr.housing_action").filter("""year = '""" + year_id + """'"""
                                                        )                                                         
                                                .select("employee_code","thematic_action_housing")
.withColumnRenamed("employee_code","empl_code")
.withColumnRenamed("thematic_action_housing","thematique_action_logement")
.withColumn("action_housing_code",sha2($"thematique_action_logement",256))
df_housing_read.createOrReplaceTempView("vw_housing")

// PERCOL PEB CCB
val df_percol_peb_ccb_read = spark.table("hr.percol_peb_ccb").filter("""year = '""" + year_id + """'"""
                                                        )                                                         
                                                .select("employee_code","flag_amundi_per_col","flag_amundi_peg","flag_amundi_ccb")
.withColumnRenamed("employee_code","empl_code")
df_percol_peb_ccb_read.createOrReplaceTempView("vw_percol_peb_ccb")


// Bonus Target
val bybonusmonth = Window.partitionBy("employee_id","france_payroll_id").orderBy($"period_month".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_bonus_read = spark.table("hr.theoric_target_bonus_amount").filter("""period_month = '""" + month_id + """'"""
                                                        )                                                         
                                                .withColumn("rank_month",rank() over bybonusmonth)
                                                .filter(col("rank_month")==="1")
                                                .select("employee_code","theoric_target_bonus_amount")
.withColumnRenamed("employee_code","empl_code")
.withColumnRenamed("theoric_target_bonus_amount","montant_prime_objectif_theorique")
df_bonus_read.createOrReplaceTempView("vw_bonus")


// Bonus Target
val bycarmonth = Window.partitionBy("france_payroll_id").orderBy($"period_month".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_car_read = spark.table("hr.car_mobility_policy").filter("""period_month = '""" + month_id + """'"""
                                                        )                                                         
                                                .withColumn("rank_month",rank() over bycarmonth)
                                                .filter(col("rank_month")==="1")
                                                .select("france_payroll_id","benefits_start_date","benefits_end_date","benefits_type","benefits_category")
.withColumnRenamed("france_payroll_id","hra_emp_id")
.withColumnRenamed("benefits_start_date","date_debut_avantage")
.withColumnRenamed("benefits_end_date","date_fin_avantage")
.withColumnRenamed("benefits_category","categorie_avantage")
.withColumnRenamed("benefits_type","type_avantage")
df_car_read.createOrReplaceTempView("vw_car")

//Etablissement Augmentation Generale
val df_augmentation_generale_read = spark.table("hr.ag_establishment").filter($"year" === year_id)
df_augmentation_generale_read.cache
df_augmentation_generale_read.createOrReplaceTempView("vw_ag_etablissement")

// COMMAND ----------

// DBTITLE 1,Read contracts, employee data
val byemployee = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_organization_change_date".desc,$"effective_organization_hierarchy_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_employee_read = spark.table("hr.employee").filter("('" + date_end_month.toString + "' >= record_start_date or '" + date_end_month.toString + "' >= effective_organization_hierarchy_change_date) and '" + date_end_month.toString + "' <= coalesce(record_end_date, '2999-12-31')")
                                                 .withColumn("rank",rank() over byemployee)
                                                 .filter(col("rank")==="1")
                                                 .filter("company_id <> '0082'")
                                                 .distinct
df_employee_read.createOrReplaceTempView("vw_employee")
df_employee_read.cache()  //put the dataframe on the cache


val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_contract_read = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                 .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'"""
                                                        )    
                                                
                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .withColumn("rank",rank() over bycontract)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("seniority_date_max",when($"contract_end_date" === "2999-12-31" or $"contract_end_date".isNull or $"contract_end_date" > lit(date_end_month), lit(date_end_month)).otherwise($"contract_end_date"))
                                                .withColumn("is_contract_month", when(date_format($"contract_start_date","yyyyMM") <= month_id  and 
                                                            date_format(coalesce($"contract_end_date", lit("2999-12-31")),"yyyyMM") >= month_id,1).otherwise(null))
                                                .filter(col("rank")==="1")
                                                .filter(col("is_contract_month")===1)
                                                .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                .distinct
df_contract_read.createOrReplaceTempView("vw_contract")

// COMMAND ----------

val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract = Window.partitionBy("employee_id","france_payroll_id").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_contract_read_month = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                       .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """' """
                                                        ) 
                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("month_contract_start_date",when($"contract_start_date" < date_start_month,date_start_month).otherwise($"contract_start_date"))
                                                .withColumn("month_contract_end_date",when($"contract_end_date" > date_end_month,date_end_month).when($"contract_end_date".isNull,date_end_month).otherwise($"contract_end_date"))
                                                .withColumn("contract_days",datediff($"month_contract_end_date",$"month_contract_start_date")+1)
                                                .filter(col("rank_month")==="1")
                                                .filter("""date_format(contract_start_date,'yyyyMM') = '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                            (date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                        )
                                                
                                                .withColumn("rank",rank() over bycontract)
                                                .withColumn("next_contract_start_date",lag($"contract_start_date", 1, null).over(bycontract) )
                                                .withColumn("next_contract_end_date",lag($"contract_end_date", 1, null).over(bycontract) )
                                                .distinct
df_contract_read_month.createOrReplaceTempView("vw_contract_month")


// COMMAND ----------

val byJobChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date_valid".desc)
val byJobChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_compensation_change_date_valid".desc)
val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date","effective_job_change_date","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_effective_change_valid = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")                                                
                                                .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                .withColumn("effective_job_change_date_valid", when($"effective_job_change_date" > lit(date_end_month),null).otherwise($"effective_job_change_date"))
                                                .withColumn("effective_job_change_date_valid_last", first($"effective_job_change_date").over(byJobChangeDateLast))
                                                .withColumn("effective_job_change_date", when($"effective_job_change_date_valid".isNotNull,$"effective_job_change_date_valid")
                                                                                        .when($"effective_job_change_date_valid_last".isNull, $"contract_start_date")
                                                                                        .otherwise($"effective_job_change_date_valid_last"))        
                                                .withColumn("effective_job_change_date_max", first($"effective_job_change_date").over(byJobChangeDateLastContract)) 

                                                .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                .withColumn("effective_compensation_change_date_valid", when($"effective_compensation_change_date" > lit(date_end_month),null).otherwise($"effective_compensation_change_date"))
                                                .withColumn("effective_compensation_change_date_valid_last", first($"effective_compensation_change_date").over(byCompensationChangeDateLast))
                                                .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date_valid".isNotNull,$"effective_compensation_change_date_valid")
                                                                                                 .when($"effective_compensation_change_date_valid_last".isNull, $"contract_start_date")
                                                                                                 .otherwise($"effective_compensation_change_date_valid_last"))            
                                                .withColumn("effective_compensation_change_date_max",first($"effective_compensation_change_date").over(byCompensationChangeDateLastContract))


                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .filter(col("rank_month")==="1")  
                                                .filter("""date_format(contract_start_date,'yyyyMM') = '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                            (date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                        )
                                               .select("employee_code",
                                                       "employee_id",
                                                       "france_payroll_id",
                                                       "contract_start_date",
                                                       "contract_end_date",
                                                       "contract_type",
                                                       "contract_type_label",
                                                       "effective_job_change_date",
                                                       "effective_compensation_change_date",
                                                       "effective_job_change_date_max",
                                                       "effective_compensation_change_date_max").distinct


val bycontract_job_month = Window.partitionBy("employee_id","france_payroll_id","effective_job_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_job_change_date_read =spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                                     .filter("""contract_start_date <= '""" + date_end_month + """'""")  
                                                                     .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                                     .withColumn("effective_job_change_date", when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                                     .withColumn("effective_job_change_date", when($"effective_job_change_date".isNotNull,$"effective_job_change_date").otherwise($"contract_start_date"))
                                                                     .filter("""effective_job_change_date <= '""" + date_end_month + """'""")   
                                                                     .withColumn("rank_month",rank() over bycontract_job_month)
                                                                     .filter(col("rank_month")==="1")  
                                                                     .distinct

val bycontract_compensation_month = Window.partitionBy("employee_id","france_payroll_id","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_compensation_change_date_read =spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                                     .filter("""contract_start_date <= '""" + date_end_month + """'""")    
                                                                     .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                                     .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date".isNotNull,$"effective_compensation_change_date").otherwise($"contract_start_date"))                                         
                                                                     .filter("""effective_compensation_change_date <= '""" + date_end_month + """'""")   
                                                                     .withColumn("rank_month",rank() over bycontract_compensation_month)
                                                                     .filter(col("rank_month")==="1")  
                                                                     .distinct

val df_contract_join = df_effective_change_valid.as("e")
                                        .join(df_contract_effective_job_change_date_read.as("c"), $"e.employee_code" === $"c.employee_code" && $"e.effective_job_change_date_max" === $"c.effective_job_change_date" && $"e.contract_start_date" === $"c.contract_start_date", "left_outer")
                                        .join(df_contract_effective_compensation_change_date_read.as("o"), $"e.employee_code" === $"o.employee_code" && $"e.effective_compensation_change_date_max" === $"o.effective_compensation_change_date" && $"e.contract_start_date" === $"o.contract_start_date", "left_outer")
                                        .join(df_contract_read.as("d"), $"e.employee_code" === $"d.employee_code" && $"e.contract_start_date" === $"d.contract_start_date" && ($"e.effective_job_change_date_max" === $"d.effective_job_change_date" || $"e.effective_compensation_change_date_max" === $"d.effective_compensation_change_date"), "left_outer")
                                        .join(df_contract_read.as("r"), $"e.employee_code" === $"r.employee_code" && $"e.contract_start_date" === $"r.contract_start_date", "left_outer")
                                        .selectExpr(
                                                "e.employee_code"
                                               ,"e.employee_id"
                                               ,"e.france_payroll_id"
                                               ,"coalesce(r.contract_start_date, e.contract_start_date) as contract_start_date"
                                               ,"coalesce(r.contract_end_date, e.contract_end_date) as contract_end_date"
                                               ,"e.effective_job_change_date"
                                               ,"coalesce(c.collective_agreement_reference, d.collective_agreement_reference) as collective_agreement_reference"                                    
                                               ,"coalesce(c.collective_agreement_group, d.collective_agreement_group) as collective_agreement_group"
                                               ,"coalesce(c.collective_agreement_level, d.collective_agreement_level) as collective_agreement_level"
                                               ,"coalesce(c.continous_service_date, d.continous_service_date) as continous_service_date"
                                               ,"coalesce(c.position_start_date, d.position_start_date) as position_start_date"
                                               ,"coalesce(c.hire_date, d.hire_date) as hire_date"
                                               ,"coalesce(c.original_hire_date, d.original_hire_date) as original_hire_date"
                                               ,"coalesce(c.effective_hire_date, d.effective_hire_date) as effective_hire_date"
                                               ,"coalesce(c.fte, d.fte) as fte"
                                               ,"coalesce(c.worker_type, d.worker_type) as worker_type"
                                               ,"coalesce(c.paidfte, d.paidfte) as paidfte"
                                               ,"coalesce(c.bonus_target, d.bonus_target) as bonus_target"
                                               ,"coalesce(c.csp, d.csp) as csp"
                                               ,"coalesce(c.coefficient, d.coefficient) as coefficient"
                                               ,"coalesce(c.coefficient_label, d.coefficient_label) as coefficient_label"
                                               ,"coalesce(c.job_title, d.job_title) as job_title"
                                               ,"coalesce(o.total_base_pay, d.total_base_pay) as total_base_pay"
                                               ,"coalesce(o.grade, d.grade) as grade"
                                               ,"coalesce(o.effective_compensation_change_date, d.effective_compensation_change_date) as effective_compensation_change_date"
                                               ,"coalesce(c.job_code, d.job_code) as job_code"
                                               ,"coalesce(c.job_title_code, d.job_title_code) as job_title_code"
                                               ,"coalesce(o.grade_code, d.grade_code) as grade_code"
                                               ,"coalesce(c.csp_code, d.csp_code) as csp_code"
                                               ,"coalesce(c.worker_rate_code, d.worker_rate_code) as worker_rate_code"
                                               ,"coalesce(d.mobility_in_code, c.mobility_in_code) as mobility_in_code"
                                               ,"coalesce(d.mobility_out_code, c.mobility_out_code) as mobility_out_code"
                                               ,"coalesce(d.info_dates_code, c.info_dates_code) as info_dates_code"
                                               ,"coalesce(d.in_out_dates_code, c.in_out_dates_code) as in_out_dates_code"
                                               ,"coalesce(d.contract_dates_code, c.contract_dates_code) as contract_dates_code"                                               
                                               ,"coalesce(c.contract_code, d.contract_code) as contract_code"
                                               ,"coalesce(d.contract_type_code, c.contract_type_code) as contract_type_code"
                                               ,"coalesce(c.collective_agreement_code, d.collective_agreement_code) as collective_agreement_code"
                                               ,"coalesce(c.company_dates_code, d.company_dates_code) as company_dates_code"
                                               ,"coalesce(d.record_start_date, c.record_start_date) as record_start_date"
                                               ,"coalesce(d.date_raw_load_file, c.date_raw_load_file) as date_raw_load_file"
                                               ,"coalesce(d.record_modification_date, c.record_modification_date) as record_modification_date"
                                               ,"coalesce(d.record_creation_date, c.record_creation_date) as record_creation_date"
                                        )

                                          .distinct

df_contract_join.createOrReplaceTempView("vw_emp_contract") 


// COMMAND ----------

// DBTITLE 1,Get Contract information job change date
val bycontract_job_change = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc,$"effective_job_change_date".desc,$"effective_compensation_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_read_job_change = df_contract_join.withColumn("rank",rank() over bycontract_job_change)                                                
                                                 .filter(col("rank")==="1")
                                                 .distinct
                                                 .withColumn("position_start_date", when($"position_start_date" > $"effective_job_change_date",$"effective_job_change_date").otherwise($"position_start_date"))
                                                 .withColumn("continous_service_date", when($"continous_service_date" > $"contract_start_date",$"contract_start_date").otherwise($"continous_service_date"))

df_contract_read_job_change.createOrReplaceTempView("vw_contract_job_change")

// COMMAND ----------

// DBTITLE 1,Contract Change Date for absenteism
val bycontract_job_change_fte_abs = Window.partitionBy("employee_id","france_payroll_id","contract_start_date","fte").orderBy($"contract_start_date".desc,$"effective_job_change_date".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract_job_change_abs = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_job_change_date".desc,$"effective_compensation_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_contract_read_job_change_abs =  df_contract_join.withColumn("rank_fte",rank() over bycontract_job_change_fte_abs)
                                                .filter(col("rank_fte")==="1")
                                    
                                    
                                                .filter("""ifnull(date_format(contract_end_date,'yyyyMM'),'299912') >= '""" + month_id + """'""")
                                                .withColumn("month_contract_start_date",when($"contract_start_date" < date_start_month,date_start_month).otherwise($"contract_start_date"))
                                                .withColumn("month_contract_end_date",when($"contract_end_date" > date_end_month,date_end_month).when($"contract_end_date".isNull,date_end_month).otherwise($"contract_end_date"))
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))

                                                .withColumn("effective_job_change_date_end",lag($"effective_job_change_date", 1, null).over(bycontract_job_change_abs))
                                                .withColumn("effective_job_change_date_previous",lag($"effective_job_change_date", 1, null).over(bycontract_job_change_abs))
                                                .withColumn("effective_job_change_date_end",when($"effective_job_change_date_end".isNull or $"effective_job_change_date_end" === $"effective_job_change_date" ,$"month_contract_end_date").otherwise(date_add($"effective_job_change_date_end",-1)))
                                                .withColumn("contract_days_job_change",when($"effective_job_change_date_end".isNotNull and $"effective_job_change_date_end" >= $"month_contract_start_date" and $"effective_job_change_date_end" < $"month_contract_end_date" and  datediff($"effective_job_change_date_end",$"month_contract_start_date")>=0, 
                                                                                            datediff($"effective_job_change_date_end",$"month_contract_start_date")+1)  
                                                                                       .when($"effective_job_change_date".isNotNull and $"effective_job_change_date" > $"month_contract_start_date" and $"effective_job_change_date" <= $"month_contract_end_date" and datediff($"month_contract_end_date",$"effective_job_change_date")>=0, 
                                                                                            datediff($"month_contract_end_date",$"effective_job_change_date")+1)   
                                                                                      .otherwise(datediff($"month_contract_end_date",$"month_contract_start_date")+1))
                                                .withColumn("rank",rank() over bycontract_job_change_abs)
                                                .withColumn("new_rank",when($"rank" > 1 and date_format($"effective_job_change_date_previous","yyyyMM") === lit(month_id) and $"effective_job_change_date_previous">$"month_contract_start_date" ,"1").otherwise($"rank"))
                                                
                                                .filter(col("new_rank")==="1")
                                                .distinct

df_contract_read_job_change_abs.createOrReplaceTempView("vw_contract_job_change_abs")

// COMMAND ----------

// DBTITLE 1,Get Absenteism Data
// absence rate
val byabs = Window.partitionBy("employee_hra", "dateval", "code", "duration_days", "duration_hours").orderBy($"date_raw_load_file".desc, $"version".desc, $"record_creation_date")
val df_absenteism_read = spark.table("hr.absenteism").filter("period_abs_month = '" + month_id + "'")
                                                      .withColumn("calendardays",lit(calendardays))
                                                      .withColumn("opendays",lit(opendays))
                                                      .withColumn("employee_hra_old",$"employee_hra")
                                                      .withColumn("employee_hra", substring_index($"employee_hra", "_", 1))
                                                      .withColumn("rank",rank() over byabs)
                                                      .filter(col("rank")==="1")
                                                      .distinct
df_absenteism_read.createOrReplaceTempView("vw_absenteism")

val df_referential_absences_read = spark.table("hr.referential_absences").select("absence_code", "absence_label_code", "absence_type")
                                                      .withColumn("code_abs", $"absence_code")                                                                                                                                     
                                                      .withColumn("type_abs",$"absence_type")
                                                      .distinct
df_referential_absences_read.createOrReplaceTempView("vw_referential_absences")

// COMMAND ----------

// DBTITLE 1,Calculate absence days
val absence_days = spark.sql( """
  select   
         c.employee_code
        ,c.employee_id
        ,c.france_payroll_id
        ,c.contract_start_date
        ,cjc.fte
        ,sum(case when a.duration_days = 0 then a.duration_hours/7 else a.duration_days end) abs_days
        ,avg(opendays) opendays
        ,sum(case when a.duration_days = 0 then a.duration_hours/7 else a.duration_days end)/avg(calendardays) as abs_rate
        ,cjc.contract_days_job_change
        ,sum(case when a.duration_days = 0 then a.duration_hours/7 else a.duration_days end)*(cjc.fte) abs_days_fte
    
  from vw_absenteism a 

  inner join vw_referential_absences pa on a.code = pa.code_abs
  
  inner join vw_contract_month c on c.france_payroll_id = a.employee_hra
  and a.dateval between c.month_contract_start_date and c.month_contract_end_date
  
  left join vw_contract_job_change_abs cjc on cjc.employee_code = c.employee_code
            and cjc.contract_start_date = c.contract_start_date
        
  where 1=1
    and a.dateval between case when c.month_contract_start_date < cjc.effective_job_change_date then cjc.effective_job_change_date else c.month_contract_start_date end  and
                          case when c.month_contract_end_date < cjc.effective_job_change_date_end then c.month_contract_end_date else cjc.effective_job_change_date_end end
  
  group by
      c.employee_code
    ,c.employee_id
    ,c.france_payroll_id
    ,c.contract_start_date
    ,cjc.fte
    ,cjc.contract_days_job_change

  order by c.employee_code,c.contract_start_date
         """)
absence_days.createOrReplaceTempView("vw_absence_days")

// COMMAND ----------

// DBTITLE 1,Absence days consolidated by month
spark.sql("""

  select distinct

        c.employee_code
       ,c.employee_id
       ,c.france_payroll_id
       ,sum(abs_days_fte)/100 as abs_days_fte
  from vw_absence_days c
  
  group by c.employee_code
       ,c.employee_id
       ,c.france_payroll_id

                               """).createOrReplaceTempView("vw_employee_absencedays")

// COMMAND ----------

// DBTITLE 1,Get Pay information for Bonus
//Full Pay on current year
val df_pay_read_full = spark.table("hr.pay").filter("current_record = true and substr(period_pay_month,0,4) = '" + year_id + "' and system_source ='" + system_source + "'")
                                            .groupBy("employee_code", 
                                                     "employee_id", 
                                                     "france_payroll_id", 
                                                     "code_rubr",
                                                     "accounting_account",
                                                     "period_pay_month",
                                                     "payroll_code")
                                          .agg(sum("base") as "base", 
                                           sum("salary_amount") as "montant_salarial", 
                                           sum("company_amount") as "montant_patronal")

                                          .withColumn("payroll_amount", when($"montant_salarial".isNotNull and $"montant_patronal".isNull,$"montant_salarial")
                                                                   .when($"montant_salarial".isNull and $"montant_patronal".isNotNull,$"montant_patronal")
                                                                   .otherwise($"montant_salarial" + $"montant_patronal"))
                                           .filter($"payroll_amount".isNotNull)

                                           .distinct.orderBy(asc("period_pay_month"),asc("employee_code"),asc("code_rubr"),asc("code_rubr"))
df_pay_read_full.cache
df_pay_read_full.createOrReplaceTempView("vw_pay_full")

// COMMAND ----------

// DBTITLE 1,Get Bonus Year To Date
val dfBonus = spark.sql(""" select f.employee_code, 
                                   f.code_rubr,
                                   f.employee_id,
                                   case when f.code_rubr like 'VPB_' then sum(f.payroll_amount) else null end as bonus_amount,
                                   case when f.code_rubr like 'VPP_' then sum(f.payroll_amount) else null end as bonus_exceptional_psb_amount,
                                   case when f.code_rubr like 'VPH_' then sum(f.payroll_amount) else null end as bonus_pef_indiv_hojo_amount,
                                   sum(f1.payroll_amount)*12  as bonus_perf_indiv_amount
                                   
                            from vw_pay_full f 
                                 left join vw_pay_full f1 on f.employee_code = f1.employee_code 
                                                             and f.code_rubr = f1.code_rubr
                                                             and f.period_pay_month = f1.period_pay_month
                                                             and f1.code_rubr in ('PX3S','PX3P')
                                                             and f1.period_pay_month = '""" + march_month_id + """'
                            where 1=1
                                and f.code_rubr in ('VPBS','VPPS','VPHS','VPBP','VPPP','VPHP','PX3S','PX3P')
                                and f.period_pay_month >= '""" + first_month_id + """'  
                                and f.period_pay_month <= '""" + month_id + """'  
                            group by f.employee_code, 
                                     f.code_rubr,
                                     f.employee_id
                           """).createOrReplaceTempView("vw_bonus")

// COMMAND ----------

// DBTITLE 1,Individual Amount
val dfIndVerse = spark.sql(""" select f.employee_code, 
                                      f.employee_id,
                                      sum(coalesce(bonus_amount,0) + coalesce(bonus_exceptional_psb_amount,0) + coalesce(bonus_pef_indiv_hojo_amount,0) + coalesce(bonus_perf_indiv_amount,0)) as ind_verse_amount
                                   
                            from vw_bonus f 
                            where 1=1
                            group by f.employee_code, 
                                     f.employee_id
                           """).filter($"ind_verse_amount" > 0).createOrReplaceTempView("vw_ind_verse")

// COMMAND ----------

// DBTITLE 1,Read Salary information
val bycontract_date = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bylast_salary = Window.partitionBy("employee_id","france_payroll_id").orderBy($"record_start_date".desc,$"date_raw_load_file".desc)
val byfirst_salary = Window.partitionBy("employee_id","france_payroll_id").orderBy($"record_start_date".asc,$"date_raw_load_file".desc)
val df_contract_read_salary = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                  .withColumn("rankcomp",rank() over bycontract_date)
                                                  .filter(col("rankcomp")==="1")
                                                 .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")

                                                 .filter("""ifnull(date_format(contract_end_date,'yyyyMM'),'299912') >= '""" + month_id + """'""") 

                                                 .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                  
 
                                                  .distinct



val bycompensation_date = Window.partitionBy("employee_id","france_payroll_id","effective_compensation_change_date").orderBy($"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,
                                                                                                                             $"record_creation_date".desc,$"effective_job_change_date".desc)

val bylastsalary = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date".desc)


val df_info_contract_salary = spark.table("hr.contract")
                              .filter("""date_format(effective_compensation_change_date,'yyyyMM') <= '""" + month_id + """'""")
                             .withColumn("rankcompsalary",rank() over bycompensation_date)
                              .filter(col("rankcompsalary")==="1")
                              .withColumn("previous_total_base_pay",lag($"total_base_pay",1) over byfirst_salary)
                              .withColumn("next_total_base_pay",lead($"total_base_pay",1) over byfirst_salary)
                              .withColumn("total_base_pay_13months",$"total_base_pay"/12*13)
                              .withColumn("previous_total_base_pay_13months",$"previous_total_base_pay"/12*13)
                              .withColumn("next_total_base_pay_13months",$"next_total_base_pay"/12*13)
                              .withColumn("last_total_base_pay",first($"total_base_pay") over bylast_salary)
                               .withColumn("last_total_base_pay_13months",$"last_total_base_pay"/12*13) 
                               .withColumn("ranklastsalary",rank() over bylastsalary)
                               .filter(col("ranklastsalary")==="1")
                               .withColumn("salary_rank",rank() over bylast_salary)
                              .distinct


val df_contract_salary = df_contract_read_salary.as("r")
                          .join(df_info_contract_salary.as("c"),$"r.employee_code" === $"c.employee_code","inner").select("c.contract_code",
                                                                                                                        "c.filename",
                                                                                                                         "c.salary_rank",
                                                                                                                         "c.compensation_change_code",
                                                                                                                        "c.compensation_bonus_plan_code",
                                                                                                                        "c.salary_rank",
                                                                                                                        "c.compensation_merit_plan_code",
                                                                                                                        "c.compensation_change_reason",
                                                                                                                        "c.compensation_change_subreason",
                                                                                                                        "c.effective_compensation_change_date",
                                                                                                                        "c.contract_type",
                                                                                                                        "c.compensation_merit_plan_label",
                                                                                                                        "c.employee_code",
                                                                                                                        "c.employee_id",
                                                                                                                        "c.france_payroll_id",
                                                                                                                        "c.contract_start_date",
                                                                                                                        "c.contract_end_date",
                                                                                                                        "c.fte",
                                                                                                                        "c.total_base_pay",
                                                                                                                        "c.foreign_travel_indemnity_amount",
                                                                                                                        "c.foreign_travel_indemnity_percent",
                                                                                                                        "c.primary_comp_basis_amount",
                                                                                                                        "c.period_salary_label",
                                                                                                                        "c.compensation_currency",
                                                                                                                        "c.bonus_target",
                                                                                                                        "c.previous_total_base_pay",
                                                                                                                        "c.next_total_base_pay",
                                                                                                                        "c.total_base_pay_13months",
                                                                                                                        "c.previous_total_base_pay_13months",
                                                                                                                        "c.next_total_base_pay_13months",
                                                                                                                        "c.last_total_base_pay",
                                                                                                                        "c.last_total_base_pay_13months")

                          //Salary
                        .join(df_contract_type.select("contract_code","contract_type").as("contract_type"),
                              ($"c.contract_code"===$"contract_type.contract_code"),"left")

                           .withColumn("last_base_pay",when(lower($"contract_type.contract_type") === "stagiaire",$"c.last_total_base_pay").otherwise($"c.last_total_base_pay"/12*13))
                          .withColumn("base_pay",when(lower($"contract_type.contract_type") === "stagiaire",$"c.total_base_pay").otherwise($"c.total_base_pay_13months"))
                          .withColumn("previous_base_pay",when(lower($"contract_type.contract_type") === "stagiaire",$"c.previous_total_base_pay").otherwise($"c.previous_total_base_pay_13months"))
                           .withColumn("next_base_pay",when(lower($"contract_type.contract_type") === "stagiaire",$"c.next_total_base_pay").otherwise($"c.next_total_base_pay_13months"))
                          .withColumn("delta_histo",when(lower($"c.compensation_change_subreason") =!= "brought to a minimum",1.0).otherwise(delta_histo))
                          .withColumn("pay_adjustment",when($"base_pay"-$"previous_base_pay">$"delta_histo" and date_format($"c.effective_compensation_change_date","yyyyMM") === month_id ,$"base_pay"-$"previous_base_pay").otherwise(lit(null)))
                          .withColumn("pct_adjustment",when($"base_pay"-$"previous_base_pay">$"delta_histo" and date_format($"c.effective_compensation_change_date","yyyyMM") === month_id ,$"base_pay"/$"previous_base_pay"-1).otherwise(lit(null)))
                          .distinct
                          .drop($"r.contract_code")
                          .drop($"contract_type.contract_code")
                          .drop($"contract_type.contract_type")
                                                                                                                    
                          .distinct
df_contract_salary.createOrReplaceTempView("vw_contract_salary")

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select employee_id,contract_start_date,contract_end_date,record_start_date,record_end_date,filename from hr.contract where employee_id = 'W00012981'

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select employee_id,effective_compensation_change_date,total_base_pay,bonus_target,record_start_date,record_end_date,filename from hr.contract where employee_id = 'W00012981'

// COMMAND ----------

// DBTITLE 1,Read Bonus from Get Workers
val bycompensation_date = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date".desc,$"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val df_contract_read_bonus = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                .filter($"bonus_target".isNotNull)
                                                .filter("""date_format(effective_compensation_change_date,'yyyyMM') <= '""" + month_id + """'""")
                                                //.filter("""ifnull(date_format(contract_end_date,'yyyyMM'),'299912') >= '""" + month_id + """'""")
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("rankcomp",rank() over bycompensation_date)
                                                .filter(col("rankcomp")==="1")
                                                .distinct

df_contract_read_bonus.createOrReplaceTempView("vw_contract_bonus")

// COMMAND ----------

// DBTITLE 1,Read Bonus Plan from Get Workers
val bycompensation_date = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date".asc,$"contract_start_date".desc,$"record_start_date".asc,$"date_raw_load_file".asc,$"record_modification_date".asc,$"record_creation_date".asc)
val df_contract_read_bonus_plan = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                .filter($"bonus_plan_name".isNotNull)
                                                .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")
                                                .filter("""ifnull(date_format(contract_end_date,'yyyyMM'),'299912') >= '""" + month_id + """'""")
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("rankcomp",rank() over bycompensation_date)
                                                .filter(col("rankcomp")==="1")
                                                .distinct

df_contract_read_bonus_plan.createOrReplaceTempView("vw_contract_bonus_plan")

// COMMAND ----------

// DBTITLE 1,Read Salary Last Month
val bycontract_salary_last_month = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date".desc,$"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_contract_read_salary_last_month = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                                   .filter("""date_format(effective_compensation_change_date,'yyyyMM') <= '""" + last_month + """'""")
                                                                   .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + last_month + """'""")
                                                                   .filter("""ifnull(date_format(contract_end_date,'yyyyMM'),'299912') >= '""" + last_month + """'""")
                                                                   .withColumn("rank",rank() over bycontract_salary_last_month)
                                                                   .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                                   .filter(col("rank")==="1")
                                                                   .distinct
                                                                   .withColumn("total_base_pay_13months",$"total_base_pay"/12*13)



val df_contract_salary_last_month = df_contract_read_salary_last_month.as("s")
                          .join(df_contract_type.as("ct"),$"ct.contract_code" === $"s.contract_code","left")
                          .withColumn("base_pay",when(lower($"ct.contract_type") === "stagiaire",$"total_base_pay").otherwise($"total_base_pay"/12*13))                          
                          .drop($"ct.contract_code")
                          .distinct
df_contract_salary_last_month.createOrReplaceTempView("vw_contract_salary_last_month")

// COMMAND ----------

// DBTITLE 1,Read Salary Last Year
val bycontract_salary_last_year = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date".desc,$"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_read_salary_last_year = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                .filter("""date_format(effective_compensation_change_date,'yyyyMM') <= '""" + last_month_previous_year + """'""") 
                                                .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + last_month_previous_year + """'""")
                                                .filter("""ifnull(date_format(contract_end_date,'yyyyMM'),'299912') >= '""" + last_month_previous_year + """'""")
                                                .withColumn("rank",rank() over bycontract_salary_last_year)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .filter(col("rank")==="1").distinct
                                                .withColumn("total_base_pay_13months",$"total_base_pay"/12*13)

df_contract_read_salary_last_year.createOrReplaceTempView("vw_contract_salary_last_year")

// COMMAND ----------

// DBTITLE 1,Get the month_id for psbnplus1
var month_id_psb = ""
if(month_id.toString <= (year_id.toString + daymonth_PSBN1.toString).substring(0,6) )
{
  month_id_psb = month_id
}
else
{
  month_id_psb = (year_id.toString + daymonth_PSBN1.toString).substring(0,6)
}

// COMMAND ----------

// DBTITLE 1,Get contract data for psbnplus1
val df_contract_read_psb = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                     .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id_psb + """'"""
                                                        )    
                                                
                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .withColumn("rank",rank() over bycontract)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .filter(col("rank")==="1").distinct
df_contract_read_psb.createOrReplaceTempView("vw_contract_psb")

// COMMAND ----------

// DBTITLE 1,Transfo for PSB N+1
val bypreviouscontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val df_previous_contract_read = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                          .filter("""contract_end_date >= to_date('"""+ year_id+"""0930','yyyyMMdd') and contract_end_date <= to_date('"""+ year_id + daymonth_PSBN1 + """','yyyyMMdd')"""
                                                                  
                                                                  
                                                        )                                                         
                                                .withColumn("rank_month",rank() over bypreviouscontract_month)
                                                .withColumn("rank",rank() over bycontract)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .filter(col("rank")==="1").distinct
                                                .as("contract").join(df_contract_type.as("ctype"),$"contract.contract_code" === $"ctype.contract_code").filter(lower($"ctype.precarity") === "precaire" )                                                
                                                .drop($"ctype.contract_code")
                                                .distinct
df_previous_contract_read.createOrReplaceTempView("vw_previous_contract")

// COMMAND ----------

// DBTITLE 1,Get employee eligible for psbnplus1
val df_is_eligible_psb_nplus1_read = spark.sql ("""
                                                 select  distinct 
                                                         c.employee_id
                                                        ,c.france_payroll_id
                                                        ,c.employee_code
                                                        ,1 as is_eligible_psb_nplus1  
                                                        ,"""+month_id+""" as period_pay_month

                                                 from    vw_employee e
                                                         inner join vw_contract_psb c on e.employee_code = c.employee_code                                                  
                                                         left join vw_d_contract_type ct on c.contract_code = ct.contract_code           
                                                         left join vw_previous_contract prev_c on prev_c.employee_code = c.employee_code 

                                                 where   1=1
                                                   and   lower(ct.contract_type) = ('cdi')
                                                   and   (c.contract_end_date is null or c.contract_end_date >= to_date('""" + year_id + daymonth_PSBN1 + """', 'yyyyMMdd'))
                                                   and   (c.contract_start_date < to_date('""" + year_id + """1001', 'yyyyMMdd') or  (c.contract_start_date >= to_date('""" + year_id + """1001', 'yyyyMMdd') 
                                                                                                                                      and c.contract_start_date <= to_date('""" + year_id + daymonth_PSBN1 + """', 'yyyyMMdd')
                                                                                                                                      and prev_c.employee_code is not null))
                   
""")

df_is_eligible_psb_nplus1_read.createOrReplaceTempView("vw_eligibilitypsbnplus1")

// COMMAND ----------

// DBTITLE 1,Increase Type Variables
val df_isPSB = spark.sql(""" 
  select employee_code, employee_id, is_eligible  
  from vw_psb
""").createOrReplaceTempView("vw_employeePSB")

val df_augmentationGenerale = spark.sql("""
  select
  
    e.employee_code,ag.percent_ag from vw_employee e

  inner join vw_d_legal_organization l
  on l.legal_organization_code = e.legal_organization_code

  inner join vw_ag_etablissement ag
  on ag.code_establishment = l.code_etablissement
""").createOrReplaceTempView("vw_augmentation_generale")

// COMMAND ----------

// DBTITLE 1,Calculate salary increase and salary information
//comparaison avec arrondi = à +/- 0,01%

val df_employee_salary_all = spark.sql(""" select 


                                        case 
                                            when ag.percent_ag is not null and (lower(cc.compensation_change_reason) = 'mérite' and lower(ct.contract_type) = 'cdi') and upper(cm.compensation_merit_plan_label) = 'AG + AI' and
                                            
                                              case
                                                when s.pay_adjustment is null 
                                                  then case when s.base_pay > slm.base_pay then s.base_pay/slm.base_pay-1  end
                                                else s.pct_adjustment
                                              end                

                                            between ag.percent_ag - 0.0001 and ag.percent_ag + 0.0001
                                            
                                            and lower(cc.compensation_change_reason) = 'mérite'
                                            
                                            THEN 'Uniquement AG'

                                            when ag.percent_ag is not null and (lower(cc.compensation_change_reason) = 'mérite' and lower(ct.contract_type) = 'cdd' ) and 
                                             
                                             case
                                                when s.pay_adjustment is null 
                                                  then case when s.base_pay > slm.base_pay then s.base_pay/slm.base_pay-1  end
                                                else s.pct_adjustment
                                              end  
                                            
                                            between ag.percent_ag - 0.0001 and ag.percent_ag + 0.0001 THEN 'Uniquement AG'

                                            when (lower(cc.compensation_change_reason) = 'mérite' and lower(ct.contract_type) = 'cdi') and upper(cm.compensation_merit_plan_label) = 'AI' and 
                                            
                                              case
                                                when s.pay_adjustment is null 
                                                  then case when s.base_pay > slm.base_pay then s.base_pay/slm.base_pay-1  end
                                                else s.pct_adjustment
                                              end  
                                              
                                              > 0 THEN 'Uniquement AI'

                                            when (lower(cc.compensation_change_reason) <> 'mérite' or (lower(cc.compensation_change_reason) = 'mérite' and lower(ct.contract_type) = 'cdd' ))  and 
                                            
                                              case
                                                when s.pay_adjustment is null 
                                                  then case when s.base_pay > slm.base_pay then s.base_pay/slm.base_pay-1  end
                                                else s.pct_adjustment
                                              end  
                                              
                                            > 0 THEN 'Uniquement AI'

                                            when ag.percent_ag is not null and upper(cm.compensation_merit_plan_label) = 'AG + AI' 
                                            and lower(cc.compensation_change_reason) = 'mérite' 
                                            and ag.percent_ag > 0  and
                                              case
                                                when s.pay_adjustment is null 
                                                  then case when s.base_pay > slm.base_pay then s.base_pay/slm.base_pay-1  end
                                                else s.pct_adjustment
                                              end  
                                            > ag.percent_ag + 0.0001 THEN 'AG + AI'

                                            when ag.percent_ag is not null and upper(cm.compensation_merit_plan_label) = 'AG + AI' 
                                            and lower(cc.compensation_change_reason) = 'mérite' 
                                            and ag.percent_ag = 0  and
                                              case
                                                when s.pay_adjustment is null 
                                                  then case when s.base_pay > slm.base_pay then s.base_pay/slm.base_pay-1  end
                                                else s.pct_adjustment
                                              end  
                                            > 0 THEN 'Uniquement AI'

                                            /* CR: specific case for 2021 as there are no AG increases */
                                            when ag.percent_ag is not null and upper(cm.compensation_merit_plan_label) = 'AG + AI' and 
                                             
                                            lower(cc.compensation_change_reason) <> 'mérite' THEN 'Uniquement AI'

                                            when ag.percent_ag is not null and lower(ct.contract_type) = 'cdd' and 
                                              case
                                                when s.pay_adjustment is null 
                                                  then case when s.base_pay > slm.base_pay then s.base_pay/slm.base_pay-1  end
                                                else s.pct_adjustment
                                              end  
                                            > ag.percent_ag + 0.0001 
                                            
                                            and ag.percent_ag > 0
                                            THEN 'AG + AI'

                                            when ag.percent_ag is not null and lower(ct.contract_type) = 'cdd' and 
                                              case
                                                when s.pay_adjustment is null 
                                                  then case when s.base_pay > slm.base_pay then s.base_pay/slm.base_pay-1  end
                                                else s.pct_adjustment
                                              end  
                                            > 0
                                            
                                            and ag.percent_ag = 0
                                            THEN 'Uniquement AI'

                                            /* CR : Specific case expat*/
                                            when ag.percent_ag is not null and lower(ct.contract_type) = 'détaché'
                                            and upper(cm.compensation_merit_plan_label) = 'AI' and lower(cc.compensation_change_reason) = 'mérite' and
                                              case
                                                when s.pay_adjustment is null 
                                                  then case when s.base_pay > slm.base_pay then s.base_pay/slm.base_pay-1  end
                                                else s.pct_adjustment
                                              end  
                                            > 0 THEN 'Uniquement AI'


                                          END increase_type 

                                        ,s.employee_code
                                        ,s.employee_id,s.france_payroll_id

                                        ,s.base_pay as annual_contractual_pay_amount
                                        ,slm.base_pay as annual_contractual_pay_m_1_amount
                                        ,case when lower(ct.contract_type) in ('stagiaire') then sly.total_base_pay else sly.total_base_pay_13months end as annual_contractual_pay_n_1_amount
                                        
                                        ,case 
                                         when 
                                            lower(ct.contract_type) in ('cdi','cdd','détaché') 
                                            and 
                                            (s.contract_start_date = slm.contract_start_date or s.contract_start_date = date_add(slm.contract_end_date,1))
                                            and
                                            (ct.contract_nature_label = ctlm.contract_nature_label or (lower(ctlm.contract_type) in ('cdi','détaché') and lower(ct.contract_type) in ('cdi','détaché')))
                                            and
                                             slm.fte <> s.fte
                                            and
                                            ifnull(slm.total_base_pay,0) > 0
                                            and
                                            (ifnull(s.pay_adjustment,0) > 0
                                              or
                                              (ifnull(s.pay_adjustment,0) = 0 
                                                and (round(s.base_pay,1) - round(slm.base_pay,1)) <1
                                                and ((round(s.next_base_pay,1) - round(s.base_pay,1)) < 1 or next_base_pay is null)
                                              )
                                            )
                                            then null
                                        
                                         when 
                                            lower(ct.contract_type) in ('cdi','cdd','détaché') 
                                            and 
                                            (s.contract_start_date = slm.contract_start_date or s.contract_start_date = date_add(slm.contract_end_date,1))
                                            and
                                            (ct.contract_nature_label = ctlm.contract_nature_label or (lower(ctlm.contract_type) in ('cdi','détaché') and lower(ct.contract_type) in ('cdi','détaché')))
                                            and
                                            ifnull(slm.total_base_pay,0) > 0
                                            and
                                            (ifnull(s.pay_adjustment,0) > 0
                                              or
                                              (ifnull(s.pay_adjustment,0) = 0 
                                                and round(s.base_pay,1) > (round(slm.base_pay,1) + case when lower(s.compensation_change_subreason) != 'brought to a minimum' then 1.0 else  """ + delta_histo + """ end)
                                                and (round(s.next_base_pay,1) > (round(s.base_pay,1) + case when lower(s.compensation_change_subreason) != 'brought to a minimum' then 1.0 else  """ + delta_histo + """ end) or next_base_pay is null)
                                              )
                                            ) 
                                            
                                           then 1 else null end as is_pay_increase
                                        
                                        
                                        
                                        ,case when lower(ct.contract_type) in ('cdi','cdd','détaché') then
                                              case when (s.contract_start_date = slm.contract_start_date or s.contract_start_date = date_add(slm.contract_end_date,1)) and  (ct.contract_nature_label = ctlm.contract_nature_label or (lower(ctlm.contract_type) in ('cdi','détaché') and lower(ct.contract_type) in ('cdi','détaché'))) and slm.total_base_pay is not null and (s.pay_adjustment is not null or (s.pay_adjustment is null and round(s.base_pay,1) > round(slm.base_pay,2) + case when lower(s.compensation_change_subreason) != 'brought to a minimum' then 1.0 else  """ + delta_histo + """ end))
                                         and ifnull(slm.total_base_pay,0) > 0
                                              
                                                then 
                                                
                                                  case
                                                    when s.pay_adjustment is null 
                                                      then case when round(s.base_pay,1) > round(slm.base_pay,1) + (1) then s.base_pay - slm.base_pay  end
                                                    else s.pay_adjustment
                                                  end                                              
                                              
                                                else null end else null end as pay_increase_amount

                                        ,s.total_base_pay        
                                        ,slm.total_base_pay as total_base_pay_m_1        
                                        ,sly.total_base_pay as total_base_pay_y_1
                                        
                                        ,case
                                                when s.pay_adjustment is null 
                                                  then case when round(s.base_pay,1) > round(slm.base_pay,1) + (1.0) then s.base_pay/slm.base_pay-1  end
                                                else s.pct_adjustment
                                              end  as increase_pct

                                        ,s.foreign_travel_indemnity_amount
                                        ,s.foreign_travel_indemnity_percent
                                        ,s.primary_comp_basis_amount
                                        ,case when s.period_salary_label = '13th month' or s.period_salary_label like '13%' then s.total_base_pay else null end as month_13th_amount
                                        ,case when s.filename = 'histo_file' and s.bonus_target is null then bo.bonus_target else s.bonus_target end as bonus_target
                                        ,s.compensation_currency
                                        ,psb.is_eligible
                                        ,upper(cm.compensation_merit_plan_label) compensation_merit_plan_label
                                        ,lower(cc.compensation_change_reason) compensation_change_reason 
                                        ,lower(cc.compensation_change_subreason) compensation_change_subreason 
                                        ,ag.percent_ag as pourcentage_ag
                                        ,ct.contract_type

                                        ,coalesce(cc.compensation_change_id,-1) as compensation_change_id

                                        ,coalesce(cm.compensation_merit_plan_id,-1) as compensation_merit_plan_id

                                        ,coalesce(cb.compensation_bonus_plan_id,-1) as compensation_bonus_plan_id
                                        
                                       ,psb.is_eligible as is_eligible_psb
                                       ,psbnplus1.is_eligible_psb_nplus1 as is_eligible_psb_nplus1
                                       ,s.salary_rank
                                       ,slm.fte
                                       ,s.fte
                                       ,s.pay_adjustment
                                       ,s.compensation_change_subreason
                                       ,round(case when s.total_base_pay = 0 or (bo.bonus_target is null and s.bonus_target is null) or ((bo.bonus_target <= 0 and s.bonus_target <=0))  then -1
                                                        when idv.ind_verse_amount <= 0 or idv.ind_verse_amount is null then 0
                                                       else (idv.ind_verse_amount/(case when s.filename = 'histo_file' then bo.bonus_target else s.bonus_target end * case when lower(ct.contract_type) in ('stagiaire') then s.total_base_pay else (s.total_base_pay/12)*13 end))*100 end,1)  as percent_payout
                                   
                                
                                  from  vw_contract_salary s

                                        left join vw_contract_salary_last_month slm on s.employee_code = slm.employee_code
                                        left join vw_contract_salary_last_year sly on s.employee_code = sly.employee_code
                                        left join vw_d_contract_type ct on ct.contract_code = s.contract_code 
                                        left join vw_d_contract_type ctlm on ctlm.contract_code = slm.contract_code 
                                        left join vw_employeePSB psb on psb.employee_code = s.employee_code
                                        left join vw_eligibilitypsbnplus1 psbnplus1 on psbnplus1.employee_code = s.employee_code
                                        left join vw_augmentation_generale ag on ag.employee_code = s.employee_code
                                        left join vw_contract_bonus bo on bo.employee_code = s.employee_code
                                        left join vw_contract_bonus_plan bop on bop.employee_code = s.employee_code
                                        left join vw_d_compensation_bonus_plan cb on cb.compensation_bonus_plan_code = (case when s.filename = 'histo_file' and s.compensation_bonus_plan_code is null then bop.compensation_bonus_plan_code else s.compensation_bonus_plan_code end)
                                        left join vw_d_compensation_change cc on cc.compensation_change_code = s.compensation_change_code
                                        left join vw_d_compensation_merit_plan cm on cm.compensation_merit_plan_code = s.compensation_merit_plan_code                                        
                                        left join vw_ind_verse idv on idv.employee_code = s.employee_code
                                  where
                                    not (s.base_pay = slm.base_pay and s.salary_rank > 1) 


""").createOrReplaceTempView("vw_contract_salary_full")

// COMMAND ----------

// DBTITLE 1,Query Compensation
val query_compensation = """ select distinct

                         s.is_pay_increase
                         ,case when s.is_pay_increase = 1 then s.pay_increase_amount end as pay_increase_amount
                         ,s.total_base_pay        
                         ,s.annual_contractual_pay_amount
                         ,s.annual_contractual_pay_n_1_amount
                         ,s.annual_contractual_pay_m_1_amount  
                         ,s.foreign_travel_indemnity_amount
                         ,s.foreign_travel_indemnity_percent                         
                         ,s.primary_comp_basis_amount
                         ,s.month_13th_amount
                         ,s.bonus_target
                         ,s.compensation_currency
                                             
                       
                         ,coalesce(d.employee_id, -1) as employee_id
                         ,coalesce(ct.contract_type_id, -1) as contract_type_id
                         ,coalesce(wr.worker_rate_id, -1) as worker_rate_id
                         ,case when upper(c.contract_type) = 'VA' or  lower(ct.contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else coalesce(csp.csp_id, -1) end as csp_id
                         ,coalesce(nat.nationality_id, -1) as nationality_id
                         ,coalesce(ag.range_age_id, -1) as range_age_id
                         ,coalesce(sec.seniority_company_id, -1) as seniority_company_id
                         ,coalesce(sep.seniority_position_id, -1) as seniority_position_id
                         ,coalesce(loc.location_id,-1) as location_id
                         ,coalesce(job.job_architecture_id, -1) as job_architecture_id
                         ,coalesce(man.manager_id, -1) as manager_id
                         ,coalesce(so.supervisory_organization_id, -1) as supervisory_organization_id
                         ,coalesce(ol.legal_organization_id,'-1') as legal_organization_id
                         ,coalesce(op.operational_organization_id,'-1') as operational_organization_id
                         ,coalesce(mob_in.mobility_in_id, -1) as mobility_in_id
                         ,coalesce(mob_out.mobility_out_id,-1) as mobility_out_id
                         ,coalesce(id.info_dates_id, -1) as info_dates_id
                         ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
                         ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
                         ,-1 as payroll_id
                         
                         ,case when s.is_pay_increase = 1 then s.compensation_change_id else -2 end compensation_change_id
                         ,case when s.is_pay_increase = 1 then s.compensation_merit_plan_id else -2 end compensation_merit_plan_id
                         ,ifnull(s.compensation_bonus_plan_id,-1) as compensation_bonus_plan_id
                         
                         ,case when s.is_pay_increase = 1 then ifnull(it.increase_type_id,-1) else -2 end increase_type_id
                         
                         ,-1 as action_housing_id
                         ,coalesce(rp.range_payout_id, -1) as range_payout_id     
                         
                         ,-1 as range_percol_id
                         
                         ,case when s.is_eligible_psb_nplus1 = 1 
                               then (case when s.is_eligible_psb=1 then 1 else 2 end) 
                               else (case when s.is_eligible_psb=1 then 3 else -1 end)  end as eligibility_psb_id     


                         ,""" + date_id + """ as date_id
                         ,current_timestamp() as recordcreationdate
                         ,'""" + runid + """' as runid
                         
                         ,case when s.compensation_bonus_plan_id > 0 and (c.contract_end_date is null or date_format(c.contract_end_date, 'yyyyMM') >= """ + month_id + """) then 1 else null end  as is_compensation_bonus_plan
                         ,case when s.salary_rank = 1 then 1 else 0 end is_active_compensation
                         ,coalesce(rpd.range_payout_detailed_id, -1) as range_payout_detailed_id
                         ,case when s.is_eligible is not null then 1 else null end as is_eligible_psb
                         ,case when s.is_eligible_psb_nplus1 is not null then 1 else null end as is_eligible_psb_nplus1 
                         
                         ,case when lower(csp.cadre_non_cadre) = 'cadre' and lower(ct.contract_type) in ('cdi', 'cdd', 'alternant') and abs.abs_days_fte is not null then abs_days_fte*(s.annual_contractual_pay_amount/365)* """ + taux_charges_patronales_cadre + """
                               when lower(csp.cadre_non_cadre) = 'non cadre' and lower(ct.contract_type) in ('cdi', 'cdd', 'alternant') and abs_days_fte is not null then abs_days_fte*(s.annual_contractual_pay_amount/365)* """ + taux_charges_patronales_non_cadre + """ end as cost_absence
                         
                   from vw_contract_salary_full  s 
                        inner join vw_employee e on e.employee_code = s.employee_code
                        inner join vw_contract c on e.employee_code = c.employee_code
                        
                        left join vw_d_employee d on e.employee_code = d.employee_code
                        left join vw_d_nationality nat on e.nationality_code = nat.nationality_code
                        left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date('""" + date_id + """','yyyyMMdd'),e.birth_date,true)/12) end)
                        left join vw_d_location loc on e.location_code = loc.location_code
                        left join vw_d_manager man on e.manager_code = man.manager_code
                        left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code
                        left join vw_d_legal_organization ol on e.legal_organization_code = ol.legal_organization_code
                        left join vw_d_operational_organization op on e.operational_organization_code = op.operational_organization_code
                        left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code
                        left join vw_d_in_out_dates iod on iod.in_out_dates_code = c.in_out_dates_code and iod.org_in_out_dates_code = e.org_in_out_dates_code
                        
                        left join vw_d_mobility_in mob_in on mob_in.mobility_in_code = c.mobility_in_code
                        left join vw_d_mobility_out mob_out on mob_out.mobility_out_code = c.mobility_out_code
                        
                        left join vw_contract_job_change ccc on ccc.employee_code = c.employee_code 
                                                            and c.contract_start_date = ccc.contract_start_date 
                                                            and ccc.rank=1                                                              
                        left join vw_d_worker_rate wr on ccc.worker_rate_code = wr.worker_rate_code                                          
                        left join vw_d_csp csp on ccc.csp_code = csp.csp_code           
                               
                        left join vw_d_contract_type ct on c.contract_type_code = ct.contract_type_code
                                                       and ccc.collective_agreement_code = ct.collective_agreement_code
                                                       
                        left join vw_d_job_architecture job on ccc.job_title_code = job.job_title_code    
                                                           and coalesce(ccc.grade_code, -1) = coalesce(job.grade_code, -1) 
                               
                        left join vw_d_info_dates id on id.company_dates_code = ccc.company_dates_code 
                                                    and id.contract_dates_code = c.contract_dates_code     
                         
                        left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(ccc.continous_service_date) then null else datediff(to_date(c.seniority_date_max),to_date(ccc.continous_service_date)) end)
                        left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(ccc.position_start_date) then null else datediff(to_date(c.seniority_date_max),to_date(ccc.position_start_date)) end)
                      
                        left join vw_d_increase_type it on s.increase_type = it.increase_type_detailed 
                        
                        left join vw_employee_absencedays abs on abs.employee_code = c.employee_code
                         
                        left join vw_d_range_payout rp on coalesce(s.percent_payout,-1) between rp.range_payout_min and rp.range_payout_max
                        left join vw_d_range_payout_detailed rpd on coalesce(s.percent_payout,-1) between rpd.range_payout_min_detailed and rpd.range_payout_max_detailed  
                           
                   """

// COMMAND ----------

val df_compensation_results = spark.sql(query_compensation)
//put the dataframe ont he cache
//val inserted_records = df_pay_results.cache().count().toInt //count the number of read records


// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """Exec [dbo].[usp_deletePartitionTableData] 'f_compensation','pay','myMonthlyRangePS',""" + date_id
val res = stmt.execute(query_delete)

// COMMAND ----------


df_compensation_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "pay.f_compensation", connectionproperties)


// COMMAND ----------

val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from Cache
df_employee_read.unpersist
df_augmentation_generale_read.unpersist
df_pay_read_full.unpersist

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)