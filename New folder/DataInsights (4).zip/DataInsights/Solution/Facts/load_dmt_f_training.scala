// Databricks notebook source
// DBTITLE 1,Get Parameters values: load_date and runid
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val historical_data_end_date = dbutils.widgets.get("historical_data_end_date");
val default_hierarchy_value="Non Affecté"
val start_date = "2017-01-01"//dbutils.widgets.get("start_date");

// COMMAND ----------

// DBTITLE 1,Include functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Refresh delta table contract
 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table employee
 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table training
 if(spark.catalog.tableExists("hr.training")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.training")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table training evaluation
 if(spark.catalog.tableExists("hr.training_evaluation")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.training_evaluation")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Set variables
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_start_month = date_value.withDayOfMonth(1)
val date_next_month = date_end_month.plusDays(1)
val date_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + ("%02d".format(date_value.getDayOfMonth))
val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))
val year_id = date_value.getYear()
val last_year_id = date_value.plusYears(-1).getYear()
val month_next_id = date_next_month.getYear() + ("%02d".format(date_next_month.getMonth.getValue()))
val startdate_value = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))



// COMMAND ----------

// DBTITLE 1,Get Dimensions data
spark.read.jdbc(jdbcurl, "dbo.d_date", connectionproperties).filter(col("month_id") === lit(month_id)).createOrReplaceTempView("vw_d_date")
spark.read.jdbc(jdbcurl, "staff.d_employee", connectionproperties).select("employee_id", "employee_code", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_employee")
spark.read.jdbc(jdbcurl, "staff.d_worker_rate", connectionproperties).select("worker_rate_id", "worker_rate_code", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_worker_rate")
spark.read.jdbc(jdbcurl, "staff.d_nationality", connectionproperties).select("nationality_id", "nationality_code").filter("current_version = 1").createOrReplaceTempView("vw_d_nationality")
spark.read.jdbc(jdbcurl, "staff.d_range_age", connectionproperties).select("range_age_id", "range_age").filter("current_version = 1").createOrReplaceTempView("vw_d_range_age")
spark.read.jdbc(jdbcurl, "staff.d_seniority_company", connectionproperties).select("seniority_company_id", "range_seniority_company_age").filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_company")
spark.read.jdbc(jdbcurl, "staff.d_seniority_position", connectionproperties).select("seniority_position_id", "range_seniority_position_age").filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_position")
spark.read.jdbc(jdbcurl, "staff.d_location", connectionproperties).select("location_id", "location_code").filter("current_version = 1").createOrReplaceTempView("vw_d_location")
spark.read.jdbc(jdbcurl, "staff.d_job_architecture", connectionproperties).select("job_architecture_id", "job_architecture_code").filter("current_version = 1").createOrReplaceTempView("vw_d_job_architecture")
spark.read.jdbc(jdbcurl, "staff.d_manager", connectionproperties).select("manager_id", "manager_code").filter("current_version = 1").createOrReplaceTempView("vw_d_manager")
spark.read.jdbc(jdbcurl, "staff.d_supervisory_organization", connectionproperties).select("supervisory_organization_id", "supervisory_organization_code").filter("current_version = 1").createOrReplaceTempView("vw_d_supervisory_organization")
spark.read.jdbc(jdbcurl, "staff.d_contract_suspension", connectionproperties).select("contract_suspension_id", "contract_suspension_code", "libelle_categorie").filter("current_version = 1").createOrReplaceTempView("vw_d_contract_suspension")


// COMMAND ----------

//lookup for training cost
val df_d_legal_org = spark.read.jdbc(jdbcurl, "staff.d_legal_organization", connectionproperties).select("legal_organization_id", "legal_organization_code", "company", "libelle_etablissement","hashkey").filter("current_version = 1")

val df_d_csp = spark.read.jdbc(jdbcurl, "staff.d_csp", connectionproperties).select("csp_id","csp", "csp_code", "professional_category_reference").filter("current_version = 1")
df_d_csp.createOrReplaceTempView("vw_d_csp")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_legal_organization", connectionproperties).select("legal_organization_id", "legal_organization_code", "company", "libelle_etablissement","hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_legal_organization")
spark.read.jdbc(jdbcurl, "staff.d_operational_organization", connectionproperties).select("operational_organization_id", "operational_organization_code", "division_consolidated", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_operational_organization")

spark.read.jdbc(jdbcurl, "staff.vw_d_legal_organization", connectionproperties).select("legal_organization_id", "company", "libelle_etablissement").createOrReplaceTempView("vw_d_legal_organization_transcoded")

spark.read.jdbc(jdbcurl, "staff.d_info_dates", connectionproperties).select("info_dates_id", "info_dates_code", "position_start_date", "hire_date", "contract_start_date", "contract_end_date", "contract_dates_code","company_dates_code").filter("current_version = 1").createOrReplaceTempView("vw_d_info_dates")

spark.read.jdbc(jdbcurl, "staff.d_hierarchy_pb", connectionproperties).filter("current_version = 1").select("hierarchy_pb_id", "cost_center_code").createOrReplaceTempView("vw_d_hierarchy_pb")
// training dimension
spark.read.jdbc(jdbcurl, "training.d_training_type", connectionproperties).filter("current_version = 1").select("training_type_id", "training_type_code").createOrReplaceTempView("vw_d_training_type")

val df_training_status = 
spark.read.jdbc(jdbcurl, "training.d_training_status", connectionproperties).filter("current_version = 1").select("training_status_id","training_status_label" ,"training_status_code","consolidated_training_status")
df_training_status.createOrReplaceTempView("vw_d_training_status")

val df_contract_type = spark.read.jdbc(jdbcurl, "staff.d_contract_type", connectionproperties).select("contract_type_id", "contract_code","contract_type_code","precarity","contract_type","contract_type_detailed", "worker_type", "collective_agreement_reference", "collective_agreement_group", "collective_agreement_level","classification_collective_agreement","contract_nature","collective_agreement_code").filter("current_version = 1")
df_contract_type.createOrReplaceTempView("vw_d_contract_type")

// COMMAND ----------

val df_training_scope = spark.read.jdbc(jdbcurl, "dbo.vw_ref_training_scope", connectionproperties)
df_training_scope.createOrReplaceTempView("vw_ref_training_scope")

// COMMAND ----------

// DBTITLE 1,Employee data
val by_orgdate = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"cost_center_start_date")

val df_employee_read = spark.table("hr.employee")
                            .distinct
                            .withColumn("cost_center_start_date", $"effective_organization_change_date")
//                            .withColumn("cost_center_end_date",date_sub(lead($"cost_center_start_date",1) over by_orgdate,1))
//                            .withColumn("cost_center_end_date",coalesce($"cost_center_end_date",to_date(lit("2999-12-31"))))
                            .filter(col("record_start_date") <= lit(date_value))
df_employee_read.createOrReplaceTempView("vw_employee")

// Retrieve employee's organization and rebuild dates based on effective_organization_change_date and rebuild end date
val byorg_version = Window.partitionBy("employee_code","employee_id","france_payroll_id","cost_center_start_date").orderBy($"record_start_date".desc,$"record_end_date".desc)
val byorg_order = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"cost_center_start_date")

val df_employeehr_ope_org = spark.table("hr.employee")
.withColumn("cost_center_start_date", $"effective_organization_change_date")
.withColumn("rank",rank() over byorg_version).filter($"rank" === 1).drop("rank")
.select("employee_code","employee_id","france_payroll_id","cost_center_code","cost_center_start_date","legal_organization_code","operational_organization_code"
                   
                    ,"record_start_date"
                    ,"record_end_date"
       ).filter($"cost_center_code".isNotNull)
.withColumn("previous_cc",lag($"cost_center_code",1) over byorg_order)
.withColumn("previous_lo",lag($"legal_organization_code",1) over byorg_order)
.withColumn("previous_oo",lag($"operational_organization_code",1) over byorg_order)
.filter(($"previous_cc" =!= $"cost_center_code" or $"previous_cc".isNull) || ($"previous_lo" =!= $"legal_organization_code" or $"previous_lo".isNull)  || ($"previous_oo" =!= $"operational_organization_code" or $"previous_oo".isNull))
.drop($"previous_cc")
.drop($"previous_lo")
.drop($"previous_oo")
.withColumn("cost_center_end_date",date_sub(lead($"cost_center_start_date",1) over by_orgdate,1))
.withColumn("cost_center_end_date",coalesce($"cost_center_end_date",to_date(lit("2999-12-31"))))
.orderBy(asc("employee_code"),asc("record_start_date"))
df_employeehr_ope_org.createOrReplaceTempView("vw_organization")

// last version of each contract without retroactivity
val bycontract_start = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract_order = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"contract_start_date")
  val df_contractstart_read = spark.table("hr.contract")
                                                .withColumn("rank_start",rank() over bycontract_start)
                                                .withColumn("contract_end_date",when($"contract_end_date".isNull,to_date(lit("2999-12-31"))).otherwise($"contract_end_date"))
                                                .withColumn("contract_start_date_month",when($"contract_end_date"<last_day($"contract_start_date") and $"contract_end_date".isNotNull,$"contract_end_date").otherwise(last_day($"contract_start_date")))
                                                .withColumn("seniority_date_max",when($"contract_end_date" === "2999-12-31" or $"contract_end_date".isNull or $"contract_end_date" > lit(load_date), lit(load_date)).otherwise($"contract_end_date"))

                                                .filter(col("rank_start")==="1")
                                                // manage date to retrive contract of the month
                                                .withColumn("previous_end_date",lag($"contract_end_date",1) over bycontract_order)
                                                .withColumn("next_start_date",lead($"contract_start_date",1) over bycontract_order)
                                                .withColumn("next_end_date",lead($"contract_end_date",1) over bycontract_order)
                                                .withColumn("previous_start_date",lag($"contract_start_date",1) over bycontract_order)
//manage start date to retrieve trainings started before first contract
.withColumn("contract_start_date",when($"previous_end_date".isNull,when($"contract_start_date" < startdate_value,$"contract_start_date").otherwise(startdate_value)).otherwise(when(last_day($"previous_end_date") < $"contract_start_date",date_add(last_day(add_months($"contract_start_date", -1)),1)).otherwise($"contract_start_date")))
.withColumn("new_contract_start_date",when($"previous_end_date".isNull,when($"contract_start_date" < startdate_value,$"contract_start_date").otherwise(startdate_value)).otherwise(date_add($"previous_end_date",1)))
//manage end date to map trainings ended after last contract 
.withColumn("contract_end_date",when($"next_end_date" === "2999-12-31",date_sub($"next_start_date",1)).otherwise(when($"next_start_date".isNull,to_date(lit("2999-12-31"))).otherwise(when(last_day($"contract_end_date") < $"next_start_date",last_day($"contract_end_date")).otherwise($"contract_end_date"))))
                                                
df_contractstart_read.createOrReplaceTempView("vw_contractstart")


//contract job change 
val bycontract_date = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"effective_job_change_date")
val bycontract_version = Window.partitionBy("employee_code","employee_id","france_payroll_id","effective_job_change_date").orderBy($"record_start_date".desc)
val df_contracthr_change = spark.table("hr.contract")
.select(
  "employee_code","employee_id","france_payroll_id"
  ,"contract_start_date"
  ,"contract_type"
  ,"worker_type"
  ,"collective_agreement_reference"
  ,"collective_agreement_group"
  ,"collective_agreement_level"
  ,"coefficient_label"
  ,"fte"
  ,"worker_rate_code"
  ,"effective_job_change_date"
  ,"record_start_date"
  ,"job_code"
  ,"csp_code"
  ,"worker_rate_code"
  ,"info_dates_code"
  ,"in_out_dates_code" 
  ,"contract_dates_code"
  ,"company_dates_code"
).filter($"contract_start_date".isNotNull)
.withColumn("rank",rank() over bycontract_version).filter($"rank" === 1).drop("rank","record_start_date")

.orderBy("employee_code","effective_job_change_date")
.withColumn("record_end_date",date_sub(lead($"effective_job_change_date",1) over bycontract_date,1))
.withColumn("prev_record_start",lag($"effective_job_change_date",1) over bycontract_date)
.withColumn("record_start_date",$"effective_job_change_date")
.withColumn("record_start_date",when($"prev_record_start".isNull,when($"record_start_date" < startdate_value,$"record_start_date").otherwise(startdate_value)).otherwise($"record_start_date"))
.withColumn("record_end_date",coalesce($"record_end_date",to_date(lit("2999-12-31"))))
.orderBy(asc("employee_code"),asc("record_start_date"))
df_contracthr_change.createOrReplaceTempView("vw_contract_jobchange")

// Build the employee view for each org change
val joinCondition_org = $"org.employee_code" === $"contract.employee_code" and (
                            ($"org.cost_center_start_date" <= $"contract.contract_start_date"  and  $"org.cost_center_end_date" >= $"contract.contract_start_date")
                            or
                            ($"org.cost_center_start_date" >= $"contract.contract_start_date"  and  $"org.cost_center_start_date" <= $"contract.contract_end_date")
                            or (($"contract.contract_end_date" === to_date(lit("2999-12-31")) or $"contract.contract_end_date".isNull) and $"org.cost_center_start_date" >= $"contract.contract_start_date")
                            
                        )


val joinCondition_job = $"emp.employee_code" === $"job.employee_code" and 
(
                            ($"job.record_start_date" >= $"emp.new_cost_center_start_date" and $"job.record_start_date" <= $"emp.new_cost_center_end_date")
                            or
                            ($"emp.new_cost_center_start_date" >= $"job.record_start_date" and $"emp.new_cost_center_start_date" <= $"job.record_end_date")
                        )
/*
(
                            ($"job.record_start_date" >= $"emp.contract_start_date" and ($"job.record_start_date" <= $"emp.contract_end_date" or $"emp.contract_end_date".isNull))
                            or
                            ($"job.record_end_date" >= $"emp.contract_start_date" and ($"job.record_end_date" <= $"emp.contract_end_date" or $"emp.contract_end_date".isNull))
                          )
*/
val joinCondition_emp = $"emp.employee_code" === $"e.employee_code" and (
                            ($"e.cost_center_start_date" >= $"emp.new_cost_center_start_date" and $"e.cost_center_start_date" <= $"emp.new_cost_center_end_date")
                            or
                            ($"emp.new_cost_center_start_date" >= $"e.cost_center_start_date" and $"emp.new_cost_center_start_date" <= $"e.cost_center_end_date")
                        )

val byemployee_cc_start = Window.partitionBy("emp.employee_code","emp.new_cost_center_start_date","emp.contract_start_date").orderBy($"e.record_start_date".desc,$"e.date_raw_load_file".desc,$"e.record_modification_date".desc)
val byemployeeid = Window.partitionBy("emp.france_payroll_id").orderBy($"emp.employee_id".desc)

val byemployee_cc_start_new = Window.partitionBy("emp.employee_code").orderBy($"emp.new_cost_center_start_date",$"job.record_start_date")

val df_employee_contract = df_employeehr_ope_org.as("org").join(df_contractstart_read.as("contract"),joinCondition_org)
                  .withColumn("new_cost_center_start_date",when($"contract.contract_start_date" > $"org.cost_center_start_date",$"contract.contract_start_date").otherwise($"org.cost_center_start_date"))
                  .withColumn("new_cost_center_end_date",when($"contract.contract_end_date" < $"org.cost_center_end_date",$"contract.contract_end_date").otherwise($"org.cost_center_end_date"))
                  .withColumn("new_cost_center_end_date",when($"new_cost_center_end_date".isNull,to_date(lit("2999-12-31"))).otherwise($"new_cost_center_end_date"))
                  .select(
                    "org.employee_code"
                    ,"org.employee_id"
                    ,"org.france_payroll_id"
                    ,"org.cost_center_code"
                    ,"org.legal_organization_code"
                    ,"org.operational_organization_code"

                    ,"new_cost_center_start_date"
                    ,"new_cost_center_end_date"
                    ,"contract.contract_type"
                    ,"contract.contract_start_date"
                    ,"contract.contract_end_date"
                    ,"contract.position_start_date"
                    ,"contract.continous_service_date"        
                    ,"contract.original_hire_date"
                    ,"contract.collective_agreement_reference"
                    ,"contract.collective_agreement_group"
                    ,"contract.collective_agreement_level"
                    ,"contract.coefficient_label"
                    ,"contract.contract_code"
                    ,"contract.seniority_date_max"
                    ,"contract.previous_end_date"
                    ,"contract.next_start_date"
                  )
                  .as("emp")
                  .join(df_contracthr_change.as("job"),joinCondition_job,"left")
                  //.filter($"new_cost_center_start_date" >= $"job.record_start_date" and $"new_cost_center_start_date" <= $"job.record_end_date")
  

                  .join(df_employee_read.as("e"),joinCondition_emp,"left")
                  .withColumn("rank",rank() over byemployee_cc_start).filter($"rank" === 1).drop("rank")

                  .join(df_d_legal_org.as("lo"),$"lo.legal_organization_code" === $"emp.legal_organization_code","left")
                  .join(df_d_csp.as("csp"),$"csp.csp_code" === $"job.csp_code","left")

                  .select(
                     "emp.employee_code"
                    ,"emp.employee_id"
                    ,"emp.france_payroll_id"
                    ,"emp.cost_center_code"
                    ,"emp.new_cost_center_start_date"
                    ,"emp.new_cost_center_end_date"
                    ,"emp.legal_organization_code"
                    ,"lo.libelle_etablissement"
                    ,"emp.operational_organization_code"
                    //last version of emp data
                    ,"e.effective_organization_change_date"
                    ,"e.effective_suporg_change_date"
                    ,"e.nationality_code"
                    ,"e.birth_date"
                    ,"e.location_code"               
                    ,"e.manager_code"
                    ,"e.supervisory_organization_code"
                    ,"e.establishment_start_date"
                    ,"e.establishment_end_date"
                    ,"e.company_start_date"
                    ,"e.company_end_date"
                    ,"e.organization_start_date"
                    ,"e.organization_end_date" 
                    ,"e.org_in_out_dates_code"
                    ,"e.local_pb_hierarchy_code"
                    // contract data
                    ,"emp.contract_type"
                    ,"emp.contract_start_date"
                    ,"emp.contract_end_date"
                    ,"emp.position_start_date"
                    ,"emp.continous_service_date"        
                    ,"emp.original_hire_date" 
                    ,"emp.contract_code"
                    ,"emp.seniority_date_max"

                    // retroactive data
                    ,"job.worker_type"
                    ,"job.collective_agreement_reference"
                    ,"job.collective_agreement_group"
                    ,"job.collective_agreement_level"
                    ,"job.coefficient_label"
                    ,"job.fte"
                    ,"job.effective_job_change_date"
                    ,"job.job_code"
                    ,"job.csp_code"
                    ,"csp.csp"
                    ,"job.worker_rate_code"
                    ,"job.info_dates_code"
                    ,"job.in_out_dates_code"
                    ,"job.contract_dates_code"
                    ,"job.company_dates_code"
                    ,"job.record_start_date"
                    ,"job.record_end_date"
                   )
                   .withColumn("prev_new_cost_center_end_date",lag($"new_cost_center_end_date",1) over byemployee_cc_start_new)
                   .withColumn("rank",rank() over byemployeeid)
                   .filter($"rank" === 1 || $"emp.france_payroll_id".isNull).drop("rank")
                   .withColumn("new_cost_center_start_date_extended",when($"prev_new_cost_center_end_date".isNull,$"new_cost_center_start_date").otherwise(date_add($"prev_new_cost_center_end_date",1)))
                   .withColumn("new_cost_center_start_date",when($"prev_new_cost_center_end_date".isNull,when($"new_cost_center_start_date" < startdate_value,$"new_cost_center_start_date").otherwise(startdate_value)).otherwise($"new_cost_center_start_date"))

df_employee_contract.createOrReplaceTempView("vw_employee_contract_retro")

// COMMAND ----------

// DBTITLE 1,Param Values
val df_param_value = spark.read.jdbc(jdbcurl, "dbo.param_value", connectionproperties).select("parameter_name", "parameter_value")
val taux_charges_patronales_cadre = df_param_value.filter($"parameter_name" === "TAUX_CHARGES_PATRONALES_CADRE").select("parameter_value").first().getString(0).toDouble
val taux_charges_patronales_non_cadre = df_param_value.filter($"parameter_name" === "TAUX_CHARGES_PATRONALES_NON_CADRE").select("parameter_value").first().getString(0).toDouble

val vacataire_csp_id = spark.sql("""select cast(sum(csp_id) as int) as vacataire_csp_id from vw_d_csp where lower(professional_category_reference) = 'autre statut'""").head().getInt(0) //Get Vacataire Csp Id

val historical_date_end_date_value = LocalDate.parse(historical_data_end_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))

// COMMAND ----------

// DBTITLE 1,Compensation Data
// all contracts
val bycontract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
  val df_contractstartall_read = spark.table("hr.contract")
                                                .withColumn("rank_start",rank() over bycontract)
                                                .withColumn("contract_end_date",when($"contract_end_date".isNull,"2999-12-31").otherwise($"contract_end_date"))
                                                .withColumn("contract_end_date_month_id",last_day($"contract_end_date"))
                                                .filter(col("rank_start")==="1")
                                                // manage date to retrive contract of the month
                                                .withColumn("previous_end_date",lag($"contract_end_date",1) over bycontract_order)
                                                .withColumn("next_start_date",lead($"contract_start_date",1) over bycontract_order)
                                                .withColumn("previous_start_date",lag($"contract_start_date",1) over bycontract_order)
                                                .withColumn("contract_start_date",when($"previous_end_date".isNull || last_day($"previous_end_date") < $"contract_start_date",date_add(last_day(add_months($"contract_start_date", -1)),1)).otherwise($"contract_start_date"))
                                                .withColumn("contract_end_date",when($"next_start_date".isNull || last_day($"contract_end_date") < $"next_start_date",last_day($"contract_end_date")).otherwise($"contract_end_date"))


                                                .distinct
df_contractstartall_read.createOrReplaceTempView("vw_contractstart_all")

//contract compensation
val bycomp_version = Window.partitionBy("employee_code","employee_id","france_payroll_id","effective_compensation_change_date").orderBy($"record_start_date".desc)
val bycomp_date = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"effective_compensation_change_date")
val df_contracthr_comp = spark.table("hr.contract").as("contract")
.select("employee_code","employee_id","france_payroll_id","grade","total_base_pay","effective_compensation_change_date","record_start_date","contract_code").filter($"effective_compensation_change_date".isNotNull)
.withColumn("rank",rank() over bycomp_version).filter($"rank" === 1).drop("rank","record_start_date")
  //Salary
  .join(df_contract_type.as("contract_type"),
        ($"contract.contract_code"===$"contract_type.contract_code"),"left")
  .withColumn("comp",when(lower($"contract_type.contract_type") === ("stagiaire"),$"total_base_pay").otherwise(($"total_base_pay"/12)*13))
.withColumn("prev_comp_date",lag($"effective_compensation_change_date",1) over bycomp_date)
// retrieves only version with changes
.withColumn("hashkey",concat_ws("|",$"grade",$"total_base_pay"))
.withColumn("previous_hashkey",lag($"hashkey",1) over bycomp_date)
.filter($"previous_hashkey" =!= $"hashkey" or $"previous_hashkey".isNull)
.drop("previous_hashkey","hashkey")

// manage historical data
.withColumn("prev_comp_date",lag($"effective_compensation_change_date",1) over bycomp_date)
.withColumn("prev_comp",lag($"comp",1) over bycomp_date)
.withColumn("next_comp",lead($"comp",1) over bycomp_date)
//.withColumn("effective_compensation_change_date",when(abs($"comp" - $"prev_comp") < 1.0 && $"effective_compensation_change_date"<= historical_date_end_date_value ,$"prev_comp_date" ).otherwise($"effective_compensation_change_date"))
//.filter($"next_comp" - $"comp" > 1.0 || ($"next_comp" - $"comp" < 1.0 && $"effective_compensation_change_date">= historical_date_end_date_value) || $"next_comp".isNull)

.withColumn("record_end_date",date_sub(lead($"effective_compensation_change_date",1) over bycomp_date,1))
.withColumn("record_start_date",$"effective_compensation_change_date")
.withColumn("record_end_date",coalesce($"record_end_date",to_date(lit("2999-12-31"))))

.orderBy(asc("employee_code"),asc("record_start_date"))

df_contracthr_comp.createOrReplaceTempView("vw_contract_salary")


val df_contract_compensation = df_contractstartall_read.as("c")
                                .join(df_contracthr_comp.as("s"),$"c.employee_code" === $"s.employee_code" and (($"s.record_start_date" <= $"c.contract_start_date" and $"s.record_end_date" >= $"c.contract_start_date") or ($"s.record_start_date" <= $"c.contract_end_date" and $"s.record_start_date" >= $"c.contract_start_date"  )))
                                .select(
                                  "s.employee_code"
                                  ,"s.employee_id"
                                  ,"s.france_payroll_id"
                                  ,"s.total_base_pay"
                                  ,"s.comp"
                                  ,"s.record_start_date"
                                  ,"s.record_end_date"
                                  ,"c.contract_start_date"
                                  ,"c.contract_end_date"
                                  ,"c.contract_end_date_month_id"
                                )

df_contract_compensation.createOrReplaceTempView("vw_contract_salary_all")

// COMMAND ----------

// DBTITLE 1,Training data
val bytraining_version = Window.partitionBy("employee_id","training_object_id").orderBy($"training_start_date",$"training_session_start_date")
val bytraining_object = Window.partitionBy("training_object_id")

val df_training_read = spark.table("hr.training").filter(!$"removed_from_recap").filter($"training_plan_date_id" >= startdate_value)

val df_training = df_training_read.as("t")
                    .withColumn("employee_per_training",approx_count_distinct("employee_id") over bytraining_object)
                    .withColumn("rank",rank() over bytraining_version)
                    // retrieve last day of month based on training plan date
                    .withColumn("training_end_date_month_id",last_day($"training_end_date"))
                    .withColumn("training_plan_month_id",last_day($"training_plan_date_id"))
                    // retrieve status
                    .join(df_training_status.as("s"),$"s.training_status_code" === $"t.training_status_code","left")
                    // retrieve consolidated hr scope
                    .join(df_training_scope.select("training_scope","training_scope_consolidated").as("scope"),$"scope.training_scope" === $"t.hr_scope","left")
                    .drop($"scope.training_scope")
                    // remove space
                    .withColumn("training_type",trim($"training_type"))
                    .withColumn("training_recap_status",trim($"training_recap_status"))
                    .withColumn("training_status_label",trim($"training_status_label"))
                    .drop($"s.training_status_code")
                    // calculated columns
                    .withColumn("training_preparation_fees",$"training_preparation_fees"/$"employee_per_training")
                    .withColumn("CPF_company_funding_amount",when(lower($"consolidated_training_status") === "réalisé",$"CPF_company_funding_amount").otherwise(0))
                    .withColumn("CPF_other_employee_amount",when(lower($"consolidated_training_status") === "réalisé",$"CPF_other_employee_amount").otherwise(0))
                    .withColumn("training_additional_fees",
                                when($"training_materials_fees".isNull,0).otherwise($"training_materials_fees")
                                +when($"training_preparation_fees".isNull,0).otherwise($"training_preparation_fees")
                                +when($"trainer_fees".isNull,0).otherwise($"trainer_fees")
                                +when($"trainee_fees".isNull,0).otherwise($"trainee_fees")
                    )
                    .withColumn("training_additional_fees_committed",
                                when(lower($"training_type") === "session" && lower($"training_status_label") === "inscrit",$"training_additional_fees").otherwise(0)
                    )
                    .withColumn("training_additional_fees_actuals",
                                when(lower($"training_type") === "session" && lower($"consolidated_training_status") === "réalisé",$"training_additional_fees").otherwise(0)
                    )
                    .withColumn("training_additional_fees_planned",
                              when((lower($"training_type") === "session" || lower($"training_type") === "événement") && lower($"consolidated_training_status") === "prévu",$"training_additional_fees").otherwise(0)
                    )
                    .withColumn("training_cost_committed",
                                when(lower($"training_type") === "session" && lower($"training_status_label") === "inscrit",$"training_price").otherwise(0)
                    )
                    .withColumn("training_cost_planned",
                                when((lower($"training_type") === "session" || lower($"training_type") === "événement" || lower($"training_type") === "formation externe") && lower($"consolidated_training_status") === "prévu",$"training_price").otherwise(0)
                    )
                   .withColumn("training_cost_actuals",
                                when(lower($"training_type") === "session" && lower($"consolidated_training_status") === "réalisé",$"training_price").otherwise(0)
                    )
                    .withColumn("training_total_cost",
                                 when($"training_cost_committed".isNull,0).otherwise($"training_cost_committed")
                                +when($"training_additional_fees_committed".isNull,0).otherwise($"training_additional_fees_committed")
                    )
                    .withColumn("total_training_costs_additional_fees_cpf",
                                when(lower($"training_type") === "session" && lower($"consolidated_training_status") === "réalisé",
                                     when($"training_price".isNull,0).otherwise($"training_price")+
                                     when($"training_additional_fees".isNull,0).otherwise($"training_additional_fees")+
                                     when($"CPF_company_funding_amount".isNull,0).otherwise($"CPF_company_funding_amount")
                                    ).otherwise(0)
                    )
                    .withColumn("training_hours_committed",
                               when((lower($"training_type") === "session") && lower($"training_status_label") === "inscrit",$"training_session_duration"/60).otherwise(0) 
                    )
                    .withColumn("training_hours_planned",
                              when(lower($"consolidated_training_status") === "prévu",
                                   when(lower($"training_type") === "session",$"training_hours").otherwise(
                                     when(lower($"training_type") === "événement" || lower($"training_type") === "formation externe",$"training_hours")
                                     .otherwise(0)
                                   )
                                  ).otherwise(0)
                    )
                    .withColumn("training_hours_actuals",
                              when(lower($"training_type") === "session" && lower($"consolidated_training_status") === "réalisé" && lower($"training_status_label") =!= "absent"  && ($"attended_to_training_session" || $"attended_to_training_session".isNull ),$"training_session_duration"/60).otherwise(0)
                    )
                    .withColumn("nb_employee_trained",when(lower($"training_type") === "session" && (lower($"training_status_label") === "présent" || lower($"training_status_label") === "partiellement présent"),1))
                    .withColumn("nb_training",when(lower($"consolidated_training_status") === "réalisé",1))

df_training.createOrReplaceTempView("vw_training")

// COMMAND ----------

// DBTITLE 1,Training Type Evenement to exclude

val df_training_evenement = df_training.filter(lower($"training_type") === "événement").as("t1")
            .join(df_training.filter(lower($"training_type") === "session").as("t2"),$"t1.employee_id" === $"t2.employee_id" && $"t1.training_plan_year_id" === $"t2.training_plan_year_id" && $"t1.training_label" === $"t2.training_label")
            .select("t1.training_type","t1.training_label","t1.training_object_id","t1.employee_id","t1.training_plan_year_id").distinct

df_training_evenement.createOrReplaceTempView("vw_training_evenement")

// COMMAND ----------

// DBTITLE 1,Training Payroll
//compensation data
 val df_training_payroll = df_training.select("employee_id","training_plan_month_id","training_object_id","training_plan_date_id","training_start_date").distinct.as("t")

.join(df_employee_contract.as("e"),($"e.france_payroll_id" === $"t.employee_id" || $"e.employee_id" === $"t.employee_id") && ($"t.training_plan_month_id" >= $"e.new_cost_center_start_date" && $"t.training_plan_month_id" <= $"e.new_cost_center_end_date") && ($"t.training_plan_month_id" >= $"e.record_start_date" && $"t.training_plan_month_id" <= $"e.record_end_date"),"left")

.join(df_employee_contract.as("e2"),($"e2.france_payroll_id" === $"t.employee_id" || $"e2.employee_id" === $"t.employee_id") && $"e.employee_id".isNull && ($"t.training_start_date" >= $"e2.new_cost_center_start_date" && $"t.training_start_date" <= $"e2.new_cost_center_end_date") && ($"t.training_plan_month_id" >= $"e2.record_start_date" && $"t.training_plan_month_id" <= $"e2.record_end_date"),"left")


.join(df_employee_contract.as("e3"),($"e3.france_payroll_id" === $"t.employee_id" || $"e3.employee_id" === $"t.employee_id") && $"e.employee_id".isNull && $"e2.employee_id".isNull && ($"t.training_plan_month_id" >= $"e3.new_cost_center_start_date_extended" && $"t.training_plan_month_id" <= $"e3.new_cost_center_end_date") && ($"e3.new_cost_center_end_date" >= $"e3.record_start_date" && $"t.training_plan_month_id" <= $"e3.record_end_date"),"left")

                              .filter($"e.employee_code".isNotNull || $"e2.employee_code".isNotNull || $"e3.employee_code".isNotNull)
                              .withColumn("emp_code",when($"e.employee_code".isNull,when($"e2.employee_code".isNull,
                                                                                         $"e.employee_code").otherwise($"e2.employee_code")).otherwise($"e.employee_code"))
                              .withColumn("etablissement",when($"e.libelle_etablissement".isNull,when($"e2.libelle_etablissement".isNull,                                                                                         $"e.libelle_etablissement").otherwise($"e2.libelle_etablissement")).otherwise($"e.libelle_etablissement"))
                              .withColumn("emp_csp",when($"e.csp".isNull,when($"e2.csp".isNull,
                                                                                         $"e.csp").otherwise($"e2.csp")).otherwise($"e.csp"))

                              .join(df_employee_contract.as("e4"),$"emp_csp" === $"e4.csp" && $"etablissement" === $"e4.libelle_etablissement" && ($"t.training_plan_month_id" >= $"e4.new_cost_center_start_date" && $"t.training_plan_month_id" <= $"e4.new_cost_center_end_date") && ($"t.training_plan_month_id" >= $"e4.record_start_date" && $"t.training_plan_month_id" <= $"e4.record_end_date"))
                              .join(df_contract_compensation.as("s"),$"e4.employee_code" === $"s.employee_code" && $"t.training_plan_month_id" >= $"s.record_start_date" && $"t.training_plan_month_id" <= $"s.record_end_date" && $"t.training_plan_month_id" >= $"s.contract_start_date" && $"t.training_plan_month_id" <= $"s.contract_end_date")
                              .groupBy("emp_code","t.training_object_id","emp_csp","etablissement")         
                              .agg(avg("s.comp") as "comp")
                              .select("emp_code","t.training_object_id","emp_csp","etablissement","comp"/*,"e2.employee_id","t.training_plan_date_id"*/)
                              .withColumn("training_payroll",(($"comp"/12)/152.19)*(when(lower($"emp_csp") === "cadre",taux_charges_patronales_cadre).otherwise(taux_charges_patronales_non_cadre)))
                              .withColumnRenamed("emp_code","employee_code")
                              .withColumnRenamed("emp_csp","csp")
                              .withColumnRenamed("etablissement","libelle_etablissement")

df_training_payroll.createOrReplaceTempView("vw_payroll")

// COMMAND ----------

// DBTITLE 1,Training Evaluation
val df_transco_evaluation = spark.read.jdbc(jdbcurl, "dbo.vw_ref_transco", connectionproperties).filter($"axe" === "FORMATION_EVALUATION").select("di_value", "source_value")

val df_training_evaluation_read = spark.table("hr.training_evaluation").filter($"evaluation_response".isNotNull).as("eval")
                    .join(df_transco_evaluation.as("transco"),trim(lower($"source_value")) === trim(lower($"evaluation_response")),"left")
                    .withColumn("evaluation",when($"di_value".isNotNull,$"di_value").otherwise($"evaluation_response"))
                    .withColumn("evaluation",$"evaluation".cast("double"))
                    .groupBy("employee_id","training_type","training_object_id","training_label")
                    .agg(avg("evaluation") as "evaluation")

df_training_evaluation_read.createOrReplaceTempView("vw_training_evaluation")

// COMMAND ----------

// DBTITLE 1,Training Query
val query_training = """ 

select 

      t.training_object_id
      ,t.training_landmark_number
      ,t.training_label
      ,t.training_provider
      ,t.training_organization
      ,t.training_mode
      ,t.authorization_certification_diploma
      ,t.training_action
      ,t.mandatory_training
      ,t.hr_scope
      ,t.training_scope_consolidated as hr_scope_consolidated
      ,t.training_subject
      ,t.parent_training_subject
      ,t.training_axis
      ,t.trainingship_type
      ,t.talent_development_budget
      ,t.inside_training_path
      ,t.reskilling
      ,t.coaching
      ,t.training_recap_working_hours
      ,t.training_hours
      ,t.training_session_duration
      ,t.training_session_break_duration
      ,t.training_estimated_participants
      ,t.training_estimated_budget
      ,t.invoice
      ,t.training_presence_sheet
      ,t.attended_to_training_session
      ,t.training_price
      ,case when t.rank = 1 then t.CPF_company_funding_amount end as CPF_company_funding_amount
      ,t.CPF_other_employee_amount
      ,t.training_materials_fees
      ,t.training_preparation_fees
      ,t.trainer_fees
      ,t.trainee_fees
      ,t.OPCA_amount
      ,t.training_creation_date
      ,t.training_modification_date
      ,t.training_start_date
      ,t.training_end_date
      ,t.training_session_start_date
      ,t.training_session_end_date
      ,t.recap_completion_date
      ,t.recap_registration_date
      ,t.last_recap_status_modification_date
      ,t.removed_from_recap
      ,t.legal_category
      ,t.training_leave_type
      ,t.training_type
      ,t.training_recap_status
      ,int(null) as training_status_planned
      ,int(null) as training_status_committed
      ,int(null) as training_status_actuals

      ,case when t.rank = 1 then t.total_training_costs_additional_fees_cpf end as total_training_costs_additional_fees_cpf
      ,case when t.rank = 1 then t.training_cost_planned end as training_cost_planned
      ,case when t.rank = 1 then t.training_cost_committed end as training_cost_committed
      ,case when t.rank = 1 then t.training_cost_actuals end as training_cost_actuals
      ,case when t.rank = 1 then t.training_additional_fees end as training_additional_fees
      ,case when t.rank = 1 then t.training_additional_fees_committed end as training_additional_fees_committed
      ,case when t.rank = 1 then t.training_additional_fees_actuals end as training_additional_fees_actuals
      ,case when t.rank = 1 then t.training_additional_fees_planned end as training_additional_fees_planned
      ,case when t.rank = 1 then t.training_total_cost end as training_total_cost
      ,case when t.rank = 1 then t.training_hours_planned end as training_hours_planned
      ,case when t.rank = 1 then t.training_hours_committed end as training_hours_committed
      ,t.training_hours_actuals
      ,eval.evaluation as training_evaluation
      ,pr.training_payroll * t.training_hours_actuals as training_payroll_cost
      ,case when t.rank = 1 then
        case  when lower(t.consolidated_training_status) = "réalisé" and lower(t.training_type) = "session" then
          ifnull(t.total_training_costs_additional_fees_cpf,0) + (ifnull(pr.training_payroll,0) * ifnull(t.training_hours_actuals,0)) 
        end 
        else
          pr.training_payroll * t.training_hours_actuals
      end  as total_training_costs_additional_fees_cpf_payroll
      ,case when t.rank = 1 then t.nb_employee_trained end as nb_employee_trained 
      ,case when t.rank = 1 then t.nb_training end as nb_training
      ,double(null) as total_training_payroll_costs

      ,int(date_format(t.training_plan_date_id,'yyyyMMdd')) as training_plan_date_id
      ,t.training_plan_year_id
      ,coalesce(case when evt.employee_id is not null then -1 else ts.training_status_id end, -1) as training_status_id 
      ,coalesce(tt.training_type_id, -1) as training_type_id

      ,-1 as training_id

      ,coalesce(d.employee_id, -1) as employee_id
      ,coalesce(ct.contract_type_id, -1) as contract_type_id
      ,coalesce(wr.worker_rate_id, -1) as worker_rate_id
      ,case when upper(e.contract_type) = 'VA' or  lower(ct.contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else coalesce(csp.csp_id, -1) end as csp_id
      ,coalesce(nat.nationality_id, -1) as nationality_id
      ,coalesce(ag.range_age_id, -1) as range_age_id
      ,coalesce(sec.seniority_company_id,-1) as seniority_company_id
      ,coalesce(sep.seniority_position_id, -1) as seniority_position_id
      ,coalesce(loc.location_id, -1) as location_id
      ,coalesce(job.job_architecture_id, -1) as job_architecture_id
      ,coalesce(man.manager_id, -1) as manager_id
      ,coalesce(so.supervisory_organization_id, -1) as supervisory_organization_id
      ,coalesce(ol.legal_organization_id,'-1') as legal_organization_id
      ,coalesce(op.operational_organization_id,'-1') as operational_organization_id
      ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
      ,coalesce(id.info_dates_id, -1) as info_dates_id
      ,'""" + date_id + """' as date_id
      ,current_timestamp() as recordcreationdate
      ,'""" + runid + """' as runid

from vw_training t

left join vw_employee_contract_retro e
on (e.france_payroll_id = t.employee_id or e.employee_id= t.employee_id)
and t.training_plan_month_id between e.new_cost_center_start_date and e.new_cost_center_end_date
and t.training_plan_month_id between e.record_start_date and e.record_end_date

left join vw_employee_contract_retro e2
on (e2.france_payroll_id = t.employee_id or e2.employee_id= t.employee_id)
and e.employee_code is null
and t.training_start_date between e2.new_cost_center_start_date and e2.new_cost_center_end_date
and t.training_start_date between e2.record_start_date and e2.record_end_date

left join vw_employee_contract_retro e3
on (e3.france_payroll_id = t.employee_id or e3.employee_id= t.employee_id)
and e2.employee_code is null and e.employee_code is null
and t.training_plan_month_id between e3.new_cost_center_start_date_extended and e3.new_cost_center_end_date
and e3.record_start_date <= e3.new_cost_center_start_date and t.training_plan_month_id <= e3.record_end_date


left join vw_d_employee d on coalesce(e.employee_code,e2.employee_code,e3.employee_code) = d.employee_code  

-- evaluation
left join vw_training_evaluation eval
on eval.employee_id = t.employee_id
and eval.training_object_id = t.training_object_id
and t.rank = 1

-- evenement
left join vw_training_evenement evt
on evt.training_object_id = t.training_object_id
and evt.employee_id = t.employee_id
and evt.training_plan_year_id = t.training_plan_year_id

-- payroll costs
left join vw_payroll pr
on pr.employee_code = e.employee_code
and pr.training_object_id = t.training_object_id

-- training dimensions
left join vw_d_training_type tt on tt.training_type_code = t.training_type
left join vw_d_training_status ts on ts.training_status_code = t.training_status_code

-- common dimensions
left join vw_d_nationality nat on coalesce(e.nationality_code,e2.nationality_code,e3.nationality_code) = nat.nationality_code
left join vw_d_range_age ag on ag.range_age = (case when isnull(coalesce(e.birth_date,e2.birth_date,e3.birth_date)) then null else floor(months_between(to_date('""" + date_id + """','yyyyMMdd'),to_date(coalesce(e.birth_date,e2.birth_date,e3.birth_date)),true)/12) end)
left join vw_d_location loc on coalesce(e.location_code,e2.location_code,e3.location_code) = loc.location_code
left join vw_d_manager man on coalesce(e.manager_code,e2.manager_code,e3.manager_code) = man.manager_code
left join vw_d_legal_organization ol on coalesce(e.legal_organization_code,e2.legal_organization_code,e3.legal_organization_code) = ol.legal_organization_code
left join vw_d_operational_organization op on coalesce(e.operational_organization_code,e2.operational_organization_code,e3.operational_organization_code) = op.operational_organization_code                            
left join vw_d_hierarchy_pb hi_pb on coalesce(e.cost_center_code,e2.cost_center_code,e3.cost_center_code) = hi_pb.cost_center_code
left join vw_d_supervisory_organization so on coalesce(e.supervisory_organization_code,e2.supervisory_organization_code,e3.supervisory_organization_code) = so.supervisory_organization_code                                 

left join vw_d_contract_type ct on ct.collective_agreement_code = sha2(getconcatenedstring(array(e.worker_type
                                                                    ,e.collective_agreement_reference
                                                            ,e.collective_agreement_group
                                                            ,e.collective_agreement_level
                                                            ,e.coefficient_label
                                                            )),256)
  and ct.contract_type_code = sha2(getconcatenedstring(array(
          e.contract_type
          )),256)
left join vw_d_worker_rate wr on coalesce(e.worker_rate_code,e2.worker_rate_code,e3.worker_rate_code) = wr.worker_rate_code                                             
left join vw_d_csp csp on coalesce(e.csp_code,e2.csp_code,e3.csp_code) = csp.csp_code                    
left join vw_d_job_architecture job on coalesce(e.job_code,e2.job_code,e3.job_code) = job.job_architecture_code       
left join vw_d_info_dates id on id.company_dates_code = coalesce(e.company_dates_code,e2.company_dates_code,e3.company_dates_code)
and id.contract_dates_code = coalesce(e.contract_dates_code,e2.contract_dates_code,e3.contract_dates_code)

left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(coalesce(e.continous_service_date,e2.continous_service_date,e3.continous_service_date)) then null else datediff(to_date(e.seniority_date_max),to_date(coalesce(e.continous_service_date,e2.continous_service_date,e3.continous_service_date))) end)
left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(coalesce(e.position_start_date,e2.position_start_date,e3.position_start_date)) then null else datediff(to_date(e.seniority_date_max),to_date(coalesce(e.position_start_date,e2.position_start_date,e3.position_start_date))) end)
                   """

// COMMAND ----------

val df_training_results = spark.sql(query_training)
df_training_results.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Delete data from table f_training for the loading date
val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """truncate table training.f_training""" 
val res = stmt.execute(query_delete)

//connection.close()

// COMMAND ----------

// DBTITLE 1,Insert data on the training table
df_training_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "training.f_training", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Statistics about data read and inserted
val read_records = 0 //df_training_read.count().toInt //count the number of read records
val inserted_records = 0 //df_training_results.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from Cache
df_training_read.unpersist
df_training_results.unpersist

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)