// Databricks notebook source
// DBTITLE 1,Get Parameters values: load_date and runid
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set variables
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd")).plusMonths(-1)
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_start_month = LocalDate.parse(date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + "01",  DateTimeFormatter.ofPattern("yyyyMMdd"))
val date_id = date_end_month.toString.replace("-","")//date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + "01"

val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))

val year_id = date_value.getYear()
val last_year_id = date_value.getYear()-1
val last_month = date_end_month.plusMonths(-1).getYear() + ("%02d".format(date_end_month.plusMonths(-1).getMonth.getValue()))
val last_month_id = date_end_month.plusMonths(-1).toString.replace("-","") //date_value.plusMonths(-1).getYear() + ("%02d".format(date_value.plusMonths(-1).getMonth.getValue())) + "01"
val first_month_id = date_value.getYear() + "01"
val last_month_previous_year = (date_value.getYear() -1) + "12"
val december_previous_year = (date_value.getYear() -1) + "1231"
val march_month_id = date_value.getYear() + "03"

val date_next_month = date_end_month.plusDays(1)
val month_next_id = date_next_month.getYear() + ("%02d".format(date_next_month.getMonth.getValue()))
val date_end_last_month = date_start_month.plusDays(-1)
val date_start_last_month = date_start_month.plusMonths(-1)


val validation_trial_period_min = date_start_month.plusMonths(-16).toString
val validation_trial_period_max = (date_start_month.plusMonths(-4).withDayOfMonth(date_start_month.plusMonths(-4).lengthOfMonth())).toString

// COMMAND ----------

// DBTITLE 1,Refresh delta table employee
 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table contract
 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table job_requisition
 if(spark.catalog.tableExists("hr.job_requisition")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.job_requisition")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table job_application
 if(spark.catalog.tableExists("hr.job_application")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.job_application")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table accounting_nature
if(spark.catalog.tableExists("hr.accounting_nature")) 
{
  try {
      spark.sql("FSCK REPAIR TABLE hr.accounting_nature")
    }
    catch {
      case e: FileNotFoundException => println("Couldn't find that file.")
      case e: IOException => println("Had an IOException trying to read that file")
    }
}

// COMMAND ----------

// DBTITLE 1,Get Dimensions data
spark.read.jdbc(jdbcurl, "recruitment.d_candidate", connectionproperties).filter("current_version = 1") .createOrReplaceTempView("vw_d_candidates")
spark.read.jdbc(jdbcurl, "recruitment.d_source_recruitment", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_source_recruitment")
spark.read.jdbc(jdbcurl, "recruitment.d_job_requisition", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_job_requisition")
spark.read.jdbc(jdbcurl, "recruitment.d_job_application", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_job_application")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.d_date", connectionproperties).filter(col("month_id") === lit(month_id)).createOrReplaceTempView("vw_d_date")
spark.read.jdbc(jdbcurl, "staff.d_employee", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_employee")
val df_contract_type = spark.read.jdbc(jdbcurl, "staff.d_contract_type", connectionproperties).filter("current_version = 1")
df_contract_type.createOrReplaceTempView("vw_d_contract_type")
spark.read.jdbc(jdbcurl, "staff.d_worker_rate", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_worker_rate")
spark.read.jdbc(jdbcurl, "staff.d_csp", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_csp")
spark.read.jdbc(jdbcurl, "staff.d_nationality", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_nationality")
spark.read.jdbc(jdbcurl, "staff.d_range_age", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_range_age")
spark.read.jdbc(jdbcurl, "staff.d_seniority_company", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_company")
spark.read.jdbc(jdbcurl, "staff.d_hierarchy_pb", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_hierarchy_pb")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_seniority_position", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_position")
spark.read.jdbc(jdbcurl, "staff.d_location", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_location")
spark.read.jdbc(jdbcurl, "staff.d_job_architecture", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_job_architecture")
spark.read.jdbc(jdbcurl, "staff.d_manager", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_manager")
spark.read.jdbc(jdbcurl, "staff.d_supervisory_organization", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_supervisory_organization")
spark.read.jdbc(jdbcurl, "staff.d_contract_suspension", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_contract_suspension")
spark.read.jdbc(jdbcurl, "staff.d_legal_organization", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_legal_organization")
spark.read.jdbc(jdbcurl, "staff.d_operational_organization", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_operational_organization")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "mobility.d_mobility_in", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_mobility_in")
spark.read.jdbc(jdbcurl, "mobility.d_mobility_out", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_mobility_out")
spark.read.jdbc(jdbcurl, "staff.d_info_dates", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_info_dates")
spark.read.jdbc(jdbcurl, "mobility.d_in_out_dates", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_in_out_dates")

spark.read.jdbc(jdbcurl, "dbo.vw_ref_seniority_company", connectionproperties).createOrReplaceTempView("vw_ref_seniority_company")

// COMMAND ----------

val vacataire_csp_id = spark.sql("""select cast(sum(csp_id) as int) as vacataire_csp_id from vw_d_csp where lower(professional_category_reference) = 'autre statut'""").head().getInt(0)

// COMMAND ----------

val borne_1_year = spark.sql("""select distinct range_seniority_company_max as borne_1_year from vw_ref_seniority_company where range_seniority_company = 'Entre 6 mois et 1 an'""").head().getInt(0) //Borne min for seniority superior to 6 months
val borne_6_month = spark.sql("""select distinct range_seniority_company_min as borne_6_month from vw_ref_seniority_company where range_seniority_company = 'Entre 6 mois et 1 an'""").head().getInt(0) //Borne min for seniority superior to 6 months
val borne_2_year = (borne_1_year*2) - 1

// COMMAND ----------

val byemployee = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_organization_change_date".desc,$"effective_organization_hierarchy_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_employee_read = spark.table("hr.employee").filter("('" + date_end_month.toString + "' >= record_start_date or '" + date_end_month.toString + "' >= effective_organization_hierarchy_change_date) and '" + date_end_month.toString + "' <= coalesce(record_end_date, '2999-12-31')")
                                                 .withColumn("rank",rank() over byemployee)
                                                 .filter(col("rank")==="1").distinct
df_employee_read.createOrReplaceTempView("vw_employee")


val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_contract_read = spark.table("hr.contract").filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")                                                         
                                                 .withColumn("rank_month",rank() over bycontract_month)
                                                 .withColumn("rank",rank() over bycontract)
                                                 .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                 .withColumn("seniority_date_max",when($"contract_end_date" === "2999-12-31" or $"contract_end_date".isNull or $"contract_end_date" > lit(load_date), lit(load_date)).otherwise($"contract_end_date"))
                                                 .filter(col("rank")==="1").distinct
df_contract_read.createOrReplaceTempView("vw_contract")

// COMMAND ----------

val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract = Window.partitionBy("employee_id","france_payroll_id").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
 
val df_contract_read_month = spark.table("hr.contract").filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """' """
                                                        ) 
                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("month_contract_start_date",when($"contract_start_date" < date_start_month,date_start_month).otherwise($"contract_start_date"))
                                                .withColumn("month_contract_end_date",when($"contract_end_date" > date_end_month,date_end_month).when($"contract_end_date".isNull,date_end_month).otherwise($"contract_end_date"))
                                                .withColumn("contract_days",datediff($"month_contract_end_date",$"month_contract_start_date")+1)
                                                .filter(col("rank_month")==="1")
                                                .withColumn("rank",rank() over bycontract)
                                                .withColumn("next_contract_start_date",lag($"contract_start_date", 1, null).over(bycontract) )
                                                .withColumn("next_contract_end_date",lag($"contract_end_date", 1, null).over(bycontract) )
                                                .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                .distinct
df_contract_read_month.createOrReplaceTempView("vw_contract_month")

// COMMAND ----------

val byJobChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date_valid".desc)
val byJobChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_compensation_change_date_valid".desc)
val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date","effective_job_change_date","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_effective_change_valid = spark.table("hr.contract")
                                                .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")                                                
                                                .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                .withColumn("effective_job_change_date_valid", when($"effective_job_change_date" > lit(date_end_month),null).otherwise($"effective_job_change_date"))
                                                .withColumn("effective_job_change_date_valid_last", first($"effective_job_change_date").over(byJobChangeDateLast))
                                                .withColumn("effective_job_change_date", when($"effective_job_change_date_valid".isNotNull,$"effective_job_change_date_valid")
                                                                                        .when($"effective_job_change_date_valid_last".isNull, $"contract_start_date")
                                                                                        .otherwise($"effective_job_change_date_valid_last"))         
                                                .withColumn("effective_job_change_date_max", first($"effective_job_change_date").over(byJobChangeDateLastContract))

                                                .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                .withColumn("effective_compensation_change_date_valid", when($"effective_compensation_change_date" > lit(date_end_month),null).otherwise($"effective_compensation_change_date"))
                                                .withColumn("effective_compensation_change_date_valid_last", first($"effective_compensation_change_date").over(byCompensationChangeDateLast))
                                                .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date_valid".isNotNull,$"effective_compensation_change_date_valid")
                                                                                                 .when($"effective_compensation_change_date_valid_last".isNull, $"contract_start_date")
                                                                                                 .otherwise($"effective_compensation_change_date_valid_last"))      
                                                .withColumn("effective_compensation_change_date_max",first($"effective_compensation_change_date").over(byCompensationChangeDateLastContract))


                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .filter(col("rank_month")==="1")  
                                                .filter("""date_format(contract_start_date,'yyyyMM') = '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                            (date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                        )
                                               .select("employee_code",
                                                       "employee_id",
                                                       "france_payroll_id",
                                                       "contract_start_date",
                                                       "contract_end_date",
                                                       "contract_type",
                                                       "contract_type_label",
                                                       "effective_job_change_date",
                                                       "effective_compensation_change_date",
                                                       "effective_job_change_date_max",
                                                       "effective_compensation_change_date_max").distinct


val bycontract_job_month = Window.partitionBy("employee_id","france_payroll_id","effective_job_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_job_change_date_read =spark.table("hr.contract").filter("""contract_start_date <= '""" + date_end_month + """'""")  
                                                                     .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                                     .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                                     .withColumn("effective_job_change_date", when($"effective_job_change_date".isNotNull,$"effective_job_change_date").otherwise($"contract_start_date"))
                                                                     .filter("""effective_job_change_date <= '""" + date_end_month + """'""")   
                                                                     .withColumn("rank_month",rank() over bycontract_job_month)
                                                                     .filter(col("rank_month")==="1")  
                                                                     .distinct

val bycontract_compensation_month = Window.partitionBy("employee_id","france_payroll_id","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_compensation_change_date_read =spark.table("hr.contract").filter("""contract_start_date <= '""" + date_end_month + """'""")    
                                                                     .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                                     .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date".isNotNull,$"effective_compensation_change_date").otherwise($"contract_start_date"))                                         
                                                                     .filter("""effective_compensation_change_date <= '""" + date_end_month + """'""")   
                                                                     .withColumn("rank_month",rank() over bycontract_compensation_month)
                                                                     .filter(col("rank_month")==="1")  
                                                                     .distinct

val df_contract_join = df_effective_change_valid.as("e")
                                        .join(df_contract_effective_job_change_date_read.as("c"), $"e.employee_code" === $"c.employee_code" && $"e.effective_job_change_date_max" === $"c.effective_job_change_date", "left_outer")
                                        .join(df_contract_effective_compensation_change_date_read.as("o"), $"e.employee_code" === $"o.employee_code" && $"e.effective_compensation_change_date_max" === $"o.effective_compensation_change_date", "left_outer")
                                        .join(df_contract_read.as("d"), $"e.employee_code" === $"d.employee_code" && $"e.contract_start_date" === $"d.contract_start_date" 
                                                                                                                  && ($"e.effective_job_change_date_max" === $"d.effective_job_change_date" || $"e.effective_compensation_change_date_max" === $"d.effective_compensation_change_date"), "left_outer")
                                        .join(df_contract_read.as("r"), $"e.employee_code" === $"r.employee_code" && $"e.contract_start_date" === $"r.contract_start_date", "left_outer")
                                        .selectExpr(
                                                "e.employee_code"
                                               ,"e.employee_id"
                                               ,"e.france_payroll_id"
                                               ,"coalesce(r.contract_start_date, e.contract_start_date) as contract_start_date"
                                               ,"coalesce(r.contract_end_date, e.contract_end_date) as contract_end_date"
                                               ,"e.effective_job_change_date"
                                               ,"coalesce(c.collective_agreement_reference, d.collective_agreement_reference) as collective_agreement_reference"                                    
                                               ,"coalesce(c.collective_agreement_group, d.collective_agreement_group) as collective_agreement_group"
                                               ,"coalesce(c.collective_agreement_level, d.collective_agreement_level) as collective_agreement_level"
                                               ,"coalesce(c.continous_service_date, d.continous_service_date) as continous_service_date"
                                               ,"coalesce(c.position_start_date, d.position_start_date) as position_start_date"
                                               ,"coalesce(c.hire_date, d.hire_date) as hire_date"
                                               ,"coalesce(c.original_hire_date, d.original_hire_date) as original_hire_date"
                                               ,"coalesce(c.effective_hire_date, d.effective_hire_date) as effective_hire_date"
                                               ,"coalesce(c.fte, d.fte) as fte"
                                               ,"coalesce(c.worker_type, d.worker_type) as worker_type"
                                               ,"coalesce(c.paidfte, d.paidfte) as paidfte"
                                               ,"coalesce(c.bonus_target, d.bonus_target) as bonus_target"
                                               ,"coalesce(c.csp, d.csp) as csp"
                                               ,"coalesce(c.coefficient, d.coefficient) as coefficient"
                                               ,"coalesce(c.coefficient_label, d.coefficient_label) as coefficient_label"
                                               ,"coalesce(c.job_title, d.job_title) as job_title"
                                               ,"coalesce(o.total_base_pay, d.total_base_pay) as total_base_pay"
                                               ,"coalesce(o.grade, d.grade) as grade"
                                               ,"coalesce(o.effective_compensation_change_date, d.effective_compensation_change_date) as effective_compensation_change_date"
                                               ,"coalesce(c.job_code, d.job_code) as job_code"
                                               ,"coalesce(c.job_title_code, d.job_title_code) as job_title_code"
                                               ,"coalesce(o.grade_code, d.grade_code) as grade_code"
                                               ,"coalesce(c.csp_code, d.csp_code) as csp_code"
                                               ,"coalesce(c.worker_rate_code, d.worker_rate_code) as worker_rate_code"
                                               ,"coalesce(d.mobility_in_code, c.mobility_in_code) as mobility_in_code"
                                               ,"coalesce(d.mobility_out_code, c.mobility_out_code) as mobility_out_code"
                                               ,"coalesce(d.info_dates_code, c.info_dates_code) as info_dates_code"
                                               ,"coalesce(d.in_out_dates_code, c.in_out_dates_code) as in_out_dates_code"
                                               ,"coalesce(d.contract_dates_code, c.contract_dates_code) as contract_dates_code"                                               
                                               ,"coalesce(c.contract_code, d.contract_code) as contract_code"
                                               ,"coalesce(d.contract_type_code, c.contract_type_code) as contract_type_code"
                                               ,"coalesce(c.collective_agreement_code, d.collective_agreement_code) as collective_agreement_code"
                                               ,"coalesce(c.company_dates_code, d.company_dates_code) as company_dates_code"
                                               ,"coalesce(d.record_start_date, c.record_start_date) as record_start_date"
                                               ,"coalesce(d.date_raw_load_file, c.date_raw_load_file) as date_raw_load_file"
                                               ,"coalesce(d.record_modification_date, c.record_modification_date) as record_modification_date"
                                               ,"coalesce(d.record_creation_date, c.record_creation_date) as record_creation_date"
                                        )

                                          .distinct

df_contract_join.createOrReplaceTempView("vw_emp_contract") 


// COMMAND ----------

val bycontract_job_change = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc,$"effective_job_change_date".desc,$"effective_compensation_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_read_job_change = df_contract_join.withColumn("rank",rank() over bycontract_job_change)                                                
                                                 .filter(col("rank")==="1")
                                                 .distinct
                                                .withColumn("position_start_date", when($"position_start_date" > $"effective_job_change_date",$"effective_job_change_date").otherwise($"position_start_date"))
                                                .withColumn("continous_service_date", when($"continous_service_date" > $"contract_start_date",$"contract_start_date").otherwise($"continous_service_date"))

df_contract_read_job_change.createOrReplaceTempView("vw_contract_job_change")

// COMMAND ----------

val byapplication_status = Window.partitionBy("candidate_id","job_application_date","job_requisition_reference").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_job_application_read = spark.table("hr.job_application").filter("""date_format(job_application_date, 'yyyyMM') = '""" + month_id + """' or
                                                                          date_format(status_timestamp, 'yyyyMM') = '""" + month_id + """'  """) 
                                                               
                                                               .withColumn("rank",rank() over byapplication_status)
                                                               .filter(col("rank")==="1")
                                                               .distinct
                                                             
df_job_application_read.createOrReplaceTempView("vw_job_application")           

// COMMAND ----------

val byjob_requisition = Window.partitionBy("job_requisition_reference", "position_reference","recruiting_start_date","effective_date").orderBy($"job_posting_start_date".desc, $"job_posting_start_date".desc, $"target_hire_date".desc, $"target_end_date".desc, $"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_job_requisition_read = spark.table("hr.job_requisition").filter("""date_format(effective_date,'yyyyMM') <= '""" + month_id + """' or 
                                                                          date_format(recruiting_start_date,'yyyyMM') <= '""" + month_id + """' or 
                                                                          date_format(job_posting_start_date,'yyyyMM') <= '""" + month_id + """' or 
                                                                          date_format(target_end_date,'yyyyMM') = '""" + month_id + """' or 
                                                                          date_format(target_hire_date,'yyyyMM') = '""" + month_id + """'""" )
                                                               .withColumn("rank",rank() over byjob_requisition)
                                                               .filter(col("rank")==="1")           
                                                               .distinct
           
df_job_requisition_read.createOrReplaceTempView("vw_job_requisition")

// COMMAND ----------

val byaccounting_nature = Window.partitionBy("cost_center_code", "wage_type_code").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_accounting_nature = spark.table("hr.accounting_nature").where($"wage_type_code" === 6284000)
                                                              .filter("""year_month = '""" + month_id + """'""")
                                                              .withColumn("rank",rank() over byaccounting_nature)
                                                              .filter(col("rank")==="1")           
                                                              .distinct

df_accounting_nature.createOrReplaceTempView("vw_accounting_nature")

// COMMAND ----------

// DBTITLE 1,Monthly Query
val query_recruitment = """ select distinct
                                           case when ja.job_application_date is not null 
                                                 and date_format(ja.job_application_date,"yyyyMM") = '""" + month_id + """'  then 1 else null end as number_of_job_applications

                                          ,case when lower(jre.job_requisition_status_consolidated) <> 'ferme'
                                                 and jr.effective_date is not null 
                                                 and date_format(jr.effective_date,"yyyyMM") <= '""" + month_id + """' then 1 else null end as number_of_jobs

                                          ,case when lower(jr.job_requisition_status) in ('open') 
                                                 and jr.recruiting_start_date is not null 
                                                 and date_format(jr.recruiting_start_date,"yyyyMM") = '""" + month_id + """' then 1 else null end as number_of_jobs_opened_month
                                         
                                         ,case when lower(jr.job_requisition_status) in ('closed') 
                                                 and jr.effective_date is not null 
                                                 and date_format(jr.effective_date,"yyyyMM") = '""" + month_id + """' then 1 else null end as number_of_jobs_closed_month
                                        
                                        ,case when lower(jr.job_requisition_status) in ('filled') 
                                                 and jr.effective_date is not null 
                                                 and date_format(jr.effective_date,"yyyyMM") = '""" + month_id + """' then 1 else null end as number_of_jobs_filled_month                                               
                                                 
                                          ,case when lower(ja.stage_reference) = 'interview' 
                                                 and ja.status_timestamp is not null 
                                                 and date_format(ja.status_timestamp,"yyyyMM") = '""" + month_id + """' then 1 else null end as number_of_interviews

                                          ,case when lower(ja.stage_reference) = 'ready for hire' 
                                                 and ja.status_timestamp is not null 
                                                 and date_format(ja.status_timestamp,"yyyyMM") = '""" + month_id + """' then 1 else null end as number_of_jobs_accepted_month

                                          ,case  when lower(ja.stage_reference) = 'ready for hire' 
                                                 and ja.status_timestamp is not null 
                                                 and date_format(ja.status_timestamp,"yyyyMM") = '""" + month_id + """'
                                                 and ja.job_requisition_reference = jr.job_requisition_reference
                                                 and jr.job_posting_start_date is not null
                                                 and jr.job_posting_start_date <= ja.status_timestamp then datediff(ja.status_timestamp,jr.job_posting_start_date) else null end as recruitment_delay
                                         
                                         ,case  when c.contract_start_date is not null 
                                                and lower(ja.stage_reference) = 'ready for hire' 
                                                and lower(jr.job_requisition_status) in ('filled') 
                                                and  date_format(c.contract_start_date,'yyyyMM') = '""" + month_id + """' then 1 else null end as number_of_jobs_started_month       
                                               
                                          ,case  when lower(ja.stage_reference) = 'ready for hire' 
                                                 and lower(jr.job_requisition_status) in ('filled') 
                                                 and ja.status_timestamp is not null 
                                                 and c.contract_start_date is not null 
                                                 and ja.status_timestamp < c.contract_start_date
                                                 and date_format(c.contract_start_date,'yyyyMM') = '""" + month_id + """' then datediff(c.contract_start_date, ja.status_timestamp) else null end as job_start_delay

                                          ,case when jr.target_hire_date is not null 
                                                and lower(ja.stage_reference) = 'ready for hire' 
                                                and c.contract_start_date is not null 
                                                and jr.target_hire_date < c.contract_start_date
                                                and date_format(c.contract_start_date,'yyyyMM') = '""" + month_id + """' then datediff(c.contract_start_date, jr.target_hire_date) else null end as commitment_delay_for_closed_jobs   

                                          ,case when ja.validation_trial_period is not null 
                                                 and c.contract_start_date >= to_date('""" + validation_trial_period_min + """') 
                                                 and c.contract_start_date <= to_date('""" + validation_trial_period_max + """') then 1 else null end as is_validation_trial_period 

                                          ,case when jr.target_hire_date is not null
                                                and jr.target_hire_date <= to_date('""" + date_end_month + """') 
                                                and lower(jre.Job_requisition_status_consolidated) = 'ouvert' then datediff(to_date('""" + date_end_month + """'),jr.target_hire_date) else null end as delta_desired_date_vs_reality

                                          ,case when c.contract_start_date is not null
                                                and lower(ct.contract_type) = 'cdi'
                                                and datediff(coalesce(c.contract_end_date,to_date('""" + date_end_month + """')),c.contract_start_date) >= """ + borne_6_month + """ then 1 else null end as retention_rate_6_months

                                          ,case when c.contract_start_date is not null
                                                and lower(ct.contract_type) = 'cdi'
                                                and datediff(coalesce(c.contract_end_date,to_date('""" + date_end_month + """')),c.contract_start_date) >= """ + borne_1_year + """ then 1 else null end as retention_rate_1_year

                                          ,case when c.contract_start_date is not null
                                                and lower(ct.contract_type) = 'cdi'
                                                and datediff(coalesce(c.contract_end_date,to_date('""" + date_end_month + """')),c.contract_start_date) >= """ + borne_2_year + """ then 1 else null end as retention_rate_2_years

                                          ,case when ja.candidate_response_date is not null
                                                 and date_format(jr.target_end_date, 'yyyyMM') = """ + month_id + """ then 1 else null end as candidate_response_rate_for_closed_jobs

                                          ,case when ja.job_application_date is not null 
                                                 and datediff(to_date('""" + date_end_month + """'),ja.job_application_date)>=21
                                                 and ja.candidate_response_date is not null
                                                 and jr.target_end_date is null then 1 else null end as candidate_response_rate_for_open_jobs

                                          ,case when ja.job_application_date is not null then datediff(to_date('""" + date_end_month + """'),ja.job_application_date) else null end as job_application_age    

                                          ,an.amount as external_recruitment_cost      

                                          ,ja.job_application_date

                                          ,coalesce(ca.candidate_id, -1) as candidate_id
                                          ,coalesce(sr.source_recruitment_id, -1) as source_recruitment_id
                                          ,coalesce(jap.job_application_id, -1) as job_application_id
                                          ,coalesce(jre.job_requisition_id, -1) as job_requisition_id

                                          ,coalesce(d.employee_id, -1) as employee_id
                                          ,coalesce(ct.contract_type_id, -1) as contract_type_id
                                          ,coalesce(wr.worker_rate_id, -1) as worker_rate_id
                                          ,case when upper(c.contract_type) = 'VA' or  lower(ct.contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else coalesce(csp.csp_id, -1) end as csp_id
                                          ,coalesce(nat.nationality_id, -1) as nationality_id
                                          ,coalesce(ag.range_age_id, -1) as range_age_id
                                          ,coalesce(sec.seniority_company_id, -1) as seniority_company_id
                                          ,coalesce(sep.seniority_position_id, -1) as seniority_position_id
                                          ,coalesce(loc.location_id,-1) as location_id
                                          ,coalesce(job.job_architecture_id, -1) as job_architecture_id
                                          ,coalesce(man.manager_id, -1) as manager_id
                                          ,coalesce(so.supervisory_organization_id, -1) as supervisory_organization_id
                                          ,coalesce(ol.legal_organization_id,'-1') as legal_organization_id
                                          ,coalesce(op.operational_organization_id,'-1') as operational_organization_id
                                          ,coalesce(mob_in.mobility_in_id, -1) as mobility_in_id
                                          ,coalesce(mob_out.mobility_out_id,-1) as mobility_out_id
                                          ,coalesce(id.info_dates_id, -1) as info_dates_id
                                          ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
                                          ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id

                                          ,""" + date_id + """ as date_id
                                          ,current_timestamp() as recordcreationdate
                                          ,'""" + runid + """' as runid

                               
                            from           vw_job_application ja
                                           full outer join vw_job_requisition jr on ja.job_requisition_reference = jr.job_requisition_reference
                                           
                                           left join vw_accounting_nature an on jr.cost_center_reference = an.cost_center_code
                                           left join vw_employee e on e.employee_id = ja.worker_reference
                                           left join vw_contract c on e.employee_code = c.employee_code

                                           left join vw_d_candidates ca on ca.candidate_code =  ja.candidate_id
                                           left join vw_d_source_recruitment sr on sr.source_recruitment_code = ja.source_reference_code
                                           left join vw_d_job_application jap on jap.job_application_code = ja.job_application_code  
                                           left join vw_d_job_requisition jre on jre.job_requisition_code = jr.job_requisition_code   

                                           left join vw_d_employee d on e.employee_code = d.employee_code
                                           left join vw_d_nationality nat on e.nationality_code = nat.nationality_code
                                           left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date('""" + date_id + """','yyyyMMdd'),e.birth_date,true)/12) end)
                                           left join vw_d_location loc on e.location_code = loc.location_code
                                           left join vw_d_manager man on e.manager_code = man.manager_code
                                           left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code
                                           left join vw_d_legal_organization ol on e.legal_organization_code = ol.legal_organization_code
                                           left join vw_d_operational_organization op on e.operational_organization_code = op.operational_organization_code
                                           left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code
                                           left join vw_d_mobility_in mob_in on mob_in.mobility_in_code = c.mobility_in_code
                                           left join vw_d_mobility_out mob_out on mob_out.mobility_out_code = c.mobility_out_code
                                           left join vw_d_in_out_dates iod on iod.in_out_dates_code = c.in_out_dates_code 
                                                                          and iod.org_in_out_dates_code = e.org_in_out_dates_code

                                           left join vw_contract_job_change ccc on ccc.employee_code = c.employee_code 
                                                            and c.contract_start_date = ccc.contract_start_date 
                                                            and ccc.rank=1                                                              
                                           left join vw_d_worker_rate wr on ccc.worker_rate_code = wr.worker_rate_code                                          
                                           left join vw_d_csp csp on ccc.csp_code = csp.csp_code           

                                           left join vw_d_contract_type ct on c.contract_type_code = ct.contract_type_code
                                                                          and ccc.collective_agreement_code = ct.collective_agreement_code

                                           left join vw_d_job_architecture job on ccc.job_title_code = job.job_title_code    
                                                                              and coalesce(ccc.grade_code, -1) = coalesce(job.grade_code, -1) 

                                           left join vw_d_info_dates id on id.company_dates_code = ccc.company_dates_code 
                                                                       and id.contract_dates_code = c.contract_dates_code      

                                           left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(ccc.continous_service_date) then null else datediff(to_date(seniority_date_max),to_date(ccc.continous_service_date)) end)
                                           left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(ccc.position_start_date) then null else datediff(to_date(seniority_date_max),to_date(ccc.position_start_date)) end)

                                           
                                
"""

// COMMAND ----------

val df_recruitment_results = spark.sql(query_recruitment)
df_recruitment_results.cache()

// COMMAND ----------

// DBTITLE 1,Delete data from table f_recruitment for existing loading date
val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """Exec [dbo].[usp_deletePartitionTableData] 'f_recruitment','recruitment','myMonthlyRangePS',""" + date_id
val res = stmt.execute(query_delete)


// COMMAND ----------

// DBTITLE 1,Insert data into the recruitment table
df_recruitment_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "recruitment.f_recruitment", connectionproperties)

// COMMAND ----------

val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)