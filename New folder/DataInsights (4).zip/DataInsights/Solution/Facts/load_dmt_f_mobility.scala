// Databricks notebook source
// DBTITLE 1,Get Parameters values: load_date and runid
val load_date = dbutils.widgets.get("load_date");  
val runid = dbutils.widgets.get("runid");
val start_date = dbutils.widgets.get("start_date");

// COMMAND ----------

// DBTITLE 1,Include functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Refresh delta table contract
 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table employee
 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table Job
 if(spark.catalog.tableExists("common.job")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE common.job")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Set variables
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val start_date_value = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val start_date_id = start_date_value.getYear() + ("%02d".format(start_date_value.getMonth.getValue())) + ("%02d".format(start_date_value.getDayOfMonth))
val date_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + ("%02d".format(date_value.getDayOfMonth))
val lastday =  date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_id2 = lastday.getYear() + ("%02d".format(lastday.getMonth.getValue())) + ("%02d".format(lastday.getDayOfMonth))
val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))
val year_id = date_value.getYear()
val last_year_id = date_value.plusYears(-1).getYear()

// COMMAND ----------

// DBTITLE 1,Get Dimensions data
spark.read.jdbc(jdbcurl, "dbo.d_date", connectionproperties).createOrReplaceTempView("vw_d_date")
spark.read.jdbc(jdbcurl, "staff.d_employee", connectionproperties).select("employee_id", "employee_code", "hashkey","current_version","start_date","end_date").createOrReplaceTempView("vw_d_employee")
spark.read.jdbc(jdbcurl, "staff.d_contract_type", connectionproperties).select("contract_type_id", "contract_type_code","contract_code","precarity","contract_type","contract_type_detailed", "contract_nature","current_version","collective_agreement_code").createOrReplaceTempView("vw_d_contract_type")
spark.read.jdbc(jdbcurl, "staff.d_worker_rate", connectionproperties).select("worker_rate_id", "worker_rate_code", "hashkey","current_version").createOrReplaceTempView("vw_d_worker_rate")
spark.read.jdbc(jdbcurl, "staff.d_csp", connectionproperties).select("csp_id", "csp_code","professional_category_reference","current_version").createOrReplaceTempView("vw_d_csp")
spark.read.jdbc(jdbcurl, "staff.d_nationality", connectionproperties).select("nationality_id", "nationality_code","current_version").createOrReplaceTempView("vw_d_nationality")
spark.read.jdbc(jdbcurl, "staff.d_range_age", connectionproperties).select("range_age_id", "range_age","current_version").createOrReplaceTempView("vw_d_range_age")
spark.read.jdbc(jdbcurl, "staff.d_seniority_company", connectionproperties).select("seniority_company_id", "range_seniority_company_age","current_version").createOrReplaceTempView("vw_d_seniority_company")
spark.read.jdbc(jdbcurl, "staff.d_seniority_position", connectionproperties).select("seniority_position_id", "range_seniority_position_age","current_version").createOrReplaceTempView("vw_d_seniority_position")
spark.read.jdbc(jdbcurl, "staff.d_location", connectionproperties).select("location_id", "location_code","current_version").createOrReplaceTempView("vw_d_location")
spark.read.jdbc(jdbcurl, "staff.d_job_architecture", connectionproperties).select("job_architecture_id", "job_architecture_code", "job_title", "job_profile_reference","current_version","start_date","end_date","job_title_code","grade_code").createOrReplaceTempView("vw_d_job_architecture")
spark.read.jdbc(jdbcurl, "staff.d_manager", connectionproperties).select("manager_id", "manager_code","current_version").createOrReplaceTempView("vw_d_manager")
spark.read.jdbc(jdbcurl, "staff.d_supervisory_organization", connectionproperties).select("supervisory_organization_id", "supervisory_organization_code","current_version").createOrReplaceTempView("vw_d_supervisory_organization")
spark.read.jdbc(jdbcurl, "staff.d_contract_suspension", connectionproperties).select("contract_suspension_id", "contract_suspension_code","current_version").createOrReplaceTempView("vw_d_contract_suspension")
spark.read.jdbc(jdbcurl, "staff.d_legal_organization", connectionproperties).select("legal_organization_id", "legal_organization_code", "company", "libelle_etablissement","code_etablissement", "companycode","hashkey","current_version","start_date","end_date").createOrReplaceTempView("vw_d_legal_organization")
spark.read.jdbc(jdbcurl, "staff.d_operational_organization", connectionproperties).select("operational_organization_id", "operational_organization_code", "code_departement", "code_direction", "division_detailed", "division_consolidated", "business_line_reference", "hashkey","current_version","start_date","end_date").createOrReplaceTempView("vw_d_operational_organization")
spark.read.jdbc(jdbcurl, "mobility.d_mobility_in", connectionproperties).select("mobility_in_id", "mobility_in_code","current_version").createOrReplaceTempView("vw_d_mobility_in")
spark.read.jdbc(jdbcurl, "mobility.d_mobility_out", connectionproperties).select("mobility_out_id", "mobility_out_code","current_version").createOrReplaceTempView("vw_d_mobility_out")

spark.read.jdbc(jdbcurl, "staff.d_info_dates", connectionproperties).select("info_dates_id", "info_dates_code", "position_start_date", "hire_date", "contract_start_date", "contract_end_date","current_version").createOrReplaceTempView("vw_d_info_dates")
spark.read.jdbc(jdbcurl, "mobility.d_in_out_dates", connectionproperties).select("in_out_dates_id", "in_out_dates_code", "org_in_out_dates_code","current_version").createOrReplaceTempView("vw_d_in_out_dates")
spark.read.jdbc(jdbcurl, "staff.d_contract_suspension_dates", connectionproperties).select("contract_suspension_dates_id", "contract_suspension_dates_code","current_version").createOrReplaceTempView("vw_d_contract_suspension_dates")
spark.read.jdbc(jdbcurl, "staff.d_hierarchy_pb", connectionproperties).filter("current_version = 1").select("hierarchy_pb_id", "cost_center_code").createOrReplaceTempView("vw_d_hierarchy_pb")


// COMMAND ----------

// DBTITLE 1,Get Vacataire CSP Id
val vacataire_csp_id = spark.sql("""select cast(sum(csp_id) as int) as vacataire_csp_id from vw_d_csp where lower(professional_category_reference) = 'autre statut'""").head().getInt(0)

// COMMAND ----------

// DBTITLE 1,Read contract, employee and job data for mobility
//Retrieves employee data, update the effective_organization_change_date to cost_center_start_date when effective_organization_change_date inferior to cost_center_start_date 
//filter on records inferior or egal to load_date
val df_employee_read = spark.table("hr.employee")
//                            .withColumn("effective_organization_change_date_old",$"effective_organization_change_date")
//                            .withColumn("effective_organization_change_date", when($"effective_organization_change_date" < $"cost_center_start_date",$"cost_center_start_date").otherwise($"effective_organization_change_date"))
                            .distinct
                            .filter(col("record_start_date") <= lit(date_value))
df_employee_read.createOrReplaceTempView("vw_employee")
//df_employee_read.cache()  //put the dataframe on the cache

//Retrieve contract data and update the position_start_date to contract_start_date when position_start_date inferior to contract_start_date
//filter on records inferior or egal to load_date
val df_contract_read = spark.table("hr.contract")

                            .withColumn("position_start_date_old",$"position_start_date")
                            .withColumn("position_start_date", when($"position_start_date" < $"contract_start_date",$"contract_start_date").otherwise($"position_start_date"))
                            .filter(col("record_start_date") <= lit(date_value))
                            .distinct
df_contract_read.createOrReplaceTempView("vw_contract")

//Retrieve job titles
//filter on records inferior or egal to load_date
spark.table("common.job").filter(col("record_start_date") <= lit(date_value))
                         .distinct
                         .createOrReplaceTempView("vw_job")

// COMMAND ----------

// Retrieve employee's organization and rebuild dates based on effective_organization_change_date and rebuild end date
val byorg_version = Window.partitionBy("employee_code","employee_id","france_payroll_id","cost_center_start_date").orderBy($"record_start_date".desc,$"record_end_date".desc)
val byorg_order = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"cost_center_start_date")
val by_orgdate = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"cost_center_start_date")

val df_employeehr_ope_org = spark.table("hr.employee")
.withColumn("cost_center_start_date", $"effective_organization_change_date")
.withColumn("rank",rank() over byorg_version).filter($"rank" === 1).drop("rank")
.select("employee_code","employee_id","france_payroll_id","cost_center_code","cost_center_start_date"
                   
                    ,"record_start_date"
                    ,"record_end_date"
       ).filter($"cost_center_code".isNotNull)
.withColumn("previous_cc",lag($"cost_center_code",1) over byorg_order)
.filter($"previous_cc" =!= $"cost_center_code" or $"previous_cc".isNull)
.drop($"previous_cc")
.withColumn("cost_center_end_date",date_sub(lead($"cost_center_start_date",1) over by_orgdate,1))
.withColumn("cost_center_end_date",coalesce($"cost_center_end_date",to_date(lit("2999-12-31"))))
.orderBy(asc("employee_code"),asc("record_start_date"))
df_employeehr_ope_org.createOrReplaceTempView("vw_organization")

// last version of each contract without retroactivity
val bycontract_start = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
  val df_contractstart_read = spark.table("hr.contract")
                                                .withColumn("rank_start",rank() over bycontract_start)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("contract_start_date_month",when($"contract_end_date"<last_day($"contract_start_date") and $"contract_end_date".isNotNull,$"contract_end_date").otherwise(last_day($"contract_start_date")))

                                                .filter(col("rank_start")==="1")
                                                .distinct
df_contractstart_read.createOrReplaceTempView("vw_contractstart")


//contract job change 
val bycontract_date = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"effective_job_change_date")
val bycontract_version = Window.partitionBy("employee_code","employee_id","france_payroll_id","effective_job_change_date").orderBy($"record_start_date".desc)
val df_contracthr_change = spark.table("hr.contract")
.select(
  "employee_code","employee_id","france_payroll_id"
  ,"contract_start_date"
  ,"contract_type"
  ,"worker_type"
  ,"collective_agreement_reference"
  ,"collective_agreement_group"
  ,"collective_agreement_level"
  ,"coefficient_label"
  ,"fte"
  ,"worker_rate_code"
  ,"effective_job_change_date"
  ,"record_start_date"
  ,"job_code"
  ,"csp_code"
  ,"worker_rate_code"
  ,"info_dates_code"
  ,"in_out_dates_code"  
  ,"contract_type_code"
  ,"collective_agreement_code"
).filter($"contract_start_date".isNotNull)
.withColumn("rank",rank() over bycontract_version).filter($"rank" === 1).drop("rank","record_start_date")
/*.groupBy("employee_code","employee_id","france_payroll_id"
  ,"contract_start_date"
  ,"contract_type"
  ,"worker_type"
  ,"collective_agreement_reference"
  ,"collective_agreement_group"
  ,"collective_agreement_level"
  ,"coefficient_label"
  ,"fte"
)
.agg(min("effective_job_change_date") as "effective_job_change_date"
    ,first("worker_rate_code") as "worker_rate_code" 
    ,first("csp_code") as "csp_code"
    ,first("job_code") as "job_code"
    ,first("info_dates_code") as "info_dates_code"
    ,first("in_out_dates_code") as "in_out_dates_code"
    )
*/
.orderBy("employee_code","effective_job_change_date").withColumn("record_end_date",date_sub(lead($"effective_job_change_date",1) over bycontract_date,1))
.withColumn("record_start_date",$"effective_job_change_date")
.withColumn("record_end_date",coalesce($"record_end_date",to_date(lit("2999-12-31"))))
.orderBy(asc("employee_code"),asc("record_start_date"))
df_contracthr_change.createOrReplaceTempView("vw_contract_jobchange")

// Build the employee view for each org change
val joinCondition_org = $"org.employee_code" === $"contract.employee_code" and (
                            ($"contract.contract_start_date" >= $"org.cost_center_start_date" and $"contract.contract_start_date" <= $"org.cost_center_end_date")
                            or
                            ($"contract.contract_end_date" >= $"org.cost_center_start_date" and $"contract.contract_end_date" <=  $"org.cost_center_end_date")
                             or (($"contract.contract_end_date" === to_date(lit("2999-12-31")) or $"contract.contract_end_date".isNull) and $"org.cost_center_start_date" >= $"contract.contract_start_date")
                            
                        )

val joinCondition_job = $"emp.employee_code" === $"job.employee_code" and (
                            ($"job.record_start_date" >= $"emp.contract_start_date" and ($"job.record_start_date" <= $"emp.contract_end_date" or $"emp.contract_end_date".isNull))
                            or
                            ($"job.record_end_date" >= $"emp.contract_start_date" and ($"job.record_end_date" <= $"emp.contract_end_date" or $"emp.contract_end_date".isNull or $"emp.contract_end_date" === "2999-12-31" or $"job.record_start_date" <= $"emp.contract_start_date" )) 
                          )

val joinCondition_emp = $"emp.employee_code" === $"e.employee_code" and (
                            ($"e.cost_center_start_date" >= $"emp.new_cost_center_start_date" and $"e.cost_center_start_date" <= $"emp.new_cost_center_end_date")
                            or
                            ($"emp.new_cost_center_start_date" >= $"e.cost_center_start_date" and $"emp.new_cost_center_start_date" <= $"e.cost_center_end_date")
                        )

//and ($"contract.contract_start_date" between $"org.cost_center_start_date" and $"org.cost_center_end_date" or or ($"contract.contract_end_date" === '2999-12-31' or $"contract.contract_end_date".isNull) and $"org.cost_center_start_date" > $"contract.contract_start_date") )

val byemployee_cc_start = Window.partitionBy("emp.employee_code","emp.new_cost_center_start_date","emp.contract_start_date").orderBy($"e.record_start_date".desc,$"e.date_raw_load_file".desc,$"e.record_modification_date".desc,$"record_creation_date".desc)

val df_employee_contract = df_employeehr_ope_org.as("org").join(df_contractstart_read.as("contract"),joinCondition_org)
                  .withColumn("new_cost_center_start_date",when($"contract.contract_start_date" > $"org.cost_center_start_date",$"contract.contract_start_date").otherwise($"org.cost_center_start_date"))
                  .withColumn("new_cost_center_end_date",when($"contract.contract_end_date" < $"org.cost_center_end_date",$"contract.contract_end_date").otherwise($"org.cost_center_end_date"))
                  .select(
                    "org.employee_code"
                    ,"org.employee_id"
                    ,"org.france_payroll_id"
                    ,"org.cost_center_code"
                  
                    ,"new_cost_center_start_date"
                    ,"new_cost_center_end_date"
                    ,"contract.contract_type"
                    ,"contract.contract_start_date"
                    ,"contract.contract_end_date"
                    ,"contract.position_start_date"
                    ,"contract.continous_service_date"        
                    ,"contract.original_hire_date"
                    ,"contract.collective_agreement_reference"
                    ,"contract.collective_agreement_group"
                    ,"contract.collective_agreement_level"
                    ,"contract.coefficient_label"
                    ,"contract.contract_code"
                    ,"contract.contract_type_code"
                    ,"contract.collective_agreement_code"
                  )
                  .as("emp")
                  .join(df_contracthr_change.as("job"),joinCondition_job,"left")
                  .filter($"new_cost_center_start_date" >= $"job.record_start_date" and $"new_cost_center_start_date" <= $"job.record_end_date")
  

                  .join(df_employee_read.as("e"),joinCondition_emp,"left")
                  .withColumn("rank",rank() over byemployee_cc_start).filter($"rank" === 1).drop("rank")
                  
                  .select(
                     "emp.employee_code"
                    ,"emp.employee_id"
                    ,"emp.france_payroll_id"
                    ,"emp.cost_center_code"
                    ,"emp.new_cost_center_start_date"
                    ,"emp.new_cost_center_end_date"
                    //last version of emp data
                    ,"e.legal_organization_code"
                    ,"e.operational_organization_code"
                    ,"e.effective_organization_change_date"
                    ,"e.effective_suporg_change_date"
                    ,"e.nationality_code"
                    ,"e.birth_date"
                    ,"e.location_code"               
                    ,"e.manager_code"
                    ,"e.supervisory_organization_code"
                    ,"e.establishment_start_date"
                    ,"e.establishment_end_date"
                    ,"e.company_start_date"
                    ,"e.company_end_date"
                    ,"e.organization_start_date"
                    ,"e.organization_end_date" 
                    ,"e.org_in_out_dates_code"
                    // contract data
                    ,"emp.contract_type"
                    ,"emp.contract_start_date"
                    ,"emp.contract_end_date"
                    ,"emp.position_start_date"
                    ,"emp.continous_service_date"        
                    ,"emp.original_hire_date" 
                    ,"emp.contract_code"
                    ,"emp.contract_type_code"
                    // retroactive data
                    ,"job.worker_type"
                    ,"job.collective_agreement_reference"
                    ,"job.collective_agreement_group"
                    ,"job.collective_agreement_level"
                    ,"job.coefficient_label"
                    ,"job.fte"
                    ,"job.effective_job_change_date"
                    ,"job.job_code"
                    ,"job.csp_code"
                    ,"job.worker_rate_code"
                    ,"job.info_dates_code"
                    ,"job.in_out_dates_code"
                    ,"job.collective_agreement_code"

                   )
                  

df_employee_contract.createOrReplaceTempView("vw_employee_contract_retro")


// COMMAND ----------

val sqlEmployeeContractOrgChange = """
  SELECT 

  e1.employee_code
  ,e1.employee_id
  ,e1.france_payroll_id
  ,e1.cost_center_code
  ,e1.new_cost_center_start_date
  ,e1.new_cost_center_end_date
  -- last version of emp data
  ,e1.legal_organization_code
  ,e1.operational_organization_code
  ,e1.effective_organization_change_date
  ,e1.effective_suporg_change_date
  ,e1.nationality_code
  ,e1.birth_date
  ,e1.location_code              
  ,e1.manager_code
  ,e1.supervisory_organization_code
  ,e1.establishment_start_date
  ,e1.establishment_end_date
  ,e1.company_start_date
  ,e1.company_end_date
  ,e1.organization_start_date
  ,e1.organization_end_date
  ,e1.org_in_out_dates_code
  -- contract data
  ,e1.contract_type
  ,e1.contract_start_date
  ,e1.contract_end_date
  ,e1.position_start_date
  ,e1.continous_service_date
  ,e1.original_hire_date
  -- retroactive data
  ,e1.worker_type
  ,e1.collective_agreement_reference
  ,e1.collective_agreement_group
  ,e1.collective_agreement_level
  ,e1.coefficient_label
  ,e1.fte
  ,e1.effective_job_change_date
  ,e1.job_code
  ,e1.csp_code
  ,e1.worker_rate_code
  ,e1.info_dates_code
  ,e1.in_out_dates_code
  
  ,sha2(getconcatenedstring(array(
          e1.contract_type
          ,e1.worker_type
          ,e1.collective_agreement_reference
          ,e1.collective_agreement_group
          ,e1.collective_agreement_level
          ,e1.coefficient_label
          )),256) as contract_code
          
  ,sha2(getconcatenedstring(array(
           e1.worker_type
          ,e1.collective_agreement_reference
          ,e1.collective_agreement_group
          ,e1.collective_agreement_level
          ,e1.coefficient_label
          )),256) as collective_agreement_code
  
  FROM vw_employee_contract_retro e1
  
  
  inner join vw_d_contract_type ct
  on ct.collective_agreement_code = sha2(getconcatenedstring(array(e1.worker_type
                                                            ,e1.collective_agreement_reference
                                                            ,e1.collective_agreement_group
                                                            ,e1.collective_agreement_level
                                                            ,e1.coefficient_label
                                                            )),256)
  and ct.contract_code = sha2(getconcatenedstring(array(
          e1.contract_type
          ,e1.worker_type
          ,e1.collective_agreement_reference
          ,e1.collective_agreement_group
          ,e1.collective_agreement_level
          ,e1.coefficient_label
          )),256)

  and ct.current_version = 1
                                                            
  and lower(ct.contract_type) in ('cdi','détaché') 
"""
spark.sql(sqlEmployeeContractOrgChange).createOrReplaceTempView("vw_employee_contract_retro_org")

// COMMAND ----------

// W20075055 + W00011601 + W20092729 + W20088432
//display(df_employee_contract.filter($"emp.employee_id" === "W20092729"))

// COMMAND ----------

// DBTITLE 1,Contracts
/*
val sqlContractVersion = """
  SELECT DISTINCT
  
    rank() over (partition by employee_code, contract_start_date order by  record_start_date desc,record_end_date asc ) as rnum   
    ,employee_code
    ,employee_id
    ,contract_start_date
    ,contract_end_date
    ,contract_type
    ,contract_code
    ,position_start_date
    ,continous_service_date
    ,effective_job_change_date
    ,record_start_date

    ,worker_rate_code
    ,mobility_in_code
    ,mobility_out_code
    ,info_dates_code
    ,in_out_dates_code
    ,job_code
    ,csp_code

  FROM vw_contract
"""
spark.sql(sqlContractVersion).filter(col("rnum")==="1").distinct.createOrReplaceTempView("vw_ContractVersion")
*/

// COMMAND ----------

// DBTITLE 1,Contracts Jobs
val sqlContractJobVersion = """
  SELECT DISTINCT
  
    rank() over (partition by employee_code, contract_start_date, stringNormalizer(job_title),effective_job_change_date order by  record_start_date asc,record_end_date asc ) as rnum   
    ,employee_code
    ,employee_id
    ,contract_start_date
    ,contract_end_date
    ,contract_type
    ,contract_code
    ,position_start_date
    ,continous_service_date
    ,effective_job_change_date
    ,record_start_date

    ,worker_rate_code
    ,mobility_in_code
    ,mobility_out_code
    ,info_dates_code
    ,in_out_dates_code
    ,job_code
    ,csp_code

  FROM vw_contract
"""
spark.sql(sqlContractJobVersion).filter(col("rnum")==="1").distinct.createOrReplaceTempView("vw_ContractJobVersion")

// COMMAND ----------

// DBTITLE 1,Business Line Reference change - Retrieve versions
val sqlBusinessLineChange = """

SELECT DISTINCT
    rank() over (partition by e.employee_code, stringNormalizer(lower(o.business_line_reference)) order by e.record_start_date desc, e.effective_Organization_Change_Date desc, o.end_date desc NULLS first, o.start_date desc) as rnum 
    ,e.employee_code
    ,e.employee_id
    ,e.record_start_date
    ,e.record_end_date
    ,e.cost_center_code
    
    ,o.business_line_reference
    ,c.job_code
    ,legal_organization_code
    ,e.operational_organization_code
    ,o.operational_organization_id
    ,c.position_start_date
    ,c.effective_job_change_date
    ,e.effective_organization_change_date
    ,e.effective_suporg_change_date
    ,c.csp_code
    ,e.nationality_code
    ,e.birth_date
    ,c.continous_service_date
    ,e.location_code                         
    ,e.manager_code
    ,e.supervisory_organization_code
    ,e.cost_center_start_date as date_deb_centre_cout
    ,e.cost_center_end_date as date_fin_centre_cout
    ,e.establishment_start_date as date_deb_etablissement
    ,e.establishment_end_date as date_fin_etablissement
    ,e.company_start_date as date_deb_societe
    ,e.company_end_date as date_fin_societe
    ,e.organization_start_date as date_deb_org
    ,e.organization_end_date as date_fin_org
    
    ,c.contract_code
    ,c.contract_start_date
    ,c.contract_end_date
    ,c.worker_rate_code
    ,c.info_dates_code
    ,c.in_out_dates_code
    ,e.org_in_out_dates_code
    
  FROM vw_employee e
  
  inner join vw_contractstart c
  on c.employee_code = e.employee_code
  and (e.cost_center_start_date between c.contract_start_date and ifnull(c.contract_end_date,'2999-12-31') or e.cost_center_end_date between c.contract_start_date and ifnull(c.contract_end_date,'2999-12-31'))
  

  inner join vw_d_contract_type ct on c.contract_code = ct.contract_code and ct.current_version = 1
  and lower(ct.contract_type) in ('cdi','détaché')
  
  inner JOIN vw_d_operational_organization o
  ON o.operational_organization_code = e.operational_organization_code
  
  where ifnull(o.business_line_reference,'') <> ''
  
"""
spark.sql(sqlBusinessLineChange).filter(col("rnum")==="1").distinct.createOrReplaceTempView("vw_BLEmployee")

// COMMAND ----------

// DBTITLE 1,Check Change Business Line Reference
val query_bl_change = """
  select 


    rank() over (partition by e1.employee_id , e1.business_line_reference  order by e1.record_start_date desc,  e2.record_start_date desc) as rnum, 

    e1.employee_code, 
    e1.employee_id,
    
    date_format(case when (e1.effective_organization_change_date = e2.effective_organization_change_date or e2.effective_organization_change_date > e1.effective_organization_change_date) then e1.record_start_date else e1.effective_organization_change_date end,'yyyyMMdd') as date_id,
      
    case when ifnull(e1.business_line_reference,'') <> ifnull(e2.business_line_reference,'') then 1 else null end as is_change_business_line,

    e1.operational_organization_id as new_operational_organization_id,
    o2.operational_organization_id as old_operational_organization_id,
    e1.record_start_date as new_record_start_date,
    e2.record_start_date as old_record_start_date ,
    e1.cost_center_code
   
    ,e1.job_code
    ,e1.legal_organization_code
    ,e1.operational_organization_code
    ,e1.position_start_date
    ,e1.effective_job_change_date
    ,case when e1.effective_organization_change_date < e2.effective_organization_change_date then e2.effective_organization_change_date else e1.effective_organization_change_date end effective_organization_change_date
    ,e1.effective_suporg_change_date
    ,e1.csp_code
    ,e1.nationality_code
    ,e1.birth_date
    ,e1.continous_service_date
    ,e1.location_code                         
    ,e1.manager_code
    ,e1.supervisory_organization_code    
    ,e1.date_deb_centre_cout
    ,e1.date_fin_centre_cout
    ,e1.date_deb_etablissement
    ,e1.date_fin_etablissement
    ,e1.date_deb_societe
    ,e1.date_fin_societe
    ,e1.date_deb_org
    ,e1.date_fin_org
    
    ,e2.operational_organization_code as old_operational_organization_code
    
    ,e1.contract_code
    ,e1.contract_start_date
    ,e1.contract_end_date
    ,e1.worker_rate_code
    ,e1.info_dates_code
    ,e1.in_out_dates_code    
    ,e1.org_in_out_dates_code
    ,e1.effective_job_change_date   
    
  from vw_BLEmployee e1 

  inner join vw_BLEmployee e2 on e1.employee_code = e2.employee_code 
  and ifnull(e1.business_line_reference,'') <> ifnull(e2.business_line_reference,'')
 
  and (e1.contract_start_date = e2.contract_start_date or e1.contract_start_date = date_add(e2.contract_end_date,1)) 
  and (
    (e1.record_start_date > e2.record_start_date and e1.record_start_date > e1.effective_organization_change_date)
  )
  left join vw_d_operational_organization o2 on e2.operational_organization_code = o2.operational_organization_code and o2.current_version = 1
                      
  where 1=1
  and (
    e1.effective_organization_change_date <= to_date('""" + date_id + """',"yyyyMMdd")
    or
    e1.record_start_date <= to_date('""" + date_id + """',"yyyyMMdd")
  )                         
                            
                            """
spark.sql(query_bl_change).filter(col("rnum")==="1").distinct.createOrReplaceTempView("vw_employee_bl_change")

// COMMAND ----------

// DBTITLE 1,Check Change Job Title
// check job title ignoring case and accents
// job change date based on max (position start and effective job change)
val sqlJobChange = """

SELECT DISTINCT
    rank() over (partition by e.employee_code, stringNormalizer(lower(j.job_title)), effective_job_change_date order by e.record_start_date desc, position_start_date asc,cost_center_start_date asc ) as rnum 
    ,rank() over (partition by e.employee_code, effective_job_change_date order by c.record_start_date desc) as rnum_change
    ,e.employee_code
    ,e.employee_id
    ,e.record_start_date
    ,e.record_end_date
    ,e.cost_center_code

    ,c.job_code
    ,j.job_title
    ,legal_organization_code
    ,operational_organization_code
    ,position_start_date
    ,effective_job_change_date
    ,CASE WHEN position_start_date <= effective_job_change_date THEN effective_job_change_date ELSE position_start_date END AS job_change_date
    ,effective_organization_change_date
    ,effective_suporg_change_date
    ,csp_code
    ,nationality_code
    ,birth_date
    ,continous_service_date
    ,location_code                         
    ,manager_code
    ,supervisory_organization_code
    ,cost_center_start_date as date_deb_centre_cout
    ,cost_center_end_date as date_fin_centre_cout
    ,establishment_start_date as date_deb_etablissement
    ,establishment_end_date as date_fin_etablissement
    ,company_start_date as date_deb_societe
    ,company_end_date as date_fin_societe
    ,organization_start_date as date_deb_org
    ,organization_end_date as date_fin_org
    
    ,c.contract_code
    ,contract_start_date
    ,contract_end_date
    ,worker_rate_code
    ,info_dates_code
    ,c.in_out_dates_code
    ,e.org_in_out_dates_code
    ,stringNormalizer(lower(j.job_title)) as job_title_clean
    
  FROM vw_employee e
  
  inner join vw_ContractJobVersion c
  on c.employee_code = e.employee_code
  --and ifnull(e.cost_center_start_date,(CASE WHEN position_start_date < effective_job_change_date THEN effective_job_change_date ELSE position_start_date END)) between c.contract_start_date and ifnull(c.contract_end_date,now())
   and (CASE WHEN position_start_date <= effective_job_change_date THEN effective_job_change_date ELSE position_start_date END) between c.contract_start_date and ifnull(c.contract_end_date,now())

  inner join vw_d_contract_type ct on c.contract_code = ct.contract_code and ct.current_version = 1
  and lower(ct.contract_type) in ('cdi','détaché')
  
  INNER JOIN vw_job j
  ON j.job_code = c.job_code
  
"""

val byjob = Window.partitionBy("employee_code").orderBy($"effective_job_change_date".desc, $"record_start_date".desc,$"position_start_date".desc)

spark.sql(sqlJobChange).filter(col("rnum")==="1").filter(col("rnum_change")==="1")
.withColumn("effective_job_change_date_previous",lead($"effective_job_change_date", 1, null).over(byjob))
.distinct.createOrReplaceTempView("vw_jobEmployee")

// COMMAND ----------

// DBTITLE 1,Check Change Job Title
val query_job_change = """
  select 


    rank() over (partition by e1.employee_id, e1.job_code order by e1.effective_job_change_date desc, e2.record_start_date desc,e2.position_start_date desc,e2.effective_job_change_date desc ) as rnum, 

    e1.employee_code, 
    e1.employee_id,
    
    date_format(case when e1.job_change_date = e2.job_change_date then e1.record_start_date else e1.job_change_date end,'yyyyMMdd') as date_id,
      
    case when ifnull(stringNormalizer(j1.job_title),'') <> ifnull(stringNormalizer(j2.job_title),'') then 1 else null end as is_change_job_title,
    case when ifnull(j1.job_profile_reference,'') <> ifnull(j2.job_profile_reference,'') then 1 else null end as is_change_job_profile,

    e1.position_start_date as new_position_start_date,
    e2.position_start_date as old_position_start_date,
    j1.job_architecture_id as new_job_architecture_id,
    j2.job_architecture_id as old_job_architecture_id,
    e1.record_start_date as new_record_start_date,
    e2.record_start_date as old_record_start_date 
   
    ,e1.cost_center_code
    ,e1.job_code
    ,e1.legal_organization_code
    ,e1.operational_organization_code
    ,e1.position_start_date
    ,e1.effective_job_change_date
    ,e1.effective_organization_change_date
    ,e1.effective_suporg_change_date
    ,e1.csp_code
    ,e1.nationality_code
    ,e1.birth_date
    ,e1.continous_service_date
    ,e1.location_code                         
    ,e1.manager_code
    ,e1.supervisory_organization_code    
    ,e1.date_deb_centre_cout
    ,e1.date_fin_centre_cout
    ,e1.date_deb_etablissement
    ,e1.date_fin_etablissement
    ,e1.date_deb_societe
    ,e1.date_fin_societe
    ,e1.date_deb_org
    ,e1.date_fin_org
    ,e2.csp_code as old_csp_code
    
    ,e1.contract_code
    ,e1.contract_start_date
    ,e1.contract_end_date
    ,e1.worker_rate_code
    ,e1.info_dates_code
    ,e1.in_out_dates_code    
    ,e1.org_in_out_dates_code
    ,e1.effective_job_change_date
    
  from vw_jobEmployee e1 

  inner join vw_jobEmployee e2 on e1.employee_code = e2.employee_code 
  and e1.job_code <> e2.job_code
  and e1.legal_organization_code = e2.legal_organization_code
  and e1.operational_organization_code = e2.operational_organization_code
  and (e1.contract_start_date = e2.contract_start_date or e1.contract_start_date = date_add(e2.contract_end_date,1))
  and (
    e1.job_change_date > e2.job_change_date
    or
    (e1.record_start_date > e2.record_start_date and (e1.record_start_date > e1.job_change_date or e1.record_start_date > e1.position_start_date))
  )
  and e1.effective_job_change_date_previous = e2.effective_job_change_date
  left join vw_d_job_architecture j1 on e1.job_code = j1.job_architecture_code and j1.current_version = 1
  left join vw_d_job_architecture j2 on e2.job_code = j2.job_architecture_code and j2.current_version = 1
                      
  where 1=1
  and (
    e1.position_start_date <= to_date('""" + date_id + """',"yyyyMMdd")
    or
    e1.record_start_date <= to_date('""" + date_id + """',"yyyyMMdd")
  )                            
                            
                            """

// COMMAND ----------

spark.sql(query_job_change).filter(col("rnum")==="1").distinct.createOrReplaceTempView("vw_employee_job_change")

// COMMAND ----------

// DBTITLE 1,Orga Change - Retrieve Versions
/*
val sqlOrgChange2 = """
  SELECT DISTINCT
    rank() over (partition by e.employee_code, cost_center_code , cost_center_start_date, contract_start_date order by e.record_start_date asc, cost_center_start_date asc ) as rnum 
    ,ifnull(LAG(cost_center_code, 1) over (partition by e.employee_code order by cost_center_start_date asc, e.record_start_date asc  ),'') AS Previous_CC 
    ,ifnull(LAG(cost_center_start_date, 1) over (partition by e.employee_code order by cost_center_start_date asc, e.record_start_date asc  ),'') AS Previous_CC_start 
    ,ifnull(LAG(cost_center_end_date, 1) over (partition by e.employee_code order by cost_center_start_date asc, e.record_start_date asc  ),'') AS Previous_CC_end 
    ,ifnull(LAG(contract_start_date, 1) over (partition by e.employee_code order by cost_center_start_date asc, e.record_start_date asc  ),'') AS Previous_CTR_start 
    ,ifnull(LAG(contract_end_date, 1) over (partition by e.employee_code order by cost_center_start_date asc, e.record_start_date asc  ),'') AS Previous_CTR_end 
    ,ifnull(LAG(effective_organization_change_date, 1) over (partition by e.employee_code order by cost_center_start_date asc, e.record_start_date asc  ),'') AS Previous_Eff_Org_Change_Date
    ,e.employee_code
    ,e.employee_id
    ,e.record_start_date
    ,e.record_end_date
    
    ,e.cost_center_code
    ,c.job_code
    ,e.legal_organization_code
    ,e.operational_organization_code
    ,c.position_start_date
    ,c.effective_job_change_date
    ,e.effective_organization_change_date
    ,e.effective_suporg_change_date
    ,c.csp_code
    ,e.nationality_code
    ,e.birth_date
    ,c.continous_service_date
    ,e.location_code                         
    ,e.manager_code
    ,e.supervisory_organization_code
    ,e.cost_center_start_date as date_deb_centre_cout
    ,e.cost_center_end_date as date_fin_centre_cout
    ,e.establishment_start_date as date_deb_etablissement
    ,e.establishment_end_date as date_fin_etablissement
    ,e.company_start_date as date_deb_societe
    ,e.company_end_date as date_fin_societe
    ,e.organization_start_date as date_deb_org
    ,e.organization_end_date as date_fin_org    

    ,ct.contract_type
    ,c.contract_code
    ,c.contract_start_date
    ,c.contract_end_date
    ,c.worker_rate_code
    ,c.info_dates_code
    ,c.in_out_dates_code
    ,e.org_in_out_dates_code
    

  FROM vw_employee e
  
  inner join vw_contractstart c
  on c.employee_code = e.employee_code
  and (e.cost_center_start_date between c.contract_start_date and ifnull(c.contract_end_date,'2999-12-31') or (e.cost_center_end_date > c.contract_start_date and (e.cost_center_end_date <= ifnull(c.contract_end_date,'2999-12-31') or e.cost_center_end_date = '2999-12-31')))

  inner join vw_d_contract_type ct on c.contract_code = ct.contract_type_code and ct.current_version = 1
  and lower(ct.contract_type) in ('cdi','détaché')
  
"""
spark.sql(sqlOrgChange2).filter(col("rnum")==="1" and col("Previous_CC")=!=col("cost_center_code") and (col("Previous_Eff_Org_Change_Date")<=col("effective_organization_change_date") or col("Previous_Eff_Org_Change_Date") === "") ).distinct.createOrReplaceTempView("vw_OrgEmployee2")
*/

// COMMAND ----------

// DBTITLE 1,Orga Change - Retrieve Latest Versions
/*
val sqlOrgChange = """
  SELECT DISTINCT
     rank() over (partition by e.employee_code, e.cost_center_code , e.date_deb_centre_cout order by e.record_start_date asc, e2.record_start_date desc, e.date_deb_centre_cout asc ) as rnum2
    ,e.rnum 
    ,e.Previous_CC 
    ,e.Previous_CC_start 
    ,e.Previous_CC_end 
    ,e.employee_code
    ,e.employee_id
    ,e.record_start_date
    ,ifnull(e2.record_end_date,e.record_end_date) record_end_date    
    ,e.cost_center_code
    ,e.job_code
    ,case when ifnull(e2.legal_organization_code,'') <> e.legal_organization_code and e2.legal_organization_code is not null then e2.legal_organization_code else e.legal_organization_code end  legal_organization_code
    ,case when ifnull(e2.operational_organization_code,'') <> e.operational_organization_code and e2.operational_organization_code is not null then e2.operational_organization_code else e.operational_organization_code end operational_organization_code 
    ,e.position_start_date
    ,e.effective_job_change_date
    ,e.effective_organization_change_date
    ,e.effective_suporg_change_date
    ,e.csp_code
    ,e.nationality_code
    ,e.birth_date
    ,e.continous_service_date
    ,e.location_code                         
    ,case when ifnull(e2.manager_code,'') <> ifnull(e.manager_code,'') and e2.manager_code is not null then e2.manager_code else e.manager_code end manager_code
    ,case when ifnull(e2.supervisory_organization_code,'') <> ifnull(e.supervisory_organization_code,'') and e2.supervisory_organization_code is not null then e2.supervisory_organization_code else e.supervisory_organization_code end supervisory_organization_code
    ,e.date_deb_centre_cout
    ,case when ifnull(e2.cost_center_end_date,'') <> ifnull(e.date_fin_centre_cout,'') and e2.cost_center_end_date is not null then e2.cost_center_end_date else e.date_fin_centre_cout end date_fin_centre_cout
    ,e.date_deb_etablissement
    ,e.date_fin_etablissement
    ,e.date_deb_societe
    ,e.date_fin_societe
    ,e.date_deb_org
    ,case when ifnull(e2.organization_end_date,'') <> ifnull(e.date_fin_org,'') and e2.organization_end_date is not null then e2.organization_end_date else e.date_fin_org end date_fin_org    
    ,e.contract_type
    ,e.contract_code
    ,e.contract_start_date
    ,e.contract_end_date
    ,last_start_ctr
    ,last_end_ctr
    ,e.worker_rate_code
    ,e.info_dates_code
    ,e.in_out_dates_code
    ,e.org_in_out_dates_code
    
    
    
from (
SELECT DISTINCT
    ifnull(LEAD(Previous_CC_start, 1) over (partition by employee_code order by date_deb_centre_cout asc, record_start_date asc  ),'') AS last_start_cc, 
    ifnull(LEAD(Previous_CC_end, 1) over (partition by employee_code order by date_deb_centre_cout asc, record_start_date asc  ),'') AS last_end_cc, 
    ifnull(LEAD(Previous_CTR_start, 1) over (partition by employee_code order by date_deb_centre_cout asc, record_start_date asc  ),'') AS last_start_ctr, 
    ifnull(LEAD(Previous_CTR_end, 1) over (partition by employee_code order by date_deb_centre_cout asc, record_start_date asc  ),'') AS last_end_ctr, 
    *  
from vw_OrgEmployee2) e
left join vw_employee e2 on e.employee_code = e2.employee_code and cost_center_start_date = last_start_cc and cost_center_end_date = last_end_cc

"""
spark.sql(sqlOrgChange).filter(col("rnum2")==="1").distinct.createOrReplaceTempView("vw_OrgEmployee")
*/

// COMMAND ----------

// DBTITLE 1,Orga Change based on effective organization change date
val sql_OrgaChange = """
select 

  rank() over (partition by e1.employee_code, e1.new_cost_center_start_date order by e1.new_cost_center_start_date ,e2.new_cost_center_start_date desc ) as rnum,


  e1.employee_code, 
  e1.employee_id,

  date_format(e1.new_cost_center_start_date,'yyyyMMdd') as date_id,

  case when ifnull(e1.cost_center_code,'') <>  ifnull(e2.cost_center_code,'') then 1 else null end as is_change_legal_cc,
  case when ifnull(l1.code_etablissement,'') <>  ifnull(l2.code_etablissement,'') then 1 else null end as is_change_etablissement,
  case when ifnull(l1.companycode,'') <>  ifnull(l2.companycode,'') then 1 else null end as is_change_company,

   
  case when ifnull(e1.cost_center_code,'') <>  ifnull(e2.cost_center_code,'') then 1 else null end as is_change_ope_cc,
  case when ifnull(o1.code_departement,'') <> ifnull(o2.code_departement,'') then 1 else null end as is_change_departement,
  case when ifnull(o1.code_direction,'') <> ifnull(o2.code_direction,'') then 1 else null end as is_change_direction,
  case when ifnull(o1.division_detailed,'') <> ifnull(o2.division_detailed,'') then 1 else null end as is_change_division_detailed,
  case when ifnull(o1.division_consolidated,'') <> ifnull(o2.division_consolidated,'') then 1 else null end as is_change_division_consolidated,
  case when ifnull(o1.business_line_reference,'') <> ifnull(o2.business_line_reference,'') then 1 else null end as is_change_business_line_reference,

  case when ifnull(e1.cost_center_code,'') <>  ifnull(e2.cost_center_code,'') and (ifnull(o1.code_departement,'') <>  ifnull(o2.code_departement,'') or 
                                                             ifnull(o1.code_direction,'') <>  ifnull(o2.code_direction,'') or 
                                                             ifnull(o1.division_detailed,'') <> ifnull(o2.division_detailed,'') or 
                                                             ifnull(o1.division_consolidated,'') <> ifnull(o2.division_consolidated,'')) then 1 else null end as is_mobility_extra,

  case when ifnull(e1.cost_center_code,'') <>  ifnull(e2.cost_center_code,'') and ifnull(o1.code_departement,'') =  ifnull(o2.code_departement,'') and
                                                            ifnull(o1.code_direction,'') =  ifnull(o2.code_direction,'') and
                                                            ifnull(o1.division_detailed,'') = ifnull(o2.division_detailed,'') and
                                                            ifnull(o1.division_consolidated,'') = ifnull(o2.division_consolidated,'') then 1 else null end as is_mobility_intra,
                                                              

  e1.cost_center_code as new_cost_center_code,
  e2.cost_center_code as old_cost_center_code,
 
  o1.code_departement as new_code_departement,
  o2.code_departement as old_code_departement,
  o1.code_direction as new_code_direction,
  o2.code_direction as old_code_direction,

  e1.new_cost_center_start_date as new_date_deb_centre_cout,
  e1.new_cost_center_end_date as new_date_fin_centre_cout,
  e2.new_cost_center_start_date as old_date_deb_centre_cout,
  e2.new_cost_center_end_date as old_date_fin_centre_cout,

  e1.organization_start_date as new_date_deb_org,
  e1.organization_end_date as new_date_fin_org,
  e2.organization_start_date as old_date_deb_org,
  e2.organization_end_date as old_date_fin_org,


  e1.operational_organization_code as new_operational_organization_code,
  e2.operational_organization_code as old_operational_organization_code,
  o1.operational_organization_id as new_operational_organization_id,
  o2.operational_organization_id as old_operational_organization_id,

  e1.establishment_start_date as new_date_deb_etablissement,
  e1.establishment_end_date as new_date_fin_etablissement,
  e2.establishment_start_date as old_date_deb_etablissement,
  e2.establishment_end_date as old_date_fin_etablissement,
  e1.company_start_date as new_date_deb_societe,
  e1.organization_end_date as new_date_fin_societe,
  e2.company_start_date as old_date_deb_societe,
  e2.organization_end_date as old_date_fin_societe,

  e1.legal_organization_code as new_legal_organization_code,
  e2.legal_organization_code as old_legal_organization_code,
  l1.legal_organization_id as new_legal_organization_id,
  l2.legal_organization_id as old_legal_organization_id,
    
  e1.job_code
  ,e1.position_start_date
  ,e1.effective_job_change_date
  ,e1.effective_organization_change_date
  ,e1.effective_suporg_change_date
  ,e1.csp_code
  ,e1.nationality_code
  ,e1.birth_date
  ,e1.continous_service_date
  ,e1.location_code                         
  ,e1.manager_code
  ,e1.supervisory_organization_code    
    
  ,e2.job_code as old_job_code
  ,e2.position_start_date as old_position_start_date 
  ,e2.effective_job_change_date as old_effective_job_change_date
  ,e2.effective_organization_change_date as old_effective_organization_change_date
  ,e2.effective_suporg_change_date as old_effective_suporg_change_date
  ,e2.csp_code as old_csp_code
  ,e2.nationality_code as old_nationality_code 
  ,e2.birth_date as old_birth_date 
  ,e2.continous_service_date as old_continous_service_date
  ,e2.location_code as old_location_code                         
  ,e2.manager_code as old_manager_code 
  ,e2.supervisory_organization_code as old_supervisory_organization_code    

  ,e1.collective_agreement_code
  ,e1.contract_code
  ,e1.contract_start_date
  ,e1.contract_end_date
  ,e1.worker_rate_code
  ,e1.info_dates_code
  ,e1.in_out_dates_code
  ,e1.org_in_out_dates_code
  ,e2.collective_agreement_code old_collective_agreement_code
  ,e2.contract_code old_contract_code
  ,e2.contract_start_date old_contract_start_date
  ,e2.contract_end_date old_contract_end_date
                  
                                                            
from vw_employee_contract_retro_org e1

inner join vw_employee_contract_retro_org e2
on e1.employee_code = e2.employee_code
and e1.new_cost_center_start_date > e2.new_cost_center_start_date
and e1.cost_center_code != e2.cost_center_code
and (e1.contract_start_date = e2.contract_start_date or e1.contract_start_date = date_add(e2.contract_end_date,1))

left join vw_d_legal_organization l1 on e1.legal_organization_code = l1.legal_organization_code and l1.current_version = 1
left join vw_d_legal_organization l2 on e2.legal_organization_code = l2.legal_organization_code and l2.current_version = 1

left join vw_d_operational_organization o1 on e1.operational_organization_code = o1.operational_organization_code and o1.current_version = 1
left join vw_d_operational_organization o2 on e2.operational_organization_code = o2.operational_organization_code and O2.current_version = 1


  where 1=1
  and (
    e1.new_cost_center_start_date <= to_date('""" + date_id + """',"yyyyMMdd")
  )
 
 """



// COMMAND ----------

// DBTITLE 1,Check Change Organization
/*val query_org_change = """
  select distinct

    rank() over (partition by e1.employee_id, e1.cost_center_code , e1.date_deb_centre_cout order by e1.date_deb_centre_cout, e2.record_start_date desc,e2.date_deb_centre_cout desc ) as rnum, 
    e1.employee_code, 
    e1.employee_id,
    
    date_format(case when e1.date_deb_centre_cout = e2.date_deb_centre_cout then e1.record_start_date else e1.date_deb_centre_cout end,'yyyyMMdd') as date_id,
    
    case when ifnull(e1.cost_center_code,'') <>  ifnull(e2.cost_center_code,'') then 1 else null end as is_change_legal_cc,
    case when ifnull(l1.code_etablissement,'') <>  ifnull(l2.code_etablissement,'') then 1 else null end as is_change_etablissement,
    case when ifnull(l1.companycode,'') <>  ifnull(l2.companycode,'') then 1 else null end as is_change_company,
   
   
    case when ifnull(e1.cost_center_code,'') <>  ifnull(e2.cost_center_code,'') then 1 else null end as is_change_ope_cc,
    case when ifnull(o1.code_departement,'') <> ifnull(o2.code_departement,'') then 1 else null end as is_change_departement,
    case when ifnull(o1.code_direction,'') <> ifnull(o2.code_direction,'') then 1 else null end as is_change_direction,
    case when ifnull(o1.division_detailed,'') <> ifnull(o2.division_detailed,'') then 1 else null end as is_change_division_detailed,
    case when ifnull(o1.division_consolidated,'') <> ifnull(o2.division_consolidated,'') then 1 else null end as is_change_division_consolidated,
    case when ifnull(o1.business_line_reference,'') <> ifnull(o2.business_line_reference,'') then 1 else null end as is_change_business_line_reference,
    
    case when ifnull(e1.cost_center_code,'') <>  ifnull(e2.cost_center_code,'') and (ifnull(o1.code_departement,'') <>  ifnull(o2.code_departement,'') or 
                                                               ifnull(o1.code_direction,'') <>  ifnull(o2.code_direction,'') or 
                                                               ifnull(o1.division_detailed,'') <> ifnull(o2.division_detailed,'') or 
                                                               ifnull(o1.division_consolidated,'') <> ifnull(o2.division_consolidated,'')) then 1 else null end as is_mobility_extra,
                                                               
    case when ifnull(e1.cost_center_code,'') <>  ifnull(e2.cost_center_code,'') and ifnull(o1.code_departement,'') =  ifnull(o2.code_departement,'') and
                                                              ifnull(o1.code_direction,'') =  ifnull(o2.code_direction,'') and
                                                              ifnull(o1.division_detailed,'') = ifnull(o2.division_detailed,'') and
                                                              ifnull(o1.division_consolidated,'') = ifnull(o2.division_consolidated,'') then 1 else null end as is_mobility_intra,
                                                              

    e1.cost_center_code as new_cost_center_code,
    e2.cost_center_code as old_cost_center_code,
 
    o1.code_departement as new_code_departement,
    o2.code_departement as old_code_departement,
    o1.code_direction as new_code_direction,
    o2.code_direction as old_code_direction,

    e1.date_deb_centre_cout as new_date_deb_centre_cout,
    e1.date_fin_centre_cout as new_date_fin_centre_cout,
    e2.date_deb_centre_cout as old_date_deb_centre_cout,
    e2.date_fin_centre_cout as old_date_fin_centre_cout,

    e1.date_deb_org as new_date_deb_org,
    e1.date_fin_org as new_date_fin_org,
    e2.date_deb_org as old_date_deb_org,
    e2.date_fin_org as old_date_fin_org,

    e1.operational_organization_code as new_operational_organization_code,
    e2.operational_organization_code as old_operational_organization_code,
    o1.operational_organization_id as new_operational_organization_id,
    o2.operational_organization_id as old_operational_organization_id,

    e1.date_deb_etablissement as new_date_deb_etablissement,
    e1.date_fin_etablissement as new_date_fin_etablissement,
    e2.date_deb_etablissement as old_date_deb_etablissement,
    e2.date_fin_etablissement as old_date_fin_etablissement,
    e1.date_deb_societe as new_date_deb_societe,
    e1.date_fin_societe as new_date_fin_societe,
    e2.date_deb_societe as old_date_deb_societe,
    e2.date_fin_societe as old_date_fin_societe,

    e1.legal_organization_code as new_legal_organization_code,
    e2.legal_organization_code as old_legal_organization_code,
    l1.legal_organization_id as new_legal_organization_id,
    l2.legal_organization_id as old_legal_organization_id,
    
    e1.record_start_date as new_record_start_date,
    e2.record_start_date as old_record_start_date
    
    ,e1.job_code
    ,e1.position_start_date
    ,e1.effective_job_change_date
    ,e1.effective_organization_change_date
    ,e1.effective_suporg_change_date
    ,e1.csp_code
    ,e1.nationality_code
    ,e1.birth_date
    ,e1.continous_service_date
    ,e1.location_code                         
    ,e1.manager_code
    ,e1.supervisory_organization_code    

    
    ,e2.job_code as old_job_code
    ,e2.position_start_date as old_position_start_date 
    ,e2.effective_job_change_date as old_effective_job_change_date
    ,e2.effective_organization_change_date as old_effective_organization_change_date
    ,e2.effective_suporg_change_date as old_effective_suporg_change_date
    ,e2.csp_code as old_csp_code
    ,e2.nationality_code as old_nationality_code 
    ,e2.birth_date as old_birth_date 
    ,e2.continous_service_date as old_continous_service_date
    ,e2.location_code as old_location_code                         
    ,e2.manager_code as old_manager_code 
    ,e2.supervisory_organization_code as old_supervisory_organization_code    
    
    ,e1.contract_code
    ,e1.contract_type_code
    ,e1.contract_start_date
    ,e1.contract_end_date
    ,e1.worker_rate_code
    ,e1.info_dates_code
    ,e1.in_out_dates_code
    ,e1.org_in_out_dates_code
    ,e2.contract_code old_contract_code
    ,e2.contract_type_code old_contract_type_code
    ,e2.contract_start_date old_contract_start_date
    ,e2.contract_end_date old_contract_end_date

    
  from vw_OrgEmployee e1 

inner join (vw_OrgEmployee e2 left join vw_contractstart c
  on c.employee_code = e2.employee_code
  and c.contract_start_date between e2.contract_end_date and date_add(e2.last_start_ctr,-1) and e2.contract_end_date is not null) on e1.employee_code = e2.employee_code
  
  and ((e1.contract_start_date = e2.contract_start_date) or (e1.contract_start_date = date_add(e2.contract_end_date,1)) or (e1.contract_start_date = date_add(e2.last_end_ctr,1)) or (e1.contract_start_date = date_add(c.contract_end_date,1)))
  and (e1.cost_center_code <> e2.cost_center_code and ifnull(e1.cost_center_code,'') <> '' and ifnull(e2.cost_center_code,'') <> '')
  and (
    e1.date_deb_centre_cout > e2.date_deb_centre_cout
    or
    (e1.record_start_date > e2.record_start_date and e1.record_start_date > e1.date_deb_centre_cout)
  )
 
  left join vw_d_legal_organization l1 on e1.legal_organization_code = l1.legal_organization_code and l1.current_version = 1
  left join vw_d_legal_organization l2 on e2.legal_organization_code = l2.legal_organization_code and l2.current_version = 1

  left join vw_d_operational_organization o1 on e1.operational_organization_code = o1.operational_organization_code and o1.current_version = 1
  left join vw_d_operational_organization o2 on e2.operational_organization_code = o2.operational_organization_code and O2.current_version = 1
    
  where 1=1
  and (
    e1.date_deb_centre_cout <= to_date('""" + date_id + """',"yyyyMMdd")
    or
    e1.record_start_date <= to_date('""" + date_id + """',"yyyyMMdd")
  )
 
 and
    date_format(e1.contract_start_date,'yyyyMM') <= date_format(case when e1.date_deb_centre_cout = e2.date_deb_centre_cout then e1.record_start_date else e1.date_deb_centre_cout end,'yyyyMM') 
 and
   (date_format(e1.contract_end_date,'yyyyMM') >= date_format(case when e1.date_deb_centre_cout = e2.date_deb_centre_cout then e1.record_start_date else e1.date_deb_centre_cout end,'yyyyMM') or e1.contract_end_date is null)
    """
*/    

// COMMAND ----------

//spark.sql(query_org_change).filter(col("rnum")==="1").distinct.createOrReplaceTempView("vw_employee_org_change")
spark.sql(sql_OrgaChange).filter(col("rnum")==="1").distinct.createOrReplaceTempView("vw_employee_org_change")



// COMMAND ----------

// DBTITLE 1,Check Change Contract
val query_contract_change = """ 
  select distinct  
  
       rank() over (partition by c1.employee_id, c1.contract_start_date, c1.contract_code order by c1.contract_end_date desc NULLS FIRST,c2.contract_start_date desc ,c2.contract_end_date desc NULLS FIRST, c2.record_start_date desc) as rnum, 
  
    c1.employee_code, 
    c1.employee_id,
    c1.mobility_in_code,
    c1.mobility_out_code,
    
    c1.contract_start_date as new_contract_start_date,
    c2.contract_start_date as old_contract_start_date,
    c1.contract_end_date as new_contract_end_date,
    c2.contract_end_date as old_contract_end_date,  
    
    date_format(case when c1.contract_start_date = c2.contract_start_date then c1.record_start_date else c1.contract_start_date end,'yyyyMMdd') as date_id,

    case when c1.contract_start_date is not null
    then
      case when lower(ct1.contract_type) in ('cdi','détaché')
      then
        case when lower(ct2.contract_type) in ('cdi','détaché')
        then
          case when c1.contract_start_date > date_add(c2.contract_end_date,1)
          then
            1
          else
            null
          end
        else
          1
        end
      else
        1
      end
    end as is_entry,
        
    case when lower(ct1.contract_type) in ('cdi','détaché') and c1.contract_start_date is not null and (c2.contract_code is null  or c1.contract_start_date > date_add(c2.contract_end_date,1) or lower(ct2.contract_type) not in ('cdi','détaché')) then 1 else null end as is_entry_cdi,
    
    
    case when c1.contract_start_date is not null then 1 else null end as is_contract_start,
    
    c1.contract_code as new_contract_code,
    c2.contract_code as old_contract_code,
    ct1.contract_type,
    ct2.contract_type as old_contract_type,

    case when ct2.contract_type is not null and ifnull(ct1.contract_type,'') <> ifnull(ct2.contract_type,'') and not (lower(ct1.contract_type) in ('cdi','détaché') and lower(ct2.contract_type) in ('cdi','détaché')) and datediff(c1.contract_start_date,c2.contract_end_date)<=30 then 1 else null end as is_change_contract,
    case when ifnull(ct1.contract_type,'') <> ifnull(ct2.contract_type,'') and datediff(c1.contract_start_date,c2.contract_end_date)<=30 
              and lower(ct1.contract_type) = 'cdd' and lower(ct2.contract_type) = 'stagiaire'  then 1 else null end as is_change_stagiaire_cdd,
    case when ct2.contract_type is not null and ifnull(ct1.contract_type,'') <> ifnull(ct2.contract_type,'') and datediff(c1.contract_start_date,c2.contract_end_date)<=30 
              and lower(ct1.contract_type) = 'cdi' and lower(ct2.contract_type) = 'stagiaire'  then 1 else null end as is_change_stagiaire_cdi,
    case when ifnull(ct1.contract_type,'') <> ifnull(ct2.contract_type,'') and datediff(c1.contract_start_date,c2.contract_end_date)<=30 
              and lower(ct1.contract_type) = 'cdd' and lower(ct2.contract_type) = 'alternant'  then 1 else null end as is_change_alternant_cdd,
    case when ifnull(ct1.contract_type,'') <> ifnull(ct2.contract_type,'') and datediff(c1.contract_start_date,c2.contract_end_date)<=30 
              and lower(ct1.contract_type) = 'cdi' and lower(ct2.contract_type) = 'alternant'  then 1 else null end as is_change_alternant_cdi,
    case when ifnull(ct1.contract_type,'') <> ifnull(ct2.contract_type,'') and datediff(c1.contract_start_date,c2.contract_end_date)<=30 
              and lower(ct1.contract_type) = 'cdi' and lower(ct2.contract_type) = 'cdd'  then 1 else null end as is_change_cdd_cdi,            
    case when ifnull(ct1.contract_type,'') <> ifnull(ct2.contract_type,'') and datediff(c1.contract_start_date,c2.contract_end_date)<=30 
              and lower(ct1.contract_type) in ('cdi','cdd') and lower(ct2.contract_type) in ('stagiaire', 'alternant')  then 1 else null end as is_change_ecole_cdd_cdi,            
    ct1.contract_type_id as new_contract_type_id,
    ct2.contract_type_id as old_contract_type_id
  
    ,c1.contract_code
    ,c1.worker_rate_code
    ,c1.mobility_in_code
    ,c1.mobility_out_code
    ,c1.info_dates_code
    ,c1.in_out_dates_code
    ,c1.csp_code
    ,c2.csp_code as old_csp_code
    ,c1.job_code
    ,c2.mobility_out_code as old_mobility_out_code
    ,ct1.contract_type_detailed as new_contract_type_detailed
    ,ct2.contract_type_detailed as old_contract_type_detailed
    ,c1.record_start_date
    ,c1.continous_service_date
    ,c1.position_start_date
    ,c1.effective_job_change_date
    

    
  from vw_contractstart c1 
  
  left join vw_contractstart c2 on c1.employee_code = c2.employee_code 
  and (
    c1.contract_start_date > c2.contract_start_date
    or
    (c1.record_start_date > c2.record_start_date and c1.record_start_date > c1.contract_start_date)
  )

  left join vw_d_contract_type ct1 on c1.contract_code = ct1.contract_code and ct1.current_version = 1
  left join vw_d_contract_type ct2 on c2.contract_code = ct2.contract_code and ct2.current_version = 1


  where 1=1
  and (
    c1.contract_start_date <= to_date('""" + date_id + """',"yyyyMMdd")
    or
    c1.record_start_date <= to_date('""" + date_id + """',"yyyyMMdd")
  )
           """
spark.sql(query_contract_change).filter(col("rnum")==="1").distinct.createOrReplaceTempView("vw_contract_change")


// COMMAND ----------

// DBTITLE 1,Check Contract End - Leaves
val query_contract_end = """ 
  select distinct  
  
         rank() over (partition by c1.employee_id, c1.contract_start_date, c1.contract_code order by c1.contract_end_date desc NULLS FIRST) as rnum, 
  
    c1.employee_code, 
    c1.employee_id,
    
    c1.contract_start_date as contract_start_date,
    c1.contract_end_date as contract_end_date, 
 
    null as new_contract_start_date,
    null as new_contract_end_date,  
    
    c1.contract_end_date as date_id,
        
    null as new_contract_code,
    ct1.contract_type,
    ct1.contract_type_detailed
    ,1 is_leave
    ,case when lower(ct1.contract_type) in ('cdi') then 1 else null end as is_leave_cdi
    ,1 as is_contract_end  
    
    ,-1 as new_contract_type_id
    
    ,ct1.contract_type_id
    
    ,c1.contract_code
    
    ,c1.worker_rate_code
    ,c1.mobility_in_code
    ,c1.mobility_out_code
    ,c1.info_dates_code
    ,c1.in_out_dates_code
    ,c1.csp_code
    ,c1.job_code
    ,c1.continous_service_date
    ,c1.position_start_date
    ,c1.effective_job_change_date
    
  
  
  from vw_contractstart c1 
  
  left join vw_d_contract_type ct1 on c1.contract_code = ct1.contract_code and ct1.current_version = 1
  
 
  where c1.contract_end_date is not null
  and (
    date_add(c1.contract_end_date,1) <= to_date('""" + date_id2 + """',"yyyyMMdd")
  )

and not exists (
    select 1
    from vw_contractstart c2
    left join vw_d_contract_type ct2 on c2.contract_code = ct2.contract_code and ct2.current_version = 1
    where (lower(ct1.contract_type) in ('cdi','détaché') and lower(ct2.contract_type) in ('cdi','détaché'))
    and date_add(c1.contract_end_date,1) = c2.contract_start_date
    and c1.employee_code = c2.employee_code 
)
"""

spark.sql(query_contract_end).filter(col("rnum")==="1").distinct.createOrReplaceTempView("vw_leaves")

// COMMAND ----------



// COMMAND ----------

// DBTITLE 1,Check Contract End
val query_contract_end = """ 
  select distinct  
  
         rank() over (partition by c1.employee_id, c1.contract_start_date, c1.contract_code order by c1.contract_end_date desc NULLS FIRST) as rnum, 
  
    c1.employee_code, 
    c1.employee_id,
    
    c1.contract_start_date as contract_start_date,
    c1.contract_end_date as contract_end_date, 
 
    null as new_contract_start_date,
    null as new_contract_end_date,  
    
    c1.contract_end_date as date_id,
        
    null as new_contract_code,
    ct1.contract_type,
    ct1.contract_type_detailed
    ,null is_leave
    ,null is_leave_cdi
    ,1 as is_contract_end  
    
    ,-1 as new_contract_type_id
    
    ,ct1.contract_type_id
    
    ,c1.contract_code
    
    ,c1.worker_rate_code
    ,c1.mobility_in_code
    ,c1.mobility_out_code
    ,c1.info_dates_code
    ,c1.in_out_dates_code
    ,c1.csp_code
    ,c1.job_code
    ,c1.continous_service_date
    ,c1.position_start_date
    ,c1.effective_job_change_date
    
  
  
  from vw_contractstart c1 
  
  left join vw_d_contract_type ct1 on c1.contract_code = ct1.contract_code and ct1.current_version = 1
  
 
  where c1.contract_end_date is not null
  and (
    date_add(c1.contract_end_date,1) <= to_date('""" + date_id2 + """',"yyyyMMdd")
  )

"""

spark.sql(query_contract_end).filter(col("rnum")==="1").distinct.createOrReplaceTempView("vw_contract_end")

// COMMAND ----------

val by_date = Window.partitionBy("employee_code").orderBy($"date_deb_centre_cout")

val queryContractEmployee = """


  SELECT DISTINCT
    rank() over (partition by employee_code,cost_center_start_date order by record_start_date desc, record_end_date ) as rnum 
    ,employee_code
    ,employee_id
    ,record_start_date
    ,record_end_date
    
    ,cost_center_code
    ,legal_organization_code
    ,operational_organization_code
    ,effective_organization_change_date
    ,effective_suporg_change_date
    ,nationality_code
    ,birth_date
    ,location_code                         
    ,manager_code
    ,supervisory_organization_code
    ,cost_center_start_date as date_deb_centre_cout
    ,cost_center_end_date as date_fin_centre_cout
    ,establishment_start_date as date_deb_etablissement
    ,establishment_end_date as date_fin_etablissement
    ,company_start_date as date_deb_societe
    ,company_end_date as date_fin_societe
    ,organization_start_date as date_deb_org
    ,organization_end_date as date_fin_org    
    ,org_in_out_dates_code
    
  FROM vw_employee
"""
spark.sql(queryContractEmployee).filter(col("rnum")==="1").distinct.withColumn("date_fin_centre_cout_calc",date_sub(lead($"date_deb_centre_cout",1) over by_date,1))
.createOrReplaceTempView("vw_ContractEmployee")



// COMMAND ----------

// DBTITLE 1,Final Dataset - Org Change In
val query_orgIn = """
select

       int(null) as is_entry
      ,int(null) as is_entry_cdi
      ,int(null) as is_contract_start
      ,int(null) as is_change_contract
      ,int(null) as is_change_stagiaire_cdd
      ,int(null) as is_change_stagiaire_cdi
      ,int(null) as is_change_alternant_cdd
      ,int(null) as is_change_alternant_cdi
      ,int(null) as is_change_cdd_cdi
      ,int(null) as is_change_ecole_cdd_cdi
      ,int(null) as is_leave
      ,int(null) as is_leave_cdi
      ,int(null) as is_contract_end
      ,ifnull(ct.contract_type_id,-1) as contract_type_id
      ,ifnull(old_ct.contract_type_id,-1) as old_contract_type_id   


      ,int(null) as is_change_job_title
      ,int(null) as is_change_job_profile                        
      ,date(null) as new_position_start_date
      ,ifnull(job.job_architecture_id,-1) as job_architecture_id
      ,ifnull(old_job.job_architecture_id,-1) as old_job_architecture_id
      ,-1 as new_job_architecture_id

      ,e.is_change_ope_cc as is_change_cc
      ,e.is_change_departement
      ,e.is_change_direction
      ,e.is_change_division_detailed
      ,e.is_change_division_consolidated
      ,int(null) as is_change_business_line_reference
      ,e.is_mobility_extra
      ,e.is_mobility_intra 
      ,int(null) as is_mobility_out

      ,e.new_date_deb_centre_cout as date_change_centre_cout
      ,e.new_date_deb_centre_cout as date_change_departement
      ,e.new_date_deb_org as date_change_direction
      ,e.new_date_deb_org as date_change_division_detailed
      ,e.new_date_deb_org as date_change_division_consolidated

       ,ifnull(e.new_operational_organization_id,-1) as operational_organization_id
      ,ifnull(e.old_operational_organization_id,-1) as old_operational_organization_id
      ,-1 as new_operational_organization_id

      ,e.is_change_etablissement
      ,e.is_change_company
      ,e.new_date_deb_etablissement as date_change_etablissement
      ,e.new_date_deb_societe as date_change_societe
      ,ifnull(e.new_legal_organization_id,-1) as legal_organization_id
      ,ifnull(e.old_legal_organization_id,-1) as old_legal_organization_id
      ,-1 as new_legal_organization_id

      ,e.effective_job_change_date as effective_job_change_date
      ,e.effective_organization_change_date as effective_organization_change_date
      ,e.effective_suporg_change_date as effective_suporg_change_date
      

      ,d.employee_id                   
      ,ifnull(wr.worker_rate_id,-1) as worker_rate_id
      ,case when lower(ct.contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else ifnull(csp.csp_id,-1) end as csp_id
      ,ifnull(old_csp.csp_id,-1) as old_csp_id
      ,-1 new_csp_id
      ,ifnull(nat.nationality_id,-1) as nationality_id
      ,ifnull(ag.range_age_id,-1) as range_age_id
      ,ifnull(sec.seniority_company_id,-1) as seniority_company_id
      ,ifnull(sep.seniority_position_id,-1) as seniority_position_id
      ,ifnull(loc.location_id,-1) as location_id                         
      ,ifnull(man.manager_id,-1) as manager_id
      ,ifnull(so.supervisory_organization_id,-1) as supervisory_organization_id
      ,-1 as mobility_in_id
      ,-1 as mobility_out_id
      ,coalesce(id.info_dates_id, -1) as info_dates_id
      ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
      ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
      ,e.date_id as date_id
      ,current_timestamp() as recordcreationdate
      ,'""" + runid + """' as runid
      
    

  from vw_employee_org_change e
  
  inner join vw_d_date dt on e.date_id = dt.date_id

  inner join vw_d_contract_type ct on e.contract_code = ct.contract_code and ct.collective_agreement_code = e.collective_agreement_code and ct.current_version = 1
  
  inner join vw_d_contract_type old_ct on e.old_contract_code = old_ct.contract_code and e.old_collective_agreement_code = old_ct.collective_agreement_code and old_ct.current_version = 1
  
  left join vw_d_worker_rate wr on e.worker_rate_code = wr.worker_rate_code and wr.current_version = 1
  left join vw_d_info_dates id on id.info_dates_code = e.info_dates_code and id.current_version = 1
  
  left join vw_d_in_out_dates iod
  on iod.in_out_dates_code = e.in_out_dates_code
  and iod.org_in_out_dates_code = e.org_in_out_dates_code
  and iod.current_version = 1 

  inner join vw_d_employee d on e.employee_code = d.employee_code and d.current_version = 1 
  left join vw_d_csp csp on e.csp_code = csp.csp_code and csp.current_version = 1
  left join vw_d_csp old_csp on e.old_csp_code = old_csp.csp_code and old_csp.current_version = 1
  left join vw_d_nationality nat on e.nationality_code = nat.nationality_code and nat.current_version = 1
  left join vw_d_job_architecture job on e.job_code = job.job_architecture_code and job.current_version = 1
  left join vw_d_job_architecture old_job on e.old_job_code = old_job.job_architecture_code and old_job.current_version = 1
  left join vw_d_location loc on e.location_code = loc.location_code and loc.current_version = 1
  left join vw_d_manager man on e.manager_code = man.manager_code and man.current_version = 1
  left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code and so.current_version = 1

  left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date(e.date_id,'yyyyMMdd'),e.birth_date)/12) end)
  and ag.current_version = 1

  left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(e.continous_service_date) then null else datediff(to_date(e.date_id,'yyyyMMdd'),e.continous_service_date) end)
  and sec.current_version = 1  

  left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(e.position_start_date) then null else datediff(to_date(e.date_id,'yyyyMMdd'),e.position_start_date) end)
  and sep.current_version = 1
  
  left join vw_d_hierarchy_pb hi_pb on e.new_cost_center_code = hi_pb.cost_center_code

"""
val df_orgIn_results = spark.sql(query_orgIn).filter($"date_id" <= date_id and $"date_id" >= start_date_id)

// COMMAND ----------

// DBTITLE 1,Final Dataset - Org Change Out
val query_orgOut = """
select

      int(null) as is_entry
      ,int(null) as is_entry_cdi
      ,int(null) as is_contract_start
      ,int(null) as is_change_contract
      ,int(null) as is_change_stagiaire_cdd
      ,int(null) as is_change_stagiaire_cdi
      ,int(null) as is_change_alternant_cdd
      ,int(null) as is_change_alternant_cdi
      ,int(null) as is_change_cdd_cdi
      ,int(null) as is_change_ecole_cdd_cdi
      ,int(null) as is_leave
      ,int(null) as is_leave_cdi
      ,int(null) as is_contract_end
      ,ifnull(ct.contract_type_id,-1) as contract_type_id
      ,-1 as old_contract_type_id   


      ,int(null) as is_change_job_title
      ,int(null) as is_change_job_profile                        
      ,date(null) as new_position_start_date
      ,ifnull(job.job_architecture_id,-1) as job_architecture_id
      ,-1 as old_job_architecture_id
      ,ifnull(new_job.job_architecture_id,-1) as new_job_architecture_id

      ,int(null) as is_change_cc
      ,e.is_change_departement
      ,e.is_change_direction
      ,e.is_change_division_detailed
      ,e.is_change_division_consolidated
      ,int(null) is_change_business_line_reference
      ,e.is_mobility_extra
      ,e.is_mobility_intra 
      ,e.is_change_ope_cc as is_mobility_out

      ,e.old_date_deb_centre_cout as date_change_centre_cout
      ,e.old_date_deb_centre_cout as date_change_departement
      ,e.old_date_deb_org as date_change_direction
      ,e.old_date_deb_org as date_change_division_detailed
      ,e.old_date_deb_org as date_change_division_consolidated

       ,ifnull(e.old_operational_organization_id,-1) as operational_organization_id
      ,-1 as old_operational_organization_id
      ,ifnull(e.new_operational_organization_id,-1) as new_operational_organization_id

      ,e.is_change_etablissement
      ,e.is_change_company
      ,e.old_date_deb_etablissement as date_change_etablissement
      ,e.old_date_deb_societe as date_change_societe
      ,ifnull(e.old_legal_organization_id,-1) as legal_organization_id
      ,-1 as old_legal_organization_id
      ,ifnull(e.new_legal_organization_id,-1) as new_legal_organization_id

      ,e.old_effective_job_change_date
      ,e.old_effective_organization_change_date
      ,e.old_effective_suporg_change_date

      ,d.employee_id                   
      ,ifnull(wr.worker_rate_id,-1) as worker_rate_id
      
      ,ifnull(csp.csp_id,-1) as csp_id
      ,-1 as old_csp_id
      ,ifnull(new_csp.csp_id,-1) as new_csp_id
      
      ,ifnull(nat.nationality_id,-1) as nationality_id
      ,ifnull(ag.range_age_id,-1) as range_age_id
      ,ifnull(sec.seniority_company_id,-1) as seniority_company_id
      ,ifnull(sep.seniority_position_id,-1) as seniority_position_id
      ,ifnull(loc.location_id,-1) as location_id                         
      ,ifnull(man.manager_id,-1) as manager_id
      ,ifnull(so.supervisory_organization_id,-1) as supervisory_organization_id
      ,-1 as mobility_in_id
      ,-1 as mobility_out_id
      ,coalesce(id.info_dates_id, -1) as info_dates_id
      ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
      ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
      ,e.date_id as date_id
      ,current_timestamp() as recordcreationdate
      ,'""" + runid + """' as runid

  from vw_employee_org_change e
  
  inner join vw_d_date dt on e.date_id = dt.date_id

  inner join vw_contractstart c
  on c.employee_code = e.employee_code
  and ifnull(e.old_date_deb_centre_cout,to_date(e.date_id,'yyyyMMdd')) between c.contract_start_date and ifnull(c.contract_end_date,now())

  inner join vw_d_contract_type ct on e.contract_code = ct.contract_code and ct.collective_agreement_code = e.collective_agreement_code and ct.current_version = 1
  
  left join vw_d_worker_rate wr on c.worker_rate_code = wr.worker_rate_code and wr.current_version = 1
  left join vw_d_info_dates id on id.info_dates_code = c.info_dates_code and id.current_version = 1

 left join vw_d_in_out_dates iod
  on iod.in_out_dates_code = e.in_out_dates_code
  and iod.org_in_out_dates_code = e.org_in_out_dates_code
  and iod.current_version = 1 
  
  inner join vw_d_employee d on e.employee_code = d.employee_code and d.current_version = 1 
  
  left join vw_d_csp csp on e.old_csp_code = csp.csp_code and csp.current_version = 1
  left join vw_d_csp new_csp on e.csp_code = new_csp.csp_code and new_csp.current_version = 1
  
  left join vw_d_nationality nat on e.old_nationality_code = nat.nationality_code and nat.current_version = 1
  
  left join vw_d_job_architecture job on e.old_job_code = job.job_architecture_code and job.current_version = 1
  left join vw_d_job_architecture new_job on e.job_code = new_job.job_architecture_code and new_job.current_version = 1
  
  left join vw_d_location loc on e.old_location_code = loc.location_code and loc.current_version = 1
  left join vw_d_manager man on e.old_manager_code = man.manager_code and man.current_version = 1
  left join vw_d_supervisory_organization so on e.old_supervisory_organization_code = so.supervisory_organization_code and so.current_version = 1

  left join vw_d_range_age ag on ag.range_age = (case when isnull(e.old_birth_date) then null else floor(months_between(to_date(e.date_id,'yyyyMMdd'),e.old_birth_date)/12) end)
  and ag.current_version = 1

  left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(e.old_continous_service_date) then null else datediff(to_date(e.date_id,'yyyyMMdd'),e.old_continous_service_date) end)
  and sec.current_version = 1  

  left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(e.old_position_start_date) then null else datediff(to_date(e.date_id,'yyyyMMdd'),e.old_position_start_date) end)
  and sep.current_version = 1
  
  left join vw_d_hierarchy_pb hi_pb on e.new_cost_center_code = hi_pb.cost_center_code

"""
val df_orgOut_results = spark.sql(query_orgOut).filter($"date_id" <= date_id and $"date_id" >= start_date_id)

// COMMAND ----------

// DBTITLE 1,Final Dataset - Job Change
val query_job = """
  select

        int(null) as is_entry
        ,int(null) as is_entry_cdi
        ,int(null) as is_contract_start
        ,int(null) as is_change_contract
        ,int(null) as is_change_stagiaire_cdd
        ,int(null) as is_change_stagiaire_cdi
        ,int(null) as is_change_alternant_cdd
        ,int(null) as is_change_alternant_cdi
        ,int(null) as is_change_cdd_cdi
        ,int(null) as is_change_ecole_cdd_cdi
        ,int(null) as is_leave
        ,int(null) as is_leave_cdi
        ,int(null) as is_contract_end
        ,ifnull(ct.contract_type_id,-1) as contract_type_id
        ,-1 as old_contract_type_id   

        ,e.is_change_job_title
        ,e.is_change_job_profile                        
        ,e.new_position_start_date
        ,coalesce(e.new_job_architecture_id,job.job_architecture_id,-1) as job_architecture_id
        ,ifnull(e.old_job_architecture_id,-1) as old_job_architecture_id
        ,-1 as new_job_architecture_id

        ,int(null) as is_change_cc
        ,int(null) as is_change_departement
        ,int(null) as is_change_direction
        ,int(null) as is_change_division_detailed
        ,int(null) as is_change_division_consolidated
        ,int(null) as is_change_business_line_reference
        ,int(null) as is_mobility_extra
        ,int(null) as is_mobility_intra 
        ,int(null) as is_mobility_out

        ,e.date_deb_centre_cout as date_change_centre_cout
        ,e.date_deb_centre_cout as date_change_departement
        ,e.date_deb_org as date_change_direction
        ,e.date_deb_org as date_change_division_detailed
        ,e.date_deb_org as date_change_division_consolidated

        ,ifnull(ope.operational_organization_id,-1) as operational_organization_id
        ,-1 as old_operational_organization_id
        ,-1 as new_operational_organization_id

        ,int(null) as is_change_etablissement
        ,int(null) as is_change_company
        ,date(null) as date_change_etablissement
        ,date(null) as date_change_societe
        ,ifnull(ole.legal_organization_id,-1) as legal_organization_id
        ,-1 as old_legal_organization_id
        ,-1 as new_legal_organization_id

        ,e.effective_job_change_date
        ,e.effective_organization_change_date
        ,e.effective_suporg_change_date

        ,d.employee_id                   
        ,ifnull(wr.worker_rate_id,-1) as worker_rate_id
        ,ifnull(csp.csp_id,-1) as csp_id
        ,ifnull(old_csp.csp_id,-1) as old_csp_id
        ,-1 new_csp_id
        ,ifnull(nat.nationality_id,-1) as nationality_id
        ,ifnull(ag.range_age_id,-1) as range_age_id
        ,ifnull(sec.seniority_company_id,-1) as seniority_company_id
        ,ifnull(sep.seniority_position_id,-1) as seniority_position_id
        ,ifnull(loc.location_id,-1) as location_id                         
        ,ifnull(man.manager_id,-1) as manager_id
        ,ifnull(so.supervisory_organization_id,-1) as supervisory_organization_id
        ,-1 as mobility_in_id
        ,-1 as mobility_out_id
        ,coalesce(id.info_dates_id, -1) as info_dates_id
        ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
        ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
        ,e.date_id as date_id
        ,current_timestamp() as recordcreationdate
        ,'""" + runid + """' as runid

  from vw_employee_job_change e
  
  inner join vw_d_date dt on e.date_id = dt.date_id

  inner join vw_d_contract_type ct on e.contract_code = ct.contract_code and ct.current_version = 1
  
  left join vw_d_worker_rate wr on e.worker_rate_code = wr.worker_rate_code and wr.current_version = 1
  left join vw_d_info_dates id on id.info_dates_code = e.info_dates_code and id.current_version = 1

  left join vw_d_in_out_dates iod
  on iod.in_out_dates_code = e.in_out_dates_code
  and iod.org_in_out_dates_code = e.org_in_out_dates_code
  and iod.current_version = 1 

  inner join vw_d_employee d on e.employee_code = d.employee_code and d.current_version = 1 
  left join vw_d_csp csp on e.csp_code = csp.csp_code and csp.current_version = 1
  left join vw_d_csp old_csp on e.old_csp_code = old_csp.csp_code and old_csp.current_version = 1
  left join vw_d_nationality nat on e.nationality_code = nat.nationality_code and nat.current_version = 1
  left join vw_d_job_architecture job on e.job_code = job.job_architecture_code and job.current_version = 1
  left join vw_d_location loc on e.location_code = loc.location_code and loc.current_version = 1
  left join vw_d_manager man on e.manager_code = man.manager_code and man.current_version = 1
  left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code and so.current_version = 1

  left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date(e.date_id,'yyyyMMdd'),e.birth_date)/12) end)
  and ag.current_version = 1

  left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(e.continous_service_date) then null else datediff(to_date(e.date_id,'yyyyMMdd'),e.continous_service_date) end)
  and sec.current_version = 1  

  left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(e.position_start_date) then null else datediff(to_date(e.date_id,'yyyyMMdd'),e.position_start_date) end)
  and sep.current_version = 1

  left join vw_d_operational_organization ope on e.operational_organization_code = ope.operational_organization_code and ope.current_version = 1

  left join vw_d_legal_organization ole on e.legal_organization_code = ole.legal_organization_code and ole.current_version = 1  
  left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code
"""
val df_job_results = spark.sql(query_job).filter($"date_id" <= date_id and $"date_id" >= start_date_id)

// COMMAND ----------

// DBTITLE 1,Final Dataset - Entries Change
val query_entries = """

  select

         c.is_entry
        ,c.is_entry_cdi
        ,c.is_contract_start
        ,c.is_change_contract
        ,c.is_change_stagiaire_cdd
        ,c.is_change_stagiaire_cdi
        ,c.is_change_alternant_cdd
        ,c.is_change_alternant_cdi
        ,c.is_change_cdd_cdi
        ,c.is_change_ecole_cdd_cdi
        ,int(null) as is_leave
        ,int(null) as is_leave_cdi
        ,int(null) as is_contract_end
        ,ifnull(c.new_contract_type_id,-1) as contract_type_id
        ,ifnull(c.old_contract_type_id ,-1) as   old_contract_type_id

        ,int(null) as is_change_job_title
        ,int(null) as is_change_job_profile                        
        ,date(null) as new_position_start_date
        ,ifnull(job.job_architecture_id,-1) as job_architecture_id
        ,-1 as old_job_architecture_id
        ,-1 as new_job_architecture_id

        ,int(null) as is_change_cc
        ,int(null) as is_change_departement
        ,int(null) as is_change_direction
        ,int(null) as is_change_division_detailed
        ,int(null) as is_change_division_consolidated
        ,int(null) as is_change_business_line_reference
        ,int(null) as is_mobility_extra
        ,int(null) as is_mobility_intra 
        ,int(null) as is_mobility_out

        ,e.new_cost_center_start_date as date_change_centre_cout
        ,e.new_cost_center_start_date as date_change_departement
        ,e.organization_start_date as date_change_direction
        ,e.organization_start_date as date_change_division_detailed
        ,e.organization_start_date as date_change_division_consolidated

        ,ifnull(ope.operational_organization_id,-1) as operational_organization_id
        ,-1 as old_operational_organization_id
        ,-1 as new_operational_organization_id

        ,int(null) as is_change_etablissement
        ,int(null) as is_change_company
        ,date(null) as date_change_etablissement
        ,date(null) as date_change_societe
        ,ifnull(ole.legal_organization_id,-1) as legal_organization_id
        ,-1 as old_legal_organization_id
        ,-1 as new_legal_organization_id

        ,c.effective_job_change_date
        ,e.effective_organization_change_date
        ,e.effective_suporg_change_date

        ,d.employee_id                   
        ,ifnull(wr.worker_rate_id,-1) as worker_rate_id
        ,case when lower(c.new_contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else ifnull(csp.csp_id,-1) end as csp_id
        ,case when lower(c.old_contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else ifnull(old_csp.csp_id,-1) end as old_csp_id
        ,-1 new_csp_id
        ,ifnull(nat.nationality_id,-1) as nationality_id
        ,ifnull(ag.range_age_id,-1) as range_age_id
        ,ifnull(sec.seniority_company_id,-1) as seniority_company_id
        ,ifnull(sep.seniority_position_id,-1) as seniority_position_id
        ,ifnull(loc.location_id,-1) as location_id                         
        ,ifnull(man.manager_id,-1) as manager_id
        ,ifnull(so.supervisory_organization_id,-1) as supervisory_organization_id
        ,coalesce(mob_in.mobility_in_id, -1) as mobility_in_id
        ,-1 as mobility_out_id
        ,coalesce(id.info_dates_id, -1) as info_dates_id
        ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
        ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
        ,c.date_id as date_id
        ,current_timestamp() as recordcreationdate
        ,'""" + runid + """' as runid

  from vw_contract_change c
  
  inner join vw_d_date dt on c.date_id = dt.date_id

/*
  inner join vw_ContractEmployee e
  on e.employee_code = c.employee_code
  and (c.new_contract_start_date between e.date_deb_centre_cout and ifnull(e.date_fin_centre_cout_calc,now()))
*/
  inner join vw_employee_contract_retro e
  on e.employee_code = c.employee_code
  and (c.new_contract_start_date between e.new_cost_center_start_date and ifnull(e.new_cost_center_end_date,now()))

  left join vw_d_worker_rate wr on c.worker_rate_code = wr.worker_rate_code and wr.current_version = 1
  left join vw_d_info_dates id on id.info_dates_code = c.info_dates_code and id.current_version = 1
   
  left join vw_d_in_out_dates iod
  on iod.in_out_dates_code = c.in_out_dates_code
  and iod.org_in_out_dates_code = e.org_in_out_dates_code
  and iod.current_version = 1 
  
  left join vw_d_mobility_in mob_in on mob_in.mobility_in_code = c.mobility_in_code and mob_in.current_version = 1

  inner join vw_d_employee d on e.employee_code = d.employee_code and d.current_version = 1 
  left join vw_d_csp csp on c.csp_code = csp.csp_code and csp.current_version = 1
  left join vw_d_csp old_csp on c.old_csp_code = old_csp.csp_code and old_csp.current_version = 1
  left join vw_d_nationality nat on e.nationality_code = nat.nationality_code and nat.current_version = 1
  left join vw_d_job_architecture job on c.job_code = job.job_architecture_code and job.current_version = 1
  left join vw_d_location loc on e.location_code = loc.location_code and loc.current_version = 1
  left join vw_d_manager man on e.manager_code = man.manager_code and man.current_version = 1
  left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code and so.current_version = 1

  left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date(c.date_id,'yyyyMMdd'),e.birth_date)/12) end)
  and ag.current_version = 1

  left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(c.continous_service_date) then null else datediff(to_date(c.date_id,'yyyyMMdd'),c.continous_service_date) end)
  and sec.current_version = 1  

  left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(c.position_start_date) then null else datediff(to_date(c.date_id,'yyyyMMdd'),c.position_start_date) end)
  and sep.current_version = 1

  left join vw_d_operational_organization ope on e.operational_organization_code = ope.operational_organization_code and to_date(c.date_id,'yyyyMMdd') between e.new_cost_center_start_date and e.new_cost_center_end_date and ope.current_version = 1

  left join vw_d_legal_organization ole on e.legal_organization_code = ole.legal_organization_code and to_date(c.date_id,'yyyyMMdd') between e.new_cost_center_start_date and e.new_cost_center_end_date and ole.current_version = 1
  left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code
"""
val df_entries_results = spark.sql(query_entries).filter($"date_id" <= date_id and $"date_id" >= start_date_id)

// COMMAND ----------

// DBTITLE 1,Final Dataset - Leaves Change
val query_leaves = """
  
  select

         int(null) as is_entry
        ,int(null) as is_entry_cdi
        ,int(null) as is_contract_start
        ,int(null) as is_change_contract
        ,int(null) as is_change_stagiaire_cdd
        ,int(null) as is_change_stagiaire_cdi
        ,int(null) as is_change_alternant_cdd
        ,int(null) as is_change_alternant_cdi
        ,int(null) as is_change_cdd_cdi
        ,int(null) as is_change_ecole_cdd_cdi
        ,c.is_leave
        ,c.is_leave_cdi
        ,int(null) as is_contract_end
        ,ifnull(c.contract_type_id,-1) as contract_type_id
        ,-1 as old_contract_type_id  

        ,int(null) as is_change_job_title
        ,int(null) as is_change_job_profile                        
        ,date(null) as new_position_start_date
        ,ifnull(job.job_architecture_id,-1) as job_architecture_id
        ,-1 as old_job_architecture_id
        ,-1 as new_job_architecture_id

        ,int(null) as is_change_cc
        ,int(null) as is_change_departement
        ,int(null) as is_change_direction
        ,int(null) as is_change_division_detailed
        ,int(null) as is_change_division_consolidated
        ,int(null) as is_change_business_line_reference
        ,int(null) as is_mobility_extra
        ,int(null) as is_mobility_intra 
        ,int(null) as is_mobility_out

        ,e.new_cost_center_start_date as date_change_centre_cout
        ,e.new_cost_center_start_date as date_change_departement
        ,e.organization_start_date as date_change_direction
        ,e.organization_start_date as date_change_division_detailed
        ,e.organization_start_date as date_change_division_consolidated

        ,ifnull(ope.operational_organization_id,-1) as operational_organization_id
        ,-1 as old_operational_organization_id
        ,-1 as new_operational_organization_id

        ,int(null) as is_change_etablissement
        ,int(null) as is_change_company
        ,date(null) as date_change_etablissement
        ,date(null) as date_change_societe
        ,ifnull(ole.legal_organization_id,-1) as legal_organization_id
        ,-1 as old_legal_organization_id
        ,-1 as new_legal_organization_id

        ,c.effective_job_change_date
        ,e.effective_organization_change_date
        ,e.effective_suporg_change_date

        ,d.employee_id                   
        ,ifnull(wr.worker_rate_id,-1) as worker_rate_id
        ,case when lower(c.contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else ifnull(csp.csp_id,-1) end as csp_id
        ,-1 as old_csp_id
        ,-1 new_csp_id
        ,ifnull(nat.nationality_id,-1) as nationality_id
        ,ifnull(ag.range_age_id,-1) as range_age_id
        ,ifnull(sec.seniority_company_id,-1) as seniority_company_id
        ,ifnull(sep.seniority_position_id,-1) as seniority_position_id
        ,ifnull(loc.location_id,-1) as location_id                         
        ,ifnull(man.manager_id,-1) as manager_id
        ,ifnull(so.supervisory_organization_id,-1) as supervisory_organization_id
        ,-1 as mobility_in_id
        ,coalesce(mob_out.mobility_out_id, -1) as mobility_out_id
        ,coalesce(id.info_dates_id, -1) as info_dates_id
        ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
        ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
        ,date_format(date_add(c.date_id,1),'yyyyMMdd') as date_id
        ,current_timestamp() as recordcreationdate
        ,'""" + runid + """' as runid

  from vw_leaves c
  
  inner join vw_d_date dt on date_format(date_add(c.date_id,1),'yyyyMMdd') = dt.date_id
/*
  inner join vw_ContractEmployee e
  on e.employee_code = c.employee_code
  and (c.contract_end_date between e.date_deb_centre_cout and ifnull(e.date_fin_centre_cout_calc,to_date('""" + date_id2 + """',"yyyyMMdd")))
*/ 
  inner join vw_employee_contract_retro e
  on e.employee_code = c.employee_code
  and (c.contract_end_date between e.new_cost_center_start_date and ifnull(e.new_cost_center_end_date,to_date('""" + date_id2 + """',"yyyyMMdd")))
 
  left join vw_d_worker_rate wr on c.worker_rate_code = wr.worker_rate_code and wr.current_version = 1
  left join vw_d_info_dates id on id.info_dates_code = c.info_dates_code and id.current_version = 1
 
  left join vw_d_in_out_dates iod
  on iod.in_out_dates_code = c.in_out_dates_code
  and iod.org_in_out_dates_code = e.org_in_out_dates_code
  and iod.current_version = 1
 
 
 left join vw_d_mobility_out mob_out on mob_out.mobility_out_code = c.mobility_out_code and mob_out.current_version = 1

  inner join vw_d_employee d on e.employee_code = d.employee_code and d.current_version = 1 
  left join vw_d_csp csp on c.csp_code = csp.csp_code and csp.current_version = 1
  left join vw_d_nationality nat on e.nationality_code = nat.nationality_code and nat.current_version = 1
  left join vw_d_job_architecture job on c.job_code = job.job_architecture_code and job.current_version = 1
  left join vw_d_location loc on e.location_code = loc.location_code and loc.current_version = 1
  left join vw_d_manager man on e.manager_code = man.manager_code and man.current_version = 1
  left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code and so.current_version = 1

  left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date(c.date_id,'yyyyMMdd'),e.birth_date)/12) end)
  and ag.current_version = 1

  left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(c.continous_service_date) then null else datediff(to_date(c.date_id,'yyyyMMdd'),c.continous_service_date) end)
  and sec.current_version = 1  

  left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(c.position_start_date) then null else datediff(to_date(c.date_id,'yyyyMMdd'),c.position_start_date) end)
  and sep.current_version = 1

  left join vw_d_operational_organization ope on e.operational_organization_code = ope.operational_organization_code and ope.current_version = 1

  left join vw_d_legal_organization ole on e.legal_organization_code = ole.legal_organization_code and ole.current_version = 1  
  left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code
"""
val df_leaves_results = spark.sql(query_leaves).filter($"date_id" <= date_id2 and $"date_id" >= start_date_id)

// COMMAND ----------

// DBTITLE 1,Final Dataset - Contract End Change
val query_contractEnd = """
  
  select

         int(null) as is_entry
        ,int(null) as is_entry_cdi
        ,int(null) as is_contract_start
        ,int(null) as is_change_contract
        ,int(null) as is_change_stagiaire_cdd
        ,int(null) as is_change_stagiaire_cdi
        ,int(null) as is_change_alternant_cdd
        ,int(null) as is_change_alternant_cdi
        ,int(null) as is_change_cdd_cdi
        ,int(null) as is_change_ecole_cdd_cdi
        ,int(null) as is_leave
        ,int(null) as is_leave_cdi
        ,c.is_contract_end
        ,ifnull(c.contract_type_id,-1) as contract_type_id
        ,-1 as old_contract_type_id  

        ,int(null) as is_change_job_title
        ,int(null) as is_change_job_profile                        
        ,date(null) as new_position_start_date
        ,ifnull(job.job_architecture_id,-1) as job_architecture_id
        ,-1 as old_job_architecture_id
        ,-1 as new_job_architecture_id

        ,int(null) as is_change_cc
        ,int(null) as is_change_departement
        ,int(null) as is_change_direction
        ,int(null) as is_change_division_detailed
        ,int(null) as is_change_division_consolidated
        ,int(null) as is_change_business_line_reference
        ,int(null) as is_mobility_extra
        ,int(null) as is_mobility_intra 
        ,int(null) as is_mobility_out

        ,e.new_cost_center_start_date as date_change_centre_cout
        ,e.new_cost_center_start_date as date_change_departement
        ,e.organization_start_date as date_change_direction
        ,e.organization_start_date as date_change_division_detailed
        ,e.organization_start_date as date_change_division_consolidated

        ,ifnull(ope.operational_organization_id,-1) as operational_organization_id
        ,-1 as old_operational_organization_id
        ,-1 as new_operational_organization_id

        ,int(null) as is_change_etablissement
        ,int(null) as is_change_company
        ,date(null) as date_change_etablissement
        ,date(null) as date_change_societe
        ,ifnull(ole.legal_organization_id,-1) as legal_organization_id
        ,-1 as old_legal_organization_id
        ,-1 as new_legal_organization_id

        ,c.effective_job_change_date
        ,e.effective_organization_change_date
        ,e.effective_suporg_change_date

        ,d.employee_id                   
        ,ifnull(wr.worker_rate_id,-1) as worker_rate_id
        ,case when lower(c.contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else ifnull(csp.csp_id,-1) end as csp_id
        ,-1 as old_csp_id
        ,-1 new_csp_id
        ,ifnull(nat.nationality_id,-1) as nationality_id
        ,ifnull(ag.range_age_id,-1) as range_age_id
        ,ifnull(sec.seniority_company_id,-1) as seniority_company_id
        ,ifnull(sep.seniority_position_id,-1) as seniority_position_id
        ,ifnull(loc.location_id,-1) as location_id                         
        ,ifnull(man.manager_id,-1) as manager_id
        ,ifnull(so.supervisory_organization_id,-1) as supervisory_organization_id
        ,-1 as mobility_in_id
        ,coalesce(mob_out.mobility_out_id, -1) as mobility_out_id
        ,coalesce(id.info_dates_id, -1) as info_dates_id
        ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
        ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
        ,date_format(c.date_id,'yyyyMMdd') as date_id
        ,current_timestamp() as recordcreationdate
        ,'""" + runid + """' as runid

  from vw_contract_end c
  
  inner join vw_d_date dt on date_format(c.date_id,'yyyyMMdd') = dt.date_id
/*
  inner join vw_ContractEmployee e
  on e.employee_code = c.employee_code
  and (c.contract_end_date between e.date_deb_centre_cout and ifnull(e.date_fin_centre_cout_calc,now()))
*/
  inner join vw_employee_contract_retro e
  on e.employee_code = c.employee_code
  and (c.contract_end_date between e.new_cost_center_start_date and ifnull(e.new_cost_center_end_date,now()))

  left join vw_d_worker_rate wr on c.worker_rate_code = wr.worker_rate_code and wr.current_version = 1
  left join vw_d_info_dates id on id.info_dates_code = c.info_dates_code and id.current_version = 1
  
  left join vw_d_in_out_dates iod
  on iod.in_out_dates_code = c.in_out_dates_code
  and iod.org_in_out_dates_code = e.org_in_out_dates_code
  and iod.current_version = 1
  
  left join vw_d_mobility_out mob_out on mob_out.mobility_out_code = c.mobility_out_code and mob_out.current_version = 1

  inner join vw_d_employee d on e.employee_code = d.employee_code and d.current_version = 1 
  left join vw_d_csp csp on c.csp_code = csp.csp_code and csp.current_version = 1
  left join vw_d_nationality nat on e.nationality_code = nat.nationality_code and nat.current_version = 1
  left join vw_d_job_architecture job on c.job_code = job.job_architecture_code and job.current_version = 1
  left join vw_d_location loc on e.location_code = loc.location_code and loc.current_version = 1
  left join vw_d_manager man on e.manager_code = man.manager_code and man.current_version = 1
  left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code and so.current_version = 1

  left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date(c.date_id,'yyyyMMdd'),e.birth_date)/12) end)
  and ag.current_version = 1

  left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(c.continous_service_date) then null else datediff(to_date(c.date_id,'yyyyMMdd'),c.continous_service_date) end)
  and sec.current_version = 1  

  left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(c.position_start_date) then null else datediff(to_date(c.date_id,'yyyyMMdd'),c.position_start_date) end)
  and sep.current_version = 1

  left join vw_d_operational_organization ope on e.operational_organization_code = ope.operational_organization_code and ope.current_version = 1

  left join vw_d_legal_organization ole on e.legal_organization_code = ole.legal_organization_code and ole.current_version = 1  
    left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code

"""
val df_contractend_results = spark.sql(query_contractEnd).filter($"date_id" <= date_id and $"date_id" >= start_date_id)

// COMMAND ----------

// DBTITLE 1,Final Dataset - Business Line Reference Change
val query_BL = """
  select

         int(null) as is_entry
        ,int(null) as is_entry_cdi
        ,int(null) as is_contract_start
        ,int(null) as is_change_contract
        ,int(null) as is_change_stagiaire_cdd
        ,int(null) as is_change_stagiaire_cdi
        ,int(null) as is_change_alternant_cdd
        ,int(null) as is_change_alternant_cdi
        ,int(null) as is_change_cdd_cdi
        ,int(null) as is_change_ecole_cdd_cdi
        ,int(null) as is_leave
        ,int(null) as is_leave_cdi
        ,int(null) as is_contract_end
        ,ifnull(ct.contract_type_id,-1) as contract_type_id
        ,-1 as old_contract_type_id   

        ,int(null) as is_change_job_title
        ,int(null) as is_change_job_profile                        
        ,date(null) as new_position_start_date
        ,coalesce(job.job_architecture_id,-1) as job_architecture_id
        ,-1 as old_job_architecture_id
        ,-1 as new_job_architecture_id

        ,int(null) as is_change_cc
        ,int(null) as is_change_departement
        ,int(null) as is_change_direction
        ,int(null) as is_change_division_detailed
        ,int(null) as is_change_division_consolidated
        ,is_change_business_line as is_change_business_line_reference
        ,int(null) as is_mobility_extra
        ,int(null) as is_mobility_intra 
        ,int(null) as is_mobility_out

        ,e.date_deb_centre_cout as date_change_centre_cout
        ,e.date_deb_centre_cout as date_change_departement
        ,e.date_deb_org as date_change_direction
        ,e.date_deb_org as date_change_division_detailed
        ,e.date_deb_org as date_change_division_consolidated

        ,ifnull(e.new_operational_organization_id,-1) as operational_organization_id
        ,ifnull(e.old_operational_organization_id,-1) as old_operational_organization_id
        ,-1 as new_operational_organization_id

        ,int(null) as is_change_etablissement
        ,int(null) as is_change_company
        ,date(null) as date_change_etablissement
        ,date(null) as date_change_societe
        ,ifnull(ole.legal_organization_id,-1) as legal_organization_id
        ,-1 as old_legal_organization_id
        ,-1 as new_legal_organization_id

        ,e.effective_job_change_date
        ,e.effective_organization_change_date
        ,e.effective_suporg_change_date

        ,d.employee_id                   
        ,ifnull(wr.worker_rate_id,-1) as worker_rate_id
        ,ifnull(csp.csp_id,-1) as csp_id
        ,-1 as old_csp_id
        ,-1 new_csp_id
        ,ifnull(nat.nationality_id,-1) as nationality_id
        ,ifnull(ag.range_age_id,-1) as range_age_id
        ,ifnull(sec.seniority_company_id,-1) as seniority_company_id
        ,ifnull(sep.seniority_position_id,-1) as seniority_position_id
        ,ifnull(loc.location_id,-1) as location_id                         
        ,ifnull(man.manager_id,-1) as manager_id
        ,ifnull(so.supervisory_organization_id,-1) as supervisory_organization_id
        ,-1 as mobility_in_id
        ,-1 as mobility_out_id
        ,coalesce(id.info_dates_id, -1) as info_dates_id
        ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
        ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
        ,e.date_id as date_id
        ,current_timestamp() as recordcreationdate
        ,'""" + runid + """' as runid

  from vw_employee_BL_change e
  
  inner join vw_d_date dt on e.date_id = dt.date_id

  inner join vw_d_contract_type ct on e.contract_code = ct.contract_code and ct.current_version = 1
  
  left join vw_d_worker_rate wr on e.worker_rate_code = wr.worker_rate_code and wr.current_version = 1
  left join vw_d_info_dates id on id.info_dates_code = e.info_dates_code and id.current_version = 1

  left join vw_d_in_out_dates iod
  on iod.in_out_dates_code = e.in_out_dates_code
  and iod.org_in_out_dates_code = e.org_in_out_dates_code
  and iod.current_version = 1 

  inner join vw_d_employee d on e.employee_code = d.employee_code and d.current_version = 1 
  left join vw_d_csp csp on e.csp_code = csp.csp_code and csp.current_version = 1
  left join vw_d_nationality nat on e.nationality_code = nat.nationality_code and nat.current_version = 1
  left join vw_d_job_architecture job on e.job_code = job.job_architecture_code and job.current_version = 1
  left join vw_d_location loc on e.location_code = loc.location_code and loc.current_version = 1
  left join vw_d_manager man on e.manager_code = man.manager_code and man.current_version = 1
  left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code and so.current_version = 1

  left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date(e.date_id,'yyyyMMdd'),e.birth_date)/12) end)
  and ag.current_version = 1

  left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(e.continous_service_date) then null else datediff(to_date(e.date_id,'yyyyMMdd'),e.continous_service_date) end)
  and sec.current_version = 1  

  left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(e.position_start_date) then null else datediff(to_date(e.date_id,'yyyyMMdd'),e.position_start_date) end)
  and sep.current_version = 1
  
  left join vw_d_legal_organization ole on e.legal_organization_code = ole.legal_organization_code and ole.current_version = 1 
  left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code
 
"""
val df_BL_results = spark.sql(query_BL).filter($"date_id" <= date_id and $"date_id" >= start_date_id)

// COMMAND ----------

// DBTITLE 1,Fact table preparation query - one line per movement type
val df_mobility_results = df_job_results
                          .union(df_leaves_results)
                          .union(df_contractend_results)
                          .union(df_entries_results)
                          .union(df_orgIn_results)
                          .union(df_orgOut_results)
                          .union(df_BL_results)
//df_mobility_results.cache()  //put the dataframe ont he cache


// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """delete from mobility.f_mobility where date_id >= '""" + start_date_id + """'"""
val res = stmt.execute(query_delete)

// COMMAND ----------

df_mobility_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","1000").jdbc(jdbcurl, "mobility.f_mobility", connectionproperties)

// COMMAND ----------

val read_records = df_employee_read.count().toInt //count the number of read records
val inserted_records = df_mobility_results.count().toInt //count the number of read records
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from Cache
df_employee_read.unpersist
df_mobility_results.unpersist

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)