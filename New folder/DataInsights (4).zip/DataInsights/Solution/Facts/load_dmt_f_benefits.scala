// Databricks notebook source
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val limit_date_histo = dbutils.widgets.get("limit_date_histo");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.databricks.optimizer.rangeJoin.binSize", "5")

// COMMAND ----------

// DBTITLE 1,Refresh Table contract
 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh Table employee
 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh Table absenteism
 if(spark.catalog.tableExists("hr.absenteism")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh Table absenteism consolidated
 if(spark.catalog.tableExists("hr.absenteism_consolidated")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism_consolidated")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Set Parameters
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd")).plusMonths(-1)
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_start_month = LocalDate.parse(date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + "01",  DateTimeFormatter.ofPattern("yyyyMMdd"))
val date_id = date_end_month.toString.replace("-","")//date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + "01"

val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))

val year_id = date_value.getYear()
val last_year_id = date_value.getYear()-1
val last_month = date_end_month.plusMonths(-1).getYear() + ("%02d".format(date_end_month.plusMonths(-1).getMonth.getValue()))
val last_month_id = date_end_month.plusMonths(-1).toString.replace("-","") //date_value.plusMonths(-1).getYear() + ("%02d".format(date_value.plusMonths(-1).getMonth.getValue())) + "01"
val first_month_id = date_value.getYear() + "01"
val last_month_previous_year = (date_value.getYear() -1) + "12"
val december_previous_year = (date_value.getYear() -1) + "1231"
val march_month_id = date_value.getYear() + "03"

val date_end_last_month = date_start_month.plusDays(-1)

val date_next_month = date_end_month.plusDays(1)
val month_next_id = date_next_month.getYear() + ("%02d".format(date_next_month.getMonth.getValue()))

val DATE_CHANGE_ABS_DAYS_PAT = "2021-07-02"

val NB_ABS_DAYS_MAT = 112
val NB_DAYS_DENOM_CAE_MAT = 28

val NB_ABS_DAYS_ADO = 70
val NB_ABS_DAYS_ADO_SUPP = 73
val NB_DAYS_DENOM_CAE_ADO = 98

val NB_DAYS_DENOM_CAE_PAT = 98
val NB_ABS_DAYS_PAT_BEFORE_072021 =  14
val NB_ABS_DAYS_PAT_AFTER_072021 =  28

val limit_date_value = LocalDate.parse(limit_date_histo, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val filter_file_current_month = if (date_end_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}
val filter_file_previous_month = if (date_end_last_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}


// COMMAND ----------

// MAGIC %md #### 1- Read Data

// COMMAND ----------

// DBTITLE 1,Read Dimensions
spark.read.jdbc(jdbcurl, "dbo.d_date", connectionproperties).filter(col("month_id") === lit(month_id)).createOrReplaceTempView("vw_d_date")
spark.read.jdbc(jdbcurl, "staff.d_employee", connectionproperties).select("employee_id", "employee_code", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_employee")
spark.read.jdbc(jdbcurl, "staff.d_contract_type", connectionproperties).select("contract_type_id", "contract_type_code","precarity","contract_type","contract_type_detailed","classification_collective_agreement","contract_nature","collective_agreement_code","contract_code").filter("current_version = 1").createOrReplaceTempView("vw_d_contract_type")
spark.read.jdbc(jdbcurl, "staff.d_worker_rate", connectionproperties).select("worker_rate_id", "worker_rate_code", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_worker_rate")
spark.read.jdbc(jdbcurl, "staff.d_csp", connectionproperties).select("csp_id", "csp_code", "cadre_non_cadre","professional_category_reference").filter("current_version = 1").createOrReplaceTempView("vw_d_csp")
spark.read.jdbc(jdbcurl, "staff.d_nationality", connectionproperties).select("nationality_id", "nationality_code").filter("current_version = 1").createOrReplaceTempView("vw_d_nationality")
spark.read.jdbc(jdbcurl, "staff.d_range_age", connectionproperties).select("range_age_id", "range_age").filter("current_version = 1").createOrReplaceTempView("vw_d_range_age")
spark.read.jdbc(jdbcurl, "staff.d_seniority_company", connectionproperties).select("seniority_company_id", "range_seniority_company_age").filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_company")
spark.read.jdbc(jdbcurl, "staff.d_hierarchy_pb", connectionproperties).select("hierarchy_pb_id", "cost_center_code").filter("current_version = 1").createOrReplaceTempView("vw_d_hierarchy_pb")

// COMMAND ----------

// DBTITLE 1,Read Dimensions
spark.read.jdbc(jdbcurl, "staff.d_seniority_position", connectionproperties).select("seniority_position_id", "range_seniority_position_age").filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_position")
spark.read.jdbc(jdbcurl, "staff.d_location", connectionproperties).select("location_id", "location_code").filter("current_version = 1").createOrReplaceTempView("vw_d_location")
spark.read.jdbc(jdbcurl, "staff.d_job_architecture", connectionproperties).select("job_architecture_id", "job_architecture_code","job_title_code","grade_code").filter("current_version = 1").createOrReplaceTempView("vw_d_job_architecture")
spark.read.jdbc(jdbcurl, "staff.d_manager", connectionproperties).select("manager_id", "manager_code").filter("current_version = 1").createOrReplaceTempView("vw_d_manager")
spark.read.jdbc(jdbcurl, "staff.d_supervisory_organization", connectionproperties).select("supervisory_organization_id", "supervisory_organization_code").filter("current_version = 1").createOrReplaceTempView("vw_d_supervisory_organization")
spark.read.jdbc(jdbcurl, "staff.d_contract_suspension", connectionproperties).select("contract_suspension_id", "contract_suspension_code").filter("current_version = 1").createOrReplaceTempView("vw_d_contract_suspension")
spark.read.jdbc(jdbcurl, "staff.d_legal_organization", connectionproperties).select("legal_organization_id", "legal_organization_code", "company", "libelle_etablissement","hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_legal_organization")
spark.read.jdbc(jdbcurl, "staff.d_operational_organization", connectionproperties).select("operational_organization_id", "operational_organization_code", "division_consolidated","top_level","libelle_departement", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_operational_organization")
spark.read.jdbc(jdbcurl, "mobility.d_mobility_in", connectionproperties).select("mobility_in_id", "mobility_in_code").filter("current_version = 1").createOrReplaceTempView("vw_d_mobility_in")
spark.read.jdbc(jdbcurl, "mobility.d_mobility_out", connectionproperties).select("mobility_out_id", "mobility_out_code").filter("current_version = 1").createOrReplaceTempView("vw_d_mobility_out")
spark.read.jdbc(jdbcurl, "staff.d_info_dates", connectionproperties).select("info_dates_id", "info_dates_code", "position_start_date", "hire_date", "contract_start_date", "contract_end_date","contract_dates_code","company_dates_code").filter("current_version = 1").createOrReplaceTempView("vw_d_info_dates")
spark.read.jdbc(jdbcurl, "mobility.d_in_out_dates", connectionproperties).select("in_out_dates_id", "in_out_dates_code","org_in_out_dates_code").filter("current_version = 1").createOrReplaceTempView("vw_d_in_out_dates")
spark.read.jdbc(jdbcurl, "pay.d_homeoffice", connectionproperties).select("homeoffice_id", "code").filter("current_version = 1").createOrReplaceTempView("vw_d_homeoffice")

spark.read.jdbc(jdbcurl, "pay.d_payroll", connectionproperties).select("payroll_id", "payroll_code", "libelle_rubrique_paie_niv1", "libelle_rubrique_paie_niv2", "libelle_rubrique_paie_niv4", "libelle_rubrique_paie_niv3", "flag_montant_masse_salariale_brute", "flag_montant_aw4", "flag_montant_rem_bs","flag_montant_aw6","flag_montant_rem_nao","flag_montant_rem_reelle","flag_montant_rem_benchmark", "code_rubrique_paie").filter("current_version = 1").createOrReplaceTempView("vw_d_payroll")

// COMMAND ----------

// DBTITLE 1,Get Vacataire CSP Id
val vacataire_csp_id = spark.sql("""select cast(sum(csp_id) as int) as vacataire_csp_id from vw_d_csp where lower(professional_category_reference) = 'autre statut'""").head().getInt(0)

// COMMAND ----------

val byemployee = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_organization_change_date".desc,$"effective_organization_hierarchy_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_employee_read = spark.table("hr.employee").filter("('" + date_end_month.toString + "' >= record_start_date or '" + date_end_month.toString + "' >= effective_organization_hierarchy_change_date) and '" + date_end_month.toString + "' <= coalesce(record_end_date, '2999-12-31')")
                                                 .withColumn("rank",rank() over byemployee)
                                                 .filter(col("rank")==="1")                                          
                                                 .filter("company_id <> '0082'")
                                                 .distinct
df_employee_read.createOrReplaceTempView("vw_employee")
df_employee_read.cache()  //put the dataframe on the cache

val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_contract_read = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                 .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")                                                    
                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .withColumn("rank",rank() over bycontract)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("seniority_date_max",when($"contract_end_date" === "2999-12-31" or $"contract_end_date".isNull or $"contract_end_date" > lit(date_end_month), lit(date_end_month)).otherwise($"contract_end_date"))
                                                .withColumn("is_contract_month", when(date_format($"contract_start_date","yyyyMM") <= month_id  and 
                                                            date_format(coalesce($"contract_end_date", lit("2999-12-31")),"yyyyMM") >= month_id,1).otherwise(null))
                                                .filter(col("rank")==="1")
                                                .filter(col("is_contract_month")===1)
                                                .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                .distinct
df_contract_read.createOrReplaceTempView("vw_contract")

val byabs = Window.partitionBy("employee_hra", "dateval", "code", "duration_days", "duration_hours").orderBy($"date_raw_load_file".desc, $"version".desc, $"record_creation_date",$"record_creation_date".desc)
val df_absenteism_read = spark.table("hr.absenteism").filter("current_record = true  and period_abs_month = '" + month_id + "'")
                                                     .withColumn("employee_hra_old",$"employee_hra")
                                                     .withColumn("employee_hra", substring_index($"employee_hra", "_", 1))
                                                     .withColumn("rank",rank() over byabs)
                                                     .filter(col("rank")==="1")
                                                     .distinct
df_absenteism_read.createOrReplaceTempView("vw_absenteism")

val byabs_conso = Window.partitionBy("employee_hra","code","dateval_start","dateval_end","dateval_end").orderBy($"date_raw_load_file".desc,$"version".desc)
val window = Window.partitionBy("employee_hra").orderBy($"dateval_start".asc)
val df_absenteism_consolidated_read = spark.table("hr.absenteism_consolidated").withColumn("employee_hra_old",$"employee_hra")
                                                                               .withColumn("employee_hra", substring_index($"employee_hra", "_", 1))
                                                                               .withColumn("rank",rank() over byabs_conso)
                                                                               .filter(col("rank")==="1")
                                                                               .withColumn("code_before", lag($"code",1,null).over(window))
                                                                               .withColumn("code_after", lead($"code",1,null).over(window))
                                                                               .distinct
df_absenteism_consolidated_read.createOrReplaceTempView("vw_absenteism_consolidated")

// COMMAND ----------

val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract = Window.partitionBy("employee_id","france_payroll_id").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)

val df_contract_read_month = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                       .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """' """
                                                        ) 
                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("month_contract_start_date",when($"contract_start_date" < date_start_month,date_start_month).otherwise($"contract_start_date"))
                                                .withColumn("month_contract_end_date",when($"contract_end_date" > date_end_month,date_end_month).when($"contract_end_date".isNull,date_end_month).otherwise($"contract_end_date"))
                                                .withColumn("contract_days",datediff($"month_contract_end_date",$"month_contract_start_date")+1)
                                                .filter(col("rank_month")==="1")
                                                .filter("""date_format(contract_start_date,'yyyyMM') = '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                            (date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                        )
                                                
                                                .withColumn("rank",rank() over bycontract)
                                                .withColumn("next_contract_start_date",lag($"contract_start_date", 1, null).over(bycontract) )
                                                .withColumn("next_contract_end_date",lag($"contract_end_date", 1, null).over(bycontract) )
                                                .distinct
df_contract_read_month.createOrReplaceTempView("vw_contract_month")


// COMMAND ----------

val byJobChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date_valid".desc)
val byJobChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_compensation_change_date_valid".desc)
val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date","effective_job_change_date","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_effective_change_valid = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")                                                
                                                .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                .withColumn("effective_job_change_date_valid", when($"effective_job_change_date" > lit(date_end_month),null).otherwise($"effective_job_change_date"))
                                                .withColumn("effective_job_change_date_valid_last", first($"effective_job_change_date").over(byJobChangeDateLast))
                                                .withColumn("effective_job_change_date", when($"effective_job_change_date_valid".isNotNull,$"effective_job_change_date_valid")
                                                                                        .when($"effective_job_change_date_valid_last".isNull, $"contract_start_date")
                                                                                        .otherwise($"effective_job_change_date_valid_last"))     
                                                .withColumn("effective_job_change_date_max", first($"effective_job_change_date").over(byJobChangeDateLastContract))    

                                                .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                .withColumn("effective_compensation_change_date_valid", when($"effective_compensation_change_date" > lit(date_end_month),null).otherwise($"effective_compensation_change_date"))
                                                .withColumn("effective_compensation_change_date_valid_last", first($"effective_compensation_change_date").over(byCompensationChangeDateLast))
                                                .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date_valid".isNotNull,$"effective_compensation_change_date_valid")
                                                                                                 .when($"effective_compensation_change_date_valid_last".isNull, $"contract_start_date")
                                                                                                 .otherwise($"effective_compensation_change_date_valid_last"))         
                                                .withColumn("effective_compensation_change_date_max",first($"effective_compensation_change_date").over(byCompensationChangeDateLastContract))   


                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .filter(col("rank_month")==="1")  
                                                .filter("""date_format(contract_start_date,'yyyyMM') = '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                            (date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                        )
                                               .select("employee_code",
                                                       "employee_id",
                                                       "france_payroll_id",
                                                       "contract_start_date",
                                                       "contract_end_date",
                                                       "contract_type",
                                                       "contract_type_label",
                                                       "effective_job_change_date",
                                                       "effective_compensation_change_date",
                                                       "effective_job_change_date_max",
                                                       "effective_compensation_change_date_max").distinct


val bycontract_job_month = Window.partitionBy("employee_id","france_payroll_id","effective_job_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_job_change_date_read =spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                                     .filter("""contract_start_date <= '""" + date_end_month + """'""")  
                                                                     .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                                     .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                                     .withColumn("effective_job_change_date", when($"effective_job_change_date".isNotNull,$"effective_job_change_date").otherwise($"contract_start_date"))
                                                                     .filter("""effective_job_change_date <= '""" + date_end_month + """'""")   
                                                                     .withColumn("rank_month",rank() over bycontract_job_month)
                                                                     .filter(col("rank_month")==="1")  
                                                                     .distinct

val bycontract_compensation_month = Window.partitionBy("employee_id","france_payroll_id","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_compensation_change_date_read =spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                                     .filter("""contract_start_date <= '""" + date_end_month + """'""")    
                                                                     .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                                     .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date".isNotNull,$"effective_compensation_change_date").otherwise($"contract_start_date"))                                         
                                                                     .filter("""effective_compensation_change_date <= '""" + date_end_month + """'""")   
                                                                     .withColumn("rank_month",rank() over bycontract_compensation_month)
                                                                     .filter(col("rank_month")==="1")  
                                                                     .distinct

val df_contract_join = df_effective_change_valid.as("e")
                                        .join(df_contract_effective_job_change_date_read.as("c"), $"e.employee_code" === $"c.employee_code" && $"e.effective_job_change_date_max" === $"c.effective_job_change_date" && $"e.contract_start_date" === $"c.contract_start_date", "left_outer")
                                        .join(df_contract_effective_compensation_change_date_read.as("o"), $"e.employee_code" === $"o.employee_code" && $"e.effective_compensation_change_date_max" === $"o.effective_compensation_change_date" && $"e.contract_start_date" === $"o.contract_start_date", "left_outer")
                                        .join(df_contract_read.as("d"), $"e.employee_code" === $"d.employee_code" && $"e.contract_start_date" === $"d.contract_start_date" && ($"e.effective_job_change_date_max" === $"d.effective_job_change_date" || $"e.effective_compensation_change_date_max" === $"d.effective_compensation_change_date"), "left_outer")
                                        .join(df_contract_read.as("r"), $"e.employee_code" === $"r.employee_code" && $"e.contract_start_date" === $"r.contract_start_date", "left_outer")
                                        .selectExpr(
                                                "e.employee_code"
                                               ,"e.employee_id"
                                               ,"e.france_payroll_id"
                                               ,"coalesce(r.contract_start_date, e.contract_start_date) as contract_start_date"
                                               ,"coalesce(r.contract_end_date, e.contract_end_date) as contract_end_date"
                                               ,"e.effective_job_change_date"
                                               ,"coalesce(c.collective_agreement_reference, d.collective_agreement_reference) as collective_agreement_reference"                                    
                                               ,"coalesce(c.collective_agreement_group, d.collective_agreement_group) as collective_agreement_group"
                                               ,"coalesce(c.collective_agreement_level, d.collective_agreement_level) as collective_agreement_level"
                                               ,"coalesce(c.continous_service_date, d.continous_service_date) as continous_service_date"
                                               ,"coalesce(c.position_start_date, d.position_start_date) as position_start_date"
                                               ,"coalesce(c.hire_date, d.hire_date) as hire_date"
                                               ,"coalesce(c.original_hire_date, d.original_hire_date) as original_hire_date"
                                               ,"coalesce(c.effective_hire_date, d.effective_hire_date) as effective_hire_date"
                                               ,"coalesce(c.fte, d.fte) as fte"
                                               ,"coalesce(c.worker_type, d.worker_type) as worker_type"
                                               ,"coalesce(c.paidfte, d.paidfte) as paidfte"
                                               ,"coalesce(c.bonus_target, d.bonus_target) as bonus_target"
                                               ,"coalesce(c.csp, d.csp) as csp"
                                               ,"coalesce(c.coefficient, d.coefficient) as coefficient"
                                               ,"coalesce(c.coefficient_label, d.coefficient_label) as coefficient_label"
                                               ,"coalesce(c.job_title, d.job_title) as job_title"
                                               ,"coalesce(o.total_base_pay, d.total_base_pay) as total_base_pay"
                                               ,"coalesce(o.grade, d.grade) as grade"
                                               ,"coalesce(o.effective_compensation_change_date, d.effective_compensation_change_date) as effective_compensation_change_date"
                                               ,"coalesce(c.job_code, d.job_code) as job_code"
                                               ,"coalesce(c.job_title_code, d.job_title_code) as job_title_code"
                                               ,"coalesce(o.grade_code, d.grade_code) as grade_code"
                                               ,"coalesce(c.csp_code, d.csp_code) as csp_code"
                                               ,"coalesce(c.worker_rate_code, d.worker_rate_code) as worker_rate_code"
                                               ,"coalesce(d.mobility_in_code, c.mobility_in_code) as mobility_in_code"
                                               ,"coalesce(d.mobility_out_code, c.mobility_out_code) as mobility_out_code"
                                               ,"coalesce(d.info_dates_code, c.info_dates_code) as info_dates_code"
                                               ,"coalesce(d.in_out_dates_code, c.in_out_dates_code) as in_out_dates_code"
                                               ,"coalesce(d.contract_dates_code, c.contract_dates_code) as contract_dates_code"                                               
                                               ,"coalesce(c.contract_code, d.contract_code) as contract_code"
                                               ,"coalesce(d.contract_type_code, c.contract_type_code) as contract_type_code"
                                               ,"coalesce(c.collective_agreement_code, d.collective_agreement_code) as collective_agreement_code"
                                               ,"coalesce(c.company_dates_code, d.company_dates_code) as company_dates_code"
                                               ,"coalesce(d.record_start_date, c.record_start_date) as record_start_date"
                                               ,"coalesce(d.date_raw_load_file, c.date_raw_load_file) as date_raw_load_file"
                                               ,"coalesce(d.record_modification_date, c.record_modification_date) as record_modification_date"
                                               ,"coalesce(d.record_creation_date, c.record_creation_date) as record_creation_date"
                                        )

                                          .distinct

df_contract_join.createOrReplaceTempView("vw_emp_contract") 


// COMMAND ----------

val bycontract_job_change = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc,$"effective_job_change_date".desc,$"effective_compensation_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_read_job_change = df_contract_join.withColumn("rank",rank() over bycontract_job_change)                                                
                                                 .filter(col("rank")==="1")
                                                 .distinct
                                                .withColumn("position_start_date", when($"position_start_date" > $"effective_job_change_date",$"effective_job_change_date").otherwise($"position_start_date"))
                                                .withColumn("continous_service_date", when($"continous_service_date" > $"contract_start_date",$"contract_start_date").otherwise($"continous_service_date"))

df_contract_read_job_change.createOrReplaceTempView("vw_contract_job_change")

// COMMAND ----------

// MAGIC %md ####2- Create KPIs

// COMMAND ----------

// DBTITLE 1,Get the Home office days
spark.sql( """select a.employee_hra,
                     a.code,
                     count(distinct dateval) as nb_homeoffice_days       
                                
              from   vw_absenteism a 
              where  upper(a.code) in ('TELE', 'TELI','TELP','TELC')
              
              group by a.employee_hra,a.code
              
                               """).createOrReplaceTempView("vw_homeofficedays")

// COMMAND ----------

// DBTITLE 1,Get the maternity, paternity, adoption and cae days to calculate the percent CAE usage
spark.sql( """select 
                      a.employee_hra
                     ,sum(case when a.code = 'CAE' and to_date(a.dateval_end) >= to_date('""" + date_start_month + """','yyyy-MM-dd') and to_date(a.dateval_end) <= to_date('""" + date_end_month + """','yyyy-MM-dd') then a.duration_days else null end) as nb_cae_consumed_days
                     ,sum(case when a.code = 'CAE' and date_format(a.dateval_start,'yyyyMM') <= """ + month_id + """ and date_format(dateval_end,'yyyyMM') >= """ + month_id + """ then 1 else null end) as nb_cae_beneficiary_days
                     ,sum(case when a.code = 'CAE' and (datediff(to_date('""" + date_end_month + """','yyyy-MM-dd'),to_date(a.dateval_end)) > 28 or datediff(to_date('""" + date_end_month + """','yyyy-MM-dd'),to_date(a.dateval_end)) > 98) then 1 else null end) as is_cae_end
                     ,sum(case when a.code= 'MAT' then duration_days else null end) as nb_mat_days
                     ,sum(case when a.code= 'PAT' then duration_days else null end) as nb_pat_days
                     ,sum(case when a.code= 'ADO' then duration_days else null end) as nb_ado_days
                     
                     ,max(case when a.code = 'CAE' then a.dateval_start end) as date_deb_cae                    
                     ,max(case when a.code = 'CAE' then a.dateval_end end) as date_end_cae
                     
                     ,max(case when a.code = 'PAT' then a.dateval_start end) as date_deb_pat                     
                     ,max(case when a.code = 'PAT' then a.dateval_end end) as date_end_pat
                     
                     ,max(case when a.code = 'MAT' then a.dateval_start end) as date_deb_mat
                     ,max(case when a.code = 'MAT' then a.dateval_end end) as date_end_mat
                     
                     ,max(case when a.code = 'ADO' then a.dateval_start end) as date_deb_ado
                     ,max(case when a.code = 'ADO' then a.dateval_end end) as date_end_ado
                     ,min(case when a.code = 'CAE' and to_date(a.dateval_end) >= to_date('""" + date_start_month + """','yyyy-MM-dd') and to_date(a.dateval_end) <= to_date('""" + date_end_month + """','yyyy-MM-dd') then a.dateval_start else null end) as date_min_consumed
                     ,max(case when a.code = 'CAE' and to_date(a.dateval_end) >= to_date('""" + date_start_month + """','yyyy-MM-dd') and to_date(a.dateval_end) <= to_date('""" + date_end_month + """','yyyy-MM-dd') then a.dateval_end else null end) as date_max_consumed
                     
                     ,""" + date_id + """ as date_id
                   
           
              from   vw_absenteism_consolidated a 
                                              
              where  1=1
                and  upper(a.code) in ('MAT', 'PAT', 'ADO', 'CAE') 
                and  to_date(a.dateval_start) <= to_date('""" + date_end_month + """','yyyy-MM-dd') 
                and  abs(year(dateval_end) - """ + year_id + """) <= 1
                and  (a.code_after = 'CAE' or a.code_after is null or a.code_before in ('MAT', 'PAT', 'ADO') or a.code_before is null)
            
          
             group by a.employee_hra
             --,year(a.dateval_start)
              
        """)
.filter($"nb_cae_consumed_days".isNotNull or $"nb_cae_beneficiary_days".isNotNull )
.createOrReplaceTempView("vw_cae")

// COMMAND ----------

val query_benefits = """ select distinct
                                home.nb_homeoffice_days
                               ,cae.nb_cae_beneficiary_days
                               ,cae.nb_cae_consumed_days
                               
                               ,case when cae.nb_cae_consumed_days is not null and cae.nb_mat_days = """ + NB_ABS_DAYS_MAT + """ then cae.nb_cae_consumed_days
                                     when cae.nb_cae_consumed_days is not null and cae.nb_pat_days is not null and date_deb_pat < to_date('""" + DATE_CHANGE_ABS_DAYS_PAT + """') then cae.nb_cae_consumed_days + """ + NB_ABS_DAYS_PAT_BEFORE_072021 + """
                                     when cae.nb_cae_consumed_days is not null and cae.nb_pat_days is not null and date_deb_pat >= to_date('""" + DATE_CHANGE_ABS_DAYS_PAT + """') then cae.nb_cae_consumed_days + """ + NB_ABS_DAYS_PAT_AFTER_072021 + """
                                     when cae.nb_cae_consumed_days is not null and cae.nb_ado_days = """ + NB_ABS_DAYS_ADO + """ then cae.nb_cae_consumed_days + """ + NB_ABS_DAYS_ADO_SUPP + """ else null end as numerator_percent_cae 
                                
                               ,case when cae.nb_cae_consumed_days is not null and cae.nb_mat_days = """ + NB_ABS_DAYS_MAT + """ then """ + NB_DAYS_DENOM_CAE_MAT + """ 
                                     when cae.nb_cae_consumed_days is not null and (cae.nb_pat_days is not null or cae.nb_ado_days = """ + NB_ABS_DAYS_ADO + """) then """ + NB_DAYS_DENOM_CAE_ADO + """ else null end as denominator_percent_cae
                                
                               ,case when cae.nb_cae_beneficiary_days is not null and ((cae.nb_mat_days is not null and cae. date_deb_cae > cae.date_end_mat) or (cae.nb_ado_days is not null and  date_deb_cae > date_end_ado)) then 'PARENT 1'
                                     when cae.nb_cae_beneficiary_days is not null and cae.nb_pat_days is not null and  cae.date_deb_cae > cae.date_end_pat then 'PARENT 2' else 'NC' end as type_parent
                               
                               ,coalesce(d.employee_id, -1) as employee_id
                               ,coalesce(ct.contract_type_id, -1) as contract_type_id
                               ,coalesce(wr.worker_rate_id, -1) as worker_rate_id
                               ,case when upper(c.contract_type) = 'VA' or  lower(ct.contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else coalesce(csp.csp_id, -1) end as csp_id
                               ,coalesce(nat.nationality_id, -1) as nationality_id
                               ,coalesce(ag.range_age_id, -1) as range_age_id
                               ,coalesce(sec.seniority_company_id, -1) as seniority_company_id
                               ,coalesce(sep.seniority_position_id, -1) as seniority_position_id
                               ,coalesce(loc.location_id,-1) as location_id
                               ,coalesce(job.job_architecture_id, -1) as job_architecture_id
                               ,coalesce(man.manager_id, -1) as manager_id
                               ,coalesce(so.supervisory_organization_id, -1) as supervisory_organization_id
                               ,coalesce(ol.legal_organization_id,'-1') as legal_organization_id
                               ,coalesce(op.operational_organization_id,'-1') as operational_organization_id
                               ,coalesce(mob_in.mobility_in_id, -1) as mobility_in_id
                               ,coalesce(mob_out.mobility_out_id,-1) as mobility_out_id
                               ,coalesce(id.info_dates_id, -1) as info_dates_id
                               ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
                               ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
                               
                               ,-1 as compensation_change_id
                               ,-1 as compensation_merit_plan_id
                               ,-1 as compensation_bonus_plan_id
                               ,coalesce(homeoff.homeoffice_id,-1) as homeoffice_id
                               ,-1 as increase_type_id
                               ,-1 as action_housing_id
                               ,-1 as range_payout_id
                               ,-1 as eligibility_psb_id
                               ,""" + date_id + """ as date_id
                               ,current_timestamp() as recordcreationdate
                               ,'""" + runid + """' as runid
                               ,case when cae.nb_cae_beneficiary_days is not null and ((cae.nb_mat_days is not null and  cae.date_deb_cae > cae.date_end_mat) or (cae.nb_ado_days is not null and  cae.date_deb_cae > cae.date_end_ado)) then 1
                                     when cae.nb_cae_beneficiary_days is not null and cae.nb_pat_days is not null and  cae.date_deb_cae > cae.date_end_pat then 2 else -1 end as type_parent_id                               
                               
                               ,coalesce(cae.date_min_consumed , cae.date_deb_cae) as date_deb_cae
                               ,coalesce(cae.date_max_consumed, cae.date_end_cae) as date_fin_cae
                         
                      from     vw_employee e 
                               inner join vw_contract c on e.employee_code = c.employee_code                        
            
                               left join vw_d_employee d on e.employee_code = d.employee_code
                               left join vw_d_nationality nat on e.nationality_code = nat.nationality_code
                               left join vw_d_location loc on e.location_code = loc.location_code
                               left join vw_d_manager man on e.manager_code = man.manager_code
                               left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code
                               left join vw_d_legal_organization ol on e.legal_organization_code = ol.legal_organization_code
                               left join vw_d_operational_organization op on e.operational_organization_code = op.operational_organization_code
                               left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code
                               left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date('""" + date_id + """','yyyyMMdd'),e.birth_date,true)/12) end)
                        
                               left join vw_d_mobility_in mob_in on mob_in.mobility_in_code = c.mobility_in_code
                               left join vw_d_mobility_out mob_out on mob_out.mobility_out_code = c.mobility_out_code                        
                               left join vw_d_in_out_dates iod on iod.in_out_dates_code = c.in_out_dates_code 
                                                              and iod.org_in_out_dates_code = e.org_in_out_dates_code
                        
                               left join vw_contract_job_change ccc on ccc.employee_code = c.employee_code 
                                                                    and c.contract_start_date = ccc.contract_start_date 
                                                                    and ccc.rank=1                                                              
                               left join vw_d_worker_rate wr on ccc.worker_rate_code = wr.worker_rate_code                                          
                               left join vw_d_csp csp on ccc.csp_code = csp.csp_code           
                               
                               left join vw_d_contract_type ct on c.contract_type_code = ct.contract_type_code
                                                              and ccc.collective_agreement_code = ct.collective_agreement_code
                                                       
                               left join vw_d_job_architecture job on ccc.job_title_code = job.job_title_code    
                                                                  and coalesce(ccc.grade_code, -1) = coalesce(job.grade_code, -1) 
                               
                               left join vw_d_info_dates id on id.company_dates_code = ccc.company_dates_code 
                                                           and id.contract_dates_code = c.contract_dates_code
                                                            
                               left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(ccc.continous_service_date) then null else datediff(to_date(c.seniority_date_max),to_date(ccc.continous_service_date)) end)
                               left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(ccc.position_start_date) then null else datediff(to_date(c.seniority_date_max),to_date(ccc.position_start_date)) end)
                               
                        
                               left join vw_homeofficedays home on e.france_payroll_id = home.employee_hra   
                               left join vw_d_homeoffice homeoff on home.code = homeoff.code
                               left join vw_cae cae on e.france_payroll_id = cae.employee_hra and cae.date_id =  """ + date_id + """ 
                                                                                      
                   """

// COMMAND ----------

val df_benefits_results = spark.sql(query_benefits).filter($"nb_homeoffice_days".isNotNull or $"nb_cae_beneficiary_days".isNotNull)


// COMMAND ----------

// MAGIC %md ####3- Save Data

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """Exec [dbo].[usp_deletePartitionTableData] 'f_benefits','pay','myMonthlyRangePS',""" + date_id
val res = stmt.execute(query_delete)

// COMMAND ----------

df_benefits_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "pay.f_benefits", connectionproperties)


// COMMAND ----------

val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)