// Databricks notebook source
val start_date = dbutils.widgets.get("start_date");
val domain = dbutils.widgets.get("domain").replace(" ","").split(",").toList;
val period = dbutils.widgets.get("period");
val runid = dbutils.widgets.get("runid");
val limit_date = dbutils.widgets.get("limit_date")
val flux = dbutils.widgets.get("flux")
val historical_data_end_date = dbutils.widgets.get("historical_data_end_date")
val init_table = dbutils.widgets.get("init_table")
val limit_date_histo = dbutils.widgets.get("limit_date_histo")
val system_source = dbutils.widgets.get("system_source")

// COMMAND ----------

// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

val date_value = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd")).plusMonths(-1)
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val dvalue = LocalDate.parse("2022-04-01", DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val system_source = if (date_end_month.isBefore (dvalue)) {"hra"} else {"adp"}

// COMMAND ----------

// MAGIC %md ## 1- Quotidien/Retroactivité

// COMMAND ----------

def load_fact_daily(path_notebook: String, start_date:String, period: String, domain:String, name:String, runid:String, loop:Boolean, limit_date: String) = {
  
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val timeoutSeconds=0
  val notebook=path_notebook 
  val intro_date = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
  
  //- 12 months of start_date
  var start_date_value_m = intro_date.minusMonths(12)
  
  if (start_date_value_m.toString < limit_date)
  {
    start_date_value_m = LocalDate.parse(limit_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
  }
  
  //end of the day of start_date
  var end_date_value_m = intro_date.withDayOfMonth(intro_date.lengthOfMonth())
  
  //start of the month from start _date
  var start_date_value_d =intro_date.withDayOfMonth(intro_date.lengthOfMonth()).minusDays(intro_date.lengthOfMonth()-1)
  
  var res = false
  var result=""
  var query_insert=""
  var query_snapshot = ""
  var res_snapshot = false
  var date_id= ""
  
  if (loop == true)
  {
       
    if(period == "month" | period == "all")
    {
      //loop on the begin and the end of each month until the start date
      while(start_date_value_m.toString <= end_date_value_m.toString)
      {
        /**********************************staff***************************************/
        if(domain.toLowerCase() == "staff")
        {
          //begin of month
          if (start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth()).toString < end_date_value_m.toString)
          {
            start_date_value_m = start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth()).minusDays(start_date_value_m.lengthOfMonth()-1)
            println("1",start_date_value_m,domain)
            result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> start_date_value_m.toString, "limit_date_histo" -> limit_date_histo)) 
            query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + start_date_value_m.toString + """','""" + result + """','""" + DateTime.now() + """') """
            res = stmt.execute(query_insert)
          }
        
          //end of month
          if (start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth()).toString < end_date_value_m.toString) 
          {          
            start_date_value_m = start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth())
            println("2",start_date_value_m,domain)
            result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> start_date_value_m.toString, "limit_date_histo" -> limit_date_histo)) 
            query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + start_date_value_m.toString + """','""" + result + """','""" + DateTime.now() + """') """
            res = stmt.execute(query_insert)
            
          }
          start_date_value_m = start_date_value_m.plusMonths(1)
     
       } 
       
           
           /**********************************pay, benefits, compensation, absence recruitment***************************************/
             //end of month
        if (domain.toLowerCase() == "pay" | domain.toLowerCase() == "benefits" | domain.toLowerCase() == "absence" | domain.toLowerCase() == "compensation" | domain.toLowerCase() == "career" | domain.toLowerCase() == "recruitment")
        {          

           var load_date = start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth()).plusDays(1)          

           if (start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth()).toString < end_date_value_m.toString)
           {
              println("3",load_date,domain)
              result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> load_date.toString, "historical_data_end_date" -> historical_data_end_date, "limit_date_histo" -> limit_date_histo, "system_source" -> system_source)) 
              query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + load_date.toString + """','""" + result + """','""" + DateTime.now() + """') """
              res = stmt.execute(query_insert)
                
            }              
            start_date_value_m = start_date_value_m.plusMonths(1)

         }
         
       }
     } 
    
    /**********************************staff daily***************************************/
    
    if((period == "day" | period=="all") & (domain.toLowerCase() == "staff" ))
    {
      //loop on each day of the month until the start date
       while(start_date_value_d.toString <= intro_date.toString)
      {
        println("4",start_date_value_d,domain)
        result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> start_date_value_d.toString, "limit_date_histo" -> limit_date_histo)) 
        query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + start_date_value_d.toString + """','""" + result + """','""" + DateTime.now() + """') """
        res = stmt.execute(query_insert)
        start_date_value_d = start_date_value_d.plusDays(1)

      }
    }
  }
   /**********************************mobility daily***************************************/
  if (loop == false)
  {  
    if((period == "day" | period=="all") & (domain.toLowerCase() == "mobility" ))
    {
        println("5",intro_date, domain)
        
        var limit_date_d = LocalDate.parse(limit_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
        result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" ->intro_date.toString, "start_date" -> limit_date_d.toString, "limit_date_histo" -> limit_date_histo)) 
        query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + intro_date.toString + """','""" + result + """','""" + DateTime.now() + """') """
        res = stmt.execute(query_insert)
    }
    
    /**********************************employee history daily***************************************/
    
    if((period == "day" | period=="all") & (domain.toLowerCase() == "employee_history" ))
    {
      println("6",intro_date,domain)
      result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> intro_date.toString, "historical_data_end_date" -> historical_data_end_date)) 
      query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + intro_date.toString + """','""" + result + """','""" + DateTime.now() + """') """
      res = stmt.execute(query_insert)
    }
    
    /**********************************training daily***************************************/
    
    if((period == "day" | period=="all") & (domain.toLowerCase() == "training" ))
    {
      println("9",intro_date,domain)
      result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> intro_date.toString, "historical_data_end_date" -> historical_data_end_date, "limit_date_histo" -> limit_date_histo)) 
      query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + intro_date.toString + """','""" + result + """','""" + DateTime.now() + """') """
      res = stmt.execute(query_insert)
    }
  } 
  
  spark.sql("clear cache")
}

// COMMAND ----------

if (flux.toLowerCase() == "quotidien"){
  if (domain.contains("staff") | domain.contains("all")){
    load_fact_daily("/DataInsights/Solution/Facts/load_dmt_f_staff", start_date, period, "staff","f_staff", runid, true, limit_date)  
  }
  //last day month
  if (domain.contains("pay") | domain.contains("all")){
      load_fact_daily("/DataInsights/Solution/Facts/load_dmt_f_pay", start_date, period, "pay", "f_pay", runid, true, limit_date)
  }
  //last day month
  if (domain.contains("benefits") | domain.contains("all")){
    load_fact_daily("/DataInsights/Solution/Facts/load_dmt_f_benefits", start_date, period, "benefits", "f_benefits", runid, true , limit_date)
  }
  if (domain.contains("mobility") | domain.contains("all")){
    load_fact_daily("/DataInsights/Solution/Facts/load_dmt_f_mobility", start_date, period, "mobility", "f_mobility", runid, false, limit_date)  
  }
  if (domain.contains("employee_history") | domain.contains("all")){
    load_fact_daily("/DataInsights/Solution/Facts/load_dmt_f_employee_history", start_date, period, "employee_history", "f_employee_history", runid, false, limit_date)  
  }
    //last day month
  if (domain.contains("absence") | domain.contains("all")){
    load_fact_daily("/DataInsights/Solution/Facts/load_dmt_f_absence", start_date, period, "absence", "f_absence", runid, true , limit_date)
  }
     //last day month
  if (domain.contains("compensation") | domain.contains("all")){
    load_fact_daily("/DataInsights/Solution/Facts/load_dmt_f_compensation", start_date, period, "compensation", "f_compensation", runid, true , limit_date)
  }
  
  if (domain.contains("training") | domain.contains("all")){
    load_fact_daily("/DataInsights/Solution/Facts/load_dmt_f_training", start_date, period, "training", "f_training", runid, false, limit_date)  
  }
  
  //last day month
  if (domain.contains("career") | domain.contains("all")){
    load_fact_daily("/DataInsights/Solution/Facts/load_dmt_f_career", start_date, period, "career", "f_career", runid, true, limit_date)  
  }
  
  //last day month
  if (domain.contains("recruitment") | domain.contains("all")){
    load_fact_daily("/DataInsights/Solution/Facts/load_dmt_f_recruitment", start_date, period, "recruitment", "f_recruitment", runid, true, limit_date)  
  }
}

// COMMAND ----------

// MAGIC %md ## 2- Historique

// COMMAND ----------

def load_fact_history(path_notebook: String, start_date:String, limit_date: String, domain: String, name:String, runid:String ) = {
  
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val timeoutSeconds=0 
  val notebook=path_notebook 

  var start_date_value_m = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
  var start_date_value_d = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
  var query_insert = ""
  var res = false
  var query_truncate = ""
  var res_truncate = false
  var query_snapshot = ""
  var res_snapshot = false
  var result=""
  var date_id= ""

  //delete from histo
  var query_delete = """ delete from dbo.load_histo_follow_up where load_table = '""" + name + """' """
  var res_delete = stmt.execute(query_delete)
  
  /**********************************pay, benefits, compensation***************************************/
  if(domain.toLowerCase() == "pay" | domain.toLowerCase() == "benefits" | domain.toLowerCase() == "compensation")
  {
    //truncate tables pay, compensation and benefits
        var daily_table = "pay.f_" + domain
        var monthly_table = "pay.f_" + domain + "_monthly"
    
     if(init_table.toLowerCase() == "yes")
     {
        query_truncate= """ truncate table  """ + daily_table
        res_truncate = stmt.execute(query_truncate)

        query_truncate= """ truncate table  """ + monthly_table
        res_truncate = stmt.execute(query_truncate)
     }
    
    while(start_date_value_m.toString <= limit_date)
    {
      start_date_value_m = start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth())      
      var load_date = start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth()).plusDays(1)      
      println("1",load_date,domain)  
      var result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> load_date.toString, "historical_data_end_date" -> historical_data_end_date, "limit_date_histo" -> limit_date_histo, "system_source" -> system_source)) 
      query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + start_date_value_m.toString + """','""" + result + """','""" + DateTime.now() + """') """
      res = stmt.execute(query_insert)
      
      //snapshot
      date_id = start_date_value_m.toString.replace("-","")
      query_snapshot = """[dbo].[usp_copy_monthly_snapshot] '""" + domain + """','historic', '""" + runid + """', '""" + date_id + """'"""
      res_snapshot = stmt.execute(query_snapshot)
      
      start_date_value_m = start_date_value_m.plusMonths(1)

     }
  }
  
   /**********************************absence***************************************/
  if(domain.toLowerCase() == "absence")
  {
        var daily_table = "absence.f_" + domain
        var monthly_table = "absence.f_" + domain + "_monthly"
    
       //truncate table absence
      if(init_table.toLowerCase() == "yes")
      {
        query_truncate= """ truncate table  """ + daily_table
        res_truncate = stmt.execute(query_truncate)

        query_truncate= """ truncate table  """ + monthly_table
        res_truncate = stmt.execute(query_truncate)
      }
    
    while(start_date_value_m.toString <= limit_date)
    {
      start_date_value_m = start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth())      
      var load_date = start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth()).plusDays(1)      
      println("1",load_date,domain)  
      var result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> load_date.toString, "historical_data_end_date" -> historical_data_end_date, "limit_date_histo" -> limit_date_histo)) 
      query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + start_date_value_m.toString + """','""" + result + """','""" + DateTime.now() + """') """
      res = stmt.execute(query_insert)
      
      //snapshot
      date_id = start_date_value_m.toString.replace("-","")
      query_snapshot = """[dbo].[usp_copy_monthly_snapshot] '""" + domain + """','historic', '""" + runid + """', '""" + date_id + """'"""
      res_snapshot = stmt.execute(query_snapshot)
      
      start_date_value_m = start_date_value_m.plusMonths(1)

     }
  }

  /**********************************career***************************************/
  if(domain.toLowerCase() == "career")
  {
        var daily_table = "career.f_" + domain
        var monthly_table = "career.f_" + domain + "_monthly"
    
       //truncate table absence
      if(init_table.toLowerCase() == "yes")
      {
        query_truncate= """ truncate table  """ + daily_table
        res_truncate = stmt.execute(query_truncate)

        query_truncate= """ truncate table  """ + monthly_table
        res_truncate = stmt.execute(query_truncate)
      }
    
    while(start_date_value_m.toString <= limit_date)
    {
      start_date_value_m = start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth())      
      var load_date = start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth()).plusDays(1)      
      println("1",load_date,domain)  
      var result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> load_date.toString, "historical_data_end_date" -> historical_data_end_date, "limit_date_histo" -> limit_date_histo)) 
      query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + start_date_value_m.toString + """','""" + result + """','""" + DateTime.now() + """') """
      res = stmt.execute(query_insert)
      
      //snapshot
      date_id = start_date_value_m.toString.replace("-","")
      query_snapshot = """[dbo].[usp_copy_monthly_snapshot] '""" + domain + """','historic', '""" + runid + """', '""" + date_id + """'"""
      res_snapshot = stmt.execute(query_snapshot)
      
      start_date_value_m = start_date_value_m.plusMonths(1)

     }
  }
  
   /**********************************staff***************************************/
  if (domain.toLowerCase() == "staff")
  {
    
     //truncate tables staff
      var daily_table = "staff.f_" + domain
      var monthly_table = "staff.f_" + domain + "_monthly"
    
      if(init_table.toLowerCase() == "yes")
      {      
        query_truncate= """ truncate table  """ + daily_table
        res_truncate = stmt.execute(query_truncate)

        query_truncate= """ truncate table  """ + monthly_table
        res_truncate = stmt.execute(query_truncate)
      }
    //load data
     while(start_date_value_m.toString <= limit_date.toString)
      {
         //begin of month
        start_date_value_m = start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth()).minusDays(start_date_value_m.lengthOfMonth()-1)
        println("2",start_date_value_m,domain)
        result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> start_date_value_m.toString, "limit_date_histo" -> limit_date_histo)) 
        query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + start_date_value_m.toString + """','""" + result + """','""" + DateTime.now() + """') """
        res = stmt.execute(query_insert)
     
        
        //end of month
        start_date_value_m = start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth())
        println("3",start_date_value_m,domain)
        result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> start_date_value_m.toString, "limit_date_histo" -> limit_date_histo)) 
        query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + start_date_value_m.toString + """','""" + result + """','""" + DateTime.now() + """') """
        res = stmt.execute(query_insert)
        
        //snapshot last day and fist day
        date_id = start_date_value_m.toString.replace("-","")
        query_snapshot = """[dbo].[usp_copy_monthly_snapshot] '""" + domain + """','historic', '""" + runid + """', '""" + date_id + """'"""
        res_snapshot = stmt.execute(query_snapshot)
        
        start_date_value_m = start_date_value_m.plusMonths(1)
      }
  }
  
  /**********************************recruitment***************************************/
  if(domain.toLowerCase() == "recruitment")
  {
        var daily_table = "recruitment.f_" + domain
        var monthly_table = "recruitment.f_" + domain + "_monthly"
    
       //truncate table absence
      if(init_table.toLowerCase() == "yes")
      {
        query_truncate= """ truncate table  """ + daily_table
        res_truncate = stmt.execute(query_truncate)

        query_truncate= """ truncate table  """ + monthly_table
        res_truncate = stmt.execute(query_truncate)
      }
    
    while(start_date_value_m.toString <= limit_date)
    {
      start_date_value_m = start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth())      
      var load_date = start_date_value_m.withDayOfMonth(start_date_value_m.lengthOfMonth()).plusDays(1)      
      println("1",load_date,domain)  
      var result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> load_date.toString, "historical_data_end_date" -> historical_data_end_date, "limit_date_histo" -> limit_date_histo)) 
      query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + start_date_value_m.toString + """','""" + result + """','""" + DateTime.now() + """') """
      res = stmt.execute(query_insert)
      
      //snapshot
      date_id = start_date_value_m.toString.replace("-","")
      query_snapshot = """[dbo].[usp_copy_monthly_snapshot] '""" + domain + """','historic', '""" + runid + """', '""" + date_id + """'"""
      res_snapshot = stmt.execute(query_snapshot)
      
      start_date_value_m = start_date_value_m.plusMonths(1)

     }
  }
  
  /**********************************mobility**************************************/
  if (domain.toLowerCase() == "mobility")
  {
        //truncate tables mobility
          var daily_table = "mobility.f_" + domain
          var monthly_table = "mobility.f_" + domain + "_monthly"
    
      if(init_table.toLowerCase() == "yes")
      {     
          query_truncate= """ truncate table  """ + daily_table
          res_truncate = stmt.execute(query_truncate)

          query_truncate= """ truncate table  """ + monthly_table
          res_truncate = stmt.execute(query_truncate)
      }
        //load data
        var limit_date_d = LocalDate.parse(limit_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
        println("4",limit_date_d,domain)
        result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> limit_date_d.toString, "start_date" -> start_date_value_m.toString, "limit_date_histo" -> limit_date_histo)) 
        query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + limit_date_d.toString + """','""" + result + """','""" + DateTime.now() + """') """
        res = stmt.execute(query_insert)   
    
        //snapshot
            
        date_id = limit_date_d.toString.replace("-","")
        query_snapshot = """[dbo].[usp_copy_monthly_snapshot] '""" + domain + """','historic', '""" + runid + """', '""" + date_id + """'"""
        res_snapshot = stmt.execute(query_snapshot)
  }
  
    /**********************************training**************************************/
  if (domain.toLowerCase() == "training")
  {
        //truncate tables mobility
          var daily_table = "training.f_" + domain
          var monthly_table = "training.f_" + domain + "_monthly"
    
      if(init_table.toLowerCase() == "yes")
      {     
          query_truncate= """ truncate table  """ + daily_table
          res_truncate = stmt.execute(query_truncate)

          query_truncate= """ truncate table  """ + monthly_table
          res_truncate = stmt.execute(query_truncate)
      }
        //load data
        var limit_date_d = LocalDate.parse(limit_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
        println("4",limit_date_d,domain)
        result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> limit_date_d.toString, "start_date" -> start_date_value_m.toString, "historical_data_end_date" -> historical_data_end_date, "limit_date_histo" -> limit_date_histo)) 
        query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + limit_date_d.toString + """','""" + result + """','""" + DateTime.now() + """') """
        res = stmt.execute(query_insert)   
    
        //snapshot
            
        date_id = limit_date_d.toString.replace("-","")
        query_snapshot = """[dbo].[usp_copy_monthly_snapshot] '""" + domain + """','historic', '""" + runid + """', '""" + date_id + """'"""
        res_snapshot = stmt.execute(query_snapshot)
  }
  
  /**********************************employee_historical_data**************************************/
  if(domain.toLowerCase() == "employee_history") //employees history data
   {
        var employee_history_table = "staff.d_employee_historical_data"
        query_truncate= """ truncate table  """ + employee_history_table
        res_truncate = stmt.execute(query_truncate)
      
        var limit_date_d = LocalDate.parse(limit_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
        println("5",limit_date_d,domain)
        result = dbutils.notebook.run(notebook, timeoutSeconds, Map("runid" -> runid, "load_date" -> limit_date_d.toString, "historical_data_end_date" -> historical_data_end_date)) 
        query_insert = """ insert into dbo.load_histo_follow_up values ('""" + name + """','""" + limit_date_d.toString + """','""" + result + """','""" + DateTime.now() + """') """
        res = stmt.execute(query_insert)
   }
  
  spark.sql("clear cache")
}

// COMMAND ----------

if (flux.toLowerCase() == "historique"){
  if (domain.contains("staff") | domain.contains("all")){
    load_fact_history("/DataInsights/Solution/Facts/load_dmt_f_staff", start_date, limit_date, "staff","f_staff", runid)  
  }
  //last day month
  if (domain.contains("pay") | domain.contains("all")){
     load_fact_history("/DataInsights/Solution/Facts/load_dmt_f_pay", start_date, limit_date, "pay", "f_pay", runid)
  }
  //last day month
  if (domain.contains("benefits") | domain.contains("all")){
    load_fact_history("/DataInsights/Solution/Facts/load_dmt_f_benefits", start_date, limit_date, "benefits", "f_benefits", runid)
  }
  
  if (domain.contains("mobility") | domain.contains("all")){
    load_fact_history("/DataInsights/Solution/Facts/load_dmt_f_mobility", start_date, limit_date, "mobility", "f_mobility", runid)
  }
  
  if (domain.contains("employee_history") | domain.contains("all")){
    load_fact_history("/DataInsights/Solution/Facts/load_dmt_f_employee_history", start_date, limit_date, "employee_history", "f_employee_history", runid)  
  }
  
  //last day month
  if (domain.contains("absence") | domain.contains("all")){
     load_fact_history("/DataInsights/Solution/Facts/load_dmt_f_absence", start_date, limit_date, "absence", "f_absence", runid)
  }
  //last day month
  if (domain.contains("compensation") | domain.contains("all")){
    load_fact_history("/DataInsights/Solution/Facts/load_dmt_f_compensation", start_date, limit_date, "compensation", "f_compensation", runid)
  }
  //last day month
  if (domain.contains("recruitment") | domain.contains("all")){
    load_fact_history("/DataInsights/Solution/Facts/load_dmt_f_recruitment", start_date, limit_date, "recruitment", "f_recruitment", runid)
  }
  //last day month
  if (domain.contains("career") | domain.contains("all")){
    load_fact_history("/DataInsights/Solution/Facts/load_dmt_f_career", start_date, limit_date, "career", "f_career", runid)
  }
  //last day month
  if (domain.contains("training") | domain.contains("all")){
    load_fact_history("/DataInsights/Solution/Facts/load_dmt_f_training", start_date, limit_date, "training", "f_training", runid)
  }
}

// COMMAND ----------

val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0

// COMMAND ----------

dbutils.notebook.exit(return_value)