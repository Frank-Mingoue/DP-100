// Databricks notebook source
val load_date = dbutils.widgets.get("load_date");  
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val date_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + ("%02d".format(date_value.getDayOfMonth))


// COMMAND ----------

// DBTITLE 1,Run procedure to set the current date load
val query_current_period = """exec dbo.usp_set_CurrentPeriod '""" + date_value + "'"
val res_current_period = stmt.execute(query_current_period)

// COMMAND ----------

// DBTITLE 1,Run Procedure for snapshot
val query_copy_monthly_snapshot = """[dbo].[usp_copy_monthly_snapshot] 'all','daily', '""" + runid + """', '""" + date_id + """'"""
val res_copy_monthly_snapshot = stmt.execute(query_copy_monthly_snapshot)

// COMMAND ----------

// DBTITLE 1,Run Procedure for Deletion of Users Out
  val query_delete_securityUserOut = """exec dbo.usp_delete_securityUserOut """
  val res_delete_securityUserOut = stmt.execute(query_delete_securityUserOut)

// COMMAND ----------

// DBTITLE 1,Run procedure for database maintenance
///Script to create partition the last day of the month in parameter

val query_db_maintenance = """ exec dbo.usp_database_maintenance '""" + load_date + """'"""
val res_db_maintenance = stmt.execute(query_db_maintenance)


// COMMAND ----------

val read_records = 0 //count the number of read records
val inserted_records = 0 //count the number of read records
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)