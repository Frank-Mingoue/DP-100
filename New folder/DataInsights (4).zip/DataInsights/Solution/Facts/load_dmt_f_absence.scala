// Databricks notebook source
// DBTITLE 1,Get Parameters values: load_date and runid
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val limit_date_histo = dbutils.widgets.get("limit_date_histo");

// COMMAND ----------

// DBTITLE 1,Include functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Refresh delta table contract
 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table employee
 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table absenteism
 if(spark.catalog.tableExists("hr.absenteism")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table absenteism consolidated
 if(spark.catalog.tableExists("hr.absenteism_consolidated")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism_consolidated")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Set variables
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd")).plusMonths(-1)
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_next_month = date_end_month.plusDays(1)
val date_id = date_end_month.toString.replace("-","")
val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))
val date_start_month = date_value.withDayOfMonth(1)
val last_month = date_end_month.plusMonths(-1).getYear() + ("%02d".format(date_end_month.plusMonths(-1).getMonth.getValue()))
val last_month_id = date_end_month.plusMonths(-1).toString.replace("-","") 
val first_month_id = date_value.getYear() + "01"
val last_year_id = date_value.plusYears(-1).getYear()
val month_next_id = date_next_month.getYear() + ("%02d".format(date_next_month.getMonth.getValue()))
val date_end_last_month = date_start_month.plusDays(-1)

val limit_date_value = LocalDate.parse(limit_date_histo, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val filter_file_current_month = if (date_end_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}
val filter_file_previous_month = if (date_end_last_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}

// COMMAND ----------

// DBTITLE 1,Get Dimension Data
spark.read.jdbc(jdbcurl, "dbo.d_date", connectionproperties).filter(col("month_id") === lit(month_id)).createOrReplaceTempView("vw_d_date")
spark.read.jdbc(jdbcurl, "staff.d_employee", connectionproperties).select("employee_id", "employee_code", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_employee")
spark.read.jdbc(jdbcurl, "staff.d_contract_type", connectionproperties).select("contract_type_id", "contract_type_code","precarity","contract_type","contract_type_detailed", "worker_type", "collective_agreement_reference", "collective_agreement_group", "collective_agreement_level","classification_collective_agreement","collective_agreement_code","contract_code").filter("current_version = 1").createOrReplaceTempView("vw_d_contract_type")
spark.read.jdbc(jdbcurl, "staff.d_worker_rate", connectionproperties).select("worker_rate_id", "worker_rate_code", "hashkey", "fte").filter("current_version = 1").createOrReplaceTempView("vw_d_worker_rate")
spark.read.jdbc(jdbcurl, "staff.d_csp", connectionproperties).select("csp_id", "csp_code", "professional_category_reference").filter("current_version = 1").createOrReplaceTempView("vw_d_csp")
spark.read.jdbc(jdbcurl, "staff.d_nationality", connectionproperties).select("nationality_id", "nationality_code").filter("current_version = 1").createOrReplaceTempView("vw_d_nationality")


// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_range_age", connectionproperties).select("range_age_id", "range_age").filter("current_version = 1").createOrReplaceTempView("vw_d_range_age")
spark.read.jdbc(jdbcurl, "staff.d_seniority_company", connectionproperties).select("seniority_company_id", "range_seniority_company_age").filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_company")
spark.read.jdbc(jdbcurl, "staff.d_seniority_position", connectionproperties).select("seniority_position_id", "range_seniority_position_age").filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_position")
spark.read.jdbc(jdbcurl, "staff.d_location", connectionproperties).select("location_id", "location_code").filter("current_version = 1").createOrReplaceTempView("vw_d_location")
spark.read.jdbc(jdbcurl, "staff.d_job_architecture", connectionproperties).select("job_architecture_id", "job_architecture_code","job_title_code","grade_code").filter("current_version = 1").createOrReplaceTempView("vw_d_job_architecture")
spark.read.jdbc(jdbcurl, "staff.d_manager", connectionproperties).select("manager_id", "manager_code").filter("current_version = 1").createOrReplaceTempView("vw_d_manager")
spark.read.jdbc(jdbcurl, "staff.d_supervisory_organization", connectionproperties).select("supervisory_organization_id", "supervisory_organization_code").filter("current_version = 1").createOrReplaceTempView("vw_d_supervisory_organization")
spark.read.jdbc(jdbcurl, "staff.d_contract_suspension", connectionproperties).select("contract_suspension_id", "contract_suspension_code", "libelle_categorie").filter("current_version = 1").createOrReplaceTempView("vw_d_contract_suspension")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_legal_organization", connectionproperties).select("legal_organization_id", "legal_organization_code", "company", "libelle_etablissement","hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_legal_organization")
spark.read.jdbc(jdbcurl, "staff.d_operational_organization", connectionproperties).select("operational_organization_id", "operational_organization_code", "division_consolidated", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_operational_organization")
spark.read.jdbc(jdbcurl, "mobility.d_mobility_in", connectionproperties).select("mobility_in_id", "mobility_in_code").filter("current_version = 1").createOrReplaceTempView("vw_d_mobility_in")
spark.read.jdbc(jdbcurl, "mobility.d_mobility_out", connectionproperties).select("mobility_out_id", "mobility_out_code").filter("current_version = 1").filter("current_version = 1")createOrReplaceTempView("vw_d_mobility_out")
spark.read.jdbc(jdbcurl, "staff.vw_d_legal_organization", connectionproperties).select("legal_organization_id", "company", "libelle_etablissement").createOrReplaceTempView("vw_d_legal_organization_transcoded")
spark.read.jdbc(jdbcurl, "staff.d_employee_dependent", connectionproperties).filter("children_date_of_death is not null").filter(col("children_date_of_death") > to_date(lit(date_id),"yyyyMMdd")) .groupBy("employee_id").agg(count("hashkey").as("nb_children")).createOrReplaceTempView("vw_d_employee_dependent")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_info_dates", connectionproperties).select("info_dates_id", "info_dates_code", "position_start_date", "hire_date", "contract_start_date", "contract_end_date", "contract_dates_code","company_dates_code").filter("current_version = 1").createOrReplaceTempView("vw_d_info_dates")
spark.read.jdbc(jdbcurl, "mobility.d_in_out_dates", connectionproperties).filter("current_version = 1").select("in_out_dates_id", "in_out_dates_code", "org_in_out_dates_code").createOrReplaceTempView("vw_d_in_out_dates")
spark.read.jdbc(jdbcurl, "staff.d_contract_suspension_dates", connectionproperties).filter("current_version = 1").select("contract_suspension_dates_id", "contract_suspension_dates_code", "contract_suspension_start_date", "contract_suspension_end_date").createOrReplaceTempView("vw_d_contract_suspension_dates")
spark.read.jdbc(jdbcurl, "staff.d_hierarchy_pb", connectionproperties).filter("current_version = 1").select("hierarchy_pb_id", "cost_center_code").createOrReplaceTempView("vw_d_hierarchy_pb")
spark.read.jdbc(jdbcurl, "dbo.param_absenteism", connectionproperties).select("code_abs", "libelle_abs","type_abs").createOrReplaceTempView("vw_param_absenteism")
spark.read.jdbc(jdbcurl, "dbo.vw_ref_seniority_company", connectionproperties).createOrReplaceTempView("vw_ref_seniority_company")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "absence.d_motif", connectionproperties).select("motif_id", "absence_code","flag_prolongation","flag_ref","absence_type","absence_reason").filter("current_version = 1") .createOrReplaceTempView("vw_d_motif")
spark.read.jdbc(jdbcurl, "absence.d_absence_info_dates", connectionproperties).select("absence_info_dates_id", "absence_info_dates_code") .filter("current_version = 1")  .createOrReplaceTempView("vw_d_absence_info_dates")
spark.read.jdbc(jdbcurl, "absence.d_range_absence_duration", connectionproperties).createOrReplaceTempView("vw_range_absence_duration")
spark.read.jdbc(jdbcurl, "absence.d_id_absence", connectionproperties).select("id_absence_id", "id_absence").createOrReplaceTempView("vw_d_absence_id")
spark.read.jdbc(jdbcurl, "absence.d_absence_frequency", connectionproperties).filter("current_version = 1") .createOrReplaceTempView("vw_d_absence_frequency")
spark.read.jdbc(jdbcurl, "absence.d_absence_info_hours", connectionproperties).select("absence_info_hours_id", "absence_info_hours_code").filter("current_version = 1").createOrReplaceTempView("vw_d_absence_hour")

// COMMAND ----------

// DBTITLE 1,Get Parameters Values

val df_param_value = spark.read.jdbc(jdbcurl, "dbo.param_value", connectionproperties).select("parameter_name", "parameter_value")
val delay_change = df_param_value.filter($"parameter_name" === "DELAI_TRANSFORMATION_CONTRAT").select("parameter_value").first().getString(0).toDouble.toInt
val borne_6_months = spark.sql("""select distinct range_seniority_company_min as calendardays from vw_ref_seniority_company where range_seniority_company = 'Entre 6 mois et 1 an'""").head().getInt(0) //Borne min for seniority superior to 6 months
val vacataire_csp_id = spark.sql("""select cast(sum(csp_id) as int) as vacataire_csp_id from vw_d_csp where lower(professional_category_reference) = 'autre statut'""").head().getInt(0) //Get Vacataire Csp Id
val opendays = spark.sql("""select cast(sum(business_day_fr) as int) as opendays from vw_d_date where month_id = '""" + month_id + """'""").head().getInt(0) // Get Nb Opened Days in the load date month
val calendardays = spark.sql("""select cast(count(distinct date_id) as int) as calendardays from vw_d_date where month_id = '""" + month_id + """'""").head().getInt(0) // Get Nb Calendar Days in the load date month


// COMMAND ----------

// DBTITLE 1,Read contract and employee
// Retrieves organization based on effective change date
val byemployee = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_organization_change_date".desc,$"effective_organization_hierarchy_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_employee_read = spark.table("hr.employee").filter("('" + date_end_month.toString + "' >= record_start_date or '" + date_end_month.toString + "' >= effective_organization_hierarchy_change_date) and '" + date_end_month.toString + "' <= coalesce(record_end_date, '2999-12-31')")
                                                 .withColumn("rank",rank() over byemployee)
                                                 .filter(col("rank")==="1")
                                                 .filter("company_id <> '0082'")  //Exclude Italian
                                                 .distinct
                                                
df_employee_read.createOrReplaceTempView("vw_employee")
df_employee_read.cache()  //put the dataframe on the cache


val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

// Retrieves last contract version for the current month
val df_contract_read = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                 .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """' """
                                                        ) 
                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("month_contract_start_date",when($"contract_start_date" < date_start_month,date_start_month).otherwise($"contract_start_date"))
                                                .withColumn("month_contract_end_date",when($"contract_end_date" > date_end_month,date_end_month).when($"contract_end_date".isNull,date_end_month).otherwise($"contract_end_date"))
                                                .withColumn("contract_days",datediff($"month_contract_end_date",$"month_contract_start_date")+1)
                                                .filter(col("rank_month")==="1")
                                                .filter("""date_format(contract_start_date,'yyyyMM') = '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                            (date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                        )
                                                
                                                .withColumn("rank",rank() over bycontract)
                                                .withColumn("next_contract_start_date",lag($"contract_start_date", 1, null).over(bycontract) )
                                                .withColumn("next_contract_end_date",lag($"contract_end_date", 1, null).over(bycontract) )
                                                .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                .distinct
df_contract_read.createOrReplaceTempView("vw_contract")

// last contract 
val bycontractlast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_last_read = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                      .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")
                                                      .withColumn("rank_last",rank() over bycontractlast)
                                                      .filter(col("rank_last")==="1").distinct  
                                                      .withColumn("seniority_date_max",when(($"contract_end_date" === "2999-12-31" or $"contract_end_date".isNull or $"contract_end_date" > lit(date_end_month)) and $"contract_start_date" < lit(date_end_month), lit(date_end_month))
                                                                                      .when($"contract_start_date" >= lit(date_end_month), date_end_month)
                                                                                      .otherwise($"contract_end_date"))
df_contract_last_read.createOrReplaceTempView("vw_contract_last")

// COMMAND ----------

val byJobChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date_valid".desc)
val byJobChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_compensation_change_date_valid".desc)
val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date","effective_job_change_date","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_effective_change_valid = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")                                                
                                                .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                .withColumn("effective_job_change_date_valid", when($"effective_job_change_date" > lit(date_end_month),null).otherwise($"effective_job_change_date"))
                                                .withColumn("effective_job_change_date_valid_last", first($"effective_job_change_date").over(byJobChangeDateLast))
                                                .withColumn("effective_job_change_date", when($"effective_job_change_date_valid".isNotNull,$"effective_job_change_date_valid")
                                                                                        .when($"effective_job_change_date_valid_last".isNull, $"contract_start_date")
                                                                                        .otherwise($"effective_job_change_date_valid_last"))         
                                                .withColumn("effective_job_change_date_max", first($"effective_job_change_date").over(byJobChangeDateLastContract))

                                                .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                .withColumn("effective_compensation_change_date_valid", when($"effective_compensation_change_date" > lit(date_end_month),null).otherwise($"effective_compensation_change_date"))
                                                .withColumn("effective_compensation_change_date_valid_last", first($"effective_compensation_change_date").over(byCompensationChangeDateLast))
                                                .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date_valid".isNotNull,$"effective_compensation_change_date_valid")
                                                                                                 .when($"effective_compensation_change_date_valid_last".isNull, $"contract_start_date")
                                                                                                 .otherwise($"effective_compensation_change_date_valid_last"))        
                                                .withColumn("effective_compensation_change_date_max",first($"effective_compensation_change_date").over(byCompensationChangeDateLastContract))    


                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .filter(col("rank_month")==="1")  
                                                .filter("""date_format(contract_start_date,'yyyyMM') = '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                            (date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                        )
                                               .select("employee_code",
                                                       "employee_id",
                                                       "france_payroll_id",
                                                       "contract_start_date",
                                                       "contract_end_date",
                                                       "contract_type",
                                                       "contract_type_label",
                                                       "effective_job_change_date",
                                                       "effective_compensation_change_date",
                                                       "effective_job_change_date_max",
                                                       "effective_compensation_change_date_max").distinct


val bycontract_job_month = Window.partitionBy("employee_id","france_payroll_id","effective_job_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_job_change_date_read =spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                                     .filter("""contract_start_date <= '""" + date_end_month + """'""")  
                                                                     .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                                     .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                                     .withColumn("effective_job_change_date", when($"effective_job_change_date".isNotNull,$"effective_job_change_date").otherwise($"contract_start_date"))
                                                                     .filter("""effective_job_change_date <= '""" + date_end_month + """'""")   
                                                                     .withColumn("rank_month",rank() over bycontract_job_month)
                                                                     .filter(col("rank_month")==="1")  
                                                                     .distinct

val bycontract_compensation_month = Window.partitionBy("employee_id","france_payroll_id","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_compensation_change_date_read =spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                                     .filter("""contract_start_date <= '""" + date_end_month + """'""")    
                                                                     .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                                     .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date".isNotNull,$"effective_compensation_change_date").otherwise($"contract_start_date"))                                         
                                                                     .filter("""effective_compensation_change_date <= '""" + date_end_month + """'""")   
                                                                     .withColumn("rank_month",rank() over bycontract_compensation_month)
                                                                     .filter(col("rank_month")==="1")  
                                                                     .distinct

val df_contract_join = df_effective_change_valid.as("e")
                                        .join(df_contract_effective_job_change_date_read.as("c"), $"e.employee_code" === $"c.employee_code" && $"e.effective_job_change_date_max" === $"c.effective_job_change_date" && $"e.contract_start_date" === $"c.contract_start_date", "left_outer")
                                        .join(df_contract_effective_compensation_change_date_read.as("o"), $"e.employee_code" === $"o.employee_code" && $"e.effective_compensation_change_date_max" === $"o.effective_compensation_change_date" && $"e.contract_start_date" === $"o.contract_start_date", "left_outer")
                                        .join(df_contract_read.as("d"), $"e.employee_code" === $"d.employee_code" && $"e.contract_start_date" === $"d.contract_start_date" && ($"e.effective_job_change_date_max" === $"d.effective_job_change_date" || $"e.effective_compensation_change_date_max" === $"d.effective_compensation_change_date"), "left_outer")
                                        .join(df_contract_read.as("r"), $"e.employee_code" === $"r.employee_code" && $"e.contract_start_date" === $"r.contract_start_date", "left_outer")
                                        .selectExpr(
                                                "e.employee_code"
                                               ,"e.employee_id"
                                               ,"e.france_payroll_id"
                                               ,"coalesce(r.contract_start_date, e.contract_start_date) as contract_start_date"
                                               ,"coalesce(r.contract_end_date, e.contract_end_date) as contract_end_date"
                                               ,"e.effective_job_change_date"
                                               ,"coalesce(c.collective_agreement_reference, d.collective_agreement_reference) as collective_agreement_reference"                                    
                                               ,"coalesce(c.collective_agreement_group, d.collective_agreement_group) as collective_agreement_group"
                                               ,"coalesce(c.collective_agreement_level, d.collective_agreement_level) as collective_agreement_level"
                                               ,"coalesce(c.continous_service_date, d.continous_service_date) as continous_service_date"
                                               ,"coalesce(c.position_start_date, d.position_start_date) as position_start_date"
                                               ,"coalesce(c.hire_date, d.hire_date) as hire_date"
                                               ,"coalesce(c.original_hire_date, d.original_hire_date) as original_hire_date"
                                               ,"coalesce(c.effective_hire_date, d.effective_hire_date) as effective_hire_date"
                                               ,"coalesce(c.fte, d.fte) as fte"
                                               ,"coalesce(c.worker_type, d.worker_type) as worker_type"
                                               ,"coalesce(c.paidfte, d.paidfte) as paidfte"
                                               ,"coalesce(c.bonus_target, d.bonus_target) as bonus_target"
                                               ,"coalesce(c.csp, d.csp) as csp"
                                               ,"coalesce(c.coefficient, d.coefficient) as coefficient"
                                               ,"coalesce(c.coefficient_label, d.coefficient_label) as coefficient_label"
                                               ,"coalesce(c.job_title, d.job_title) as job_title"
                                               ,"coalesce(o.total_base_pay, d.total_base_pay) as total_base_pay"
                                               ,"coalesce(o.grade, d.grade) as grade"
                                               ,"coalesce(o.effective_compensation_change_date, d.effective_compensation_change_date) as effective_compensation_change_date"
                                               ,"coalesce(c.job_code, d.job_code) as job_code"
                                               ,"coalesce(c.job_title_code, d.job_title_code) as job_title_code"
                                               ,"coalesce(o.grade_code, d.grade_code) as grade_code"
                                               ,"coalesce(c.csp_code, d.csp_code) as csp_code"
                                               ,"coalesce(c.worker_rate_code, d.worker_rate_code) as worker_rate_code"
                                               ,"coalesce(d.mobility_in_code, c.mobility_in_code) as mobility_in_code"
                                               ,"coalesce(d.mobility_out_code, c.mobility_out_code) as mobility_out_code"
                                               ,"coalesce(d.info_dates_code, c.info_dates_code) as info_dates_code"
                                               ,"coalesce(d.in_out_dates_code, c.in_out_dates_code) as in_out_dates_code"
                                               ,"coalesce(d.contract_dates_code, c.contract_dates_code) as contract_dates_code"                                               
                                               ,"coalesce(c.contract_code, d.contract_code) as contract_code"
                                               ,"coalesce(d.contract_type_code, c.contract_type_code) as contract_type_code"
                                               ,"coalesce(c.collective_agreement_code, d.collective_agreement_code) as collective_agreement_code"
                                               ,"coalesce(c.company_dates_code, d.company_dates_code) as company_dates_code"
                                               ,"coalesce(d.record_start_date, c.record_start_date) as record_start_date"
                                               ,"coalesce(d.date_raw_load_file, c.date_raw_load_file) as date_raw_load_file"
                                               ,"coalesce(d.record_modification_date, c.record_modification_date) as record_modification_date"
                                               ,"coalesce(d.record_creation_date, c.record_creation_date) as record_creation_date"
                                        )

                                          .distinct

df_contract_join.createOrReplaceTempView("vw_emp_contract") 


// COMMAND ----------

// DBTITLE 1,Get Retroactivity data
val bycontract_job_change_fte = Window.partitionBy("employee_id","france_payroll_id","contract_start_date","fte").orderBy($"contract_start_date".desc,$"effective_job_change_date".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract_job_change = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_job_change_date".desc,$"effective_compensation_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_contract_read_job_change =  df_contract_join.withColumn("rank_fte",rank() over bycontract_job_change_fte)
                                                .filter(col("rank_fte")==="1")
                                    
                                    
                                                .filter("""ifnull(date_format(contract_end_date,'yyyyMM'),'299912') >= '""" + month_id + """'""")
                                                .withColumn("month_contract_start_date",when($"contract_start_date" < date_start_month,date_start_month).otherwise($"contract_start_date"))
                                                .withColumn("month_contract_end_date",when($"contract_end_date" > date_end_month,date_end_month).when($"contract_end_date".isNull,date_end_month).otherwise($"contract_end_date"))
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))

                                                .withColumn("effective_job_change_date_end",lag($"effective_job_change_date", 1, null).over(bycontract_job_change))
                                                .withColumn("effective_job_change_date_previous",lag($"effective_job_change_date", 1, null).over(bycontract_job_change))
                                                .withColumn("effective_job_change_date_end",when($"effective_job_change_date_end".isNull or $"effective_job_change_date_end" === $"effective_job_change_date" ,$"month_contract_end_date").otherwise(date_add($"effective_job_change_date_end",-1)))
                                                .withColumn("contract_days_job_change",when($"effective_job_change_date_end".isNotNull and $"effective_job_change_date_end" >= $"month_contract_start_date" and $"effective_job_change_date_end" < $"month_contract_end_date" and  datediff($"effective_job_change_date_end",$"month_contract_start_date")>=0, 
                                                                                            datediff($"effective_job_change_date_end",$"month_contract_start_date")+1)  
                                                                                       .when($"effective_job_change_date".isNotNull and $"effective_job_change_date" > $"month_contract_start_date" and $"effective_job_change_date" <= $"month_contract_end_date" and datediff($"month_contract_end_date",$"effective_job_change_date")>=0, 
                                                                                            datediff($"month_contract_end_date",$"effective_job_change_date")+1)   
                                                                                      .otherwise(datediff($"month_contract_end_date",$"month_contract_start_date")+1))
                                                .withColumn("rank",rank() over bycontract_job_change)
                                                .withColumn("new_rank",when($"rank" > 1 and date_format($"effective_job_change_date_previous","yyyyMM") === lit(month_id) and $"effective_job_change_date_previous">$"month_contract_start_date" ,"1").otherwise($"rank"))
                                                
                                                .filter(col("new_rank")==="1")
                                                .distinct
                                                .withColumn("position_start_date", when($"position_start_date" > $"effective_job_change_date",$"effective_job_change_date").otherwise($"position_start_date"))
                                                .withColumn("continous_service_date", when($"continous_service_date" > $"contract_start_date",$"contract_start_date").otherwise($"continous_service_date"))
df_contract_read_job_change.createOrReplaceTempView("vw_contract_job_change")

// COMMAND ----------

// DBTITLE 1,Read absenteism data
val df_referential_absences_read = spark.table("hr.referential_absences").select("absence_code", "absence_label_code", "absence_type")
                                                      .withColumn("code_abs", $"absence_code")                                                                                                                                     
                                                      .withColumn("type_abs",$"absence_type")
                                                      .distinct
df_referential_absences_read.createOrReplaceTempView("vw_referential_absences")

// absence rate
val df_absenteism_read = spark.table("hr.absenteism")
                        .filter("period_abs_month = '" + month_id + "'")
                        .filter($"type_absence".isNotNull)
                        .withColumn("calendardays",lit(calendardays))                                                                                                                        
                        .withColumn("opendays",lit(opendays))
                        .withColumn("employee_hra_old",$"employee_hra")
                        .withColumn("employee_hra", substring_index($"employee_hra", "_", 1))
                        .distinct

df_absenteism_read.createOrReplaceTempView("vw_absenteism")

val byabsence = Window.partitionBy("employee_hra","code","dateval_start_month") .orderBy($"curated_ingested_date".desc,$"date_raw_load_file".desc,$"version".desc)

val df_absenteism_consolidated_month_read  = spark.table("hr.absenteism_consolidated")
                                                  .filter("""date_format(dateval_start_prol_first,'yyyyMM') = '""" + month_id + """' or 
                                                             date_format(coalesce(dateval_end_prol_last, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                            (date_format(dateval_start_prol_first,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(dateval_end_prol_last, '2999-12-31'),'yyyyMM') >= '""" + month_id + """') or 
                                                            date_format(dateval_start,'yyyyMM') = '""" + month_id + """' or 
                                                             date_format(coalesce(dateval_end, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                            (date_format(dateval_start,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(dateval_end, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                        )
                                                 .withColumn("is_absence_month",when(date_format($"dateval_start","yyyyMM") === month_id ||
                                                                                     date_format($"dateval_end","yyyyMM") === month_id || 
                                                                                     (date_format($"dateval_start","yyyyMM") <= month_id && date_format($"dateval_end","yyyyMM") >= month_id),lit(1)).otherwise(lit(0)))
                                                 .withColumn("dateval_start_month",when($"dateval_start" < date_start_month,date_start_month).otherwise($"dateval_start"))
                                                 .withColumn("dateval_end_month",when($"dateval_end" > date_end_month,date_end_month).otherwise($"dateval_end"))
                                                 .withColumn("calendardays",lit(calendardays))
                                                 .withColumn("opendays",lit(opendays))
                                                 .distinct
                                                 .withColumn("rank_last",rank() over byabsence)
                                                 .filter(col("rank_last")==="1") 
                                      
df_absenteism_consolidated_month_read.createOrReplaceTempView("vw_absenteism_consolidated_month")



// COMMAND ----------

val df_absenteism_consolidated = spark.sql("""
                                              select  
                                                     a.employee_hra, 
                                                     sum(case when cjc.employee_code is not null then b.duration_days end) as duration_days_month, 
                                                     sum(case when cjc.employee_code is not null then b.duration_hours end) as duration_hours_month, 
                                                     sum(case when cjc.employee_code is not null and b.duration_days = 0 then b.duration_hours/7
                                                              when cjc.employee_code is not null and b.duration_days > 0 then b.duration_days end ) as duration_days_total,
                                                     a.duration_days,
                                                     a.duration_hours,
                                                     a.dateval_start, 
                                                     a.dateval_end,
                                                     a.dateval_start_prol,
                                                     a.dateval_end_prol,
                                                     a.dateval_start_prol_first,
                                                     a.dateval_end_prol_last,
                                                     a.h_start,
                                                     a.h_end,
                                                     a.code,
                                                     a.id_absence,
                                                     a.id_absence_2,
                                                     a.h_code,
                                                     a.dates_code,
                                                     a.dateval_start_month,
                                                     a.dateval_end_month,
                                                     a.calendardays,
                                                     a.opendays,
                                                     a.is_absence_month

                                              from   vw_absenteism_consolidated_month a 
                                                     left join vw_absenteism b on a.employee_hra = b.employee_hra 
                                                                              and a.code = b.code 
                                                                              
                                                                              and b.dateval between a.dateval_start and a.dateval_end
                                                     left join vw_contract c on c.france_payroll_id = a.employee_hra
                                                                            and b.dateval between c.month_contract_start_date and c.month_contract_end_date
                                                                            
                                                     left  join vw_contract_job_change cjc on cjc.employee_code = c.employee_code
                                                                                          and cjc.contract_start_date = c.contract_start_date
                                                                                          and b.dateval between case when c.month_contract_start_date < cjc.effective_job_change_date then cjc.effective_job_change_date else c.month_contract_start_date end  and
                                                                                                                case when c.month_contract_end_date < cjc.effective_job_change_date_end then c.month_contract_end_date else cjc.effective_job_change_date_end end

                                              where  1=1

                                              group by a.employee_hra, 
                                                       a.duration_days,
                                                       a.duration_hours,
                                                       a.dateval_start, 
                                                       a.dateval_end,
                                                       a.dateval_start_prol,
                                                       a.dateval_end_prol,
                                                       a.dateval_start_prol_first,
                                                       a.dateval_end_prol_last,
                                                       a.h_start,
                                                       a.h_end,
                                                       a.code,
                                                       a.id_absence,
                                                       a.id_absence_2,
                                                       a.h_code,
                                                       a.dates_code,
                                                       a.dateval_start_month,
                                                       a.dateval_end_month,
                                                       a.calendardays,
                                                       a.opendays,
                                                       a.is_absence_month

""")

df_absenteism_consolidated.createOrReplaceTempView("vw_absenteism_consolidated")


// COMMAND ----------

// DBTITLE 1,Nb Productive Days
val employee_productivedays_workingdays = spark.sql( """
  select   
         c.employee_code
        ,c.employee_id
        ,c.france_payroll_id
        ,c.contract_start_date
        ,cjc.fte
        ,sum(case when cjc.employee_code is not null and b.duration_days = 0 then b.duration_hours/7
                  when cjc.employee_code is not null and b.duration_days > 0 then b.duration_days end ) as  abs_days
        ,avg(a.opendays) opendays
        ,sum(case when cjc.employee_code is not null and b.duration_days = 0 then b.duration_hours/7
                  when cjc.employee_code is not null and b.duration_days > 0 then b.duration_days end ) /avg(a.calendardays)  as abs_rate
        ,cjc.contract_days_job_change
        ,a.code
        ,a.dateval_start as dateval_start
    
  from   vw_absenteism_consolidated_month a 
         inner join vw_absenteism b on a.employee_hra = b.employee_hra 
                                   and a.code = b.code 
                                   and b.dateval between a.dateval_start and a.dateval_end
         inner join vw_contract c on c.france_payroll_id = a.employee_hra
                                 and b.dateval between c.month_contract_start_date and c.month_contract_end_date
         inner  join vw_contract_job_change cjc on cjc.employee_code = c.employee_code
                                               and cjc.contract_start_date = c.contract_start_date
                                               and b.dateval between case when c.month_contract_start_date < cjc.effective_job_change_date then cjc.effective_job_change_date else c.month_contract_start_date end  and
                                                                     case when c.month_contract_end_date < cjc.effective_job_change_date_end then c.month_contract_end_date else cjc.effective_job_change_date_end end
        
  where 1=1
    
  
  group by
      c.employee_code
    ,c.employee_id
    ,c.france_payroll_id
    ,c.contract_start_date
    ,cjc.fte
    ,cjc.contract_days_job_change
    ,a.code
    ,a.dateval_start

  order by c.employee_code,c.contract_start_date
         """)
employee_productivedays_workingdays.createOrReplaceTempView("vw_employee_productivedays_working")

// COMMAND ----------

// DBTITLE 1,Nb Workings days and ETP By Employee, Contract and FTE
spark.sql("""

  select distinct
         c.employee_code
        ,c.employee_id
        ,c.france_payroll_id
        ,c.contract_start_date
       ,case when lower(ct.contract_type_detailed) != 'interim' then cjc.fte else null end as worker_rate
       ,cjc.contract_days_job_change as workingdays_fte
       ,ifnull(wrk.abs_rate,0) abs_rate
       ,cjc.contract_days_job_change
       ,cjc.contract_days_job_change/ """+calendardays+""" as wrk_rate
       ,cjc.contract_days_job_change/ """+calendardays+""" - (ifnull(wrk.abs_rate,0)) as prd_rate
       ,wrk.abs_days*(wrk.fte/100) as abs_days_etp
       ,wrk.code
       ,wrk.dateval_start
       
  from vw_contract c
  inner join vw_contract_job_change cjc on c.employee_code = cjc.employee_code and c.contract_start_date = cjc.contract_start_date

  left join vw_employee_productivedays_working wrk
  on wrk.employee_code = c.employee_code and c.contract_start_date = wrk.contract_start_date and cjc.fte = wrk.fte and cjc.contract_days_job_change = wrk.contract_days_job_change
  
  left join vw_d_contract_type ct on c.contract_code = ct.contract_type_code

                               """).createOrReplaceTempView("vw_employee_workingdays_fte")

// COMMAND ----------

// DBTITLE 1,Nb Workings days, etp contractuel and productive By Employee and contracts
spark.sql("""

  select distinct

        c.employee_code
       ,c.employee_id
       ,c.france_payroll_id
       ,c.contract_start_date
       ,c.code
       ,c.dateval_start
       ,sum(workingdays_fte)  as workingdays
       ,sum(wrk_rate*worker_rate) as etp_contractuel
       ,sum(prd_rate*worker_rate) as etp_productive
       ,sum(abs_rate*worker_rate) as etp_absent
       ,sum(abs_days_etp) as abs_days_etp
       
  from vw_employee_workingdays_fte c
  
  group by c.employee_code
       ,c.employee_id
       ,c.france_payroll_id
       ,c.contract_start_date
       ,c.code
       ,c.dateval_start

                               """).createOrReplaceTempView("vw_employee_workingdays")

// COMMAND ----------

// DBTITLE 1,Nb Workings days, etp contractuel and productive By Employee
spark.sql("""select  c.employee_code 
                    ,c.employee_id
                    ,c.france_payroll_id     
                    ,c.code
                    ,c.dateval_start
                    ,sum(workingdays_fte)  as workingdays_month  
                    ,sum(wrk_rate*worker_rate) as etp_contractuel_base_month
                    ,sum(prd_rate*worker_rate) as etp_productive_base_month
                    ,sum(abs_rate*worker_rate) as etp_absent_month
                    ,sum(abs_days_etp) as abs_days_etp_month
              from vw_employee_workingdays_fte c
                   
              group by c.employee_code
                      ,c.employee_id
                      ,c.france_payroll_id
                      ,c.code
                      ,c.dateval_start
                               """).createOrReplaceTempView("vw_employee_workingdays_month")

// COMMAND ----------

// DBTITLE 1,Get Nb Absences Month
spark.sql(""" select distinct 
                     count(distinct ab.id_absence) as nb_absences
                    ,count(distinct case when m.flag_prolongation = 1 then ab.id_absence end) as nb_absences_prolong 
                    ,ab.employee_hra
                                     
               from vw_absenteism_consolidated ab   
                    inner join vw_d_motif m on m.absence_code = ab.code and m.flag_ref = 1   
                
               group by  ab.employee_hra
    """).createOrReplaceTempView("vw_nb_absence_month")

// COMMAND ----------

// DBTITLE 1,Get Distinct Id Absence in Month
spark.sql("""
              select ab.employee_hra,
                     ab.id_absence,
                     coalesce(sum(case when m.flag_prolongation = 1 then duration_days_total end),0) as absence_duration_month_prolong
               
              from  vw_absenteism_consolidated ab   
                    inner join vw_d_motif m on m.absence_code = ab.code and m.flag_ref = 1  
                     
              group by ab.employee_hra,
                       ab.id_absence
                       
        """).createOrReplaceTempView("vw_id_absence")

// COMMAND ----------

// DBTITLE 1,Get Total Absence for each id absence in month
spark.sql(""" select distinct 
                     coalesce(sum(case when (m.flag_prolongation is null or m.flag_prolongation = 0) and (abt.duration_days = 0 or abt.duration_days is null) then coalesce(abt.duration_hours,0)/7 
                                       when (m.flag_prolongation is null or m.flag_prolongation = 0) and abt.duration_days > 0 then coalesce(abt.duration_days, 0) end),0) as absence_duration
                    ,coalesce(sum(case when m.flag_prolongation = 1 then coalesce(abt.duration_days,0) end),0) as absence_duration_prolong   
                    ,last(ab.absence_duration_month_prolong) as absence_duration_month_prolong                 
                    ,abt.employee_hra
                    ,abt.id_absence
                    ,abt.code
                    ,min(coalesce(m.flag_prolongation,0)) as flag_prolongation
                    ,coalesce(sum(case when (m.flag_prolongation is null or m.flag_prolongation = 0) and (abt.duration_days = 0 or abt.duration_days is null) then coalesce(abt.duration_hours,0)/7 
                                       when (m.flag_prolongation is null or m.flag_prolongation = 0) and abt.duration_days > 0 then coalesce(abt.duration_days, 0) end),
                                       coalesce(sum(case when m.flag_prolongation = 1 then coalesce(abt.duration_days,0) end),0)) as absence_duration_range
                                       
                    , coalesce(sum(case when (m.flag_prolongation is null or m.flag_prolongation = 0) and (abt.duration_days = 0 or abt.duration_days is null) then coalesce(abt.duration_hours,0)/7 
                                       when (m.flag_prolongation is null or m.flag_prolongation = 0) and abt.duration_days > 0 then coalesce(abt.duration_days, 0) end),0) + coalesce(sum(case when m.flag_prolongation = 1 then coalesce(abt.duration_days,0) end),0) as absence_duration_range_prolong_old
           
                  
                            
                                     
               from vw_absenteism_consolidated_month abt                                                                        
                    inner join vw_d_motif m on m.absence_code = abt.code and m.flag_ref = 1  
                    inner join vw_id_absence ab on ab.employee_hra = abt.employee_hra
                                               and ab.id_absence = abt.id_absence 
                
              group by  abt.employee_hra
                        ,abt.id_absence
                        ,abt.code
    """).filter($"absence_duration_range">0)
        .withColumn("absence_duration_range_prolong",sum($"absence_duration_range").over(Window.partitionBy($"id_absence",$"employee_hra").orderBy($"id_absence")))
        .withColumn("flag_prolong_init",min($"flag_prolongation").over(Window.partitionBy($"id_absence",$"employee_hra").orderBy($"id_absence")))
        .createOrReplaceTempView("vw_nb_absence_duration_prol_month")

// COMMAND ----------

// DBTITLE 1,Query Absenteism
val query_absence = """ select distinct 
                                case when c.rank=1 then ab.duration_days_total else null end as duration_days 
                                
                               ,case when coalesce(m.flag_prolongation,0) = nadpm.flag_prolongation and nadpm.absence_duration_prolong > 0 
                                      and c.rank = 1 then nadpm.absence_duration_prolong else null end as duration_days_prolong
                               
                               ,case when coalesce(m.flag_prolongation,0) = nadpm.flag_prolong_init  
                                      and c.rank = 1 then nadpm.absence_duration_month_prolong + coalesce(ab.duration_days_total,0) else null end  as duration_days_prolong_month
                                                                         
                              ,case when lower(ct.contract_type_detailed) != 'interim' and c.rank=1
                                    then wdm.etp_contractuel_base_month else null end as absence_etp_contractuel                            
                             
                              ,""" + calendardays + """ as calendardays 

                              ,case when ab.dateval_start <= to_date('""" + date_end_month + """')
                                    and ab.dateval_end >= to_date('""" + date_start_month + """') 
                                    and c.rank = 1 then 1 else null end as number_absences
                              
                              ,case when c.rank=1 then wdm.abs_days_etp_month  end  as nb_days_absence_etp                               
                              
                              ,case when c.rank=1 then wdm.etp_absent_month end as etp_absent
                              
                              ,case when nam.nb_absences>1  
                                     and c.rank=1
                                     and m.flag_prolongation is null then 1 else null end as absent_more_than_once
                               
                              ,case when ab.code in ('CAE','MATP') 
                                     and c.rank=1
                                     and date_format(ab.dateval_end, 'yyyyMM') = """  + month_id + """ then 1
                                    when ab.code in ('MAT') 
                                     and c.rank=1
                                     and date_format(ab.dateval_end, 'yyyyMM') = """  + month_id + """ 
                                     and (ab.dateval_start_prol is null or  (ab.dateval_start_prol is not null
                                                                             and date_format(ab.dateval_start_prol, 'yyyyMM') <> """  + month_id + """ 
                                                                             and date_format(ab.dateval_start_prol, 'yyyyMM') <> """  + month_next_id + """)) then 1 else null end as number_of_maternity_leave_returns_cae

                               ,case when ab.dateval_start <= to_date('""" + date_end_month + """')
                                     and ab.dateval_end >= to_date('""" + date_start_month + """')
                                     and c.rank = 1
                                     and m.flag_prolongation = 1 then 1 else null end as prolongation_absence 
                                     
                                   
                               ,coalesce(ai.id_absence_id, -1) as absence_id
                               ,coalesce(d.employee_id, -1) as employee_id
                               ,coalesce(ct.contract_type_id, -1) as contract_type_id
                               ,coalesce(wr.worker_rate_id, -1) as worker_rate_id                           
                               ,case when upper(c.contract_type) = 'VA'  or  lower(ct.contract_type_detailed) = 'vacataire'  then """ + vacataire_csp_id + """  else coalesce(csp.csp_id, -1) end as csp_id
                               ,coalesce(nat.nationality_id, -1) as nationality_id
                               ,coalesce(ag.range_age_id, -1) as range_age_id
                               ,coalesce(sec.seniority_company_id,-1) as seniority_company_id
                               ,coalesce(sep.seniority_position_id, -1) as seniority_position_id
                               ,coalesce(loc.location_id, -1) as location_id
                               ,coalesce(job.job_architecture_id, -1) as job_architecture_id
                               ,coalesce(man.manager_id, -1) as manager_id
                               ,coalesce(so.supervisory_organization_id, -1) as supervisory_organization_id
                               ,coalesce(ol.legal_organization_id,'-1') as legal_organization_id
                               ,coalesce(op.operational_organization_id,'-1') as operational_organization_id
                               ,coalesce(id.info_dates_id, -1) as info_dates_id   
                               ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
                               ,coalesce(abi.absence_info_dates_id, -1) as absence_info_dates_id                     
                               ,coalesce(fa.absence_frequency_id,-1) as absence_frequency_id 
                               ,coalesce(m.motif_id, -1) as motif_id                             
                               ,coalesce(rad.range_absence_duration_id, -1) as range_absence_duration_merge_id 
                               ,coalesce(absh.absence_info_hours_id,-1) as absence_info_hours_id
                               ,""" + date_id + """ as date_id
                               ,current_timestamp() as recordcreationdate
                               ,'""" + runid + """' as runid

                          from vw_absenteism_consolidated ab   
                               inner join vw_d_motif m on m.absence_code = ab.code and m.flag_ref = 1   
                               inner join vw_employee e on e.france_payroll_id = ab.employee_hra
                               inner join vw_contract c on c.france_payroll_id = ab.employee_hra
                                
                               left join vw_d_employee d on e.employee_code = d.employee_code         
                               left join vw_d_nationality nat on e.nationality_code = nat.nationality_code
                               left join vw_d_location loc on e.location_code = loc.location_code
                               left join vw_d_manager man on e.manager_code = man.manager_code
                               left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code  
                               left join vw_d_legal_organization ol on e.legal_organization_code = ol.legal_organization_code
                               left join vw_d_operational_organization op on e.operational_organization_code = op.operational_organization_code 
                               left join vw_d_hierarchy_pb  hi_pb on e.cost_center_code = hi_pb.cost_center_code 
                               left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date('""" + date_id + """','yyyyMMdd'),to_date(e.birth_date),true)/12) end) 

                               left join vw_contract_job_change ccc on ccc.employee_code = c.employee_code 
                                                                and c.contract_start_date = ccc.contract_start_date 
                                                                and ccc.rank=1   
                                                                
                              left join vw_d_worker_rate wr on ccc.worker_rate_code = wr.worker_rate_code                                             
                              left join vw_d_csp csp on ccc.csp_code = csp.csp_code                       
                              
                              left join vw_d_contract_type ct on c.contract_type_code = ct.contract_type_code
                                                             and ccc.collective_agreement_code = ct.collective_agreement_code
                                                           
                              left join vw_d_job_architecture job on ccc.job_title_code = job.job_title_code    
                                                                 and coalesce(ccc.grade_code, -1) = coalesce(job.grade_code, -1)
                                                                 
                              left join vw_d_info_dates id on id.company_dates_code = ccc.company_dates_code 
                                                          and id.contract_dates_code = c.contract_dates_code
                                                         
                               left join vw_contract_last cl on c.employee_code = cl.employee_code
                               left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(ccc.continous_service_date) then null else datediff(to_date(cl.seniority_date_max),to_date(ccc.continous_service_date)) end)
                               left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(ccc.position_start_date) then null else datediff(to_date(cl.seniority_date_max),to_date(ccc.position_start_date)) end)
                               
                               left join vw_d_absence_info_dates abi on abi.absence_info_dates_code = ab.dates_code
                               left join vw_d_absence_hour absh on ab.h_code = absh.absence_info_hours_code
                               
                               left join vw_nb_absence_month nam on nam.employee_hra = ab.employee_hra                               
                               left join vw_d_absence_frequency fa on nam.nb_absences between fa.range_absence_frequency_min and fa.range_absence_frequency_max
                               
                               left join vw_d_absence_id ai on ai.id_absence = ab.id_absence                              
                                                                                                             
                               left join vw_nb_absence_duration_prol_month nadpm on nadpm.employee_hra = ab.employee_hra 
                                                                                and nadpm.id_absence = ab.id_absence
                                                                                and nadpm.code = ab.code
                                                                          
                               left join vw_range_absence_duration rad on ceil(nadpm.absence_duration_range) between rad.range_absence_duration_min and rad.range_absence_duration_max
                                                                        and ceil(nadpm.absence_duration_range_prolong) between rad.range_absence_duration_prol_min and rad.range_absence_duration_prol_max                                                                                                         
                                                                                                                                                     
                               left join vw_employee_workingdays_month wdm on e.employee_code = wdm.employee_code    
                                                                           and ab.code = wdm.code
                                                                           and ab.dateval_start = wdm.dateval_start
    """

// COMMAND ----------

// DBTITLE 1,Absence Results
val df_absence_results = spark.sql(query_absence)
df_absence_results.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Delete data from table f_absence for existing loading date
val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """Exec [dbo].[usp_deletePartitionTableData] 'f_absence','absence','myMonthlyRangePS',""" + date_id
val res = stmt.execute(query_delete)


// COMMAND ----------

// DBTITLE 1,Insert data into the absence table
df_absence_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "absence.f_absence", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Statistics about data read and inserted
val read_records = df_absenteism_consolidated_month_read.count().toInt //count the number of read records
val inserted_records = df_absence_results.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from Cache
df_absenteism_consolidated_month_read.unpersist
df_absence_results.unpersist

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)