// Databricks notebook source
// DBTITLE 1,Get Parameters values: load_date and runid
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val historical_data_end_date = dbutils.widgets.get("historical_data_end_date");
val limit_date_histo = dbutils.widgets.get("limit_date_histo");

// COMMAND ----------

// DBTITLE 1,Include functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set variables
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd")).plusMonths(-1)
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_start_month = LocalDate.parse(date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + "01",  DateTimeFormatter.ofPattern("yyyyMMdd"))
val date_id = date_end_month.toString.replace("-","")//date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + "01"

val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))

val year_id = date_value.getYear()
val last_year_id = date_value.getYear()-1
val last_month = date_end_month.plusMonths(-1).getYear() + ("%02d".format(date_end_month.plusMonths(-1).getMonth.getValue()))
val last_month_id = date_end_month.plusMonths(-1).toString.replace("-","") //date_value.plusMonths(-1).getYear() + ("%02d".format(date_value.plusMonths(-1).getMonth.getValue())) + "01"
val first_month_id = date_value.getYear() + "01"
val last_month_previous_year = (date_value.getYear() -1) + "12"
val december_previous_year = (date_value.getYear() -1) + "1231"
val march_month_id = date_value.getYear() + "03"

val date_next_month = date_end_month.plusDays(1)
val month_next_id = date_next_month.getYear() + ("%02d".format(date_next_month.getMonth.getValue()))
val date_end_last_month = date_start_month.plusDays(-1)
val date_start_last_month = date_start_month.plusMonths(-1)

val historical_date_end_date_value = LocalDate.parse(historical_data_end_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
//delta for pay increase
val delta_histo = if (historical_date_end_date_value.isAfter(date_value)) {1.0} else { 0}
//check to filter only on historical data
val is_histo = if (historical_date_end_date_value.isAfter(date_value)) {1} else { 0}

val limit_date_value = LocalDate.parse(limit_date_histo, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val filter_file_current_month = if (date_end_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}
val filter_file_previous_month = if (date_end_last_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}

// COMMAND ----------

// DBTITLE 1,Refresh delta table employee
 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table contract
 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table career
 if(spark.catalog.tableExists("hr.career")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.career")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// MAGIC %md ##1- Read Dimensions Data

// COMMAND ----------

// DBTITLE 1,Get Dimensions data
spark.read.jdbc(jdbcurl, "career.d_career_goal", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_career_goal")
spark.read.jdbc(jdbcurl, "career.d_career_mobility", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_career_mobility")
spark.read.jdbc(jdbcurl, "career.d_career_promotion", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_career_promotion")
spark.read.jdbc(jdbcurl, "career.d_career_review", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_career_review")
spark.read.jdbc(jdbcurl, "career.d_career_review_status", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_career_review_status")
spark.read.jdbc(jdbcurl, "career.d_career_campaign", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_career_campaign")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.d_date", connectionproperties).filter(col("month_id") === lit(month_id)).createOrReplaceTempView("vw_d_date")
spark.read.jdbc(jdbcurl, "staff.d_employee", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_employee")

val df_d_contract_type = spark.read.jdbc(jdbcurl, "staff.d_contract_type", connectionproperties).filter("current_version = 1")
df_d_contract_type.createOrReplaceTempView("vw_d_contract_type")

spark.read.jdbc(jdbcurl, "staff.d_worker_rate", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_worker_rate")
spark.read.jdbc(jdbcurl, "staff.d_csp", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_csp")
spark.read.jdbc(jdbcurl, "staff.d_nationality", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_nationality")
spark.read.jdbc(jdbcurl, "staff.d_range_age", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_range_age")
spark.read.jdbc(jdbcurl, "staff.d_seniority_company", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_company")
spark.read.jdbc(jdbcurl, "staff.d_hierarchy_pb", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_hierarchy_pb")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_seniority_position", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_position")
spark.read.jdbc(jdbcurl, "staff.d_location", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_location")
spark.read.jdbc(jdbcurl, "staff.d_job_architecture", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_job_architecture")
spark.read.jdbc(jdbcurl, "staff.d_manager", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_manager")
spark.read.jdbc(jdbcurl, "staff.d_supervisory_organization", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_supervisory_organization")
spark.read.jdbc(jdbcurl, "staff.d_legal_organization", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_legal_organization")
spark.read.jdbc(jdbcurl, "staff.d_operational_organization", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_operational_organization")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "mobility.d_mobility_in", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_mobility_in")
spark.read.jdbc(jdbcurl, "mobility.d_mobility_out", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_mobility_out")
spark.read.jdbc(jdbcurl, "staff.d_info_dates", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_info_dates")
spark.read.jdbc(jdbcurl, "mobility.d_in_out_dates", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_in_out_dates")

spark.read.jdbc(jdbcurl, "dbo.vw_ref_seniority_company", connectionproperties).createOrReplaceTempView("vw_ref_seniority_company")
spark.read.jdbc(jdbcurl, "dbo.vw_ref_transco", connectionproperties).createOrReplaceTempView("vw_ref_transco")

// COMMAND ----------

// DBTITLE 1,Get the default vacataire id and status review not started and not applicable
val vacataire_csp_id = spark.sql("""select distinct case when lower(professional_category_reference) = 'autre statut' then csp_id else -1 end as vacataire_csp_id from vw_d_csp order by vacataire_csp_id desc""").head().getInt(0)
val no_started_review_status_id = spark.sql("""select distinct case when lower(review_status) = 'not started' then review_status_id else -1 end as no_started_review_status_id from vw_d_career_review_status order by no_started_review_status_id desc""").head().getInt(0)
val no_applicable_review_status_id = spark.sql("""select distinct case when lower(review_status) = 'non applicable' then review_status_id else -1 end as no_applicable_review_status_id from vw_d_career_review_status order by no_applicable_review_status_id desc""").head().getInt(0)

// COMMAND ----------

// DBTITLE 1,Get the campaign start date and the campaign end date of the month, the campaign id associated to date
val campaign_start_date_cal = spark.sql("""select case when to_date(review_period_start_date) <= to_date('""" + date_end_month + """')
                                            and to_date(review_period_end_date) >= to_date('""" + date_end_month + """') then to_date(review_period_start_date) else to_date('1900-01-01') end as review_period_start_date
                               from vw_d_career_campaign 
                               order by review_period_start_date desc """).head().getDate(0)

val campaign_end_date_cal = spark.sql("""select case when to_date(review_period_start_date) <= to_date('""" + date_end_month + """')
                                            and to_date(review_period_end_date) >= to_date('""" + date_end_month + """') then last_day(add_months(to_date(review_period_end_date),1)) else to_date('2999-12-31') end as review_period_end_date
                               from vw_d_career_campaign 
                               order by review_period_end_date  asc""").head().getDate(0)

val campaign_start_date = if(campaign_start_date_cal.toString == "1900-01-01") {date_end_month.toString} else {campaign_start_date_cal.toString}
val campaign_end_date = if(campaign_end_date_cal.toString == "2999-12-31") {date_end_month.toString} else {campaign_end_date_cal.toString}

val campaign_id = spark.sql("""select case when to_date(review_period_start_date) = to_date('""" + campaign_start_date + """')
                                            and last_day(add_months(to_date(review_period_end_date),1)) = to_date('""" + campaign_end_date + """') then career_campaign_id else -1 end as career_campaign_id
                               from vw_d_career_campaign 
                               order by career_campaign_id desc""").head().getInt(0)
val campaign_type = spark.sql("""select case when to_date(review_period_start_date) = to_date('""" + campaign_start_date + """')
                                            and last_day(add_months(to_date(review_period_end_date),1)) = to_date('""" + campaign_end_date + """') then review_type else 'ZZ' end as career_review_type
                               from vw_d_career_campaign 
                               order by career_review_type asc""").head().getString(0)

val review_id = spark.sql("""select case when lower(trim(review_type_reference)) = lower(trim('""" + campaign_type + """'))
                                            and lower(trim(review_reference)) = 'nc' then review_id else -1 end as career_review_id
                               from vw_d_career_review 
                               order by career_review_id desc""").head().getInt(0)


// COMMAND ----------

// DBTITLE 1,Get Days Off
spark.read.jdbc(jdbcurl, "dbo.d_date", connectionproperties).filter($"business_day_fr".isNull)
                                                            .filter($"date" >= date_start_last_month && $"date"<= date_end_month)
                                                            .select("date")
                                                            .distinct
                                                            .createOrReplaceTempView("vw_days_off")

// COMMAND ----------

// MAGIC %md ##6- Read Career Data from Refined

// COMMAND ----------

// DBTITLE 1,Get Goals Information
val bygoal = Window.partitionBy("employee_id","france_payroll_id","goal_id").orderBy($"goal_due_date".desc, $"goal_completion_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bygoal_last = Window.partitionBy("employee_id","france_payroll_id").orderBy($"goal_due_date".desc, $"goal_completion_date".desc,$"goal_id",$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_career_read_goal = spark.table("hr.career").filter("""date_format(goal_due_date,'yyyy') = '""" + year_id + """'""")
                                                  .withColumn("rank",rank() over bygoal)
                                                  .filter(col("rank")==="1")
                                                  .withColumn("goal_order",rank() over bygoal_last)
                                                  .select(
                                                          "employee_id",
                                                          "france_payroll_id",
                                                          "employee_code",
                                                          "goal_id",
                                                          "goal_due_date", 
                                                          "goal_completion_date",
                                                          "career_goal_code",
                                                          "record_start_date",
                                                          "goal_order",
                                                          "date_raw_load_file"
                                                          )
                                                  .distinct
df_career_read_goal.createOrReplaceTempView("vw_career_goal")

// COMMAND ----------

// DBTITLE 1,Get the Mobility information current
val bymobility = Window.partitionBy("employee_id","france_payroll_id").orderBy($"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_career_read_mobility = spark.table("hr.career").filter("""date_raw_load_file <= '""" + date_end_month + """'""")
                                                      .filter($"relocation_long_term_area".isNotNull or $"relocation_long_term_willing".isNotNull or $"relocation_short_term_area".isNotNull or $"relocation_short_term_willing".isNotNull)
                                                      .withColumn("rank",rank() over bymobility)
                                                      .filter(col("rank")==="1")
                                                      .select(
                                                              "employee_id",
                                                              "france_payroll_id",
                                                              "employee_code",
                                                              "relocation_long_term_area",
                                                              "relocation_long_term_willing",
                                                              "relocation_short_term_area",
                                                              "relocation_short_term_willing",
                                                              "career_mobility_code"
                                                              )

                                                      .distinct
df_career_read_mobility.createOrReplaceTempView("vw_career_mobility")

// COMMAND ----------

// MAGIC %md ##2- Read Employee Data from Refined

// COMMAND ----------

val byemployee = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_organization_change_date".desc,$"effective_organization_hierarchy_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_employee_read = spark.table("hr.employee").filter("('" + date_end_month.toString + "' >= record_start_date or '" + date_end_month.toString + "' >= effective_organization_hierarchy_change_date) and '" + date_end_month.toString + "' <= coalesce(record_end_date, '2999-12-31')")
                                                 .withColumn("rank",rank() over byemployee)
                                                 .filter(col("rank")==="1")
                                                 .filter("company_id <> '0082'")  //Exclude Italian
                                                 .distinct
df_employee_read.createOrReplaceTempView("vw_employee")

// COMMAND ----------

// MAGIC %md ##3- Read Contract Data of loading Month from Refined

// COMMAND ----------

// DBTITLE 1,Get last version of contract valid in the month
val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_read = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                 .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'"""
                                                        )    
                                                
                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .withColumn("rank",rank() over bycontract)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("seniority_date_max",when($"contract_end_date" === "2999-12-31" or $"contract_end_date".isNull or $"contract_end_date" > lit(load_date), lit(load_date)).otherwise($"contract_end_date"))
                                                .withColumn("is_contract_month", when(date_format($"contract_start_date","yyyyMM") <= month_id  and 
                                                            date_format(coalesce($"contract_end_date", lit("2999-12-31")),"yyyyMM") >= month_id,1).otherwise(null))
                                                .filter(col("rank")==="1")
                                                .filter(col("is_contract_month")===1)
                                                .distinct
df_contract_read.createOrReplaceTempView("vw_contract")

// COMMAND ----------

// DBTITLE 1,Get all contracts valid in the month
val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract = Window.partitionBy("employee_id","france_payroll_id").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_contract_read_month = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                      .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """' """
                                                        ) 
                                                      .withColumn("rank_month",rank() over bycontract_month)
                                                      .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                      .withColumn("month_contract_start_date",when($"contract_start_date" < date_start_month,date_start_month).otherwise($"contract_start_date"))
                                                      .withColumn("month_contract_end_date",when($"contract_end_date" > date_end_month,date_end_month).when($"contract_end_date".isNull,date_end_month).otherwise($"contract_end_date"))
                                                      .withColumn("contract_days",datediff($"month_contract_end_date",$"month_contract_start_date")+1)
                                                      .filter(col("rank_month")==="1")
                                                      .filter("""date_format(contract_start_date,'yyyyMM') = '""" + month_id + """' or 
                                                                  date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                                  (date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                              )

                                                      .withColumn("rank",rank() over bycontract)
                                                      .withColumn("next_contract_start_date",lag($"contract_start_date", 1, null).over(bycontract) )
                                                      .withColumn("next_contract_end_date",lag($"contract_end_date", 1, null).over(bycontract) )
                                                      .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                      .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                                 && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                             .otherwise($"effective_job_change_date"))
                                                      .distinct
df_contract_read_month.createOrReplaceTempView("vw_contract_month")


// COMMAND ----------

// DBTITLE 1,Get the valid effective job change date and valid compensation change date in the month
val byJobChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date_valid".desc)
val byJobChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_compensation_change_date_valid".desc)
val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date","effective_job_change_date","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_effective_change_valid = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                          .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")                                                
                                                          .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                          .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                          .withColumn("effective_job_change_date_valid", when($"effective_job_change_date" > lit(date_end_month),null).otherwise($"effective_job_change_date"))
                                                          .withColumn("effective_job_change_date_valid_last", first($"effective_job_change_date").over(byJobChangeDateLast))
                                                          .withColumn("effective_job_change_date", when($"effective_job_change_date_valid".isNotNull,$"effective_job_change_date_valid")
                                                                                                  .when($"effective_job_change_date_valid_last".isNull, $"contract_start_date")
                                                                                                  .otherwise($"effective_job_change_date_valid_last"))         
                                                          .withColumn("effective_job_change_date_max", first($"effective_job_change_date").over(byJobChangeDateLastContract))

                                                          .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                          .withColumn("effective_compensation_change_date_valid", when($"effective_compensation_change_date" > lit(date_end_month),null).otherwise($"effective_compensation_change_date"))
                                                          .withColumn("effective_compensation_change_date_valid_last", first($"effective_compensation_change_date").over(byCompensationChangeDateLast))
                                                          .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date_valid".isNotNull,$"effective_compensation_change_date_valid")
                                                                                                           .when($"effective_compensation_change_date_valid_last".isNull, $"contract_start_date")
                                                                                                           .otherwise($"effective_compensation_change_date_valid_last"))       
                                                          .withColumn("effective_compensation_change_date_max",first($"effective_compensation_change_date").over(byCompensationChangeDateLastContract))     


                                                          .withColumn("rank_month",rank() over bycontract_month)
                                                          .filter(col("rank_month")==="1")  
                                                          .filter("""date_format(contract_start_date,'yyyyMM') = '""" + month_id + """' or 
                                                                      date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                                      (date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                                  )
                                                         .select("employee_code",
                                                                 "employee_id",
                                                                 "france_payroll_id",
                                                                 "contract_start_date",
                                                                 "contract_end_date",
                                                                 "contract_type",
                                                                 "contract_type_label",
                                                                 "effective_job_change_date",
                                                                 "effective_compensation_change_date",
                                                                 "effective_job_change_date_max",
                                                                 "effective_compensation_change_date_max").distinct


val bycontract_job_month = Window.partitionBy("employee_id","france_payroll_id","effective_job_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_job_change_date_read =spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                                          .filter("""contract_start_date <= '""" + date_end_month + """'""")  
                                                                          .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                                          .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                                          .withColumn("effective_job_change_date", when($"effective_job_change_date".isNotNull,$"effective_job_change_date").otherwise($"contract_start_date"))
                                                                          .filter("""effective_job_change_date <= '""" + date_end_month + """'""")   
                                                                          .withColumn("rank_month",rank() over bycontract_job_month)
                                                                          .filter(col("rank_month")==="1")  
                                                                          .distinct

val bycontract_compensation_month = Window.partitionBy("employee_id","france_payroll_id","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_compensation_change_date_read =spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                                                   .filter("""contract_start_date <= '""" + date_end_month + """'""")    
                                                                                   .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                                                   .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date".isNotNull,$"effective_compensation_change_date").otherwise($"contract_start_date"))                                         
                                                                                   .filter("""effective_compensation_change_date <= '""" + date_end_month + """'""")   
                                                                                   .withColumn("rank_month",rank() over bycontract_compensation_month)
                                                                                   .filter(col("rank_month")==="1")  
                                                                                   .distinct

val df_contract_join = df_effective_change_valid.as("e")
                                        .join(df_contract_effective_job_change_date_read.as("c"), $"e.employee_code" === $"c.employee_code" && $"e.effective_job_change_date_max" === $"c.effective_job_change_date", "left_outer")
                                        .join(df_contract_effective_compensation_change_date_read.as("o"), $"e.employee_code" === $"o.employee_code" && $"e.effective_compensation_change_date_max" === $"o.effective_compensation_change_date", "left_outer")
                                        .join(df_contract_read.as("d"), $"e.employee_code" === $"d.employee_code" && $"e.contract_start_date" === $"d.contract_start_date" 
                                                                                                                  && ($"e.effective_job_change_date_max" === $"d.effective_job_change_date" || $"e.effective_compensation_change_date_max" === $"d.effective_compensation_change_date"), "left_outer")
                                        .join(df_contract_read.as("r"), $"e.employee_code" === $"r.employee_code" && $"e.contract_start_date" === $"r.contract_start_date", "left_outer")
                                        .selectExpr(
                                                "e.employee_code"
                                               ,"e.employee_id"
                                               ,"e.france_payroll_id"
                                               ,"coalesce(r.contract_start_date, e.contract_start_date) as contract_start_date"
                                               ,"coalesce(r.contract_end_date, e.contract_end_date) as contract_end_date"
                                               ,"e.effective_job_change_date"
                                               ,"coalesce(c.collective_agreement_reference, d.collective_agreement_reference) as collective_agreement_reference"                                    
                                               ,"coalesce(c.collective_agreement_group, d.collective_agreement_group) as collective_agreement_group"
                                               ,"coalesce(c.collective_agreement_level, d.collective_agreement_level) as collective_agreement_level"
                                               ,"coalesce(c.continous_service_date, d.continous_service_date) as continous_service_date"
                                               ,"coalesce(c.position_start_date, d.position_start_date) as position_start_date"
                                               ,"coalesce(c.hire_date, d.hire_date) as hire_date"
                                               ,"coalesce(c.original_hire_date, d.original_hire_date) as original_hire_date"
                                               ,"coalesce(c.effective_hire_date, d.effective_hire_date) as effective_hire_date"
                                               ,"coalesce(c.fte, d.fte) as fte"
                                               ,"coalesce(c.worker_type, d.worker_type) as worker_type"
                                               ,"coalesce(c.paidfte, d.paidfte) as paidfte"
                                               ,"coalesce(c.bonus_target, d.bonus_target) as bonus_target"
                                               ,"coalesce(c.csp, d.csp) as csp"
                                               ,"coalesce(c.coefficient, d.coefficient) as coefficient"
                                               ,"coalesce(c.coefficient_label, d.coefficient_label) as coefficient_label"
                                               ,"coalesce(c.job_title, d.job_title) as job_title"
                                               ,"coalesce(o.total_base_pay, d.total_base_pay) as total_base_pay"
                                               ,"coalesce(o.grade, d.grade) as grade"
                                               ,"coalesce(o.effective_compensation_change_date, d.effective_compensation_change_date) as effective_compensation_change_date"
                                               ,"coalesce(c.job_code, d.job_code) as job_code"
                                               ,"coalesce(c.job_title_code, d.job_title_code) as job_title_code"
                                               ,"coalesce(o.grade_code, d.grade_code) as grade_code"
                                               ,"coalesce(c.csp_code, d.csp_code) as csp_code"
                                               ,"coalesce(c.worker_rate_code, d.worker_rate_code) as worker_rate_code"
                                               ,"coalesce(d.mobility_in_code, c.mobility_in_code) as mobility_in_code"
                                               ,"coalesce(d.mobility_out_code, c.mobility_out_code) as mobility_out_code"
                                               ,"coalesce(d.info_dates_code, c.info_dates_code) as info_dates_code"
                                               ,"coalesce(d.in_out_dates_code, c.in_out_dates_code) as in_out_dates_code"
                                               ,"coalesce(d.contract_dates_code, c.contract_dates_code) as contract_dates_code"                                               
                                               ,"coalesce(c.contract_code, d.contract_code) as contract_code"
                                               ,"coalesce(d.contract_type_code, c.contract_type_code) as contract_type_code"
                                               ,"coalesce(c.collective_agreement_code, d.collective_agreement_code) as collective_agreement_code"
                                               ,"coalesce(c.company_dates_code, d.company_dates_code) as company_dates_code"
                                               ,"coalesce(d.record_start_date, c.record_start_date) as record_start_date"
                                               ,"coalesce(d.date_raw_load_file, c.date_raw_load_file) as date_raw_load_file"
                                               ,"coalesce(d.record_modification_date, c.record_modification_date) as record_modification_date"
                                               ,"coalesce(d.record_creation_date, c.record_creation_date) as record_creation_date"
                                        )

                                          .distinct

df_contract_join.createOrReplaceTempView("vw_emp_contract") 


// COMMAND ----------

// DBTITLE 1,Get the last effective job change and the last compensation change date in the month
val bycontract_job_change = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc,$"effective_job_change_date".desc,$"effective_compensation_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_read_job_change = df_contract_join.withColumn("rank",rank() over bycontract_job_change)                                                
                                                 .filter(col("rank")==="1")
                                                 .distinct
                                                 .withColumn("position_start_date", when($"position_start_date" > $"effective_job_change_date",$"effective_job_change_date").otherwise($"position_start_date"))
                                                 .withColumn("continous_service_date", when($"continous_service_date" > $"contract_start_date",$"contract_start_date").otherwise($"continous_service_date"))

df_contract_read_job_change.createOrReplaceTempView("vw_contract_job_change")

// COMMAND ----------

// MAGIC %md ##4- Read Contract Data of previous Month from Refined

// COMMAND ----------

// DBTITLE 1,Get the last contract of previous month
val bycontract_last_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract_last = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_previous_read = spark.table("hr.contract").filter($"filename" like filter_file_previous_month)
                                                          .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + last_month + """'""")    
                                                          .withColumn("rank_month",rank() over bycontract_last_month)
                                                          .withColumn("rank",rank() over bycontract_last)
                                                          .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                          .withColumn("seniority_date_max",when($"contract_end_date" === "2999-12-31" or $"contract_end_date".isNull or $"contract_end_date" > lit(load_date), lit(load_date)).otherwise($"contract_end_date"))
                                                          .withColumn("is_contract_month", when(date_format($"contract_start_date","yyyyMM") <= last_month  and 
                                                                      date_format(coalesce($"contract_end_date", lit("2999-12-31")),"yyyyMM") >= last_month,1).otherwise(null))
                                                          .filter(col("rank")==="1")
                                                          .filter(col("is_contract_month")===1)
                                                          .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                          .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                                     && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                                 .otherwise($"effective_job_change_date"))
                                                          .distinct
df_contract_previous_read.createOrReplaceTempView("vw_contract_previous_month")

// COMMAND ----------

// DBTITLE 1,Get all contracts valid in the previous month
val bycontract_last_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract_previous = Window.partitionBy("employee_id","france_payroll_id").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_contract_read_last_month = spark.table("hr.contract").filter($"filename" like filter_file_previous_month)
                                                            .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + last_month + """' or 
                                                                       date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + last_month + """' """ ) 
                                                            
                                                            .withColumn("rank_month",rank() over bycontract_last_month)
                                                            .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                            .withColumn("month_contract_start_date",when($"contract_start_date" < date_start_month,date_start_month).otherwise($"contract_start_date"))
                                                            .withColumn("month_contract_end_date",when($"contract_end_date" > date_end_last_month,date_end_last_month).when($"contract_end_date".isNull,date_end_last_month).otherwise($"contract_end_date"))
                                                            .withColumn("contract_days",datediff($"month_contract_end_date",$"month_contract_start_date")+1)
                                                            .filter(col("rank_month")==="1")
                                                            .filter("""date_format(contract_start_date,'yyyyMM') = '""" + last_month + """' or 
                                                                        date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + last_month + """' or 
                                                                        (date_format(contract_start_date,'yyyyMM') <= '""" + last_month + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + last_month + """')"""
                                                                    )

                                                            .withColumn("rank",rank() over bycontract_previous)
                                                            .withColumn("next_contract_start_date",lag($"contract_start_date", 1, null).over(bycontract_previous) )
                                                            .withColumn("next_contract_end_date",lag($"contract_end_date", 1, null).over(bycontract_previous) )
                                                            .distinct
df_contract_read_last_month.createOrReplaceTempView("vw_contract_last_month")

// COMMAND ----------

// DBTITLE 1,Get the valid effective job change date and valid compensation change date in the month
val byJobChangeDateLastMonth = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLastMonth = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date_valid".desc)
val byJobChangeDateLastMonthContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLastMonthContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_compensation_change_date_valid".desc)
val bycontract_last_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date","effective_job_change_date","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_effective_change_valid_previous = spark.table("hr.contract").filter($"filename" like filter_file_previous_month)
                                                                  .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + last_month + """'""")                                                
                                                                  .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                                  .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < last_month && date_format($"effective_compensation_change_date","yyyyMM") < last_month
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                                  .withColumn("effective_job_change_date_valid", when($"effective_job_change_date" > lit(date_end_last_month),null).otherwise($"effective_job_change_date"))
                                                                  .withColumn("effective_job_change_date_valid_last", first($"effective_job_change_date").over(byJobChangeDateLastMonth))
                                                                  .withColumn("effective_job_change_date", when($"effective_job_change_date_valid".isNotNull,$"effective_job_change_date_valid")
                                                                                                          .when($"effective_job_change_date_valid_last".isNull, $"contract_start_date")
                                                                                                          .otherwise($"effective_job_change_date_valid_last")) 
                                                                  .withColumn("effective_job_change_date_max", first($"effective_job_change_date").over(byJobChangeDateLastMonthContract))        

                                                                  .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                                  .withColumn("effective_compensation_change_date_valid", when($"effective_compensation_change_date" > lit(date_end_last_month),null).otherwise($"effective_compensation_change_date"))
                                                                  .withColumn("effective_compensation_change_date_valid_last", first($"effective_compensation_change_date").over(byCompensationChangeDateLastMonth))
                                                                  .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date_valid".isNotNull,$"effective_compensation_change_date_valid")
                                                                                                                   .when($"effective_compensation_change_date_valid_last".isNull, $"contract_start_date")
                                                                                                                   .otherwise($"effective_compensation_change_date_valid_last"))            
                                                                  .withColumn("effective_compensation_change_date_max",first($"effective_compensation_change_date").over(byCompensationChangeDateLastMonthContract))


                                                                  .withColumn("rank_month",rank() over bycontract_last_month)
                                                                  .filter(col("rank_month")==="1")  
                                                                  .filter("""date_format(contract_start_date,'yyyyMM') = '""" + last_month + """' or 
                                                                              date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + last_month + """' or 
                                                                              (date_format(contract_start_date,'yyyyMM') <= '""" + last_month + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + last_month + """')"""
                                                                          )
                                                                 .select("employee_code",
                                                                         "employee_id",
                                                                         "france_payroll_id",
                                                                         "contract_start_date",
                                                                         "contract_end_date",
                                                                         "contract_type",
                                                                         "contract_type_label",
                                                                         "effective_job_change_date",
                                                                         "effective_compensation_change_date",
                                                                         "effective_job_change_date_max",
                                                                         "effective_compensation_change_date_max"
                                                                        ).distinct


val bycontract_job_last_month = Window.partitionBy("employee_id","france_payroll_id","effective_job_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_job_change_date_previous_read =spark.table("hr.contract").filter($"filename" like filter_file_previous_month)
                                                                                   .filter("""contract_start_date <= '""" + date_end_last_month + """'""")  
                                                                                   .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                                                   .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < last_month && date_format($"effective_compensation_change_date","yyyyMM") < last_month
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                                                          .otherwise($"effective_job_change_date"))
                                                                                   .withColumn("effective_job_change_date", when($"effective_job_change_date".isNotNull,$"effective_job_change_date").otherwise($"contract_start_date"))
                                                                                   .filter("""effective_job_change_date <= '""" + date_end_last_month + """'""")   
                                                                                   .withColumn("rank_month",rank() over bycontract_job_last_month)
                                                                                   .filter(col("rank_month")==="1")  
                                                                                   .distinct

val bycontract_compensation_last_month = Window.partitionBy("employee_id","france_payroll_id","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_compensation_change_date_previous_read =spark.table("hr.contract").filter($"filename" like filter_file_previous_month)
                                                                                           .filter("""contract_start_date <= '""" + date_end_last_month + """'""")    
                                                                                           .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                                                           .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date".isNotNull,$"effective_compensation_change_date").otherwise($"contract_start_date"))
                                                                                           .filter("""effective_compensation_change_date <= '""" + date_end_last_month + """'""")   
                                                                                           .withColumn("rank_month",rank() over bycontract_compensation_last_month)
                                                                                           .filter(col("rank_month")==="1")  
                                                                                           .distinct


val df_contract_join_previous = df_effective_change_valid_previous.as("e")
                                        .join(df_contract_effective_job_change_date_previous_read.as("c"), $"e.employee_code" === $"c.employee_code" && $"e.effective_job_change_date_max" === $"c.effective_job_change_date", "left_outer")
                                        .join(df_contract_effective_compensation_change_date_previous_read.as("o"), $"e.employee_code" === $"o.employee_code" && $"e.effective_compensation_change_date_max" === $"o.effective_compensation_change_date", "left_outer")
                                        .join(df_contract_read_last_month.as("d"), $"e.employee_code" === $"d.employee_code" && $"e.contract_start_date" === $"d.contract_start_date" 
                                                                                                                  && ($"e.effective_job_change_date_max" === $"d.effective_job_change_date" || $"e.effective_compensation_change_date_max" === $"d.effective_compensation_change_date"), "left_outer")
                                        .join(df_contract_read_last_month.as("r"), $"e.employee_code" === $"r.employee_code" && $"e.contract_start_date" === $"r.contract_start_date", "left_outer")
                                        .selectExpr(
                                                "e.employee_code"
                                               ,"e.employee_id"
                                               ,"e.france_payroll_id"
                                               ,"coalesce(r.contract_start_date, e.contract_start_date) as contract_start_date"
                                               ,"coalesce(r.contract_end_date, e.contract_end_date) as contract_end_date"
                                               ,"e.effective_job_change_date"
                                               ,"coalesce(c.collective_agreement_reference, d.collective_agreement_reference) as collective_agreement_reference"                                    
                                               ,"coalesce(c.collective_agreement_group, d.collective_agreement_group) as collective_agreement_group"
                                               ,"coalesce(c.collective_agreement_level, d.collective_agreement_level) as collective_agreement_level"
                                               ,"coalesce(c.continous_service_date, d.continous_service_date) as continous_service_date"
                                               ,"coalesce(c.position_start_date, d.position_start_date) as position_start_date"
                                               ,"coalesce(c.hire_date, d.hire_date) as hire_date"
                                               ,"coalesce(c.original_hire_date, d.original_hire_date) as original_hire_date"
                                               ,"coalesce(c.effective_hire_date, d.effective_hire_date) as effective_hire_date"
                                               ,"coalesce(c.fte, d.fte) as fte"
                                               ,"coalesce(c.worker_type, d.worker_type) as worker_type"
                                               ,"coalesce(c.paidfte, d.paidfte) as paidfte"
                                               ,"coalesce(c.bonus_target, d.bonus_target) as bonus_target"
                                               ,"coalesce(c.csp, d.csp) as csp"
                                               ,"coalesce(c.coefficient, d.coefficient) as coefficient"
                                               ,"coalesce(c.coefficient_label, d.coefficient_label) as coefficient_label"
                                               ,"coalesce(c.job_title, d.job_title) as job_title"
                                               ,"coalesce(o.total_base_pay, d.total_base_pay) as total_base_pay"
                                               ,"coalesce(o.grade, d.grade) as grade"
                                               ,"coalesce(o.effective_compensation_change_date, d.effective_compensation_change_date) as effective_compensation_change_date"
                                               ,"coalesce(c.job_code, d.job_code) as job_code"
                                               ,"coalesce(c.job_title_code, d.job_title_code) as job_title_code"
                                               ,"coalesce(o.grade_code, d.grade_code) as grade_code"
                                               ,"coalesce(c.csp_code, d.csp_code) as csp_code"
                                               ,"coalesce(c.worker_rate_code, d.worker_rate_code) as worker_rate_code"
                                               ,"coalesce(d.mobility_in_code, c.mobility_in_code) as mobility_in_code"
                                               ,"coalesce(d.mobility_out_code, c.mobility_out_code) as mobility_out_code"
                                               ,"coalesce(d.info_dates_code, c.info_dates_code) as info_dates_code"
                                               ,"coalesce(d.in_out_dates_code, c.in_out_dates_code) as in_out_dates_code"
                                               ,"coalesce(d.contract_dates_code, c.contract_dates_code) as contract_dates_code"                                               
                                               ,"coalesce(c.contract_code, d.contract_code) as contract_code"
                                               ,"coalesce(d.contract_type_code, c.contract_type_code) as contract_type_code"
                                               ,"coalesce(c.collective_agreement_code, d.collective_agreement_code) as collective_agreement_code"
                                               ,"coalesce(c.company_dates_code, d.company_dates_code) as company_dates_code"
                                               ,"coalesce(d.record_start_date, c.record_start_date) as record_start_date"
                                               ,"coalesce(d.date_raw_load_file, c.date_raw_load_file) as date_raw_load_file"
                                               ,"coalesce(d.record_modification_date, c.record_modification_date) as record_modification_date"
                                               ,"coalesce(d.record_creation_date, c.record_creation_date) as record_creation_date"
                                        )

                                          .distinct

df_contract_join_previous.createOrReplaceTempView("vw_emp_contract_previous") 

// COMMAND ----------

// DBTITLE 1,Get the last effective job change and the last compensation change date in the previous month
val bycontract_job_change_previous = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc,$"effective_job_change_date".desc,$"effective_compensation_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_read_previous_month = df_contract_join_previous.withColumn("rank",rank() over bycontract_job_change_previous)                                                
                                                 .filter(col("rank")==="1")
                                                 .distinct
                                                .withColumn("position_start_date", when($"position_start_date" > $"effective_job_change_date",$"effective_job_change_date").otherwise($"position_start_date"))
                                                .withColumn("continous_service_date", when($"continous_service_date" > $"contract_start_date",$"contract_start_date").otherwise($"continous_service_date"))

df_contract_read_previous_month.createOrReplaceTempView("vw_contract_job_change_previous")

// COMMAND ----------

// MAGIC %md ##5- Read Contract Data of Current Campaing from Refined

// COMMAND ----------

/*

review_reference > Dernière retrospective réalisée. Ecrasée par la dernière valeur existante
review_initiated_date > date d’init pour la review_reference nommée dans le fichier
review_end_date > Liée à la campagne de fin d’année même si la review_reference n’est pas fin d’année
review_period_start_date >  Lié à la campagne review reference
review_period_end_date > Idem
Review status > Lié à la dernière campagne de fin d’année s’il y en a une
my_review_end_date> Lié à la dernière campagne de mi année s’il y en a une
my_review_status > Idem


Cycle de vie des Statuts :
1) Les statuts sont affectés aux 3 KPIs : NOMBRE D'ENTRETIEN, SALARIES AYANT BENEFICE D'UN ENTRETIEN et PROGRESSION DES ENTRETIENS. 
2) Ces statuts sont affectés par CAMPAGNE
3) A l'ouverture de la CAMPAGNE, on prend tous les contrats actifs (DATE DEBUT CONTRAT <DATE DEBUT CAMPAGNE et DATE FIN CONTRAT >= DATE DEBUT CAMPAGNE)
4) Ces entretiens prennent le statut "Non Démarré" au démarrage de la campagne tant que pas de statut envoyé par WD (démarrage de la campagne = 1er entretien envoyé par WD)
5) Ensuite, à chaque fin de mois durant la CAMPAGNE (+1 mois), on vérifie DATE DEBUT ENTRETIEN et DATE FIN ENTRETIEN. Si DATE DEBUT ENTRETIEN durant le mois et DATE DE FIN ENTRETIEN est vide ou > au mois, alors "En cours", sinon si DATE FIN ENTRETIEN durant le mois alors "Terminé". [Pour le premier chargement End Year 2021]
5bis) En mode courant : on prend en fin de mois le statut envoyé par WD
6) Au Mois M+1 de la fin de la CAMPAGNE, tous les ENTRETIENS aux Statuts autre que "Terminés", deviennent "Annulés" dans WD. [Pas d'action DI même si le process n'est pas terminé]
7) Tout contrat pour lequel le NOMBRE DE SORTIES = 1 apparait dans le mois durant la campagne, se voit affecté la position "Non Applicable" si le statut est <> de "Terminé", sinon il conserve son statut. 
8) Tout contrat pour lequel la DATE DE DEBUT DE CONTRAT apparait durant la campagne, n'est jamais pris en considération
9) 2 conclusions : Il ne peut donc jamais ya voir de "NC" et la somme du NOMBRE D'ENTRETIEN (sur tous les statuts) doit rester identique sur toute une CAMPAGNE
10) 1 statut par mois

*/

// COMMAND ----------

// DBTITLE 1,Build Reviews to calculate
val df_all_reviews = spark.table("hr.career").filter($"review_reference".isNotNull)
                      .withColumn("review_type",when(lower($"review_reference").contains("year end"),"Year End")
                                                                         .when(lower($"review_reference").contains("mid-year"),"Mid-Year"))
                      .withColumn("review_year",year($"review_period_start_date"))
                      .select(
                          "review_type"
                          ,"review_year"
                          ,"review_period_start_date"
                          ,"review_period_end_date"
                          ,"career_campaign_code"
                      ).distinct
                      .withColumn("review_limit_date",last_day(add_months($"review_period_end_date",1)))
                      .filter($"review_limit_date" >= date_end_month && $"review_period_start_date" <= date_end_month)

df_all_reviews.createOrReplaceTempView("vw_all_reviews")


// COMMAND ----------

// DBTITLE 1,All Employee Contract
val by_orgdate = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"cost_center_start_date")

val df_employee_read_review = spark.table("hr.employee").filter($"filename" like filter_file_current_month)
                            .distinct
                            .withColumn("cost_center_start_date", $"effective_organization_change_date")
                            .filter(col("record_start_date") <= lit(date_end_last_month))
                            .withColumn("cost_center_end_date",date_sub(lead($"cost_center_start_date",1) over by_orgdate,1))
                            .withColumn("cost_center_end_date",coalesce($"cost_center_end_date",to_date(lit("2999-12-31"))))
df_employee_read_review.createOrReplaceTempView("vw_review_employee")

// Retrieve employee's organization and rebuild dates based on effective_organization_change_date and rebuild end date
val byorg_version = Window.partitionBy("employee_code","employee_id","france_payroll_id","cost_center_start_date").orderBy($"record_start_date".desc,$"record_end_date".desc)
val byorg_order = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"cost_center_start_date")

val df_employeehr_ope_org = spark.table("hr.employee").filter($"filename" like filter_file_current_month)
.withColumn("cost_center_start_date", $"effective_organization_change_date")
.withColumn("rank",rank() over byorg_version).filter($"rank" === 1).drop("rank").filter("company_id <> '0082'")// exlude Italy
.select("employee_code","employee_id","france_payroll_id","cost_center_code","cost_center_start_date","legal_organization_code","operational_organization_code"
                   
                    ,"record_start_date"
                    ,"record_end_date"
       ).filter($"cost_center_code".isNotNull)
.withColumn("previous_cc",lag($"cost_center_code",1) over byorg_order)
.withColumn("previous_lo",lag($"legal_organization_code",1) over byorg_order)
.withColumn("previous_oo",lag($"operational_organization_code",1) over byorg_order)
.filter(($"previous_cc" =!= $"cost_center_code" or $"previous_cc".isNull) || ($"previous_lo" =!= $"legal_organization_code" or $"previous_lo".isNull)  || ($"previous_oo" =!= $"operational_organization_code" or $"previous_oo".isNull))
.drop($"previous_cc")
.drop($"previous_lo")
.drop($"previous_oo")
.withColumn("cost_center_end_date",date_sub(lead($"cost_center_start_date",1) over by_orgdate,1))
.withColumn("cost_center_end_date",coalesce($"cost_center_end_date",to_date(lit("2999-12-31"))))
.orderBy(asc("employee_code"),asc("record_start_date"))
df_employeehr_ope_org.createOrReplaceTempView("vw_organization")

// last version of each contract without retroactivity
val bycontract_start = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract_order = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"contract_start_date")
  val df_contractstart_read = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                .withColumn("rank_start",rank() over bycontract_start)
                                                .withColumn("contract_end_date",when($"contract_end_date".isNull,to_date(lit("2999-12-31"))).otherwise($"contract_end_date"))
                                                .withColumn("contract_start_date_month",when($"contract_end_date"<last_day($"contract_start_date") and $"contract_end_date".isNotNull,$"contract_end_date").otherwise(last_day($"contract_start_date")))
                                                .withColumn("seniority_date_max",when($"contract_end_date" === "2999-12-31" or $"contract_end_date".isNull or $"contract_end_date" > lit(load_date), lit(load_date)).otherwise($"contract_end_date"))

                                                .filter(col("rank_start")==="1")
                                                // manage date to retrive contract of the month
                                                .withColumn("previous_end_date",lag($"contract_end_date",1) over bycontract_order)
                                                .withColumn("next_start_date",lead($"contract_start_date",1) over bycontract_order)
                                                .withColumn("next_end_date",lead($"contract_end_date",1) over bycontract_order)
                                                .withColumn("previous_start_date",lag($"contract_start_date",1) over bycontract_order)
                                                
df_contractstart_read.createOrReplaceTempView("vw_contractstart")


//contract job change 
val bycontract_date = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"effective_job_change_date")
val bycontract_version = Window.partitionBy("employee_code","employee_id","france_payroll_id","effective_job_change_date").orderBy($"record_start_date".desc)
val df_contracthr_change = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
.select(
  "employee_code","employee_id","france_payroll_id"
  ,"contract_start_date"
  ,"contract_type"
  ,"worker_type"
  ,"collective_agreement_code"
  ,"collective_agreement_reference"
  ,"collective_agreement_group"
  ,"collective_agreement_level"
  ,"coefficient_label"
  ,"fte"
  ,"worker_rate_code"
  ,"effective_job_change_date"
  ,"record_start_date"
  ,"job_code"
  ,"csp_code"
  ,"worker_rate_code"
  ,"info_dates_code"
  ,"in_out_dates_code" 
  ,"contract_dates_code"
  ,"company_dates_code"
  ,"job_title_code"
  ,"grade_code"
).filter($"contract_start_date".isNotNull)
.withColumn("rank",rank() over bycontract_version).filter($"rank" === 1).drop("rank","record_start_date")

.orderBy("employee_code","effective_job_change_date")
.withColumn("record_end_date",date_sub(lead($"effective_job_change_date",1) over bycontract_date,1))
.withColumn("prev_record_start",lag($"effective_job_change_date",1) over bycontract_date)
.withColumn("record_start_date",$"effective_job_change_date")
.withColumn("record_end_date",coalesce($"record_end_date",to_date(lit("2999-12-31"))))
.orderBy(asc("employee_code"),asc("record_start_date"))
df_contracthr_change.createOrReplaceTempView("vw_contract_jobchange")

// Build the employee view for each org change
val joinCondition_org = $"org.employee_code" === $"contract.employee_code" and (
                            ($"org.cost_center_start_date" <= $"contract.contract_start_date"  and  $"org.cost_center_end_date" >= $"contract.contract_start_date")
                            or
                            ($"org.cost_center_start_date" >= $"contract.contract_start_date"  and  $"org.cost_center_start_date" <= $"contract.contract_end_date")
                            or (($"contract.contract_end_date" === to_date(lit("2999-12-31")) or $"contract.contract_end_date".isNull) and $"org.cost_center_start_date" >= $"contract.contract_start_date")
                        )


val joinCondition_job = $"emp.employee_code" === $"job.employee_code" and 
(
                            ($"job.record_start_date" >= $"emp.new_cost_center_start_date" and $"job.record_start_date" <= $"emp.new_cost_center_end_date")
                            or
                            ($"emp.new_cost_center_start_date" >= $"job.record_start_date" and $"emp.new_cost_center_start_date" <= $"job.record_end_date")
                        )
/*
(
                            ($"job.record_start_date" >= $"emp.contract_start_date" and ($"job.record_start_date" <= $"emp.contract_end_date" or $"emp.contract_end_date".isNull))
                            or
                            ($"job.record_end_date" >= $"emp.contract_start_date" and ($"job.record_end_date" <= $"emp.contract_end_date" or $"emp.contract_end_date".isNull))
                          )
*/
val joinCondition_emp = $"emp.employee_code" === $"e.employee_code" and (
                            ($"e.cost_center_start_date" >= $"emp.new_cost_center_start_date" and $"e.cost_center_start_date" <= $"emp.new_cost_center_end_date")
                            or
                            ($"emp.new_cost_center_start_date" >= $"e.cost_center_start_date" and $"emp.new_cost_center_start_date" <= $"e.cost_center_end_date")
                        )

val byemployee_cc_start = Window.partitionBy("emp.employee_code","emp.new_cost_center_start_date","emp.contract_start_date").orderBy($"e.record_start_date".desc,$"e.date_raw_load_file".desc,$"e.record_modification_date".desc,$"e.record_creation_date".desc)
val byemployeeid = Window.partitionBy("emp.france_payroll_id").orderBy($"emp.employee_id".desc)

val byemployee_cc_start_new = Window.partitionBy("emp.employee_code").orderBy($"emp.new_cost_center_start_date",$"job.record_start_date")

val df_employee_contract = df_employeehr_ope_org.as("org").join(df_contractstart_read.as("contract"),joinCondition_org)
                  .withColumn("new_cost_center_start_date",when($"contract.contract_start_date" > $"org.cost_center_start_date",$"contract.contract_start_date").otherwise($"org.cost_center_start_date"))
                  .withColumn("new_cost_center_end_date",when($"contract.contract_end_date" < $"org.cost_center_end_date",$"contract.contract_end_date").otherwise($"org.cost_center_end_date"))
                  .withColumn("new_cost_center_end_date",when($"new_cost_center_end_date".isNull,to_date(lit("2999-12-31"))).otherwise($"new_cost_center_end_date"))
                  .select(
                    "org.employee_code"
                    ,"org.employee_id"
                    ,"org.france_payroll_id"
                    ,"org.cost_center_code"
                    ,"org.legal_organization_code"
                    ,"org.operational_organization_code"

                    ,"new_cost_center_start_date"
                    ,"new_cost_center_end_date"
                    ,"contract.contract_type"
                    ,"contract.contract_start_date"
                    ,"contract.contract_end_date"
                    ,"contract.position_start_date"
                    ,"contract.continous_service_date"        
                    ,"contract.original_hire_date"
                    ,"contract.collective_agreement_reference"
                    ,"contract.collective_agreement_group"
                    ,"contract.collective_agreement_level"
                    ,"contract.coefficient_label"
                    ,"contract.contract_code"
                    ,"contract.contract_type_code"
                    ,"contract.collective_agreement_code"
                    ,"contract.seniority_date_max"
                    ,"contract.previous_end_date"
                    ,"contract.next_start_date"
                    ,"contract.mobility_in_code"
                    ,"contract.mobility_out_code"
                    ,"contract.contract_type_code"
                  )
                  .as("emp")
                  .join(df_contracthr_change.as("job"),joinCondition_job,"left")
                  //.filter($"new_cost_center_start_date" >= $"job.record_start_date" and $"new_cost_center_start_date" <= $"job.record_end_date")
  
                  .join(df_employee_read_review.as("e"),joinCondition_emp,"left")
                  .withColumn("rank",rank() over byemployee_cc_start).filter($"rank" === 1).drop("rank")

                  .join(df_d_contract_type.as("ct"),$"emp.contract_type_code" === $"ct.contract_type_code" and $"job.collective_agreement_code" === $"ct.collective_agreement_code","left")

                  .select(
                     "emp.employee_code"
                    ,"emp.employee_id"
                    ,"emp.france_payroll_id"
                    ,"emp.cost_center_code"
                    ,"emp.new_cost_center_start_date"
                    ,"emp.new_cost_center_end_date"
                    ,"emp.legal_organization_code"
                    ,"emp.operational_organization_code"
                    //last version of emp data
                    ,"e.effective_organization_change_date"
                    ,"e.effective_suporg_change_date"
                    ,"e.nationality_code"
                    ,"e.birth_date"
                    ,"e.location_code"               
                    ,"e.manager_code"
                    ,"e.supervisory_organization_code"
                    ,"e.establishment_start_date"
                    ,"e.establishment_end_date"
                    ,"e.company_start_date"
                    ,"e.company_end_date"
                    ,"e.organization_start_date"
                    ,"e.organization_end_date" 
                    ,"e.org_in_out_dates_code"
                    ,"e.local_pb_hierarchy_code"
                    // contract data
                    ,"ct.contract_type"
                    ,"emp.contract_start_date"
                    ,"emp.contract_end_date"
                    ,"emp.position_start_date"
                    ,"emp.continous_service_date"        
                    ,"emp.original_hire_date" 
                    ,"emp.contract_code"
                    ,"emp.seniority_date_max"
                    ,"emp.mobility_in_code"
                    ,"emp.mobility_out_code"
                    ,"emp.contract_type_code"
                    // retroactive data
                    ,"job.worker_type"
                    ,"job.collective_agreement_code"
                    ,"job.collective_agreement_reference"
                    ,"job.collective_agreement_group"
                    ,"job.collective_agreement_level"
                    ,"job.coefficient_label"
                    ,"job.fte"
                    ,"job.effective_job_change_date"
                    ,"job.job_code"
                    ,"job.job_title_code"
                    ,"job.csp_code"
                    ,"job.worker_rate_code"
                    ,"job.info_dates_code"
                    ,"job.in_out_dates_code"
                    ,"job.contract_dates_code"
                    ,"job.company_dates_code"
                    ,"job.record_start_date"
                    ,"job.record_end_date"
                    ,"job.grade_code"
                   )
                   .withColumn("prev_new_cost_center_end_date",lag($"new_cost_center_end_date",1) over byemployee_cc_start_new)
                   .withColumn("rank",rank() over byemployeeid)
                   .filter($"rank" === 1 || $"emp.france_payroll_id".isNull).drop("rank")
                   .withColumn("new_cost_center_start_date_extended",when($"prev_new_cost_center_end_date".isNull,$"new_cost_center_start_date").otherwise(date_add($"prev_new_cost_center_end_date",1)))

df_employee_contract.createOrReplaceTempView("vw_employee_contract_retro")

// COMMAND ----------

// DBTITLE 1,Get the Review Information
val byreview = Window.partitionBy("employee_id","france_payroll_id","review_type").orderBy($"review_initiated_date".desc,$"review_end_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_career_read_review = spark.table("hr.career")
                                                    .withColumn("review_end_date_old", $"review_end_date")
                                                    .withColumn("review_end_date",when(lower($"review_reference").contains("year end"),$"review_end_date")
                                                                                  .when(lower($"review_reference").contains("mid-year"),$"my_review_end_date")
                                                                                  .otherwise(coalesce($"review_end_date", $"my_review_end_date")))
                                                    .withColumn("review_status_code_old", $"review_status_code")
                                                    .withColumn("review_status",when(lower($"review_reference").contains("year end"),$"review_status")
                                                                                  .when(lower($"review_reference").contains("mid-year"),$"my_review_status")
                                                                                  .otherwise(coalesce($"review_status", $"my_review_status")))
                                                    .withColumn("review_status_code_old", $"review_status_code")
                                                    .withColumn("review_status_code",when(lower($"review_reference").contains("year end"),$"review_status_code")
                                                                                  .when(lower($"review_reference").contains("mid-year"),$"my_review_status_code")
                                                                                  .otherwise(coalesce($"review_status_code", $"my_review_status_code")))
                                                    .withColumn("review_type",when(lower($"review_reference").contains("year end"),"Year End")
                                                                                                       .when(lower($"review_reference").contains("mid-year"),"Mid-Year"))
                                                    .withColumn("review_year",year($"review_period_start_date"))

                                                    .withColumn("rank",rank() over byreview)
                                                    .filter(col("rank")==="1")
                                                    .select(
                                                            "employee_id",
                                                            "france_payroll_id",
                                                            "employee_code",
                                                            "review_reference",
                                                            "review_initiated_date", 
                                                            "review_end_date",
                                                            "review_status",
                                                            "review_period_start_date",
                                                            "review_period_end_date",
                                                            "review_code",
                                                            "review_status_code",
                                                            "career_campaign_code",
                                                            "review_type",
                                                            "review_year"
                                                            )

                                                    .distinct

df_career_read_review.createOrReplaceTempView("vw_career_review")

// COMMAND ----------

val joinCondition_Employee = ($"e.new_cost_center_start_date" <= $"r.review_period_start_date" and $"e.new_cost_center_end_date" >= $"r.review_period_start_date" and $"e.record_start_date" <= $"r.review_period_start_date" and $"e.record_end_date" >= $"r.review_period_start_date" and (lower($"e.contract_type") === "cdi" or  lower($"e.contract_type") === "détaché"))

val joinCondition_Review = ($"e.employee_code" === $"review.employee_code" and $"review.review_initiated_date" >= $"r.review_period_start_date" and $"review.review_initiated_date" <= $"r.review_period_end_date" and $"r.review_type" === $"review.review_type" and $"r.review_year" === $"review.review_year")

val joinCondition_EmployeeCurrent = ($"e.employee_code" === $"current.employee_code" and ($"current.new_cost_center_start_date" <= date_end_month and $"current.new_cost_center_end_date" >= date_end_month and $"current.record_start_date" <= date_end_month and $"current.record_end_date" >= date_end_month))

val df_career_review_employee = df_all_reviews.as("r")
                                  //applicable employees for each review
                                  .join(df_employee_contract.as("e"),joinCondition_Employee)
                                  //applicable employees for each review
                                  .join(df_employee_contract.as("current"),joinCondition_EmployeeCurrent,"left")
                                  //review data
                                  .join(df_career_read_review.as("review"),joinCondition_Review,"left")
                                  //recalculated status based for retroactive load
                                  .withColumn("review_status",when($"review.review_initiated_date".isNull ,
                                      when($"current.employee_code".isNotNull &&  $"review.review_period_end_date" > date_end_month 
                                           && $"review.review_end_date" > date_end_month
                                           && ($"current.contract_end_date" > date_end_month || $"current.contract_end_date".isNotNull),"Not Started").otherwise("Non applicable")
                                      ).otherwise(
                                      when($"review.review_initiated_date" > date_end_month &&  $"review.review_period_end_date" > date_end_month 
                                           && $"review.review_end_date" > date_end_month, "Not Started").otherwise(
                                        when($"review.review_initiated_date" <= date_end_month && $"review.review_end_date" > date_end_month,
                                             when($"current.employee_code".isNotNull && ($"current.contract_end_date" > date_end_month || $"current.contract_end_date".isNotNull),"In Progress").otherwise("Non applicable")
                                            ).otherwise(
                                          when($"review.review_status".isNull &&  $"review.review_period_end_date" > date_end_month 
                                               && $"review.review_end_date" > date_end_month,"Not Started")
                                          .otherwise($"review.review_status")
                                        )
                                      )
                                    )
                                  )
                                  .withColumn("review_contract_date",
                                    when($"review.review_initiated_date".isNull,
                                           $"r.review_period_start_date"
                                        ).otherwise(
                                        $"review.review_initiated_date"
                                    )
                                  )
                                  .withColumn("review_performed",when($"review.review_end_date" <= date_end_month,1))
                                  .select(
                                    "r.review_type"
                                    ,"r.review_year"
                                    ,"r.review_period_start_date"
                                    ,"r.review_period_end_date"
                                    ,"r.review_limit_date"
                                    ,"e.employee_code"
                                    ,"e.employee_id"
                                    ,"e.france_payroll_id"
                                    ,"e.contract_start_date"
                                    ,"e.contract_end_date"
                                    ,"review.review_initiated_date"
                                    ,"review.review_reference"
                                    ,"review.review_end_date"
                                    ,"review_status"
                                    ,"review.review_code"
                                    ,"r.career_campaign_code"
                                    ,"review_contract_date"
                                    ,"review_performed"
                                  )

df_career_review_employee.createOrReplaceTempView("vw_employee_reviews")

// COMMAND ----------

// DBTITLE 1,Query Career Promo/Mobility
val query_career = """ 
                          select  distinct                                               
                                  case when (c.contract_start_date = cp.contract_start_date 
                                         or  (c.contract_start_date > cp.contract_start_date and cp.contract_end_date is not null 
                                                                                             and (datediff(c.contract_start_date,cp.contract_end_date) - count(d.date) over (partition by c.employee_id, c.france_payroll_id,c.contract_start_date,cp.contract_end_date)) in (0,1)))
                                        and lower(ct.contract_type) in ('cdi', 'détaché')
                                        and lower(ct_p.contract_type) in ('cdi', 'détaché')
                                        and coalesce(lower(ct.classification_collective_agreement),'-1') <> coalesce(lower(ct_p.classification_collective_agreement),'-1') 
                                        and (ca.goal_order = 1 or ca.goal_order is null) then 1 else null end as number_of_classification_convention_collective_changes
                         
                                  ,case when (c.contract_start_date = cp.contract_start_date 
                                         or  (c.contract_start_date > cp.contract_start_date and cp.contract_end_date is not null 
                                                                                             and (datediff(c.contract_start_date,cp.contract_end_date) - count(d.date) over (partition by c.employee_id, c.france_payroll_id,c.contract_start_date,cp.contract_end_date)) in (0,1)))
                                         and lower(ct.contract_type) in ('cdi', 'détaché')
                                         and lower(ct_p.contract_type) in ('cdi', 'détaché')
                                         and coalesce(lower(t_convention_collective.di_value),'NC') <> coalesce(lower(t_convention_collective_p.di_value),'NC') 
                                         and (ca.goal_order = 1 or ca.goal_order is null) then 1 else null end as number_of_convention_collective_changes

                                  ,case when (c.contract_start_date = cp.contract_start_date 
                                         or  (c.contract_start_date > cp.contract_start_date and cp.contract_end_date is not null 
                                                                                             and (datediff(c.contract_start_date,cp.contract_end_date) - count(d.date) over (partition by c.employee_id, c.france_payroll_id,c.contract_start_date,cp.contract_end_date)) in (0,1)))
                                         and coalesce(lower(csp.csp),'NC') <> coalesce(lower(csp_p.csp),'NC') 
                                         and (ca.goal_order = 1 or ca.goal_order is null) then 1 else null end as number_of_csp_changes

                                  ,case when (c.contract_start_date = cp.contract_start_date 
                                         or  (c.contract_start_date > cp.contract_start_date and cp.contract_end_date is not null 
                                                                                             and (datediff(c.contract_start_date,cp.contract_end_date) - count(d.date) over (partition by c.employee_id, c.france_payroll_id,c.contract_start_date,cp.contract_end_date)) in (0,1)))
                                         and lower(ct.contract_type) in ('cdi', 'détaché')
                                         and lower(ct_p.contract_type) in ('cdi', 'détaché')
                                         and coalesce(lower(job.grade),'NC') <> coalesce(lower(job_p.grade),'NC') 
                                         and (ca.goal_order = 1 or ca.goal_order is null) then 1 else null end as number_of_grade_changes

                                  ,case when (c.contract_start_date = cp.contract_start_date 
                                         or  (c.contract_start_date > cp.contract_start_date and cp.contract_end_date is not null 
                                                                                             and (datediff(c.contract_start_date,cp.contract_end_date) - count(d.date) over (partition by c.employee_id, c.france_payroll_id,c.contract_start_date,cp.contract_end_date)) in (0,1)))
                                         and lower(ct.contract_type) in ('cdi', 'détaché')
                                         and lower(ct_p.contract_type) in ('cdi', 'détaché')
                                         and lower(csp.csp) = lower(csp_p.csp)
                                         and coalesce(lower(t_convention_collective.di_value),'NC') = coalesce(lower(t_convention_collective_p.di_value),'NC')
                                         and coalesce(lower(ct.classification_collective_agreement),'-1') <> coalesce(lower(ct_p.classification_collective_agreement),'-1') 
                                         and coalesce(lower(ct.coefficient_version),'-1') = coalesce(lower(ct_p.coefficient_version),'-1')
                                         and coalesce(lower(ct.coefficient_order),'-1') > coalesce(lower(ct_p.coefficient_order),'-1') 
                                         and (ca.goal_order = 1 or ca.goal_order is null) then 1 else null end as number_of_coefficient_promotions
                                       
                                  ,case when (c.contract_start_date = cp.contract_start_date 
                                         or  (c.contract_start_date > cp.contract_start_date and cp.contract_end_date is not null 
                                                                                             and (datediff(c.contract_start_date,cp.contract_end_date) - count(d.date) over (partition by c.employee_id, c.france_payroll_id,c.contract_start_date,cp.contract_end_date)) in (0,1)))
                                         and lower(ct.contract_type) in ('cdi', 'détaché')
                                         and lower(ct_p.contract_type) in ('cdi', 'détaché')
                                         and coalesce(lower(csp.csp),'NC') <> coalesce(lower(csp_p.csp),'NC') 
                                         and (  (lower(csp.csp) in ('employé','tam','cadre') and lower(csp_p.csp) in ('ouvrier'))
                                             or (lower(csp.csp) in ('tam','cadre') and lower(csp_p.csp) in ('employé')) 
                                             or (lower(csp.csp) in ('cadre') and lower(csp_p.csp) in ('tam')) )
                                         and (ca.goal_order = 1 or ca.goal_order is null) then 1 else null end as number_of_csp_promotions                                    
                                  
                                  ,case when (c.contract_start_date = cp.contract_start_date 
                                         or  (c.contract_start_date > cp.contract_start_date and cp.contract_end_date is not null 
                                                                                             and (datediff(c.contract_start_date,cp.contract_end_date) - count(d.date) over (partition by c.employee_id, c.france_payroll_id,c.contract_start_date,cp.contract_end_date)) in (0,1)))
                                         and lower(ct.contract_type) in ('cdi', 'détaché')
                                         and lower(ct_p.contract_type) in ('cdi', 'détaché')
                                         and coalesce(lower(job.grade),'NC') <> coalesce(lower(job_p.grade),'NC')
                                         and coalesce(lower(job.job_title),'NC') <> coalesce(lower(job_p.job_title),'NC')
                                         and (coalesce(round(ccc.total_base_pay,1),0) > coalesce(round(cccp.total_base_pay,1),0) + """ + delta_histo + """) 
                                         and (ca.goal_order = 1 or ca.goal_order is null) then 1 else null end as number_of_grade_poste_compensation_promotions
                                                               
                                  ,int(null) as number_of_employees_benefiting_a_review
                                         
                                  ,case when lower(co.relocation_long_term_willing) = 'yes'
                                          or lower(co.relocation_short_term_willing) = 'yes' 
                                        and (ca.goal_order = 1 or ca.goal_order is null) then 1 else null end as number_of_relocation_willing
                                         
                                  ,int(null) as number_of_reviews
                                    
                                  ,case when ca.goal_id is not null
                                         and not isnull(c.contract_start_date) 
                                         and to_date(c.contract_start_date) <= to_date('""" + date_id + """',"yyyyMMdd") 
                                         and (isnull(c.contract_end_date) 
                                            or ((not isnull(c.contract_end_date) and to_date(c.contract_end_date) >= to_date('""" + date_id + """',"yyyyMMdd"))))
                                         and date_format(ca.goal_due_date,'yyyy') = '""" + year_id + """' then 1 else null end as number_of_fixed_objectives_year
                                  
                                  ,case when ca.goal_id is not null
                                         and date_format(ca.goal_due_date,'yyyy') = '""" + year_id + """'
                                         and not isnull(c.contract_start_date) 
                                         and to_date(c.contract_start_date) <= to_date('""" + date_id + """',"yyyyMMdd") 
                                         and (isnull(c.contract_end_date) 
                                            or ((not isnull(c.contract_end_date) and to_date(c.contract_end_date) >= to_date('""" + date_id + """',"yyyyMMdd"))))
                                         and date_format(ca.date_raw_load_file,'yyyyMM') = '""" + month_id+ """' then 1 else null end as number_of_fixed_objectives_month
                                  
                                  ,coalesce(d.employee_id, -1) as employee_id
                                  ,coalesce(ct.contract_type_id, -1) as contract_type_id
                                  ,coalesce(wr.worker_rate_id, -1) as worker_rate_id
                                  ,case when upper(c.contract_type) = 'VA' or lower(ct.contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else coalesce(csp.csp_id, -1) end as csp_id
                                  ,coalesce(nat.nationality_id, -1) as nationality_id
                                  ,coalesce(ag.range_age_id, -1) as range_age_id
                                  ,coalesce(sec.seniority_company_id, -1) as seniority_company_id
                                  ,coalesce(sep.seniority_position_id, -1) as seniority_position_id
                                  ,coalesce(loc.location_id,-1) as location_id
                                  ,coalesce(job.job_architecture_id, -1) as job_architecture_id
                                  ,coalesce(man.manager_id, -1) as manager_id
                                  ,coalesce(so.supervisory_organization_id, -1) as supervisory_organization_id
                                  ,coalesce(ol.legal_organization_id,'-1') as legal_organization_id
                                  ,coalesce(op.operational_organization_id,'-1') as operational_organization_id
                                  ,coalesce(mob_in.mobility_in_id, -1) as mobility_in_id
                                  ,coalesce(mob_out.mobility_out_id, -1) as mobility_out_id
                                  ,coalesce(id.info_dates_id, -1) as info_dates_id
                                  ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
                                  ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id                                   
                                  ,coalesce(p.promotion_id, -1) as promotion_id
                                  ,-1 as review_id
                                  ,coalesce(cg.career_goal_id, -1) as career_goal_id
                                  ,coalesce(cm.career_mobility_id, -1) as career_mobility_id  
                                  ,-1 as career_campaign_id        
                                  ,""" + date_id + """ as date_id
                                  ,current_timestamp() as recordcreationdate
                                  ,'""" + runid + """' as runid 
                                  
                                  ,-1 as review_status_id
                                
                             from vw_employee e
                                  left join vw_contract c on e.employee_code = c.employee_code
                                  
                                  left join vw_d_employee d on e.employee_code = d.employee_code
                                  left join vw_d_nationality nat on e.nationality_code = nat.nationality_code
                                  left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date('""" + date_id + """','yyyyMMdd'),e.birth_date,true)/12) end)
                                  left join vw_d_location loc on e.location_code = loc.location_code
                                  left join vw_d_manager man on e.manager_code = man.manager_code
                                  left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code
                                  left join vw_d_legal_organization ol on e.legal_organization_code = ol.legal_organization_code
                                  left join vw_d_operational_organization op on e.operational_organization_code = op.operational_organization_code
                                  left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code
                                  left join vw_d_mobility_in mob_in on mob_in.mobility_in_code = c.mobility_in_code
                                  left join vw_d_mobility_out mob_out on mob_out.mobility_out_code = c.mobility_out_code
                                  left join vw_d_in_out_dates iod on iod.in_out_dates_code = c.in_out_dates_code 
                                                                 and iod.org_in_out_dates_code = e.org_in_out_dates_code

                                  left join vw_contract_job_change ccc on ccc.employee_code = c.employee_code 
                                                                    and c.contract_start_date = ccc.contract_start_date 
                                                                    and ccc.rank=1 
                                                                    
                                  left join vw_d_worker_rate wr on ccc.worker_rate_code = wr.worker_rate_code                                          
                                  left join vw_d_csp csp on ccc.csp_code = csp.csp_code  

                                  left join vw_d_contract_type ct on c.contract_type_code = ct.contract_type_code
                                                                 and ccc.collective_agreement_code = ct.collective_agreement_code
                                  left join vw_ref_transco t_convention_collective on lower(t_convention_collective.source_value) = lower(ct.collective_agreement_reference_label)
                                                                                  and t_convention_collective.axe = 'CONVENTION_COLLECTIVE'  
                                                                                   
                                  left join vw_d_job_architecture job on ccc.job_title_code = job.job_title_code    
                                                                     and coalesce(ccc.grade_code, -1) = coalesce(job.grade_code, -1) 
                               
                                  left join vw_d_info_dates id on id.company_dates_code = ccc.company_dates_code 
                                                              and id.contract_dates_code = c.contract_dates_code
                                                            
                                  left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(ccc.continous_service_date) then null else datediff(to_date(c.seniority_date_max),to_date(ccc.continous_service_date)) end)
                                  left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(ccc.position_start_date) then null else datediff(to_date(c.seniority_date_max),to_date(ccc.position_start_date)) end)
                                                                
                                  
                                  left join vw_contract_previous_month cp on c.employee_code = cp.employee_code   
                                  left join vw_contract_job_change_previous cccp on cccp.employee_code = cp.employee_code 
                                                                    and cp.contract_start_date = cccp.contract_start_date 
                                                                    and cccp.rank=1 
                                                                    
                                  left join vw_d_contract_type ct_p on cp.contract_type_code = ct_p.contract_type_code
                                                                 and cccp.collective_agreement_code = ct_p.collective_agreement_code
                                  left join vw_ref_transco t_convention_collective_p on lower(t_convention_collective_p.source_value) = lower(ct_p.collective_agreement_reference_label)
                                                                                   and t_convention_collective_p.axe = 'CONVENTION_COLLECTIVE'
                                                                                   
                                  left join vw_d_csp csp_p on cccp.csp_code = csp_p.csp_code   
                                  left join vw_d_job_architecture job_p on cccp.job_title_code = job_p.job_title_code    
                                                                     and coalesce(cccp.grade_code, -1) = coalesce(job_p.grade_code, -1) 
                                  
                                  
                                  
                                  left join vw_d_career_promotion p on  sha2(getconcatenedstring(array(csp_p.csp
                                                                                                      ,csp.csp)),256) = p.promotion_code
                                                                                                      
                                  left join vw_days_off d on d.date <= c.contract_start_date and d.date >= coalesce(cp.contract_end_date,'2999-12-31')    
                                 
                                  left join vw_career_goal ca on ca.employee_code = e.employee_code                                  
                                  left join vw_d_career_goal cg on ca.career_goal_code = cg.career_goal_code   
                                  
                                  left join vw_career_mobility co on co.employee_code = e.employee_code 
                                  left join vw_d_career_mobility cm on co.career_mobility_code = cm.career_mobility_code
                                  
                                        
                   """

// COMMAND ----------

// DBTITLE 1,Query Career Review
val query_career_review = """ 
                          select  
                                  int(null) as number_of_classification_convention_collective_changes
                                  ,int(null) as number_of_convention_collective_changes
                                  ,int(null) as number_of_csp_changes
                                  ,int(null) as number_of_grade_changes
                                  ,int(null) as number_of_coefficient_promotions
                                  ,int(null) as number_of_csp_promotions                                    
                                  ,int(null) as number_of_grade_poste_compensation_promotions
                                                               
                                  ,rv.review_performed as number_of_employees_benefiting_a_review
                                         
                                  ,int(null) as number_of_relocation_willing
                                         
                                  ,1 as number_of_reviews
                                    
                                  ,int(null) as number_of_fixed_objectives_year
                                  ,int(null) as number_of_fixed_objectives_month
                                  
                                  ,coalesce(d.employee_id, -1) as employee_id
                                  ,coalesce(ct.contract_type_id, -1) as contract_type_id
                                  ,coalesce(wr.worker_rate_id, -1) as worker_rate_id
                                  ,case when upper(e.contract_type) = 'VA' or lower(ct.contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else coalesce(csp.csp_id, -1) end as csp_id
                                  ,coalesce(nat.nationality_id, -1) as nationality_id
                                  ,coalesce(ag.range_age_id, -1) as range_age_id
                                  ,coalesce(sec.seniority_company_id, -1) as seniority_company_id
                                  ,coalesce(sep.seniority_position_id, -1) as seniority_position_id
                                  ,coalesce(loc.location_id,-1) as location_id
                                  ,coalesce(job.job_architecture_id, -1) as job_architecture_id
                                  ,coalesce(man.manager_id, -1) as manager_id
                                  ,coalesce(so.supervisory_organization_id, -1) as supervisory_organization_id
                                  ,coalesce(ol.legal_organization_id,'-1') as legal_organization_id
                                  ,coalesce(op.operational_organization_id,'-1') as operational_organization_id
                                  ,coalesce(mob_in.mobility_in_id, -1) as mobility_in_id
                                  ,coalesce(mob_out.mobility_out_id, -1) as mobility_out_id
                                  ,coalesce(id.info_dates_id, -1) as info_dates_id
                                  ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
                                  ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id                                   
                                  ,-1 as promotion_id
                                  ,coalesce(r.review_id, coalesce(r2.review_id,-1)) as review_id
                                  ,-1 as career_goal_id
                                  ,-1 as career_mobility_id  
                                  ,coalesce(cp.career_campaign_id, -1) as career_campaign_id        
                                  ,""" + date_id + """ as date_id
                                  ,current_timestamp() as recordcreationdate
                                  ,'""" + runid + """' as runid 
                                  
                                  ,coalesce(rs.review_status_id, -1) as review_status_id
                                
                             from vw_employee_reviews rv
                             
                             left join vw_employee_contract_retro e
                              on e.employee_code = rv.employee_code 
                              and e.new_cost_center_start_date <= rv.review_contract_date and e.new_cost_center_end_date >= rv.review_contract_date
                              and e.record_start_date <= rv.review_contract_date and e.record_end_date >= rv.review_contract_date

                                  
                                  left join vw_d_employee d on rv.employee_code = d.employee_code
                                  left join vw_d_nationality nat on e.nationality_code = nat.nationality_code
                                  left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date('""" + date_id + """','yyyyMMdd'),e.birth_date,true)/12) end)
                                  left join vw_d_location loc on e.location_code = loc.location_code
                                  left join vw_d_manager man on e.manager_code = man.manager_code
                                  left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code
                                  left join vw_d_legal_organization ol on e.legal_organization_code = ol.legal_organization_code
                                  left join vw_d_operational_organization op on e.operational_organization_code = op.operational_organization_code
                                  left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code
                                  left join vw_d_mobility_in mob_in on mob_in.mobility_in_code = e.mobility_in_code
                                  left join vw_d_mobility_out mob_out on mob_out.mobility_out_code = e.mobility_out_code
                                  left join vw_d_in_out_dates iod on iod.in_out_dates_code = e.in_out_dates_code 
                                                                 and iod.org_in_out_dates_code = e.org_in_out_dates_code

                                  left join vw_d_worker_rate wr on e.worker_rate_code = wr.worker_rate_code                                          
                                  left join vw_d_csp csp on e.csp_code = csp.csp_code  

                                  left join vw_d_contract_type ct on e.contract_type_code = ct.contract_type_code
                                                                 and e.collective_agreement_code = ct.collective_agreement_code

                                  left join vw_d_job_architecture job on e.job_title_code = job.job_title_code    
                                                                     and coalesce(e.grade_code, -1) = coalesce(job.grade_code, -1) 
                               
                                  left join vw_d_info_dates id on id.company_dates_code = e.company_dates_code 
                                                              and id.contract_dates_code = e.contract_dates_code
                                                            
                                  left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(e.continous_service_date) then null else datediff(to_date(e.seniority_date_max),to_date(e.continous_service_date)) end)
                                  left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(e.position_start_date) then null else datediff(to_date(e.seniority_date_max),to_date(e.position_start_date)) end)
                                                                
                                  left join vw_d_career_review r on r.review_code = rv.review_code
                                  left join vw_d_career_review r2 on r2.review_reference = 'NC' and rv.review_type = r2.review_type_reference
                                  
                                  left join vw_d_career_review_status rs on rs.review_status = rv.review_status
                                  left join vw_d_career_campaign cp on cp.career_campaign_code = rv.career_campaign_code  
                                                                    
                                                                         
                   """

// COMMAND ----------

// DBTITLE 1,Run Query Review
val df_career_review_results = spark.sql(query_career_review)
df_career_review_results.cache

// COMMAND ----------

// DBTITLE 1,Run Query
val df_career_results = spark.sql(query_career).filter(""" number_of_classification_convention_collective_changes is not null
                                                        or number_of_convention_collective_changes is not null
                                                        or number_of_csp_changes is not null
                                                        or number_of_grade_changes is not null
                                                        or number_of_coefficient_promotions is not null
                                                        or number_of_csp_promotions is not null 
                                                        or number_of_relocation_willing is not null""")
                        .union(df_career_review_results)
df_career_results.cache

// COMMAND ----------

// DBTITLE 1,Delete data from table f_career for existing loading date
val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """Exec [dbo].[usp_deletePartitionTableData] 'f_career','career','myMonthlyRangePS',""" + date_id
val res = stmt.execute(query_delete)


// COMMAND ----------

// DBTITLE 1,Insert data into the career table
df_career_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "career.f_career", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_employee_read.count().toInt //count the number of read records
val inserted_records = df_career_results.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_employee_read.unpersist
df_career_results.unpersist

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)