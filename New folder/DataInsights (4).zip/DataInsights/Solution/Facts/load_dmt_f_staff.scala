// Databricks notebook source
// DBTITLE 1,Get Parameters values: load_date and runid
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val limit_date_histo = dbutils.widgets.get("limit_date_histo");

// COMMAND ----------

// DBTITLE 1,Include functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Refresh delta table contract
 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table employee
 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table absenteism
 if(spark.catalog.tableExists("hr.absenteism")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table contract suspension
 if(spark.catalog.tableExists("hr.contrat_suspension")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contrat_suspension")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table referential absences
 if(spark.catalog.tableExists("hr.referential_absences")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.referential_absences")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Set variables
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_start_month = date_value.withDayOfMonth(1)
val date_next_month = date_end_month.plusDays(1)
val date_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue())) + ("%02d".format(date_value.getDayOfMonth))
val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))
val year_id = date_value.getYear()
val last_year_id = date_value.plusYears(-1).getYear()
val month_next_id = date_next_month.getYear() + ("%02d".format(date_next_month.getMonth.getValue()))

val date_end_last_month = date_start_month.plusDays(-1)

var date_inf_transfo = ""
var date_sup_transfo = ""
var date_max_change = ""

if (("%02d".format(date_value.getMonth.getValue())) == "01" )
{
      date_inf_transfo =  last_year_id + "-01-01"
      date_sup_transfo =  last_year_id + "-12-31"
      date_max_change = date_value.getYear() + "-01-31"
}
if (("%02d".format(date_value.getMonth.getValue())) == "12" )
{
     date_inf_transfo =  date_value.getYear() + "-01-01"
     date_sup_transfo =  date_value.getYear() + "-12-31"
     date_max_change = date_value.plusYears(1).getYear() + "-01-31"
}


val limit_date_value = LocalDate.parse(limit_date_histo, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val filter_file_current_month = if (date_end_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}
val filter_file_previous_month = if (date_end_last_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}

// COMMAND ----------

// DBTITLE 1,Get Dimensions data
spark.read.jdbc(jdbcurl, "dbo.d_date", connectionproperties).filter(col("month_id") === lit(month_id)).createOrReplaceTempView("vw_d_date")
spark.read.jdbc(jdbcurl, "staff.d_employee", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_employee")
spark.read.jdbc(jdbcurl, "staff.d_contract_type", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_contract_type")
spark.read.jdbc(jdbcurl, "staff.d_worker_rate", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_worker_rate")
spark.read.jdbc(jdbcurl, "staff.d_csp", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_csp")
spark.read.jdbc(jdbcurl, "staff.d_nationality", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_nationality")
spark.read.jdbc(jdbcurl, "staff.d_range_age", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_range_age")
spark.read.jdbc(jdbcurl, "staff.d_seniority_company", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_company")
spark.read.jdbc(jdbcurl, "staff.d_seniority_position", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_position")
spark.read.jdbc(jdbcurl, "staff.d_location", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_location")
spark.read.jdbc(jdbcurl, "staff.d_job_architecture", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_job_architecture")
spark.read.jdbc(jdbcurl, "staff.d_manager", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_manager")
spark.read.jdbc(jdbcurl, "staff.d_supervisory_organization", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_supervisory_organization")
spark.read.jdbc(jdbcurl, "staff.d_contract_suspension", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_contract_suspension")


// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_legal_organization", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_legal_organization")
spark.read.jdbc(jdbcurl, "staff.d_operational_organization", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_operational_organization")
spark.read.jdbc(jdbcurl, "staff.d_info_dates", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_info_dates")
spark.read.jdbc(jdbcurl, "staff.d_contract_suspension_dates", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_contract_suspension_dates")
spark.read.jdbc(jdbcurl, "staff.d_hierarchy_pb", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_hierarchy_pb")
spark.read.jdbc(jdbcurl, "staff.vw_d_legal_organization", connectionproperties).select("legal_organization_id", "company", "libelle_etablissement").createOrReplaceTempView("vw_d_legal_organization_transcoded")
spark.read.jdbc(jdbcurl, "staff.d_employee_dependent", connectionproperties).filter("children_date_of_death is not null").filter(col("children_date_of_death") > to_date(lit(date_id),"yyyyMMdd")) .groupBy("employee_id").agg(count("hashkey").as("nb_children")).createOrReplaceTempView("vw_d_employee_dependent")

spark.read.jdbc(jdbcurl, "mobility.d_mobility_in", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_mobility_in")
spark.read.jdbc(jdbcurl, "mobility.d_mobility_out", connectionproperties).filter("current_version = 1").filter("current_version = 1")createOrReplaceTempView("vw_d_mobility_out")
spark.read.jdbc(jdbcurl, "mobility.d_in_out_dates", connectionproperties).filter("current_version = 1").createOrReplaceTempView("vw_d_in_out_dates")

spark.read.jdbc(jdbcurl, "dbo.param_absenteism", connectionproperties).createOrReplaceTempView("vw_param_absenteism")
spark.read.jdbc(jdbcurl, "dbo.vw_ref_seniority_company", connectionproperties).createOrReplaceTempView("vw_ref_seniority_company")

// COMMAND ----------

// DBTITLE 1,Get Parameters Values
val df_param_value = spark.read.jdbc(jdbcurl, "dbo.param_value", connectionproperties).select("parameter_name", "parameter_value")
val delay_change = df_param_value.filter($"parameter_name" === "DELAI_TRANSFORMATION_CONTRAT").select("parameter_value").first().getString(0).toDouble.toInt
val borne_6_months = spark.sql("""select distinct range_seniority_company_min as calendardays from vw_ref_seniority_company where range_seniority_company = 'Entre 6 mois et 1 an'""").head().getInt(0) //Borne min for seniority superior to 6 months
val vacataire_csp_id = spark.sql("""select cast(sum(csp_id) as int) as vacataire_csp_id from vw_d_csp where lower(professional_category_reference) = 'autre statut'""").head().getInt(0) //Get Vacataire Csp Id
val opendays = spark.sql("""select cast(sum(business_day_fr) as int) as opendays from vw_d_date where month_id = '""" + month_id + """'""").head().getInt(0) // Get Nb Opened Days in the load date month
val calendardays = spark.sql("""select cast(count(distinct date_id) as int) as calendardays from vw_d_date where month_id = '""" + month_id + """'""").head().getInt(0) // Get Nb Calendar Days in the load date month

// COMMAND ----------

// DBTITLE 1,Read contract, employee and contract suspension data for staff
val byemployee = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_organization_change_date".desc,$"effective_organization_hierarchy_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_employee_read = spark.table("hr.employee").filter("('" + date_end_month.toString + "' >= record_start_date or '" + date_end_month.toString + "' >= effective_organization_hierarchy_change_date) and '" + date_end_month.toString + "' <= coalesce(record_end_date, '2999-12-31')")
                                                 .withColumn("rank",rank() over byemployee)
                                                 .filter(col("rank")==="1").distinct
df_employee_read.createOrReplaceTempView("vw_employee")
df_employee_read.cache()  //put the dataframe on the cache


val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract = Window.partitionBy("employee_id","france_payroll_id").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)

val df_contract_read = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                 .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """' """
                                                        ) 
                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("month_contract_start_date",when($"contract_start_date" < date_start_month,date_start_month).otherwise($"contract_start_date"))
                                                .withColumn("month_contract_end_date",when($"contract_end_date" > date_end_month,date_end_month).when($"contract_end_date".isNull,date_end_month).otherwise($"contract_end_date"))
                                                .withColumn("contract_days",datediff($"month_contract_end_date",$"month_contract_start_date")+1)
                                                .filter(col("rank_month")==="1")
                                                .filter("""date_format(contract_start_date,'yyyyMM') = '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                            (date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                        )
                                                
                                                .withColumn("rank",rank() over bycontract)
                                                .withColumn("next_contract_start_date",lag($"contract_start_date", 1, null).over(bycontract) )
                                                .withColumn("next_contract_end_date",lag($"contract_end_date", 1, null).over(bycontract) )
                                                .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                .distinct
df_contract_read.createOrReplaceTempView("vw_contract")



val bycontractsuspension_month = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_suspension_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_suspension_read = spark.table("hr.contract_suspension").filter("""date_format(contract_suspension_start_date,'yyyyMM') = '""" + month_id + """' or 
                                                            date_format(coalesce(contract_suspension_end_date, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                            (date_format(contract_suspension_start_date,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(contract_suspension_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                        )                                                         
                                                .withColumn("rank_month",rank() over bycontractsuspension_month)
                                                .withColumn("contract_suspension_end_date",when($"contract_suspension_end_date" === "2999-12-31",null).otherwise($"contract_suspension_end_date"))
                                                .filter(col("rank_month")==="1").distinct
df_contract_suspension_read.createOrReplaceTempView("vw_contract_suspension")

val df_contract_suspension_year_read = spark.table("hr.contract_suspension").filter("""year(contract_suspension_start_date) = """ + year_id + """ or 
                                                            year(coalesce(contract_suspension_end_date, '2999-12-31')) = """ + year_id + """ or (
                                                            year(contract_suspension_start_date) <= """ + year_id + """ and year(coalesce(contract_suspension_end_date, '2999-12-31')) >= """ + year_id + """)"""
                                                        )                                                         
                                                .select("employee_code","employee_id","france_payroll_id")
                                                .withColumn("has_suspension",lit(1))
                                                .distinct
df_contract_suspension_year_read.createOrReplaceTempView("vw_contract_suspension_year")


val bycontractlast = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bysenioritymax = Window.partitionBy("employee_id","france_payroll_id").orderBy($"seniority_date_max".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_last_read = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                      .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")
                                                      .withColumn("rank_last",rank() over bycontractlast)
                                                      .filter(col("rank_last")==="1").distinct  
                                                      .withColumn("seniority_date_max",when(($"contract_end_date" === "2999-12-31" or $"contract_end_date".isNull or $"contract_end_date" > lit(load_date)) and $"contract_start_date" < lit(load_date), lit(load_date))
                                                                                      .when($"contract_start_date" >= lit(load_date), date_end_month)
                                                                                      .otherwise($"contract_end_date"))
                                                      .withColumn("rank_seniority",rank() over bysenioritymax)
df_contract_last_read.createOrReplaceTempView("vw_contract_last")

// COMMAND ----------

// DBTITLE 1,Effective Job Change and Compensation To Apply To Each Contract
val byJobChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date_valid".desc)
val byJobChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_compensation_change_date_valid".desc)
val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date","effective_job_change_date","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_creation_date".desc,$"record_modification_date".desc)


val df_effective_change_valid = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")                                                
                                                .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") <= month_id && date_format($"effective_compensation_change_date","yyyyMM") <= month_id
                                                                                                                                                           && $"effective_job_change_date" <= $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                .withColumn("effective_job_change_date_valid", when($"effective_job_change_date" > lit(date_value),null).otherwise($"effective_job_change_date"))
                                                .withColumn("effective_job_change_date_valid_last", first($"effective_job_change_date").over(byJobChangeDateLast))
                                                .withColumn("effective_job_change_date", when($"effective_job_change_date_valid".isNotNull,$"effective_job_change_date_valid")
                                                                                        .when($"effective_job_change_date_valid_last".isNull, $"contract_start_date")
                                                                                        .otherwise($"effective_job_change_date_valid_last"))         
                                                .withColumn("effective_job_change_date_max", first($"effective_job_change_date").over(byJobChangeDateLastContract))

                                                .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                .withColumn("effective_compensation_change_date_valid", when($"effective_compensation_change_date" > lit(date_value),null).otherwise($"effective_compensation_change_date"))
                                                .withColumn("effective_compensation_change_date_valid_last", first($"effective_compensation_change_date").over(byCompensationChangeDateLast))
                                                .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date_valid".isNotNull,$"effective_compensation_change_date_valid")
                                                                                                 .when($"effective_compensation_change_date_valid_last".isNull, $"contract_start_date")
                                                                                                 .otherwise($"effective_compensation_change_date_valid_last"))      
                                                .withColumn("effective_compensation_change_date_max",first($"effective_compensation_change_date").over(byCompensationChangeDateLastContract))
                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .filter(col("rank_month")==="1")  
                                                .filter("""date_format(contract_start_date,'yyyyMM') = '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') = '""" + month_id + """' or 
                                                            (date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' and date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """')"""
                                                        )
                                               .select("employee_code",
                                                       "employee_id",
                                                       "france_payroll_id",
                                                       "contract_start_date",
                                                       "contract_end_date",
                                                       "contract_type",
                                                       "contract_type_label",
                                                       "effective_job_change_date",
                                                       "effective_compensation_change_date",
                                                       "effective_job_change_date_max",
                                                       "effective_compensation_change_date_max").distinct


val bycontract_job_month = Window.partitionBy("employee_id","france_payroll_id","effective_job_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_creation_date".desc,$"record_modification_date".desc)
val df_contract_effective_job_change_date_read =spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                                     .filter("""contract_start_date <= '""" + date_value + """'""")  
                                                                     .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                                     .withColumn("effective_job_change_date", when($"effective_job_change_date".isNotNull,$"effective_job_change_date").otherwise($"contract_start_date")) 
                                                                     .filter("""effective_job_change_date <= '""" + date_value + """'""")   
                                               
                                                                     .withColumn("rank_month",rank() over bycontract_job_month)
                                                                     .filter(col("rank_month")==="1")  
                                                                     .distinct

val bycontract_compensation_month = Window.partitionBy("employee_id","france_payroll_id","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_creation_date".desc,$"record_modification_date".desc)
val df_contract_effective_compensation_change_date_read =spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                                     .filter("""contract_start_date <= '""" + date_value + """'""")     
                                                                     .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                                     .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date".isNotNull,$"effective_compensation_change_date").otherwise($"contract_start_date"))                                         
                                                                     .filter("""effective_compensation_change_date <= '""" + date_value + """'""")   

                                                                     .withColumn("rank_month",rank() over bycontract_compensation_month)
                                                                     .filter(col("rank_month")==="1")  
                                                                     .distinct

val df_contract_join = df_effective_change_valid.as("e")
                                        .join(df_contract_effective_job_change_date_read.as("c"), $"e.employee_code" === $"c.employee_code" && $"e.effective_job_change_date_max" === $"c.effective_job_change_date", "left_outer")
                                        .join(df_contract_effective_compensation_change_date_read.as("o"), $"e.employee_code" === $"o.employee_code" && $"e.effective_compensation_change_date_max" === $"o.effective_compensation_change_date", "left_outer")
                                        .join(df_contract_read.as("d"), $"e.employee_code" === $"d.employee_code" && $"e.contract_start_date" === $"d.contract_start_date" 
                                                                                                                  && ($"e.effective_job_change_date_max" === $"d.effective_job_change_date" || $"e.effective_compensation_change_date_max" === $"d.effective_compensation_change_date"), "left_outer")
                                        .join(df_contract_read.as("r"), $"e.employee_code" === $"r.employee_code" && $"e.contract_start_date" === $"r.contract_start_date", "left_outer")
                                        .selectExpr(
                                                "e.employee_code"
                                               ,"e.employee_id"
                                               ,"e.france_payroll_id"
                                               ,"coalesce(r.contract_start_date, e.contract_start_date) as contract_start_date"
                                               ,"coalesce(r.contract_end_date, e.contract_end_date) as contract_end_date"
                                               ,"e.effective_job_change_date"
                                               ,"coalesce(c.collective_agreement_reference, d.collective_agreement_reference) as collective_agreement_reference"                                    
                                               ,"coalesce(c.collective_agreement_group, d.collective_agreement_group) as collective_agreement_group"
                                               ,"coalesce(c.collective_agreement_level, d.collective_agreement_level) as collective_agreement_level"
                                               ,"coalesce(c.continous_service_date, d.continous_service_date) as continous_service_date"
                                               ,"coalesce(c.position_start_date, d.position_start_date) as position_start_date"
                                               ,"coalesce(c.hire_date, d.hire_date) as hire_date"
                                               ,"coalesce(c.original_hire_date, d.original_hire_date) as original_hire_date"
                                               ,"coalesce(c.effective_hire_date, d.effective_hire_date) as effective_hire_date"
                                               ,"coalesce(c.fte, d.fte) as fte"
                                               ,"coalesce(c.worker_type, d.worker_type) as worker_type"
                                               ,"coalesce(c.paidfte, d.paidfte) as paidfte"
                                               ,"coalesce(c.bonus_target, d.bonus_target) as bonus_target"
                                               ,"coalesce(c.csp, d.csp) as csp"
                                               ,"coalesce(c.coefficient, d.coefficient) as coefficient"
                                               ,"coalesce(c.coefficient_label, d.coefficient_label) as coefficient_label"
                                               ,"coalesce(c.job_title, d.job_title) as job_title"
                                               ,"coalesce(o.total_base_pay, d.total_base_pay) as total_base_pay"
                                               ,"coalesce(o.grade, d.grade) as grade"
                                               ,"coalesce(o.effective_compensation_change_date, d.effective_compensation_change_date) as effective_compensation_change_date"
                                               ,"coalesce(c.job_code, d.job_code) as job_code"
                                               ,"coalesce(c.job_title_code, d.job_title_code) as job_title_code"
                                               ,"coalesce(o.grade_code, d.grade_code) as grade_code"
                                               ,"coalesce(c.csp_code, d.csp_code) as csp_code"
                                               ,"coalesce(c.worker_rate_code, d.worker_rate_code) as worker_rate_code"
                                               ,"coalesce(d.mobility_in_code, c.mobility_in_code) as mobility_in_code"
                                               ,"coalesce(d.mobility_out_code, c.mobility_out_code) as mobility_out_code"
                                               ,"coalesce(d.info_dates_code, c.info_dates_code) as info_dates_code"
                                               ,"coalesce(d.in_out_dates_code, c.in_out_dates_code) as in_out_dates_code"
                                               ,"coalesce(d.contract_dates_code, c.contract_dates_code) as contract_dates_code"                                               
                                               ,"coalesce(c.contract_code, d.contract_code) as contract_code"
                                               ,"coalesce(d.contract_type_code, c.contract_type_code) as contract_type_code"
                                               ,"coalesce(c.collective_agreement_code, d.collective_agreement_code) as collective_agreement_code"
                                               ,"coalesce(c.company_dates_code, d.company_dates_code) as company_dates_code"
                                               ,"coalesce(d.record_start_date, c.record_start_date) as record_start_date"
                                               ,"coalesce(d.date_raw_load_file, c.date_raw_load_file) as date_raw_load_file"
                                               ,"coalesce(d.record_modification_date, c.record_modification_date) as record_modification_date"
                                               ,"coalesce(d.record_creation_date, c.record_creation_date) as record_creation_date"
                                            )

                                          .distinct

df_contract_join.createOrReplaceTempView("vw_emp_contract") 


// COMMAND ----------

val bycontract_job_change_fte = Window.partitionBy("employee_id","france_payroll_id","contract_start_date","fte").orderBy($"contract_start_date".desc,$"effective_job_change_date".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract_job_change = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_job_change_date".desc,$"effective_compensation_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_contract_read_job_change =  df_contract_join
                                                .withColumn("rank_fte",rank() over bycontract_job_change_fte)
                                                .filter(col("rank_fte")==="1")
                        
                                                .filter("""ifnull(date_format(contract_end_date,'yyyyMM'),'299912') >= '""" + month_id + """'""")
                                                .withColumn("month_contract_start_date",when($"contract_start_date" < date_start_month,date_start_month).otherwise($"contract_start_date"))
                                                .withColumn("month_contract_end_date",when($"contract_end_date" > date_end_month,date_end_month).when($"contract_end_date".isNull,date_end_month).otherwise($"contract_end_date"))
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))

                                                .withColumn("effective_job_change_date_end",lag($"effective_job_change_date", 1, null).over(bycontract_job_change))
                                                .withColumn("effective_job_change_date_previous",lag($"effective_job_change_date", 1, null).over(bycontract_job_change))
                                                .withColumn("effective_job_change_date_end",when($"effective_job_change_date_end".isNull or $"effective_job_change_date_end" === $"effective_job_change_date" ,$"month_contract_end_date").otherwise(date_add($"effective_job_change_date_end",-1)))
                                                .withColumn("contract_days_job_change",when($"effective_job_change_date_end".isNotNull and $"effective_job_change_date_end" >= $"month_contract_start_date" and $"effective_job_change_date_end" < $"month_contract_end_date" and  datediff($"effective_job_change_date_end",$"month_contract_start_date")>=0, 
                                                                                            datediff($"effective_job_change_date_end",$"month_contract_start_date")+1)  
                                                                                       .when($"effective_job_change_date".isNotNull and $"effective_job_change_date" > $"month_contract_start_date" and $"effective_job_change_date" <= $"month_contract_end_date" and datediff($"month_contract_end_date",$"effective_job_change_date")>=0, 
                                                                                            datediff($"month_contract_end_date",$"effective_job_change_date")+1)   
                                                                                      .otherwise(datediff($"month_contract_end_date",$"month_contract_start_date")+1))
                                                .withColumn("rank",rank() over bycontract_job_change)
                                                .withColumn("new_rank",when($"rank" > 1 and date_format($"effective_job_change_date_previous","yyyyMM") === lit(month_id) and $"effective_job_change_date_previous">$"month_contract_start_date" ,"1").otherwise($"rank"))
                                                
                                                .filter(col("new_rank")==="1")
                                                .distinct
                                                .withColumn("position_start_date", when($"position_start_date" > $"effective_job_change_date",$"effective_job_change_date").otherwise($"position_start_date"))
                                                .withColumn("continous_service_date", when($"continous_service_date" > $"contract_start_date",$"contract_start_date").otherwise($"continous_service_date"))

df_contract_read_job_change.createOrReplaceTempView("vw_contract_job_change")

// COMMAND ----------

// DBTITLE 1,Read absenteism data
// absence rate
val byabs = Window.partitionBy("employee_hra", "dateval", "code", "duration_days", "duration_hours").orderBy($"date_raw_load_file".desc, $"version".desc, $"record_creation_date")
val df_absenteism_read = spark.table("hr.absenteism").filter("period_abs_month = '" + month_id + "'")
                                                      .withColumn("calendardays",lit(calendardays))
                                                      .withColumn("opendays",lit(opendays))
                                                      .withColumn("employee_hra_old",$"employee_hra")
                                                      .withColumn("employee_hra", substring_index($"employee_hra", "_", 1))
                                                      .withColumn("rank",rank() over byabs)
                                                      .filter(col("rank")==="1")
                                                      .distinct
df_absenteism_read.createOrReplaceTempView("vw_absenteism")

val df_referential_absences_read = spark.table("hr.referential_absences").select("absence_code", "absence_label_code", "absence_type")
                                                      .withColumn("code_abs", $"absence_code")                                                                                                                                     
                                                      .withColumn("type_abs",$"absence_type")
                                                      .distinct
df_referential_absences_read.createOrReplaceTempView("vw_referential_absences")

// COMMAND ----------

// DBTITLE 1,Nb Productive Days
val employee_productivedays_workingdays = spark.sql( """
  select   
     c.employee_code
    ,c.employee_id
    ,c.france_payroll_id
    ,c.contract_start_date
    ,cjc.fte
    ,sum(case when a.duration_days = 0 then a.duration_hours/7 else a.duration_days end) abs_days
    ,avg(opendays) opendays
    ,sum(case when a.duration_days = 0 then a.duration_hours/7 else a.duration_days end)/avg(calendardays) as abs_rate
    ,cjc.contract_days_job_change
    
  from vw_absenteism a 

  inner join vw_referential_absences pa on a.code = pa.code_abs
  
  inner join vw_contract c
  on c.france_payroll_id = a.employee_hra
  and a.dateval between c.month_contract_start_date and c.month_contract_end_date
  
  left  join vw_contract_job_change cjc 
        on cjc.employee_code = c.employee_code
        and cjc.contract_start_date = c.contract_start_date
        
  where 1=1
    and a.dateval between case when c.month_contract_start_date < cjc.effective_job_change_date then cjc.effective_job_change_date else c.month_contract_start_date end  and
                          case when c.month_contract_end_date < cjc.effective_job_change_date_end then c.month_contract_end_date else cjc.effective_job_change_date_end end
  
  group by
      c.employee_code
    ,c.employee_id
    ,c.france_payroll_id
    ,c.contract_start_date
    ,cjc.fte
    ,cjc.contract_days_job_change

  order by c.employee_code,c.contract_start_date
         """)
employee_productivedays_workingdays.createOrReplaceTempView("vw_employee_productivedays_working")

// COMMAND ----------

val by_contract_type_fte = Window.partitionBy("contract_type_code").orderBy($"start_date".desc,$"contract_type_id".desc)


val df_fte_contract_type = spark.read.jdbc(jdbcurl, "staff.d_contract_type", connectionproperties).filter("current_version = 1")
                                                      .withColumn("rank",rank() over by_contract_type_fte)
                                                      .filter(col("rank")==="1")
                                                      .distinct

df_fte_contract_type.createOrReplaceTempView("vw_d_contract_type_fte")

// COMMAND ----------

// DBTITLE 1,Nb Workings days and ETP By Employee, Contract and FTE
spark.sql("""

  select distinct

       c.employee_code
       ,c.employee_id
       ,c.france_payroll_id
       ,c.contract_start_date
       ,case when lower(ct.contract_type_detailed) != 'interim' then cjc.fte else null end as worker_rate
       ,case when lower(ct.contract_type) in ('cdi', 'cdd', 'stagiaire', 'alternant', 'détaché') then cjc.fte else null end as worker_rate_total 
       ,cjc.contract_days_job_change as workingdays_fte
       ,ifnull(wrk.abs_rate,0) abs_rate
       ,cjc.contract_days_job_change
       ,cjc.contract_days_job_change/ """+calendardays+""" as wrk_rate
       ,cjc.contract_days_job_change/ """+calendardays+""" - (ifnull(wrk.abs_rate,0)) as prd_rate
       ,ct.contract_type
       ,ct.contract_type_detailed
       ,ct.precarity
       
  from vw_contract c
  inner join vw_contract_job_change cjc on c.employee_code = cjc.employee_code and c.contract_start_date = cjc.contract_start_date

  left join vw_employee_productivedays_working wrk
  on wrk.employee_code = c.employee_code and c.contract_start_date = wrk.contract_start_date and cjc.fte = wrk.fte and cjc.contract_days_job_change = wrk.contract_days_job_change
  
  left join vw_d_contract_type_fte ct on c.contract_type_code = ct.contract_type_code

                               """).createOrReplaceTempView("vw_employee_workingdays_fte")

// COMMAND ----------

// DBTITLE 1,Nb Workings days, etp contractuel and productive By Employee and contracts
spark.sql("""

  select distinct

        c.employee_code
       ,c.employee_id
       ,c.france_payroll_id
       ,c.contract_start_date
       ,sum(workingdays_fte)  as workingdays
       ,sum(wrk_rate*worker_rate) as etp_contractuel
       ,sum(prd_rate*worker_rate) as etp_productive
       ,sum(wrk_rate*worker_rate_total) as etp_contractuel_total
  from vw_employee_workingdays_fte c
  
  group by c.employee_code
       ,c.employee_id
       ,c.france_payroll_id
       ,c.contract_start_date

                               """).createOrReplaceTempView("vw_employee_workingdays")

// COMMAND ----------

// DBTITLE 1,Nb Workings days, etp contractuel and productive By Employee
spark.sql("""select  c.employee_code 
                    ,c.employee_id
                    ,c.france_payroll_id                    
                    ,sum(workingdays_fte)  as workingdays_month  
                    ,sum(wrk_rate*worker_rate) as etp_contractuel_base_month
                    ,sum(prd_rate*worker_rate) as etp_productive_base_month
                    ,sum(wrk_rate*worker_rate_total) as etp_contractuel_total_base_month
                    ,sum(case when lower(c.precarity) = 'precaire' then wrk_rate*worker_rate else null end) as etp_contractuel_precaire_month                    
                    ,sum(case when lower(c.contract_type) = 'cdd' then wrk_rate*worker_rate else null end) as etp_contractuel_cdd_month
                    ,sum(case when lower(c.contract_type_detailed) = 'cdd surcroît' then wrk_rate*worker_rate else null end) as etp_contractuel_cdd_surcroit_month
                    ,sum(case when lower(c.contract_type_detailed) = 'cdd remplacement' then wrk_rate*worker_rate else null end) as etp_contractuel_cdd_remplacement_month
                    ,sum(case when lower(c.contract_type) in ('stagiaire', 'alternant') then wrk_rate*worker_rate else null end) as etp_contractuel_ecole_month
                    ,count(distinct c.contract_type) as nb_contract_type
                    ,count(distinct c.contract_type_detailed) as nb_contract_type_detailed
                    
              from vw_employee_workingdays_fte c
                   
              group by c.employee_code
                      ,c.employee_id
                      ,c.france_payroll_id
                               """).createOrReplaceTempView("vw_employee_workingdays_month")


// COMMAND ----------

// DBTITLE 1,Read data for contracts transfo
//Contract Last
val bycontract_recordstartdate = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"contract_end_date".desc_nulls_last,$"record_start_date".desc,$"record_end_date".asc)
val bycontract_window = Window.partitionBy("employee_id","france_payroll_id","contract_type").orderBy($"contract_start_date".desc_nulls_last)                                                                                                                     
val df_contract_last_year_read = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                           .withColumn("rank",rank() over bycontract_recordstartdate)
                                                           .filter(col("rank")==="1")
                                                           .withColumn("previous_contract_type",lag($"contract_type", 1, null).over(bycontract_window) )
                                                           .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                           .withColumn("position_start_date", when($"position_start_date" > $"effective_job_change_date",$"effective_job_change_date").otherwise($"position_start_date"))
df_contract_last_year_read.createOrReplaceTempView("vw_contract_last_year")

// COMMAND ----------

// DBTITLE 1,Contract Transfo Rate Numerator
val query_transfo_rate = """   
                       select  
                              null as effectif  
                             ,null as effectif_etp_productive_detailed 
                             ,null as effectif_etp_productive 
                             ,null as effectif_etp_contractuel_detailed  
                             ,null as effectif_etp_contractuel 
                             ,null as effectif_etp_contractuel_total 
                             ,null as effectif_etp_contractuel_detailed_total 
                             ,null as effectif_etp_contractuel_precarite 
                             ,null as effectif_etp_contractuel_cdd 
                             ,null as effectif_etp_contractuel_surcroit
                             ,null as effectif_etp_contractuel_remplacement
                             ,null as effectif_etp_contractuel_ecole 
                             ,null as effectif_present   
                             ,null as active_contract
                             ,null as is_contract
                             ,""" + opendays + """ as opendays 
                             ,null as is_permanent
                             ,null as is_suspension
                             ,null as time_in_position
                             ,null as length_of_service
                             ,null as age
                             ,null as nb_children
                             ,null as fte
                             ,null as paidfte
                             ,null as worker_type 
                             ,null as bonus_target
                             ,null as contractual_pay 
                             ,c2.contract_start_date 
                             ,c2.contract_end_date
                             ,date_add(c2.contract_end_date,1)  as date_out_company
                             ,case when c2.contract_end_date is null then null else datediff(c2.contract_end_date, c2.contract_start_date) end as duree_contract
                             
                             ,null as is_seniority_company_6_months
                             
                             ,null as date_deb_suspension
                             ,null as date_fin_suspension
                             ,null as duree_suspension
                             
                             ,null as position_start_date
                             ,null as hire_date
                             ,null as original_hire_date
                             ,null as effective_hire_date
                             ,null as effective_job_change_date
                             ,null as effective_organization_change_date
                             ,null as effective_suporg_change_date
                             ,null as date_deb_centre_cout
                             ,null as date_fin_centre_cout
                             ,null as date_deb_etablissement
                             ,null as date_fin_etablissement
                             ,null as date_deb_societe
                             ,null as date_fin_societe
                             ,null as date_deb_org
                             ,null as date_fin_org
                             ,null as category_ce
                                  
                             ,coalesce(d.employee_id, -1) as employee_id
                             ,coalesce(ct2.contract_type_id, -1) as contract_type_id
                             ,coalesce(wr.worker_rate_id, -1) as worker_rate_id
                             ,case when upper(c2.contract_type) = 'VA' or  lower(ct2.contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else coalesce(csp.csp_id, -1) end as csp_id
                             ,coalesce(nat.nationality_id, -1) as nationality_id
                             ,coalesce(ag.range_age_id, -1) as range_age_id
                             ,coalesce(sec.seniority_company_id,-1) as seniority_company_id
                             ,coalesce(sep.seniority_position_id, -1) as seniority_position_id
                             ,coalesce(loc.location_id, -1) as location_id
                             ,coalesce(job.job_architecture_id, -1) as job_architecture_id
                             ,coalesce(man.manager_id, -1) as manager_id
                             ,coalesce(so.supervisory_organization_id, -1) as supervisory_organization_id
                             ,-2 as contract_suspension_id
                             ,coalesce(ol.legal_organization_id,'-1') as legal_organization_id
                             ,coalesce(op.operational_organization_id,'-1') as operational_organization_id
                             ,coalesce(mob_in.mobility_in_id, -1) as mobility_in_id
                             ,coalesce(mob_out.mobility_out_id,-1) as mobility_out_id
                             ,coalesce(id.info_dates_id, -1) as info_dates_id
                             ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
                             ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
                              ,-2 as contract_suspension_dates_id
                             ,case when """ + month_id + """  = concat(""" + year_id + """,'01') then concat(""" + last_year_id + """,'1231') 
                                    when """ + date_id + """ = concat(""" + year_id + """,'1231') then """ + date_id + """ end as date_id
                             ,current_timestamp() as recordcreationdate
                             ,'""" + runid + """' as runid

                              ,1 as is_transfo
                              ,case when lower(ct1.contract_type) = 'stagiaire' and lower(ct2.contract_type) = 'cdd' then 1 else null end as is_transfo_stagiare_cdd
                              ,case when lower(ct1.contract_type) = 'stagiaire' and lower(ct2.contract_type) = 'cdi' then 1 else null end as is_transfo_stagiare_cdi
                              ,case when lower(ct1.contract_type) = 'alternant' and lower(ct2.contract_type) = 'cdd' then 1 else null end as is_transfo_alternant_cdd
                              ,case when lower(ct1.contract_type) = 'alternant' and lower(ct2.contract_type) = 'cdi' then 1 else null end as is_transfo_alternant_cdi
                              ,case when lower(ct1.contract_type) = 'cdd' and lower(ct2.contract_type) = 'cdi' then 1 else null end as is_transfo_cdd_cdi
                              ,case when lower(ct1.contract_type) in ('stagiaire','alternant') and lower(ct2.contract_type) in ('cdi','cdd') then 1 else null end as is_transfo_ecole
                              ,null as is_demon_transfo
                              
                       from   vw_contract_last_year c1
                              inner join vw_d_contract_type ct1 on c1.contract_code = ct1.contract_code and lower(ct1.precarity) = 'precaire'
                              inner join vw_contract_last_year c2 on c1.employee_code = c2.employee_code 
                              inner join vw_d_contract_type ct2 on c2.contract_code = ct2.contract_code and  ct1.contract_type <> ct2.contract_type
                              
                              inner join vw_employee e on c2.employee_code = e.employee_code
                              inner join vw_d_employee d on e.employee_code = d.employee_code                            

                              left join vw_d_nationality nat on e.nationality_code = nat.nationality_code
                              left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date('""" + date_id + """','yyyyMMdd'),to_date(e.birth_date),true)/12) end)
                              left join vw_d_location loc on e.location_code = loc.location_code
                              left join vw_d_manager man on e.manager_code = man.manager_code
                              left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code
                              left join vw_d_legal_organization ol on e.legal_organization_code = ol.legal_organization_code
                              left join vw_d_legal_organization_transcoded olt on olt.legal_organization_id = ol.legal_organization_id
                              left join vw_d_operational_organization op on e.operational_organization_code = op.operational_organization_code                               
                              left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code                              
                              
                              left join vw_d_in_out_dates iod on iod.in_out_dates_code = c2.in_out_dates_code and iod.org_in_out_dates_code = e.org_in_out_dates_code 
                              left join vw_d_csp csp on C2.csp_code = csp.csp_code                    
                              left join vw_d_job_architecture job on C2.job_code = job.job_architecture_code
                              left join vw_d_mobility_in mob_in on mob_in.mobility_in_code = c2.mobility_in_code
                              left join vw_d_mobility_out mob_out on mob_out.mobility_out_code = c2.mobility_out_code
                              left join vw_d_info_dates id on id.info_dates_code = c2.info_dates_code                                                                                     
                              left join vw_d_worker_rate wr on wr.worker_rate_code = c2.worker_rate_code 
                              
                              left join vw_contract_last cl on c1.employee_code = cl.employee_code and cl.rank_seniority=1
                              left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when c2.continous_service_date is not null and c2.continous_service_date < cl.seniority_date_max then datediff(to_date(cl.seniority_date_max),to_date(c2.continous_service_date)) else datediff(to_date(cl.seniority_date_max),to_date(c1.contract_end_date)) end)
                              left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when c2.position_start_date is not null and c2.position_start_date < cl.seniority_date_max  then datediff(to_date(cl.seniority_date_max),to_date(c2.position_start_date)) else datediff(to_date(cl.seniority_date_max),to_date(c1.contract_end_date)) end)
                                                                                   
                       where  1=1
                         and  c1.contract_end_date between '""" + date_inf_transfo + """' and '""" + date_sup_transfo + """'
                         and  c1.contract_end_date < c2.contract_start_date
                         and  c2.contract_start_date <= '""" + date_max_change + """'
                         and  datediff(c2.contract_start_date,c1.contract_end_date) <= """ + delay_change + """
                         and  c1.previous_contract_type is null
               
                      
                    order by  c1.employee_id
                          
                               """

// COMMAND ----------

val df_transfo_rate = spark.sql(query_transfo_rate).filter("date_id = '" + date_id + "'")

// COMMAND ----------

// DBTITLE 1,Contract Transfo Rate Denominator
val query_denom_transfo =  """ 
                       select  
                              null as effectif  
                             ,null as effectif_etp_productive_detailed 
                             ,null as effectif_etp_productive 
                             ,null as effectif_etp_contractuel_detailed  
                             ,null as effectif_etp_contractuel 
                             ,null as effectif_etp_contractuel_total 
                             ,null as effectif_etp_contractuel_detailed_total 
                             ,null as effectif_etp_contractuel_precarite 
                             ,null as effectif_etp_contractuel_cdd 
                             ,null as effectif_etp_contractuel_surcroit
                             ,null as effectif_etp_contractuel_remplacement
                             ,null as effectif_etp_contractuel_ecole 
                             ,null as effectif_present   
                             ,null as active_contract
                             ,null as is_contract
                             ,""" + opendays + """ as opendays 
                             ,null as is_permanent
                             ,null as is_suspension
                             ,null as time_in_position
                             ,null as length_of_service
                             ,null as age
                             ,null as nb_children
                             ,null as fte
                             ,null as paidfte
                             ,null as worker_type 
                             ,null as bonus_target
                             ,null as contractual_pay 
                             ,c.contract_start_date 
                             ,c.contract_end_date
                             ,date_add(c.contract_end_date,1)  as date_out_company
                             ,case when c.contract_end_date is null then null else datediff(c.contract_end_date, c.contract_start_date) end as duree_contract
                             
                             ,null as is_seniority_company_6_months
                             
                             ,null as date_deb_suspension
                             ,null as date_fin_suspension
                             ,null as duree_suspension
                             
                             ,null as position_start_date
                             ,null as hire_date
                             ,null as original_hire_date
                             ,null as effective_hire_date
                             ,null as effective_job_change_date
                             ,null as effective_organization_change_date
                             ,null as effective_suporg_change_date
                             ,null as date_deb_centre_cout
                             ,null as date_fin_centre_cout
                             ,null as date_deb_etablissement
                             ,null as date_fin_etablissement
                             ,null as date_deb_societe
                             ,null as date_fin_societe
                             ,null as date_deb_org
                             ,null as date_fin_org
                             ,null as category_ce
                                  
                             ,coalesce(d.employee_id, -1) as employee_id
                             ,coalesce(ct.contract_type_id, -1) as contract_type_id
                             ,coalesce(wr.worker_rate_id, -1) as worker_rate_id
                             ,case when upper(c.contract_type) = 'VA' or  lower(ct.contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else coalesce(csp.csp_id, -1) end as csp_id
                             ,coalesce(nat.nationality_id, -1) as nationality_id
                             ,coalesce(ag.range_age_id, -1) as range_age_id
                             ,coalesce(sec.seniority_company_id,-1) as seniority_company_id
                             ,coalesce(sep.seniority_position_id, -1) as seniority_position_id
                             ,coalesce(loc.location_id, -1) as location_id
                             ,coalesce(job.job_architecture_id, -1) as job_architecture_id
                             ,coalesce(man.manager_id, -1) as manager_id
                             ,coalesce(so.supervisory_organization_id, -1) as supervisory_organization_id
                             ,-2 as contract_suspension_id
                             ,coalesce(ol.legal_organization_id,'-1') as legal_organization_id
                             ,coalesce(op.operational_organization_id,'-1') as operational_organization_id
                             ,coalesce(mob_in.mobility_in_id, -1) as mobility_in_id
                             ,coalesce(mob_out.mobility_out_id,-1) as mobility_out_id
                             ,coalesce(id.info_dates_id, -1) as info_dates_id
                             ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
                             ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
                             ,-2 as contract_suspension_dates_id
                             ,case when """ + month_id + """  = concat(""" + year_id + """,'01') then concat(""" + last_year_id + """,'1231') 
                                    when """ + date_id + """ = concat(""" + year_id + """,'1231') then """ + date_id + """ end as date_id
                             ,current_timestamp() as recordcreationdate
                             ,'""" + runid + """' as runid

                              ,null as is_transfo
                              ,null as is_transfo_stagiare_cdd
                              ,null as is_transfo_stagiare_cdi
                              ,null as is_transfo_alternant_cdd
                              ,null as is_transfo_alternant_cdi
                              ,null as is_transfo_cdd_cdi
                              ,null as is_transfo_ecole
                              ,case when lower(ct.contract_type_detailed) != 'interim' and c.fte > 0 then 1  else null end as is_denom_transfo
                              
                       from   vw_contract_last_year c
                              inner join vw_d_contract_type ct on c.contract_code = ct.contract_code and lower(ct.precarity) = 'precaire'
                              inner join vw_employee e on c.employee_code = e.employee_code
                              inner join vw_d_employee d on e.employee_code = d.employee_code                            

                              left join vw_d_nationality nat on e.nationality_code = nat.nationality_code
                              left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date('""" + date_id + """','yyyyMMdd'),to_date(e.birth_date),true)/12) end)
                              left join vw_d_location loc on e.location_code = loc.location_code
                              left join vw_d_manager man on e.manager_code = man.manager_code
                              left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code
                              left join vw_d_legal_organization ol on e.legal_organization_code = ol.legal_organization_code
                              left join vw_d_legal_organization_transcoded olt on olt.legal_organization_id = ol.legal_organization_id
                              left join vw_d_operational_organization op on e.operational_organization_code = op.operational_organization_code  
                              left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code
                              
                              left join vw_d_in_out_dates iod on iod.in_out_dates_code = c.in_out_dates_code and iod.org_in_out_dates_code = e.org_in_out_dates_code   
                              left join vw_d_csp csp on c.csp_code = csp.csp_code                    
                              left join vw_d_job_architecture job on c.job_code = job.job_architecture_code
                              left join vw_d_info_dates id on id.info_dates_code = c.info_dates_code                                                                                   
                              left join vw_d_worker_rate wr on wr.worker_rate_code = c.worker_rate_code
                              left join vw_d_mobility_in mob_in on mob_in.mobility_in_code = c.mobility_in_code
                              left join vw_d_mobility_out mob_out on mob_out.mobility_out_code = c.mobility_out_code
                              
                              left join vw_contract_last cl on c.employee_code = cl.employee_code and cl.rank_seniority=1                            
                              left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(c.continous_service_date) then null else datediff(to_date(cl.seniority_date_max),to_date(c.continous_service_date)) end)
                              left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(c.position_start_date) then null else datediff(to_date(cl.seniority_date_max),to_date(c.position_start_date)) end)
                              
                       where  1=1
                         and  c.contract_end_date between '""" + date_inf_transfo + """' and '""" + date_sup_transfo + """'
                   

                    order by  c.employee_id
                          
                               """

// COMMAND ----------

val df_denom_transfo_rate = spark.sql(query_denom_transfo).filter("date_id = '" + date_id + "'")

// COMMAND ----------

// DBTITLE 1,Suspension Dates
spark.sql("""
  select
     c.employee_code
    ,c.contract_suspension_start_date
    ,c.contract_suspension_end_date
    ,1 is_suspension
    ,ifnull(cs.contract_suspension_id,-1) contract_suspension_id
    ,ifnull(csd.contract_suspension_dates_id,-1) contract_suspension_dates_id
  from vw_contract_suspension c
  inner join vw_d_contract_suspension_dates csd on c.contract_suspension_dates_code = csd.contract_suspension_dates_code 
  left join vw_d_contract_suspension cs on c.suspension_contrat_code = cs.contract_suspension_code
  where c.contract_suspension_end_date >= to_date(cast(""" + date_id + """ as string),'yyyyMMdd')
  order by c.employee_code                          
""").createOrReplaceTempView("vw_employee_suspension")

// COMMAND ----------

// DBTITLE 1,Staff Query
val query_staff = """ select  distinct
                              case 
                                  when lower(ct.contract_type_detailed) != 'interim' and c.rank = 1
                                   and not isnull(c.contract_start_date) 
                                   and to_date(c.contract_start_date) <= to_date('""" + date_id + """',"yyyyMMdd") 
                                   and (isnull(c.contract_end_date) 
                                            or ((not isnull(c.contract_end_date) and to_date(c.contract_end_date) >= to_date('""" + date_id + """',"yyyyMMdd"))))
                                    then 1 
                                    
                                  when lower(ct.contract_type_detailed) != 'interim' and c.rank = 2
                                   and not isnull(c.contract_start_date) 
                                   and to_date(c.contract_start_date) <= to_date('""" + date_id + """',"yyyyMMdd") 
                                   and (isnull(c.contract_end_date) 
                                            or ((not isnull(c.contract_end_date) and to_date(c.contract_end_date) >= to_date('""" + date_id + """',"yyyyMMdd"))))
                                   and not isnull(c.next_contract_start_date) 
                                   and to_date(c.next_contract_start_date) > to_date('""" + date_id + """',"yyyyMMdd")  
                                    then 1 
                                    
                                  when lower(ct.contract_type_detailed) != 'interim'
                                    and not isnull(c.contract_start_date) 
                                    and to_date(c.contract_start_date) <= to_date('""" + date_id + """',"yyyyMMdd")
                                    and date_format(c.contract_end_date,"yyyyMM") = '""" + month_id + """'
                                    and not isnull(c.contract_end_date) and to_date(c.contract_end_date) < to_date('""" + date_id + """',"yyyyMMdd") then null
                                    else null end as effectif                            
                                    
                            ,case 
                                  when lower(ct.contract_type_detailed) != 'interim'
                                   then 
                                     case when wd.etp_productive < 0 then 0 else wd.etp_productive end else null end  as effectif_etp_productive_detailed 
                           
                           ,case 
                                  when c.rank=1
                                   then 
                                       case when wdm.etp_productive_base_month < 0 then 0 else wdm.etp_productive_base_month end else null end  as effectif_etp_productive 
                                   
                             ,case 
                                  when lower(ct.contract_type_detailed) != 'interim'
                                   then wd.etp_contractuel else null end  as effectif_etp_contractuel_detailed  
                             
                             ,case 
                                  when c.rank=1
                                   then wdm.etp_contractuel_base_month else null end  as effectif_etp_contractuel 

                              ,case 
                                   when lower(ct.contract_type) in ('cdi', 'cdd', 'stagiaire', 'alternant', 'détaché') and c.rank=1 then
                                    case when wdm.nb_contract_type = 1 then wdm.etp_contractuel_base_month else wd.etp_contractuel end 
                                    else null end  as effectif_etp_contractuel_total 
                                    
                             ,case 
                                   when lower(ct.contract_type_detailed) in ('cdd surcroît', 'cdd remplacement') and c.rank=1 then
                                   case when wdm.nb_contract_type_detailed = 1 then wdm.etp_contractuel_base_month else
                                    wd.etp_contractuel end else null end  as effectif_etp_contractuel_detailed_total 

                             ,case 
                                  when lower(ct.precarity) = 'precaire' and c.rank=1 
                                  then wdm.etp_contractuel_precaire_month else null end as effectif_etp_contractuel_precarite 

                             ,case 
                                  when lower(ct.contract_type) = 'cdd' and c.rank=1
                                   then wdm.etp_contractuel_cdd_month else null end as effectif_etp_contractuel_cdd 

                            ,case 
                                  when lower(ct.contract_type_detailed) = 'cdd surcroît' and c.rank=1
                                   then wdm.etp_contractuel_cdd_surcroit_month else null end as effectif_etp_contractuel_surcroit

                            ,case 
                                  when lower(ct.contract_type_detailed) = 'cdd remplacement' and c.rank=1
                                   then wdm.etp_contractuel_cdd_remplacement_month else null end  as effectif_etp_contractuel_remplacement

                             ,case 
                                  when lower(ct.contract_type) in ('stagiaire', 'alternant') and c.rank=1
                                   then wdm.etp_contractuel_ecole_month else null end  as effectif_etp_contractuel_ecole 

                             ,case 
                                   when lower(ct.contract_type_detailed) != 'interim' and ccc.fte > 0 then 1  else null end as effectif_present   
                             ,case 
                                  when lower(ct.contract_type_detailed) != 'interim'
                                   and not isnull(c.contract_start_date) 
                                   and c.contract_start_date <= to_date('""" + date_id + """',"yyyyMMdd") 
                                   and (isnull(c.contract_end_date) 
                                            or (not isnull(c.contract_end_date) and to_date(c.contract_end_date) >= to_date('""" + date_id + """',"yyyyMMdd")))
                                    then 1 
                                  else null end as active_contract
                              
                            ,case 
                                  when lower(ct.contract_type_detailed) != 'interim'
                                   and not isnull(c.contract_start_date) 
                                   and (date_format(c.contract_start_date,"yyyyMM") <= '""" + month_id + """'
                                   and (isnull(c.contract_end_date) 
                                            or (not isnull(c.contract_end_date) and date_format(c.contract_end_date,"yyyyMM") >= '""" + month_id + """')))
                                    then 1 
                                  else null end as is_contract

                             ,""" + opendays + """ as opendays 

                             ,case when lower(ct.contract_type) = 'cdi' 
                                         and not isnull(c.contract_start_date) 
                                         and c.contract_start_date <= to_date('""" + year_id + """0101','yyyyMMdd')
                                         and (isnull(c.contract_end_date) or c.contract_end_date >= to_date('""" + year_id + """1231','yyyyMMdd')) 
                                         and isnull(esy.has_suspension) then 1 else null end as is_permanent

                             ,es.is_suspension
                             ,case when lower(ct.contract_type_detailed) != 'interim' and ccc.position_start_date is not null then datediff(to_date('""" + date_id + """','yyyyMMdd'),to_date(ccc.position_start_date)) else null end as time_in_position
                             ,case when lower(ct.contract_type_detailed) != 'interim' and ccc.continous_service_date is not null then datediff(to_date('""" + date_id + """','yyyyMMdd'),to_date(ccc.continous_service_date)) else null end as length_of_service
                             ,case when lower(ct.contract_type_detailed) != 'interim' and e.birth_date is not null then floor(months_between(to_date('""" + date_id + """','yyyyMMdd'),to_date(e.birth_date),true)/12) else null end as age
                             ,de.nb_children
                             ,ccc.fte
                             ,ccc.paidfte
                             ,ccc.worker_type 
                             ,ccc.bonus_target
                             ,case 
                                  when lower(ct.contract_type) != 'stagiaire'
                                   then (ccc.total_base_pay/12)*13 else ccc.total_base_pay end  as contractual_pay 
                             ,c.contract_start_date 
                             ,to_timestamp(case when c.contract_end_date  = '2999-12-31' then null else  c.contract_end_date  end) as contract_end_date
                             ,to_timestamp(case when c.contract_end_date  = '2999-12-31' then null else date_add(c.contract_end_date,1) end) as date_out_company
                             ,case when c.contract_end_date is null or c.contract_end_date  = '2999-12-31' then null else datediff(c.contract_end_date, c.contract_start_date) end as duree_contract
                             
                             ,case when sec.range_seniority_company_age >= """ + borne_6_months + """ then 1 else null end as is_seniority_company_6_months
                             
                             ,case when es.is_suspension = 1 then es.contract_suspension_start_date else null end as date_deb_suspension
                             ,case when es.is_suspension = 1 then es.contract_suspension_end_date else null end as date_fin_suspension
                             ,case when es.is_suspension = 1 and es.contract_suspension_end_date is null then null else datediff(es.contract_suspension_end_date, es.contract_suspension_start_date) end as duree_suspension
                             
                             ,to_timestamp(ccc.position_start_date) as position_start_date
                             ,to_timestamp(ccc.hire_date) as hire_date
                             ,to_timestamp(ccc.original_hire_date) as original_hire_date
                             ,to_timestamp(ccc.effective_hire_date) as effective_hire_date
                             ,to_timestamp(ccc.effective_job_change_date) as effective_job_change_date
                             ,to_timestamp(e.effective_organization_change_date) as effective_organization_change_date
                             ,to_timestamp(e.effective_suporg_change_date) as effective_suporg_change_date
                             ,to_timestamp(e.cost_center_start_date) as date_deb_centre_cout
                             ,to_timestamp(e.cost_center_end_date) as date_fin_centre_cout
                             ,c.contract_start_date as date_deb_etablissement
                             ,to_timestamp(case when c.contract_end_date  = '2999-12-31' then null else date_add(c.contract_end_date,1) end) as date_fin_etablissement
                             ,c.contract_start_date as date_deb_societe
                             ,to_timestamp(case when c.contract_end_date  = '2999-12-31' then null else date_add(c.contract_end_date,1) end) as date_fin_societe
                             ,c.contract_start_date as date_deb_org
                             ,to_timestamp(case when c.contract_end_date  = '2999-12-31' then null else date_add(c.contract_end_date,1) end) as date_fin_org
                             
                             ,case when upper(olt.company) = 'CHANEL PARFUMS BEAUTE' and lower(ct.contract_type) = 'alternant' then 'Catégorie A'
                                  when upper(olt.company) = 'CHANEL PARFUMS BEAUTE' and ccc.coefficient_label >=225 and ccc.coefficient_label<=275 then 'Catégorie B'
                                  when upper(olt.company) = 'CHANEL PARFUMS BEAUTE' and ccc.coefficient_label >=300 and ccc.coefficient_label<=360 then 'Catégorie C'
                                  when upper(olt.company) = 'CHANEL PARFUMS BEAUTE' and ccc.coefficient_label >=400 and ccc.coefficient_label<=460 then 'Catégorie D'
                                  when upper(olt.company) = 'CHANEL PARFUMS BEAUTE' and ccc.coefficient_label >=500  then 'Catégorie E'
                                  when upper(olt.libelle_etablissement) in ("CHANEL NEUILLY","CHANEL PANTIN 2") and upper(op.division_consolidated) <> "EUROPE" and ccc.coefficient_label<=300  then 'Catégorie 1'
                                  when upper(olt.libelle_etablissement) in ("CHANEL NEUILLY","CHANEL PANTIN 2") and upper(op.division_consolidated) <> "EUROPE" and ccc.coefficient_label >=325 and ccc.coefficient_label<=460  then 'Catégorie 2'
                                  when upper(olt.libelle_etablissement) in ("CHANEL NEUILLY","CHANEL PANTIN 2") and upper(op.division_consolidated) <> "EUROPE" and ccc.coefficient_label >=550  then 'Catégorie 3'
                                  else null end as category_ce
                                  
                             ,coalesce(d.employee_id, -1) as employee_id
                             ,coalesce(ct.contract_type_id, -1) as contract_type_id
                             ,coalesce(wr.worker_rate_id, -1) as worker_rate_id
                             ,case when upper(c.contract_type) = 'VA' or  lower(ct.contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else coalesce(csp.csp_id, -1) end as csp_id
                             ,coalesce(nat.nationality_id, -1) as nationality_id
                             ,coalesce(ag.range_age_id, -1) as range_age_id
                             ,coalesce(sec.seniority_company_id,-1) as seniority_company_id
                             ,coalesce(sep.seniority_position_id, -1) as seniority_position_id
                             ,coalesce(loc.location_id, -1) as location_id
                             ,coalesce(job.job_architecture_id, -1) as job_architecture_id
                             ,coalesce(man.manager_id, -1) as manager_id
                             ,coalesce(so.supervisory_organization_id, -1) as supervisory_organization_id
                             ,coalesce(es.contract_suspension_id, -2) as contract_suspension_id
                             ,coalesce(ol.legal_organization_id,'-1') as legal_organization_id
                             ,coalesce(op.operational_organization_id,'-1') as operational_organization_id
                             ,coalesce(mob_in.mobility_in_id, -1) as mobility_in_id
                             ,coalesce(mob_out.mobility_out_id,-1) as mobility_out_id
                             ,coalesce(id.info_dates_id, -1) as info_dates_id
                             ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
                             ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
                             ,coalesce(es.contract_suspension_dates_id, -2) as contract_suspension_dates_id
                             ,""" + date_id + """ as date_id
                             ,current_timestamp() as recordcreationdate
                             ,'""" + runid + """' as runid
                             ,null as is_transfo
                             ,null as is_transfo_stagiare_cdd
                             ,null as is_transfo_stagiare_cdi
                             ,null as is_transfo_alternant_cdd
                             ,null as is_transfo_alternant_cdi
                             ,null as is_transfo_cdd_cdi
                             ,null as is_transfo_ecole
                             ,null as is_denom_transfo
                             
                             
                         
                       from vw_employee e
                            inner join vw_contract c on e.employee_code = c.employee_code
                            inner join vw_d_employee d on e.employee_code = d.employee_code                            
                            
                            left join vw_d_nationality nat on e.nationality_code = nat.nationality_code
                            left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date('""" + date_id + """','yyyyMMdd'),to_date(e.birth_date),true)/12) end)
                            left join vw_d_location loc on e.location_code = loc.location_code
                            left join vw_d_manager man on e.manager_code = man.manager_code
                            left join vw_d_legal_organization ol on e.legal_organization_code = ol.legal_organization_code
                            left join vw_d_legal_organization_transcoded olt on olt.legal_organization_id = ol.legal_organization_id
                            left join vw_d_operational_organization op on e.operational_organization_code = op.operational_organization_code                            
                            left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code
                            left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code                                 
                            left join vw_d_employee_dependent de on de.employee_id = d.employee_id
                            
                            left join vw_d_in_out_dates iod on iod.in_out_dates_code = c.in_out_dates_code 
                                                            and iod.org_in_out_dates_code = e.org_in_out_dates_code
                            left join vw_d_mobility_in mob_in on mob_in.mobility_in_code = c.mobility_in_code
                            left join vw_d_mobility_out mob_out on mob_out.mobility_out_code = c.mobility_out_code
                            left join vw_employee_suspension es on es.employee_code = e.employee_code
                            left join vw_contract_suspension_year esy on esy.employee_code = e.employee_code                                                                                                             
                            
                            left join vw_contract_job_change ccc on ccc.employee_code = c.employee_code 
                                                                and c.contract_start_date = ccc.contract_start_date 
                                                                and ccc.rank=1   
                            left join vw_d_worker_rate wr on ccc.worker_rate_code = wr.worker_rate_code                                             
                            left join vw_d_csp csp on ccc.csp_code = csp.csp_code                                            
                            left join vw_d_contract_type ct on c.contract_type_code = ct.contract_type_code
                                                           and ccc.collective_agreement_code = ct.collective_agreement_code
                            left join vw_d_job_architecture job on ccc.job_title_code = job.job_title_code    
                                                               and coalesce(ccc.grade_code, -1) = coalesce(job.grade_code, -1)
                            left join vw_d_info_dates id on id.company_dates_code = ccc.company_dates_code 
                                                         and id.contract_dates_code = c.contract_dates_code
                            
                            left join vw_contract_last cl on c.employee_code = cl.employee_code and c.contract_start_date = cl.contract_start_date
                            left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(ccc.continous_service_date) then null else datediff(to_date(cl.seniority_date_max),to_date(ccc.continous_service_date)) end)
                            left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(ccc.position_start_date) then null else datediff(to_date(cl.seniority_date_max),to_date(ccc.position_start_date)) end)
                                                                                                                                       
                            left join vw_employee_workingdays wd on e.employee_code = wd.employee_code and c.contract_start_date = wd.contract_start_date                            
                            left join vw_employee_workingdays_month wdm on e.employee_code = wdm.employee_code
                                  
                   """

// COMMAND ----------

// DBTITLE 1,Staff Results by filtering on effectif_etp_contractuel_detailed > 0
//val df_staff_results = spark.sql(query_staff).filter(col("effectif") === 1 || col("effectif") === 0 || col("effectif_etp_contractuel") === 1)
val df_daily_results = spark.sql(query_staff).filter("effectif = 1 or effectif_etp_contractuel_detailed > 0")


// COMMAND ----------

val df_staff_results = df_daily_results
                            .union(df_transfo_rate)
                            .union(df_denom_transfo_rate)
df_staff_results.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Delete data from table f_staff for the loading date
val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """delete from staff.f_staff where date_id = """ + date_id
val res = stmt.execute(query_delete)

//connection.close()

// COMMAND ----------

// DBTITLE 1,Insert data on the staff table
df_staff_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "staff.f_staff", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Statistics about data read and inserted
val read_records = df_employee_read.count().toInt //count the number of read records
val inserted_records = df_staff_results.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from Cache
df_employee_read.unpersist
df_staff_results.unpersist

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select effective_job_change_date,csp,collective_agreement_level,collective_agreement_group,filename,contract_start_date,contract_end_date,* from hr.contract where employee_id = 'W00011516' order by record_start_date desc