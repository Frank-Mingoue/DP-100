// Databricks notebook source
//init widget
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val historical_data_end_date = dbutils.widgets.get("historical_data_end_date");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "50") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.databricks.optimizer.rangeJoin.binSize", "5")
//sc.getExecutorStorageStatus.length - 1

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

val historical_date_end_date_value = LocalDate.parse(historical_data_end_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))


// COMMAND ----------

// MAGIC %md ## 1- Read Data

// COMMAND ----------

// MAGIC %md ##### Contract

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// MAGIC %md ###### Job Archi

// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_job_architecture", connectionproperties).createOrReplaceTempView("vw_d_job_archi")//.select("job_architecture_id","job_title","grade","grade_label")
val df_job_archi=spark.table("vw_d_job_archi").filter($"current_version" === 1)
//Get grade to transcode data changes
val df_grade=df_job_archi.select("grade","grade_label").distinct
//display(df_job_archi)

// COMMAND ----------

// MAGIC %md ##### Contract Type

// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_contract_type", connectionproperties).select("contract_type_id","contract_type_code","classification_collective_agreement","collective_agreement_reference_label","collective_agreement_reference","contract_type","contract_nature","contract_nature_label","current_version","contract_code","collective_agreement_code","contract_type_code").filter($"current_version" === 1).createOrReplaceTempView("vw_d_contract_type")
val df_contract_type=spark.table("vw_d_contract_type")

// COMMAND ----------

//contract start
val bycontract_start_date = Window.partitionBy("employee_code","employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc)
val df_contracthr_start = spark.table("hr.contract")
// last version of each contract
.withColumn("rank",rank() over bycontract_start_date).filter($"rank" === 1).drop($"rank")
.drop($"record_start_date").withColumn("record_start_date",$"contract_start_date")
.withColumn("contract_end_date",coalesce($"contract_end_date",to_date(lit("2999-12-31"))))
.orderBy(asc("employee_code"),asc("record_start_date"))
df_contracthr_start.cache()

//last contract end date
val df_contract_last_end_date = df_contracthr_start.groupBy("employee_code","employee_id","france_payroll_id")
.agg(max("contract_end_date") as "contract_end_date")
.orderBy(asc("employee_code"))

//contract change
val bycontract_date = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"effective_job_change_date")
val bycontract_version = Window.partitionBy("employee_code","employee_id","france_payroll_id","effective_job_change_date").orderBy($"record_start_date".desc)
val df_contracthr_change = spark.table("hr.contract")
.select("employee_code","employee_id","france_payroll_id"
,"contract_start_date"
,"contract_type_label"
,"collective_agreement_reference_label"
,"worker_type"
,"collective_agreement_group"
,"collective_agreement_level"
,"coefficient_label"
,"fte"
,"worker_rate_code"
,"contract_code"
,"collective_agreement_code"        
,"effective_job_change_date"
,"record_start_date"
).filter($"contract_start_date".isNotNull)
// last version for each effective job change date
.withColumn("rank",rank() over bycontract_version).filter($"rank" === 1).drop("rank","record_start_date")
// retrieves only version with changes
.withColumn("hashkey",concat_ws("|",
                                $"contract_type_label"
                                ,$"collective_agreement_reference_label"
                                ,$"worker_type"
                                ,$"collective_agreement_group"
                                ,$"collective_agreement_level"
                                ,$"coefficient_label"
                                ,$"fte"
                                ,$"worker_rate_code"
                                ,$"contract_code"
                                ,$"collective_agreement_code"
                               ))
.withColumn("previous_hashkey",lag($"hashkey",1) over bycontract_date)
.filter($"previous_hashkey" =!= $"hashkey" or $"previous_hashkey".isNull)
.drop("previous_hashkey","hashkey")
// generate record start and end date to manage version of each contract
.orderBy("employee_code","effective_job_change_date").withColumn("record_end_date",date_sub(lead($"effective_job_change_date",1) over bycontract_date,1))
.withColumn("record_start_date",$"effective_job_change_date")
.withColumn("record_end_date",coalesce($"record_end_date",to_date(lit("2999-12-31"))))
.orderBy(asc("employee_code"),asc("record_start_date"))
df_contracthr_change.cache()


//contract compensation
val bycomp_version = Window.partitionBy("employee_code","employee_id","france_payroll_id","effective_compensation_change_date").orderBy($"record_start_date".desc)
val bycomp_date = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"effective_compensation_change_date")
val df_contracthr_comp = spark.table("hr.contract").as("c")
.select("employee_code","employee_id","france_payroll_id","grade","total_base_pay","effective_compensation_change_date","record_start_date","contract_code").filter($"effective_compensation_change_date".isNotNull)
// last version for each effective compensation change date
.withColumn("rank",rank() over bycomp_version).filter($"rank" === 1).drop("rank","record_start_date")
  //Salary
  .join(df_contract_type.as("contract_type"),
        ($"c.contract_code"===$"contract_type.contract_code"),"left")
  .withColumn("comp",when(lower($"contract_type.contract_type") === ("stagiaire"),$"total_base_pay").otherwise(($"total_base_pay"/12)*13))
  .withColumn("prev_comp_date",lag($"effective_compensation_change_date",1) over bycomp_date)
// retrieves only version with changes
.withColumn("hashkey",concat_ws("|",$"grade",$"total_base_pay"))
.withColumn("previous_hashkey",lag($"hashkey",1) over bycomp_date)
.filter($"previous_hashkey" =!= $"hashkey" or $"previous_hashkey".isNull)
.drop("previous_hashkey","hashkey")
// manage historical data
.withColumn("prev_comp_date",lag($"effective_compensation_change_date",1) over bycomp_date)
.withColumn("prev_comp",lag($"comp",1) over bycomp_date)
.withColumn("next_comp",lead($"comp",1) over bycomp_date)
.withColumn("effective_compensation_change_date",when($"comp" - $"prev_comp" < 1.0 && $"effective_compensation_change_date"<= historical_date_end_date_value ,$"prev_comp_date" ).otherwise($"effective_compensation_change_date"))
.withColumn("effective_compensation_change_date",when($"comp" - $"prev_comp" < 1.0 && $"effective_compensation_change_date"<= historical_date_end_date_value ,$"prev_comp_date" ).otherwise($"effective_compensation_change_date"))
.filter($"next_comp" - $"comp" > 1.0 || ($"next_comp" - $"comp" < 1.0 && $"effective_compensation_change_date">= historical_date_end_date_value) || $"next_comp".isNull)
// generate record start and end date to manage version of each contract
.withColumn("record_end_date",date_sub(lead($"effective_compensation_change_date",1) over bycomp_date,1))
.withColumn("record_start_date",$"effective_compensation_change_date")
.withColumn("record_end_date",coalesce($"record_end_date",to_date(lit("2999-12-31"))))
.orderBy(asc("employee_code"),asc("record_start_date"))
df_contracthr_comp.cache()


//job_change
val byjob_date = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"effective_job_change_date")//job_change
val byjob_version = Window.partitionBy("employee_code","employee_id","france_payroll_id","effective_job_change_date").orderBy($"record_start_date".desc)
val df_employeehr_job = spark.table("hr.contract").as("employee")
.select("employee_code","employee_id","france_payroll_id","csp","csp_code","job_title","effective_job_change_date","record_start_date","contract_start_date").filter($"effective_job_change_date".isNotNull)
// last version for each effective compensation change date
.withColumn("rank",rank() over byjob_version).filter($"rank" === 1).drop("rank","record_start_date")
// retrieves only version with changes
.withColumn("hashkey",concat_ws("|",$"csp",$"csp_code",$"job_title"))
.withColumn("previous_hashkey",lag($"hashkey",1) over byjob_date)
.filter($"previous_hashkey" =!= $"hashkey" or $"previous_hashkey".isNull)
.drop("previous_hashkey","hashkey")
// generate record start and end date to manage version of each contract
.withColumn("record_end_date",date_sub(lead($"effective_job_change_date",1) over byjob_date,1))
.withColumn("record_start_date",$"effective_job_change_date")
.withColumn("record_end_date",coalesce($"record_end_date",to_date(lit("2999-12-31"))))
.orderBy(asc("employee_code"),asc("record_start_date"))
df_employeehr_job.cache()



// COMMAND ----------

// MAGIC %md ##### Employee

// COMMAND ----------

 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val byorg_version = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"cost_center_start_date")//org_change
val by_orgversion = Window.partitionBy("employee_code","employee_id","france_payroll_id","cost_center_start_date").orderBy($"record_start_date".desc)
val by_orgdate = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"record_start_date")

val df_employeehr_ope_org = spark.table("hr.employee")
// based on WD organization date
.withColumn("cost_center_start_date", $"effective_organization_change_date")
.withColumn("rank",rank() over by_orgversion).filter($"rank" === 1).drop($"rank")
.select("employee_code","employee_id","france_payroll_id","operational_organization_code","legal_organization_code","cost_center_code","cost_center_start_date").filter($"cost_center_code".isNotNull)
// retrieves only version with changes
//.withColumn("previous_cc",lag($"cost_center_code",1) over byorg_version)
//.filter($"previous_cc" =!= $"cost_center_code" or $"previous_cc".isNull)
//.drop($"previous_cc")
// generate record start and end date to manage version of each contract
.withColumnRenamed("cost_center_start_date","record_start_date")
.withColumn("record_end_date",date_sub(lead($"record_start_date",1) over by_orgdate,1))
.withColumn("record_end_date",coalesce($"record_end_date",to_date(lit("2999-12-31"))))
.orderBy(asc("employee_code"),asc("record_start_date"))
df_employeehr_ope_org.cache()

val df_employeehr_org = spark.table("hr.employee")
// based on WD organization date
.withColumn("cost_center_start_date", $"effective_organization_change_date")
.select("employee_code","employee_id","france_payroll_id","legal_organization_code","cost_center_code","cost_center_start_date").filter($"cost_center_code".isNotNull)
// retrieves only version with changes
.withColumn("previous_cc",lag($"cost_center_code",1) over byorg_version)
.filter($"previous_cc" =!= $"cost_center_code" or $"previous_cc".isNull)
.drop($"previous_cc")
// generate record start and end date to manage version of each contract
.withColumnRenamed("cost_center_start_date","record_start_date")
.withColumn("record_end_date",date_sub(lead($"record_start_date",1) over by_orgdate,1))
.withColumn("record_end_date",coalesce($"record_end_date",to_date(lit("2999-12-31"))))
.orderBy(asc("employee_code"),asc("record_start_date"))
df_employeehr_org.cache()


// COMMAND ----------

// MAGIC %md ##### Contract suspension

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract_suspension")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract_suspension")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val df_contractsusp_read = spark.table("hr.contract_suspension").select("employee_code","employee_id","france_payroll_id","contract_suspension_start_date","contract_suspension_end_date","contract_suspension_dates_code","suspension_contrat_code").withColumn("record_start_date",$"contract_suspension_start_date")
.orderBy(asc("employee_code"),asc("contract_suspension_start_date"))

df_contractsusp_read.cache()


// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_employee", connectionproperties).filter($"current_version" === 1).dropDuplicates("matricule_workday","matricule_hra").createOrReplaceTempView("vw_d_employee")
val df_staff_employee=spark.table("vw_d_employee")

// COMMAND ----------

// MAGIC %md ##### Legal Organization

// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_legal_organization", connectionproperties).select("legal_organization_id","legal_organization_code","companycode","company","code_etablissement","libelle_etablissement",
                                                                                    "cost_center_code", "cost_center_label","current_version").filter($"current_version" === 1)
                                                                                    .createOrReplaceTempView("vw_d_legal_organization")
val df_legal_organization=spark.table("vw_d_legal_organization")
//display(df_legal_organization)

// COMMAND ----------

// MAGIC %md ##### Operationnal Organization

// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_operational_organization", connectionproperties).select("operational_organization_id",
                                                                                          "operational_organization_code","current_version").filter($"current_version" === 1).createOrReplaceTempView("vw_d_operational_organization")
val df_ope_organization = spark.table("vw_d_operational_organization")
//display(df_ope_organization)

// COMMAND ----------

// MAGIC %md ##### Staff csp

// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_csp", connectionproperties).select("csp_id","cadre_non_cadre","csp","professional_category_reference","professional_category_name","csp_code","current_version").filter($"current_version" === 1).createOrReplaceTempView("vw_d_csp")
val df_csp =spark.table("vw_d_csp")
//display(df_csp)

// COMMAND ----------

// MAGIC %md ##### Mobilite

// COMMAND ----------

spark.read.jdbc(jdbcurl, "mobility.d_mobility_in", connectionproperties).select("mobility_in_id","event_classification_subcategory_label","mobility_in_code","current_version").filter($"current_version" === 1).createOrReplaceTempView("vw_d_mobility_in")
val df_mobility_in=spark.table("vw_d_mobility_in")
//display(df_mobility_in)

// COMMAND ----------

spark.read.jdbc(jdbcurl, "mobility.d_mobility_out", connectionproperties).select("mobility_out_id","mobility_out_code","local_termination_reason","current_version").filter($"current_version" === 1).createOrReplaceTempView("vw_d_mobility_out")
val df_mobility_out=spark.table("vw_d_mobility_out")
//display(df_mobility_out)

// COMMAND ----------

// MAGIC %md ##### Suspension

// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_contract_suspension", connectionproperties).filter($"current_version" === 1).createOrReplaceTempView("vw_d_contract_suspension")
val df_suspension=spark.table("vw_d_contract_suspension")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_contract_suspension_dates", connectionproperties).filter($"current_version" === 1).createOrReplaceTempView("vw_d_contract_suspension_dates")
val df_suspension_date = spark.table("vw_d_contract_suspension_dates")
//display(df_suspension_date)

// COMMAND ----------

// MAGIC %md ##2- Union of Situation between contract & employe

// COMMAND ----------



val df_contract_employee_situation =  df_contracthr_start.select("employee_code"
                                                  ,"record_start_date")
                                    .union(df_contracthr_change.select("employee_code"
                                                  ,"record_start_date"
                                                  ))
                                    .union(df_contracthr_comp.select("employee_code"
                                                  ,"record_start_date"
                                                  ))
                                    .union(df_employeehr_org.as("org")
                                           .join(
                                           df_contract_last_end_date.select("employee_code","contract_end_date").as("c"),$"org.employee_code" === $"c.employee_code")
                                           .filter($"org.record_start_date" <= $"c.contract_end_date")
                                           .select("org.employee_code","record_start_date")
                                          )
                                    .union(df_employeehr_job.select("employee_code","record_start_date")
                                          )
                                    .union(df_contractsusp_read.as("susp").join(
                                           df_contract_last_end_date.select("employee_code","contract_end_date").as("c"),$"susp.employee_code" === $"c.employee_code")
                                           .filter($"record_start_date" <= $"c.contract_end_date")
                                           .select("susp.employee_code","record_start_date")
                                          )
                                    //generate row for suspension end
                                   .union(df_contractsusp_read.as("susp").join(
                                           df_contract_last_end_date.select("employee_code","contract_end_date").as("c"),$"susp.employee_code" === $"c.employee_code")
                                           .withColumn("record_start_date",date_add($"contract_suspension_end_date",1))
                                           .filter($"record_start_date" <= $"c.contract_end_date")
                                           .select("susp.employee_code","record_start_date")
                                                  )
                                    .distinct().filter($"record_start_date".isNotNull)
                                    .orderBy(asc("employee_code"),asc("record_start_date"))

df_contract_employee_situation.cache()


// COMMAND ----------

// DBTITLE 1,Get Operational Org
val joinCondition_orga = /*when($"org.record_end_date".isNull,($"org.employee_code"=== $"emp.employee_code"  
                                      and $"emp.record_start_date" >=  $"org.record_start_date"
                                      and $"emp.record_start_date" <=  "2999-01-10T23:28:29.904+0000")
                                      )
    .otherwise*/
    ($"o.employee_code"=== $"e.employee_code"  
//                                      and $"e.record_start_date" >=  $"o.record_start_date"
//                                      and $"e.record_start_date" <=  $"o.record_end_date"
    ) 

val window = Window.partitionBy("e.employee_code","e.record_start_date").orderBy($"o.record_start_date".desc,$"o.cost_center_code".asc)

val df_employee_ope_temp = df_contract_employee_situation.repartition($"employee_code").as("e").join(df_employeehr_ope_org.repartition($"employee_code").as("o"),joinCondition_orga,"left")

val df_employee_ope_org = df_employee_ope_temp
.filter(($"e.record_start_date" >=  $"o.record_start_date" and $"e.record_start_date" <=  $"o.record_end_date") or $"o.employee_code".isNull)
.withColumn("rank",rank() over window).filter($"rank" === 1).drop($"rank")
.select("e.employee_code","e.record_start_date","o.operational_organization_code","o.legal_organization_code")
.filter($"e.record_start_date".isNotNull)

df_employee_ope_org.cache()

// COMMAND ----------

val window = Window.partitionBy("employee_code").orderBy($"record_start_date".desc)

val df_contract_employee_situation_ordered = df_contract_employee_situation.withColumn("record_end_date", lag($"record_start_date", 1, null).over(window) ).withColumn("record_end_date", $"record_end_date" - expr("INTERVAL 1 DAYS")).orderBy(asc("employee_code"),asc("record_start_date")).cache()

// COMMAND ----------

// MAGIC %md ## 3- Merge data

// COMMAND ----------

// DBTITLE 1,Contract End
val by_contractend_orgdate = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"record_start_date")
val by_contractend_lastorgdate = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"record_start_date").rowsBetween(Window.unboundedPreceding,Window.unboundedFollowing)
val by_contractend_orgversion = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"cost_center_start_date")//job_change


val df_contractend_org = spark.table("hr.employee").filter($"cost_center_code".isNotNull)
.withColumn("cost_center_start_date", $"effective_organization_change_date")
.select("employee_code","employee_id","france_payroll_id","operational_organization_code","legal_organization_code","cost_center_start_date","cost_center_code")
//.withColumn("previous_cc",lag($"cost_center_code",1) over by_contractend_orgversion)
//.filter($"previous_cc" =!= $"cost_center_code" or $"previous_cc".isNull)
//.drop($"previous_cc")
.withColumnRenamed("cost_center_start_date","record_start_date")
//.groupBy("employee_code","employee_id","france_payroll_id","operational_organization_code","legal_organization_code","cost_center_code")
//agg(min("cost_center_start_date") as "record_start_date")
.withColumn("record_end_date",date_sub(lead($"record_start_date",1) over by_contractend_orgdate,1))
.withColumn("record_end_date",coalesce($"record_end_date",to_date(lit("2999-12-31"))))


val joinCondition_org = when($"org.record_end_date".isNull,($"org.employee_code"=== $"contract_end.employee_code"  
                                      and $"contract_end.contract_end_date" >=  $"org.record_start_date"
                                      and $"contract_end.contract_end_date" <=  "2999-01-10T23:28:29.904+0000")
                                      )
    .otherwise($"org.employee_code"=== $"contract_end.employee_code"  
                                      and $"contract_end.contract_end_date" >=  $"org.record_start_date"
                                      and $"contract_end.contract_end_date" <=  $"org.record_end_date") 

val window = Window.partitionBy("contract_end.employee_code","contract_end.contract_end_date").orderBy($"org.record_start_date".desc,$"org.cost_center_code".asc)

val df_contract_end = df_contracthr_start.as("contract_end").filter($"contract_end_date".isNotNull and $"contract_end_date" < "2999-12-31" ).join(df_contractend_org.as("org"),joinCondition_org,"left").withColumn("rank",rank() over window).filter($"rank" === 1).drop($"rank").select(
  "contract_end.employee_code","contract_end.employee_id","contract_end.france_payroll_id","contract_end.csp_code","contract_end.contract_code","contract_end.job_code","contract_end.local_termination_reason","contract_end.mobility_in_code","contract_end.mobility_out_code","org.operational_organization_code","org.legal_organization_code","contract_end.event_classification_subcategory_label","contract_end.collective_agreement_reference_label","contract_end.total_base_pay","contract_end.contract_end_date","contract_end.fte")

//employee id
.join(df_staff_employee.as("staff_employee"),$"contract_end.employee_code"===$"staff_employee.employee_code")

//mobility out
.join(df_mobility_out.as("mobility_out"),
   ($"contract_end.mobility_out_code"===$"mobility_out.mobility_out_code"),
   "left")
//mobility in
.join(df_mobility_in.as("mobility_in"),
   ($"contract_end.mobility_in_code"===$"mobility_in.mobility_in_code"),
   "left")

//contract_type
.join(df_contract_type.as("contract_type"),
      ($"contract_end.contract_code"===$"contract_type.contract_code"),"left")    

//csp code
.join(df_csp.as("csp"),
     ($"contract_end.csp_code"===$"csp.csp_code"),
     "left")

//job code
.join(df_job_archi.as("job"),
     ($"contract_end.job_code"===$"job.job_architecture_code"),
     "left")

//legal_organization
.join(df_legal_organization.as("legal"),
     ($"org.legal_organization_code"===$"legal.legal_organization_code"),"left")  
//operational organization
.join(df_ope_organization.as("ope"),
     ($"org.operational_organization_code"===$"ope.operational_organization_code"),"left")

                                //Presence : ajout suspension contrat
                                .withColumn("presence", lit("Sorti"))

                                // salaire contractuel
                                .withColumn("salaire_contractuel",when(lower($"contract_type.contract_type") === ("stagiaire"),$"contract_end.total_base_pay").otherwise(($"contract_end.total_base_pay"/12)*13))
                                //default values
                                .withColumn("record_start_date",date_add($"contract_end.contract_end_date",1))

                                //default values
                                .withColumn("contract_suspension_id",lit(-1))
                                .withColumn("contract_suspension_dates_id",lit(-1))
                                .withColumn("suspension_contrat_code",lit(null))
                                .withColumn("libelle_motif",lit(null))
                                .withColumn("contract_suspension_start_date",lit(null))
                                .withColumn("contract_suspension_end_date",lit(null))

                                //final select
                                .select("contract_end.employee_code",//id employee
                                        "staff_employee.employee_id",//id_employee
                                        "staff_employee.matricule_workday",
                                        "staff_employee.matricule_hra",
                                        "record_start_date",//date_effet
                                        "presence",//presence,
                                        "legal.legal_organization_id",//id legal organization
                                        "legal.companycode",//company-societe
                                        "legal.company",//company-societe
                                        "legal.code_etablissement",//etablissement juridique
                                        "legal.libelle_etablissement",//etablissement juridique
                                        "legal.cost_center_code",//Centre de cout
                                        "legal.cost_center_label",//centre de cout
                                        "ope.operational_organization_id",
                                        "contract_end.collective_agreement_reference_label",//convention collective
                                        "contract_type.contract_nature",//Nature du contrat
                                        "contract_type.contract_nature_label",//Nature du contrat
                                        "contract_end.fte",//Taux de travail contractuel
                                        "csp.csp_id",
                                        "csp.csp_code",//csp
                                        "csp.csp",//csp
                                        "salaire_contractuel",//salaire contractuel
                                        "job.grade_label",//grade
                                        "contract_type.classification_collective_agreement",//classification convention collective
                                        "job.job_architecture_id",
                                        "contract_end.job_code",//Poste
                                        "job.job_title",//poste
                                        "mobility_in.mobility_in_id",
                                        "contract_end.event_classification_subcategory_label",//motif etnree
                                        "mobility_out.mobility_out_id",
                                        "contract_end.local_termination_reason",//motif sortie
                                        "contract_suspension_id",
                                        "suspension_contrat_code",//type suspension contrat
                                        "libelle_motif",
                                        "contract_suspension_dates_id",
                                        "contract_suspension_start_date",//date suspension contrat debut
                                        "contract_suspension_end_date"//date suspensions contrat fin
                                       )

                                       //null value
                                       .na.fill(-1,Array("legal_organization_id"))
                                       .na.fill(-1,Array("csp_id"))
                                      .na.fill(-1,Array("operational_organization_id"))
                                      .na.fill(-1,Array("mobility_in_id"))
                                      .na.fill(-1,Array("mobility_out_id"))
                                      .na.fill(-1,Array("job_architecture_id"))
                                      .distinct()
                                      
                                      //.withColumnRenamed("collective_agreement_reference_label","collective_agreement_reference")
                                      //.withColumnRenamed("classification_collective_agreement","classification_convention_collective")
                                      //.withColumnRenamed("contract_nature","contract_type")
                                      //.withColumnRenamed("contract_nature_label","contract_type_label")
                                      //.withColumnRenamed("grade_label","grade")
         

// COMMAND ----------

//df_contracthr_start
//df_contracthr_change
//df_contracthr_comp
//df_contractsusp_read
//df_employeehr_org
//df_employeehr_job


val joinConditionContract_start = when($"contract_start.contract_end_date".isNull,($"contract_employee.employee_code"=== $"contract_start.employee_code"  
                                      and $"contract_employee.record_start_date" >=  $"contract_start.contract_start_date"
                                      and $"contract_employee.record_start_date" <=  "2999-12-31")
                                      )
    .otherwise($"contract_employee.employee_code"=== $"contract_start.employee_code"  
                                      and $"contract_employee.record_start_date" >=  $"contract_start.contract_start_date"
                                      and $"contract_employee.record_start_date" <=  $"contract_start.contract_end_date") 

val joinConditionContract_change = when($"contract_change.record_end_date".isNull,($"contract_employee.employee_code"=== $"contract_change.employee_code"  
                                      and $"contract_employee.record_start_date" >=  $"contract_change.record_start_date"
                                      and $"contract_employee.record_start_date" <=  "2999-12-31")
                                      )
    .otherwise($"contract_employee.employee_code"=== $"contract_change.employee_code"  
                                      and $"contract_employee.record_start_date" >=  $"contract_change.record_start_date"
                                      and $"contract_employee.record_start_date" <=  $"contract_change.record_end_date") 


val joinConditionContract_comp = when($"contract_comp.record_end_date".isNull,($"contract_employee.employee_code"=== $"contract_comp.employee_code"  
                                      and $"contract_employee.record_start_date" >=  $"contract_comp.record_start_date"
                                      and $"contract_employee.record_start_date" <=  "2999-12-31")
                                      )
    .otherwise($"contract_employee.employee_code"=== $"contract_comp.employee_code"  
                                      and $"contract_employee.record_start_date" >=  $"contract_comp.record_start_date"
                                      and $"contract_employee.record_start_date" <=  $"contract_comp.record_end_date") 

val joinConditionContract_susp = ($"contract_employee.employee_code" === $"contract_susp.employee_code"  
                                      and 
                                      (($"contract_employee.record_start_date" >=  $"contract_susp.record_start_date"
                                      and $"contract_employee.record_end_date" <=  $"contract_susp.contract_suspension_end_date")
                                       or
                                      ($"contract_employee.record_start_date" >= $"contract_susp.record_start_date"
                                      and $"contract_employee.record_end_date" >=  $"contract_susp.contract_suspension_end_date"
                                      and $"contract_employee.record_start_date" <=  $"contract_susp.contract_suspension_end_date"
                                      )
//                                       or
//                                       (
//                                         $"contract_employee.record_start_date" >= $"contract_susp.record_start_date"
//                                        and $"contract_employee.record_end_date".isNull
//                                       )
                                      ))
/*
val joinConditionEmployee_org = when($"employee_org.record_end_date".isNull,($"contract_employee.employee_code"=== $"employee_org.employee_code"  
                                      and $"contract_employee.record_start_date" >=  $"employee_org.record_start_date"
                                      and $"contract_employee.record_start_date" <=  "2999-12-31")
                                      )
    .otherwise($"contract_employee.employee_code"=== $"employee_org.employee_code"  
                                      and $"contract_employee.record_start_date" >=  $"employee_org.record_start_date"
                                      and $"contract_employee.record_start_date" <=  $"employee_org.record_end_date") 
*/
val joinConditionEmployee_job = when($"employee_job.record_end_date".isNull,($"contract_employee.employee_code"=== $"employee_job.employee_code"  
                                      and $"contract_employee.record_start_date" >=  $"employee_job.record_start_date"
                                      and $"contract_employee.record_start_date" <=  "2999-12-31")
                                      )
    .otherwise($"contract_employee.employee_code"=== $"employee_job.employee_code"  
                                      and $"contract_employee.record_start_date" >=  $"employee_job.record_start_date"
                                      and $"contract_employee.record_start_date" <=  $"employee_job.record_end_date") 

val df_contract_employee = df_contract_employee_situation_ordered.as("contract_employee")
                                .join(df_staff_employee.as("staff_employee"),
                                     $"contract_employee.employee_code"===$"staff_employee.employee_code")

                                //contract_start
                                .join(df_contracthr_start.as("contract_start"),
                                      joinConditionContract_start,
                                     "left")  
                                //mobility in
                                .join(df_mobility_in.as("mobility_in"),
                                     ($"contract_start.mobility_in_code"===$"mobility_in.mobility_in_code"),
                                     "left")

                                //contract_change
                                .join(df_contracthr_change.as("contract_change"),
                                      joinConditionContract_change,
                                     "left")  
                               //contract_type
                               .join(df_contract_type.as("contract_type"),
                                     ($"contract_start.contract_code"===$"contract_type.contract_code"),
                                     "left")                                  
                               //contract_type_change
                               .join(df_contract_type.as("contract_type_change"),
                                     ($"contract_change.contract_code"===$"contract_type_change.contract_code"),
                                     "left")                                  
                                //contract_comp
                                .join(df_contracthr_comp.as("contract_comp"),
                                      joinConditionContract_comp,
                                     "left")  
                                .join(df_grade.as("grd"),
                                      $"grd.grade" === $"contract_comp.grade",
                                     "left")  

                                //contract_suspension
                                .join(df_contractsusp_read.as("contract_susp"),
                                      joinConditionContract_susp,
                                     "left") 
                                //suspension
                                .join(df_suspension.as("suspension"),
                                     ($"contract_susp.suspension_contrat_code"==="$suspension.contract_suspension_code"),
                                     "left")
                                .join(df_suspension_date.as("suspension_date"),
                                    ($"contract_susp.contract_suspension_dates_code"==="$suspension.contract_suspension_dates_code"),
                                     "left")
                                //employee_org
/*
.join(df_employeehr_org.as("employee_org"),
                                      joinConditionEmployee_org,
                                     "left") 
*/
                                //employee_job
                                .join(df_employeehr_job.as("employee_job"),
                                      joinConditionEmployee_job,
                                     "left") 
                                //csp code
                                .join(df_csp.as("csp"),
                                     ($"employee_job.csp_code"===$"csp.csp_code"),
                                     "left")
                                //operational organization
                                .join(df_employee_ope_org.as("ope_org"),
                                     ($"contract_employee.employee_code"===$"ope_org.employee_code" and $"contract_employee.record_start_date"===$"ope_org.record_start_date"),
                                     "left")
                                .join(df_ope_organization.as("ope"),
                                     ($"ope_org.operational_organization_code"===$"ope.operational_organization_code"),"left")
                               //legal_organization
                               .join(df_legal_organization.as("orga"),
                                     ($"ope_org.legal_organization_code"===$"orga.legal_organization_code"),
                                     "left")  
                                //Presence : ajout suspension contrat
                                .withColumn("presence", when($"contract_susp.contract_suspension_start_date".isNull, "Actif").otherwise("Inactif"))

                                // salaire contractuel
                                .withColumn("salaire_contractuel",when(lower($"contract_type.contract_type") === ("stagiaire"),$"contract_comp.total_base_pay").otherwise(($"contract_comp.total_base_pay"/12)*13))
                                // suspension contrat
                                .withColumn("libelle_motif",when($"contract_susp.employee_code".isNotNull,$"suspension.libelle_motif").otherwise(lit(null)))
                                //default values
                                .withColumn("mobility_out_id",lit(-1))
                                .withColumn("job_architecture_id",lit(-1))
                                .withColumn("job_code",lit(null))
                                .withColumn("local_termination_reason",lit(null))


                                .select("contract_employee.employee_code",//id employee
                                        "staff_employee.employee_id",//id_employee
                                        "staff_employee.matricule_workday",
                                        "staff_employee.matricule_hra",
                                        "contract_employee.record_start_date",//date_effet
                                        "presence",//presence,
                                        "orga.legal_organization_id",//id legal organization
                                        "orga.companycode",//company-societe
                                        "orga.company",//company-societe
                                        "orga.code_etablissement",//etablissement juridique
                                        "orga.libelle_etablissement",//etablissement juridique
                                        "orga.cost_center_code",//Centre de cout
                                        "orga.cost_center_label",//centre de cout
                                        "ope.operational_organization_id",
                                        "contract_change.collective_agreement_reference_label",//convention collective
                                        "contract_type.contract_nature",//Nature du contrat
                                        "contract_type.contract_nature_label",//Nature du contrat
                                        "contract_change.fte",//Taux de travail contractuel
                                        "csp.csp_id",
                                        "csp.csp_code",//csp
                                        "csp.csp",//csp
                                        "salaire_contractuel",//salaire contractuel
                                        "grd.grade_label",//grade
                                        "contract_type_change.classification_collective_agreement",//classification convention collective
                                        "job_architecture_id",
                                        "job_code",//Poste
                                        "employee_job.job_title",//poste
                                        "mobility_in.mobility_in_id",
                                        "contract_start.event_classification_subcategory_label",//motif etnree
                                        "mobility_out_id",
                                        "local_termination_reason",//motif sortie
                                        "suspension.contract_suspension_id",
                                        "contract_susp.suspension_contrat_code",//type suspension contrat
                                        "libelle_motif",
                                        "suspension_date.contract_suspension_dates_id",
                                        "contract_susp.contract_suspension_start_date",//date suspension contrat debut
                                        "contract_susp.contract_suspension_end_date"//date suspensions contrat fin
                                       )

                                       //null value
                                       .na.fill(-1,Array("legal_organization_id"))
                                       .na.fill(-1,Array("contract_suspension_id"))
                                       .na.fill(-1,Array("csp_id"))
                                       .na.fill(-1,Array("operational_organization_id"))
                                       .na.fill(-1,Array("mobility_in_id"))
                                       //.na.fill(-1,Array("mobility_out_id"))
                                       .na.fill(-1,Array("contract_suspension_dates_id"))
                                       //.na.fill(-1,Array("job_architecture_id"))
                                       .distinct()

.union(df_contract_end)
                                      .withColumnRenamed("collective_agreement_reference_label","collective_agreement_reference")
                                      .withColumnRenamed("classification_collective_agreement","classification_convention_collective")
                                      .withColumnRenamed("contract_nature","contract_type")
                                      .withColumnRenamed("contract_nature_label","contract_type_label")
                                      .withColumnRenamed("grade_label","grade")
                                      .filter($"record_start_date" <= date_value)



// COMMAND ----------

// MAGIC %md ##3- write

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """truncate table staff.d_employee_historical_data"""
val res = stmt.execute(query_delete)

// COMMAND ----------

df_contract_employee.coalesce(1).write.mode(SaveMode.Append)
                                      .option("tablock","true")
                                      .option("batchsize","500")
                                      .jdbc(jdbcurl, "staff.d_employee_historical_data", connectionproperties)


// COMMAND ----------

val read_records = df_contract_employee_situation_ordered.count().toInt 
val return_value = "read_records:" + read_records 

//val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0

// COMMAND ----------

df_contracthr_start.unpersist()
df_contracthr_change.unpersist()
df_contracthr_comp.unpersist()
df_employeehr_job.unpersist()
df_employeehr_ope_org.unpersist()
df_employeehr_org.unpersist()
df_contractsusp_read.unpersist()
df_contract_employee_situation.unpersist()
df_contract_employee_situation_ordered.unpersist()

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)