// Databricks notebook source
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val historical_data_end_date = dbutils.widgets.get("historical_data_end_date");
val limit_date_histo = dbutils.widgets.get("limit_date_histo");
val system_source = dbutils.widgets.get("system_source");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "-1")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
spark.conf.set("spark.sql.adaptive.localShuffleReader.enabled", "true")
spark.conf.set("spark.databricks.optimizer.rangeJoin.binSize", "5")

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

 if(spark.catalog.tableExists("hr.absenteism")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

 if(spark.catalog.tableExists("hr.pay")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.pay")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

 if(spark.catalog.tableExists("hr.cet")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.cet")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

 if(spark.catalog.tableExists("hr.ag_establishment")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.ag_establishment")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

 if(spark.catalog.tableExists("hr.eligibility_psb")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.eligibility_psb")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd")).plusMonths(-1)
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_id = date_end_month.toString.replace("-","")
val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))
val year_id = date_value.getYear()
val last_year_id = date_value.getYear()-1
val last_month = date_end_month.plusMonths(-1).getYear() + ("%02d".format(date_end_month.plusMonths(-1).getMonth.getValue()))
val last_month_id =date_end_month.plusMonths(-1).withDayOfMonth(date_end_month.plusMonths(-1).lengthOfMonth()).toString.replace("-","")
val first_month_id = date_value.getYear() + "01"
val last_month_previous_year = (date_value.getYear() -1) + "12"
val december_previous_year = (date_value.getYear() -1) + "1231"
val march_month_id = date_value.getYear() + "03"
val pourcentage_pi = 0.2
val holidays_bonus = 1500
val bonus_agreement_amount_CHANEL_France = 1090
val bonus_agreement_amount_Verneuil = 1225
val bonus_defile_collection_Verneuil = 1320
val bonus_defile_collection_CHANEL_France_CDD_4 = 1640
val bonus_defile_collection_CHANEL_France_CDD_3 = 1207
val bonus_defile_collection_CHANEL_France_CDD_2B = 966
val bonus_defile_collection_CHANEL_France_CDD_2A = 691
val bonus_defile_collection_CHANEL_France_CDI_4 = 1810
val bonus_defile_collection_CHANEL_France_CDI_3 = 1432
val bonus_defile_collection_CHANEL_France_CDI_2B = 1152
val bonus_defile_collection_CHANEL_France_CDI_2A = 837
val daymonth_PSBN1 = 1130

val date_next_month = date_end_month.plusDays(1)
val month_next_id = date_next_month.getYear() + ("%02d".format(date_next_month.getMonth.getValue()))

val date_start_month = date_value.withDayOfMonth(1)

val date_end_last_month = date_start_month.plusDays(-1)

val limit_date_value = LocalDate.parse(limit_date_histo, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val filter_file_current_month = if (date_end_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}
val filter_file_previous_month = if (date_end_last_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}

// COMMAND ----------

val dvalue = LocalDate.parse("2022-04-01", DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val system_source = if (date_end_month.isBefore (dvalue)) {"hra"} else {"adp"}

// COMMAND ----------

val historical_date_end_date_value = LocalDate.parse(historical_data_end_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
//delta for pay increase
val delta_histo = if (historical_date_end_date_value.isAfter(date_value)) {1} else { 0}
//check to filter only on historical data
val is_histo = if (historical_date_end_date_value.isAfter(date_value)) {1} else { 0}


// COMMAND ----------

// DBTITLE 1,Get the month_id for psbnplus1
var month_id_psb = ""
if(month_id.toString <= (year_id.toString + daymonth_PSBN1.toString).substring(0,6) )
{
  month_id_psb = month_id
}
else
{
  month_id_psb = (year_id.toString + daymonth_PSBN1.toString).substring(0,6)
}


// COMMAND ----------

// DBTITLE 1,Get C&B Parameters
val df_param_value = spark.read.jdbc(jdbcurl, "dbo.param_value", connectionproperties).select("parameter_name", "parameter_value")
val plafond_pi = df_param_value.filter($"parameter_name" === "PLAFOND_PI").select("parameter_value").first().getString(0).toDouble
val pourcentage_pi = df_param_value.filter($"parameter_name" === "POURCENTAGE_PI").select("parameter_value").first().getString(0).toDouble
val holiday_bonus = df_param_value.filter($"parameter_name" === "PRIME_VACANCES").select("parameter_value").first().getString(0).toDouble
val bonus_agreement_amount_CHANEL_France = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_ACCORD_SALARIAL_CHANEL_FRANCE").select("parameter_value").first().getString(0).toDouble
val bonus_agreement_amount_Verneuil = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_ACCORD_SALARIAL_VERNEUIL").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_Verneuil = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_VERNEUIL").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDD_4 = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDD_4").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDD_3 = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDD_3").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDD_2B = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDD_2B").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDD_2A = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDD_2A").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDI_4 = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDI_4").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDI_3 = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDI_3").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDI_2B = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDI_2B").select("parameter_value").first().getString(0).toDouble
val bonus_defile_collection_CHANEL_France_CDI_2A = df_param_value.filter($"parameter_name" === "MONTANT_PRIME_DEFILE_COLLECTION_FRANCE_CDI_2A").select("parameter_value").first().getString(0).toDouble
val daymonth_PSBN1 = df_param_value.filter($"parameter_name" === "MONTHDAY_PSBN1").select("parameter_value").first().getString(0).toDouble.toInt 

// COMMAND ----------

// DBTITLE 1,Get dimensions values
spark.read.jdbc(jdbcurl, "dbo.d_date", connectionproperties).filter(col("month_id") === lit(month_id)).createOrReplaceTempView("vw_d_date")
spark.read.jdbc(jdbcurl, "staff.d_employee", connectionproperties).select("employee_id", "employee_code", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_employee")
val df_contract_type = spark.read.jdbc(jdbcurl, "staff.d_contract_type", connectionproperties).select("contract_type_id", "contract_type_code","precarity","contract_type","contract_type_detailed","classification_collective_agreement","contract_nature","collective_agreement_code","contract_code").filter("current_version = 1")
df_contract_type.createOrReplaceTempView("vw_d_contract_type")
spark.read.jdbc(jdbcurl, "staff.d_worker_rate", connectionproperties).select("worker_rate_id", "worker_rate_code", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_worker_rate")
spark.read.jdbc(jdbcurl, "staff.d_csp", connectionproperties).select("csp_id", "csp_code", "cadre_non_cadre","professional_category_reference").filter("current_version = 1").createOrReplaceTempView("vw_d_csp")
spark.read.jdbc(jdbcurl, "staff.d_nationality", connectionproperties).select("nationality_id", "nationality_code").filter("current_version = 1").createOrReplaceTempView("vw_d_nationality")
spark.read.jdbc(jdbcurl, "staff.d_range_age", connectionproperties).select("range_age_id", "range_age").filter("current_version = 1").createOrReplaceTempView("vw_d_range_age")
spark.read.jdbc(jdbcurl, "staff.d_seniority_company", connectionproperties).select("seniority_company_id", "range_seniority_company_age").filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_company")
spark.read.jdbc(jdbcurl, "staff.d_hierarchy_pb", connectionproperties).filter("current_version = 1").select("hierarchy_pb_id", "cost_center_code").createOrReplaceTempView("vw_d_hierarchy_pb")

// COMMAND ----------

// DBTITLE 1,Get dimensions values
spark.read.jdbc(jdbcurl, "staff.d_seniority_position", connectionproperties).select("seniority_position_id", "range_seniority_position_age").filter("current_version = 1").createOrReplaceTempView("vw_d_seniority_position")
spark.read.jdbc(jdbcurl, "staff.d_location", connectionproperties).select("location_id", "location_code").filter("current_version = 1").createOrReplaceTempView("vw_d_location")
spark.read.jdbc(jdbcurl, "staff.d_job_architecture", connectionproperties).select("job_architecture_id", "job_architecture_code","job_title_code","grade_code").filter("current_version = 1").createOrReplaceTempView("vw_d_job_architecture")
spark.read.jdbc(jdbcurl, "staff.d_manager", connectionproperties).select("manager_id", "manager_code").filter("current_version = 1").createOrReplaceTempView("vw_d_manager")
spark.read.jdbc(jdbcurl, "staff.d_supervisory_organization", connectionproperties).select("supervisory_organization_id", "supervisory_organization_code").filter("current_version = 1").createOrReplaceTempView("vw_d_supervisory_organization")
spark.read.jdbc(jdbcurl, "staff.d_contract_suspension", connectionproperties).select("contract_suspension_id", "contract_suspension_code").filter("current_version = 1").createOrReplaceTempView("vw_d_contract_suspension")
spark.read.jdbc(jdbcurl, "staff.d_legal_organization", connectionproperties).select("legal_organization_id", "legal_organization_code", "company", "libelle_etablissement","code_etablissement","hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_legal_organization")
spark.read.jdbc(jdbcurl, "staff.d_operational_organization", connectionproperties).select("operational_organization_id", "operational_organization_code", "division_consolidated","top_level","libelle_departement", "hashkey").filter("current_version = 1").createOrReplaceTempView("vw_d_operational_organization")
spark.read.jdbc(jdbcurl, "pay.d_payroll", connectionproperties).select("payroll_id", "payroll_code", "libelle_rubrique_paie_niv1", "libelle_rubrique_paie_niv2", "libelle_rubrique_paie_niv4", "libelle_rubrique_paie_niv3", "flag_montant_masse_salariale_brute", "flag_montant_aw4", "flag_montant_rem_bs","flag_montant_aw6","flag_montant_rem_nao","flag_montant_rem_reelle","flag_montant_rem_benchmark", "code_rubrique_paie","is_payroll_di").filter("current_version = 1").createOrReplaceTempView("vw_d_payroll")

// COMMAND ----------

// DBTITLE 1,Get dimensions values
spark.read.jdbc(jdbcurl, "mobility.d_mobility_in", connectionproperties).select("mobility_in_id", "mobility_in_code").filter("current_version = 1").createOrReplaceTempView("vw_d_mobility_in")
spark.read.jdbc(jdbcurl, "mobility.d_mobility_out", connectionproperties).select("mobility_out_id", "mobility_out_code").filter("current_version = 1").createOrReplaceTempView("vw_d_mobility_out")

spark.read.jdbc(jdbcurl, "staff.d_info_dates", connectionproperties).select("info_dates_id", "info_dates_code", "position_start_date", "hire_date", "contract_start_date", "contract_end_date","contract_dates_code","company_dates_code").filter("current_version = 1").createOrReplaceTempView("vw_d_info_dates")
spark.read.jdbc(jdbcurl, "mobility.d_in_out_dates", connectionproperties).select("in_out_dates_id", "in_out_dates_code","org_in_out_dates_code").filter("current_version = 1").createOrReplaceTempView("vw_d_in_out_dates")

// use view to filter on transcoded value
spark.read.jdbc(jdbcurl, "pay.vw_d_compensation_change", connectionproperties).select("compensation_change_id", "compensation_change_code","compensation_change_reason","compensation_change_subreason").filter("current_version = 1").createOrReplaceTempView("vw_d_compensation_change")
spark.read.jdbc(jdbcurl, "pay.vw_d_compensation_merit_plan", connectionproperties).select("compensation_merit_plan_id", "compensation_merit_plan_code","compensation_merit_plan_label").filter("current_version = 1").createOrReplaceTempView("vw_d_compensation_merit_plan")
spark.read.jdbc(jdbcurl, "pay.d_compensation_bonus_plan", connectionproperties).select("compensation_bonus_plan_id", "compensation_bonus_plan_code").filter("current_version = 1").createOrReplaceTempView("vw_d_compensation_bonus_plan")
spark.read.jdbc(jdbcurl, "pay.d_action_housing", connectionproperties).select("action_housing_id", "action_housing_code").filter("current_version = 1").createOrReplaceTempView("vw_d_action_housing")
spark.read.jdbc(jdbcurl, "pay.d_homeoffice", connectionproperties).select("homeoffice_id", "code").filter("current_version = 1").createOrReplaceTempView("vw_d_homeoffice")
spark.read.jdbc(jdbcurl, "pay.d_increase_type", connectionproperties).select("increase_type_id", "increase_type_detailed").createOrReplaceTempView("vw_d_increase_type")

spark.read.jdbc(jdbcurl, "pay.d_range_payout", connectionproperties).select("range_payout_id", "range_payout_percent", "range_payout_min", "range_payout_max").filter("current_version = 1").createOrReplaceTempView("vw_d_range_payout")
spark.read.jdbc(jdbcurl, "pay.d_range_payout_detailed", connectionproperties).select("range_payout_detailed_id", "range_payout_percent_detailed", "range_payout_min_detailed", "range_payout_max_detailed").filter("current_version = 1").createOrReplaceTempView("vw_d_range_payout_detailed")
spark.read.jdbc(jdbcurl, "pay.d_range_percol", connectionproperties).select("range_percol_id", "range_percol_min", "range_percol_max", "range_percol").filter("current_version = 1").createOrReplaceTempView("vw_d_range_percol")

val df_decPay = spark.read.jdbc(jdbcurl, "pay.f_pay", connectionproperties).select("employee_id","annual_contractual_pay_amount").filter(col("date_id") === lit(december_previous_year)).orderBy(asc("employee_id")).distinct
df_decPay.cache.createOrReplaceTempView("vw_f_pay_last_december")

val df_prevPay = spark.read.jdbc(jdbcurl, "pay.f_pay", connectionproperties).select("employee_id","contract_type_id", "annual_contractual_pay_amount","total_base_pay").filter(col("date_id") === lit(last_month_id)).orderBy(asc("employee_id")).distinct
df_prevPay.cache.createOrReplaceTempView("vw_f_pay_last_month")
spark.read.jdbc(jdbcurl, "dbo.vw_ref_seniority_company", connectionproperties).createOrReplaceTempView("vw_ref_seniority_company")

// COMMAND ----------

// DBTITLE 1,Get vacataire csp id
val vacataire_csp_id = spark.sql("""select cast(sum(csp_id) as int) as vacataire_csp_id from vw_d_csp where lower(professional_category_reference) = 'autre statut'""").head().getInt(0)

// COMMAND ----------

// DBTITLE 1,Get borne for 1 year and 6 month
val borne_1_year = spark.sql("""select distinct range_seniority_company_max as borne_1_year from vw_ref_seniority_company where range_seniority_company = 'Entre 6 mois et 1 an'""").head().getInt(0) //Borne min for seniority superior to 6 months
val borne_6_month = spark.sql("""select distinct range_seniority_company_min as borne_6_month from vw_ref_seniority_company where range_seniority_company = 'Entre 6 mois et 1 an'""").head().getInt(0) //Borne min for seniority superior to 6 months

// COMMAND ----------

// DBTITLE 1,Flat Files
// PSB
val df_is_eligible_psb_read = spark.sql("""
  select 
    employee_code,  employee_id, france_payroll_id,
    """+month_id+""" as period_pay_month, 1 as is_eligible
  from hr.eligibility_psb where year(period) = """ + year_id
)
df_is_eligible_psb_read.createOrReplaceTempView("vw_psb")


// Amount LTI
val byltimonth = Window.partitionBy("employee_id","france_payroll_id").orderBy($"period_month".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_amount_lti_read = spark.table("hr.amount_lti").filter("""period_month = '""" + month_id + """'""" )                                                         
                                                     .withColumn("rank_month",rank() over byltimonth)
                                                     .filter(col("rank_month")==="1")
                                                     .select("employee_code","amount_lti_annual")
                                                     .withColumnRenamed("employee_code","empl_code")
                                                     .withColumnRenamed("amount_lti_annual","montant_lti_annuel")
df_amount_lti_read.createOrReplaceTempView("vw_amount_lti")

// Housing
val byhousing = Window.partitionBy("employee_id","france_payroll_id").orderBy($"year".desc, $"thematic_action_housing".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_housing_read = spark.table("hr.housing_action").filter("""year = '""" + year_id + """'""")    
                                                      .withColumn("rank_housing",rank() over byhousing)
                                                      .select("employee_code","thematic_action_housing","rank_housing")
                                                      .withColumnRenamed("employee_code","empl_code")
                                                      .withColumnRenamed("thematic_action_housing","thematique_action_logement")
                                                      .withColumn("action_housing_code",sha2($"thematique_action_logement",256))
df_housing_read.createOrReplaceTempView("vw_housing")

// PERCOL PEB CCB
val df_percol_peb_ccb_read = spark.table("hr.percol_peb_ccb").filter("""year = '""" + year_id + """'""")                                                         
                                                             .select("employee_code","flag_amundi_per_col","flag_amundi_peg","flag_amundi_ccb")
                                                             .withColumnRenamed("employee_code","empl_code")
df_percol_peb_ccb_read.createOrReplaceTempView("vw_percol_peb_ccb")


// Bonus Target
val bybonusmonth = Window.partitionBy("employee_id","france_payroll_id").orderBy($"period_month".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_bonus_read = spark.table("hr.theoric_target_bonus_amount").filter("""period_month = '""" + month_id + """'"""  )                                                         
                                                                 .withColumn("rank_month",rank() over bybonusmonth)
                                                                 .filter(col("rank_month")==="1")
                                                                 .select("employee_code","theoric_target_bonus_amount")
                                                                 .withColumnRenamed("employee_code","empl_code")
                                                                 .withColumnRenamed("theoric_target_bonus_amount","montant_prime_objectif_theorique")
df_bonus_read.createOrReplaceTempView("vw_bonus")


// Bonus Target
val bycarmonth = Window.partitionBy("france_payroll_id").orderBy($"period_month".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val bycar = Window.partitionBy("france_payroll_id").orderBy($"period_month".desc, $"benefits_type".desc, $"benefits_start_date".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_car_read = spark.table("hr.car_mobility_policy").filter("""period_month = '""" + month_id + """'""" )                                                         
                                                       .withColumn("rank_month",rank() over bycarmonth)
                                                       .filter(col("rank_month")==="1")                                                      
                                                       .withColumn("rank_car",rank() over bycar)
                                                       .select("france_payroll_id","benefits_start_date","benefits_end_date","benefits_type","benefits_category","rank_car") 
                                                       .withColumnRenamed("france_payroll_id","hra_emp_id")
                                                       .withColumnRenamed("benefits_start_date","date_debut_avantage")
                                                       .withColumnRenamed("benefits_end_date","date_fin_avantage")
                                                       .withColumnRenamed("benefits_category","categorie_avantage")
                                                       .withColumnRenamed("benefits_type","type_avantage")
df_car_read.createOrReplaceTempView("vw_car")

//Etablissement Augmentation Generale
val df_augmentation_generale_read = spark.table("hr.ag_establishment").filter($"year" === year_id)
df_augmentation_generale_read.cache
df_augmentation_generale_read.createOrReplaceTempView("vw_ag_etablissement")

// COMMAND ----------

// DBTITLE 1,Get employee, contract, cet and absenteism data
val byemployee_hra = Window.partitionBy("france_payroll_id").orderBy($"effective_organization_change_date".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val byemployee = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_organization_change_date".desc,$"effective_organization_hierarchy_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_employee_read = spark.table("hr.employee").filter("('" + date_end_month.toString + "' >= record_start_date or '" + date_end_month.toString + "' >= effective_organization_hierarchy_change_date) and '" + date_end_month.toString + "' <= coalesce(record_end_date, '2999-12-31')")
                                                 .withColumn("rank_hra",rank() over byemployee_hra)
                                                 .withColumn("rank",rank() over byemployee)
                                                 .filter(col("rank")==="1")                                          
                                                 .filter("company_id <> '0082'")
                                                 .distinct
df_employee_read.createOrReplaceTempView("vw_employee")
df_employee_read.cache()  //put the dataframe on the cache


val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc, $"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_contract_read = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                 .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")  
                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .withColumn("rank",rank() over bycontract)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("seniority_date_max",when($"contract_end_date" === "2999-12-31" or $"contract_end_date".isNull or $"contract_end_date" > lit(date_end_month), lit(date_end_month)).otherwise($"contract_end_date"))
                                                .filter(col("rank")==="1") 
                                                .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))       
                                                .distinct
df_contract_read.createOrReplaceTempView("vw_contract")

val df_absenteism_read = spark.table("hr.absenteism").filter("current_record = true  and period_abs_month = '" + month_id + "'").distinct
df_absenteism_read.createOrReplaceTempView("vw_absenteism")

val df_cetread = spark.table("hr.cet").filter("""date_format(date_operation,'yyyyMM') = '""" + month_id + """'""").distinct
df_cetread.createOrReplaceTempView("vw_cet")

// COMMAND ----------

val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val bycontract = Window.partitionBy("employee_id","france_payroll_id").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_contract_read_month = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                       .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """' or 
                                                            date_format(coalesce(contract_end_date, '2999-12-31'),'yyyyMM') >= '""" + month_id + """' """
                                                        ) 
                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("month_contract_start_date",when($"contract_start_date" < date_start_month,date_start_month).otherwise($"contract_start_date"))
                                                .withColumn("month_contract_end_date",when($"contract_end_date" > date_end_month,date_end_month).when($"contract_end_date".isNull,date_end_month).otherwise($"contract_end_date"))
                                                .withColumn("contract_days",datediff($"month_contract_end_date",$"month_contract_start_date")+1)
                                                .filter(col("rank_month")==="1")
                                                .withColumn("rank",rank() over bycontract)
                                                .withColumn("next_contract_start_date",lag($"contract_start_date", 1, null).over(bycontract) )
                                                .withColumn("next_contract_end_date",lag($"contract_end_date", 1, null).over(bycontract) )
                                                .distinct
df_contract_read_month.createOrReplaceTempView("vw_contract_month")


// COMMAND ----------

val byJobChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLast = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date_valid".desc)
val byJobChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_job_change_date_valid".desc)
val byCompensationChangeDateLastContract = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"effective_compensation_change_date_valid".desc)
val bycontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date","effective_job_change_date","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_effective_change_valid = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")                                                
                                                .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                .withColumn("effective_job_change_date_valid", when($"effective_job_change_date" > lit(date_end_month),null).otherwise($"effective_job_change_date"))
                                                .withColumn("effective_job_change_date_valid_last", first($"effective_job_change_date").over(byJobChangeDateLast))
                                                .withColumn("effective_job_change_date", when($"effective_job_change_date_valid".isNotNull,$"effective_job_change_date_valid")
                                                                                        .when($"effective_job_change_date_valid_last".isNull, $"contract_start_date")
                                                                                        .otherwise($"effective_job_change_date_valid_last"))        
                                                .withColumn("effective_job_change_date_max", first($"effective_job_change_date").over(byJobChangeDateLastContract)) 

                                                .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                .withColumn("effective_compensation_change_date_valid", when($"effective_compensation_change_date" > lit(date_end_month),null).otherwise($"effective_compensation_change_date"))
                                                .withColumn("effective_compensation_change_date_valid_last", first($"effective_compensation_change_date").over(byCompensationChangeDateLast))
                                                .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date_valid".isNotNull,$"effective_compensation_change_date_valid")
                                                                                                 .when($"effective_compensation_change_date_valid_last".isNull, $"contract_start_date")
                                                                                                 .otherwise($"effective_compensation_change_date_valid_last"))            
                                                .withColumn("effective_compensation_change_date_max",first($"effective_compensation_change_date").over(byCompensationChangeDateLastContract))


                                                .withColumn("rank_month",rank() over bycontract_month)
                                                .filter(col("rank_month")==="1")  
                                                
                                               .select("employee_code",
                                                       "employee_id",
                                                       "france_payroll_id",
                                                       "contract_start_date",
                                                       "contract_end_date",
                                                       "contract_type",
                                                       "contract_type_label",
                                                       "effective_job_change_date",
                                                       "effective_compensation_change_date",
                                                       "effective_job_change_date_max",
                                                       "effective_compensation_change_date_max").distinct


val bycontract_job_month = Window.partitionBy("employee_id","france_payroll_id","effective_job_change_date","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_job_change_date_read =spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                                     .filter("""contract_start_date <= '""" + date_end_month + """'""")  
                                                                     .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                                     .withColumn("effective_job_change_date",when(date_format($"effective_job_change_date","yyyyMM") < month_id && date_format($"effective_compensation_change_date","yyyyMM") < month_id
                                                                                                                                                           && $"effective_job_change_date" < $"effective_compensation_change_date",$"effective_compensation_change_date")
                                                                                       .otherwise($"effective_job_change_date"))
                                                                     .withColumn("effective_job_change_date", when($"effective_job_change_date".isNotNull,$"effective_job_change_date").otherwise($"contract_start_date"))
                                                                     .filter("""effective_job_change_date <= '""" + date_end_month + """'""")   
                                                                     .withColumn("rank_month",rank() over bycontract_job_month)
                                                                     .filter(col("rank_month")==="1")  
                                                                     .distinct

val bycontract_compensation_month = Window.partitionBy("employee_id","france_payroll_id","effective_compensation_change_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_effective_compensation_change_date_read =spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                                     .filter("""contract_start_date <= '""" + date_end_month + """'""")    
                                                                     .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                                                                     .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date".isNotNull,$"effective_compensation_change_date").otherwise($"contract_start_date"))                                         
                                                                     .filter("""effective_compensation_change_date <= '""" + date_end_month + """'""")   
                                                                     .withColumn("rank_month",rank() over bycontract_compensation_month)
                                                                     .filter(col("rank_month")==="1")  
                                                                     .distinct

val df_contract_join = df_effective_change_valid.as("e")
                                        .join(df_contract_effective_job_change_date_read.as("c"), $"e.employee_code" === $"c.employee_code" && $"e.effective_job_change_date_max" === $"c.effective_job_change_date" && $"e.contract_start_date" === $"c.contract_start_date", "left_outer")
                                        .join(df_contract_effective_compensation_change_date_read.as("o"), $"e.employee_code" === $"o.employee_code" && $"e.effective_compensation_change_date_max" === $"o.effective_compensation_change_date" && $"e.contract_start_date" === $"o.contract_start_date", "left_outer")
                                        .join(df_contract_read.as("d"), $"e.employee_code" === $"d.employee_code" && $"e.contract_start_date" === $"d.contract_start_date" && ($"e.effective_job_change_date_max" === $"d.effective_job_change_date" || $"e.effective_compensation_change_date_max" === $"d.effective_compensation_change_date"), "left_outer")
                                        .join(df_contract_read.as("r"), $"e.employee_code" === $"r.employee_code" && $"e.contract_start_date" === $"r.contract_start_date", "left_outer")
                                        .selectExpr(
                                                "e.employee_code"
                                               ,"e.employee_id"
                                               ,"e.france_payroll_id"
                                               ,"coalesce(r.contract_start_date, e.contract_start_date) as contract_start_date"
                                               ,"coalesce(r.contract_end_date, e.contract_end_date) as contract_end_date"
                                               ,"e.effective_job_change_date"
                                               ,"coalesce(c.collective_agreement_reference, d.collective_agreement_reference) as collective_agreement_reference"                                    
                                               ,"coalesce(c.collective_agreement_group, d.collective_agreement_group) as collective_agreement_group"
                                               ,"coalesce(c.collective_agreement_level, d.collective_agreement_level) as collective_agreement_level"
                                               ,"coalesce(c.continous_service_date, d.continous_service_date) as continous_service_date"
                                               ,"coalesce(c.position_start_date, d.position_start_date) as position_start_date"
                                               ,"coalesce(c.hire_date, d.hire_date) as hire_date"
                                               ,"coalesce(c.original_hire_date, d.original_hire_date) as original_hire_date"
                                               ,"coalesce(c.effective_hire_date, d.effective_hire_date) as effective_hire_date"
                                               ,"coalesce(c.fte, d.fte) as fte"
                                               ,"coalesce(c.worker_type, d.worker_type) as worker_type"
                                               ,"coalesce(c.paidfte, d.paidfte) as paidfte"
                                               ,"coalesce(c.bonus_target, d.bonus_target) as bonus_target"
                                               ,"coalesce(c.csp, d.csp) as csp"
                                               ,"coalesce(c.coefficient, d.coefficient) as coefficient"
                                               ,"coalesce(c.coefficient_label, d.coefficient_label) as coefficient_label"
                                               ,"coalesce(c.job_title, d.job_title) as job_title"
                                               ,"coalesce(o.total_base_pay, d.total_base_pay) as total_base_pay"
                                               ,"coalesce(o.grade, d.grade) as grade"
                                               ,"coalesce(o.effective_compensation_change_date, d.effective_compensation_change_date) as effective_compensation_change_date"
                                               ,"coalesce(c.job_code, d.job_code) as job_code"
                                               ,"coalesce(c.job_title_code, d.job_title_code) as job_title_code"
                                               ,"coalesce(o.grade_code, d.grade_code) as grade_code"
                                               ,"coalesce(c.csp_code, d.csp_code) as csp_code"
                                               ,"coalesce(c.worker_rate_code, d.worker_rate_code) as worker_rate_code"
                                               ,"coalesce(d.mobility_in_code, c.mobility_in_code) as mobility_in_code"
                                               ,"coalesce(d.mobility_out_code, c.mobility_out_code) as mobility_out_code"
                                               ,"coalesce(d.info_dates_code, c.info_dates_code) as info_dates_code"
                                               ,"coalesce(d.in_out_dates_code, c.in_out_dates_code) as in_out_dates_code"
                                               ,"coalesce(d.contract_dates_code, c.contract_dates_code) as contract_dates_code"                                               
                                               ,"coalesce(c.contract_code, d.contract_code) as contract_code"
                                               ,"coalesce(d.contract_type_code, c.contract_type_code) as contract_type_code"
                                               ,"coalesce(c.collective_agreement_code, d.collective_agreement_code) as collective_agreement_code"
                                               ,"coalesce(c.company_dates_code, d.company_dates_code) as company_dates_code"
                                               ,"coalesce(d.record_start_date, c.record_start_date) as record_start_date"
                                               ,"coalesce(d.date_raw_load_file, c.date_raw_load_file) as date_raw_load_file"
                                               ,"coalesce(d.record_modification_date, c.record_modification_date) as record_modification_date"
                                               ,"coalesce(d.record_creation_date, c.record_creation_date) as record_creation_date"
                                        )

                                          .distinct

df_contract_join.createOrReplaceTempView("vw_emp_contract") 


// COMMAND ----------

// DBTITLE 1,Get Contract data by filtering on effective job change data
val bycontract_job_change = Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc,$"effective_job_change_date".desc,$"effective_compensation_change_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_read_job_change = df_contract_join.withColumn("rank",rank() over bycontract_job_change)                                                
                                                 .filter(col("rank")==="1")
                                                 .distinct
                                                 .withColumn("position_start_date", when($"position_start_date" > $"effective_job_change_date",$"effective_job_change_date").otherwise($"position_start_date"))
                                                 .withColumn("continous_service_date", when($"continous_service_date" > $"contract_start_date",$"contract_start_date").otherwise($"continous_service_date"))

df_contract_read_job_change.createOrReplaceTempView("vw_contract_job_change")

// COMMAND ----------

// DBTITLE 1,Get contract data for psbnplus1
val df_contract_read_psb = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                     .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id_psb + """'""")   
                                                    .withColumn("rank_month",rank() over bycontract_month)
                                                    .withColumn("rank",rank() over bycontract)
                                                    .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                    .filter(col("rank")==="1")
                                                    .distinct
df_contract_read_psb.createOrReplaceTempView("vw_contract_psb")

// COMMAND ----------

// DBTITLE 1,Transfo for PSB N+1
val bypreviouscontract_month = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_previous_contract_read = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                          .filter("""contract_end_date >= to_date('"""+ year_id+"""0930','yyyyMMdd') and contract_end_date <= to_date('"""+ year_id + daymonth_PSBN1 + """','yyyyMMdd')""") 
                                                          .withColumn("rank_month",rank() over bypreviouscontract_month)
                                                          .withColumn("rank",rank() over bycontract)
                                                          .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                          .filter(col("rank")==="1")
                                                          .distinct
                                                          .as("contract").join(df_contract_type.as("ctype"),$"contract.contract_code" === $"ctype.contract_code").filter(lower($"ctype.precarity") === "precaire" )
df_previous_contract_read.createOrReplaceTempView("vw_previous_contract")

// COMMAND ----------

// DBTITLE 1,Get employee eligible for psbnplus1
val df_is_eligible_psb_nplus1_read = spark.sql ("""
                                                 select  distinct 
                                                         c.employee_id
                                                        ,c.france_payroll_id
                                                        ,c.employee_code
                                                        ,1 as is_eligible_psb_nplus1  
                                                        ,"""+month_id+""" as period_pay_month

                                                 from    vw_employee e
                                                         inner join vw_contract_psb c on e.employee_code = c.employee_code                                                  
                                                         left join vw_d_contract_type ct on c.contract_code = ct.contract_code           
                                                         left join vw_previous_contract prev_c on prev_c.employee_code = c.employee_code 

                                                 where   1=1
                                                   and   lower(ct.contract_type) = ('cdi')
                                                   and   (c.contract_end_date is null or c.contract_end_date >= to_date('""" + year_id + daymonth_PSBN1 + """', 'yyyyMMdd'))
                                                   and   (c.contract_start_date < to_date('""" + year_id + """1001', 'yyyyMMdd') or  (c.contract_start_date >= to_date('""" + year_id + """1001', 'yyyyMMdd') 
                                                                                                                                      and c.contract_start_date <= to_date('""" + year_id + daymonth_PSBN1 + """', 'yyyyMMdd')
                                                                                                                                      and prev_c.employee_code is not null))
                   
""")

df_is_eligible_psb_nplus1_read.createOrReplaceTempView("vw_eligibilitypsbnplus1")

// COMMAND ----------

// DBTITLE 1,Get pay data
//Full Pay on current month
val df_pay_read = spark.table("hr.pay").filter("current_record = true and period_pay_month ='" + month_id + "' and system_source ='" + system_source + "'")
                                        .groupBy("employee_code", 
                                                 "employee_id", 
                                                 "france_payroll_id", 
                                                 "code_rubr",
                                                 "accounting_account",
                                                 "period_pay_month",
                                                 "payroll_code")
                                      .agg(sum("base") as "base", 
                                           sum("salary_amount") as "montant_salarial", 
                                           sum("company_amount") as "montant_patronal" )
                                        
                                      .withColumn("payroll_amount", when($"montant_salarial".isNotNull and $"montant_patronal".isNull,$"montant_salarial")
                                                                   .when($"montant_salarial".isNull and $"montant_patronal".isNotNull,$"montant_patronal")
                                                                   .otherwise($"montant_salarial" + $"montant_patronal"))
                                       .filter($"payroll_amount".isNotNull)

                                       .distinct.orderBy(asc("employee_code"),asc("code_rubr"),asc("code_rubr"))


val df_pay_month = df_pay_read.as("pay")
                  .join(df_is_eligible_psb_read.as("psb"),$"psb.employee_code" === $"pay.employee_code","full")
                  .join(df_is_eligible_psb_nplus1_read.as("psbnplus1"),coalesce($"pay.employee_code",$"psb.employee_code") === $"psbnplus1.employee_code", "full")

                  .withColumn("emp_code",coalesce($"pay.employee_code", $"psb.employee_code", $"psbnplus1.employee_code")) 
                  .withColumn("emp_id",coalesce($"pay.employee_id", $"psb.employee_id", $"psbnplus1.employee_id"))
                  .withColumn("fr_payroll_id",coalesce($"pay.france_payroll_id", $"psb.france_payroll_id", $"psbnplus1.france_payroll_id"))
                  .withColumn("period",coalesce($"pay.period_pay_month", $"psb.period_pay_month", $"psbnplus1.period_pay_month"))

                  .select("emp_code",
                          "emp_id",
                          "fr_payroll_id",
                          "period",
                          "code_rubr",
                          "accounting_account",
                          "payroll_code",
                          "base",
                          "montant_salarial",
                          "montant_patronal",
                          "payroll_amount",
                          "psb.is_eligible",
                          "psbnplus1.is_eligible_psb_nplus1")
                  .withColumnRenamed("emp_code","employee_code")
                  .withColumnRenamed("emp_id","employee_id")
                  .withColumnRenamed("fr_payroll_id","france_payroll_id")
                  .withColumnRenamed("period","period_pay_month")

  //LTI
  .join(df_amount_lti_read.as("lti"),$"lti.empl_code" === $"employee_code","left")
  //Housing
  .join(df_housing_read.as("housing"),$"housing.empl_code" === $"employee_code","left")
  //PERCOL PEB CCB
  .join(df_percol_peb_ccb_read.as("percol"),$"percol.empl_code" === $"employee_code","left")
  //Bonus
  .join(df_bonus_read.as("bonus"),$"bonus.empl_code" === $"employee_code","left")
  //Car
  .join(df_car_read.as("car"),$"car.hra_emp_id" === $"france_payroll_id","left")


  df_pay_month.cache
  df_pay_month.createOrReplaceTempView("vw_pay")


//Full Pay on current year
val df_pay_read_full = spark.table("hr.pay").filter("current_record = true and substr(period_pay_month,0,4) = '" + year_id + "' and system_source ='" + system_source + "'")
                                            .groupBy("employee_code", 
                                                     "employee_id", 
                                                     "france_payroll_id", 
                                                     "code_rubr",
                                                     "accounting_account",
                                                     "period_pay_month",
                                                     "payroll_code")
                                          .agg(sum("base") as "base", 
                                           sum("salary_amount") as "montant_salarial", 
                                           sum("company_amount") as "montant_patronal")

                                          .withColumn("payroll_amount", when($"montant_salarial".isNotNull and $"montant_patronal".isNull,$"montant_salarial")
                                                                   .when($"montant_salarial".isNull and $"montant_patronal".isNotNull,$"montant_patronal")
                                                                   .otherwise($"montant_salarial" + $"montant_patronal"))
                                           .filter($"payroll_amount".isNotNull)

                                           .distinct.orderBy(asc("period_pay_month"),asc("employee_code"),asc("code_rubr"),asc("code_rubr"))
df_pay_read_full.cache
df_pay_read_full.createOrReplaceTempView("vw_pay_full")


// COMMAND ----------

// DBTITLE 1,Contract salary
val bycontract_salary = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date".desc,$"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_read_salary = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
//.filter("""date_format(effective_compensation_change_date,'yyyyMM') <= '""" + month_id + """'""") 
                                                .filter("""date_format(effective_compensation_change_date,'yyyyMM') <= '""" + month_id + """'""")
                                                .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + month_id + """'""")
                                                .filter("""ifnull(date_format(contract_end_date,'yyyyMM'),'299912') >= '""" + month_id + """'""")
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("rank",rank() over bycontract_salary)
                                                .filter(col("rank")==="1")       
                                                .distinct
df_contract_read_salary.createOrReplaceTempView("vw_contract_salary")

// COMMAND ----------

// DBTITLE 1,Contract Bonus from Get Workers
val bycompensation_date = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date".desc,$"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val df_contract_read_bonus = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                .filter($"bonus_target".isNotNull)
                                                .filter("""date_format(effective_compensation_change_date,'yyyyMM') <= '""" + month_id + """'""")
                                                //.filter("""ifnull(date_format(contract_end_date,'yyyyMM'),'299912') >= '""" + month_id + """'""")
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .withColumn("rankcomp",rank() over bycompensation_date)
                                                .filter(col("rankcomp")==="1")
                                                .distinct

df_contract_read_bonus.createOrReplaceTempView("vw_contract_bonus")

// COMMAND ----------

// DBTITLE 1,Contract salary last month
val bycontract_salary_last_month = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date".desc,$"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_read_salary_last_month = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                .filter("""date_format(effective_compensation_change_date,'yyyyMM') <= '""" + last_month_id + """'""")                                                     
                                                .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + last_month_id + """'""")  
                                                .filter("""ifnull(date_format(contract_end_date,'yyyyMMdd'),'29991231') >= '""" + last_month_id + """'""")
                                                .withColumn("rank",rank() over bycontract_salary_last_month)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .filter(col("rank")==="1") 
                                                .distinct
df_contract_read_salary_last_month.createOrReplaceTempView("vw_contract_salary_last_month")

// COMMAND ----------

// DBTITLE 1,Contract salary last year
val bycontract_salary_last_year = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date".desc,$"contract_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_read_salary_last_year = spark.table("hr.contract").filter($"filename" like filter_file_current_month)
                                                .filter("""date_format(effective_compensation_change_date,'yyyyMM') <= '""" + last_month_previous_year + """'""") 
                                                .filter("""date_format(contract_start_date,'yyyyMM') <= '""" + last_month_previous_year + """'""")
                                                .filter("""ifnull(date_format(contract_end_date,'yyyyMM'),'299912') >= '""" + last_month_previous_year + """'""")
                                                .withColumn("rank",rank() over bycontract_salary_last_year)
                                                .withColumn("contract_end_date",when($"contract_end_date" === "2999-12-31",null).otherwise($"contract_end_date"))
                                                .filter(col("rank")==="1")  
                                                .distinct 

df_contract_read_salary_last_year.createOrReplaceTempView("vw_contract_salary_last_year")

// COMMAND ----------

// DBTITLE 1,Get Bonus Year To Date
val dfBonus = spark.sql(""" select f.employee_code, 
                                   f.code_rubr,
                                   f.employee_id,
                                   case when f.code_rubr like 'VPB_'
                                   or  f.code_rubr in ('0406S','5406S') 
                                   then sum(f.payroll_amount) else null end as bonus_amount,
                                   case when f.code_rubr like 'VPP_'
                                   or f.code_rubr = '1750S'
                                   then sum(f.payroll_amount) else null end as bonus_exceptional_psb_amount,
                                   case when f.code_rubr like 'VPH_'
                                   or f.code_rubr = '1711S'
                                   then sum(f.payroll_amount) else null end as bonus_pef_indiv_hojo_amount,
                                   sum(f1.payroll_amount)*12  as bonus_perf_indiv_amount
                                   
                            from vw_pay_full f 
                                 left join vw_pay_full f1 on f.employee_code = f1.employee_code 
                                                             and f.code_rubr = f1.code_rubr
                                                             and f.period_pay_month = f1.period_pay_month
                                                             and f1.code_rubr in ('PX3S','PX3P','PX6S','1705S','5705S','1708S','5708S','1714S','5714S','1717S','5717S','1720S','5720S')
                                                             and f1.period_pay_month = '""" + march_month_id + """'
                            where 1=1
                                and f.code_rubr in ('VPBS','VPPS','VPHS','VPBP','VPPP','VPHP','PX3S','PX3P','PX6S','0406S','5406S','1750S','1711S','1705S','5705S','1708S','5708S','1714S','5714S','1717S','5717S','1720S','5720S')
                                and f.period_pay_month >= '""" + first_month_id + """'  
                                and f.period_pay_month <= '""" + month_id + """'  
                            group by f.employee_code, 
                                     f.code_rubr,
                                     f.employee_id
                           """).createOrReplaceTempView("vw_bonus")

// COMMAND ----------

// DBTITLE 1,Individual Amount
val dfIndVerse = spark.sql(""" select f.employee_code, 
                                      f.employee_id,
                                      sum(coalesce(bonus_amount,0) + coalesce(bonus_exceptional_psb_amount,0) + coalesce(bonus_pef_indiv_hojo_amount,0) + coalesce(bonus_perf_indiv_amount,0)) as ind_verse_amount
                                   
                            from vw_bonus f 
                            where 1=1
                            group by f.employee_code, 
                                     f.employee_id
                           """).filter($"ind_verse_amount" > 0).createOrReplaceTempView("vw_ind_verse")

// COMMAND ----------

// DBTITLE 1,Get The YTD Percol Abundancy
spark.sql(""" select f.employee_code, 
                             f.code_rubr,
                             sum(f.payroll_amount) as percol_abound_amount_ytd
                             
                     from vw_pay_full f 
                          inner join vw_d_payroll pr on f.payroll_code = pr.payroll_code and upper(pr.libelle_rubrique_paie_niv4) in ('ABONDEMENT PER COL')
                                where 1=1
                                and f.period_pay_month >= '""" + first_month_id + """' 
                                and f.period_pay_month <= '""" + month_id + """' 
                      group by f.employee_code, 
                             f.code_rubr
                           """).createOrReplaceTempView("vw_percol_ytd")


// COMMAND ----------

// DBTITLE 1,Employee salary
//comparaison avec arrondi = à +/- 0,01%

val df_employee_salary_all = spark.sql(""" select distinct
                                                  s.employee_code
                                                 ,s.employee_id,s.france_payroll_id
                                                 ,case when lower(ct.contract_type) in ('stagiaire') then s.total_base_pay else (s.total_base_pay/12)*13 end as annual_contractual_pay_amount
                                                 ,case when lower(ct.contract_type) in ('stagiaire') then slm.total_base_pay else (slm.total_base_pay/12)*13 end annual_contractual_pay_m_1_amount  
                                                 ,case when lower(ct.contract_type) in ('stagiaire') then sly.total_base_pay else (sly.total_base_pay/12)*13 end  as annual_contractual_pay_n_1_amount
                                                 ,(ifnull(s.prime_co_percent,0)+ifnull(s.prime_exp_percent,0)) as new_montant_prime_objectif_theorique_percent
                                                 ,s.prime_co_percent
                                                 ,s.prime_exp_percent
                                                 ,s.total_base_pay  
                                                 ,s.foreign_travel_indemnity_amount
                                                 ,s.foreign_travel_indemnity_percent
                                                 ,s.primary_comp_basis_amount
                                                 ,case when s.period_salary_label = '13th month' or s.period_salary_label like '13%' then s.total_base_pay else null end as month_13th_amount
                                                 ,case when s.filename = 'histo_file' then bo.bonus_target else s.bonus_target end as bonus_target
                                                 ,s.compensation_currency
                                                 ,double(null) as is_pay_increase
                                                 ,double(null) as pay_increase_amount
                                                 ,int(null) as is_compensation_bonus_plan      
                                                 ,idv.ind_verse_amount
                                                 ,round(case when s.total_base_pay = 0 or (bo.bonus_target is null and s.bonus_target is null) or ((bo.bonus_target <= 0 and s.bonus_target <=0))  then -1
                                                        when idv.ind_verse_amount <= 0 or idv.ind_verse_amount is null then 0
                                                       else (idv.ind_verse_amount/(case when s.filename = 'histo_file' then bo.bonus_target else s.bonus_target end * case when lower(ct.contract_type) in ('stagiaire') then s.total_base_pay else (s.total_base_pay/12)*13 end))*100 end,1)  as percent_payout
                                        
                                  from  vw_contract_salary s

                                        left join vw_contract_salary_last_month slm on s.employee_code = slm.employee_code
                                        left join vw_contract_salary_last_year sly on s.employee_code = sly.employee_code
                                        left join vw_d_contract_type ct on ct.contract_code = s.contract_code 
                                        left join vw_contract_bonus bo on bo.employee_code = s.employee_code
                                        left join vw_ind_verse idv on idv.employee_code = s.employee_code


""").createOrReplaceTempView("vw_contract_salary_full")

// COMMAND ----------

// DBTITLE 1,Query for pay
val query_pay = """ select distinct
                          case when pr.is_payroll_di is not null and (p.rank_housing = 1 or p.rank_housing is null) 
                                                                 and (p.rank_car = 1 or p.rank_car is null) then p.payroll_amount * case when pr.libelle_rubrique_paie_niv1 = '6 - BSI' and 'adp' = lower('""" + system_source + """') then -1 else 1 end else null end as payroll_amount
                         ,case when upper(pr.libelle_rubrique_paie_niv4) in ('ABONDEMENT PER COL') then py.percol_abound_amount_ytd else null end as percol_abound_amount_ytd               
                         ,bo.bonus_amount
                         ,bo.bonus_exceptional_psb_amount
                         ,bo.bonus_pef_indiv_hojo_amount
                         ,bo.bonus_perf_indiv_amount
                         ,case when cast(""" + date_id + """ as int) < 20220301 then p.montant_prime_objectif_theorique else s.new_montant_prime_objectif_theorique_percent * s.annual_contractual_pay_amount end as montant_prime_objectif_theorique
                         ,case when date_format(c.contract_start_date, 'yyyyMM') <= """ + month_id + """
                                     and (c.contract_end_date is null or date_format(c.contract_end_date, 'yyyyMM') >= """ + month_id + """) then p.montant_lti_annuel end as montant_lti_annuel
                         ,p.flag_amundi_peg as is_open_peg                         
                         ,p.flag_amundi_per_col as is_open_percol
                         ,p.flag_amundi_ccb as is_open_ccb
                         ,case when lower(ct.contract_type) in ('cdi','cdd') 
                                     and range_seniority_company_age >= """ + borne_6_month + """ and ccc.fte > 0 
                                     and date_format(c.contract_start_date, 'yyyyMM') <= """ + month_id + """
                                     and (c.contract_end_date is null or date_format(c.contract_end_date, 'yyyyMM') >= """ + month_id + """) then 1 else null end as is_eligible_cesu
                         ,case when lower(type_avantage) = 'crédit mobilité uniquement' then 1 else null end as is_credit_mobility
                         ,case when lower(type_avantage) = 'voiture et crédit mobilité' then 1 else null end as is_credit_mobility_car_position
                         ,case when lower(type_avantage) = 'voiture uniquement' then 1 else null end as is_car_position 
                         
                         
                         ,case when p.is_eligible is not null then 1 else null end as is_eligible_psb
                         ,case when p.is_eligible_psb_nplus1 is not null then 1 else null end as is_eligible_psb_nplus1        
                        
                           
                         ,case when p.thematique_action_logement is not null then 1 else null end as is_action_housing
                         ,case when lower(ct.contract_type) in ('cdi') 
                                     and range_seniority_company_age >= """ + borne_1_year + """ 
                                     and c.contract_start_date <= to_date('""" + year_id + """1231', 'yyyyMMdd')  and (c.contract_end_date is null or c.contract_end_date >= to_date('""" + year_id + """1231', 'yyyyMMdd')) then 1 
                               when  lower(ct.contract_type) in ('cdi')  
                                     and c.contract_end_date is not null
                                     and date_format(c.contract_end_date,'yyyy') = '""" + year_id + """' and datediff(to_date(c.contract_end_date),to_date(ccc.continous_service_date)) >= """ + borne_1_year + """ then 1  else null end as is_eligible_action_housing

                         ,s.is_pay_increase
                         ,s.pay_increase_amount
                         ,c.total_base_pay        
                         ,s.annual_contractual_pay_amount
                         ,s.annual_contractual_pay_n_1_amount
                         ,s.annual_contractual_pay_m_1_amount  
                         
                         ,s.foreign_travel_indemnity_amount
                         ,s.foreign_travel_indemnity_percent                         
                         ,s.primary_comp_basis_amount
                         ,s.month_13th_amount
                         ,s.bonus_target
                         ,s.compensation_currency
                    
                         
                         ,case when c.total_base_pay is null or s.total_base_pay = 0  then null
                               when lower(ct.contract_type) in ('stagiaire') and s.total_base_pay* """ + pourcentage_pi + """ < """ + plafond_pi + """ then s.total_base_pay*""" + pourcentage_pi + """
                               when lower(ct.contract_type) <> ('stagiaire') and ((s.total_base_pay/12)*13)* """ + pourcentage_pi + """ < """ + plafond_pi + """ then ((s.total_base_pay/12)*13)* """ + pourcentage_pi + """ else """ + plafond_pi + """ end as p_i_estimated_amount 
                         
                         ,case when  c.contract_end_date <= last_day(to_date(cast(""" + date_id + """ as string),'yyyyMMdd')) and pr.flag_montant_rem_reelle = 1 then p.payroll_amount else null end as additional_rem_amount  
                         
                
                         ,case when date_format(c.contract_start_date, 'yyyyMM') <= """ + month_id + """
                                     and (c.contract_end_date is null or date_format(c.contract_end_date, 'yyyyMM') >= """ + month_id + """) then """ + holidays_bonus + """ else null end as bonus_holidays
                         
                         ,case when date_format(c.contract_start_date, 'yyyyMM') <= """ + month_id + """
                                     and (c.contract_end_date is null or date_format(c.contract_end_date, 'yyyyMM') >= """ + month_id + """) then """ + pourcentage_pi + """ else null end as percent_pi
                                     
                         ,case when date_format(c.contract_start_date, 'yyyyMM') <= """ + month_id + """
                                     and (c.contract_end_date is null or date_format(c.contract_end_date, 'yyyyMM') >= """ + month_id + """) then """ + plafond_pi + """ else null end as plafond_pi
                         
                         ,case when date_format(c.contract_start_date, 'yyyyMM') <= """ + month_id + """
                                     and (c.contract_end_date is null or date_format(c.contract_end_date, 'yyyyMM') >= """ + month_id + """) then
                                     case when upper(op.top_level) = 'CHANEL FRANCE' and upper(csp.cadre_non_cadre) = 'NON CADRE' and lower(ct.contract_type) <> ('stagiaire') and upper(op.libelle_departement) not in ('ATELIER HC','ATELIER PAP') then """+ bonus_agreement_amount_CHANEL_France +"""
                               when upper(op.top_level) = 'VERNEUIL' and upper(csp.cadre_non_cadre) = 'NON CADRE' and lower(ct.contract_type) <> ('stagiaire') then """+ bonus_agreement_amount_Verneuil +""" else null end else null end as bonus_salarial_agreement_amount

                         ,case when date_format(c.contract_start_date, 'yyyyMM') <= """ + month_id + """
                                     and (c.contract_end_date is null or date_format(c.contract_end_date, 'yyyyMM') >= """ + month_id + """) then 
                           case when upper(op.top_level) = 'VERNEUIL' and lower(ct.contract_type) <> ('stagiaire') then """+ bonus_defile_collection_Verneuil +""" 
                               when upper(op.top_level) = 'CHANEL FRANCE' and lower(ct.contract_type) = 'cdd' and upper(op.libelle_departement) in ('ATELIER HC','ATELIER PAP') and upper(ct.classification_collective_agreement) = '4A' then """+bonus_defile_collection_CHANEL_France_CDD_4+"""
                               when upper(op.top_level) = 'CHANEL FRANCE' and lower(ct.contract_type) = 'cdd' and upper(op.libelle_departement) in ('ATELIER HC','ATELIER PAP') and upper(ct.classification_collective_agreement) = '2B' then """+bonus_defile_collection_CHANEL_France_CDD_2B+"""
                               when upper(op.top_level) = 'CHANEL FRANCE' and lower(ct.contract_type) = 'cdd' and upper(op.libelle_departement) in ('ATELIER HC','ATELIER PAP') and upper(ct.classification_collective_agreement) = '2A' then """+bonus_defile_collection_CHANEL_France_CDD_2A+"""
                               when upper(op.top_level) = 'CHANEL FRANCE' and lower(ct.contract_type) = 'cdd' and upper(op.libelle_departement) in ('ATELIER HC','ATELIER PAP') and upper(ct.classification_collective_agreement) in ('3C','3B','3A','2C') then """+bonus_defile_collection_CHANEL_France_CDD_3+"""
                               when upper(op.top_level) = 'CHANEL FRANCE' and lower(ct.contract_type) in ('cdi', 'alternant') and upper(op.libelle_departement) in ('ATELIER HC','ATELIER PAP') and upper(ct.classification_collective_agreement) in ('3C','3B','3A','2C') then """+bonus_defile_collection_CHANEL_France_CDI_3+"""
                               when upper(op.top_level) = 'CHANEL FRANCE' and lower(ct.contract_type) in ('cdi', 'alternant') and upper(op.libelle_departement) in ('ATELIER HC','ATELIER PAP') and upper(ct.classification_collective_agreement) in ('2A','1A') then """+bonus_defile_collection_CHANEL_France_CDI_2A+"""
                               when upper(op.top_level) = 'CHANEL FRANCE' and lower(ct.contract_type) in ('cdi', 'alternant') and upper(op.libelle_departement) in ('ATELIER HC','ATELIER PAP') and upper(ct.classification_collective_agreement) in ('2B') then """+bonus_defile_collection_CHANEL_France_CDI_2B+"""
                               when upper(op.top_level) = 'CHANEL FRANCE' and lower(ct.contract_type) in ('cdi', 'alternant') and upper(op.libelle_departement) in ('ATELIER HC','ATELIER PAP') and upper(ct.classification_collective_agreement) in ('4A','4B','4','5C','5B','5A') then """+bonus_defile_collection_CHANEL_France_CDI_4+"""
                            else null end else null end as bonus_defile_collection      
                         
                                         
                         
                         ,case when upper(pr.code_rubrique_paie) in ('WE1P', 'WE2P', 'WE3P', 'WE4P', 'WE5P', 'VB5P','WE1S', 'WE2S', 'WE3S', 'WE4S', 'WE5S', 'VB5S') and p.payroll_amount is not null then 1 else null end as nb_account_consent
                        
                        
                          ,case when cet.nb_cet_solded_days is null then 0 else cet.nb_cet_solded_days end as nb_cet_solded_days 
                          ,case when cet.nb_cet_taken_days is null then 0 else cet.nb_cet_taken_days end  as nb_cet_taken_days
                          ,case when cet.nb_cet_consumed_days is null then 0 else cet.nb_cet_consumed_days end as nb_cet_consumed_days 
                          ,case when cet.nb_cet_beneficiary_days is null then 0 else cet.nb_cet_beneficiary_days end as nb_cet_beneficiary_days
                          ,case when cet.percent_cet is null then 0 else cet.percent_cet end as percent_cet
                          
                          
                         ,c.default_weekly_hours
                         ,c.scheduled_weekly_hours
                         ,c.additional_job_classifications
                         ,c.additional_job_classifications_label
                         
                         ,coalesce(d.employee_id, -1) as employee_id
                         ,coalesce(ct.contract_type_id, -1) as contract_type_id
                         ,coalesce(wr.worker_rate_id, -1) as worker_rate_id
                         ,case when upper(c.contract_type) = 'VA' or  lower(ct.contract_type_detailed) = 'vacataire' then """ + vacataire_csp_id + """ else coalesce(csp.csp_id, -1) end as csp_id
                         ,coalesce(nat.nationality_id, -1) as nationality_id
                         ,coalesce(ag.range_age_id, -1) as range_age_id
                         ,coalesce(sec.seniority_company_id, -1) as seniority_company_id
                         ,coalesce(sep.seniority_position_id, -1) as seniority_position_id
                         ,coalesce(loc.location_id,-1) as location_id
                         ,coalesce(job.job_architecture_id, -1) as job_architecture_id
                         ,coalesce(man.manager_id, -1) as manager_id
                         ,coalesce(so.supervisory_organization_id, -1) as supervisory_organization_id
                         ,coalesce(ol.legal_organization_id,'-1') as legal_organization_id
                         ,coalesce(op.operational_organization_id,'-1') as operational_organization_id
                         ,coalesce(mob_in.mobility_in_id, -1) as mobility_in_id
                         ,coalesce(mob_out.mobility_out_id,-1) as mobility_out_id
                         ,coalesce(id.info_dates_id, -1) as info_dates_id
                         ,coalesce(iod.in_out_dates_id, -1) as in_out_dates_id
                         ,coalesce(hi_pb.hierarchy_pb_id, -1) as hierarchy_pb_id
                         ,coalesce(pr.payroll_id, -1) as payroll_id
                         
                         ,-2 as compensation_change_id
                         ,-2 as compensation_merit_plan_id
                         ,-2 compensation_bonus_plan_id                         
                         ,-2 as increase_type_id       
                         
                         ,coalesce(ah.action_housing_id,-1) as action_housing_id
                         ,coalesce(rp.range_payout_id, -1) as range_payout_id                         
                         ,coalesce(rpe.range_percol_id,-1) as range_percol_id                         
                         ,case when p.is_eligible_psb_nplus1 = 1 
                               then (case when p.is_eligible=1 then 1 else 2 end) 
                               else (case when p.is_eligible=1 then 3 else -1 end)  end as eligibility_psb_id   


                         ,""" + date_id + """ as date_id
                         ,current_timestamp() as recordcreationdate
                         ,'""" + runid + """' as runid
                         
                         ,s.is_compensation_bonus_plan
                         ,coalesce(rpd.range_payout_detailed_id, -1) as range_payout_detailed_id
                         , case when (p.rank_housing = 1 or p.rank_housing is null) 
                                and (p.rank_car = 1 or p.rank_car is null) then p.payroll_amount * case when pr.libelle_rubrique_paie_niv1 = '6 - BSI' and 'adp' = lower('""" + system_source + """') then -1 else 1 end else null end as payroll_amount_all
                         ,case when cast(""" + date_id + """ as int) >= 20220301 then s.prime_co_percent end as prime_co_percent
                         ,case when cast(""" + date_id + """ as int) >= 20220301 then s.prime_exp_percent end as prime_exp_percent
                         
                   from vw_pay p 
                        inner join vw_employee e on (e.employee_code = p.employee_code or (e.france_payroll_id = p.france_payroll_id and p.employee_id is null and e.rank_hra = 1))
                        inner join vw_contract c on e.employee_code = c.employee_code
                        
                        left join vw_d_employee d on e.employee_code = d.employee_code
                        left join vw_d_nationality nat on e.nationality_code = nat.nationality_code
                        left join vw_d_range_age ag on ag.range_age = (case when isnull(e.birth_date) then null else floor(months_between(to_date('""" + date_id + """','yyyyMMdd'),e.birth_date,true)/12) end)
                        left join vw_d_location loc on e.location_code = loc.location_code
                        left join vw_d_manager man on e.manager_code = man.manager_code
                        left join vw_d_supervisory_organization so on e.supervisory_organization_code = so.supervisory_organization_code
                        left join vw_d_legal_organization ol on e.legal_organization_code = ol.legal_organization_code
                        left join vw_d_operational_organization op on e.operational_organization_code = op.operational_organization_code
                        left join vw_d_mobility_in mob_in on mob_in.mobility_in_code = c.mobility_in_code
                        left join vw_d_mobility_out mob_out on mob_out.mobility_out_code = c.mobility_out_code
                        left join vw_d_in_out_dates iod on iod.in_out_dates_code = c.in_out_dates_code 
                                                       and iod.org_in_out_dates_code = e.org_in_out_dates_code
                        
                        left join vw_contract_job_change ccc on ccc.employee_code = c.employee_code 
                                                            and c.contract_start_date = ccc.contract_start_date 
                                                            and ccc.rank=1                                                              
                        left join vw_d_worker_rate wr on ccc.worker_rate_code = wr.worker_rate_code                                          
                        left join vw_d_csp csp on ccc.csp_code = csp.csp_code           
                               
                        left join vw_d_contract_type ct on c.contract_type_code = ct.contract_type_code
                                                       and ccc.collective_agreement_code = ct.collective_agreement_code
                                                       
                        left join vw_d_job_architecture job on ccc.job_title_code = job.job_title_code    
                                                           and coalesce(ccc.grade_code, -1) = coalesce(job.grade_code, -1) 
                               
                        left join vw_d_info_dates id on id.company_dates_code = ccc.company_dates_code 
                                                    and id.contract_dates_code = c.contract_dates_code      
                         
                        left join vw_d_seniority_company sec on sec.range_seniority_company_age = (case when isnull(ccc.continous_service_date) then null else datediff(to_date(seniority_date_max),to_date(ccc.continous_service_date)) end)
                        left join vw_d_seniority_position sep on sep.range_seniority_position_age = (case when isnull(ccc.position_start_date) then null else datediff(to_date(seniority_date_max),to_date(ccc.position_start_date)) end)
                      
                        
                        left join vw_d_payroll pr on pr.payroll_code = p.payroll_code
                        left join vw_bonus bo on bo.employee_code = p.employee_code and bo.code_rubr = p.code_rubr               
                        left join vw_d_action_housing ah on ah.action_housing_code = p.action_housing_code     
                        left join vw_percol_ytd py on py.employee_code = p.employee_code and py.code_rubr = p.code_rubr 
                        left join vw_d_range_percol rpe on ceil(py.percol_abound_amount_ytd) between rpe.range_percol_min and rpe.range_percol_max
                        
                        
                        left join vw_contract_salary_full s on s.employee_code = e.employee_code
                        
                    
                        left join vw_cet cet on cet.employee_code = e.employee_code 
                        left join vw_d_hierarchy_pb hi_pb on e.cost_center_code = hi_pb.cost_center_code
                        
                        
                        left join vw_d_range_payout rp on coalesce(s.percent_payout,-1) between rp.range_payout_min and rp.range_payout_max
                        left join vw_d_range_payout_detailed rpd on coalesce(s.percent_payout,-1) between rpd.range_payout_min_detailed and rpd.range_payout_max_detailed   
                   """

// COMMAND ----------

val df_pay_results = spark.sql(query_pay)
//put the dataframe ont he cache
//val inserted_records = df_pay_results.cache().count().toInt //count the number of read records


// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """Exec [dbo].[usp_deletePartitionTableData] 'f_pay','pay','myMonthlyRangePS',""" + date_id
val res = stmt.execute(query_delete)

// COMMAND ----------

df_pay_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").option("schemacheckenabled","false").jdbc(jdbcurl, "pay.f_pay", connectionproperties)


// COMMAND ----------

/*val read_records = df_employee_read.count().toInt 
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0
*/

val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from Cache
df_employee_read.unpersist
df_pay_results.unpersist
df_pay_read_full.unpersist
df_pay_read.unpersist
df_prevPay.unpersist
df_decPay.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)