// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non utilisé"

// COMMAND ----------

 if(spark.catalog.tableExists("hr.training")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.training")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bytraining_status = Window.partitionBy("training_recap_status", "training_status_code", "training_type").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_training_status =  spark.table("hr.training").withColumn("rank",rank() over bytraining_status)
                                                    .filter(col("rank")==="1")
                                                    .select( "training_recap_status"
                                                            ,"training_status_code" 
                                                            ,"training_type"
                                                            ,"version"
                                                            ,"date_raw_load_file"
                                                            ,"filepath"
                                                            ,"filename"
                                                            ,"current_record"
                                                            ,"record_start_date"
                                                            ,"record_end_date"
                                                            ,"record_creation_date"
                                                            ,"record_modification_date"
                                                            ,"curated_ingested_date")
                                                 .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                                                 .distinct
                  
df_training_status.createOrReplaceTempView("vw_training_status")


// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.param_training_status", connectionproperties).createOrReplaceTempView("vw_param_training_status")

// COMMAND ----------

val query_record = """

select 
  
   distinct 
    ts.training_status_code as training_status_code
    ,coalesce(trim(prm.training_status),'"""+ default_hierarchy_value +"""') as training_status_label
    ,dense_rank() over (order by prm.consolidated_training_status,prm.training_status) as training_status_order
    ,coalesce(trim(prm.consolidated_training_status),'"""+ default_hierarchy_value +"""') as training_consolidated_status
    ,dense_rank() over (order by prm.consolidated_training_status) as training_consolidated_status_order

  
    ,ts.version
    ,ts.date_raw_load_file
    ,ts.filepath
    ,ts.filename
    ,ts.curated_ingested_date
    ,ts.current_record
    ,ts.record_start_date
    ,ts.record_end_date
    ,ts.record_creation_date
    ,ts.record_modification_date


    ,sha2(getconcatenedstring(array(  
      consolidated_training_status
    )),256)  as hashkey
    ,'""" + runid + """' as runid 
    
  from vw_training_status ts

  inner join vw_param_training_status prm
  on trim(lower(prm.training_type)) = trim(lower(ts.training_type)) and trim(lower(prm.training_recap_status)) = trim(lower(ts.training_recap_status))

  where 1=1
  and ts.training_recap_status is not null

"""

// COMMAND ----------

val training_status_inserted = spark.sql(query_record)
training_status_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_training_status """
val res = stmt.execute(query_delete)

// COMMAND ----------

training_status_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_training_status", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_training_status """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_training_status.count().toInt //count the number of read records
val inserted_records = training_status_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0


// COMMAND ----------

df_training_status.unpersist
training_status_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)

// COMMAND ----------

//dbutils.widgets.help()