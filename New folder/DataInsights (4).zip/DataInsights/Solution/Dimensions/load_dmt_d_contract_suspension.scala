// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract_suspension")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract_suspension")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bycontract_suspension = Window.partitionBy("reason").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_suspension_read = spark.table("hr.contract_suspension").withColumn("rank",rank() over bycontract_suspension)
                           .filter(col("rank")==="1")
                           .select(   "reason"
                                     ,"label_reason" 
                                     ,"category"
                                     ,"label_category"
                                     ,"version"
                                     ,"date_raw_load_file"
                                     ,"filepath"
                                     ,"filename"
                                     ,"record_creation_date"
                                     ,"record_modification_date"
                                     ,"curated_ingested_date")
                          .distinct
df_contract_suspension_read.createOrReplaceTempView("vw_d_contract_suspension")
df_contract_suspension_read.cache()  //put the dataframe ont he cache
//display(df_contract_suspension_read)

// COMMAND ----------

val query_record = """select 
                                    cs.reason as motif 
                                   ,last(cs.label_reason) as libelle_motif
                                   ,last(cs.category) as categorie
                                   ,last(cs.label_category) as libelle_categorie
                                   ,last(cs.version) as version
                                   ,last(cs.date_raw_load_file) as date_raw_load_file
                                   ,last(cs.filepath) as filepath
                                   ,last(cs.filename) as filename
                                   ,last(cs.curated_ingested_date) as curated_ingested_date
                                   ,1 as current_record
                                   ,last(cs.record_modification_date) as record_start_date
                                   ,timestamp(null) as record_end_date
                                   ,last(cs.record_creation_date) as record_creation_date
                                   ,last(cs.record_modification_date) as record_modification_date
                                   ,sha2(cs.reason, 256) as contract_suspension_code
                                   ,sha2(getconcatenedstring(array(last(cs.label_reason)
                                                                   ,last(cs.category)
                                                                   ,last(cs.label_category))),256)  as hashkey
                                   ,'""" + runid + """' as runid
                         
                        from vw_d_contract_suspension cs
                        
                        where 1 = 1
                          and (cs.reason is not null and cs.reason<>'')
                          
                        group by   
                                    cs.reason
                        """ 

// COMMAND ----------

val contract_suspension_inserted = spark.sql(query_record)
contract_suspension_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_contract_suspension """
val res = stmt.execute(query_delete)

// COMMAND ----------

contract_suspension_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_contract_suspension", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_contract_suspension """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_contract_suspension_read.count().toInt //count the number of read records
val inserted_records =contract_suspension_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_contract_suspension_read.unpersist
contract_suspension_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)