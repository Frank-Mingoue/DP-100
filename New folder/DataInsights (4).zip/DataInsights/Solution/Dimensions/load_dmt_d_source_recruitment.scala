// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_autre = "Non Affecte"
val default_hierarchy_order = 99

// COMMAND ----------

 if(spark.catalog.tableExists("hr.job_application")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.job_application")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bysource = Window.partitionBy("source_reference").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_source_recruitment_read = spark.table("hr.job_application").withColumn("rank",rank() over bysource)
                                                              .filter(col("rank")==="1")
                                                              .select("source_reference"
                                                                      ,"source_reference_code","version"
                                                                      ,"date_raw_load_file"
                                                                      ,"filepath"
                                                                      ,"filename"
                                                                      ,"current_record"
                                                                      ,"record_start_date"
                                                                      ,"record_end_date"
                                                                      ,"record_creation_date"
                                                                      ,"record_modification_date"
                                                                      ,"curated_ingested_date")
                                                              .distinct
df_source_recruitment_read.createOrReplaceTempView("vw_source_recruitment")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_source_recruitment", connectionproperties).createOrReplaceTempView("vw_ref_source_recruitment")

// COMMAND ----------

val query_record = """select  distinct
                              r.source_reference as source_reference
                             ,coalesce(rs.source_recruitment_detailed, '""" + default_hierarchy_autre + """') as source_recruitment_detailed
                             ,coalesce(rs.source_recruitment_detailed_order, """ + default_hierarchy_order + """) as source_recruitment_detailed_order
                             ,coalesce(rs.source_recruitment_consolidated, '""" + default_hierarchy_autre + """') as source_recruitment_consolidated
                             ,coalesce(rs.source_recruitment_consolidated_order, """ + default_hierarchy_order + """) as source_recruitment_consolidated_order
                             ,coalesce(rs.source_recruitment_type, '""" + default_hierarchy_autre + """') as source_recruitment_type
                             ,coalesce(rs.source_recruitment_type_order, """ + default_hierarchy_order + """) as source_recruitment_type_order
                             ,r.version 
                             ,r.date_raw_load_file
                             ,r.filepath
                             ,r.filename
                             ,r.curated_ingested_date
                             ,r.current_record
                             ,r.record_start_date
                             ,r.record_end_date
                             ,r.record_creation_date
                             ,r.record_modification_date
                             ,sha2(getconcatenedstring(array(r.source_reference)),256) as source_recruitment_code
                             ,sha2(getconcatenedstring(array(rs.source_recruitment_detailed
                                                            ,rs.source_recruitment_consolidated
                                                            ,rs.source_recruitment_type)),256)  as hashkey
                             ,'""" + runid + """' as runid
                         
                        from vw_source_recruitment r   
                             left join vw_ref_source_recruitment rs on trim(lower(r.source_reference)) = trim(lower(rs.source_value))
                        where 1=1
                          and r.source_reference is not null
                      """ 


// COMMAND ----------

val source_recruitment_inserted = spark.sql(query_record)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_source_recruitment """
val res = stmt.execute(query_delete)

// COMMAND ----------

source_recruitment_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_source_recruitment", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_source_recruitment """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_source_recruitment_read.count().toInt //count the number of read records
val inserted_records = source_recruitment_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_source_recruitment_read.unpersist
source_recruitment_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)