// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

if(spark.catalog.tableExists("hr.career")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.career")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bycareer_review = Window.partitionBy("review_reference").orderBy($"review_initiated_date".desc,$"review_end_date".desc,$"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc, $"record_creation_date".desc, $"version".desc, $"current_record".desc, $"filename".desc)
val df_review_read = spark.table("hr.career").withColumn("review_type_reference_old",$"review_type_reference")
                                             .withColumn("review_type_reference",when(lower($"review_reference").contains("year end"),"Year End")
                                                                                .when(lower($"review_reference").contains("mid-year"),"Mid-Year")
                                                                                .otherwise($"review_type_reference"))
                                             .withColumn("review_end_date_old", $"review_end_date")
                                             .withColumn("review_end_date",when(lower($"review_reference").contains("year end"),$"review_end_date")
                                                                                .when(lower($"review_reference").contains("mid-year"),$"my_review_end_date")
                                                                                .otherwise(coalesce($"review_end_date", $"my_review_end_date")))
                                             .withColumn("rank",rank() over bycareer_review)
                                             .filter(col("rank")==="1")
                                             .select( "review_reference" 
                                                   ,"review_type_reference" 
                                                   ,"review_initiated_date"
                                                   ,"review_end_date"
                                                   ,"review_code"
                                                   ,"version"
                                                   ,"date_raw_load_file"
                                                   ,"filepath"
                                                   ,"filename"
                                                   ,"current_record"
                                                   ,"record_start_date"
                                                   ,"record_end_date"
                                                   ,"record_creation_date"
                                                   ,"record_modification_date"
                                                   ,"curated_ingested_date")
                                            .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")                                                      
                                            .distinct
df_review_read.createOrReplaceTempView("vw_review")

// COMMAND ----------

val query_record = """ select  distinct                               
                               r.review_reference 
                              ,r.review_type_reference
                              ,r.review_initiated_date
                              ,r.review_end_date
                              ,r.review_code as review_code
                              ,r.version
                              ,r.date_raw_load_file
                              ,r.filepath
                              ,r.filename
                              ,r.curated_ingested_date    
                              ,r.record_start_date
                              ,r.record_end_date
                              ,r.record_creation_date 
                              ,r.record_modification_date
                              ,sha2(getconcatenedstring(array(r.review_type_reference
                                                             ,r.review_initiated_date
                                                             ,r.review_end_date)),256)  as hashkey
                              ,'""" + runid + """' as runid
                         
                        from  vw_review r 
                        where 1=1
                          and r.review_reference is not null
                      
                      union
                      
                      select  distinct                               
                               'NC' 
                              ,r.review_type_reference
                              ,null
                              ,null
                              ,sha2(getconcatenedstring(array('NC'
                                                             ,r.review_type_reference)),256) as review_code
                              ,last(r.version) as version
                              ,last(r.date_raw_load_file) as date_raw_load_file
                              ,last(r.filepath) as filepath
                              ,last(r.filename) as filename
                              ,last(r.curated_ingested_date) as curated_ingested_date    
                              ,last(r.record_start_date) as record_start_date
                              ,last(r.record_end_date) as record_end_date
                              ,last(r.record_creation_date) as record_creation_date 
                              ,last(r.record_modification_date) as record_modification_date
                              ,sha2(getconcatenedstring(array('NC'
                                                             ,r.review_type_reference)),256)  as hashkey
                              ,'""" + runid + """' as runid
                         
                        from  vw_review r 
                        where 1=1
                          and r.review_type_reference is not null
                        group by r.review_type_reference
                      """ 


// COMMAND ----------

val review_inserted = spark.sql(query_record)
review_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_career_review """
val res = stmt.execute(query_delete)

// COMMAND ----------

review_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_career_review", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_career_review"""
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_review_read.count().toInt //count the number of read records
val inserted_records = review_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_review_read.unpersist
review_inserted.unpersist

// COMMAND ----------

spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)