// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

if(spark.catalog.tableExists("hr.career")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.career")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bycareer_goal = Window.partitionBy("goal_id", "goal_due_date").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_modification_date".desc,$"record_end_date".desc,$"filename".desc)
val df_goal_read = spark.table("hr.career").withColumn("rank",rank() over bycareer_goal)
                                           .filter(col("rank")==="1")
                                           .select( "goal_id" 
                                                   ,"goal_due_date"
                                                   ,"goal_completion_date" 
                                                   ,"version"
                                                   ,"date_raw_load_file"
                                                   ,"filepath"
                                                   ,"filename"
                                                   ,"current_record"
                                                   ,"record_start_date"
                                                   ,"record_end_date"
                                                   ,"record_creation_date"
                                                   ,"record_modification_date"
                                                   ,"curated_ingested_date")
                                            .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")                                                      
                                            .distinct
df_goal_read.createOrReplaceTempView("vw_goal")

// COMMAND ----------

val query_record = """ select  distinct                               
                               g.goal_id 
                              ,case when substr(g.goal_due_date, 0,4) in ('0222','3020') then concat('2020',substr(g.goal_due_date, 5,10)) else g.goal_due_date end as goal_due_date
                              ,case when substr(g.goal_completion_date, 0,4) in ('0222','3020') then concat('2020',substr(g.goal_completion_date, 5,10)) else g.goal_completion_date end as goal_completion_date 
                              ,sha2(getconcatenedstring(array(g.goal_id
                                                             ,g.goal_due_date
                                                             ,g.goal_completion_date)),256) as career_goal_code
                              ,g.version
                              ,g.date_raw_load_file
                              ,g.filepath
                              ,g.filename
                              ,g.curated_ingested_date    
                              ,g.record_start_date
                              ,g.record_end_date
                              ,g.record_creation_date 
                              ,g.record_modification_date                               
                              ,sha2(getconcatenedstring(array(
                                                              g.goal_due_date
                                                             ,g.goal_completion_date
                                                             )),256)  as hashkey
                              ,'""" + runid + """' as runid
                         
                       from   vw_goal g 
                       where  1=1
                        and   g.goal_id is not null
                        and   g.goal_due_date is not null
                      """ ,

// COMMAND ----------

val goal_inserted = spark.sql(query_record)
goal_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_career_goal """
val res = stmt.execute(query_delete)

// COMMAND ----------

goal_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_career_goal", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_career_goal"""
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_goal_read.count().toInt //count the number of read records
val inserted_records = goal_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_goal_read.unpersist
goal_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)