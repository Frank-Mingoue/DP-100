// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_range_payout_detailed", connectionproperties).createOrReplaceTempView("vw_param_payout_detailed")

// COMMAND ----------

val query_record = """select distinct
                             range_payout_percent_detailed
                            ,range_payout_detailed
                            ,range_payout_order_detailed
                            ,range_payout_min_detailed
                            ,range_payout_max_detailed
                            ,recordcreationdate
                            ,recordmodificationdate
                            ,sha2(cast(range_payout_percent_detailed as string),256) as range_payout_code_detailed
                            ,sha2(cast(array( range_payout_detailed)as string),256) as hashkey
                            ,'""" + runid + """' as runid
                         
                        from vw_param_payout_detailed
                        where range_payout_percent_detailed is not null and range_payout_detailed is not null
                        """

// COMMAND ----------

val range_payout_detailed_inserted = spark.sql(query_record)
range_payout_detailed_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_range_payout_detailed """
val res = stmt.execute(query_delete)

// COMMAND ----------

range_payout_detailed_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_range_payout_detailed", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_range_payout_detailed """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val inserted_records = range_payout_detailed_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + inserted_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
range_payout_detailed_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)