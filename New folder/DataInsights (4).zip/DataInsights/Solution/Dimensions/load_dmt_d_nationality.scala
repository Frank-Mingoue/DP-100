// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value = "Non affecté"

// COMMAND ----------

 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bynationality_id = Window.partitionBy("primary_nationality","additional_nationalities").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_nationality_read = spark.table("hr.employee").withColumn("rank",rank() over bynationality_id)
                .filter(col("rank")==="1")
                .select(  "primary_nationality"
                         ,"additional_nationalities"
                         ,"version"
                         ,"date_raw_load_file"
                         ,"filepath"
                         ,"filename"
                         ,"current_record"
                         ,"record_start_date"
                         ,"record_end_date"
                         ,"record_creation_date"
                         ,"record_modification_date"
                         ,"curated_ingested_date")
                  .distinct
df_nationality_read.createOrReplaceTempView("vw_nationality")
df_nationality_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.param_nationality", connectionproperties).createOrReplaceTempView("vw_param_nationality")

// COMMAND ----------

//ON code_iso_3 = primary_nationality  changed to ON country_name_fr= primary_nationality as code_iso_3 is based on the country code

val query_record = """select 
                                   coalesce(last(pn.country_group), '""" + default_hierarchy_value + """') as nationality_group
                                  ,n.primary_nationality as primary_nationality_code
                                  ,coalesce(last(pn.country_name_fr), n.primary_nationality) as primary_nationality
                                  ,coalesce(last(pn_bis.country_name_fr),trim(getvalueposition(n.additional_nationalities,0,';'))) as secondary_nationality
                                  ,n.additional_nationalities as additional_nationalities_code
                                  ,coalesce(last(pn_add.country_name_fr),n.additional_nationalities) as additional_nationalities
                                  ,last(n.version) as version
                                  ,last(n.date_raw_load_file) as date_raw_load_file
                                  ,last(n.filepath) as filepath
                                  ,last(n.filename) as filename
                                  ,last(n.curated_ingested_date) as curated_ingested_date
                                  ,last(n.current_record) as current_record
                                  ,last(n.record_start_date) as record_start_date
                                  ,last(n.record_end_date) as record_end_date
                                  ,last(n.record_creation_date) as record_creation_date
                                  ,last(n.record_modification_date) as record_modification_date         
                                  ,sha2(getconcatenedstring(array(n.primary_nationality,n.additional_nationalities)),256) as nationality_code
                                  ,sha2(getconcatenedstring(array(last(pn.country_group))),256) as hashkey
                                  ,'""" + runid + """' as runid
                         
                        from vw_nationality n
                             left join vw_param_nationality pn on lower(pn.code_iso_3) = lower(n.primary_nationality)        
                             left join vw_param_nationality pn_bis on lower(pn_bis.code_iso_3) = lower(trim(getvalueposition(n.additional_nationalities,0,';')))    
                             left join vw_param_nationality pn_add on lower(pn_add.code_iso_3) = lower(n.additional_nationalities) 
                        where 1=1
                          and n.primary_nationality is not null
                          
                        group by 
                                  n.primary_nationality
                                  ,n.additional_nationalities """ 


// COMMAND ----------

val nationality_inserted = spark.sql(query_record)

nationality_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_nationality """
val res = stmt.execute(query_delete)

// COMMAND ----------

nationality_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_nationality", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_nationality """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_nationality_read.count().toInt //count the number of read records
val inserted_records = nationality_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_nationality_read.unpersist
nationality_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)