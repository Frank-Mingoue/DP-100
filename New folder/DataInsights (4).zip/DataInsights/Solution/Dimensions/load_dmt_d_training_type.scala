// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

 if(spark.catalog.tableExists("hr.training")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.training")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bytraining_type = Window.partitionBy("training_type", "training_type_code").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_training_type =  spark.table("hr.training").withColumn("rank",rank() over bytraining_type)
                                                  .filter(col("rank")==="1")
                                                  .select( "training_type"
                                                          ,"training_type_code"                             
                                                          ,"version"
                                                          ,"date_raw_load_file"
                                                          ,"filepath"
                                                          ,"filename"
                                                          ,"current_record"
                                                          ,"record_start_date"
                                                          ,"record_end_date"
                                                          ,"record_creation_date"
                                                          ,"record_modification_date"
                                                          ,"curated_ingested_date")
                                               .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                                               .distinct
df_training_type.createOrReplaceTempView("vw_training_type")


// COMMAND ----------

val query_record = """
  select 
    distinct
    t.training_type as training_type_code
    ,t.training_type as training_type_label
    ,dense_rank() over(order by training_type) as training_type_order
    ,t.version
    ,t.date_raw_load_file
    ,t.filepath
    ,t.filename
    ,t.curated_ingested_date
    ,t.current_record
    ,t.record_start_date
    ,t.record_end_date
    ,t.record_creation_date
    ,t.record_modification_date


    ,sha2(getconcatenedstring(array(  
      training_type
    )),256)  as hashkey
    ,'""" + runid + """' as runid 

  from vw_training_type t


  where 1=1
  and t.training_type is not null

"""

// COMMAND ----------

val training_type_inserted = spark.sql(query_record)
training_type_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_training_type """
val res = stmt.execute(query_delete)

// COMMAND ----------

training_type_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_training_type", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_training_type """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_training_type.count().toInt //count the number of read records
val inserted_records = training_type_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0


// COMMAND ----------

df_training_type.unpersist
training_type_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)