// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bymobility_out = Window.partitionBy("local_termination_reason").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_mobility_out_read = spark.table("hr.contract").withColumn("rank",rank() over bymobility_out)
            .filter(col("rank")==="1")
                  .select("local_termination_reason",
                          "version",
                          "filepath",
                          "filename",
                          "curated_ingested_date",
                          "current_record",
                          "record_start_date",
                          "record_end_date",
                          "record_creation_date",
                          "record_modification_date",
                          "date_raw_load_file")
                  .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                  .distinct

df_mobility_out_read.createOrReplaceTempView("vw_mobility_out")
df_mobility_out_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_mobility", connectionproperties).createOrReplaceTempView("vw_param_mobility")

// COMMAND ----------

 //,ct.libelle_nature_contrat
val query_record = """select 
                                mob_out.local_termination_reason
                               ,coalesce(last(pm.mobility_detail_order),99) as local_termination_reason_order
                               ,coalesce(last(pm.mobility_group), '""" + default_hierarchy_value + """') as local_termination_reason_group
                               ,coalesce(last(pm.mobiltiy_group_order),99) as local_termination_reason_group_order
                               ,last(mob_out.version) as version
                               ,last(mob_out.date_raw_load_file) as date_raw_load_file
                               ,last(mob_out.filepath) as filepath
                               ,last(mob_out.filename) as filename
                               ,last(mob_out.curated_ingested_date) as curated_ingested_date
                               ,last(mob_out.current_record) as current_record
                               ,last(mob_out.record_start_date) as record_start_date
                               ,last(mob_out.record_end_date) as record_end_date
                               ,last(mob_out.record_creation_date) as record_creation_date
                               ,last(mob_out.record_modification_date) as record_modification_date
                               ,sha2(mob_out.local_termination_reason,256) as mobility_out_code
                               ,sha2(getconcatenedstring(array( mob_out.local_termination_reason
                                                               ,last(pm.mobility_group))),256) as hashkey
                              
                               ,'""" + runid + """' as runid 
                                                                      
                        from vw_mobility_out mob_out 
                             left join vw_param_mobility pm on trim(lower(mob_out.local_termination_reason)) = trim(lower(pm.source_value))
                        where 1=1
                          and mob_out.local_termination_reason is not null
                        group by 
                                mob_out.local_termination_reason
                               """

// COMMAND ----------

val mobility_out_inserted = spark.sql(query_record)
mobility_out_inserted.cache()  //put the dataframe ont he cache


// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_mobility_out """
val res = stmt.execute(query_delete)

// COMMAND ----------

mobility_out_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_mobility_out", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_mobility_out """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_mobility_out_read.count().toInt //count the number of records to upsert
val inserted_records = mobility_out_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_mobility_out_read.unpersist
mobility_out_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)

// COMMAND ----------

//dbutils.widgets.help()