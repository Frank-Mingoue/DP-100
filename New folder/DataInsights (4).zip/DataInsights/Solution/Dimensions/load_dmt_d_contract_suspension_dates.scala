// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract_suspension")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract_suspension")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bycontract_suspension_dates = Window.partitionBy("contract_suspension_start_date","contract_suspension_end_date").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_suspension_dates_read = spark.table("hr.contract_suspension").withColumn("rank",rank() over bycontract_suspension_dates)
                           .filter(col("rank")==="1")
                           .select(   "contract_suspension_start_date"
                                     ,"contract_suspension_end_date"  
                                     ,"version"
                                     ,"date_raw_load_file"
                                     ,"filepath"
                                     ,"filename"
                                     ,"record_creation_date"
                                     ,"record_modification_date"
                                     ,"curated_ingested_date")
                          .distinct

df_contract_suspension_dates_read.createOrReplaceTempView("vw_d_contract_suspension_dates")
df_contract_suspension_dates_read.cache()  //put the dataframe ont he cache


// COMMAND ----------

val query_record = """select 
                                    cs.contract_suspension_start_date as contract_suspension_start_date
                                   ,cs.contract_suspension_end_date as contract_suspension_end_date
                                   ,case when cs.contract_suspension_end_date is null then null else datediff(cs.contract_suspension_end_date,cs.contract_suspension_start_date) end as contract_suspension_duration
                                   ,last(cs.version) as version
                                   ,last(cs.date_raw_load_file) as date_raw_load_file
                                   ,last(cs.filepath) as filepath
                                   ,last(cs.filename) as filename
                                   ,last(cs.curated_ingested_date) as curated_ingested_date
                                   ,1 as current_record
                                   ,last(cs.record_modification_date) as record_start_date
                                   ,timestamp(null) as record_end_date
                                   ,last(cs.record_creation_date) as record_creation_date
                                   ,last(cs.record_modification_date) as record_modification_date
                                   ,sha2(getconcatenedstring(array(cs.contract_suspension_start_date
                                                                        ,cs.contract_suspension_end_date)),256) as contract_suspension_dates_code
                                   ,sha2(getconcatenedstring(array(cs.contract_suspension_start_date
                                                                        ,cs.contract_suspension_end_date)),256)  as hashkey
                                   ,'""" + runid + """' as runid
                         
                        from vw_d_contract_suspension_dates cs
                        
                        where 1 = 1 
                          and (cs.contract_suspension_start_date is not null or cs.contract_suspension_end_date is not null )
                          
                        group by   
                               cs.contract_suspension_start_date
                               ,cs.contract_suspension_end_date
                        """ 

// COMMAND ----------

val contract_suspension_dates_inserted = spark.sql(query_record)
contract_suspension_dates_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_contract_suspension_dates """
val res = stmt.execute(query_delete)

// COMMAND ----------

contract_suspension_dates_inserted.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_contract_suspension_dates", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_contract_suspension_dates"""
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_contract_suspension_dates_read.count().toInt //count the number of read records
val inserted_records =contract_suspension_dates_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_contract_suspension_dates_read.unpersist
contract_suspension_dates_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)