// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bycontract_dates = Window.partitionBy("employee_code","contract_start_date","contract_end_date","contract_type","contract_type_label").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_dates_read = spark.table("hr.contract").withColumn("rank",rank() over bycontract_dates)
                           .filter(col("rank")==="1")
                           .select(   "employee_code"
                                     ,"contract_start_date"
                                     ,"contract_end_date" 
                                     ,"contract_type"
                                     ,"contract_type_label"
                                     ,"version"
                                     ,"date_raw_load_file"
                                     ,"filepath"
                                     ,"filename"
                                     ,"current_record"
                                     ,"record_start_date"
                                     ,"record_end_date"
                                     ,"record_creation_date"
                                     ,"record_modification_date"
                                     ,"curated_ingested_date")
                          .withColumn("new_contract_end_date", when(to_date(col("contract_end_date")) === lit("2999-12-31"),null).otherwise(col("contract_end_date")))
                          .distinct
df_contract_dates_read.createOrReplaceTempView("vw_d_contract_dates")
df_contract_dates_read.cache()  //put the dataframe ont he cache


// COMMAND ----------

val bycompany_dates = Window.partitionBy("employee_code","position_start_date","hire_date","original_hire_date","continous_service_date","contract_start_date","contract_type_label").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_company_dates_read = spark.table("hr.contract").withColumn("rank",rank() over bycompany_dates)
                           .filter(col("rank")==="1")
                           .select(  
                                     "employee_code"
                                     ,"position_start_date"
                                     ,"hire_date" 
                                     ,"original_hire_date"
                                     ,"continous_service_date"
                                     ,"contract_start_date"
                                     ,"contract_type"
                                     ,"contract_type_label"
                                     ,"version"
                                     ,"date_raw_load_file"
                                     ,"filepath"
                                     ,"filename"
                                     ,"current_record"
                                     ,"record_start_date"
                                     ,"record_end_date"
                                     ,"record_creation_date"
                                     ,"record_modification_date"
                                     ,"curated_ingested_date")
                          .distinct
df_company_dates_read.createOrReplaceTempView("vw_d_company_dates")
df_company_dates_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_range_contract_duration", connectionproperties).createOrReplaceTempView("vw_ref_range_contract_duration")


// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.vw_d_contract_type", connectionproperties).select("contract_type","contract_nature").where(lower($"contract_type")==="cdi" or
                                                                                 lower($"contract_type")==="détaché").distinct.createOrReplaceTempView("vw_staff_d_contract_type")

// COMMAND ----------

val query_record = """select 
                                   case when c.position_start_date is null then d.contract_start_date
                                        else c.position_start_date end as position_start_date
                                   ,c.continous_service_date as hire_date
                                   ,case when ct.contract_type is not null then null else
                                         datediff(d.new_contract_end_date,d.contract_start_date)+1 end as contract_duration
                                   ,d.contract_start_date
                                   ,d.new_contract_end_date as contract_end_date
                                   ,last(d.version) as version
                                   ,last(d.date_raw_load_file) as date_raw_load_file
                                   ,last(d.filepath) as filepath
                                   ,last(d.filename) as filename
                                   ,last(d.curated_ingested_date) as curated_ingested_date
                                   ,last(d.current_record) as current_record
                                   ,last(d.record_start_date) as record_start_date
                                   ,last(d.record_end_date) as record_end_date
                                   ,last(d.record_creation_date) as record_creation_date
                                   ,last(d.record_modification_date) as record_modification_date
                                   ,sha2(getconcatenedstring(array(c.position_start_date
                                                                  ,c.continous_service_date
                                                                  ,d.contract_start_date
                                                                  ,d.contract_end_date
                                                                  ,d.contract_type)),256) as info_dates_code
                                   ,sha2(getconcatenedstring(array(
                                                                   d.contract_start_date
                                                                  ,d.contract_end_date
                                                                  ,d.contract_type)),256) as contract_dates_code
                                                                  
                                   ,sha2(getconcatenedstring(array(c.position_start_date
                                                                  ,c.continous_service_date)),256) as company_dates_code
                                                                  
                                   ,sha2(getconcatenedstring(array(c.position_start_date
                                                                        ,c.continous_service_date
                                                                        ,d.contract_start_date
                                                                        ,d.new_contract_end_date
                                                                        ,d.contract_type
                                                                        ,last(cd.range_contract_duration))),256)  as hashkey
                                   ,'""" + runid + """' as runid
                                   ,case when ct.contract_type is not null then null else last(cd.range_contract_duration) end as range_contract_duration
                                   ,case when ct.contract_type is not null then null else last(cd.range_contract_duration_order) end as range_contract_duration_order
                        from vw_d_contract_dates d
                             inner join vw_d_company_dates c on d.employee_code = c.employee_code 
                             left join vw_ref_range_contract_duration cd on 
                                 (datediff(d.new_contract_end_date,d.contract_start_date)+1) >= cd.range_contract_duration_min 
                             and (datediff(d.new_contract_end_date,d.contract_start_date)+1) < cd.range_contract_duration_max
                             left join vw_staff_d_contract_type ct on d.contract_type = ct.contract_nature
                        where 1 = 1
                          and (c.position_start_date is not null or c.continous_service_date is not null or d.contract_start_date is not null)
                          
                        group by   
                                c.position_start_date
                               ,c.continous_service_date
                               ,d.contract_start_date
                               ,d.new_contract_end_date
                               ,d.contract_end_date
                               ,d.contract_type
                               ,ct.contract_type
                        """ 

// COMMAND ----------

val info_dates_inserted = spark.sql(query_record)
info_dates_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_info_dates """
val res = stmt.execute(query_delete)

// COMMAND ----------

info_dates_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_info_dates", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_info_dates"""
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_contract_dates_read.count().toInt //count the number of read records
val inserted_records =info_dates_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_contract_dates_read.unpersist
df_company_dates_read.unpersist
info_dates_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)