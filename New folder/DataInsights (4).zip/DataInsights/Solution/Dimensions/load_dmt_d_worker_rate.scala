// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val byworker_rate = Window.partitionBy("time_type","fte","paidfte").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_worker_rate_read = spark.table("hr.contract").withColumn("rank",rank() over byworker_rate)
                   .filter(col("rank")==="1")
                   .select(   "time_type" 
                             ,"time_type_label" 
                             ,"fte"                           
                             ,"paidfte"
                             ,"version"
                             ,"date_raw_load_file"
                             ,"filepath"
                             ,"filename"
                             ,"current_record"
                             ,"record_start_date"
                             ,"record_end_date"
                             ,"record_creation_date"
                             ,"record_modification_date"
                             ,"curated_ingested_date")
                  .distinct

df_worker_rate_read.createOrReplaceTempView("vw_worker_rate")
df_worker_rate_read.cache()  //put the dataframe on the cache

// COMMAND ----------

 //,ct.libelle_nature_contrat
val query_record = """select 
                                    ct.time_type
                                   ,ct.time_type_label 
                                   ,ct.fte
                                   ,ct.paidfte
                                   ,last(ct.version) as version
                                   ,last(ct.date_raw_load_file) as date_raw_load_file
                                   ,last(ct.filepath) as filepath
                                   ,last(ct.filename) as filename
                                   ,last(ct.curated_ingested_date) as curated_ingested_date
                                   ,last(ct.current_record) as current_record
                                   ,last(ct.record_start_date) as record_start_date
                                   ,last(ct.record_end_date) as record_end_date
                                   ,last(ct.record_creation_date) as record_creation_date
                                   ,last(ct.record_modification_date) as record_modification_date
                                   ,sha2(getconcatenedstring(array( ct.time_type
                                                                   ,ct.fte
                                                                   ,ct.paidfte)),256) as worker_rate_code
                                   ,sha2(getconcatenedstring(array( ct.time_type_label)),256)  as hashkey
                                   ,'""" + runid + """' as runid                       
                                                                      
                        from vw_worker_rate ct
                        where 1=1
                          and (ct.time_type is not null or ct.fte is not null or ct.paidfte is not null)
                        group by 
                               ct.time_type
                              ,ct.time_type_label
                              ,ct.fte
                              ,ct.paidfte
                       """

// COMMAND ----------

val worker_rate_inserted = spark.sql(query_record)
worker_rate_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_worker_rate """
val res = stmt.execute(query_delete)

// COMMAND ----------

worker_rate_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_worker_rate", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_worker_rate """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val inserted_records = worker_rate_inserted.count().toInt //count the number of read records
val read_records = df_worker_rate_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_worker_rate_read.unpersist
worker_rate_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)