// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_autre = "Non Affecte"

// COMMAND ----------

 if(spark.catalog.tableExists("common.organization")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE common.organization")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val byoperational_organization = Window.partitionBy("cost_center_code","code_direction","code_department","business_line_reference","business_line_name").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_operational_organization_read = spark.table("common.organization").withColumn("rank",rank() over byoperational_organization)
                                                                         .filter(col("rank")==="1")
                                                                         .select( "code_direction" 
                                                                                 ,"label_direction"                           
                                                                                 ,"code_department"
                                                                                 ,"label_department"
                                                                                 ,"cost_center_code"
                                                                                 ,"cost_center_label"
                                                                                 ,"business_line_reference"
                                                                                 ,"business_line_name" 
                                                                                 ,"current_hierarchy"                                   
                                                                                 ,"version"
                                                                                 ,"date_raw_load_file"
                                                                                 ,"filepath"
                                                                                 ,"filename"
                                                                                 ,"current_record"
                                                                                 ,"record_start_date"
                                                                                 ,"record_end_date"
                                                                                 ,"record_creation_date"
                                                                                 ,"record_modification_date"
                                                                                 ,"curated_ingested_date")
                                                                      .distinct
                                                                      .orderBy($"record_start_date",$"record_end_date")
                                                                      
df_operational_organization_read.cache()
df_operational_organization_read.createOrReplaceTempView("vw_d_operational_organization")  //put the dataframe ont he cache

// COMMAND ----------

val byoperational_organization_current = Window.partitionBy("cost_center_code","code_direction","code_department","business_line_reference","business_line_name").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_operational_organization_read_current = spark.table("common.organization")
                     .filter($"current_hierarchy" === true)
                     .withColumn("rank",rank() over byoperational_organization_current)
                     .filter(col("rank")==="1")
                     .select( "code_direction"                           
                             ,"code_department"
                             ,"cost_center_code"
                             ,"business_line_reference"
                             ,"business_line_name" 
                             ,"current_hierarchy"                        )
                  .distinct
                  .orderBy($"record_start_date",$"record_end_date")
                  .createOrReplaceTempView("vw_d_operational_organization_current")
 //put the dataframe ont he cache

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_operational_organization", connectionproperties).createOrReplaceTempView("vw_ref_operational_organization")

// COMMAND ----------

val query_record = """select 
                                    coalesce(po.top_level, '""" + default_hierarchy_autre + """') as top_level
                                   ,coalesce(last(po.top_level_order),99) as top_level_order
                                   ,coalesce(po.division_consolidated, '""" + default_hierarchy_autre + """') as division_consolidated                                   
                                   ,coalesce(last(po.division_consolidated_order),99) as division_consolidated_order
                                   ,coalesce(po.division_detailed, '""" + default_hierarchy_autre + """') as division_detailed                                   
                                   ,coalesce(last(po.division_detailed_order),99) as division_detailed_order
                                   ,o.code_direction                                 
                                   ,coalesce(last(po.direction_order),99) as direction_order
                                   ,coalesce(last(o.label_direction),'""" + default_hierarchy_autre + """') as libelle_direction
                                   ,o.code_department as code_departement 
                                   ,coalesce(last(o.label_department),'""" + default_hierarchy_autre + """') as libelle_departement
                                   ,o.cost_center_code
                                   ,last(o.cost_center_label) as cost_center_label
                                   ,o.business_line_reference
                                   ,o.business_line_name as business_line_name
                                   ,last(o.version) as version
                                   ,last(o.date_raw_load_file) as date_raw_load_file
                                   ,last(o.filepath) as filepath
                                   ,last(o.filename) as filename
                                   ,last(o.curated_ingested_date) as curated_ingested_date
                                   ,last(o.current_record) as current_record
                                   ,last(o.record_start_date) as record_start_date
                                   ,last(o.record_end_date) as record_end_date
                                   ,last(o.record_creation_date) as record_creation_date
                                   ,last(o.record_modification_date) as record_modification_date
                                   ,sha2(getconcatenedstring(array(   o.cost_center_code
                                                                     ,o.code_direction
                                                                     ,o.code_department
                                                                     ,o.business_line_reference
                                                                     ,o.business_line_name
                                                                     )),256) as operational_organization_code
                                   ,sha2(getconcatenedstring(array(
                                                                      coalesce(po.top_level, '""" + default_hierarchy_autre + """')
                                                                     ,coalesce(last(po.top_level_order),99)
                                                                     ,coalesce(po.division_consolidated, '""" + default_hierarchy_autre + """')
                                                                     ,coalesce(last(po.division_consolidated_order),99)
                                                                     ,coalesce(po.division_detailed, '""" + default_hierarchy_autre + """')
                                                                     ,coalesce(last(po.division_detailed),99) 
                                                                     ,coalesce(last(o.label_direction),'""" + default_hierarchy_autre + """') 
                                                                     ,coalesce(last(o.label_department),'""" + default_hierarchy_autre + """') 
                                                                     ,last(o.cost_center_label) )),256) as hashkey
                                   ,'""" + runid + """' as runid
                                   ,max(or.current_hierarchy) as current_hierarchy
                         
                        from vw_d_operational_organization o
                            left join vw_ref_operational_organization po on coalesce(lower(o.code_direction),lower(o.label_direction)) = lower(po.direction)
                            left join vw_d_operational_organization_current or on coalesce(or.cost_center_code,'-1') = coalesce(o.cost_center_code,'-1')
                                                                              and coalesce(or.code_direction,'-1')= coalesce(o.code_direction,'-1')
                                                                              and coalesce(or.code_department,'-1') = coalesce(o.code_department,'-1')
                                                                              and coalesce(or.business_line_reference,'-1') = coalesce(o.business_line_reference,'-1')
                                                                              and coalesce(or.business_line_name,'-1') = coalesce(o.business_line_name,'-1')
                        where 1=1
                          and o.cost_center_code is not null 
                        group by
                                 po.top_level
                                ,po.division_consolidated
                                ,po.division_detailed
                                ,o.code_direction
                                ,o.code_department
                                ,o.cost_center_code
                                ,o.business_line_reference
                                ,o.business_line_name
                        """ 

// COMMAND ----------

val operational_organization_inserted = spark.sql(query_record)
operational_organization_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_operational_organization """
val res = stmt.execute(query_delete)

// COMMAND ----------

operational_organization_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_operational_organization", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_operational_organization """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_operational_organization_read.count().toInt //count the number of read records
val inserted_records = operational_organization_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_operational_organization_read.unpersist
operational_organization_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)