// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

 if(spark.catalog.tableExists("hr.employee_children")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee_children")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val byemployee_dependent = Window.partitionBy("employee_id","france_payroll_id","l_children_first_name","l_children_last_name","children_date_of_birth").orderBy($"record_creation_date".desc,$"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)

val df_employee_dependent_read = spark.table("hr.employee_children") 
                          .withColumn("l_children_first_name",lower($"children_first_name"))
                          .withColumn("l_children_last_name",lower($"children_last_name"))
                          .withColumn("l_children_first_name_ai",stringNormalizer(col("children_first_name")))
                          .withColumn("l_children_last_name_ai",stringNormalizer(col("children_last_name")))
                          .withColumn("rank",rank() over byemployee_dependent)
                          .filter(col("rank")==="1")
                          .select(   "employee_id"
                                    ,"france_payroll_id"
                                    ,"rank"
                                    ,"employee_code"
                                    ,"children_order_number" 
                                    ,"children_gender"                           
                                    ,"children_date_of_birth"
                                    ,"children_first_name"
                                    ,"l_children_last_name_ai"
                                    ,"children_last_name"
                                    ,"children_dependent"
                                    ,"children_date_of_death"
                                    ,"version"
                                    ,"date_raw_load_file"
                                    ,"filepath"
                                    ,"filename"
                                    ,"current_record"
                                    ,"record_start_date"
                                    ,"record_end_date"
                                    ,"record_creation_date"
                                    ,"record_modification_date"
                                    ,"curated_ingested_date")
                        .distinct

df_employee_dependent_read.createOrReplaceTempView("vw_d_employee_dependent")
df_employee_dependent_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

val d_employees = spark.read.jdbc(jdbcurl, "staff.d_employee", connectionproperties).select("employee_id", "employee_code").createOrReplaceTempView("vw_d_employee")

// COMMAND ----------

val query_record = """select distinct
                                    e.employee_id
                                   ,lpad((row_number() over (partition by e.employee_id order by last(ed.children_date_of_birth))),2,'0') as children_order_number
                                   ,last(ed.children_gender) as children_gender
                                   ,last(ed.children_date_of_birth) as children_date_of_birth
                                   ,ed.children_first_name
                                   ,ed.children_last_name
                                   ,last(ed.children_dependent) as children_dependent
                                   ,last(ed.children_date_of_death) as children_date_of_death
                                   ,'' as date_deb_prise_en_charge
                                   ,'' as date_fin_prise_en_charge
                                   ,'0' as enfant_a_charge_secu
                                   ,'' as date_deb_prise_en_charge_secu
                                   ,'' as date_fin_prise_en_charge_secu
                                   ,last(ed.version) as version
                                   ,last(ed.date_raw_load_file) as date_raw_load_file
                                   ,last(ed.filepath) as filepath
                                   ,last(ed.filename) as filename
                                   ,last(ed.curated_ingested_date) as curated_ingested_date
                                   ,last(ed.current_record) as current_record
                                   ,last(ed.record_start_date) as record_start_date
                                   ,last(ed.record_end_date) as record_end_date
                                   ,last(ed.record_creation_date) as record_creation_date
                                   ,last(ed.record_modification_date) as record_modification_date
                                   ,sha2(getconcatenedstring(array(e.employee_id
                                                                   ,lower(ed.children_first_name)
                                                                   ,lower(ed.l_children_last_name_ai)
                                                                   ,ed.children_date_of_birth)),256) as employee_dependent_code
                                   ,sha2(getconcatenedstring(array(last(ed.children_gender)
                                                                   ,last(ed.children_dependent))),256) as hashkey
                                   ,'""" + runid + """' as runid
                         
                        from vw_d_employee_dependent ed
                             inner join vw_d_employee e on ed.employee_code = e.employee_code
                        where 1 = 1
                          and (ed.children_first_name is not null or ed.children_last_name is not null)
                          
                        group by
                                    e.employee_id
                                   ,ed.children_first_name
                                   ,ed.children_last_name
                                   ,ed.children_order_number
                                   ,ed.children_date_of_birth
                                   ,ed.employee_id
                                   ,ed.france_payroll_id 
                                   ,ed.l_children_last_name_ai
                                   """ 

// COMMAND ----------

val employee_dependent_inserted = spark.sql(query_record)
employee_dependent_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_employee_dependent"""
val res = stmt.execute(query_delete)

// COMMAND ----------

employee_dependent_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_employee_dependent", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staff.d_employee_dependent"""
val res = stmt.execute(query_delete)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_employee_dependent """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_employee_dependent_read.count().toInt //count the number of read records
val inserted_records = employee_dependent_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_employee_dependent_read.unpersist
employee_dependent_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)