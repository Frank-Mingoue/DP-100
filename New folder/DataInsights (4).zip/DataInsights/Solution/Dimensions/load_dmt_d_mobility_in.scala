// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bymobility_in = Window.partitionBy("event_classification_subcategory","contract_reason").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_mobility_in_read = spark.table("hr.contract").withColumn("rank",rank() over bymobility_in)
                                                  .filter(col("rank")==="1")
                                                  .select( "event_classification_subcategory" 
                                                          ,"event_classification_subcategory_label" 
                                                          ,"rank"
                                                          ,"contract_reason"
                                                          ,"version"
                                                          ,"date_raw_load_file"
                                                          ,"record_start_date"
                                                          ,"record_end_date"
                                                          ,"filepath"
                                                          ,"filename"
                                                          ,"current_record"
                                                          ,"record_creation_date"
                                                          ,"record_modification_date"
                                                          ,"curated_ingested_date")
                                                   .distinct
df_mobility_in_read.createOrReplaceTempView("vw_mobility_in")
df_mobility_in_read.cache()  //put the dataframe on the cache



// COMMAND ----------

 //,ct.libelle_nature_contrat
val query_record = """select 
                                mob_in.event_classification_subcategory
                               ,last(mob_in.event_classification_subcategory_label) as event_classification_subcategory_label
                               ,last(mob_in.version) as version
                               ,last(mob_in.date_raw_load_file) as date_raw_load_file
                               ,last(mob_in.filepath) as filepath
                               ,last(mob_in.filename) as filename
                               ,last(mob_in.curated_ingested_date) as curated_ingested_date
                               ,last(mob_in.current_record) as current_record
                               ,last(mob_in.record_start_date) as record_start_date
                               ,last(mob_in.record_end_date) as record_end_date
                               ,last(mob_in.record_creation_date) as record_creation_date
                               ,last(mob_in.record_modification_date) as record_modification_date
                               ,case when mob_in.contract_reason is null then sha2(mob_in.event_classification_subcategory,256) else sha2(getconcatenedstring(array(mob_in.event_classification_subcategory,mob_in.contract_reason)),256) end as mobility_in_code
                               ,sha2(getconcatenedstring(array( last(mob_in.event_classification_subcategory_label))),256) as hashkey
                               ,'""" + runid + """' as runid 
                               ,coalesce(mob_in.contract_reason,last(mob_in.event_classification_subcategory_label)) as contract_reason
                                                                      
                        from   vw_mobility_in mob_in
                        where  1=1
                          and (mob_in.event_classification_subcategory is not null or mob_in.contract_reason is not null)
                        group by 
                                mob_in.event_classification_subcategory,
                                mob_in.contract_reason
                               """

// COMMAND ----------

val mobility_in_inserted = spark.sql(query_record)
mobility_in_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_mobility_in """
val res = stmt.execute(query_delete)

// COMMAND ----------

mobility_in_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_mobility_in", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_mobility_in """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val inserted_records = mobility_in_inserted.count().toInt //count the number of read records
val read_records = df_mobility_in_read.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_mobility_in_read.unpersist
mobility_in_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)

// COMMAND ----------

//dbutils.widgets.help()