// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_autre = "Non Affecte"

// COMMAND ----------

 if(spark.catalog.tableExists("common.organization")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE common.organization")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val by_hierarchy_pb = Window.partitionBy("cost_center_code").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_hierarchy_pb_read = spark.table("common.organization").filter($"direction_detail_code".isNotNull or $"direction_detail_code".isNotNull)
                         .withColumn("rank",rank() over by_hierarchy_pb)
                         .filter(col("rank")==="1")
                         .select("cost_center_code" 
                                   ,"cost_center_label"                           
                                   ,"direction_detail_name"
                                   ,"direction_detail_code"
                                   ,"direction_code"
                                   ,"direction_name"
                                   ,"direction_psb_budget_code"
                                   ,"direction_psb_budget_name"
                                   ,"direction_presentation_code"
                                   ,"direction_presentation_name"
                                   ,"version"
                                   ,"date_raw_load_file"
                                   ,"filepath"
                                   ,"filename"
                                   ,"current_record"
                                   ,"record_start_date"
                                   ,"record_end_date"
                                   ,"record_creation_date"
                                   ,"record_modification_date"
                                   ,"curated_ingested_date")
                         .distinct
df_hierarchy_pb_read.createOrReplaceTempView("vw_d_hierarchy_pb")
df_hierarchy_pb_read.cache()  //put the dataframe ont he cache


// COMMAND ----------

///last + groupby
val query_record = """select 
                          
                            o.cost_center_code
                            ,last(o.cost_center_label) as cost_center_label
                            ,last(o.direction_detail_code) as direction_detail_code
                            ,last(o.direction_detail_name) as direction_detail_name
                            ,last(o.direction_code) as direction_code
                            ,last(o.direction_name) as direction_name
                            ,last(o.direction_psb_budget_code) as direction_psb_budget_code
                            ,last(o.direction_psb_budget_name) as direction_psb_budget_name
                            ,last(o.direction_presentation_code) as direction_presentation_code
                            ,last(o.direction_presentation_name) as direction_presentation_name
                            ,last(o.version) as version
                            ,last(o.date_raw_load_file) as date_raw_load_file
                            ,last(o.filepath) as filepath
                            ,last(o.filename) as filename
                            ,last(o.curated_ingested_date) as curated_ingested_date
                            ,last(o.current_record) as current_record
                            ,last(o.record_start_date) as record_start_date
                            ,last(o.record_end_date) as record_end_date
                            ,last(o.record_creation_date) as record_creation_date
                            ,last(o.record_modification_date) as record_modification_date
                            ,sha2(o.cost_center_code,256) as hierarchy_pb_code
                            ,sha2(getconcatenedstring(array(
                                                              last(o.cost_center_label)
                                                              ,last(o.direction_detail_code)
                                                              ,last(o.direction_detail_name)
                                                              ,last(o.direction_code)
                                                              ,last(o.direction_name)
                                                              ,last(o.direction_psb_budget_code)
                                                              ,last(o.direction_psb_budget_name)
                                                              ,last(o.direction_presentation_code)
                                                              ,last(o.direction_presentation_name))),256) as hashkey
                                   ,'""" + runid + """' as runid
                                   
                        from vw_d_hierarchy_pb o
                        
                        where 1=1
                          and o.cost_center_code is not null
                          
                        group by
                                   o.cost_center_code             
                         """ 

// COMMAND ----------

val hierarchy_pb_inserted = spark.sql(query_record)
hierarchy_pb_inserted.cache()  //put the dataframe ont he cache


// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_hierarchy_pb """
val res = stmt.execute(query_delete)

// COMMAND ----------

hierarchy_pb_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_hierarchy_pb", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_hierarchy_pb """
stmt.execute(sql)
connection.close()

// COMMAND ----------

val read_records = df_hierarchy_pb_read.count().toInt //count the number of read records
val inserted_records = hierarchy_pb_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_hierarchy_pb_read.unpersist
hierarchy_pb_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)