// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_init_param_range_table 'param_age' """
stmt.execute(sql)

connection.close()

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.param_age", connectionproperties).createOrReplaceTempView("vw_param_age")

// COMMAND ----------

val query_record = """select distinct
                                    range_age
                                   ,range_age_order_level_1
                                   ,range_age_level_1
                                   ,range_age_level_2
                                   ,range_age_order_level_2
                                   ,range_age_min
                                   ,range_age_max
                                   ,recordcreationdate
                                   ,recordmodificationdate
                                   ,sha2(cast(range_age as string),256) as range_age_code
                                   ,sha2(getconcatenedstring(array(range_age_level_1,range_age_level_2)),256) as hashkey
                                   ,'""" + runid + """' as runid
                         
                        from vw_param_age
                        where range_age is not null and range_age_level_1 is not null
                        """

// COMMAND ----------

val range_age_inserted = spark.sql(query_record)
range_age_inserted.cache()  //put the dataframe ont he cache
//display(range_age_inserted)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_range_age """
val res = stmt.execute(query_delete)

// COMMAND ----------

range_age_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_range_age", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_range_age """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val inserted_records = range_age_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + inserted_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
range_age_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)