// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_range_absence_duration", connectionproperties).createOrReplaceTempView("vw_param_absence_duration")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_range_absence_prol_duration", connectionproperties).createOrReplaceTempView("vw_param_absence_duration_prol")

// COMMAND ----------

val query_record = """   select     distinct
                                    d.range_absence_duration
                                   ,d.range_absence_duration_order
                                   ,d.range_absence_duration_min
                                   ,d.range_absence_duration_max
                                   ,dp.range_absence_duration_prol
                                   ,dp.range_absence_duration_prol_order
                                   ,dp.range_absence_duration_prol_min
                                   ,dp.range_absence_duration_prol_max
                                   ,d.recordcreationdate
                                   ,d.recordmodificationdate
                                   ,sha2(getconcatenedstring(array(d.range_absence_duration, dp.range_absence_duration_prol)),256) as range_absence_duration_code
                                   ,sha2(getconcatenedstring(array(d.range_absence_duration_order,dp.range_absence_duration_prol_order)),256) as hashkey
                                   ,'""" + runid + """' as runid
                                   
                         
                        from       vw_param_absence_duration d
                                   full join vw_param_absence_duration_prol  dp on 1 =1
                        where      1=1
                          and      d.range_absence_duration is not null
                          
                        union
                        
                        select     distinct
                                    d.range_absence_duration
                                   ,d.range_absence_duration_order
                                   ,d.range_absence_duration_min
                                   ,d.range_absence_duration_max
                                   ,'NC'
                                   ,100
                                   ,0
                                   ,0
                                   ,d.recordcreationdate
                                   ,d.recordmodificationdate
                                   ,sha2(getconcatenedstring(array(d.range_absence_duration,'NC')),256) as range_absence_duration_code
                                   ,sha2(getconcatenedstring(array(d.range_absence_duration_order,100)),256) as hashkey
                                   ,'""" + runid + """' as runid
                                   
                         
                        from       vw_param_absence_duration d
                        where      1=1
                          and      d.range_absence_duration is not null
                  
                        
                        """

// COMMAND ----------

val absence_duration_inserted = spark.sql(query_record)
absence_duration_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_range_absence_duration """
val res = stmt.execute(query_delete)

// COMMAND ----------

absence_duration_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_range_absence_duration", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_range_absence_duration """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val inserted_records = absence_duration_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + inserted_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
absence_duration_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)