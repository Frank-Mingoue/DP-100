// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

/*val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_init_param_range_table 'param_percol' """
stmt.execute(sql)

connection.close()*/

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_range_percol", connectionproperties).createOrReplaceTempView("vw_param_percol")

// COMMAND ----------

val query_record = """select distinct
                                    range_percol_detailed
                                   ,range_percol_detailed_order
                                   ,range_percol
                                   ,range_percol_order
                                   ,range_percol_min
                                   ,range_percol_max
                                   ,recordcreationdate
                                   ,recordmodificationdate
                                   ,sha2(cast(range_percol_detailed as string),256) as range_percol_code
                                   ,sha2(getconcatenedstring(array(range_percol)),256) as hashkey
                                   ,'""" + runid + """' as runid
                         
                        from vw_param_percol
                        where range_percol_detailed is not null
                        """

// COMMAND ----------

val range_percol_inserted = spark.sql(query_record)
range_percol_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_range_percol """
val res = stmt.execute(query_delete)

// COMMAND ----------

range_percol_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_range_percol", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_range_percol """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val inserted_records = range_percol_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + inserted_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
range_percol_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)