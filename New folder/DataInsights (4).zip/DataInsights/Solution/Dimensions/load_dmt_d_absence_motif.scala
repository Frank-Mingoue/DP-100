// Databricks notebook source
// DBTITLE 1,Get Parameters for DB Connection and the RunId
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include the functions to connect to databases and ADLS
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Connections to the Database
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value = "Non Affecté"

// COMMAND ----------

// DBTITLE 1,Prepare the table hr absenteism for reading
 if(spark.catalog.tableExists("hr.absenteism")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bymotif = Window.partitionBy("code").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_motif_read = spark.table("hr.absenteism").withColumn("rank",rank() over bymotif)
                                                //.filter(col("rank")==="1")
                                                .select( "employee_hra"
                                                        ,"code"
                                                        ,"dateval"
                                                        ,"label"
                                                        ,"version"
                                                        ,"date_raw_load_file"
                                                        ,"filepath"
                                                        ,"filename"
                                                        ,"current_record"
                                                        ,"record_start_date"
                                                        ,"record_end_date"
                                                        ,"record_creation_date"
                                                        ,"record_modification_date"
                                                        ,"curated_ingested_date")
                                                 .distinct
df_motif_read.createOrReplaceTempView("vw_motif")
df_motif_read.cache()  //put the dataframe on the cache


// COMMAND ----------

 if(spark.catalog.tableExists("hr.referential_absences")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.referential_absences")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val byref_abs = Window.partitionBy("absence_code").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc)
val df_ref_abs_read = spark.table("hr.referential_absences").withColumn("rank",rank() over byref_abs)
                                                        //.filter(col("rank")==="1")
                                                        .select( "period"
                                                                ,"absence_code"
                                                                ,"absence_label_code"
                                                                ,"absence_reason"
                                                                ,"absence_family"
                                                                ,"absence_rate"
                                                                ,"absence_predictable_unpredictable"
                                                                ,"flag_productive_etp"
                                                                ,"flag_absence_rate"
                                                                ,"flag_prolongation"   
                                                                ,"absence_type"
                                                                ,"version"
                                                                ,"date_raw_load_file"
                                                                ,"filepath"
                                                                ,"filename"
                                                                ,"current_record"
                                                                ,"record_start_date"
                                                                ,"record_end_date"
                                                                ,"record_creation_date"
                                                                ,"record_modification_date"
                                                                ,"curated_ingested_date")
                                                         .distinct
df_ref_abs_read.createOrReplaceTempView("vw_ref_abs")
df_ref_abs_read.cache()  //put the dataframe on the cache


// COMMAND ----------

// DBTITLE 1,Select columns to insert
val query_record = """select 
                                   
                                    last(ra.period) as period
                                   ,mt.code as absence_code
                                   ,mt.label as absence_label_code
                                   ,last(ra.absence_reason) as absence_reason
                                   ,last(ra.absence_family) as absence_family
                                   ,last(ra.absence_rate) as absence_rate
                                   ,last(ra.absence_predictable_unpredictable) as absence_predictable_unpredictable
                                   ,case when last(lower(ra.flag_productive_etp)) = 'oui' then 1
                                         when last(lower(ra.flag_productive_etp)) = 'non' then 0
                                         else null end as flag_productive_etp
                                   ,case when last(lower(ra.flag_absence_rate)) = 'oui' then 1
                                         when last(lower(ra.flag_absence_rate)) = 'non' then 0
                                         else null end as flag_absence_rate
                                   ,case when last(lower(ra.flag_prolongation)) = 'oui' then 1
                                         when last(lower(ra.flag_prolongation)) = 'non' then 0
                                         else null end as flag_prolongation
                                   ,last(ra.absence_type) as absence_type
                                   ,case when last(ra.absence_code) is not null then 1 else 0 end as flag_ref 
                                   ,last(mt.version) as version
                                   ,last(mt.date_raw_load_file) as date_raw_load_file
                                   ,last(mt.filepath) as filepath
                                   ,last(mt.filename) as filename
                                   ,last(mt.curated_ingested_date) as curated_ingested_date
                                   ,last(mt.current_record) as current_record
                                   ,last(mt.record_start_date) as record_start_date
                                   ,last(mt.record_end_date) as record_end_date
                                   ,last(mt.record_creation_date) as record_creation_date
                                   ,last(mt.record_modification_date) as record_modification_date                            
                                   ,sha2(getconcatenedstring(array( mt.code
                                                                   ,mt.label
                                                                   )),256)  as hashkey 
                                    
                                   ,'""" + runid + """' as runid
                        from vw_motif mt
                        left join vw_ref_abs ra on ra.absence_code = mt.code

                        where 1 = 1
                          and mt.code is not null
                          
                        group by 
                                 mt.code
                                ,mt.label
                        """ 

// COMMAND ----------

// DBTITLE 1,Store the query results in the dataframe and put the dataframe in the cache
val motif_inserted = spark.sql(query_record)
motif_inserted.cache()  //put the dataframe on the cache


// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_motif """
val res = stmt.execute(query_delete)

// COMMAND ----------

motif_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_motif", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_motif """
stmt.execute(sql)

connection.close()

// COMMAND ----------

//set up the return value with the number of lines read, rejected and inserted
val read_records = df_motif_read.count().toInt //count the number of read records
val inserted_records = motif_inserted.count().toInt //count the number of read records
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_motif_read.unpersist
motif_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)