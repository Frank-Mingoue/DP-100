// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------


val bycompensation_change = Window.partitionBy("compensation_change_reason", "compensation_change_subreason").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_compensation_change_read = spark.table("hr.contract").withColumn("rank",rank() over bycompensation_change)
                           .filter(col("rank")==="1")
                           .select(   "compensation_change_reason"
                                     ,"compensation_change_subreason" 
                                     ,"version"
                                     ,"date_raw_load_file"
                                     ,"filepath"
                                     ,"filename"
                                     ,"current_record"
                                     ,"record_start_date"
                                     ,"record_end_date"
                                     ,"record_creation_date"
                                     ,"record_modification_date"
                                     ,"curated_ingested_date")
                          .distinct

df_compensation_change_read.createOrReplaceTempView("vw_d_compensation_change")
df_compensation_change_read.cache()  //put the dataframe ont he cache


// COMMAND ----------

val query_record = """select 
                                    cc.compensation_change_subreason
                                   ,cc.compensation_change_reason as compensation_change_reason
                                   ,last(cc.version) as version
                                   ,last(cc.date_raw_load_file) as date_raw_load_file
                                   ,last(cc.filepath) as filepath
                                   ,last(cc.filename) as filename
                                   ,last(cc.curated_ingested_date) as curated_ingested_date
                                   ,last(cc.current_record) as current_record
                                   ,last(cc.record_start_date) as record_start_date
                                   ,last(cc.record_end_date) as record_end_date
                                   ,last(cc.record_creation_date) as record_creation_date
                                   ,last(cc.record_modification_date) as record_modification_date
                                   ,sha2(getconcatenedstring(array(cc.compensation_change_reason, cc.compensation_change_subreason)), 256) as compensation_change_code
                                   ,sha2(getconcatenedstring(array(cc.compensation_change_reason, cc.compensation_change_subreason)), 256)  as hashkey
                                   ,'""" + runid + """' as runid
                         
                        from vw_d_compensation_change cc
                        
                        where 1 = 1
                          and (cc.compensation_change_reason is not null or cc.compensation_change_subreason is not null)
                          
                        group by
                                cc.compensation_change_reason
                               ,cc.compensation_change_subreason
                        """ 

// COMMAND ----------

val compensation_change_inserted = spark.sql(query_record)
compensation_change_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_compensation_change """
val res = stmt.execute(query_delete)

// COMMAND ----------

compensation_change_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_compensation_change", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_compensation_change"""
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_compensation_change_read.count().toInt //count the number of read records
val inserted_records =compensation_change_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_compensation_change_read.unpersist
compensation_change_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)