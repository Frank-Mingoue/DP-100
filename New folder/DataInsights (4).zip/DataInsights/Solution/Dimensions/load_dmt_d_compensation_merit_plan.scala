// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bycompensation_merit_plan = Window.partitionBy("compensation_merit_plan").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_compensation_merit_plan_read = spark.table("hr.contract").withColumn("rank",rank() over bycompensation_merit_plan)
                           .filter(col("rank")==="1")
                           .select(   "compensation_merit_plan"
                                     ,"compensation_merit_plan_label"
                                     ,"version"
                                     ,"date_raw_load_file"
                                     ,"filepath"
                                     ,"filename"
                                     ,"current_record"
                                     ,"record_start_date"
                                     ,"record_end_date"
                                     ,"record_creation_date"
                                     ,"record_modification_date"
                                     ,"curated_ingested_date")
                          .distinct

df_compensation_merit_plan_read.createOrReplaceTempView("vw_d_compensation_merit_plan")
df_compensation_merit_plan_read.cache()  //put the dataframe ont he cache


// COMMAND ----------

val query_record = """select 
                                    cm.compensation_merit_plan
                                   ,last(cm.compensation_merit_plan_label) as compensation_merit_plan_label
                                   ,last(cm.version) as version
                                   ,last(cm.date_raw_load_file) as date_raw_load_file
                                   ,last(cm.filepath) as filepath
                                   ,last(cm.filename) as filename
                                   ,last(cm.curated_ingested_date) as curated_ingested_date
                                   ,last(cm.current_record) as current_record
                                   ,last(cm.record_start_date) as record_start_date
                                   ,last(cm.record_end_date) as record_end_date
                                   ,last(cm.record_creation_date) as record_creation_date
                                   ,last(cm.record_modification_date) as record_modification_date
                                   ,sha2(cm.compensation_merit_plan, 256) as compensation_merit_plan_code
                                   ,sha2(last(cm.compensation_merit_plan_label),256)  as hashkey
                                   ,'""" + runid + """' as runid
                         
                        from vw_d_compensation_merit_plan cm
                        
                        where 1 = 1
                          and (cm.compensation_merit_plan is not null)
                          
                        group by   
                               cm.compensation_merit_plan
                        """ 

// COMMAND ----------

val compensation_merit_plan_inserted = spark.sql(query_record)
compensation_merit_plan_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_compensation_merit_plan """
val res = stmt.execute(query_delete)

// COMMAND ----------

compensation_merit_plan_inserted.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_compensation_merit_plan", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_compensation_merit_plan"""
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_compensation_merit_plan_read.count().toInt //count the number of read records
val inserted_records =compensation_merit_plan_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_compensation_merit_plan_read.unpersist
compensation_merit_plan_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)