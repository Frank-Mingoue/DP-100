// Databricks notebook source
// DBTITLE 1,Get Parameter RunId
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Import Functions and Librairies
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set SQL Connections
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Refresh table job_requisition
 if(spark.catalog.tableExists("hr.job_requisition")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.job_requisition")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Job requisition and recruiter information
val byrecruiter = Window.partitionBy("job_requisition_reference").orderBy($"effective_date".asc, $"filename".asc, $"date_raw_load_file".asc, $"version".asc)
val byposting_start_date = Window.partitionBy("job_requisition_reference","recruiting_start_date","position_reference").orderBy($"new_job_posting_start_date".asc, $"filename".asc, $"date_raw_load_file".asc, $"version".asc)
val byjob_requisition = Window.partitionBy("job_requisition_reference","recruiting_start_date","position_reference").orderBy($"effective_date".desc, $"job_posting_start_date".desc, $"target_hire_date".desc, $"target_end_date".desc, $"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_job_requisition_read = spark.table("hr.job_requisition").withColumn("rank",rank() over byjob_requisition)
                                                               .withColumn("first_primary_recruiter",first($"primary_recruiter") over byrecruiter)
                                                               .withColumn("new_job_posting_start_date",when($"job_posting_start_date".isNull,"2999-12-31").otherwise($"job_posting_start_date"))
                                                               .withColumn("first_job_posting_start_date",first($"new_job_posting_start_date") over byposting_start_date)
                                                               .filter(col("rank")==="1")
                                                               .select( 
                                                                        "job_requisition_reference"
                                                                       ,"job_requisition_code"
                                                                       ,"recruiting_instruction_data"
                                                                       ,"recruiting_start_date"
                                                                       ,"job_requisition_status" 
                                                                       ,"position_reference" 
                                                                       ,"effective_date"
                                                                       ,"target_hire_date"
                                                                       ,"job_posting_start_date"
                                                                       ,"new_job_posting_start_date"
                                                                       ,"first_job_posting_start_date"
                                                                       ,"position_label"
                                                                       ,"target_end_date"
                                                                       ,"cost_center_reference"
                                                                       ,"primary_recruiter"
                                                                       ,"first_primary_recruiter"
                                                                       ,"hiring_manager"
                                                                       ,"primary_location_label"
                                                                       ,"job_contract_nature"
                                                                       ,"recruiting_start_date"
                                                                       ,"job_profile"
                                                                       ,"version"
                                                                       ,"date_raw_load_file"
                                                                       ,"filepath"
                                                                       ,"filename"
                                                                       ,"current_record"
                                                                       ,"record_start_date"
                                                                       ,"record_end_date"
                                                                       ,"record_creation_date"
                                                                       ,"record_modification_date"
                                                                       ,"curated_ingested_date")
                                                               .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                                                               .distinct

df_job_requisition_read.createOrReplaceTempView("vw_job_requisition")
df_job_requisition_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Get Frozen Status date
val byjob_requisition_frozen = Window.partitionBy("job_requisition_reference","recruiting_start_date","position_reference").orderBy($"effective_date".desc, $"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_job_requisition_frozen_read = spark.table("hr.job_requisition").filter(lower($"job_requisition_status") ==="frozen")
                                                                      .withColumn("rank",rank() over byjob_requisition_frozen)
                                                                      .filter(col("rank")==="1")
                                                                      .select( 
                                                                              "job_requisition_reference"
                                                                              ,"job_requisition_code"
                                                                             ,"job_requisition_status" 
                                                                             ,"effective_date")
                                                                      .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                                                                      .distinct

df_job_requisition_frozen_read.createOrReplaceTempView("vw_job_requisition_frozen")
df_job_requisition_frozen_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Get Open Status date
val byjob_requisition_opening = Window.partitionBy("job_requisition_reference","recruiting_start_date","position_reference").orderBy($"effective_date".desc, $"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_job_requisition_opening_read = spark.table("hr.job_requisition").filter(lower($"job_requisition_status") ==="open")
                                                                       .withColumn("rank",rank() over byjob_requisition_opening)
                                                                       .filter(col("rank")==="1")
                                                                       .select( 
                                                                              "job_requisition_reference"
                                                                             ,"job_requisition_code"
                                                                             ,"job_requisition_status" 
                                                                             ,"effective_date")
                                                                      .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                                                                      .distinct

df_job_requisition_opening_read.createOrReplaceTempView("vw_job_requisition_opening")
df_job_requisition_opening_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Get Unfreezed Status date
val byjob_requisition_unfreezed = Window.partitionBy("job_requisition_reference","recruiting_start_date","position_reference").orderBy($"effective_date".desc,$"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_job_requisition_unfreezed_read = spark.table("hr.job_requisition")
                                                                      .filter(lower($"job_requisition_status") ==="unfreezed")
                                                                      .withColumn("rank",rank() over byjob_requisition_unfreezed)
                                                                      .filter(col("rank")==="1")
                                                                      .select( 
                                                                              "job_requisition_reference"
                                                                             ,"job_requisition_code"
                                                                             ,"job_requisition_status" 
                                                                             ,"effective_date")
                                                                      .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                                                                      .distinct

df_job_requisition_unfreezed_read.createOrReplaceTempView("vw_job_requisition_unfreezed")
df_job_requisition_unfreezed_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Get Closed Status date
val byjob_requisition_closed = Window.partitionBy("job_requisition_reference","recruiting_start_date","position_reference").orderBy($"effective_date".desc,$"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_job_requisition_closed_read = spark.table("hr.job_requisition")
                                                                      .filter(lower($"job_requisition_status") ==="closed")
                                                                      .withColumn("rank",rank() over byjob_requisition_closed)
                                                                      .filter(col("rank")==="1")
                                                                      .select( 
                                                                              "job_requisition_reference"
                                                                             ,"job_requisition_code"
                                                                             ,"job_requisition_status" 
                                                                             ,"effective_date")
                                                                      .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                                                                      .distinct

df_job_requisition_closed_read.createOrReplaceTempView("vw_job_requisition_closed")
df_job_requisition_closed_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Get Transco and hierarchy for job requisition status
spark.read.jdbc(jdbcurl, "dbo.vw_ref_job_requisition_status", connectionproperties).createOrReplaceTempView("vw_ref_job_requisition_status")

// COMMAND ----------

// DBTITLE 1,Job Requisition Query
val query_record = """select  distinct
                              jr.job_requisition_reference
                             ,jr.recruiting_instruction_data
                             ,jr.job_requisition_status
                             ,r.job_requisition_status_detailed
                             ,r.job_requisition_status_detailed_order
                             ,r.job_requisition_status_consolidated
                             ,r.job_requisition_status_consolidated_order
                             ,jr.position_reference
                             ,jr.target_hire_date
                             ,jr.first_job_posting_start_date as job_posting_start_date
                             ,jr.position_label
                             ,jr.target_end_date
                             ,jrf.effective_date as job_freeze_date
                             ,jro.effective_date as job_opening_date
                             ,jru.effective_date as job_unfreeze_date                             
                             ,jrc.effective_date as job_closed_date
                             ,jr.cost_center_reference as job_cost_center_code
                             ,jr.first_primary_recruiter as primary_recruiter
                             ,jr.hiring_manager
                             ,jr.primary_location_label
                             ,jr.job_contract_nature
                             ,jr.recruiting_start_date
                             ,jr.job_profile as job_profile_code
                             ,jr.job_requisition_code
                             ,jr.version 
                             ,jr.date_raw_load_file
                             ,jr.filepath
                             ,jr.filename 
                             ,jr.curated_ingested_date 
                             ,jr.current_record
                             ,jr.record_start_date
                             ,jr.record_end_date
                             ,jr.record_creation_date 
                             ,jr.record_modification_date
                             ,sha2(getconcatenedstring(array( jr.recruiting_instruction_data
                                                             ,jr.job_requisition_status
                                                             ,r.job_requisition_status_detailed
                                                             ,r.job_requisition_status_consolidated
                                                             ,jr.position_reference
                                                             ,jr.target_hire_date
                                                             ,jr.first_job_posting_start_date
                                                             ,jr.position_label
                                                             ,jr.target_end_date
                                                             ,jrf.effective_date
                                                             ,jro.effective_date
                                                             ,jru.effective_date
                                                             ,jr.cost_center_reference
                                                             ,jr.first_primary_recruiter
                                                             ,jr.hiring_manager
                                                             ,jr.primary_location_label
                                                             ,jr.job_contract_nature
                                                             ,jr.recruiting_start_date
                                                             ,jr.job_profile)),256)  as hashkey
                             ,'""" + runid + """' as runid
                         
                        from vw_job_requisition jr
                             left join vw_ref_job_requisition_status r on trim(lower(r.source_value)) =  trim(lower(jr.job_requisition_status))
                             left join vw_job_requisition_unfreezed jru on jr.job_requisition_code = jru.job_requisition_code
                             left join vw_job_requisition_opening jro on jr.job_requisition_code = jro.job_requisition_code
                             left join vw_job_requisition_frozen jrf on jr.job_requisition_code = jrf.job_requisition_code
                             left join vw_job_requisition_closed jrc on jr.job_requisition_code = jrc.job_requisition_code
                        
                        where 1=1
                          and jr.job_requisition_reference is not null
                      """ 

// COMMAND ----------

// DBTITLE 1,Get Query Results
val job_requisition_inserted = spark.sql(query_record)
job_requisition_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Truncate staging table 
val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_job_requisition """
val res = stmt.execute(query_delete)

// COMMAND ----------

// DBTITLE 1,Write on staging table
job_requisition_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_job_requisition", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Run the merge stored procedure in order to insert data into final dmt table
val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_job_requisition """
stmt.execute(sql)

connection.close()

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_job_requisition_read.count().toInt //count the number of read records
val inserted_records = job_requisition_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_job_requisition_read.unpersist
job_requisition_inserted.unpersist

// COMMAND ----------

// DBTITLE 1,Return Values
dbutils.notebook.exit(return_value)