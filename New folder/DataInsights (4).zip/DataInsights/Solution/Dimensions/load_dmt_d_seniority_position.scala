// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_init_param_range_table 'param_seniority_position' """
stmt.execute(sql)

connection.close()

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.param_seniority_position", connectionproperties).createOrReplaceTempView("vw_param_seniority_position")

// COMMAND ----------

val query_record = """select        distinct                            
                                    range_seniority_position_age
                                   ,range_seniority_position_order
                                   ,range_seniority_position
                                   ,range_seniority_position_min
                                   ,range_seniority_position_max
                                   ,recordcreationdate
                                   ,recordmodificationdate                                 
                                   ,sha2(cast(range_seniority_position_age as string),256) as seniority_position_code
                                   ,sha2(getconcatenedstring(array(s.range_seniority_position)),256) as hashkey
                                   ,'""" + runid + """' as runid
                           
                         
                        from vw_param_seniority_position s
                        where 1=1 
                          and s.range_seniority_position_age is not null and s.range_seniority_position is not null
                             
                           """ 

// COMMAND ----------

val seniority_position_inserted = spark.sql(query_record)
seniority_position_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_seniority_position """
val res = stmt.execute(query_delete)

// COMMAND ----------

seniority_position_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_seniority_position", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_seniority_position """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val inserted_records = seniority_position_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + inserted_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
seniority_position_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)