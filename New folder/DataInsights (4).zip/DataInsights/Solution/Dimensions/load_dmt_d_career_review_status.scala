// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

if(spark.catalog.tableExists("hr.career")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.career")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bycareer_review_status = Window.partitionBy("review_status").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"filename".desc )
val df_review_status_read = spark.table("hr.career").withColumn("rank",rank() over bycareer_review_status)
                                                     .filter(col("rank")==="1")
                                                     .select("review_status"
                                                           ,"review_status_code"
                                                           ,"version"
                                                           ,"date_raw_load_file"
                                                           ,"filepath"
                                                           ,"filename"
                                                           ,"current_record"
                                                           ,"record_start_date"
                                                           ,"record_end_date"
                                                           ,"record_creation_date"
                                                           ,"record_modification_date"
                                                           ,"curated_ingested_date")
                                                    .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")                                                      
                                                    .distinct
df_review_status_read.createOrReplaceTempView("vw_review_status")

// COMMAND ----------

val bymy_career_review_status = Window.partitionBy("my_review_status").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"filename".desc)
val df_my_review_status_read = spark.table("hr.career").withColumn("rank",rank() over bymy_career_review_status)
                                                     .filter(col("rank")==="1")
                                                     .select("my_review_status"
                                                           ,"my_review_status_code"
                                                           ,"version"
                                                           ,"date_raw_load_file"
                                                           ,"filepath"
                                                           ,"filename"
                                                           ,"current_record"
                                                           ,"record_start_date"
                                                           ,"record_end_date"
                                                           ,"record_creation_date"
                                                           ,"record_modification_date"
                                                           ,"curated_ingested_date")
                                                    .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")                                                      
                                                    .distinct
df_my_review_status_read.createOrReplaceTempView("vw_my_review_status")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_review_status", connectionproperties).createOrReplaceTempView("vw_ref_review_status")

// COMMAND ----------

val query_record = """ select  distinct                               
                               coalesce(r.review_status, mr.my_review_status) as review_status
                              ,coalesce(s.review_status_level_order,99) as review_status_order
                              ,coalesce(r.review_status_code, mr.my_review_status_code) as review_status_code
                              ,coalesce(r.version, mr.version) as version
                              ,coalesce(r.date_raw_load_file, mr.date_raw_load_file) as date_raw_load_file
                              ,coalesce(r.filepath, mr.filepath) as filepath
                              ,coalesce(r.filename, mr.filename) as filename
                              ,coalesce(r.curated_ingested_date, mr.curated_ingested_date) as curated_ingested_date  
                              ,coalesce(r.record_start_date, mr.record_start_date) as record_start_date
                              ,coalesce(r.record_end_date, mr.record_end_date) as record_end_date
                              ,coalesce(r.record_creation_date, mr.record_creation_date) as record_creation_date 
                              ,coalesce(r.record_modification_date, mr.record_modification_date) as record_modification_date
                              ,sha2(coalesce(r.review_status, mr.my_review_status),256)  as hashkey
                              ,'""" + runid + """' as runid
                         
                        from  vw_review_status r 
                              full outer join vw_my_review_status mr on trim(lower(r.review_status)) = trim(lower(mr.my_review_status)) 
                              left join vw_ref_review_status s on trim(lower(r.review_status)) = trim(lower(s.source_value)) or trim(lower(mr.my_review_status)) = trim(lower(s.source_value))
                        where 1=1
                          and (r.review_status is not null or mr.my_review_status is not null) 
                          
                        union
                  
                      select  distinct                               
                              'Not Started' as review_status
                              ,1 as review_status_order
                              ,sha2('Not Started',256)  as review_status_code
                              ,1 as version
                              ,'1900-01-01' as date_raw_load_file
                              ,'default status value for non démarré' as filepath
                              ,'Sdefault status value for non démarrée' as filename
                              ,'1900-01-01' as curated_ingested_date    
                              ,'1900-01-01' as record_start_date
                              ,null as record_end_date
                              ,current_timestamp() as record_creation_date 
                              ,current_timestamp() as record_modification_date
                              ,sha2('Non démarré',256)  as hashkey
                              ,'""" + runid + """' as runid
                         
                        from  vw_review_status r 
                        where 1=1
                         and  not exists (select * from vw_review_status where lower(review_status) = 'not started') 
                         
                         union
                  
                      select  distinct                               
                              'Non applicable' as review_status
                              ,6 as review_status_order
                              ,sha2('Non applicable',256)  as review_status_code
                              ,1 as version
                              ,'1900-01-01' as date_raw_load_file
                              ,'default status value for non applicable' as filepath
                              ,'Sdefault status value for non applicable' as filename
                              ,'1900-01-01' as curated_ingested_date    
                              ,'1900-01-01' as record_start_date
                              ,null as record_end_date
                              ,current_timestamp() as record_creation_date 
                              ,current_timestamp() as record_modification_date
                              ,sha2('Non démarré',256)  as hashkey
                              ,'""" + runid + """' as runid
                         
                        from  vw_review_status r   
                        where 1=1
                  
                      """ 


// COMMAND ----------

val review_status_inserted = spark.sql(query_record)
review_status_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_career_review_status """
val res = stmt.execute(query_delete)

// COMMAND ----------

review_status_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_career_review_status", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_career_review_status"""
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_review_status_read.count().toInt //count the number of read records
val inserted_records = review_status_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_review_status_read.unpersist
df_my_review_status_read.unpersist
review_status_inserted.unpersist

// COMMAND ----------

spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)