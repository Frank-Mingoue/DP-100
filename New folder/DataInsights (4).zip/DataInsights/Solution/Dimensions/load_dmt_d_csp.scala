// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------


val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

 if(spark.catalog.tableExists("common.job")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE common.job")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------


val bycsp = Window.partitionBy("professional_category_reference").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_csp_read = spark.table("common.job").withColumn("rank",rank() over bycsp)
           .filter(col("rank")==="1")
           .select( "professional_category_reference" 
                   ,"professional_category_name"   
                   ,"version"
                   ,"date_raw_load_file"
                   ,"filepath"
                   ,"filename"
                   ,"current_record"
                   ,"record_start_date"
                   ,"record_end_date"
                   ,"record_creation_date"
                   ,"record_modification_date"
                   ,"curated_ingested_date")
           .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
           .distinct

df_csp_read.createOrReplaceTempView("vw_csp")
df_csp_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_csp", connectionproperties).createOrReplaceTempView("vw_ref_csp")

// COMMAND ----------

val query_record = """select 
                              coalesce(last(r.cadre_non_cadre),'""" + default_hierarchy_value + """') as cadre_non_cadre
                             ,coalesce(last(r.cadre_non_cadre_order),99) as cadre_non_cadre_order
                             ,coalesce(last(r.csp),'""" + default_hierarchy_value + """') as csp
                             ,coalesce(last(r.csp_order),99) as csp_order
                             ,csp.professional_category_reference 
                             ,last(csp.professional_category_name) as professional_category_name
                             ,coalesce(last(r.csp_detailed_order),99) as csp_detailed_order
                             ,last(csp.version) as version
                             ,last(csp.date_raw_load_file) as date_raw_load_file
                             ,last(csp.filepath) as filepath
                             ,last(csp.filename) as filename
                             ,last(csp.curated_ingested_date) as curated_ingested_date
                             ,last(csp.current_record) as current_record
                             ,last(csp.record_start_date) as record_start_date
                             ,last(csp.record_end_date) as record_end_date
                             ,last(csp.record_creation_date) as record_creation_date
                             ,last(csp.record_modification_date) as record_modification_date
                             ,sha2(csp.professional_category_reference,256) as csp_code
                             ,sha2(getconcatenedstring(array(last(r.cadre_non_cadre),last(r.csp),last(csp.professional_category_name))),256)  as hashkey
                             ,'""" + runid + """' as runid
                         
                        from vw_csp csp
                             left join vw_ref_csp  r on (trim(lower(r.source_value)) =  trim(lower(csp.professional_category_name)) or lower(r.source_value) =  trim(lower(csp.professional_category_reference)))
                        where 1 = 1
                          and csp.professional_category_reference is not null                           
                        group by 
                              csp.professional_category_reference 
                           
                           
                         union
                         
                         select 
                              r.cadre_non_cadre as cadre_non_cadre
                             ,r.cadre_non_cadre_order as cadre_non_cadre_order
                             ,r.csp as csp
                             ,r.csp_order as csp_order
                             ,'Autre statut' as professional_category_reference
                             ,'Autre statut' as professional_category_name
                             ,r.csp_detailed_order as csp_detailed_order
                             ,1 as version
                             ,current_date() as date_raw_load_file
                             ,'default value for vacataire' as filepath
                             ,'default value for vacataire' as filename
                             ,current_date() as curated_ingested_date
                             ,true as current_record
                             ,current_date() as record_start_date
                             ,null as record_end_date
                             ,current_timestamp() as record_creation_date
                             ,current_timestamp()  as record_modification_date
                             ,sha2('Autre statut',256) as csp_code
                             ,sha2(getconcatenedstring(array(r.cadre_non_cadre,r.csp,'Autre statut')),256)  as hashkey
                             ,'""" + runid + """' as runid
                         
                        from  vw_ref_csp r 
                        where 1 = 1
                          and lower(r.csp) = 'autre statut'  
                      """ 


// COMMAND ----------

val csp_inserted = spark.sql(query_record)
csp_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_csp """
val res = stmt.execute(query_delete)

// COMMAND ----------

csp_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_csp", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_csp """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_csp_read.count().toInt //count the number of read records
val inserted_records = csp_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_csp_read.unpersist
csp_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)