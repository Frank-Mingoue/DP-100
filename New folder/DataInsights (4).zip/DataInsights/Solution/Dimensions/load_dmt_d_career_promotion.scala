// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

spark.read.jdbc(jdbcurl, "staff.d_csp", connectionproperties).filter("current_version = 1")
                                                                         .createOrReplaceTempView("vw_d_csp")

// COMMAND ----------

val query_record = """select  distinct                               
                              concat(c1.csp ,' vers ',c2.csp) as change_in_csp
                             ,c1.csp as csp_old
                             ,c2.csp as csp_new
                             ,sha2(getconcatenedstring(array(c1.csp
                                                             ,c2.csp)),256) as promotion_code
                             ,sha2(getconcatenedstring(array(c1.csp
                                                             ,c2.csp)),256)  as hashkey
                             
                             ,'""" + runid + """' as runid
                         
                        from vw_d_csp c1
                        inner join vw_d_csp c2
                        on c1.csp != c2.csp
                        where c1.csp not in ("Autre statut", "NC") and c2.csp not in ("Autre statut", "NC")
                      """ 


// COMMAND ----------

val promotion_inserted = spark.sql(query_record)
promotion_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_career_promotion """
val res = stmt.execute(query_delete)

// COMMAND ----------

promotion_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_career_promotion", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_career_promotion"""
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = promotion_inserted.count().toInt //count the number of read records
val inserted_records = promotion_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

promotion_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)