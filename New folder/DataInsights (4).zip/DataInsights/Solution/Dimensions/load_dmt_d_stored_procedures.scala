// Databricks notebook source
// init widgets
val runid = dbutils.widgets.get("runid");
val load = dbutils.widgets.get("load");
val flux = dbutils.widgets.get("flux")

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

  val connection = getSQLconnection()
  val stmt = connection.createStatement()

// COMMAND ----------

if (load == "pre_load"){
  
  if(flux == "historique") //loading historical data
  {
    val query_init_dimensions = """exec dbo.usp_init_dimensions """
    val res_init_dimensions = stmt.execute(query_init_dimensions)
  }
  
  println("Power Apps to DI: stored procedures to run before loading dimensions")


  val query_param_referentiel = """exec dbo.usp_load_param_referentiel """
  val res_param_referentiel = stmt.execute(query_param_referentiel)
  
  val query_load_mail_control = """exec dbo.usp_load_mail_control """
  val res_load_mail_control = stmt.execute(query_load_mail_control)
  
  val query_load_monthly_calendar = """exec dbo.usp_load_param_monthly_calendar """
  val res_load_monthly_calendar = stmt.execute(query_load_monthly_calendar)

  val query_load_user_security = """exec dbo.usp_load_user_security """
  val res_load_user_security = stmt.execute(query_load_user_security)

}

else if (load =="post_load"){
  println("DI to Power Apps: stored procedures to run after loading dimensions")

  val query_merge_apps_d_legal_organization = """exec dbo.usp_merge_apps_d_legal_organization """
  val res_merge_apps_d_legal_organization = stmt.execute(query_merge_apps_d_legal_organization)
  

  val query_merge_apps_d_operational_organization = """exec dbo.usp_merge_apps_d_operational_organization """
  val res_merge_apps_d_operational_organization = stmt.execute(query_merge_apps_d_operational_organization)
  
  
  val query_merge_apps_hra_employee = """exec dbo.usp_merge_apps_hra_employee """
  val res_merge_apps_hra_employee = stmt.execute(query_merge_apps_hra_employee)
  

  val query_usp_insert_new_costcenter_user_list = """exec dbo.usp_insert_new_costcenter_user_list """
  val res_usp_insert_new_costcenter_user_list = stmt.execute(query_usp_insert_new_costcenter_user_list)
  
  
//  val query_delete_securityUserOut = """exec dbo.usp_delete_securityUserOut """
//  val res_delete_securityUserOut = stmt.execute(query_delete_securityUserOut)
  
  val query_mailDomain = """exec dbo.usp_load_mail_domain """
  val res_mailDomain = stmt.execute(query_mailDomain)
}
else{
  println("nothing")
}

// COMMAND ----------

val read_records = 0 //count the number of read records
val inserted_records = 0 //count the number of read records
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)