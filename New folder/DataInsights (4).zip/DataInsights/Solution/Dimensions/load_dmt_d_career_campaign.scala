// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

if(spark.catalog.tableExists("hr.career")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.career")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bycareer_campaign = Window.partitionBy("review_type","review_period_start_date", "review_period_end_date").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc, $"record_creation_date".desc, $"version".desc, $"current_record".desc,$"filename".desc)
val df_campaign_read = spark.table("hr.career").withColumn("review_type",when(lower($"review_reference").contains("year end"),"Year End")
                                                                         .when(lower($"review_reference").contains("mid-year"),"Mid-Year"))
                                               .withColumn("rank",rank() over bycareer_campaign)
                                               .filter(col("rank")==="1")
                                               .select( "review_type"
                                                       ,"review_period_start_date"
                                                       ,"review_period_end_date"
                                                       ,"version"
                                                       ,"date_raw_load_file"
                                                       ,"filepath"
                                                       ,"filename"
                                                       ,"current_record"
                                                       ,"record_start_date"
                                                       ,"record_end_date"
                                                       ,"record_creation_date"
                                                       ,"record_modification_date"
                                                       ,"curated_ingested_date")
                                                .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")                                                      
                                                .distinct
df_campaign_read.createOrReplaceTempView("vw_campaign")

// COMMAND ----------

val query_record = """ select  distinct           
                               g.review_type
                              ,g.review_period_start_date
                              ,g.review_period_end_date
                              ,sha2(getconcatenedstring(array(g.review_period_start_date
                                                             ,g.review_period_end_date)),256) as career_campaign_code
                              ,g.version
                              ,g.date_raw_load_file
                              ,g.filepath
                              ,g.filename
                              ,g.curated_ingested_date    
                              ,g.record_start_date
                              ,g.record_end_date
                              ,g.record_creation_date 
                              ,g.record_modification_date                               
                              ,sha2(getconcatenedstring(array(g.review_period_start_date
                                                             ,g.review_period_end_date
                                                             )),256)  as hashkey
                              ,'""" + runid + """' as runid
                         
                       from   vw_campaign g 
                       where  1=1
                        and   g.review_period_start_date is not null
                      """ 

// COMMAND ----------

val campaign_inserted = spark.sql(query_record)
campaign_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_career_campaign """
val res = stmt.execute(query_delete)

// COMMAND ----------

campaign_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_career_campaign", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_career_campaign"""
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_campaign_read.count().toInt //count the number of read records
val inserted_records = campaign_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_campaign_read.unpersist
campaign_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)