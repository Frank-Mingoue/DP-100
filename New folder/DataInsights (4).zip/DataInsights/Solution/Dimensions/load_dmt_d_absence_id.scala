// Databricks notebook source
// DBTITLE 1,Get Parameters for DB Connection and the RunId
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include the functions to connect to databases and ADLS
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Connections to the Database
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Prepare the table hr absenteism for reading
 if(spark.catalog.tableExists("hr.absenteism_consolidated")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism_consolidated")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Select columns to insert
val query_record = """select distinct
                             id_absence
                             ,current_timestamp() as record_creation_date
                        
                       from hr.absenteism_consolidated
                        """ 

// COMMAND ----------

// DBTITLE 1,Store the query results in the dataframe and put the dataframe in the cache
val id_absence_inserted = spark.sql(query_record)
id_absence_inserted.cache()  //put the dataframe on the cache


// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_id_absence """
val res = stmt.execute(query_delete)

// COMMAND ----------

id_absence_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_id_absence", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_id_absence """
stmt.execute(sql)

connection.close()

// COMMAND ----------

//set up the return value with the number of lines read, rejected and inserted
val read_records = spark.table("hr.absenteism_consolidated").count().toInt //count the number of read records
val inserted_records = id_absence_inserted.count().toInt //count the number of read records
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

dbutils.notebook.exit(return_value)