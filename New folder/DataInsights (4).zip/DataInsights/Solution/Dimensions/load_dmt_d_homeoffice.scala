// Databricks notebook source
// DBTITLE 1,Get Parameters for DB Connection and the RunId
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include the functions to connect to databases and ADLS
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Connections to the Database
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value = "Non Affecté"

// COMMAND ----------

// DBTITLE 1,Prepare the table location for reading
 if(spark.catalog.tableExists("hr.absenteism")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Read the last value for site by using curated
val byhomeoffice = Window.partitionBy("code").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_homeoffice_read = spark.table("hr.absenteism").withColumn("rank",rank() over byhomeoffice)
            .filter(col("rank")==="1" and (col("code")==="TELE" or col("code")==="TELI" or col("code")==="TELP" or col("code")==="TELC"))
            .select( "code" 
                    ,"label"             
                    ,"version"
                    ,"date_raw_load_file"
                    ,"filepath"
                    ,"filename"
                    ,"current_record"
                    ,"record_start_date"
                    ,"record_end_date"
                    ,"record_creation_date"
                    ,"record_modification_date"
                    ,"curated_ingested_date")
             .distinct
df_homeoffice_read.createOrReplaceTempView("vw_homeoffice")
df_homeoffice_read.cache()  //put the dataframe on the cache


// COMMAND ----------

// DBTITLE 1,Get the table param nationality
spark.read.jdbc(jdbcurl, "dbo.vw_ref_homeoffice", connectionproperties).createOrReplaceTempView("vw_param_homeoffice")

// COMMAND ----------

// DBTITLE 1,Select columns to insert
val query_record = """select 
                                ho.code
                               ,last(ho.label) as libelle
                               ,coalesce(last(pm.homeoffice_detail_order),99) as libelle_order
                               ,coalesce(last(pm.homeoffice_group), '""" + default_hierarchy_value + """') as homeoffice_group
                               ,coalesce(last(pm.homeoffice_group_order),99) as homeoffice_group_order
                               ,last(ho.version) as version
                               ,last(ho.date_raw_load_file) as date_raw_load_file
                               ,last(ho.filepath) as filepath
                               ,last(ho.filename) as filename
                               ,last(ho.curated_ingested_date) as curated_ingested_date
                               ,last(ho.current_record) as current_record
                               ,last(ho.record_start_date) as record_start_date
                               ,last(ho.record_end_date) as record_end_date
                               ,last(ho.record_creation_date) as record_creation_date
                               ,last(ho.record_modification_date) as record_modification_date
                               ,sha2(ho.code,256) as homeoffice_code
                               ,sha2(getconcatenedstring(array( last(ho.label)
                                                               ,last(pm.homeoffice_group))),256) as hashkey
                              
                               ,'""" + runid + """' as runid 
                                                                      
                        from vw_homeoffice ho 
                             left join vw_param_homeoffice pm on lower(ho.label) = lower(pm.source_value)
                        where 1=1
                          and ho.code is not null
                        group by 
                                ho.code
                                   
                                    """

// COMMAND ----------

// DBTITLE 1,Store the query results in the dataframe and put the dataframe in the cache
val homeoffice_inserted = spark.sql(query_record)
homeoffice_inserted.cache()  //put the dataframe on the cache


// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_homeoffice """
val res = stmt.execute(query_delete)

// COMMAND ----------

homeoffice_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_homeoffice", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_homeoffice """
stmt.execute(sql)

connection.close()

// COMMAND ----------

//set up the return value with the number of lines read, rejected and inserted
val read_records = df_homeoffice_read.count().toInt //count the number of read records
val inserted_records = homeoffice_inserted.count().toInt //count the number of read records
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_homeoffice_read.unpersist
homeoffice_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)