// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val df_contract_type_read = spark.table("hr.contract")
val bycontract_type = Window.partitionBy("employee_code","contract_type","worker_type"
).orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)


val df_contract_type =  df_contract_type_read.withColumn("rank",rank() over bycontract_type)
                     .filter(col("rank")==="1")
                     .withColumn("contract_type_key",$"contract_type")
                     .select( "employee_code"
                             ,"contract_start_date"
                             ,"contract_end_date"
                             ,"contract_type" 
                             ,"contract_type_key"
                             ,"contract_type_label"
                             ,"first_contract_type"
                             ,"first_contract_type_label"
                             ,"worker_type"
                             /*
                             ,"collective_agreement_reference"
                             ,"collective_agreement_reference_label"
                             ,"collective_agreement_group"
                             ,"collective_agreement_level"
                             ,"coefficient"
                             ,"coefficient_label"
                             */
                             ,"version"
                             ,"date_raw_load_file"
                             ,"filepath"
                             ,"filename"
                             ,"current_record"
                             ,"record_start_date"
                             ,"record_end_date"
                             ,"record_creation_date"
                             ,"record_modification_date"
                             ,"curated_ingested_date")
                  .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                  .distinct

df_contract_type.createOrReplaceTempView("vw_contract_type")
//put the dataframe on the cache

//contract job change 
val bycontract_date = Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"effective_job_change_date")
val bycontract_version = Window.partitionBy("employee_code","employee_id","france_payroll_id","effective_job_change_date").orderBy($"record_start_date".desc)
val df_contracthr_change = spark.table("hr.contract")
.select(
  "employee_code","employee_id","france_payroll_id"
  ,"contract_start_date"
  ,"contract_type"
  ,"worker_type"
  ,"collective_agreement_reference"
  ,"collective_agreement_reference_label"
  ,"collective_agreement_group"
  ,"collective_agreement_level"
  ,"coefficient"
  ,"coefficient_label"
  ,"effective_job_change_date"
  ,"record_start_date"
).filter($"contract_start_date".isNotNull)
.withColumn("rank",rank() over bycontract_version).filter($"rank" === 1).drop("rank","record_start_date")
.orderBy("employee_code","effective_job_change_date").withColumn("record_end_date",date_sub(lead($"effective_job_change_date",1) over bycontract_date,1))
.withColumn("record_start_date",$"effective_job_change_date")
.withColumn("record_end_date",coalesce($"record_end_date",to_date(lit("2999-12-31"))))
.orderBy(asc("employee_code"),asc("record_start_date"))

df_contracthr_change.createOrReplaceTempView("vw_contract_job")

// Build the employee view for each org change
val joinCondition_job = $"ct.employee_code" === $"job.employee_code" and (
                            ($"ct.contract_start_date" <= $"job.record_start_date" and ($"job.record_start_date" <= $"ct.contract_end_date" or $"ct.contract_end_date".isNull))
                            or
                            ($"ct.contract_start_date" <= $"job.record_end_date" and ($"job.record_end_date" <= $"ct.contract_end_date" or $"ct.contract_end_date".isNull))
                            )


val df_contract = df_contract_type.as("ct").join(df_contracthr_change.as("job"),joinCondition_job)
                  .select(
                    "ct.contract_type" 
                    ,"ct.contract_type_key"
                    ,"ct.contract_type_label"
                    ,"ct.first_contract_type"
                    ,"ct.first_contract_type_label"
                    ,"ct.worker_type"
                    ,"job.collective_agreement_reference"
                    ,"job.collective_agreement_reference_label"
                    ,"job.collective_agreement_group"
                    ,"job.collective_agreement_level"
                    ,"job.coefficient"
                    ,"job.coefficient_label"
                    ,"ct.version"
                    ,"ct.date_raw_load_file"
                    ,"ct.filepath"
                    ,"ct.filename"
                    ,"ct.current_record"
                    ,"ct.record_start_date"
                    ,"ct.record_end_date"
                    ,"ct.record_creation_date"
                    ,"ct.record_modification_date"
                    ,"ct.curated_ingested_date"
                    //,"ct.employee_code"
                  ).distinct
                
val bycontract_type_all = Window.partitionBy("contract_type","worker_type","collective_agreement_reference","collective_agreement_group","collective_agreement_level","coefficient").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_contract_type_all = df_contract_type_read.withColumn("rank",rank() over bycontract_type_all)
                     .filter(col("rank")==="1")
                     .withColumn("contract_type_key",$"contract_type")
                     .select( "contract_type" 
                             ,"contract_type_key"
                             ,"contract_type_label"
                             ,"first_contract_type"
                             ,"first_contract_type_label"
                             ,"worker_type"
                             ,"collective_agreement_reference"
                             ,"collective_agreement_reference_label"
                             ,"collective_agreement_group"
                             ,"collective_agreement_level"
                             ,"coefficient"
                             ,"coefficient_label"
                             ,"version"
                             ,"date_raw_load_file"
                             ,"filepath"
                             ,"filename"
                             ,"current_record"
                             ,"record_start_date"
                             ,"record_end_date"
                             ,"record_creation_date"
                             ,"record_modification_date"
                             ,"curated_ingested_date")
                  .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                  .distinct

val df_contract_type_final = df_contract.union(df_contract_type_all).distinct
df_contract_type_final.createOrReplaceTempView("vw_contract_type_all")


// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_contract_type", connectionproperties).createOrReplaceTempView("vw_ref_contract_type")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_coefficient", connectionproperties).createOrReplaceTempView("vw_ref_coefficient")

// COMMAND ----------

 //,ct.libelle_nature_contrat
val query_record = """select 
                                    coalesce(last(pct.precarity),'""" + default_hierarchy_value + """') as  precarity     
                                   ,coalesce(last(precarity_order),99)  as precarity_order
                                   ,coalesce(last(pct.contract_type),'""" + default_hierarchy_value + """') as contract_type
                                   ,coalesce(last(contract_type_order),99) as contract_type_order
                                   ,coalesce(last(pct.contract_type_detailed) ,'""" + default_hierarchy_value + """') as contract_type_detailed
                                   ,coalesce(last(contract_type_detailed_order),99) as contract_type_detailed_order
                                   ,ct.contract_type as contract_nature
                                   ,last(ct.contract_type_label) as contract_nature_label
                                   ,coalesce(last(level_order),99) as contract_nature_order
                                   ,last(ct.first_contract_type) as first_contract_nature
                                   ,last(ct.first_contract_type_label) as first_contract_nature_label                      
                                   ,ct.worker_type
                                   ,ct.collective_agreement_reference
                                   ,last(ct.collective_agreement_reference_label) as collective_agreement_reference_label
                                   ,ct.collective_agreement_group
                                   ,ct.collective_agreement_level
                                   ,case when lower(ct.collective_agreement_reference) like '%couture%' then 
                                                   case when ct.collective_agreement_group is null and ct.collective_agreement_level is not null then ct.collective_agreement_level
                                                        when ct.collective_agreement_level is null and ct.collective_agreement_group is not null then ct.collective_agreement_group 
                                                         else concat(ct.collective_agreement_group,ct.collective_agreement_level) 
                                                   end 
                                         else ct.coefficient_label end as classification_collective_agreement
                                   ,ct.coefficient_label as coefficient
                                   ,last(ro.coefficient_order) as coefficient_order
                                   ,last(ro.version) as coefficient_version
                                   ,last(ct.version) as version
                                   ,last(ct.date_raw_load_file) as date_raw_load_file
                                   ,last(ct.filepath) as filepath
                                   ,last(ct.filename) as filename
                                   ,last(ct.curated_ingested_date) as curated_ingested_date
                                   ,last(ct.current_record) as current_record
                                   ,last(ct.record_start_date) as record_start_date
                                   ,last(ct.record_end_date) as record_end_date
                                   ,last(ct.record_creation_date) as record_creation_date
                                   ,last(ct.record_modification_date) as record_modification_date
                                   
                                   ,sha2(getconcatenedstring(array( ct.contract_type_key               
                                                                    ,ct.worker_type
                                                                    ,ct.collective_agreement_reference
                                                                    ,ct.collective_agreement_group
                                                                    ,ct.collective_agreement_level
                                                                    ,ct.coefficient_label
                                                                    )),256) as contract_code
                                                                    
                                   ,sha2(ct.contract_type_key,256) as contract_type_code
                                                                    
                                   ,sha2(getconcatenedstring(array(  ct.worker_type
                                                                    ,ct.collective_agreement_reference
                                                                    ,ct.collective_agreement_group
                                                                    ,ct.collective_agreement_level
                                                                    ,ct.coefficient_label
                                                                    )),256) as collective_agreement_code
                                   
                                   ,sha2(getconcatenedstring(array(  ct.contract_type_key               
                                                                    ,ct.worker_type
                                                                    ,ct.collective_agreement_reference
                                                                    ,ct.collective_agreement_group
                                                                    ,ct.collective_agreement_level
                                                                    ,ct.coefficient_label
                                                                    ,last(pct.precarity)
                                                                    ,last(pct.contract_type)
                                                                    ,last(pct.contract_type_detailed)
                                                                    ,last(ct.contract_type_label)
                                                                    ,last(ct.first_contract_type)
                                                                    ,last(ct.collective_agreement_reference_label))),256)  as hashkey
                                   ,'""" + runid + """' as runid 
                                                                      
                        from vw_contract_type_all ct

                        left join vw_ref_contract_type pct 
                        on trim(lower(pct.source_value)) = trim(lower(ct.contract_type_label)) 
                        or trim(lower(pct.source_value)) = trim(lower(ct.contract_type))
                        
                        left join vw_ref_coefficient ro on trim(lower(ro.coefficient)) = trim(lower(case when lower(ct.collective_agreement_reference) like '%couture%' then 
                                                   case when ct.collective_agreement_group is null and ct.collective_agreement_level is not null then ct.collective_agreement_level
                                                        when ct.collective_agreement_level is null and ct.collective_agreement_group is not null then ct.collective_agreement_group 
                                                         else concat(ct.collective_agreement_group,ct.collective_agreement_level) 
                                                   end 
                                         else ct.coefficient_label end))
                                                        and (trim(lower(ro.source_value)) = trim(lower(ct.collective_agreement_reference)) or trim(lower(ro.source_value)) = trim(lower(ct.collective_agreement_reference_label)))
                                                        
                        where 1=1
                          and ct.contract_type is not null
                          
                        group by 
                               ct.contract_type   
                              ,ct.contract_type_key          
                              ,ct.worker_type
                              ,ct.collective_agreement_reference
                              ,ct.collective_agreement_group
                              ,ct.collective_agreement_level
                              ,ct.coefficient_label

                             """

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from vw_ref_contract_type where lower(source_value) = lower('04-Apprenti BAC, BAC/BREVET PRO 2ème année')

// COMMAND ----------

val contract_type_inserted = spark.sql(query_record)
contract_type_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_contract_type """
val res = stmt.execute(query_delete)

// COMMAND ----------

contract_type_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_contract_type", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_contract_type """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_contract_type_read.count().toInt //count the number of read records
val inserted_records = contract_type_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0


// COMMAND ----------

df_contract_type_read.unpersist
contract_type_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)