// Databricks notebook source
// DBTITLE 1,Get Parameters for DB Connection and the RunId
val runid =dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include the functions to connect to databases and ADLS
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Connections to the Database
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value = "Non Affecté"

// COMMAND ----------

// DBTITLE 1,Prepare the table location for reading
 if(spark.catalog.tableExists("common.location")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE common.location")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Read the last value for site by using curated
val bylocation = Window.partitionBy("location").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_location_read = spark.table("common.location").withColumn("rank",rank() over bylocation)
            .filter(col("rank")==="1")
            .select( "location" 
                    ,"location_type"                           
                    ,"location_country"
                    ,"location_reference"
                    ,"version"
                    ,"date_raw_load_file"
                    ,"filepath"
                    ,"filename"
                    ,"current_record"
                    ,"record_start_date"
                    ,"record_end_date"
                    ,"record_creation_date"
                    ,"record_modification_date"
                    ,"curated_ingested_date")
             .distinct
df_location_read.createOrReplaceTempView("vw_location")
df_location_read.cache()  //put the dataframe on the cache


// COMMAND ----------

// DBTITLE 1,Get the table param nationality
spark.read.jdbc(jdbcurl, "dbo.param_nationality", connectionproperties).createOrReplaceTempView("vw_param_nationality")

// COMMAND ----------

// DBTITLE 1,Select columns to insert
val query_record = """select 
                               l.location
                              ,coalesce(l.location_type, '""" + default_hierarchy_value + """') as location_type
                              ,coalesce(coalesce(last(pn.country_name_fr), last(l.location_country)), '""" + default_hierarchy_value + """') as location_country
                              ,l.location_reference
                              ,last(l.version) as version
                              ,last(l.date_raw_load_file) as date_raw_load_file
                              ,last(l.filepath) as filepath
                              ,last(l.filename) as filename
                              ,last(l.curated_ingested_date) as curated_ingested_date
                              ,true as current_record
                              ,last(l.record_start_date) as record_start_date
                              ,last(l.record_end_date) as record_end_date
                              ,last(l.record_creation_date) as record_creation_date
                              ,last(l.record_modification_date) as record_modification_date
                              ,sha2(l.location, 256) as location_code
                              ,sha2(getconcatenedstring(array(l.location_type,l.location_country)),256)  as hashkey
                              ,'""" + runid + """' as runid
                         
                        from vw_location l
                             left join vw_param_nationality pn on lower(pn.code_iso_3) = lower(l.location_country)  
                             
                        where 1=1
                          and l.location is not null
                                                
                        group by    l.location
                                   ,l.location_type
                                   ,l.location_country
                                   ,pn.country_name_fr
                                   ,l.location_reference
                                   
                                    """

// COMMAND ----------

// DBTITLE 1,Store the query results in the dataframe and put the dataframe in the cache
val location_inserted = spark.sql(query_record)
location_inserted.cache()  //put the dataframe on the cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_location """
val res = stmt.execute(query_delete)

// COMMAND ----------

location_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_location", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_location """
stmt.execute(sql)

connection.close()

// COMMAND ----------

//set up the return value with the number of lines read, rejected and inserted
val read_records = df_location_read.count().toInt //count the number of read records
val inserted_records = location_inserted.count().toInt //count the number of read records
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_location_read.unpersist
location_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)