// Databricks notebook source
// DBTITLE 1,Get Parameters for DB Connection and the RunId
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include the functions to connect to databases and ADLS
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Connections to the Database
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Prepare the table hr absenteism for reading
 if(spark.catalog.tableExists("hr.absenteism_consolidated")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism_consolidated")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val byabs_info_dates = Window.partitionBy("dateval_start","dateval_end","dateval_start_prol","dateval_end_prol","dateval_start_prol_first","dateval_end_prol_last").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc)

val df_abs_info_dates_read = spark.table("hr.absenteism_consolidated").withColumn("rank",rank() over byabs_info_dates)
                                                                      .filter(col("rank")==="1")
                                                                      .select(
                                                                               "dateval_start"
                                                                              ,"dateval_end"
                                                                              ,"dateval_start_prol"
                                                                              ,"dateval_end_prol"
                                                                              ,"dateval_start_prol_first"
                                                                              ,"dateval_end_prol_last"
                                                                              ,"dates_code"
                                                                              ,"version"
                                                                              ,"date_raw_load_file"
                                                                              ,"filepath"
                                                                              ,"filename"
                                                                              ,"curated_ingested_date")
                                                                       .distinct
                                                                       
df_abs_info_dates_read.cache()  //put the dataframe on the cache
df_abs_info_dates_read.createOrReplaceTempView("vw_abs_info_dates")

// COMMAND ----------

// DBTITLE 1,Select columns to insert
val query_record = """select        distinct
                                    id.dateval_start as absence_start_date
                                   ,id.dateval_end as absence_end_date
                                   ,id.dateval_start_prol as absence_start_date_prol
                                   ,id.dateval_end_prol as absence_end_date_prol
                                   ,id.dateval_start_prol_first as absence_start_date_prol_first
                                   ,id.dateval_end_prol_last as absence_end_date_prol_last
                                   ,id.dates_code  as absence_info_dates_code
                                   ,id.version as version
                                   ,id.date_raw_load_file as date_raw_load_file
                                   ,id.filepath as filepath
                                   ,id.filename as filename
                                   ,id.curated_ingested_date as curated_ingested_date                        
                                   ,id.dates_code  as hashkey 
                                    
                                   ,'""" + runid + """' as runid
                        from vw_abs_info_dates id
                             
                        where 1 = 1
                          and (id.dateval_start is not null or id.dateval_end is not null)
                     
                          
  
                               
                        """ 

// COMMAND ----------

// DBTITLE 1,Store the query results in the dataframe and put the dataframe in the cache
val abs_info_dates_inserted = spark.sql(query_record)
abs_info_dates_inserted.cache()  //put the dataframe on the cache


// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_absence_info_dates """
val res = stmt.execute(query_delete)

// COMMAND ----------

abs_info_dates_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_absence_info_dates", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_absence_info_dates """
stmt.execute(sql)

connection.close()

// COMMAND ----------

//set up the return value with the number of lines read, rejected and inserted
val read_records = df_abs_info_dates_read.count().toInt //count the number of read records
val inserted_records = abs_info_dates_inserted.count().toInt //count the number of read records
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_abs_info_dates_read.unpersist
abs_info_dates_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)