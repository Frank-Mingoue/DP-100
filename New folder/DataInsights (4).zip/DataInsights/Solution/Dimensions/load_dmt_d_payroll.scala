// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

 if(spark.catalog.tableExists("hr.payroll")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.payroll")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bypayroll = Window.partitionBy("code_rubr","accounting_account").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_payroll_read = spark.table("hr.payroll").filter(col("current_record") === true)
                                               .withColumn("rank",rank() over bypayroll)
                                               .filter(col("rank")==="1")
                                               .select( "payroll_code"
                                                       ,"code_rubr" 
                                                       ,"accounting_account"
                                                       ,"label_rubr"   
                                                       ,"flag_salary"
                                                       ,"flag_debit"                   
                                                       ,"code_payroll_level_4"
                                                       ,"label_payroll_level_4"                   
                                                       ,"code_payroll_level_3"
                                                       ,"label_payroll_level_3"
                                                       ,"code_payroll_level_2"
                                                       ,"label_payroll_level_2"
                                                       ,"code_payroll_level_1"
                                                       ,"label_payroll_level_1"
                                                       ,"flag_amount_wage_gross"
                                                       ,"flag_amount_aw4"
                                                       ,"flag_amount_aw6"
                                                       ,"flag_amount_rem_nao"
                                                       ,"flag_amount_rem_bs"                   
                                                       ,"flag_amount_rem_benchmark"
                                                       ,"flag_amount_rem_target"
                                                       ,"flag_amount_rem_real"    
                                                       ,"is_payroll_di"
                                                       ,"version"
                                                       ,"date_raw_load_file"
                                                       ,"filepath"
                                                       ,"filename"
                                                       ,"current_record"
                                                       ,"record_start_date"
                                                       ,"record_end_date"
                                                       ,"record_creation_date"
                                                       ,"record_modification_date"
                                                       ,"curated_ingested_date")
                                               .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                                               .distinct

df_payroll_read.cache()  //put the dataframe ont he cache
df_payroll_read.createOrReplaceTempView("vw_payroll")


// COMMAND ----------

//spark.read.jdbc(jdbcurl, "dbo.param_payroll", connectionproperties).createOrReplaceTempView("vw_param_payroll")

// COMMAND ----------

val query_record = """select 
                              p.code_payroll_level_1 as code_rubrique_paie_niv1
                             ,last(p.label_payroll_level_1) as libelle_rubrique_paie_niv1
                             ,p.code_payroll_level_2 as code_rubrique_paie_niv2
                             ,last(p.label_payroll_level_2) as libelle_rubrique_paie_niv2
                             ,p.code_payroll_level_3  as code_rubrique_paie_niv3
                             ,last(p.label_payroll_level_3) as libelle_rubrique_paie_niv3
                             ,p.code_payroll_level_4 as code_rubrique_paie_niv4
                             ,last(p.label_payroll_level_4) as libelle_rubrique_paie_niv4
                             ,p.code_rubr as code_rubrique_paie
                             ,last(p.label_rubr) as libelle_rubrique_paie
                             ,p.accounting_account as compte_comptable
                             ,last(p.flag_salary) as flag_salarial
                             ,last(p.flag_debit) as flag_debit
                             ,case when last(lower(p.flag_amount_wage_gross)) = 'oui' then 1 else null end as  flag_montant_masse_salariale_brute
                             ,case when last(lower(p.flag_amount_aw4)) = 'oui' then 1 else null end as  flag_montant_aw4
                             ,case when last(lower(p.flag_amount_aw6)) = 'oui' then 1 else null end as  flag_montant_aw6
                             ,case when last(lower(p.flag_amount_rem_nao)) = 'oui' then 1 else null end as  flag_montant_rem_nao
                             ,case when last(lower(p.flag_amount_rem_bs)) = 'oui' then 1 else null end as  flag_montant_rem_bs
                             ,case when last(lower(p.flag_amount_rem_benchmark)) = 'oui' then 1 else null end as  flag_montant_rem_benchmark
                             ,case when last(lower(p.flag_amount_rem_target)) = 'oui' then 1 else null end as  flag_montant_rem_cible
                             ,case when last(lower(p.flag_amount_rem_real)) = 'oui' then 1 else null end as  flag_montant_rem_reelle
                             ,last(p.version) as version
                             ,last(p.date_raw_load_file) as date_raw_load_file
                             ,last(p.filepath) as filepath
                             ,last(p.filename) as filename
                             ,last(p.curated_ingested_date) as curated_ingested_date
                             ,last(p.current_record) as current_record
                             ,last(p.record_start_date) as record_start_date
                             ,last(p.record_end_date) as record_end_date
                             ,last(p.record_creation_date) as record_creation_date
                             ,last(p.record_modification_date) as record_modification_date
                             ,p.payroll_code
                             ,sha2(getconcatenedstring(array(p.code_payroll_level_1
                                                             ,p.code_payroll_level_2
                                                             ,p.code_payroll_level_3
                                                             ,p.code_payroll_level_4
                                                             ,p.code_rubr)),256) as hashkey 
                             ,'""" + runid + """' as runid
                             ,last(is_payroll_di) as is_payroll_di
                         
                        from vw_payroll p
                        
                        where 1 = 1
                          and p.code_rubr is not null 
                           
                        group by 
                               p.code_payroll_level_1
                              ,p.code_payroll_level_2
                              ,p.code_payroll_level_3
                              ,p.code_payroll_level_4
                              ,p.code_rubr 
                              ,p.payroll_code
                              ,p.accounting_account
                              """ 


// COMMAND ----------

val payroll_inserted = spark.sql(query_record)
payroll_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------


val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_payroll """
val res = stmt.execute(query_delete)

// COMMAND ----------

payroll_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_payroll", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_payroll """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_payroll_read.count().toInt //count the number of read records
val inserted_records = payroll_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_payroll_read.unpersist
payroll_inserted.unpersist

// COMMAND ----------


dbutils.notebook.exit(return_value)