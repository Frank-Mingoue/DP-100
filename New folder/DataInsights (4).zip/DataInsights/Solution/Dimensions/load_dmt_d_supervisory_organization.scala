// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bysupervisory_organization = Window.partitionBy("supervisory_organization_reference").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_supervisory_organization_read = spark.table("hr.employee").withColumn("rank",rank() over bysupervisory_organization)
                           .filter(col("rank")==="1")
                           .select(   "supervisory_organization_reference"
                                     ,"supervisory_organization_name" 
                                     ,"version"
                                     ,"date_raw_load_file"
                                     ,"filepath"
                                     ,"filename"
                                     ,"current_record"
                                     ,"record_start_date"
                                     ,"record_end_date"
                                     ,"record_creation_date"
                                     ,"record_modification_date"
                                     ,"curated_ingested_date")
                          .distinct

df_supervisory_organization_read.createOrReplaceTempView("vw_d_supervisory_organization")
df_supervisory_organization_read.cache()  //put the dataframe ont he cache


// COMMAND ----------

val query_record = """select 
                                    sp.supervisory_organization_reference
                                   ,last(sp.supervisory_organization_name) as supervisory_organization_name
                                   ,last(sp.version) as version
                                   ,last(sp.date_raw_load_file) as date_raw_load_file
                                   ,last(sp.filepath) as filepath
                                   ,last(sp.filename) as filename
                                   ,last(sp.curated_ingested_date) as curated_ingested_date
                                   ,last(sp.current_record) as current_record
                                   ,last(sp.record_start_date) as record_start_date
                                   ,last(sp.record_end_date) as record_end_date
                                   ,last(sp.record_creation_date) as record_creation_date
                                   ,last(sp.record_modification_date) as record_modification_date
                                   ,sha2(sp.supervisory_organization_reference, 256) as supervisory_organization_code
                                   ,sha2(getconcatenedstring(array(last(sp.supervisory_organization_name))),256)  as hashkey
                                   ,'""" + runid + """' as runid
                         
                        from vw_d_supervisory_organization sp
                        
                        where 1 = 1
                          and (sp.supervisory_organization_reference is not null)
                          
                        group by   
                                    sp.supervisory_organization_reference
                        """ 

// COMMAND ----------

val supervisory_organization_inserted = spark.sql(query_record)
supervisory_organization_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_supervisory_organization """
val res = stmt.execute(query_delete)

// COMMAND ----------

supervisory_organization_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_supervisory_organization", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_supervisory_organization """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_supervisory_organization_read.count().toInt //count the number of read records
val inserted_records =supervisory_organization_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_supervisory_organization_read.unpersist
supervisory_organization_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)