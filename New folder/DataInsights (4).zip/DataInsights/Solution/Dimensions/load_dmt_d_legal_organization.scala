// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_autre = "Non Affecte"

// COMMAND ----------

 if(spark.catalog.tableExists("common.organization")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE common.organization")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bylegal_organization = Window.partitionBy("cost_center_code","companycode","code_establishment").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_legal_organization_read = spark.table("common.organization").withColumn("rank",rank() over bylegal_organization)
                                                                   .filter(col("rank")==="1")
                                                                   .select(  "companycode" 
                                                                             ,"company"                           
                                                                             ,"code_establishment"
                                                                             ,"label_establishment"
                                                                             ,"cost_center_code"
                                                                             ,"cost_center_label"
                                                                             ,"current_hierarchy"
                                                                             ,"version"
                                                                             ,"date_raw_load_file"
                                                                             ,"filepath"
                                                                             ,"filename"
                                                                             ,"current_record"
                                                                             ,"record_start_date"
                                                                             ,"record_end_date"
                                                                             ,"record_creation_date"
                                                                             ,"record_modification_date"
                                                                             ,"curated_ingested_date")
                                                                   .distinct
df_legal_organization_read.cache()  //put the dataframe ont he cache
df_legal_organization_read.createOrReplaceTempView("vw_d_legal_organization")

// COMMAND ----------

val bylegal_organization_current = Window.partitionBy("cost_center_code","companycode","code_establishment").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_legal_organization_read_current = spark.table("common.organization").filter(col("current_hierarchy")==="true")
                                                                           .withColumn("rank",rank() over bylegal_organization_current)
                                                                           .filter(col("rank")==="1")
                                                                           .select(  "companycode"                        
                                                                                     ,"code_establishment"
                                                                                     ,"cost_center_code"
                                                                                     ,"current_hierarchy")
                                                                           .distinct
df_legal_organization_read_current.cache()  //put the dataframe ont he cache
df_legal_organization_read_current.createOrReplaceTempView("vw_d_legal_organization_current")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_legal_organization", connectionproperties).createOrReplaceTempView("vw_ref_legal_organization")

// COMMAND ----------

val query_record = """select 
                             coalesce(last(po.top_level), '""" + default_hierarchy_autre + """') as top_level
                             ,coalesce(last(po.top_level_order),99) as top_level_order
                            ,o.companycode
                            ,last(po.company) as company
                            ,coalesce(last(po.company_order),99) as company_order
                            ,o.code_establishment as code_etablissement
                            ,coalesce(last(o.label_establishment), '""" + default_hierarchy_autre + """') as libelle_etablissement
                            ,o.cost_center_code
                            ,last(o.cost_center_label) as cost_center_label
                            ,last(o.version) as version
                            ,last(o.date_raw_load_file) as date_raw_load_file
                            ,last(o.filepath) as filepath
                            ,last(o.filename) as filename
                            ,last(o.curated_ingested_date) as curated_ingested_date
                            ,last(o.current_record) as current_record
                            ,last(o.record_start_date) as record_start_date
                            ,last(o.record_end_date) as record_end_date
                            ,last(o.record_creation_date) as record_creation_date
                            ,last(o.record_modification_date) as record_modification_date
                            ,sha2(getconcatenedstring(array(
                                                             o.cost_center_code
                                                            ,o.companycode
                                                            ,o.code_establishment)),256) as legal_organization_code
                            ,sha2(getconcatenedstring(array(
                                                             coalesce(last(po.top_level), '""" + default_hierarchy_autre + """')
                                                                     ,coalesce(last(po.top_level_order),99)
                                                                    ,last(po.company)
                                                                    ,coalesce(last(po.company_order),99)
                                                                    ,coalesce(last(o.label_establishment), '""" + default_hierarchy_autre + """')
                                                                    ,last(o.cost_center_label))),256) as hashkey
                                   ,'""" + runid + """' as runid
                                   ,last(oc.current_hierarchy) as current_hierarchy
                         
                        from vw_d_legal_organization o
                             left join vw_ref_legal_organization po on (lower(o.company) = lower(po.source_value) or lower(o.company) = lower(po.company))
                             left join vw_d_legal_organization_current oc on coalesce(oc.cost_center_code,'-1') = coalesce(o.cost_center_code,'-1')
                                                                         and coalesce(oc.code_establishment,'-1') = coalesce(o.code_establishment,'-1')
                                                                         and coalesce(oc.companycode,'-1') = coalesce(o.companycode,'-1')
                             
                        where 1=1
                          and o.cost_center_code is not null 
                          
                        group by
                                   o.companycode
                                   ,o.code_establishment
                                   ,o.cost_center_code             
                         """ 

// COMMAND ----------

val legal_organization_inserted = spark.sql(query_record)
legal_organization_inserted.cache()  //put the dataframe ont he cache
//display(legal_organization_inserted.where($"top_level"==="CHANEL MODE ITALIE"))

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_legal_organization """
val res = stmt.execute(query_delete)

// COMMAND ----------

legal_organization_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_legal_organization", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_legal_organization """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_legal_organization_read.count().toInt //count the number of read records
val inserted_records = legal_organization_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_legal_organization_read.unpersist
legal_organization_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)