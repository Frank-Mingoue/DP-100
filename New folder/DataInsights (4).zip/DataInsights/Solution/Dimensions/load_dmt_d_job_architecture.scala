// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------


val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_autre = "NC"

// COMMAND ----------

 if(spark.catalog.tableExists("common.job")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE common.job")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Reference Info
val byjob_reference = Window.partitionBy("job_profile_reference").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_job_reference_read = spark.table("common.job").withColumn("rank",rank() over byjob_reference)
                                                         .filter(col("rank")==="1")
                                                         .select(  "job_profile_name"
                                                                  ,"job_profile_reference"
                                                                  ,"job_profile_reference_label"
                                                                  ,"job_category"
                                                                  ,"job_family"
                                                                  ,"job_family_group")

                                                    .distinct
                                                    .createOrReplaceTempView("vw_job_reference")


// COMMAND ----------

// DBTITLE 1,Get Management Level Info
val byjob_management_level = Window.partitionBy("management_level").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_job_managementlevel_read = spark.table("common.job").withColumn("rank",rank() over byjob_management_level)
                                                         .filter(col("rank")==="1")
                                                         .select( "management_level"
                                                                  ,"management_level_label")

                                                    .distinct
                                                    .createOrReplaceTempView("vw_job_management_level")
  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Get Grade info
val byjob_grade = Window.partitionBy("grade").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_job_grade= spark.table("common.job").withColumn("rank",rank() over byjob_grade)
                                                         .filter(col("rank")==="1")
                                                         .select(  "grade"
                                                                  ,"grade_label")

                                                    .distinct
                                                    .createOrReplaceTempView("vw_job_grade")
  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Get Job Title data from Contract
val byjob_title = Window.partitionBy("employee_code", "employee_id", "france_payroll_id", "job_title", "management_level","job_profile_reference").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_job_title_read = spark.table("hr.contract").withColumn("rank",rank() over byjob_title)
                                                 .filter(col("rank")==="1")
                                                 .select( "employee_code"
                                                          ,"employee_id"
                                                          ,"france_payroll_id"
                                                          ,"job_title"        
                                                          ,"management_level"
                                                          ,"job_profile_reference"
                                                          ,"job_title_code"
                                                          ,"job_code"
                                                          ,"version"
                                                          ,"date_raw_load_file"
                                                          ,"filepath"
                                                          ,"filename"
                                                          ,"current_record"
                                                          ,"record_start_date"
                                                          ,"record_end_date"
                                                          ,"record_creation_date"
                                                          ,"record_modification_date"
                                                          ,"curated_ingested_date")

                                            .distinct
df_job_title_read.createOrReplaceTempView("vw_job_title")                                           
df_job_title_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Get Grade data from Contract
val bygrade = Window.partitionBy("employee_code", "employee_id", "france_payroll_id", "grade").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_grade_read = spark.table("hr.contract").withColumn("rank",rank() over bygrade)
                                                 .filter(col("rank")==="1")
                                                 .select( "employee_code"
                                                          ,"employee_id"
                                                          ,"france_payroll_id"
                                                          ,"grade"        
                                                          ,"grade_code")

                                            .distinct
df_grade_read.createOrReplaceTempView("vw_grade")                                           
df_grade_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Query to build Job Architecture
val query_record = """select 
                             upper(jt.job_title) as job_title
                            ,jg.grade
                            ,case when lower(last(jg.grade_label)) like 'not%graded' or lower(jg.grade) like 'not%graded' then 'Not Graded' 
                                  when length(trim(getvalueposition(last(jg.grade_label),1,' ')))=1 then concat('0',trim(getvalueposition(last(jg.grade_label),1,' ')))
                                  else trim(getvalueposition(last(jg.grade_label),1,' ')) end as grade_label
                            ,case when lower(last(jg.grade_label)) like 'not%graded' or lower(jg.grade) like 'not%graded' then 0 else trim(getvalueposition(last(jg.grade_label),1,' ')) end as grade_order
                            ,case when lower(last(jg.grade_label)) like 'not%graded' or lower(jg.grade) like 'not%graded' then 'Not Graded'
                                  when trim(getvalueposition(last(jg.grade_label),1,' ')) >= 16 then "16 et +" 
                                  when length(trim(getvalueposition(last(jg.grade_label),1,' ')))=1 then concat('0',trim(getvalueposition(last(jg.grade_label),1,' ')))
                                  else trim(getvalueposition(last(jg.grade_label),1,' ')) end as consolidated_grade
                            ,case when lower(last(jg.grade_label)) = 'not graded' or lower(jg.grade) like 'not%graded' then 0
                                  when trim(getvalueposition(last(jg.grade_label),1,' ')) >= 16 then 16 else trim(getvalueposition(last(jg.grade_label),1,' ')) end as consolidated_grade_order  
                            ,jt.management_level
                            ,trim(getvalueposition(last(jm.management_level_label),1,'-')) as management_level_label
                            ,case lower(trim(getvalueposition(last(jm.management_level_label),1,'-')))
                                when "c" then "01"
                                when "h" then "02"
                                when "a" then "03"
                                when "n" then "04"
                                when "e" then "05"
                                when "l" then "06"
                                when "ex1" then "07"
                                when "not banded" then "99"
                                else "99" end  as management_level_order
                            ,jt.job_profile_reference
                            ,last(jr.job_profile_reference_label) as job_profile_reference_label
                            ,last(jr.job_profile_name) as job_profile_name
                            ,coalesce(last(jr.job_category), '""" + default_hierarchy_autre + """') as job_category
                            ,coalesce(last(jr.job_family), '""" + default_hierarchy_autre + """') as job_family
                            ,coalesce(last(jr.job_family_group), '""" + default_hierarchy_autre + """') as job_family_group
                            ,last(jt.version) as version
                            ,last(jt.date_raw_load_file) as date_raw_load_file
                            ,last(jt.filepath) as filepath
                            ,last(jt.filename) as filename
                            ,last(jt.curated_ingested_date) as curated_ingested_date
                            ,last(jt.current_record) as current_record
                            ,last(jt.record_start_date) as record_start_date
                            ,last(jt.record_end_date) as record_end_date
                            ,last(jt.record_creation_date) as record_creation_date
                            ,last(jt.record_modification_date) as record_modification_date
                            ,sha2(getconcatenedstring(array(
                                                             lower(jt.job_title)
                                                            ,jg.grade
                                                            ,jt.management_level
                                                            ,jt.job_profile_reference)),256)  as job_architecture_code
                            
                            ,sha2(jg.grade ,256) as grade_code
                                                        
                            ,sha2(getconcatenedstring(array(
                                                             lower(jt.job_title)
                                                            ,jt.management_level
                                                            ,jt.job_profile_reference)),256) as job_title_code
                            ,sha2(getconcatenedstring(array( 
                                                             case when lower(last(jg.grade_label)) like 'not%graded' or lower(jg.grade) like 'not%graded' then 'Not Graded' else last(jg.grade_label) end
                                                            ,last(jm.management_level_label)
                                                            ,last(jr.job_profile_reference_label)
                                                            ,last(jr.job_profile_name) 
                                                            ,last(jr.job_category)
                                                            ,last(jr.job_family)
                                                            ,last(jr.job_family_group))),256)  as hashkey
                            
                             ,'""" + runid + """' as runid
                                             
                        from vw_job_title jt 
                             inner join vw_grade g on jt.employee_code = g.employee_code 
                             left join vw_job_grade jg on lower(jg.grade) = lower(g.grade)
                             left join vw_job_management_level jm on lower(jm.management_level) = lower(jt.management_level)
                             left join vw_job_reference jr on lower(jt.job_profile_reference) = lower(jr.job_profile_reference)
                        
                        where 1 = 1
                          and (jt.job_title is not null or jg.grade is not null or jt.management_level is not null or jt.job_profile_reference is not null)
                        
                        group by 
                                 jt.job_title
                                ,jg.grade
                                ,jt.management_level
                                ,jt.job_profile_reference
                                
                                
                                """

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select job_family_group,employee_id,* from employee.get_workers where filename = 'getworkers_20220707_2240.csv' and job_profile_reference = 'JP-MAR_GEN_GEN_00I'

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select job_family_group,filename from common.job  where job_profile_reference = 'JP-MAR_GEN_GEN_00I'

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select jr.job_family_group,jt.job_profile_reference from 
// MAGIC 
// MAGIC vw_job_title jt 
// MAGIC                              left join vw_job_reference jr on lower(jt.job_profile_reference) = lower(jr.job_profile_reference)
// MAGIC                              where jt.job_title_code = 'aa6aeb8801df9f5a5d759bbb92e67e0b98a02c23a6c963bac0af85a2c37664c0'

// COMMAND ----------

val job_architecture_inserted = spark.sql(query_record)
job_architecture_inserted.cache()  //put the dataframe ont he cache
//display(job_architecture_inserted)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_job_architecture """
val res = stmt.execute(query_delete)

// COMMAND ----------

job_architecture_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_job_architecture", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_job_architecture """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_job_title_read.count().toInt //count the number of read records
val inserted_records = job_architecture_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
job_architecture_inserted.unpersist
df_grade_read.unpersist
df_job_title_read.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)