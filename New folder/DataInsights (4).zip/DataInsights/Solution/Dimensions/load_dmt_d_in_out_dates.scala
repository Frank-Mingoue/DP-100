// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val byin_out_dates = Window.partitionBy("employee_code","cost_center_start_date","cost_center_end_date","establishment_start_date","establishment_end_date","company_start_date","company_end_date").orderBy($"record_start_date".desc)
val df_in_out_dates_org_read = spark.table("hr.employee").withColumn("rank",rank() over byin_out_dates)
                           .filter(col("rank")==="1")
                           .select(  "employee_code"
                                     ,"employee_id"
                                     ,"cost_center_start_date"
                                     ,"establishment_start_date"
                                     ,"establishment_end_date"  
                                     ,"company_start_date"
                                     ,"company_end_date"  
                                     ,"version"
                                     ,"date_raw_load_file"
                                     ,"filepath"
                                     ,"filename"
                                     ,"current_record"
                                     ,"record_start_date"
                                     ,"record_end_date"
                                     ,"record_creation_date"
                                     ,"record_modification_date"
                                     ,"curated_ingested_date")
                          .distinct
df_in_out_dates_org_read.createOrReplaceTempView("vw_d_in_out_dates_org")
df_in_out_dates_org_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

val byin_out_dates = Window.partitionBy("employee_code","hire_date","original_hire_date","contract_end_date").orderBy($"record_start_date".desc)
val df_in_out_dates_read = spark.table("hr.contract").withColumn("rank",rank() over byin_out_dates)
                           .filter(col("rank")==="1")
                           .select(  "employee_code"
                                     ,"employee_id"
                                     ,"hire_date"
                                     ,"original_hire_date"
                                     ,"contract_start_date"  
                                     ,"contract_end_date"  
                                     ,"version"
                                     ,"date_raw_load_file"
                                     ,"filepath"
                                     ,"filename"
                                     ,"current_record"
                                     ,"record_start_date"
                                     ,"record_end_date"
                                     ,"record_creation_date"
                                     ,"record_modification_date"
                                     ,"curated_ingested_date")
                          .distinct
df_in_out_dates_read.createOrReplaceTempView("vw_d_in_out_dates")
df_in_out_dates_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

val query_record = """
select
  c.original_hire_date as date_in_chanel,
  date_add(c.contract_end_date,1)  as date_out_chanel
  ,e.establishment_start_date as date_in_etablishment_chanel
  ,date_add(e.establishment_end_date,1) as date_out_etablishment_chanel
  ,e.company_start_date as date_in_company_chanel
  ,date_add(e.company_end_date,1) as date_out_company_chanel

 ,last(c.version) as version
 ,last(c.date_raw_load_file) as date_raw_load_file
 ,last(c.filepath) as filepath
 ,last(c.filename) as filename
 ,last(c.curated_ingested_date) as curated_ingested_date
 ,true as current_record
 ,last(c.record_start_date) as record_start_date
 ,last(c.record_end_date) as record_end_date
 ,last(c.record_creation_date) as record_creation_date
 ,last(c.record_modification_date) as record_modification_date
 ,sha2(getconcatenedstring(array(c.original_hire_date
                                 ,c.contract_end_date)),256) as in_out_dates_code
 ,sha2(getconcatenedstring(array(e.establishment_start_date
                                 ,e.establishment_end_date
                                 ,e.company_start_date
                                 ,e.company_end_date)),256) as org_in_out_dates_code
,sha2(getconcatenedstring(array(c.original_hire_date
                                 ,c.contract_end_date
                                 ,e.establishment_start_date
                                 ,e.establishment_end_date
                                 ,e.company_start_date
                                 ,e.company_end_date)),256)  as hashkey
  ,'""" + runid + """' as runid
     
from vw_d_in_out_dates_org e
inner join vw_d_in_out_dates c
on e.employee_code = c.employee_code

where coalesce(c.original_hire_date
               ,c.contract_end_date
               ,e.establishment_start_date
               ,e.establishment_end_date
               ,e.company_start_date
               ,e.company_end_date
               ) is not null

group by   

     c.original_hire_date
     ,c.contract_end_date
     ,e.establishment_start_date
     ,e.establishment_end_date
     ,e.company_start_date
     ,e.company_end_date
                         
                        """ 

// COMMAND ----------

val in_out_dates_inserted = spark.sql(query_record)
in_out_dates_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_in_out_dates """
val res = stmt.execute(query_delete)

// COMMAND ----------

in_out_dates_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_in_out_dates", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_in_out_dates"""
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_in_out_dates_read.count().toInt //count the number of read records
val inserted_records =in_out_dates_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_in_out_dates_read.unpersist
in_out_dates_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)