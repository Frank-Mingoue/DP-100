// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

if(spark.catalog.tableExists("hr.career")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.career")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val by_careermobility = Window.partitionBy("relocation_short_term_area","relocation_long_term_area","relocation_long_term_willing","relocation_short_term_willing","date_raw_load_file").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc, $"record_end_date".desc, $"filename".desc, $"version")
val df_career_mobility_read = spark.table("hr.career").withColumn("rank",rank() over by_careermobility)
                                                      .filter(col("rank")==="1")
                                                      .distinct
                                                      .withColumn("mobility_destination_willing",
                                                         when((lower($"relocation_long_term_area") === "france" and $"relocation_short_term_area".isNull)
                                                             or (lower($"relocation_short_term_area") === "france" and $"relocation_long_term_area".isNull)
                                                             or (lower($"relocation_long_term_area") === "france" and lower($"relocation_short_term_area") === "france"),lit("FRANCE"))
                                                                  
                                                         .when((!lower($"relocation_long_term_area").contains("france") and $"relocation_long_term_area".isNotNull 
                                                                                                                        and $"relocation_short_term_area".isNull)
                                                             or (!lower($"relocation_short_term_area").contains("france") and $"relocation_short_term_area".isNotNull 
                                                                                                                          and $"relocation_long_term_area".isNull)
                                                             or (!lower($"relocation_short_term_area").contains("france") and !lower($"relocation_long_term_area").contains("france")
                                                                                                                          and $"relocation_long_term_area".isNotNull                                                                                                                           
                                                                                                                          and $"relocation_short_term_area".isNotNull),lit("INTERNATIONAL"))
                                                                  
                                                        .when((lower($"relocation_long_term_area").contains("france") and length(lower(trim($"relocation_long_term_area"))) > length(lit("france")))                                                               
                                                             or (lower($"relocation_short_term_area").contains("france") and length(lower(trim($"relocation_short_term_area"))) > length(lit("france")))                                                              
                                                             or (lower($"relocation_long_term_area").contains("france") and !lower($"relocation_short_term_area").contains("france")) 
                                                             or (lower($"relocation_short_term_area").contains("france") and !lower($"relocation_long_term_area").contains("france")), lit("FRANCE ET INTERNATIONAL"))
                                                         .otherwise("PAS DE DESTINATION EXPRIMEE"))

                                                      .withColumn("mobility_period",
                                                        when((lower($"relocation_long_term_willing") === "oui" or lower($"relocation_long_term_willing") === "yes") and 
                                                             (lower($"relocation_short_term_willing") === "non" or lower($"relocation_short_term_willing") === "no" or $"relocation_short_term_willing".isNull),lit("LONGUE PERIODE"))
                                                                  
                                                       .when((lower($"relocation_short_term_willing") === "oui" or lower($"relocation_short_term_willing") === "yes") and 
                                                             (lower($"relocation_long_term_willing") === "non" or lower($"relocation_long_term_willing") === "no" or $"relocation_long_term_willing".isNull),lit("COURTE PERIODE"))
                                                                  
                                                     
                                                       .when((lower($"relocation_long_term_willing") === "oui" or lower($"relocation_long_term_willing") === "yes") and 
                                                              (lower($"relocation_short_term_willing") === "oui" or lower($"relocation_short_term_willing") === "yes"),lit("TOUTES PERIODES"))
                                                       .otherwise("PAS DE SOUHAIT DE MOBILITE"))
                                                     .select( "relocation_short_term_area" 
                                                             ,"relocation_long_term_area"
                                                             ,"relocation_short_term_willing"
                                                             ,"relocation_long_term_willing" 
                                                             ,"mobility_destination_willing"
                                                             ,"mobility_period"                                                             
                                                             ,"version"
                                                             ,"date_raw_load_file"
                                                             ,"filepath"
                                                             ,"filename"
                                                             ,"current_record"
                                                             ,"record_start_date"
                                                             ,"record_end_date"
                                                             ,"record_creation_date"
                                                             ,"record_modification_date"
                                                             ,"curated_ingested_date")
                                                    .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")                                                      
                                                    .distinct
df_career_mobility_read.createOrReplaceTempView("vw_career_mobility")

// COMMAND ----------

val query_record = """select  distinct          
                              m.relocation_short_term_area 
                             ,m.relocation_long_term_area
                             ,m.relocation_short_term_willing  
                             ,m.relocation_long_term_willing                   
                             ,m.mobility_destination_willing
                             ,m.mobility_period
                             ,m.date_raw_load_file as mobility_detection_date
                             ,sha2(getconcatenedstring(array(m.relocation_short_term_area
                                                            ,m.relocation_long_term_area
                                                            ,m.relocation_short_term_willing
                                                            ,m.relocation_long_term_willing
                                                            ,m.date_raw_load_file)),256) as career_mobility_code
                             ,m.version
                             ,m.date_raw_load_file
                             ,m.filepath
                             ,m.filename
                             ,m.curated_ingested_date    
                             ,m.record_start_date
                             ,m.record_end_date
                             ,m.record_creation_date 
                             ,m.record_modification_date
                             ,sha2(getconcatenedstring(array( m.mobility_destination_willing 
                                                             ,m.mobility_period
                                                             ,m.date_raw_load_file)),256)  as hashkey
                             ,'""" + runid + """' as runid
                         
                       from  vw_career_mobility m
                       where 1=1
                       and (m.relocation_short_term_area is not null or 
                            m.relocation_long_term_area is not null or
                            m.relocation_short_term_willing is not null or
                            m.relocation_long_term_willing is not null
                           )
                      """ 


// COMMAND ----------

val career_mobility_inserted = spark.sql(query_record)
career_mobility_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_career_mobility """
val res = stmt.execute(query_delete)

// COMMAND ----------

career_mobility_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_career_mobility", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_career_mobility"""
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_career_mobility_read.count().toInt //count the number of read records
val inserted_records = career_mobility_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_career_mobility_read.unpersist
career_mobility_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)