// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_autre = "Autre"

// COMMAND ----------

 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bymanager = Window.partitionBy("manager_reference","lt_leader_reference_n_1","lt_leader_reference").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_manager_read = spark.table("hr.employee").withColumn("rank",rank() over bymanager)
               .filter(col("rank")==="1")
               .select( "manager_reference" 
                       ,"manager_last_name"                           
                       ,"manager_first_name"
                       ,"lt_leader_last_name_n_1"
                       ,"lt_leader_first_name_n_1"
                       ,"lt_leader_reference_n_1"
                       ,"lt_leader_last_name"
                       ,"lt_leader_first_name"     
                       ,"lt_leader_reference"    
                       ,"version"
                       ,"date_raw_load_file"
                       ,"filepath"
                       ,"filename"
                       ,"current_record"
                       ,"record_start_date"
                       ,"record_end_date"
                       ,"record_creation_date"
                       ,"record_modification_date"
                       ,"curated_ingested_date")
               .distinct
df_manager_read.createOrReplaceTempView("vw_manager")
df_manager_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

val query_record = """select 
                             m.manager_reference
                            ,last(m.manager_last_name) as manager_last_name
                            ,last(m.manager_first_name) as manager_first_name
                            ,last(m.lt_leader_last_name_n_1) as lt_leader_last_name_n_1
                            ,last(m.lt_leader_first_name_n_1) as lt_leader_first_name_n_1
                            ,m.lt_leader_reference_n_1 
                            ,last(m.lt_leader_last_name) as lt_leader_last_name
                            ,last(m.lt_leader_first_name) as lt_leader_first_name
                            ,m.lt_leader_reference
                            ,last(m.version) as version
                            ,last(m.date_raw_load_file) as date_raw_load_file
                            ,last(m.filepath) as filepath
                            ,last(m.filename) as filename
                            ,last(m.curated_ingested_date) as curated_ingested_date
                            ,last(m.current_record) as current_record
                            ,last(m.record_start_date) as record_start_date
                            ,last(m.record_end_date) as record_end_date
                            ,last(m.record_creation_date) as record_creation_date
                            ,last(m.record_modification_date) as record_modification_date
                            ,sha2(getconcatenedstring(array(
                                                             m.manager_reference
                                                            ,m.lt_leader_reference_n_1 
                                                            ,m.lt_leader_reference)),256) as  manager_code
                            ,sha2(getconcatenedstring(array(
                                                            last(m.manager_last_name) 
                                                           ,last(m.manager_first_name)
                                                           ,last(m.lt_leader_last_name_n_1) 
                                                           ,last(m.lt_leader_first_name_n_1)
                                                           ,last(m.lt_leader_last_name)
                                                           ,last(m.lt_leader_first_name))),256) as  hashkey
                            ,'""" + runid + """' as runid
                         
                        from vw_manager m
                        where 1 = 1
                          and (m.manager_reference is not null or m.lt_leader_reference_n_1 is not null or m.lt_leader_reference is not null)
                        group by 
                             m.manager_reference 
                            ,m.lt_leader_reference_n_1 
                            ,m.lt_leader_reference
                       """ 

// COMMAND ----------

val manager_inserted = spark.sql(query_record)
manager_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_manager """
val res = stmt.execute(query_delete)

// COMMAND ----------

manager_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_manager", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_manager """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val inserted_records = manager_inserted.count().toInt //count the number of read records
val read_records = df_manager_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
manager_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)