// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_init_param_range_table 'param_seniority_company' """
stmt.execute(sql)

connection.close()

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.param_seniority_company", connectionproperties).createOrReplaceTempView("vw_param_seniority_company")

// COMMAND ----------

val query_record = """select        distinct                            
                                    range_seniority_company_age
                                   ,range_seniority_company_order
                                   ,range_seniority_company
                                   ,range_seniority_company_min
                                   ,range_seniority_company_max
                                   ,recordcreationdate
                                   ,recordmodificationdate                                 
                                   ,sha2(cast(range_seniority_company_age as string),256) as seniority_company_code
                                   ,sha2(getconcatenedstring(array(s.range_seniority_company)),256) as hashkey
                                   ,'""" + runid + """' as runid
                           
                         
                        from vw_param_seniority_company s
                        where 1=1 
                          and s.range_seniority_company_age is not null and s.range_seniority_company is not null
                             
                           """ 

// COMMAND ----------

val seniority_company_inserted = spark.sql(query_record)
seniority_company_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_seniority_company """
val res = stmt.execute(query_delete)

// COMMAND ----------

seniority_company_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_seniority_company", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_seniority_company """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val inserted_records = seniority_company_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + inserted_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
seniority_company_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)