// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

 if(spark.catalog.tableExists("hr.job_application")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.job_application")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val bycandidates = Window.partitionBy("candidate_id","job_requisition_reference").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_candidates_read = spark.table("hr.job_application").withColumn("rank",rank() over bycandidates)
                                                      .select( "candidate_id" 
                                                              ,"candidate_first_name"
                                                              ,"candidate_last_name" 
                                                              ,"worker_reference"
                                                              ,"job_requisition_reference"
                                                              ,"last_degree_reference"
                                                              ,"version"
                                                              ,"date_raw_load_file"
                                                              ,"filepath"
                                                              ,"filename"
                                                              ,"current_record"
                                                              ,"record_start_date"
                                                              ,"record_end_date"
                                                              ,"record_creation_date"
                                                              ,"record_modification_date"
                                                              ,"curated_ingested_date")
                                                      .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                                                      .distinct
                                                      
df_candidates_read.createOrReplaceTempView("vw_candidates")
df_candidates_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_degree_level", connectionproperties).createOrReplaceTempView("vw_ref_degree_level")

// COMMAND ----------

val query_record = """select  distinct   
                              c.candidate_id as id_candidate
                             ,first(c.candidate_last_name) over (partition by c.candidate_id order by c.record_modification_date desc)  as candidate_last_name
                             ,first(c.candidate_first_name) over (partition by c.candidate_id order by c.record_modification_date desc)  as candidate_first_name
                             ,first(c.worker_reference) over (partition by c.candidate_id order by c.record_modification_date desc)  as matricule_workday
                             ,count(c.job_requisition_reference) over (partition by c.candidate_id order by  c.candidate_id desc) as number_of_jobs_applied
                             ,first(c.last_degree_reference) over (partition by c.candidate_id order by d.degree_level_order desc) as degree_reference
                             ,first(d.degree_level) over (partition by c.candidate_id order by d.degree_level_order desc) as degree_level
                             ,first(d.degree_level_order) over (partition by c.candidate_id order by d.degree_level_order desc) as degree_level_order
                             ,c.candidate_id as candidate_code
                             ,first(c.version) over (partition by c.candidate_id order by c.curated_ingested_date desc)  as version
                             ,first(c.date_raw_load_file) over (partition by c.candidate_id order by c.date_raw_load_file desc)  as date_raw_load_file
                             ,first(c.filepath) over (partition by c.candidate_id order by c.date_raw_load_file desc)  as filepath
                             ,first(c.filename) over (partition by c.candidate_id order by c.date_raw_load_file desc)  as filename
                             ,first(c.curated_ingested_date) over (partition by c.candidate_id order by c.curated_ingested_date desc)  as curated_ingested_date
                             ,first(c.current_record) over (partition by c.candidate_id order by c.record_modification_date desc)  as current_record
                             ,first(c.record_start_date) over (partition by c.candidate_id order by c.record_modification_date desc)  as record_start_date
                             ,first(c.record_end_date) over (partition by c.candidate_id order by c.record_modification_date desc)  as record_end_date
                             ,first(c.record_creation_date) over (partition by c.candidate_id order by c.record_modification_date desc)  as record_creation_date
                             ,first(c.record_modification_date) over (partition by c.candidate_id order by c.record_modification_date desc)  as record_modification_date
                             ,sha2(getconcatenedstring(array(first(c.candidate_last_name) over (partition by c.candidate_id order by c.record_modification_date desc)
                                                            ,first(c.candidate_first_name) over (partition by c.candidate_id order by c.record_modification_date desc)
                                                            ,first(c.last_degree_reference) over (partition by c.candidate_id order by d.degree_level_order desc)
                                                            ,first(d.degree_level) over (partition by c.candidate_id order by d.degree_level_order desc))),256)  as hashkey
                             ,'""" + runid + """' as runid
                         
                        from vw_candidates c
                             left join vw_ref_degree_level d on lower(trim(c.last_degree_reference)) = lower(trim(d.source_value))
                        
                        where 1 = 1
                          and c.candidate_id is not null                           
                       
                           
                      """ 


// COMMAND ----------

val candidates_inserted = spark.sql(query_record)
candidates_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_candidate """
val res = stmt.execute(query_delete)

// COMMAND ----------

candidates_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_candidate", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_candidate """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_candidates_read.count().toInt //count the number of read records
val inserted_records = candidates_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_candidates_read.unpersist
candidates_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)