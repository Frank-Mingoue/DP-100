// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val byemployee_id = Window.partitionBy("employee_id","france_payroll_id").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_employee_read = spark.table("hr.employee").withColumn("rank",rank() over byemployee_id)
                .filter(col("rank")==="1")
                .select(  "employee_id"
                         ,"france_payroll_id"
                         ,"last_name"
                         ,"first_name"
                         ,"birth_name"
                         ,"prefix"
                         ,"gender"
                         ,"birth_date"
                         ,"city_of_birth"
                         ,"department_of_birth"
                         ,"country_of_birth"
                         ,"primary_work_email"
                         ,"primary_home_email"
                         ,"street_number"
                         ,"street_number_extension"
                         ,"street_name"
                         ,"additional_address"
                         ,"postal_code"
                         ,"city"
                         ,"marital_status"
                         ,"marital_status_label"
                         ,"national_identifier"
                         ,"user_name"
                         ,"igi_identification"
                         ,"spouse_first_name"
                         ,"spouse_last_name"
                        ,"special_population"
                         ,"version"
                         ,"date_raw_load_file"
                         ,"filepath"
                         ,"filename"
                         ,"curated_ingested_date"
                         ,"current_record"
                         ,"record_start_date"
                         ,"record_end_date"
                         ,"record_creation_date"
                         ,"record_modification_date")
                  .distinct
df_employee_read.createOrReplaceTempView("vw_employee") // create a temp view
df_employee_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

val query_record = """select                                     
                                    employee_id as matricule_workday
                                   ,e.france_payroll_id as matricule_hra
                                   ,last(e.last_name) as last_name
                                   ,last(e.first_name) as first_name
                                   ,last(e.birth_name) as birth_name
                                   ,last(e.prefix) as prefix
                                   ,last(e.gender) as gender
                                   ,last(e.birth_date) as birth_date
                                   ,last(e.city_of_birth) as city_of_birth
                                   ,last(e.department_of_birth) as department_of_birth
                                   ,last(e.country_of_birth) as country_of_birth
                                   ,last(e.primary_work_email) as primary_work_email
                                   ,last(e.primary_home_email) as primary_home_email
                                   ,last(replace(e.street_number,' ','')) as street_number
                                   ,last(e.street_number_extension) as street_number_extension
                                   ,last(e.street_name) as street_name
                                   ,last(e.additional_address) as additional_address
                                   ,last(e.postal_code) as postal_code
                                   ,last(e.city) as city
                                   ,last(e.marital_status) as marital_status
                                   ,last(e.marital_status_label) as marital_status_label
                                   ,last(e.national_identifier) as national_identifier
                                   ,last(e.user_name) as user_name
                                   ,last(e.igi_identification) as igi_identification
                                   ,last(e.spouse_first_name) as spouse_first_name
                                   ,last(e.spouse_last_name) as spouse_last_name
                                   ,last(e.special_population) as population_particuliere
                                   ,last(e.version) as version
                                   ,last(e.date_raw_load_file) as date_raw_load_file
                                   ,last(e.filepath) as filepath
                                   ,last(e.filename) as filename
                                   ,last(e.curated_ingested_date) as curated_ingested_date
                                   ,last(e.current_record) as current_record
                                   ,last(e.record_start_date) as record_start_date
                                   ,last(e.record_end_date) as record_end_date
                                   ,last(e.record_creation_date) as record_creation_date
                                   ,last(e.record_modification_date) as record_modification_date
                                   ,sha2(getconcatenedstring(array(e.employee_id, e.france_payroll_id)),256) as employee_code
                                   ,sha2(getconcatenedstring(array( last(e.last_name)
                                                                   ,last(e.first_name)
                                                                   ,last(e.birth_name)
                                                                   ,last(e.prefix)
                                                                   ,last(e.gender)
                                                                   ,last(e.birth_date)
                                                                   ,last(e.city_of_birth)
                                                                   ,last(e.department_of_birth)
                                                                   ,last(e.country_of_birth)
                                                                   ,last(e.primary_work_email)
                                                                   ,last(e.primary_home_email)
                                                                   ,last(replace(e.street_number,' ',''))
                                                                   ,last(e.street_number_extension)
                                                                   ,last(e.street_name)
                                                                   ,last(e.additional_address)
                                                                   ,last(e.postal_code)
                                                                   ,last(e.city)
                                                                   ,last(e.marital_status)
                                                                   ,last(e.marital_status_label)
                                                                   ,last(e.national_identifier)
                                                                   ,last(e.user_name)
                                                                   ,last(e.igi_identification)
                                                                   ,last(e.spouse_first_name)
                                                                   ,last(e.spouse_last_name))),256) as hashkey
                                   ,'""" + runid + """' as runid
                         
                        from vw_employee e
                        where 1=1
                        group by 
                                    e.employee_id
                                   ,e.france_payroll_id
                                  """

// COMMAND ----------

val employee_inserted = spark.sql(query_record)
employee_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_employee """
val res = stmt.execute(query_delete)

// COMMAND ----------

employee_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_employee", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_employee """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val inserted_records = employee_inserted.count().toInt //count the number of read records
val read_records = df_employee_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_employee_read.unpersist
employee_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)