// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

if(spark.catalog.tableExists("hr.job_application")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.job_application")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val byjob_application = Window.partitionBy("candidate_id","job_requisition_reference","job_application_date").orderBy($"status_timestamp".desc,$"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc, $"stage_reference".asc )
val df_job_application_read = spark.table("hr.job_application").withColumn("rank",rank() over byjob_application)
                                                               .filter(col("rank")==="1")
                                                               .select("candidate_id"
                                                                       ,"job_requisition_reference"
                                                                       ,"job_application_date"  
                                                                       ,"candidate_response_date"
                                                                       ,"duration_trial_period"
                                                                       ,"validation_trial_period"
                                                                       ,"stage_reference" 
                                                                       ,"status_timestamp"
                                                                       ,"disposition_reference"
                                                                       ,"job_application_code"
                                                                       ,"version"
                                                                       ,"date_raw_load_file"
                                                                       ,"filepath"
                                                                       ,"filename"
                                                                       ,"current_record"
                                                                       ,"record_start_date"
                                                                       ,"record_end_date"
                                                                       ,"record_creation_date"
                                                                       ,"record_modification_date"
                                                                       ,"curated_ingested_date")
                                                               .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                                                               .distinct
df_job_application_read.createOrReplaceTempView("vw_job_application")

// COMMAND ----------

val byjob_application_acceptation_date = Window.partitionBy("candidate_id","job_requisition_reference","job_application_date").orderBy($"status_timestamp".desc,$"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_job_application_acceptation_date_read = spark.table("hr.job_application").filter(lower($"stage_reference") ==="ready for hire")
                                                                                .withColumn("rank",rank() over byjob_application_acceptation_date)
                                                                                .filter(col("rank")==="1")
                                                                                .select( "candidate_id"
                                                                                         ,"job_requisition_reference"
                                                                                         ,"job_application_date" 
                                                                                         ,"candidate_response_date"
                                                                                         ,"duration_trial_period"
                                                                                         ,"validation_trial_period"
                                                                                         ,"stage_reference" 
                                                                                         ,"status_timestamp"
                                                                                         ,"job_application_code")
                                                                                 .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                                                                                 .distinct
df_job_application_acceptation_date_read.createOrReplaceTempView("vw_job_application_acceptation_date")

// COMMAND ----------

val byjob_application_interview_date = Window.partitionBy("candidate_id","job_requisition_reference","job_application_date").orderBy($"status_timestamp".desc,$"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_job_application_interview_date_read = spark.table("hr.job_application").filter(lower($"stage_reference") ==="interview")
                                                                              .withColumn("rank",rank() over byjob_application_interview_date)
                                                                              .filter(col("rank")==="1")
                                                                              .select( "candidate_id"
                                                                                       ,"job_requisition_reference"
                                                                                       ,"job_application_date" 
                                                                                       ,"candidate_response_date"
                                                                                       ,"duration_trial_period"
                                                                                       ,"validation_trial_period"
                                                                                       ,"stage_reference" 
                                                                                       ,"status_timestamp"
                                                                                       ,"job_application_code")
                                                                               .orderBy($"curated_ingested_date",$"record_modification_date",$"date_raw_load_file")
                                                                               .distinct
df_job_application_interview_date_read.createOrReplaceTempView("vw_job_application_interview_date")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_application_status", connectionproperties).createOrReplaceTempView("vw_ref_application_status")
spark.read.jdbc(jdbcurl, "dbo.vw_ref_refusal_reason", connectionproperties).createOrReplaceTempView("vw_ref_refusal_reason")

// COMMAND ----------

val query_record = """select  distinct
                              ja.candidate_response_date
                             ,ad.status_timestamp as candidate_job_acceptation_date                             
                             ,ja.job_application_date
                             ,ja.duration_trial_period
                             ,ja.validation_trial_period
                             ,id.status_timestamp as interview_date
                             ,ja.stage_reference 
                             ,a.application_status
                             ,a.application_status_order
                             ,a.application_status_consolidated
                             ,a.application_status_consolidated_order
                             ,ja.disposition_reference
                             ,r.refusal_reason
                             ,r.refusal_reason_order
                             ,r.refusal_source
                             ,r.refusal_source_order                             
                             ,ja.job_application_code
                             ,ja.version
                             ,ja.date_raw_load_file
                             ,ja.filepath
                             ,ja.filename
                             ,ja.curated_ingested_date
                             ,ja.current_record
                             ,ja.record_start_date
                             ,ja.record_end_date
                             ,record_creation_date
                             ,record_modification_date                                                             
                             ,sha2(getconcatenedstring(array( ja.candidate_response_date
                                                             ,ad.status_timestamp    
                                                             ,ja.duration_trial_period
                                                             ,ja.validation_trial_period
                                                             ,id.status_timestamp
                                                             ,a.application_status
                                                             ,a.application_status_consolidated
                                                             ,ja.disposition_reference
                                                             ,r.refusal_reason
                                                             ,r.refusal_source)),256)  as hashkey
                             ,'""" + runid + """' as runid
                         
                        from vw_job_application ja
                             left join vw_ref_application_status a on lower(trim(ja.stage_reference)) = lower(trim(a.source_value))
                             left join vw_ref_refusal_reason r on lower(trim(ja.disposition_reference)) = lower(trim(r.source_value))
                             left join vw_job_application_acceptation_date ad on ad.job_application_code = ja.job_application_code
                             left join vw_job_application_interview_date id on id.job_application_code = ja.job_application_code
                        where 1 = 1
                          and ja.job_application_date is not null     
                          and ja.stage_reference is not null
                        
                      """ 


// COMMAND ----------

val job_application_inserted = spark.sql(query_record)
job_application_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_job_application """
val res = stmt.execute(query_delete)

// COMMAND ----------

job_application_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_job_application", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_job_application """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_job_application_read.count().toInt //count the number of read records
val inserted_records = job_application_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

df_job_application_read.unpersist
job_application_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)