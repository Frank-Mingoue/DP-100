// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_absence_frequency", connectionproperties).createOrReplaceTempView("vw_param_frequency")

// COMMAND ----------

val query_record = """select distinct
                             range_absence_frequency
                            ,range_absence_frequency_order
                            ,range_absence_frequency_min
                            ,range_absence_frequency_max
                            ,recordcreationdate
                            ,recordmodificationdate
                            ,sha2(cast(range_absence_frequency as string),256) as range_absence_frequency_code
                            ,sha2(getconcatenedstring(array(range_absence_frequency,range_absence_frequency_order)),256) as hashkey
                            ,'""" + runid + """' as runid
                         
                       from vw_param_frequency
                       where range_absence_frequency is not null
                        """

// COMMAND ----------

val absence_frequency_inserted = spark.sql(query_record)
absence_frequency_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_absence_frequency """
val res = stmt.execute(query_delete)

// COMMAND ----------

absence_frequency_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_absence_frequency", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_absence_frequency """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val inserted_records = absence_frequency_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + inserted_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
absence_frequency_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)