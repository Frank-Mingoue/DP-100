// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

 if(spark.catalog.tableExists("hr.pay")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.pay")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val byaction_housing = Window.partitionBy("thematic_action_housing").orderBy($"date_raw_load_file".desc,$"curated_ingested_date".desc,$"record_modification_date".desc,$"record_creation_date".desc)
val df_action_housing_read = spark.table("hr.housing_action").withColumn("rank",rank() over byaction_housing)
                           .filter(col("rank")==="1")
                           .select(   "thematic_action_housing"
                                     ,"version"
                                     ,"date_raw_load_file"
                                     ,"filepath"
                                     ,"filename"
                                     ,"current_record"
                                     ,"record_start_date"
                                     ,"record_end_date"
                                     ,"record_creation_date"
                                     ,"record_modification_date"
                                     ,"curated_ingested_date")
                          .distinct

df_action_housing_read.createOrReplaceTempView("vw_d_action_housing")
df_action_housing_read.cache()  //put the dataframe ont he cache


// COMMAND ----------

val query_record = """select 
                                    ah.thematic_action_housing as action_housing
                                   ,last(ah.version) as version
                                   ,last(ah.date_raw_load_file) as date_raw_load_file
                                   ,last(ah.filepath) as filepath
                                   ,last(ah.filename) as filename
                                   ,last(ah.curated_ingested_date) as curated_ingested_date
                                   ,last(ah.current_record) as current_record
                                   ,last(ah.record_start_date) as record_start_date
                                   ,last(ah.record_end_date) as record_end_date
                                   ,last(ah.record_creation_date) as record_creation_date
                                   ,last(ah.record_modification_date) as record_modification_date
                                   ,sha2(ah.thematic_action_housing, 256) as action_housing_code
                                   ,sha2(last(ah.thematic_action_housing),256)  as hashkey
                                   ,'""" + runid + """' as runid
                         
                        from vw_d_action_housing ah
                        
                        where 1 = 1
                          and (ah.thematic_action_housing is not null)
                          
                        group by   
                               ah.thematic_action_housing
                        """ 

// COMMAND ----------

val action_housing_inserted = spark.sql(query_record)
action_housing_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_action_housing """
val res = stmt.execute(query_delete)

// COMMAND ----------

action_housing_inserted.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_action_housing", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_action_housing"""
stmt.execute(sql)

connection.close()

// COMMAND ----------

val read_records = df_action_housing_read.count().toInt //count the number of read records
val inserted_records =action_housing_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_action_housing_read.unpersist
action_housing_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)