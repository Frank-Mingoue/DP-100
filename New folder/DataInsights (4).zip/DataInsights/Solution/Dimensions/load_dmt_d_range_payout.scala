// Databricks notebook source
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.vw_ref_range_payout", connectionproperties).createOrReplaceTempView("vw_param_payout")

// COMMAND ----------

val query_record = """select distinct
                             range_payout_percent
                            ,range_payout
                            ,range_payout_order
                            ,range_payout_min
                            ,range_payout_max
                            ,recordcreationdate
                            ,recordmodificationdate
                            ,sha2(cast(range_payout_percent as string),256) as range_payout_code
                            ,sha2(cast(array( range_payout)as string),256) as hashkey
                            ,'""" + runid + """' as runid
                         
                        from vw_param_payout
                        where range_payout_percent is not null and range_payout is not null
                        """

// COMMAND ----------

val range_payout_inserted = spark.sql(query_record)
range_payout_inserted.cache()  //put the dataframe ont he cache

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table staging.stg_d_range_payout """
val res = stmt.execute(query_delete)

// COMMAND ----------

range_payout_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "staging.stg_d_range_payout", connectionproperties)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql = """ exec usp_merge_d_range_payout """
stmt.execute(sql)

connection.close()

// COMMAND ----------

val inserted_records = range_payout_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + inserted_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
range_payout_inserted.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)