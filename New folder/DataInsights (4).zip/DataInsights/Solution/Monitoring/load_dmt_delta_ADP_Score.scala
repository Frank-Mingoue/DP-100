// Databricks notebook source
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// MAGIC %run /DataInsights/1-Raw/get_file_structure

// COMMAND ----------

// DBTITLE 1,Set variables
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Truncate table
val connection = getSQLconnection()
val stmt = connection.createStatement()
val truncate = """ TRUNCATE TABLE monitoring.data_quality_paie_details """


stmt.execute(truncate)


// COMMAND ----------

// DBTITLE 1,Get last adp file
// MAGIC %python
// MAGIC 
// MAGIC source_path_score = "/mnt/raw_container/adp/adp_paie"
// MAGIC 
// MAGIC def get_csv_files(source_path_score):
// MAGIC   """recursively list path of all csv files in path directory """
// MAGIC   csv_files = []
// MAGIC   files_to_treat = dbutils.fs.ls(source_path_score)
// MAGIC   #print (files_to_treat)
// MAGIC 
// MAGIC   while files_to_treat:
// MAGIC     path = files_to_treat.pop(0).path
// MAGIC     #print ("Path : " + path)
// MAGIC     if path.endswith('/'):
// MAGIC       files_to_treat += dbutils.fs.ls(path)
// MAGIC     elif path.endswith('.csv'):
// MAGIC       csv_files.append(path)
// MAGIC   return csv_files
// MAGIC 
// MAGIC get_csv_files(source_path_score)
// MAGIC 
// MAGIC 
// MAGIC last_adp_file = get_csv_files(source_path_score).pop() #Get last adp file
// MAGIC 
// MAGIC before_last_adp_file = get_csv_files(source_path_score).pop(len(get_csv_files(source_path_score))-2) #Get before last adp file
// MAGIC 
// MAGIC Folder_of_last_file = last_adp_file[0:48] #Get day folder of the last adp file
// MAGIC 
// MAGIC Folder_of_before_last_file = before_last_adp_file[0:48]
// MAGIC 
// MAGIC print(Folder_of_last_file)
// MAGIC 
// MAGIC if Folder_of_last_file == Folder_of_before_last_file:
// MAGIC   print('folder ok')
// MAGIC   spark.conf.set('before_last_adp_file', str(before_last_adp_file))
// MAGIC else :
// MAGIC   print('folder not ok')
// MAGIC   spark.conf.set('before_last_adp_file', str(''))
// MAGIC 
// MAGIC 
// MAGIC print(last_adp_file)
// MAGIC print(before_last_adp_file)
// MAGIC 
// MAGIC spark.conf.set('last_adp_file', str(last_adp_file))

// COMMAND ----------

// DBTITLE 1,Get last score non retro file
// MAGIC %python
// MAGIC 
// MAGIC 
// MAGIC source_path_score = "/mnt/raw_container/score/paie"
// MAGIC 
// MAGIC def get_csv_files(source_path_score):
// MAGIC   """recursively list path of all csv files in path directory """
// MAGIC   csv_files = []
// MAGIC   files_to_treat = dbutils.fs.ls(source_path_score)
// MAGIC   #print (files_to_treat)
// MAGIC 
// MAGIC   while files_to_treat:
// MAGIC     path = files_to_treat.pop(0).path
// MAGIC     #print ("Path : " + path)
// MAGIC     if path.endswith('/'):
// MAGIC       files_to_treat += dbutils.fs.ls(path)
// MAGIC     elif path.endswith('.csv') and "retro" not in path:
// MAGIC       csv_files.append(path)
// MAGIC   return csv_files
// MAGIC 
// MAGIC 
// MAGIC 
// MAGIC last_score_file = get_csv_files(source_path_score).pop() #Get last score paie file not retro
// MAGIC 
// MAGIC print(last_score_file)
// MAGIC 
// MAGIC spark.conf.set('last_score_file', str(last_score_file))

// COMMAND ----------

// DBTITLE 1,Get score file path from Python
var score_file_to_treat = spark.conf.get("last_score_file").substring(5)

var adp_file_to_treat_1 = spark.conf.get("last_adp_file").substring(5)

var adp_file_to_treat_2 = spark.conf.get("before_last_adp_file")

if(!spark.conf.get("before_last_adp_file").equals(""))
{
 adp_file_to_treat_2 = spark.conf.get("before_last_adp_file").substring(5)
}

println(score_file_to_treat)

println(adp_file_to_treat_1)

println(adp_file_to_treat_2)


// COMMAND ----------

// DBTITLE 1,Read CSV Files score et adp
val score_file = spark.read.format("csv")
  .option("header", "true")
  .option("inferSchema", "true")
  .option("delimiter", ";")
  .load(score_file_to_treat)

val adp_file = spark.read.format("csv")
  .option("header", "true")
  .option("inferSchema", "true")
  .option("delimiter", ";")
  .load(adp_file_to_treat_1)

// Remplacement des , par des .
val sum_score= score_file.withColumn("MONTANT_UPDATED", regexp_replace ($"MONTANT", lit(","),lit(".")))
                .agg(sum("MONTANT_UPDATED") as "montant_score").head().getDouble(0)


//remplacement des null par des 0
val sum_adp_1 = adp_file.withColumn("MONTANT PATRONAL UPDATED", when($"MONTANT PATRONAL".isNull, 0).otherwise($"MONTANT PATRONAL"))
                      .withColumn("MONTANT SALARIAL UPDATED", when($"MONTANT SALARIAL".isNull, 0).otherwise($"MONTANT SALARIAL"))
                      .withColumn("Sum_ADP", $"MONTANT PATRONAL UPDATED" + $"MONTANT SALARIAL UPDATED")

// Sum du montant du fichier adp pour les comptes comptables 6
val result_sum_adp = sum_adp_1.filter(substring(col("COMPTE_COMPTABLE"),1,1) === "6")
                            .agg(sum("Sum_ADP") as "Montant_adp")

var final_result_adp_score = result_sum_adp.withColumn("montant_score", lit(sum_score))

// Nombre de lignes comptes comptables 6 dans le fichier adp
val count_adp = adp_file.filter(substring(col("COMPTE_COMPTABLE"),1,1) === "6")
                        .agg(count("COMPTE_COMPTABLE") as "nb adp")

var sum_adp_union = sum_adp_1

// si il existe 2 fichiers ADP(806931 et 806932)
if(!adp_file_to_treat_2.equals(""))
{
  val adp_file_2 = spark.read.format("csv")
  .option("header", "true")
  .option("inferSchema", "true")
  .option("delimiter", ";")
  .load(adp_file_to_treat_2)
  

  val sum_adp_2 = adp_file_2.withColumn("MONTANT PATRONAL UPDATED", when($"MONTANT PATRONAL".isNull, 0).otherwise($"MONTANT PATRONAL"))
                      .withColumn("MONTANT SALARIAL UPDATED", when($"MONTANT SALARIAL".isNull, 0).otherwise($"MONTANT SALARIAL"))
                      .withColumn("Sum_ADP", $"MONTANT PATRONAL UPDATED" + $"MONTANT SALARIAL UPDATED")
  
  val result_sum_adp_2 = sum_adp_2.filter(substring(col("COMPTE_COMPTABLE"),1,1) === "6")
                            .agg(sum("Sum_ADP") as "Montant_adp")
  
  sum_adp_union = sum_adp_1.unionAll(sum_adp_2)
  
  val final_result_adp1_adp2 = sum_adp_union.filter(substring(col("COMPTE_COMPTABLE"),1,1) === "6")                                            
                                            .agg(sum("Sum_ADP") as "montant_adp")
  
  final_result_adp_score = final_result_adp1_adp2.withColumn("montant_score", lit(sum_score))
  
  display(final_result_adp_score)
}
else
{
  display(final_result_adp_score)
}

final_result_adp_score.cache()

// COMMAND ----------

final_result_adp_score.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","1").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality_paie_sum", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Get Delta between 2 files
val adp = sum_adp_union.withColumn("ADP_rubrique_paie", when($"MONTANT PATRONAL".isNull, concat(col("CODE_RUBR"), lit("S"))).otherwise(concat(col("CODE_RUBR"), lit("P"))))

val updated_score = score_file.withColumn("MONTANT_UPDATED", regexp_replace ($"MONTANT", lit(","),lit(".")))                            

val score_diff = updated_score.as("score").join(adp.as("adp"), $"adp.MATRICULE_WD" === $"score.`MATRICULE WD`" && $"adp.ADP_rubrique_paie" === $"score.`RUBRIQUES DE PAIE`", "leftanti")
                                          .selectExpr("`MATRICULE WD` as matricule_workday",
                                                 "`RUBRIQUES DE PAIE` as rubrique_paie",
                                                 "'Ligne du fichier score non présente dans adp' as anomaly_label")
                                     


val adp_diff = adp.as("adp").join(updated_score.as("score"), $"adp.MATRICULE_WD" === $"score.`MATRICULE WD`" && $"adp.ADP_rubrique_paie" === $"score.`RUBRIQUES DE PAIE`", "leftanti")
                            .selectExpr("MATRICULE_WD as matricule_workday",
                                       "ADP_rubrique_paie as rubrique_paie",
                                       "'Ligne du fichier adp non présente dans score' as anomaly_label")

score_diff.cache()
adp_diff.cache()


// COMMAND ----------

score_diff.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality_paie_details", connectionproperties)

adp_diff.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality_paie_details", connectionproperties)

// COMMAND ----------

val inserted_records_score = score_diff.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "inserted_records:" + inserted_records_score + ";rejected_records:" + 0

// COMMAND ----------

val inserted_records = adp_diff.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

dbutils.notebook.exit(return_value)