// Databricks notebook source
dbutils.widgets.text("date_filter", "20220731");

val date_filter = dbutils.widgets.get("date_filter");

// COMMAND ----------

// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// MAGIC %run /DataInsights/1-Raw/get_file_structure

// COMMAND ----------

// DBTITLE 1,Set variables
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Call Datamart Tables
spark.read.jdbc(jdbcurl, "staff.d_employee", connectionproperties).select("employee_id","matricule_workday", "first_name", "last_name","hashkey","current_version","start_date","end_date").createOrReplaceTempView("vw_d_employee")
spark.read.jdbc(jdbcurl, "staff.f_staff_monthly", connectionproperties).filter("date_id = " + date_filter).select("date_id","employee_id").createOrReplaceTempView("vw_f_staff")

// COMMAND ----------

// DBTITLE 1,Get last effectif file
// MAGIC %python
// MAGIC 
// MAGIC source_path_score_effectif = "/mnt/raw_container/score/effectif"
// MAGIC 
// MAGIC def get_csv_files(source_path_score_effectif):
// MAGIC   """recursively list path of all csv files in path directory """
// MAGIC   csv_files = []
// MAGIC   files_to_treat = dbutils.fs.ls(source_path_score_effectif)  
// MAGIC 
// MAGIC   while files_to_treat:
// MAGIC     path = files_to_treat.pop(0).path
// MAGIC     if path.endswith('/'):
// MAGIC       files_to_treat += dbutils.fs.ls(path)
// MAGIC     elif path.endswith('.csv'):
// MAGIC       csv_files.append(path)
// MAGIC   return csv_files
// MAGIC 
// MAGIC get_csv_files(source_path_score_effectif)
// MAGIC 
// MAGIC 
// MAGIC last_effectif_file = get_csv_files(source_path_score_effectif).pop() #Get last effective file
// MAGIC 
// MAGIC print(last_effectif_file)
// MAGIC 
// MAGIC spark.conf.set('last_effectif_file', str(last_effectif_file))

// COMMAND ----------

// DBTITLE 1,Get score file path from Python
var score_file_to_treat = spark.conf.get("last_effectif_file").substring(5)


println(score_file_to_treat)

// COMMAND ----------

// DBTITLE 1,Connection to Database
val connection = getSQLconnection()
val stmt = connection.createStatement()

val truncate1 = """ TRUNCATE TABLE monitoring.data_quality_effectif_details """
val truncate2 = """ TRUNCATE TABLE monitoring.data_quality_effectif_sum """
stmt.execute(truncate1)
stmt.execute(truncate2)

val sql = " SELECT effectif, effectif_etp_productive, effectif_etp_contractuel FROM  staff.f_staff_monthly WHERE date_id = " + date_filter

val result = stmt.executeQuery(sql)

println(result)

var sum_effectif = 0.0
var sum_etp_productive = 0.0
var sum_etp_contractuel = 0.0

var i = 0

while (result.next){
  sum_effectif = sum_effectif + result.getDouble("effectif")
  sum_etp_productive = sum_etp_productive + result.getDouble("effectif_etp_productive")
  sum_etp_contractuel = sum_etp_contractuel + result.getDouble("effectif_etp_contractuel")
  
  i = i + 1
}

println("Somme effectif : " + sum_effectif)
println("Somme etp productive : " +sum_etp_productive)
println("Somme etp contractuel : " +sum_etp_contractuel)
println("number of rows : " + i)

// COMMAND ----------

// DBTITLE 1,Read effectif CSV File
val score_effectif_file = spark.read.format("csv")
  .option("header", "true")
  .option("inferSchema", "true")
  .option("delimiter", ";")
  .load(score_file_to_treat)


val score_effectif_file_updated = score_effectif_file.withColumn("ETP_CONTRACTUEL_DOUBLE", regexp_replace ($"`ETP CONTRACTUEL`", lit(","),lit(".")))
                                                     .withColumn("ETP_PRODUCTIVE_DOUBLE", regexp_replace ($"`ETP PRODUCTIVE`", lit(","),lit(".")))
                                                     .withColumn("EFFECTIF_TETE_UPDATED", regexp_replace ($"`EFFECTIF TETE`", lit(","),lit(".")))
                                                     .agg(sum("ETP_CONTRACTUEL_DOUBLE") * 100 as "file_etp_contractuel", sum("ETP_PRODUCTIVE_DOUBLE") * 100 as "file_etp_productive",
                                                          sum("EFFECTIF_TETE_UPDATED") as "file_effectif_tete")

val score_effectif_file_Mat = score_effectif_file.withColumn("MATRICULE_WD", regexp_replace ($"`MATRICULE WD`", lit(","),lit(".")))
                                                     .withColumn("ETP_CONTRACTUEL_DOUBLE", regexp_replace ($"`ETP CONTRACTUEL`", lit(","),lit(".")))
                                                     .withColumn("ETP_PRODUCTIVE_DOUBLE", regexp_replace ($"`ETP PRODUCTIVE`", lit(","),lit(".")))
                                                     .withColumn("EFFECTIF_TETE_UPDATED", regexp_replace ($"`EFFECTIF TETE`", lit(","),lit(".")))
                                                     .drop($"MATRICULE WD")
                                                     .drop($"ETP CONTRACTUEL")
                                                     .drop($"ETP PRODUCTIVE")
                                                     .drop($"EFFECTIF TETE")
                                                     .drop($"ETP ABSENCE")
                                                     .drop($"PERIODE")

score_effectif_file_Mat.createOrReplaceTempView("score_effectif_file_Mat")
                                                      

val final_result_effectif = score_effectif_file_updated.withColumn("SQL_etp_contractuel", lit(sum_etp_contractuel))
                                                       .withColumn("SQL_etp_productive", lit(sum_etp_productive))
                                                       .withColumn("SQL_effective_tete", lit(sum_effectif))


display(final_result_effectif)

final_result_effectif.cache()

// récupération des matricules WD 

val file_effectif_matricule_wd = score_effectif_file.select("`MATRICULE WD`").distinct.map(row => row.mkString(" ")).collect//.show()


var matricule_wd = ""

for(r <- file_effectif_matricule_wd)
{
  
  matricule_wd = matricule_wd + "'" + r + "', "
  
}

matricule_wd = matricule_wd.dropRight(2)

//println("resultat : " + matricule_wd)
//display(file_effectif_matricule_wd)



// COMMAND ----------

// DBTITLE 1,Insert agg data
final_result_effectif.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality_effectif_sum", connectionproperties)

// COMMAND ----------

val inserted_records = final_result_effectif.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Insert delta data
if(!matricule_wd.equals(""))
{
    val sql_insert_delta = """ INSERT INTO monitoring.data_quality_effectif_details 
                      SELECT m.employee_id as employee_id, matricule_workday,first_name, last_name,  effectif, effectif_etp_productive, effectif_etp_contractuel, 'Absent dans le fichier effectif paie' as anomaly_label 
                      FROM staff.f_staff_monthly m
                      LEFT JOIN [staff].[d_employee] e
                      ON m.employee_id = e.employee_id 
                      WHERE date_id = """ + date_filter + """
                      AND matricule_workday not in (""" + matricule_wd + """)"""


    val result_insert_delta = stmt.execute(sql_insert_delta)
}

// COMMAND ----------

// DBTITLE 1,Data present in CSV file but missing from table
val sql_insert_delta_csv = """ select max(e.employee_id) employee_id, 
       matricule_workday,
       first_name, 
       last_name,  
       EFFECTIF_TETE_UPDATED as effectif, 
       ETP_PRODUCTIVE_DOUBLE * 100 as effectif_etp_productive, 
       ETP_CONTRACTUEL_DOUBLE * 100 as effectif_etp_contractuel, 
       'Absent de la table effectif' as anomaly_label
from score_effectif_file_Mat m
inner join vw_d_employee e
on m.MATRICULE_WD = e.matricule_workday
where NOT EXISTS (
    SELECT 1
    FROM
        vw_f_staff f 
        inner join vw_d_employee e2
        on e2.employee_id = f.employee_id
        where m.MATRICULE_WD = e2.matricule_workday
)
group by 
matricule_workday,
first_name, 
last_name,  
EFFECTIF_TETE_UPDATED, 
ETP_PRODUCTIVE_DOUBLE,
ETP_CONTRACTUEL_DOUBLE"""

// COMMAND ----------

val sql_insert_delta_csv_results = spark.sql(sql_insert_delta_csv)

// COMMAND ----------

sql_insert_delta_csv_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","1000").jdbc(jdbcurl, "monitoring.data_quality_effectif_details", connectionproperties)

// COMMAND ----------

val inserted_records = sql_insert_delta_csv_results.count().toInt //count the number of inserted records

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from Cache
sql_insert_delta_csv_results.unpersist

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)