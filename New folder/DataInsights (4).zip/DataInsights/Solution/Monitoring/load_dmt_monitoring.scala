// Databricks notebook source
dbutils.widgets.text("load_date", "2021-09-01");
dbutils.widgets.text("runid", "1");
dbutils.widgets.text("limit_date_histo", "2021-01-01");

// COMMAND ----------

// DBTITLE 1,Get Parameters values: load_date and runid
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val limit_date_histo = dbutils.widgets.get("limit_date_histo");

// COMMAND ----------

// DBTITLE 1,Include functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Refresh delta table contract
 if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh delta table employee
 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Set variables
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd")).plusMonths(-1)
val date_end_month = date_value.withDayOfMonth(date_value.lengthOfMonth())
val date_next_month = date_end_month.plusDays(1)
val date_id = date_end_month.toString.replace("-","")
val month_id = date_value.getYear() + ("%02d".format(date_value.getMonth.getValue()))
val date_start_month = date_value.withDayOfMonth(1)
val last_month = date_end_month.plusMonths(-1).getYear() + ("%02d".format(date_end_month.plusMonths(-1).getMonth.getValue()))
val last_month_id = date_end_month.plusMonths(-1).toString.replace("-","") 
val first_month_id = date_value.getYear() + "01"
val last_year_id = date_value.plusYears(-1).getYear()
val month_next_id = date_next_month.getYear() + ("%02d".format(date_next_month.getMonth.getValue()))
val date_end_last_month = date_start_month.plusDays(-1)

val limit_date_value = LocalDate.parse(limit_date_histo, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val filter_file_current_month = if (date_end_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}
val filter_file_previous_month = if (date_end_last_month.isAfter(limit_date_value)) {"%"} else {"histo_file"}

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val sql1 = """ TRUNCATE TABLE monitoring.data_quality """
val sql2 = """ TRUNCATE TABLE monitoring.data_quality_details """
val sql3 = """ TRUNCATE TABLE monitoring.difference_between_contract_and_pay """
stmt.execute(sql1)
stmt.execute(sql2)
stmt.execute(sql3)


connection.close()

// COMMAND ----------

// DBTITLE 1,Cas 1 - Doublons hr.employee
val df_payroll_id_dup =  spark.table("hr.employee")
                          .filter($"employee_id".isNotNull)                      
                          .select("france_payroll_id","employee_id")
                          .distinct

val df_payroll_id_count =  df_payroll_id_dup 
                    .groupBy ("employee_id")
                    .agg(countDistinct("france_payroll_id") as "nb_matricule_paie")
                    .filter(countDistinct("france_payroll_id") > 1)

val windowSpec = Window.partitionBy("c.employee_id").orderBy($"record_start_date".desc)

val df_payroll_id_count_fin =  spark.table("hr.employee").as("c")
                                        .join(df_payroll_id_count.as("e"), $"e.employee_id" === $"c.employee_id")  
                                        .withColumn("rank",row_number.over(windowSpec))
                                        .filter(col("rank") === "1")
                                        .select ( "c.employee_id",
                                                  "c.last_name",
                                                  "c.first_name",
                                                  "e.nb_matricule_paie")
                                        .distinct

val df_contract_payroll_id_join = spark.table("hr.contract").as("c")
                                        .join(df_payroll_id_count_fin.as("e"), $"e.employee_id" === $"c.employee_id")  
                                        .withColumn("rank",row_number.over(windowSpec))
                                        .filter(col("rank") === "1")
                                        .select (
                                                  "e.last_name",
                                                  "e.first_name",
                                                  "c.employee_id",
                                                  //"cast(NULL as smallint) as france_payroll_id",
                                                  "c.contract_type",
                                                  "c.contract_start_date",
                                                  "c.contract_end_date",
                                                  "nb_matricule_paie"
                                                 )
                                        //.sort(asc("c.france_payroll_id"),asc("c.employee_id"),desc("c.contract_start_date"))
                                        .distinct
                                      

val df_payroll_results = df_contract_payroll_id_join.selectExpr ("employee_id",
                                                      "cast(NULL as smallint) as france_payroll_id",
                                                      "first_name",
                                                      "last_name",
                                                      "contract_type",
                                                      "contract_start_date",
                                                      "contract_end_date",
                                                      "nb_matricule_paie as nb_of_duplication",
                                                     "'Doublons matricule paie de la table hr.employee' as anomaly_label")
                                                    .withColumn("last_refresh",date_format(current_date(),"dd-MM-yyy").as("last_refresh"))
                                                    .withColumn("contract_start_date",date_format(col("contract_start_date"), "dd-MM-yyyy").as("contract_start_date"))
                                                    .withColumn("contract_end_date",date_format(col("contract_end_date"), "dd-MM-yyyy").as("contract_end_date"))
//.show()

df_payroll_results.cache()

// COMMAND ----------

df_payroll_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Cas 1 - Doublons hr.contract
val df_payroll_id_dup_ctr =  spark.table("hr.contract")
                          .filter($"employee_id".isNotNull)                      
                          .select("france_payroll_id","employee_id")
                          .distinct

val df_payroll_id_count_ctr =  df_payroll_id_dup_ctr 
                    .groupBy ("employee_id")
                    .agg(countDistinct("france_payroll_id") as "nb_matricule_paie")
                    .filter(countDistinct("france_payroll_id") > 1)

val df_payroll_id_count_fin_ctr =  spark.table("hr.employee").as("e")
                                        .join(df_payroll_id_count_ctr.as("c"), $"e.employee_id" === $"c.employee_id")  
                                        .filter($"e.record_end_date".isNull)
                                        .select ( "e.employee_id",
                                                  "e.last_name",
                                                  "e.first_name",
                                                  "c.nb_matricule_paie")
                                        .distinct

val df_contract_payroll_id_join_ctr = spark.table("hr.contract").as("c")
                                        .join(df_payroll_id_count_fin_ctr.as("e"), $"e.employee_id" === $"c.employee_id")  
                                        .withColumn("rank",row_number.over(windowSpec))
                                        .filter(col("rank") === "1")
                                        .select (
                                                  "e.last_name",
                                                  "e.first_name",
                                                  "c.employee_id",
                                                  //"cast(NULL as smallint) as france_payroll_id",
                                                  "c.contract_type",
                                                  "c.contract_start_date",
                                                  "c.contract_end_date",
                                                  "nb_matricule_paie"
                                                 )
                                        //.sort(asc("c.france_payroll_id"),asc("c.employee_id"),desc("c.contract_start_date"))
                                        .distinct
                                      

val df_payroll_results_contract = df_contract_payroll_id_join_ctr.selectExpr ("employee_id",
                                                      "cast(NULL as smallint) as france_payroll_id",
                                                      "first_name",
                                                      "last_name",
                                                      "contract_type",
                                                      "contract_start_date",
                                                      "contract_end_date",
                                                      "nb_matricule_paie as nb_of_duplication",
                                                     "'Doublons matricule paie de la table hr.contract' as anomaly_label")
                                                    .withColumn("last_refresh",date_format(current_date(),"dd-MM-yyy").as("last_refresh"))
                                                    .withColumn("contract_start_date",date_format(col("contract_start_date"), "dd-MM-yyyy").as("contract_start_date"))
                                                    .withColumn("contract_end_date",date_format(col("contract_end_date"), "dd-MM-yyyy").as("contract_end_date"))
//.show()

df_payroll_results_contract.cache()

// COMMAND ----------

df_payroll_results_contract.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Cas 1 Detail - Doublons hr.employee
val df_payroll_details_results_emp = spark.table("hr.employee").as("c")
                                .join(df_payroll_id_count_fin.as("e"), $"e.employee_id" === $"c.employee_id")
                                .selectExpr(
                                        "e.last_name",
                                        "e.first_name",
                                        "c.employee_id",
                                        "c.france_payroll_id")
                                        .distinct
                                        //.show()

val df_payroll_details_results = spark.table("hr.contract").as("c")
                                .join(df_payroll_details_results_emp.as("e"), $"e.employee_id" === $"c.employee_id")
                                .selectExpr(
                                        "e.last_name",
                                        "e.first_name",
                                        "e.employee_id",
                                        "e.france_payroll_id",
                                        "c.contract_type",
                                        "c.contract_start_date",
                                        "c.contract_end_date",
                                        "'Doublons matricule paie de la table hr.employee' as anomaly_label")
                                        .withColumn("contract_start_date",date_format(col("c.contract_start_date"), "dd-MM-yyyy").as("contract_start_date"))
                                        .withColumn("contract_end_date",date_format(col("c.contract_end_date"), "dd-MM-yyyy").as("contract_end_date"))
                                        .distinct
                                        //.show()
                                
df_payroll_details_results.cache()

// COMMAND ----------

df_payroll_details_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality_details", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Cas 1 Detail - Doublons hr.contract
val df_payroll_details_results_ctr = spark.table("hr.contract").as("c")
                                .join(df_payroll_id_count_fin_ctr.as("e"), $"e.employee_id" === $"c.employee_id")
                                .selectExpr(
                                        "e.last_name",
                                        "e.first_name",
                                        "c.employee_id",
                                        "c.france_payroll_id",
                                        "c.contract_type",
                                        "c.contract_start_date",
                                        "c.contract_end_date",
                                        "'Doublons matricule paie de la table hr.contract' as anomaly_label")
                                        .withColumn("contract_start_date",date_format(col("c.contract_start_date"), "dd-MM-yyyy").as("contract_start_date"))
                                        .withColumn("contract_end_date",date_format(col("c.contract_end_date"), "dd-MM-yyyy").as("contract_end_date"))
                                        .distinct
                                        //.show()
                                
df_payroll_details_results_ctr.cache()

// COMMAND ----------

df_payroll_details_results_ctr.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality_details", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Cas 2 - doublons hr.employee
val df_employee_dup =  spark.table("hr.employee")
                          .filter($"france_payroll_id".isNotNull)                      
                          .select("france_payroll_id","employee_id")
                          .distinct

val df_employee_count =  df_employee_dup 
                    .groupBy ("france_payroll_id")
                    .agg(countDistinct("employee_id") as "nb_matricule_workday")
                    .filter(countDistinct("employee_id") > 1)

val windowSpecPaie = Window.partitionBy("c.france_payroll_id").orderBy($"record_start_date".desc)

val df_workday_id_count_fin =  spark.table("hr.employee").as("c")
                                        .join(df_employee_count.as("e"), $"e.france_payroll_id" === $"c.france_payroll_id")  
                                        .withColumn("rank",row_number.over(windowSpecPaie))
                                        .filter(col("rank") === "1")
                                        .select ( "c.france_payroll_id",
                                                  "c.last_name",
                                                  "c.first_name",
                                                  "e.nb_matricule_workday")
                                        .distinct

val df_contract_join = spark.table("hr.contract").as("c")
                                        .join(df_workday_id_count_fin.as("e"), $"e.france_payroll_id" === $"c.france_payroll_id")  
                                        .withColumn("rank",row_number.over(windowSpecPaie))
                                        .filter(col("rank") === "1")
                                        .select (
                                                  "e.last_name",
                                                  "e.first_name",
                                                  //"c.employee_id",
                                                  "c.france_payroll_id",
                                                  "c.contract_type",
                                                  "c.contract_start_date",
                                                  "c.contract_end_date",
                                                  "nb_matricule_workday"
                                                 )
                                        .distinct
                                        
val df_workday_results = df_contract_join                                        
                                        .selectExpr ("cast(NULL as smallint) as employee_id",
                                                     "france_payroll_id",
                                                     "first_name",
                                                     "last_name",
                                                     "contract_type",
                                                     "contract_start_date",
                                                     "contract_end_date",
                                                     "nb_matricule_workday as nb_of_duplication",
                                                     "'Doublons matricule employé de la table hr.employee' as anomaly_label"
                                                     )
                                                    .withColumn("last_refresh",date_format(current_date(),"dd-MM-yyy").as("last_refresh"))
                                                    .withColumn("contract_start_date",date_format(col("contract_start_date"), "dd-MM-yyyy").as("contract_start_date"))
                                                    .withColumn("contract_end_date",date_format(col("contract_end_date"), "dd-MM-yyyy").as("contract_end_date"))

//.show()
df_workday_results.cache()
                                    

// COMMAND ----------

df_workday_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Cas 2 - Doublons hr.contract
val df_workday_id_dup_ctr =  spark.table("hr.contract")
                          .filter($"france_payroll_id".isNotNull)                      
                          .select("france_payroll_id","employee_id")
                          .distinct

val df_workday_id_count_ctr =  df_workday_id_dup_ctr 
                    .groupBy ("france_payroll_id")
                    .agg(countDistinct("employee_id") as "nb_matricule_workday")
                    .filter(countDistinct("employee_id") > 1)

val df_workday_id_count_fin_ctr =  spark.table("hr.employee").as("e")
                                        .join(df_workday_id_count_ctr.as("c"), $"e.france_payroll_id" === $"c.france_payroll_id")  
                                        .withColumn("rank",row_number.over(windowSpecPaie))
                                        .filter(col("rank") === "1")
                                        .select ( "e.france_payroll_id",
                                                  "e.last_name",
                                                  "e.first_name",
                                                  "c.nb_matricule_workday")
                                        .distinct

val df_contract_workday_id_join_ctr = spark.table("hr.contract").as("c")
                                        .join(df_workday_id_count_fin_ctr.as("e"), $"e.france_payroll_id" === $"c.france_payroll_id")  
                                        .withColumn("rank",row_number.over(windowSpecPaie))
                                        .filter(col("rank") === "1")
                                        .select (
                                                  "e.last_name",
                                                  "e.first_name",
                                                  "c.france_payroll_id",
                                                  "c.contract_type",
                                                  "c.contract_start_date",
                                                  "c.contract_end_date",
                                                  "nb_matricule_workday"
                                                 )
                                        .distinct
                                      

val df_workday_results_contract = df_contract_workday_id_join_ctr.selectExpr ("cast(NULL as smallint) as employee_id",
                                                      "france_payroll_id",
                                                      "first_name",
                                                      "last_name",
                                                      "contract_type",
                                                      "contract_start_date",
                                                      "contract_end_date",
                                                      "nb_matricule_workday as nb_of_duplication",
                                                     "'Doublons matricule employé de la table hr.contract' as anomaly_label")
                                                    .withColumn("last_refresh",date_format(current_date(),"dd-MM-yyy").as("last_refresh"))
                                                    .withColumn("contract_start_date",date_format(col("contract_start_date"), "dd-MM-yyyy").as("contract_start_date"))
                                                    .withColumn("contract_end_date",date_format(col("contract_end_date"), "dd-MM-yyyy").as("contract_end_date"))
//.show()

df_workday_results_contract.cache()

// COMMAND ----------

df_workday_results_contract.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Cas 2 Detail - Doublons hr.employee
val df_workday_details_results_emp = spark.table("hr.employee").as("c")
                                .join(df_workday_id_count_fin.as("e"), $"e.france_payroll_id" === $"c.france_payroll_id")
                                .selectExpr(
                                        "e.last_name",
                                        "e.first_name",
                                        "c.employee_id",
                                        "c.france_payroll_id")
                                        .distinct
                                        //.show()

val df_workday_details_results = spark.table("hr.contract").as("c")
                                .join(df_workday_details_results_emp.as("e"), $"e.france_payroll_id" === $"c.france_payroll_id")
                                .selectExpr(
                                        "e.last_name",
                                        "e.first_name",
                                        "e.employee_id",
                                        "e.france_payroll_id",
                                        "c.contract_type",
                                        "c.contract_start_date",
                                        "c.contract_end_date",
                                        "'Doublons matricule employé de la table hr.employee' as anomaly_label")
                                        .withColumn("contract_start_date",date_format(col("c.contract_start_date"), "dd-MM-yyyy").as("contract_start_date"))
                                        .withColumn("contract_end_date",date_format(col("c.contract_end_date"), "dd-MM-yyyy").as("contract_end_date"))
                                        .distinct
                                        //.show()
                                
df_workday_details_results.cache()

// COMMAND ----------

df_workday_details_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality_details", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Cas 2 Detail - Doublons hr.contract
val df_workday_details_results_ctr = spark.table("hr.contract").as("c")
                                .join(df_workday_id_count_fin_ctr.as("e"), $"e.france_payroll_id" === $"c.france_payroll_id")
                                .selectExpr(
                                        "e.last_name",
                                        "e.first_name",
                                        "c.employee_id",
                                        "c.france_payroll_id",
                                        "c.contract_type",
                                        "c.contract_start_date",
                                        "c.contract_end_date",
                                        "'Doublons matricule employé de la table hr.contract' as anomaly_label")
                                        .withColumn("contract_start_date",date_format(col("c.contract_start_date"), "dd-MM-yyyy").as("contract_start_date"))
                                        .withColumn("contract_end_date",date_format(col("c.contract_end_date"), "dd-MM-yyyy").as("contract_end_date"))
                                        .distinct
                                        //.show()
                                
df_workday_details_results_ctr.cache()

// COMMAND ----------

df_workday_details_results_ctr.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality_details", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Cas 3 - Doublons Contrats Actifs
val windowSpec = Window.partitionBy("c.france_payroll_id", "c.employee_id").orderBy($"record_start_date".desc)

val df_employee = spark.table("hr.employee").as("c")
                          .withColumn("rank",row_number.over(windowSpec))
                          .filter($"france_payroll_id".isNotNull)
                          .filter(col("rank") === "1")                          
                          .select("france_payroll_id",
                                  "employee_id",
                                  "last_name",
                                  "first_name",
                                  "record_start_date",
                                  "record_end_date",
                                  "rank").distinct

val df_contract_join = spark.table("hr.contract").as("c")
                                        .join(df_employee.as("e"), $"e.france_payroll_id" === $"c.france_payroll_id" && $"e.employee_id" === $"c.employee_id" && $"e.record_end_date".isNull)                
                                        .filter($"c.contract_end_date".isNull)                                        
                                        .groupBy ("c.employee_id",
                                                  "c.france_payroll_id",
                                                  "e.last_name",
                                                 "e.first_name"//,
                                                 //"c.contract_type",
                                                 //"c.contract_end_date"
                                                 )
                                        .agg(countDistinct("c.contract_start_date") as "nb_of_actifs_contracts")
                                        .filter(countDistinct("c.contract_start_date") > 1)
                                        //.show()

val df_contract_join_fin = spark.table("hr.contract").as("c")
                                        .join(df_contract_join.as("e"), $"e.france_payroll_id" === $"c.france_payroll_id" && $"e.employee_id" === $"c.employee_id")                
                                        .withColumn("rank",row_number.over(windowSpec))
                                        .filter(col("rank") === "1")                                        
                                        .select  ("c.employee_id",
                                                  "c.france_payroll_id",
                                                  "e.last_name",
                                                  "e.first_name",
                                                  "c.contract_type",
                                                  "c.contract_start_date",
                                                  "c.contract_end_date",
                                                  "nb_of_actifs_contracts"
                                                 )
                                        .distinct

val df_actif_contract_results = df_contract_join_fin.selectExpr ("employee_id",
                                                      "france_payroll_id",
                                                     "first_name",
                                                     "last_name",
                                                      "contract_type",
                                                      "contract_start_date",
                                                      "contract_end_date",
                                                      "nb_of_actifs_contracts as nb_of_duplication",
                                                     "'Doublons contrats actifs' as anomaly_label")
                                                      .withColumn("last_refresh",date_format(current_date(),"dd-MM-yyy").as("last_refresh"))
                                                      .withColumn("contract_start_date",date_format(col("contract_start_date"), "dd-MM-yyyy").as("contract_start_date"))
                                                      .withColumn("contract_end_date",date_format(col("contract_end_date"), "dd-MM-yyyy").as("contract_end_date"))//.show()

df_actif_contract_results.cache()

// COMMAND ----------

df_actif_contract_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Cas 3 Detail - Doublons Contrats Actifs
val df_actifs_contracts_results = spark.table("hr.contract").as("c")
                                .join(df_contract_join.as("e"), $"e.france_payroll_id" === $"c.france_payroll_id" && $"e.employee_id" === $"c.employee_id")
                                .filter($"c.contract_end_date".isNull)
                                .selectExpr(
                                        "e.last_name",
                                        "e.first_name",
                                        "c.employee_id",
                                        "c.france_payroll_id",
                                        "c.contract_type",
                                        "c.contract_start_date",
                                        "c.contract_end_date",
                                        "'Doublons contrats actifs' as anomaly_label")
                                        .withColumn("contract_start_date",date_format(col("c.contract_start_date"), "dd-MM-yyyy").as("contract_start_date"))
                                        .withColumn("contract_end_date",date_format(col("c.contract_end_date"), "dd-MM-yyyy").as("contract_end_date"))
                                        .distinct
                                        //.show()

df_actifs_contracts_results.cache()

// COMMAND ----------

df_actifs_contracts_results.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality_details", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Cas 4 (Matricule de paie absents dans hr.contract)
val windowSpec = Window.partitionBy("c.france_payroll_id", "c.employee_id").orderBy($"c.record_start_date".desc)

val df_employee = spark.table("hr.employee")
                          //.withColumn("rank",row_number.over(windowSpec))
                          .filter($"france_payroll_id".isNotNull)
                          //.filter(col("rank") === "1")                          
                          .select("france_payroll_id",
                                  "employee_id",
                                  "last_name",
                                  "first_name",
                                  "record_start_date",
                                  "record_end_date").distinct


val df_pay = spark.table("hr.pay").select("france_payroll_id").distinct

val payroll_id_list = df_pay.collect.map(x => x(0))

val df_contract_join = spark.table("hr.contract").as("c")
                                        .join(df_employee.as("e"), $"e.france_payroll_id" === $"c.france_payroll_id" && $"e.employee_id" === $"c.employee_id" && $"e.record_end_date".isNull,"leftouter") 
                                        .withColumn("rank",row_number.over(windowSpec))
                                        .filter(col("rank") === "1")
                                        .filter($"c.france_payroll_id".isNotNull)
                                        .filter(!$"c.france_payroll_id".isin(payroll_id_list: _*))
                                        .selectExpr ("c.employee_id",
                                                    "c.france_payroll_id",
                                                    "e.last_name",
                                                    "e.first_name",
                                                    "c.contract_type",
                                                    "c.contract_start_date",
                                                    "c.contract_end_date",
                                                    "cast(null as smallint) as nb_of_duplication",
                                                    "'Matricule de paie hr.contrat absent du référentiel hr.paie' as anomaly_label").distinct
                                                 .withColumn("last_refresh",date_format(current_date(),"dd-MM-yyy").as("last_refresh"))
                                                 .withColumn("contract_start_date",date_format(col("c.contract_start_date"), "dd-MM-yyyy").as("contract_start_date"))
                                                 .withColumn("contract_end_date",date_format(col("c.contract_end_date"), "dd-MM-yyyy").as("contract_end_date"))//.show()
df_contract_join.cache()

// COMMAND ----------

df_contract_join.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Cas 4 (Matricule de paie absents dans hr.employee)
val df_pay = spark.table("hr.pay").select("france_payroll_id").distinct

val payroll_id_list = df_pay.collect.map(x => x(0))

val windowSpec = Window.partitionBy("e.france_payroll_id", "e.employee_id").orderBy($"e.record_start_date".desc)

val df_employee = spark.table("hr.employee").as("e")
                          .join(spark.table("hr.contract").as("c"), $"e.employee_id" === $"c.employee_id" && $"e.france_payroll_id" === $"c.france_payroll_id","leftouter")
                          .withColumn("rank",row_number.over(windowSpec))
                          .filter($"e.france_payroll_id".isNotNull)
                          .filter(col("rank") === "1")
                          .filter(!$"e.france_payroll_id".isin(payroll_id_list: _*))
                          .selectExpr ("e.france_payroll_id",
                                  "e.employee_id",
                                  "e.last_name",
                                  "e.first_name",
                                  "c.contract_type",
                                  "c.contract_start_date",
                                  "c.contract_end_date",
                                  "cast(null as smallint) as nb_of_duplication",
                                  "'Matricule de paie hr.employee absent du référentiel hr.paie' as anomaly_label"
                                  ).distinct
                            .withColumn("last_refresh",date_format(current_date(),"dd-MM-yyy").as("last_refresh"))
                            .withColumn("contract_start_date",date_format(col("c.contract_start_date"), "dd-MM-yyyy").as("contract_start_date"))
                            .withColumn("contract_end_date",date_format(col("c.contract_end_date"), "dd-MM-yyyy").as("contract_end_date"))
                                //.show()
df_employee.cache()

// COMMAND ----------

df_employee.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.data_quality", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Cas 4 (Différence entre les payroll_id entre hr.contract et hr.pay)
val windowSpec = Window.partitionBy("france_payroll_id", "employee_id").orderBy($"record_start_date".desc)

val df_employee = spark.table("hr.employee")
                          .withColumn("rank",row_number.over(windowSpec))
                          .filter($"france_payroll_id".isNotNull)
                          .filter(col("rank") === "1")                          
                          .select("france_payroll_id",
                                  "employee_id",
                                  "last_name",
                                  "first_name",
                                  "record_start_date",
                                  "record_end_date",
                                  "rank").distinct

val df_pay_join = spark.table("hr.pay").as("p")
                                        .join(spark.table("hr.contract").as("c"), $"p.france_payroll_id" =!= $"c.france_payroll_id" && $"p.employee_id" === $"c.employee_id")
                                        .join(df_employee.as("e"), $"e.france_payroll_id" === $"c.france_payroll_id" && $"e.employee_id" === $"c.employee_id" && $"e.record_end_date".isNull )                                       
                                        .selectExpr ("p.employee_id",                                                  
                                                  "e.last_name",
                                                  "e.first_name",
                                                  "c.contract_type",
                                                  "c.contract_start_date",
                                                  "c.contract_end_date",
                                                  "p.france_payroll_id as pay_payroll_id",
                                                  "c.france_payroll_id as contract_payroll_id")
                                        .withColumn("contract_start_date",date_format(col("c.contract_start_date"), "dd-MM-yyyy").as("contract_start_date"))
                                        .withColumn("contract_end_date",date_format(col("c.contract_end_date"), "dd-MM-yyyy").as("contract_end_date"))
                                        .distinct
                                       // .show()
df_pay_join.cache()

// COMMAND ----------

df_pay_join.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","500").option("best_effort","true").jdbc(jdbcurl, "monitoring.difference_between_contract_and_pay", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Statistics about data read and inserted
val inserted_records = df_pay_join.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from Cache
df_pay_join.unpersist
df_employee.unpersist
df_contract_join.unpersist

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)