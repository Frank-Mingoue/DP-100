// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val system_source = dbutils.widgets.get("system_source")

// COMMAND ----------

val dvalue = "2022-03-31"
val system_source = if (load_date <= dvalue) {"hra"} else {"adp"}

// COMMAND ----------

// DBTITLE 1,Include Notebook Containing Common Functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Configuration
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760 ")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Set the table ref_centrecout
val table_ref_centrecout = "organization." + system_source.toLowerCase() + "_ref_centrecout"

// COMMAND ----------

// DBTITLE 1,Refresh table organization ref_centrecout
if(spark.catalog.tableExists(table_ref_centrecout)) 
{
  try {
    spark.sql("MSCK REPAIR TABLE " + table_ref_centrecout)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get last date file organization ref_centrecout loaded for the parameter load_date
val extension = if(system_source.toLowerCase() == "hra"){ "_ref_centrecout" } else { "_ref_centre_cout" }
val path_ref_org = "/organization/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + extension
val partition_ref_centrecout = get_last_partition_file(path_ref_org,load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source after test if it exists and count number of read records
val bycostcenter = Window.partitionBy("centre_cout").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc,$"libelle_centre_cout".desc)
val df_ref_organization_read = spark.table(table_ref_centrecout).filter("date_raw_load_file = '" + partition_ref_centrecout + "'")                                 
                                                                .withColumn("rank",rank() over bycostcenter)
                                                                .filter(col("rank")==="1")
//TDO Rajouter les colonnes pour les frequence de rafraichissement
df_ref_organization_read.cache()  //put the dataframe on the cache
df_ref_organization_read.createOrReplaceTempView("vw_ref_organization") // create a temp view

// COMMAND ----------

// DBTITLE 1,Query to select only organization data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """ select distinct 
                               ro.centre_cout as ref_orga_code
                              ,ro.centre_cout as cost_center_code
                              ,ro.libelle_centre_cout as cost_center_label
                              ,ro.code_departement as code_department
                              ,ro.libelle_departement as label_department
                              ,ro.code_direction as code_direction
                              ,ro.libelle_direction as label_direction
                              ,ro.code_etablissement as code_establishment
                              ,ro.libelle_etablissement as label_establishment
                              ,ro.code_societe as companycode
                              ,ro.libelle_societe as company
                              ,ro.filepath
                              ,ro.version
                              ,ro.date_raw_load_file
                              ,ro.filename
                              ,to_date(ro.curated_ingested_date) as curated_ingested_date
                              ,ro.year_file
                              ,ro.month_file
                              ,ro.day_file
                              ,true as current_hierarchy
                              ,true as current_record
                              ,ro.date_raw_load_file as record_start_date
                              ,null as record_end_date
                              ,current_timestamp() as record_creation_date
                              ,current_timestamp() as record_modification_date
                              ,getconcatenedstring(array(ro.libelle_centre_cout
                                                        ,ro.code_departement
                                                        ,ro.libelle_departement
                                                        ,ro.code_direction
                                                        ,ro.libelle_direction
                                                        ,ro.code_etablissement
                                                        ,ro.libelle_etablissement
                                                        ,ro.code_societe
                                                        ,ro.libelle_societe)) as hashkey 
                              ,'""" + runid + """' as runid
                              ,lower(trim(split(ro.filepath,"/")[3])) as system_source
                              
                        from vw_ref_organization ro
                        
                        where 1=1

"""

// COMMAND ----------

val df_results = spark.sql(query_source).cache

// COMMAND ----------

// DBTITLE 1,Refresh common.ref_organization
if(spark.catalog.tableExists("common.ref_organization")) 
{ 
try {
    spark.sql("FSCK REPAIR TABLE common.ref_organization")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the table job after drop the table if exists and store data and table structure on organization_table
val ref_organization_table = DeltaTable.forName("common.ref_organization")

// COMMAND ----------

// DBTITLE 1,Rows for organization updated
val ref_neworganization = df_results.as("ref_organization_updated")
  .join(ref_organization_table.toDF.as("ref_organization"), Seq("ref_orga_code"))
  .where("""ref_organization.current_record = true and (ref_organization_updated.hashkey<>ref_organization.hashkey) and ref_organization_updated.date_raw_load_file >= ref_organization.date_raw_load_file """)

// COMMAND ----------

// DBTITLE 1,Union of dataframes between ref organization updated from existing organization and new organization 
// Stage the update by unioning two sets of rows
// 1. Rows that will be inserted in the `whenNotMatched` clause
// 2. Rows that will either UPDATE the current contracts of existing employees or insert the new contracts of new employees
val ref_organization_upsert = ref_neworganization
  .selectExpr("null as mergekey", "ref_organization_updated.*")   // Rows for 1.
  .union(
    df_results.as("df_results").selectExpr("df_results.ref_orga_code as mergekey", "*")  // Rows for 2.
  )
//remove duplicate
val ref_organization_upsert_distinct = ref_organization_upsert.distinct()
//display(organization_upsert_distinct)

// COMMAND ----------

// DBTITLE 1,Merge on table ref organization
ref_organization_table.alias("t")
  .merge(
    ref_organization_upsert_distinct.alias("s"),
    """ t.ref_orga_code = s.mergekey """)
  .whenMatched("""t.current_record = true and (t.hashkey <> s.hashkey) and  s.date_raw_load_file >= t.date_raw_load_file""")
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "case when date_add(s.record_start_date,-1)< t.record_start_date then t.record_start_date else date_add(s.record_start_date,-1) end ",
    "record_modification_date" -> "s.record_modification_date",
    "runid" -> "s.runid",
    "current_hierarchy" -> "false")
  )
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE common.ref_organization")

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_ref_organization_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val inserted_records = df_results.count().toInt //count the number of records to upsert
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_ref_organization_read.unpersist
df_results.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update common.ref_organization 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)