// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val system_source = dbutils.widgets.get("system_source")

// COMMAND ----------

val dvalue = "2022-03-31"
val system_source = if (load_date <= dvalue) {"hra"} else {"adp"}

// COMMAND ----------

// DBTITLE 1,Include notebook containing common functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Notebook Configuration
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Set Up default values
val defaultStartDate = LocalDate.parse("2015-01-01", DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val defaultEndDate = LocalDate.parse("2999-12-31", DateTimeFormatter.ofPattern("yyyy-MM-dd"))

// COMMAND ----------

// DBTITLE 1,Refresh table employee.get_workers
if(spark.catalog.tableExists("employee.get_workers")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.get_workers")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Employee Workday
val byemployeewd = Window.partitionBy("cost_center_code").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_employeewd_read = spark.table("employee.get_workers")
                  .filter("date_raw_load_file = '" + load_date + "'")
                  .withColumn("rank",rank() over byemployeewd)
                  .filter(col("rank")==="1")
                  .withColumn("cost_center_key",lpad($"cost_center_code",10,"0"))
                  .select("cost_center_code"
                           ,"cost_center_name"
                           ,"company_id"
                           ,"company"
                           ,"business_line_reference"
                           ,"business_line_name"
                           ,"cost_center_key"
                           ,"filepath"
                           ,"version"
                           ,"date_raw_load_file"
                           ,"filename"
                           ,"curated_ingested_date").distinct   //read parquet file

//put the dataframe ont he cache
df_employeewd_read.cache() 

df_employeewd_read.createOrReplaceTempView("vw_employeewd")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.sap_cc
if(spark.catalog.tableExists("organization.sap_cc")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE organization.sap_cc")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get last date file sap loaded for the parameter load_date
val partition_sap = get_last_partition_file("/organization/sap/sap_cc",load_date, "curated")

// COMMAND ----------

// DBTITLE 1,Cost Center SAP
val bycostcentersap = Window.partitionBy("costcentercode").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_costcentersap_read = spark.table("organization.sap_cc")
                                  .filter("date_raw_load_file = '" + partition_sap + "'")
                                  .withColumn("rank",rank() over bycostcentersap)
                                  .filter(col("rank")==="1")
                                  .withColumn("cost_center_key",lpad($"costcentercode",10,"0"))
                                  .distinct    //read parquet file
df_costcentersap_read.cache()  //put the dataframe ont he cache
df_costcentersap_read.createOrReplaceTempView("vw_costcentersap")

// COMMAND ----------

// DBTITLE 1,Set the table centrecout
val table_centrecout = "organization." + system_source.toLowerCase() + "_centrecout"

// COMMAND ----------

// DBTITLE 1,Refresh table organization centrecout
if(spark.catalog.tableExists(table_centrecout)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_centrecout)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get last date file centre_cout loaded for the parameter load_date
val path_org = "/organization/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + "_centrecout"
val partition_centrecout = get_last_partition_file(path_org,load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Set the table ref_centrecout
val table_ref_centrecout = "organization." + system_source.toLowerCase() + "_ref_centrecout"

// COMMAND ----------

// DBTITLE 1,Refresh table organization ref_centrecout
if(spark.catalog.tableExists(table_ref_centrecout)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_ref_centrecout)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get last date file organization ref_centrecout loaded for the parameter load_date
val extension = if(system_source.toLowerCase() == "hra"){ "_ref_centrecout" } else { "_ref_centre_cout" }
val path_ref_org = "/organization/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + extension
val partition_ref_centrecout = get_last_partition_file(path_ref_org,load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Refresh table organization.organisation_chanel_italie
//TODO: change source table in common folder
if(spark.catalog.tableExists("organization.organisation_chanel_italie")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE organization.organisation_chanel_italie")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get last date file chanel_italy loaded for the parameter load_date
val partition_chanel_italy= get_last_partition_file("/organization/business/organisation_chanel_italie",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Cost Center HRA - Italien

val df_italy = spark.table("organization.organisation_chanel_italie").filter("date_raw_load_file = '" + partition_chanel_italy + "'")
                                                                                                .withColumnRenamed("cost_center_code","centre_cout")
                                                                                                .withColumnRenamed("cost_center_name","libelle_centre_cout")
                                                                                                .withColumnRenamed("niveau_5_departement","libelle_departement")
                                                                                                .withColumnRenamed("niveau_4_direction","libelle_direction")

val df_new_italy = df_italy
                        .withColumn("date_deb_centre_cout",lit(defaultStartDate))
                        .withColumn("date_fin_centre_cout",lit(null))
                        .withColumn("sous_compte",lit(null))
                        .withColumn("taux_repartition",lit(null))
                        .withColumn("date_deb_etablissement",lit(defaultStartDate))
                        .withColumn("date_fin_etablissement",lit(null))
                        .withColumn("code_etablissement",lit(null))
                        .withColumn("libelle_etablissement",when(lower($"niveau_2_division_consolidee") === "camelia" ,lit("Etablissement - Camelia")).otherwise(lit("CHANEL COORDINATION S.R.L. ITALIE")))
                        .withColumn("date_deb_societe",lit(defaultStartDate))
                        .withColumn("date_fin_societe",lit(null))
                        .withColumn("code_societe",lit(null))
                        .withColumn("libelle_societe",lit(null))
                        .withColumn("motif_entree",lit(null))
                        .withColumn("date_deb_org",lit(defaultStartDate))
                        .withColumn("date_fin_org",lit(null))
                        .withColumn("code_direction",$"libelle_direction")
                        .withColumn("code_departement",$"libelle_departement")
                        .withColumn("cost_center_key",lpad($"centre_cout",10,"0"))// add caracter
                        .select("centre_cout"
                                 ,"libelle_centre_cout"
                                 ,"sous_compte"
                                 ,"taux_repartition"
                                 ,"code_etablissement"
                                 ,"libelle_etablissement"
                                 ,"code_societe"
                                 ,"libelle_societe"
                                 ,"code_direction"
                                 ,"libelle_direction"
                                 ,"code_departement"
                                 ,"libelle_departement"
                                 ,"cost_center_key"
                                 ,"date_deb_centre_cout"
                                 ,"date_deb_etablissement"
                                 ,"date_deb_societe"
                                 ,"date_deb_org"
                                 ,"filepath"
                                 ,"version"
                                 ,"date_raw_load_file"
                                 ,"filename"
                                 ,"curated_ingested_date")

// COMMAND ----------

// DBTITLE 1,Cost Center HRA
val bycostcenterhra = Window.partitionBy("centre_cout").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)

val df_costcernterhra_readfirst = spark.table(table_centrecout)


val df_costcenterhra_read = df_costcernterhra_readfirst
                                 .filter("date_raw_load_file = '" + partition_centrecout + "'")                                 
                                 .withColumn("rank",rank() over bycostcenterhra)
                                 .filter(col("rank")==="1")
                                 .withColumn("cost_center_key",lpad($"centre_cout",10,"0"))// add caracter
                                 .select(
                                          "centre_cout"
                                         ,"libelle_centre_cout"
                                         ,"sous_compte"
                                         ,"taux_repartition"
                                         ,"code_etablissement"
                                         ,"libelle_etablissement"
                                         ,"code_societe"
                                         ,"libelle_societe"
                                         ,"code_direction"
                                         ,"libelle_direction"
                                         ,"code_departement"
                                         ,"libelle_departement"
                                         ,"cost_center_key"
                                         ,"date_deb_centre_cout"
                                         ,"date_deb_etablissement"
                                         ,"date_deb_societe"
                                         ,"date_deb_org"
                                         ,"filepath"
                                         ,"version"
                                         ,"date_raw_load_file"
                                         ,"filename"
                                         ,"curated_ingested_date").distinct //read parquet file
val df_new_hra_centre_cout = df_costcenterhra_read.union(df_new_italy)

df_new_hra_centre_cout.cache()  //put the dataframe ont he cache
df_new_hra_centre_cout.createOrReplaceTempView("vw_costcenterhra")  
//display(df_costcenterhra_read)

// COMMAND ----------

// DBTITLE 1,Last Hierarchy
val bycostcenterhra_last_hier = Window.partitionBy("centre_cout").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc, $"date_deb_centre_cout".desc,$"date_deb_etablissement".desc,$"date_deb_societe".desc,$"date_deb_org".desc,$"sous_compte".desc,$"taux_repartition")
val df_costcenterhra_last_hier_read = df_new_hra_centre_cout
                                 .withColumn("rank",rank() over bycostcenterhra_last_hier)
                                 //.filter(col("rank")==="1")
                                 .withColumn("cost_center_key",lpad($"centre_cout",10,"0"))
                                 .withColumn("current_hierarchy",when($"rank" === 1,lit(true)))
                                 .select(
                                         "centre_cout"
                                         ,"libelle_centre_cout"
                                         ,"sous_compte"
                                         ,"taux_repartition"
                                         ,"code_etablissement"
                                         ,"libelle_etablissement"
                                         ,"code_societe"
                                         ,"libelle_societe"
                                         ,"code_direction"
                                         ,"libelle_direction"
                                         ,"code_departement"
                                         ,"libelle_departement"
                                         ,"cost_center_key"
                                         ,"date_deb_centre_cout"
                                         ,"current_hierarchy"
                                         ,"filepath"
                                         ,"version"
                                         ,"date_raw_load_file"
                                         ,"filename"
                                         ,"curated_ingested_date"
                                 ).distinct //read parquet file
df_costcenterhra_last_hier_read.cache()  //put the dataframe ont he cache
df_costcenterhra_last_hier_read.createOrReplaceTempView("vw_costcenterhra_last_hier")  

// COMMAND ----------

// DBTITLE 1,Ref_Cost_Center
val byrefcostcenterhra = Window.partitionBy("centre_cout").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)

val df_ref_costcernterhra_readfirst = spark.table(table_ref_centrecout)


val df_ref_costcenterhra_read = df_ref_costcernterhra_readfirst
                                 .filter("date_raw_load_file = '" + partition_ref_centrecout + "'")                                 
                                 .withColumn("rank",rank() over byrefcostcenterhra)
                                 .filter(col("rank")==="1")
                                 .withColumn("cost_center_key",lpad($"centre_cout",10,"0"))// add caracter
                                 .withColumn("current_hierarchy_ref", lit(true))
                                 .select(
                                          "centre_cout"
                                         ,"libelle_centre_cout"
                                         ,"code_etablissement"
                                         ,"libelle_etablissement"
                                         ,"code_societe"
                                         ,"libelle_societe"
                                         ,"code_direction"
                                         ,"libelle_direction"
                                         ,"code_departement"
                                         ,"libelle_departement"
                                         ,"cost_center_key"
                                         ,"filepath"
                                         ,"version"
                                         ,"date_raw_load_file"
                                         ,"filename"
                                         ,"curated_ingested_date"
                                         ,"current_hierarchy_ref").distinct //read parquet file


df_ref_costcenterhra_read.cache()  //put the dataframe ont he cache
df_ref_costcenterhra_read.createOrReplaceTempView("vw_ref_costcenterhra")  
//display(df_costcenterhra_read)

// COMMAND ----------

// DBTITLE 1,Get all cost center from employee workday and ref_centrecout
val df_cost_center_all =  df_employeewd_read.select("cost_center_key","cost_center_code").union(df_ref_costcenterhra_read.select("cost_center_key","centre_cout")).distinct

// COMMAND ----------

// DBTITLE 1,Build the hierarchy
val df_join =  df_cost_center_all.as("a")
              .join(df_employeewd_read.as("e"),$"a.cost_center_key" === $"e.cost_center_key", "left_outer")
              .join(df_costcentersap_read.as("c"), $"a.cost_center_key" === $"c.cost_center_key", "left_outer")
              .join(df_ref_costcenterhra_read.as("r"), $"a.cost_center_key" === $"r.cost_center_key", "left_outer")
              .join(df_costcenterhra_last_hier_read.as("o"), $"a.cost_center_key" === $"o.cost_center_key", "left_outer")
              .selectExpr(
                      "a.cost_center_code"
                     ,"a.cost_center_key"
                     ,"coalesce(r.centre_cout, e.cost_center_code, o.centre_cout, c.costcentercode) as cost_center_code_key"
                     ,"coalesce(c.costcentername, e.cost_center_name, r.libelle_centre_cout, o.libelle_centre_cout) as cost_center_label"
                     ,"coalesce(r.code_societe, e.company_id, o.code_societe) as company_code"
                     ,"coalesce(r.libelle_societe, e.company, o.libelle_societe) as company_label"

                     ,"c.centertype"
                     ,"c.marketsegment"
                     ,"c.activitydomain"
                     ,"c.standardcostcenter"
                     ,"c.essbasefunction"
                     ,"c.profitcenter"
                
                     ,"coalesce(r.code_etablissement, o.code_etablissement) as code_etablissement"
                     ,"coalesce(r.libelle_etablissement, o.libelle_etablissement) as libelle_etablissement"
                     ,"coalesce(r.code_direction, o.code_direction) as code_direction"
                     ,"coalesce(r.libelle_direction, o.libelle_direction) as libelle_direction"
                     ,"coalesce(r.code_departement, o.code_departement) as code_departement"
                     ,"coalesce(r.libelle_departement, o.libelle_departement) as libelle_departement"
                     ,"coalesce(r.current_hierarchy_ref, o.current_hierarchy) as current_hierarchy"
                
                     ,"coalesce(e.filepath, r.filepath) as filepath"
                     ,"coalesce(e.version, r.version) as version"
                     ,"coalesce(e.date_raw_load_file, r.date_raw_load_file) as date_raw_load_file"
                     ,"coalesce(e.filename, r.filename) as filename"
                     ,"coalesce(e.curated_ingested_date, r.curated_ingested_date) as curated_ingested_date"
                
              ).distinct

df_join.createOrReplaceTempView("vw_emp_orga") 

// COMMAND ----------

// DBTITLE 1,Get the business line
val df_business_line = df_employeewd_read.as("e")
              .select(
                      "e.cost_center_code"
                     ,"e.cost_center_name"
                     ,"e.business_line_reference"
                     ,"e.business_line_name"
             ).distinct
df_business_line.createOrReplaceTempView("vw_emp_business_line") 

// COMMAND ----------

// DBTITLE 1,Refresh table Organization Hierarchy_pb
if(spark.catalog.tableExists("organization.hierarchy_pb")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE organization.hierarchy_pb")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get last date file hierarchy pb loaded for the parameter load_date
val partition_date_hierarchy_pb = get_last_partition_file("/organization/business/hierarchy_pb",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Get the hierarchy pb
val df_hierarchy_pb_read = spark.table("organization.hierarchy_pb").filter($"date_raw_load_file"===partition_date_hierarchy_pb)
                                                                   .withColumn("cost_center_key",lpad($"cost_center_code",10,"0"))
                                                                   .distinct
df_hierarchy_pb_read.createOrReplaceTempView("vw_hierarchy_pb")

// COMMAND ----------

// DBTITLE 1,Query to select only organization data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select  distinct
                             getconcatenedstring(array( o.cost_center_code_key
                                                            ,o.company_code
                                                            ,o.code_etablissement
                                                            ,o.code_departement
                                                            ,o.code_direction
                                                            ,l.business_line_reference
                                                            ,l.business_line_name
                                                            )) as orga_code
                            ,o.cost_center_code_key as cost_center_code
                            ,last(o.cost_center_label) as cost_center_label
                            ,last(o.centertype) as centertype
                            ,o.company_code as companycode
                            ,last(o.company_label) as company
                            ,last(o.marketsegment) as marketsegment
                            ,last(o.activitydomain) as activitydomain
                            ,last(o.standardcostcenter) as standardcostcenter
                            ,last(o.essbasefunction) as essbasefunction
                            ,last(o.profitcenter) as profitcenter
                            ,o.code_etablissement as code_establishment
                            ,last(o.libelle_etablissement) as label_establishment
                            ,o.code_direction 
                            ,last(o.libelle_direction) as label_direction
                            ,o.code_departement as code_department
                            ,last(o.libelle_departement ) as label_department
                            ,l.business_line_reference
                            ,l.business_line_name as business_line_name
                            ,last(p.dird_direction_detail_code) as direction_detail_code
                            ,last(p.dird_direction_detail_name) as direction_detail_name
                            ,last(p.dirr_direction_code) as direction_code
                            ,last(p.dirr_direction_name) as direction_name
                            ,last(p.dirb_direction_psb_budget_code) as direction_psb_budget_code
                            ,last(p.dirb_direction_psb_budget_name) as direction_psb_budget_name
                            ,last(p.dirp_direction_presentation_code) as direction_presentation_code
                            ,last(p.dirp_direction_presentation_name) as direction_presentation_name
                            ,last(o.current_hierarchy) as current_hierarchy
                            ,last(o.version) as version
                            ,last(o.date_raw_load_file) as date_raw_load_file
                            ,last(o.filepath) as  filepath
                            ,last(o.filename) as filename
                            ,last(o.curated_ingested_date) as curated_ingested_date
                            ,true as current_record
                            ,last(o.date_raw_load_file) as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(
                                                             last(o.cost_center_label) 
                                                            ,last(o.centertype)
                                                            ,last(o.company_label) 
                                                            ,last(o.marketsegment) 
                                                            ,last(o.activitydomain)
                                                            ,last(o.standardcostcenter) 
                                                            ,last(o.essbasefunction) 
                                                            ,last(o.profitcenter) 
                                                            ,last(o.libelle_etablissement) 
                                                            ,last(o.libelle_direction) 
                                                            ,last(o.libelle_departement)
                                                            ,last(p.dird_direction_detail_code)
                                                            ,last(p.dird_direction_detail_name)
                                                            ,last(p.dirr_direction_code)
                                                            ,last(p.dirr_direction_name)
                                                            ,last(p.dirb_direction_psb_budget_code)
                                                            ,last(p.dirb_direction_psb_budget_name)
                                                            ,last(p.dirp_direction_presentation_code)
                                                            ,last(p.dirp_direction_presentation_name)
                                                           )) as hashkey  
                           ,'""" + runid + """' as runid  
                           ,lower(trim(split(last(o.filepath),"/")[3])) as system_source
                           
               from    vw_emp_orga o 
                       left join vw_emp_business_line l on o.cost_center_code = l.cost_center_code
                       left join vw_hierarchy_pb p on o.cost_center_key = p.cost_center_key
                       
               where   1=1
                 and   (o.cost_center_code is not null)  
                 
               group by
                        o.cost_center_code_key
                       ,o.company_code
                       ,o.code_etablissement
                       ,o.code_departement
                       ,o.code_direction
                       ,l.business_line_reference
                       ,l.business_line_name
           """
              

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source).cache
//display(df_results)

// COMMAND ----------

// DBTITLE 1,Refresh table common.organization
if(spark.catalog.tableExists("common.organization")) 
{ 
try {
    spark.sql("FSCK REPAIR TABLE common.organization")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the table job after drop the table if exists and store data and table structure on organization_table
val organization_table = DeltaTable.forName("common.organization")

// COMMAND ----------

// DBTITLE 1,Rows for organization updated
val neworganization = df_results.as("organization_updated")
  .join(organization_table.toDF.as("organization"), Seq("orga_code"))
  .where("""organization.current_record = true and (organization_updated.hashkey<>organization.hashkey) and organization_updated.date_raw_load_file >= organization.date_raw_load_file """)

// COMMAND ----------

// DBTITLE 1,Union of dataframes between organization updated from existing employees and new jobs from new employees
// Stage the update by unioning two sets of rows
// 1. Rows that will be inserted in the `whenNotMatched` clause
// 2. Rows that will either UPDATE the current contracts of existing employees or insert the new contracts of new employees
val organization_upsert = neworganization
  .selectExpr("null as mergekey", "organization_updated.*")   // Rows for 1.
  .union(
    df_results.as("df_results").selectExpr("df_results.orga_code as mergekey", "*")  // Rows for 2.
  )
//remove duplicate
val organization_upsert_distinct = organization_upsert.distinct()
//display(organization_upsert_distinct)

// COMMAND ----------

// DBTITLE 1,Merge on table organization
organization_table.alias("t")
  .merge(
    organization_upsert_distinct.alias("s"),
    """ t.orga_code = s.mergekey """)
  .whenMatched("""t.current_record = true and (t.hashkey <> s.hashkey) and  s.date_raw_load_file >= t.date_raw_load_file""")
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "case when date_add(s.record_start_date,-1)< t.record_start_date then t.record_start_date else date_add(s.record_start_date,-1) end ",
    "record_modification_date" -> "s.record_modification_date",
    "runid" -> "s.runid",
    "current_hierarchy" -> "false")
  )
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Get The Current Hierarchy for all Cost Center Code
df_results.filter($"current_hierarchy" === true)
          .select("cost_center_code"
                 ,"companycode"
                 ,"code_establishment"
                 ,"code_department"
                 ,"code_direction"
                 ,"business_line_reference"
                 ,"business_line_name")
          .distinct
          .createOrReplaceTempView("vw_current_hier_org")

// COMMAND ----------

// DBTITLE 1,Set Current Hierarchy To False for all Cost Center present in the Query
spark.sql("""
update common.organization 
set current_hierarchy = false 
where 1=1 
and cost_center_code in (select cost_center_code from vw_current_hier_org)

""")

// COMMAND ----------

// DBTITLE 1,Set the Current Hierarchy to True for the valid hierarchy of Cost Center present in the file
spark.sql("""
merge into common.organization o1
using vw_current_hier_org o2
on o1.cost_center_code = o2.cost_center_code
and coalesce(o1.companycode,-1) = coalesce(o2.companycode,-1)
and coalesce(o1.code_establishment,-1) = coalesce(o2.code_establishment,-1)
and coalesce(o1.code_department,-1) = coalesce(o2.code_department,-1)
and coalesce(o1.code_direction,-1) = coalesce(o2.code_direction,-1)
and coalesce(o1.business_line_reference, -1) = coalesce(o2.business_line_reference,-1)
and coalesce(o1.business_line_name, -1) = coalesce(o2.business_line_name,-1)
when matched then
  update set o1.current_hierarchy = true        
""")

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE common.organization")

// COMMAND ----------

// DBTITLE 1,Get Statistics
val read_records_employeewd = df_employeewd_read.count().toInt //count the number of read records
val inserted_records = organization_upsert_distinct.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records_employeewd + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_employeewd_read.unpersist
df_costcentersap_read.unpersist
df_costcenterhra_read.unpersist
df_costcenterhra_last_hier_read.unpersist
df_results.unpersist

// COMMAND ----------

spark.sql(""" 
update common.organization 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)