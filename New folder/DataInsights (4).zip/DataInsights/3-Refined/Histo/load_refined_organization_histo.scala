// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include notebook containing common functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Set Default Start Date
val defaultStartDate = LocalDate.parse("2015-01-01", DateTimeFormatter.ofPattern("yyyy-MM-dd"))

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded
val partition_date_cc = get_last_partition_file("/organization/sap/sap_cc",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Refresh table Organization SAP CC
if(spark.catalog.tableExists("organization.sap_cc")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE organization.sap_cc")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Cost Center SAP
val bycostcentersap = Window.partitionBy("costcentercode").orderBy($"filename".desc)
val df_costcentersap_read = spark.table("organization.sap_cc").filter($"date_raw_load_file"===partition_date_cc)
                                  .withColumn("rank",rank() over bycostcentersap)
                                  .filter(col("rank")==="1")
                                  .withColumn("cost_center_key",lpad($"costcentercode",10,"0"))
                                  .distinct    //read parquet file
df_costcentersap_read.cache()  //put the dataframe ont he cache
df_costcentersap_read.createOrReplaceTempView("vw_costcentersap")

// COMMAND ----------

// DBTITLE 1,Get Last partition file loaded

val partition_date_hra = get_last_partition_file("/organization/hra/hra_centrecout",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Update table hra_centrecout
if(spark.catalog.tableExists("organization.hra_centrecout")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE organization.hra_centrecout")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Cost Center HRA
val bycostcenterhra = Window.partitionBy("centre_cout").orderBy($"filename".desc)
val bycostcenterhra_version = Window.partitionBy("centre_cout","code_etablissement","code_societe","code_direction","code_departement").orderBy($"filename".desc, $"date_deb_centre_cout".asc)



val df_costcenterhra_read = spark.table("organization.hra_centrecout").filter($"date_raw_load_file"===partition_date_hra)
                                 .withColumn("rank",rank() over bycostcenterhra)
                                 .withColumn("rank_version",rank() over bycostcenterhra_version)
                                 .filter(col("rank")==="1")
                                 .filter(col("rank_version")==="1")
                                 .withColumn("cost_center_key",lpad($"centre_cout",10,"0"))
                                 .select(
                                          "centre_cout"
                                         ,"libelle_centre_cout"
                                         ,"sous_compte"
                                         ,"taux_repartition"
                                         ,"code_etablissement"
                                         ,"libelle_etablissement"
                                         ,"code_societe"
                                         ,"libelle_societe"
                                         ,"code_direction"
                                         ,"libelle_direction"
                                         ,"code_departement"
                                         ,"libelle_departement"
                                         ,"cost_center_key"
                                         ,"date_deb_centre_cout"
                                         ,"filepath"
                                         ,"version"
                                         ,"date_raw_load_file"
                                         ,"filename"
                                         ,"curated_ingested_date").distinct //read parquet file
df_costcenterhra_read.cache()  //put the dataframe ont he cache
df_costcenterhra_read.createOrReplaceTempView("vw_costcenterhra")  

// COMMAND ----------

// DBTITLE 1,Get Last Hierarchy
val bycostcenterhra_last_hier = Window.partitionBy("centre_cout").orderBy($"filename".desc, $"date_deb_centre_cout".desc)
val endDate = Window.partitionBy("centre_cout").orderBy($"date_deb_centre_cout".asc)

val df_costcenterhra_allversions = df_costcenterhra_read
                                 .withColumn("rank",rank() over bycostcenterhra_last_hier)
                                 .withColumn("cost_center_key",lpad($"centre_cout",10,"0"))
                                 .withColumn("current_hierarchy",when(col("rank") === 1,true).otherwise(false))
                                 .withColumn("date_fin_centre_cout", lead($"date_deb_centre_cout", 1, null).over(endDate) )
                                 .withColumn("date_fin_centre_cout", $"date_fin_centre_cout" - expr("INTERVAL 1 DAYS"))
                                 .select(
                                          "centre_cout"
                                         ,"libelle_centre_cout"
                                         ,"sous_compte"
                                         ,"taux_repartition"
                                         ,"code_etablissement"
                                         ,"libelle_etablissement"
                                         ,"code_societe"
                                         ,"libelle_societe"
                                         ,"code_direction"
                                         ,"libelle_direction"
                                         ,"code_departement"
                                         ,"libelle_departement"
                                         ,"cost_center_key"
                                         ,"date_deb_centre_cout"
                                         ,"date_fin_centre_cout"
                                         ,"current_hierarchy"
                                         ,"filepath"
                                         ,"version"
                                         ,"date_raw_load_file"
                                         ,"filename"
                                         ,"curated_ingested_date").distinct //read parquet file
df_costcenterhra_allversions.cache()  //put the dataframe ont he cache
df_costcenterhra_allversions.createOrReplaceTempView("vw_costcenterhra_last_hier")  

// COMMAND ----------

// DBTITLE 1,Organization join
val df_join = df_costcenterhra_allversions.as("o")
              .join(df_costcentersap_read.as("c"), $"c.cost_center_key" === $"o.cost_center_key", "left_outer")
              .select(
                      "c.costcentercode"
                     ,"c.costcentername"
                     ,"c.companycode"
                     ,"c.company"
                     ,"c.costcentercode"
                     ,"c.costcentername"
                     ,"c.centertype"
                     ,"c.companycode"
                     ,"c.company"
                     ,"c.marketsegment"
                     ,"c.activitydomain"
                     ,"c.standardcostcenter"
                     ,"c.essbasefunction"
                     ,"c.profitcenter"
                     ,"o.centre_cout"
                     ,"o.libelle_centre_cout"
                     ,"o.sous_compte"
                     ,"o.taux_repartition"
                     ,"o.code_etablissement"
                     ,"o.libelle_etablissement"
                     ,"o.code_societe"
                     ,"o.libelle_societe"
                     ,"o.code_direction"
                     ,"o.libelle_direction"
                     ,"o.code_departement"
                     ,"o.libelle_departement"
                     ,"o.current_hierarchy"
                     ,"o.date_deb_centre_cout"
                     ,"o.date_fin_centre_cout"
                     ,"c.filepath"
                     ,"c.version"
                     ,"c.date_raw_load_file"
                     ,"c.filename"
                     ,"c.curated_ingested_date"
                     ,"c.cost_center_key")
              .withColumn("record_start_date",coalesce($"o.date_deb_centre_cout",lit(defaultStartDate)))
              .withColumn("record_end_date",$"o.date_fin_centre_cout")
              .withColumn("cost_center_code_key", coalesce($"o.centre_cout", $"c.costcentercode"))
              .withColumn("cost_center_label", coalesce($"c.costcentername", $"o.libelle_centre_cout"))
              .withColumn("company_code", coalesce($"o.code_societe",$"c.companycode"))
              .withColumn("company_label", coalesce($"o.libelle_societe", $"c.company"))
             
df_join.createOrReplaceTempView("vw_emp_orga") 

// COMMAND ----------

// DBTITLE 1,Refresh Table organization.hierarchy_pb
if(spark.catalog.tableExists("organization.hierarchy_pb")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE organization.hierarchy_pb")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded
val partition_date_hierarchy_pb = get_last_partition_file("/organization/business/hierarchy_pb",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Get Hierarchy PB data
val df_hierarchy_pb_read = spark.table("organization.hierarchy_pb").filter($"date_raw_load_file"===partition_date_hierarchy_pb)
                                                                   .withColumn("cost_center_key",lpad($"cost_center_code",10,"0"))
                                                                   .distinct
df_hierarchy_pb_read.createOrReplaceTempView("vw_hierarchy_pb")

// COMMAND ----------

// DBTITLE 1,Query to select only organization data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select  distinct
                             getconcatenedstring(array( o.cost_center_code_key
                                                            ,o.company_code
                                                            ,o.code_etablissement
                                                            ,o.code_departement
                                                            ,o.code_direction
                                                            ,null
                                                            ,null
                                                            )) as orga_code
                            ,o.cost_center_code_key as cost_center_code
                            ,last(o.cost_center_label) as cost_center_label
                            ,last(o.centertype) as centertype
                            ,o.company_code as companycode
                            ,last(o.company_label) as company
                            ,last(o.marketsegment) as marketsegment
                            ,last(o.activitydomain) as activitydomain
                            ,last(o.standardcostcenter) as standardcostcenter
                            ,last(o.essbasefunction) as essbasefunction
                            ,last(o.profitcenter) as profitcenter
                            ,o.code_etablissement as code_establishment
                            ,last(o.libelle_etablissement) as label_establishment
                            ,o.code_direction 
                            ,last(o.libelle_direction) as label_direction
                            ,o.code_departement as code_department
                            ,last(o.libelle_departement ) as label_department
                            ,null as business_line_reference
                            ,null as business_line_name
                            ,last(p.dird_direction_detail_code) as direction_detail_code
                            ,last(p.dird_direction_detail_name) as direction_detail_name
                            ,last(p.dirr_direction_code) as direction_code
                            ,last(p.dirr_direction_name) as direction_name
                            ,last(p.dirb_direction_psb_budget_code) as direction_psb_budget_code
                            ,last(p.dirb_direction_psb_budget_name) as direction_psb_budget_name
                            ,last(p.dirp_direction_presentation_code) as direction_presentation_code
                            ,last(p.dirp_direction_presentation_name) as direction_presentation_name
                            ,ifnull(last(o.current_hierarchy),true) as current_hierarchy
                            ,last(o.version) as version
                            ,last(o.date_raw_load_file) as date_raw_load_file
                            ,last(o.filepath) as  filepath
                            ,'histo_file' as filename
                            ,last(o.curated_ingested_date) as curated_ingested_date
                            ,ifnull(last(o.current_hierarchy),true) as current_record
                            ,last(o.record_start_date) as record_start_date
                            ,last(o.record_end_date) as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(
                                                             last(o.cost_center_label) 
                                                            ,last(o.centertype)
                                                            ,last(o.company_label) 
                                                            ,last(o.marketsegment) 
                                                            ,last(o.activitydomain)
                                                            ,last(o.standardcostcenter) 
                                                            ,last(o.essbasefunction) 
                                                            ,last(o.profitcenter) 
                                                            ,last(o.libelle_etablissement) 
                                                            ,last(o.libelle_direction) 
                                                            ,last(o.libelle_departement)
                                                            ,null
                                                            ,null
                                                            ,last(p.dird_direction_detail_code)
                                                            ,last(p.dird_direction_detail_name)
                                                            ,last(p.dirr_direction_code)
                                                            ,last(p.dirr_direction_name)
                                                            ,last(p.dirb_direction_psb_budget_code)
                                                            ,last(p.dirb_direction_psb_budget_name)
                                                            ,last(p.dirp_direction_presentation_code)
                                                            ,last(p.dirp_direction_presentation_name)
                                                           )) as hashkey 
                           ,'""" + runid + """' as runid
                           ,lower(trim(split(last(o.filepath),"/")[3])) as system_source
                           
               from    vw_emp_orga o 
                       left join vw_hierarchy_pb p on o.cost_center_key = p.cost_center_key
                       
               where   1=1
                 and   (o.cost_center_code_key is not null)  
                 
               group by
                        o.cost_center_code_key
                       ,o.company_code
                       ,o.code_etablissement
                       ,o.code_departement
                       ,o.code_direction
           """
              

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source)

// COMMAND ----------

// DBTITLE 1,Refresh table common.organization
if(spark.catalog.tableExists("common.organization")) 
{ 
try {
    spark.sql("FSCK REPAIR TABLE common.organization")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the table job after drop the table if exists and store data and table structure on organization_table
val organization_table = DeltaTable.forName("common.organization")

// COMMAND ----------

// DBTITLE 1,Rows for organizationupdated
val neworganization = df_results.as("organization_updated")
  .join(organization_table.toDF.as("organization"), Seq("orga_code"))
  .where("""organization.current_record = true and (organization_updated.hashkey<>organization.hashkey) and organization_updated.date_raw_load_file >= organization.date_raw_load_file """)

// COMMAND ----------

// DBTITLE 1,Union of dataframes between organization updated from existing employees and new jobs from new employees
// Stage the update by unioning two sets of rows
// 1. Rows that will be inserted in the `whenNotMatched` clause
// 2. Rows that will either UPDATE the current contracts of existing employees or insert the new contracts of new employees
val organization_upsert = neworganization
  .selectExpr("null as mergekey", "organization_updated.*")   // Rows for 1.
  .union(
    df_results.as("df_results").selectExpr("df_results.orga_code as mergekey", "*")  // Rows for 2.
  )
//remove duplicate
val organization_upsert_distinct = organization_upsert.distinct()

// COMMAND ----------

// DBTITLE 1,Merge on table organization
organization_table.alias("t")
  .merge(
    organization_upsert_distinct.alias("s"),
    """ t.orga_code = s.mergekey """)
  .whenMatched("""t.current_record = true and (t.hashkey <> s.hashkey) and  s.date_raw_load_file > t.date_raw_load_file""")
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "date_add(s.record_start_date,-1)",
    "record_modification_date" -> "s.record_modification_date",
    "runid" -> "s.runid",
    "current_hierarchy" -> "false")
  )
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE common.organization")

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records_employeewd = df_costcenterhra_read.count().toInt //count the number of read records
val inserted_records = organization_upsert_distinct.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records_employeewd + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_costcentersap_read.unpersist
df_costcenterhra_read.unpersist
df_costcenterhra_allversions.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update common.organization 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)