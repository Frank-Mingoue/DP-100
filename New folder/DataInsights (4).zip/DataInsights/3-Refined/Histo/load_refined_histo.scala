// Databricks notebook source
// DBTITLE 1,Get Parameters
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val limit_date = dbutils.widgets.get("limit_date");
val system_source = dbutils.widgets.get("system_source");
val init_refined = dbutils.widgets.get("init_refined");
val table_name = dbutils.widgets.get("table_name").replace(" ","").split(",").toSeq;

// COMMAND ----------

// DBTITLE 1,Import Common libraries and functions
// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

val dvalue = "2022-03-31"
val system_source = if (load_date <= dvalue) {"hra"} else {"adp"}

// COMMAND ----------

// DBTITLE 1,Purge refined tables and create tables
val timeoutSeconds=0
if(init_refined.toLowerCase() == "yes" )
{
  dbutils.notebook.run("/DataInsights/Init/purge_database", timeoutSeconds, Map("database" -> "all", "layer" -> "refined", "table" -> "all"))
}
dbutils.notebook.run("/DataInsights/Init/init_database", timeoutSeconds, Map("database" -> "all", "layer" -> "refined"))

// COMMAND ----------

// DBTITLE 1,Truncate table load_histo_follow_up
val connection = getSQLconnection()
val stmt = connection.createStatement()

val table_name_lower = table_name.map(a => a.toLowerCase())

val query_delete = """ truncate table dbo.load_histo_follow_up """
val res_delete = stmt.execute(query_delete)

// COMMAND ----------

// DBTITLE 1,Load refined pay histo
if(table_name_lower.contains("pay") || table_name_lower.contains("all") )
{
  if(spark.catalog.tableExists("pay.hra_paie")) 
  {
    try {
        spark.sql("MSCK REPAIR TABLE pay.hra_paie")
      }
      catch {
        case e: FileNotFoundException => println("Couldn't find that file.")
        case e: IOException => println("Had an IOException trying to read that file")
      }
  }


  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val pay_notebook="/DataInsights/3-Refined/HR/load_refined_pay" 
  val timeoutSeconds=0
  //to adjust for each environment - check in curated which files have been loaded

  //var start_date_value = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
  var query_insert = ""
  var res = false
  var l_date = spark.table("pay.hra_paie").select("date_raw_load_file").distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 

  for (x_date <- l_date)
  {
    //print(x_date)
    var start_date_value = LocalDate.parse(x_date.toString, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
    var result_pay=dbutils.notebook.run(pay_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value.toString, "system_source" -> system_source))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_pay_histo','""" + start_date_value.toString + """','""" + result_pay + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
    print(start_date_value)
  }
}

// COMMAND ----------

// DBTITLE 1,Load refined payroll histo
if(table_name_lower.contains("payroll") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val payroll_notebook="/DataInsights/3-Refined/HR/load_refined_payroll"
  val result_payroll=dbutils.notebook.run(payroll_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value, "system_source" -> system_source))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_payroll_histo','""" + start_date_value.toString + """','""" + result_payroll + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined absenteism histo
if(table_name_lower.contains("absenteism") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val abs_notebook="/DataInsights/3-Refined/HR/load_refined_absenteism"
  val result_abs=dbutils.notebook.run(abs_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_absenteism_histo','""" + start_date_value.toString + """','""" + result_abs + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined absenteism consolidated histo
if(table_name_lower.contains("absenteism_consolidated") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val cet_notebook="/DataInsights/3-Refined/HR/load_refined_absenteism_consolidated"
  val result_absenteism_consolidated=dbutils.notebook.run(cet_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_absenteism_consolidated','""" + start_date_value.toString + """','""" + result_absenteism_consolidated + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined referential absences histo
if(table_name_lower.contains("referential_absence") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val cet_notebook="/DataInsights/3-Refined/HR/load_refined_referential_absences"
  val result_referential_absences=dbutils.notebook.run(cet_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_referential_absences','""" + start_date_value.toString + """','""" + result_referential_absences + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined job histo
if(table_name_lower.contains("job") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val job_notebook="/DataInsights/3-Refined/Histo/load_refined_job_histo"
  val result_job=dbutils.notebook.run(job_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_job_histo','""" + start_date_value.toString + """','""" + result_job + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined location histo
if(table_name_lower.contains("location") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val location_notebook="/DataInsights/3-Refined/Histo/load_refined_location_histo"
  val result_location=dbutils.notebook.run(location_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_location_histo','""" + start_date_value.toString + """','""" + result_location + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined organization histo
if(table_name_lower.contains("organization") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val orga_notebook="/DataInsights/3-Refined/Histo/load_refined_organization_histo"
  val result_orga=dbutils.notebook.run(orga_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_orga_histo','""" + start_date_value.toString + """','""" + result_orga + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined employee histo
if(table_name_lower.contains("employee") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val employee_notebook="/DataInsights/3-Refined/HR/load_refined_employee_hra"
  val result_employee=dbutils.notebook.run(employee_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value, "flux" -> "historique", "limit_date" -> limit_date, "system_source" -> system_source))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_employee_histo','""" + start_date_value.toString + """','""" + result_employee + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined contract suspension
if(table_name_lower.contains("contract_suspension") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val contract_suspension_notebook="/DataInsights/3-Refined/HR/load_refined_contract_suspension"
  val result_contract_suspension=dbutils.notebook.run(contract_suspension_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value, "system_source" -> system_source))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_contract_suspension','""" + start_date_value.toString + """','""" + result_contract_suspension + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined contract histo
if(table_name_lower.contains("contract") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val contract_notebook="/DataInsights/3-Refined/HR/load_refined_contract_hra"
  val result_contract=dbutils.notebook.run(contract_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value, "flux" -> "historique", "limit_date" -> limit_date, "system_source" -> system_source))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_contract_histo','""" + start_date_value.toString + """','""" + result_contract + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined child histo
if(table_name_lower.contains("child") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val child_hra_notebook="/DataInsights/3-Refined/Histo/load_refined_child_histo"
  val result_child_hra=dbutils.notebook.run(child_hra_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value, "system_source" -> system_source))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_child_histo','""" + start_date_value.toString + """','""" + result_child_hra + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined ag establishment histo
if(table_name_lower.contains("ag_establishment") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val payroll_notebook="/DataInsights/3-Refined/HR/load_refined_ag_establishment"
  val result_ag_establishment=dbutils.notebook.run(payroll_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_ag_establishment_histo','""" + start_date_value.toString + """','""" + result_ag_establishment + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined amount lti histo
if(table_name_lower.contains("amount_lti") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val cet_notebook="/DataInsights/3-Refined/HR/load_refined_amount_lti"
  val result_amount_lti=dbutils.notebook.run(cet_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_amount_lti','""" + start_date_value.toString + """','""" + result_amount_lti + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined car mobility policy histo
if(table_name_lower.contains("car_mobility_policy") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val cet_notebook="/DataInsights/3-Refined/HR/load_refined_car_mobility_policy"
  val result_car_mobility_policy=dbutils.notebook.run(cet_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_car_mobility_policy','""" + start_date_value.toString + """','""" + result_car_mobility_policy + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined cet histo
if(table_name_lower.contains("cet") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val cet_notebook="/DataInsights/3-Refined/HR/load_refined_cet"
  val result_cet=dbutils.notebook.run(cet_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value, "system_source" -> system_source))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_cet','""" + start_date_value.toString + """','""" + result_cet + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined eligibility psb histo
if(table_name_lower.contains("eligibility_psb") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val cet_notebook="/DataInsights/3-Refined/HR/load_refined_eligibility_psb"
  val result_eligibility_psb=dbutils.notebook.run(cet_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_eligibility_psb','""" + start_date_value.toString + """','""" + result_eligibility_psb + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined housing action histo
if(table_name_lower.contains("housing_action") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val cet_notebook="/DataInsights/3-Refined/HR/load_refined_housing_action"
  val result_housing_action=dbutils.notebook.run(cet_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_housing_action','""" + start_date_value.toString + """','""" + result_housing_action + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined percol peb ccb histo
if(table_name_lower.contains("percol_peb_ccb") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val cet_notebook="/DataInsights/3-Refined/HR/load_refined_percol_peb_ccb"
  val result_percol_peb_ccb=dbutils.notebook.run(cet_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_percol_peb_ccb','""" + start_date_value.toString + """','""" + result_percol_peb_ccb + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load refined theoric target bonus amount histo
if(table_name_lower.contains("target_bonus_amount") || table_name_lower.contains("all") )
{
  val connection = getSQLconnection()
  val stmt = connection.createStatement()
  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val start_date_value = load_date
  val timeoutSeconds=0 
  val cet_notebook="/DataInsights/3-Refined/HR/load_refined_theoric_target_bonus_amount"
  val result_theoric_target_bonus_amount=dbutils.notebook.run(cet_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value))
  val query_insert = """ insert into dbo.load_histo_follow_up values ('refined_theoric_target_bonus_amount','""" + start_date_value.toString + """','""" + result_theoric_target_bonus_amount + """','""" + DateTime.now() + """') """
  val res = stmt.execute(query_insert)
}

// COMMAND ----------

// DBTITLE 1,Load Refined Job Application and Degree
if(table_name_lower.contains("job_application") || table_name_lower.contains("all") )
{
    if(spark.catalog.tableExists("recruitment.get_candidates")) 
    {
      try {
          spark.sql("MSCK REPAIR TABLE recruitment.get_candidates")
        }
        catch {
          case e: FileNotFoundException => println("Couldn't find that file.")
          case e: IOException => println("Had an IOException trying to read that file")
        }
    }


  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val candidate_notebook="/DataInsights/3-Refined/HR/load_refined_job_application" 
  val degree_notebook="/DataInsights/3-Refined/HR/load_refined_degree" 
  val timeoutSeconds=0
  //to adjust for each environment - check in curated which files have been loaded

  //var start_date_value = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
  var query_insert = ""
  var res = false
  var l_date = spark.table("recruitment.get_candidates").select("date_raw_load_file").distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 

  for (x_date <- l_date)
  {
    //print(x_date)
    var start_date_value = LocalDate.parse(x_date.toString, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
    var result_candidate=dbutils.notebook.run(candidate_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value.toString))
    var result_degree=dbutils.notebook.run(degree_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value.toString))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_job_application_histo','""" + start_date_value.toString + """','""" + result_candidate + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
    print(start_date_value)
  }
}

// COMMAND ----------

// DBTITLE 1,Load Refined Job Requisition
if(table_name_lower.contains("job_requisition") || table_name_lower.contains("all") )
{
  if(spark.catalog.tableExists("recruitment.get_jobrequisitions")) 
  {
    try {
        spark.sql("MSCK REPAIR TABLE recruitment.get_jobrequisitions")
      }
      catch {
        case e: FileNotFoundException => println("Couldn't find that file.")
        case e: IOException => println("Had an IOException trying to read that file")
      }
  }


  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val requisition_notebook="/DataInsights/3-Refined/HR/load_refined_job_requisition" 
  val timeoutSeconds=0
  //to adjust for each environment - check in curated which files have been loaded

  //var start_date_value = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
  var query_insert = ""
  var res = false
  var l_date = spark.table("recruitment.get_jobrequisitions").select("date_raw_load_file").distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 

  for (x_date <- l_date)
  {
    //print(x_date)
    var start_date_value = LocalDate.parse(x_date.toString, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
    var result_requisition=dbutils.notebook.run(requisition_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value.toString))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_job_requisition_histo','""" + start_date_value.toString + """','""" + result_requisition + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
    print(start_date_value)
  }
}

// COMMAND ----------

// DBTITLE 1,Load Refined Training
if(table_name_lower.contains("training") || table_name_lower.contains("all") )
{
  if(spark.catalog.tableExists("training.formation")) 
  {
    try {
        spark.sql("MSCK REPAIR TABLE training.formation")
      }
      catch {
        case e: FileNotFoundException => println("Couldn't find that file.")
        case e: IOException => println("Had an IOException trying to read that file")
      }
  }


  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val training_notebook="/DataInsights/3-Refined/HR/load_refined_training" 
  val timeoutSeconds=0
  //to adjust for each environment - check in curated which files have been loaded

  //var start_date_value = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
  var query_insert = ""
  var res = false
  var l_date = spark.table("training.formation").select("date_raw_load_file").distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 

  for (x_date <- l_date)
  {
    //print(x_date)
    var start_date_value = LocalDate.parse(x_date.toString, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
    var result_training=dbutils.notebook.run(training_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value.toString))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_training_histo','""" + start_date_value.toString + """','""" + result_training + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
    print(start_date_value)
  }
}

// COMMAND ----------

// DBTITLE 1,Load Refined Training Evaluation
if(table_name_lower.contains("training_evaluation") || table_name_lower.contains("all") )
{
  if(spark.catalog.tableExists("training.evaluation")) 
  {
    try {
        spark.sql("MSCK REPAIR TABLE training.evaluation")
      }
      catch {
        case e: FileNotFoundException => println("Couldn't find that file.")
        case e: IOException => println("Had an IOException trying to read that file")
      }
  }


  val current_date = LocalDate.of(DateTime.now().getYear,DateTime.now().getMonthOfYear,DateTime.now().getDayOfMonth)
  val evaluation_notebook="/DataInsights/3-Refined/HR/load_refined_training_evaluation" 
  val timeoutSeconds=0
  //to adjust for each environment - check in curated which files have been loaded

  //var start_date_value = LocalDate.parse(start_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
  var query_insert = ""
  var res = false
  var l_date = spark.table("training.evaluation").select("date_raw_load_file").distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 

  for (x_date <- l_date)
  {
    //print(x_date)
    var start_date_value = LocalDate.parse(x_date.toString, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
    var result_evaluation=dbutils.notebook.run(evaluation_notebook, timeoutSeconds, Map("runid" -> "1", "load_date" -> start_date_value.toString))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_training_evaluation_histo','""" + start_date_value.toString + """','""" + result_evaluation + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
    print(start_date_value)
  }
}

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Statistics
val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0

// COMMAND ----------

dbutils.notebook.exit(return_value)