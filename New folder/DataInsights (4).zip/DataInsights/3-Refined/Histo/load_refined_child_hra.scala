// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source system, entity, domain and subdomain
//init widget
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include notebook containing common functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

if(spark.catalog.tableExists("employee.hra_enfants")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.hra_enfants")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val partition_date = get_last_partition_file("/employee/hra/hra_enfants",load_date,"curated")

// COMMAND ----------

val df_enfanthra_read = spark.table("employee.hra_enfants").filter($"date_raw_load_file"===partition_date)
  .withColumnRenamed("prenom","prenom_enfant")
  .withColumnRenamed("date_naissance","date_naissance_enfant")
  .withColumnRenamed("sexe","sexe_enfant")
  .withColumnRenamed("nom","nom_enfant")           

//display(df_enfanthra_read)

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.param_transco_ref",connectionproperties).createOrReplaceTempView("vw_dbo_param_transco_ref")
val df_transco = spark.table("vw_dbo_param_transco_ref").na.fill("Nothing")
//display(df_transco)

// COMMAND ----------

//transco
val df_enfanthra_read_transco = gettransco2(df_transco,df_enfanthra_read,"hra","workday")
df_enfanthra_read_transco._1.createOrReplaceTempView("vw_enfant") // create a temp view


// COMMAND ----------

// DBTITLE 1,Query to select only contracts data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select   distinct 
                              getconcatenedstring(array(e.matricule_wd
                                                        ,e.matricule_hr_access 
                                                              )) as employee_key
                               ,getconcatenedstring(array(e.matricule_wd
                                                        ,stringNormalizer(lower(e.prenom_enfant))
                                                        ,e.date_naissance_enfant
                                                        ,stringNormalizer(lower(e.nom_enfant)))) as employee_key_wd
                               ,getconcatenedstring(array(e.matricule_hr_access
                                                        ,stringNormalizer(lower(e.prenom_enfant))
                                                        ,e.date_naissance_enfant
                                                        ,stringNormalizer(lower(e.nom_enfant)))) as employee_key_hra
                              ,sha2(getconcatenedstring(array(e.matricule_wd, e.matricule_hr_access)),256) as employee_code
                              ,e.matricule_wd as employee_id
                              ,e.matricule_hr_access as france_payroll_id
                              ,e.numero_ordre as children_order_number
                              ,e.children_gender
                              ,e.date_naissance_enfant as children_date_of_birth
                              ,e.prenom_enfant as children_first_name
                              ,e.nom_enfant as children_last_name
                              ,e.children_dependent
                              ,e.date_deces
                              ,e.version
                              ,e.date_raw_load_file
                              ,e.filepath
                              ,e.filename
                              ,e.curated_ingested_date
                              ,false as current_record
                              ,e.date_deb_prise_en_charge as record_start_date
                              ,e.date_fin_prise_en_charge as record_end_date
                              ,current_timestamp() as record_creation_date
                              ,current_timestamp() as record_modification_date
                              ,getconcatenedstring(array( 
                                                          e.nom_enfant
                                                          ,e.prenom_enfant
                                                          ,e.date_naissance_enfant
                                                          ,e.children_gender
                                                          )) as hashkey 
                       , '""" + runid + """' as runid
               from    vw_enfant e
               where   1 = 1
                 and   (e.matricule_wd is not null or e.matricule_hr_access is not null)

              """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source)
//display(df_results.where($"employee_id"==="W00010001"))

// COMMAND ----------

 if(spark.catalog.tableExists("hr.employee_children")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee_children")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the table employee after drop the table if exists and store data and table structure on employees_table
val employee_table = DeltaTable.forName("hr.employee_children")
employee_table.toDF.count

// COMMAND ----------

// DBTITLE 1,Merge on table employee
employee_table.alias("t")
    .merge(
      df_results.alias("s"),
      """s.employee_key_wd=t.employee_key_wd or
      s.employee_key_hra = t.employee_key_hra""")
    .whenNotMatched().insertAll()
    .execute()


// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE hr.employee_children")

// COMMAND ----------

val read_records = df_enfanthra_read.count().toInt //count the number of read records
val inserted_records = df_results.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0
df_results.unpersist()
df_enfanthra_read.unpersist()

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)

// COMMAND ----------

