// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include Notebook Containing Common Functions and Librairies
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")
//sc.getExecutorStorageStatus.length - 1

// COMMAND ----------

// DBTITLE 1,Get Last Partition File
val partition_date = get_last_partition_file("/employee/hra/hra_emploi",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Get Job Transco Data
val df_path = "dbfs:/mnt/raw_container/business/transco_job/*/*/*/*/"
val df_transco = spark.read.format("csv").option("sep",";").option("header",true).load(df_path)
                           .withColumn("ancien_libelle_poste", upper($"ancien_libelle_poste"))
                           .withColumn("nouveau_libelle_poste", upper($"nouveau_libelle_poste"))
                           .distinct

// COMMAND ----------

// DBTITLE 1,HRA Emploi - Test if the source path exists
if(spark.catalog.tableExists("employee.hra_emploi")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.hra_emploi")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Read data Emploi
val df_emploihra_read = spark.table("employee.hra_emploi").filter($"date_raw_load_file"===partition_date).as("j")
                                                          .join(df_transco.as("t"), $"j.matricule_wd" === $"t.matricule_wd" and lower($"j.libelle_emploi") === lower($"t.ancien_libelle_poste"), "left_outer")
                                                          .withColumn("libelle_emploi", when($"ancien_libelle_poste".isNotNull,$"nouveau_libelle_poste").otherwise($"libelle_emploi"))
                                                          .select("j.matricule_wd","matricule_hr_access",                                                         
                                                                 "date_effet_emploi","date_fin_emploi","code_emploi","libelle_emploi",
                                                                  "taux_emploi","date_raw_load_file","filepath","filename","curated_ingested_date")
//read parquet file
df_emploihra_read.createOrReplaceTempView("vw_emploi")

// COMMAND ----------

// DBTITLE 1,Refresh table HRA Carrière
if(spark.catalog.tableExists("employee.hra_carriere")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.hra_carriere")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Read Carriere Data
val df_carrierehra_read = spark.table("employee.hra_carriere").filter($"date_raw_load_file"===partition_date)
                                                                .select("matricule_wd","matricule_hr_access",                                                                            
                                                                       "date_deb_carriere","date_fin_carriere","qualification","libelle_qualification")
//read parquet file
df_carrierehra_read.createOrReplaceTempView("vw_carriere")

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded histo grade
val partition_date = get_last_partition_file("/employee/workday/histo_grade",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Refresh table histo grade
if(spark.catalog.tableExists("employee.histo_grade")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.histo_grade")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Histo Grade data
val df_histograde_read = spark.table("employee.histo_grade").where($"date_raw_load_file"===partition_date)
                                                            .withColumnRenamed("compensation_grade_reference_label_2","grade")
                                                            .withColumnRenamed("compensation_grade_reference_label","grade_label")
                                                            .withColumn("grade",when($"grade".isNull , "NOT_GRADED").otherwise($"grade"))
                                                            .withColumn("france_payroll_id", lit(null: String))
df_histograde_read.createOrReplaceTempView("vw_grade")
//display(df_histograde_read)                                                     

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded histo job profile
val partition_date = get_last_partition_file("/employee/workday/histo_job_profile",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Refresh table histo job profile
if(spark.catalog.tableExists("employee.histo_job_profile")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.histo_job_profile")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Histo Job Profile data
val df_histojobprofile_read = spark.table("employee.histo_job_profile").where($"date_raw_load_file"===partition_date)
                                                                         .withColumn("france_payroll_id", lit(null: String))                                                                     
df_histojobprofile_read.createOrReplaceTempView("vw_jobprofile")

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded histo management level
val partition_date = get_last_partition_file("/employee/workday/histo_management_level",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Refresh table histo management level
if(spark.catalog.tableExists("employee.histo_management_level")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.histo_management_level")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Histo Management Level data
val df_histomanagement_read = spark.table("employee.histo_management_level").where($"date_raw_load_file"===partition_date)
                                                                         .withColumnRenamed("management_level_reference","management_level")
                                                                         .withColumn("france_payroll_id", lit(null: String))
df_histomanagement_read.distinct.createOrReplaceTempView("vw_management")
//display(df_histomanagement_read)                                                     

// COMMAND ----------

// DBTITLE 1,Get Employee Job Info
val df_employee = df_emploihra_read.select("matricule_wd","matricule_hr_access","date_effet_emploi")
                            .union(df_carrierehra_read.select("matricule_wd","matricule_hr_access","date_deb_carriere"))
                            .union(df_histograde_read.select("employee_id","france_payroll_id","effective_date_from_comp"))
                            .union(df_histojobprofile_read.select("employee_id","france_payroll_id","effective_date_from_job_change"))
                            .union(df_histomanagement_read.select("employee_id","france_payroll_id","effective_date_from_job_change"))
                            .withColumnRenamed("date_effet_emploi","date_effet")
                            .orderBy($"date_effet".asc)
  
df_employee.distinct.createOrReplaceTempView("vw_employee")

// COMMAND ----------

// DBTITLE 1,Query to select only job data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """

  select

  distinct

    getconcatenedstring(array ( lower(e.libelle_emploi) 
                               ,g.grade
                               ,m.management_level
                               ,c.qualification
                               ,p.job_profile_reference)) as job_key

    ,sha2(getconcatenedstring(array(
                               lower(e.libelle_emploi)
                              ,g.grade
                              ,m.management_level
                              ,p.job_profile_reference
                              )),256) as job_code
    ,upper(e.libelle_emploi) as job_title
    ,g.grade
    ,case when lower(g.grade) like '%not_graded%' then 'Not Graded' else g.grade_label end as grade_label
    ,m.management_level
    ,m.management_level_label
    ,c.qualification as professional_category_reference
    ,c.libelle_qualification as professional_category_name
    ,p.job_profile_name
    ,p.job_profile_reference
    ,null as job_profile_reference_label
    ,p.job_category
    ,p.job_family
    ,p.job_family_group
    ,null as version
    ,e.date_raw_load_file as date_raw_load_file
    ,e.filepath as filepath
    ,'histo_file' as filename
    ,e.curated_ingested_date as curated_ingested_date
    ,true as current_record
    ,e.date_raw_load_file as record_start_date
    ,null as record_end_date
    ,current_timestamp() as record_creation_date
    ,current_timestamp() as record_modification_date
    ,getconcatenedstring(array(                                                            
         case when lower(g.grade) like '%not_graded%' then 'Not Graded' else g.grade_label end
         ,m.management_level_label
        ,c.qualification
        ,p.job_profile_name
        ,null
        ,p.job_category
        ,p.job_family
        ,p.job_family_group
       )) as hashkey 
    ,'""" + runid + """' as runid
    ,lower(trim(split(e.filepath,"/")[3])) as system_source

from vw_employee f
    
    left join vw_emploi e on (e.matricule_wd = f.matricule_wd or e.matricule_hr_access = f.matricule_hr_access) and (f.date_effet >= e.date_effet_emploi)
    left join vw_carriere c on (c.matricule_wd = f.matricule_wd or c.matricule_hr_access = f.matricule_hr_access) and (f.date_effet >= c.date_deb_carriere )
    left join vw_grade g  on g.employee_id = f.matricule_wd and  (f.date_effet >= g.effective_date_from_comp )
    left join vw_jobprofile p on p.employee_id = f.matricule_wd and (f.date_effet >= p.effective_date_from_job_change)
    left join vw_management m  on (m.employee_id = f.matricule_wd) and (f.date_effet >= m.effective_date_from_job_change)
    
  where 1=1
    and (lower(e.libelle_emploi) is not null 
         or g.grade is not null
         or m.management_level is not null
         or c.qualification is not null
         or p.job_profile_reference is not null)

"""

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source).cache()
//display(df_results)

// COMMAND ----------

// DBTITLE 1,Refresh table Common.job
if(spark.catalog.tableExists("common.job")) 
{ 
try {
    spark.sql("FSCK REPAIR TABLE common.job")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the table job after drop the table if exists and store data and table structure on job_table
val job_table = DeltaTable.forName("common.job")
job_table.toDF.count

// COMMAND ----------

// DBTITLE 1,Rows for job updated
val newjob = df_results.as("job_updated")
  .join(job_table.toDF.as("job"), Seq("job_key"))
  .where("""job.current_record = true and (job_updated.hashkey <> job.hashkey) and job_updated.date_raw_load_file >= job.date_raw_load_file """)

// COMMAND ----------

// DBTITLE 1,Union of dataframes between jobs updated from existing employees and new jobs from new employees
// Stage the update by unioning two sets of rows
// 1. Rows that will be inserted in the `whenNotMatched` clause
// 2. Rows that will either UPDATE the current contracts of existing employees or insert the new contracts of new employees
val job_upsert = newjob
  .selectExpr("null as mergekey", "job_updated.*")    // Rows for 1.
  .union(
    df_results.as("df_results").selectExpr("df_results.job_key as mergekey","*")  // Rows for 2.
  )
//remove duplicate
val job_upsert_distinct = job_upsert.distinct()

// COMMAND ----------

// DBTITLE 1,Merge on table Job
job_table.alias("t")
  .merge(
    job_upsert_distinct.alias("s"),
    """ t.job_key = s.mergekey """)

  .whenMatched("""t.current_record = true and (t.hashkey <> s.hashkey) and s.date_raw_load_file > t.date_raw_load_file """)
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "date_add(s.record_start_date,-1)",
    "record_modification_date" -> "s.record_modification_date",
    "runid" -> "s.runid")
  )
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE common.job")

// COMMAND ----------

// DBTITLE 1,Get Statistics
val read_records = 0 //df_emploihra_read.count().toInt //count the number of read records
val inserted_records = 0 //job_upsert_distinct.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_results.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update common.job 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)