// Databricks notebook source
val runid = dbutils.widgets.get("runid");
val start_date = dbutils.widgets.get("start_date")
val end_date = dbutils.widgets.get("end_date")
val table_name = dbutils.widgets.get("table_name").replace(" ","").split(",").toList;
val system_source = dbutils.widgets.get("system_source");

// COMMAND ----------

val dvalue = "2022-03-31"
val system_source = if (start_date <= dvalue) {"hra"} else {"adp"}

// COMMAND ----------

// MAGIC %run /DataInsights/Include/config_connection

// COMMAND ----------

if(spark.catalog.tableExists("employee.get_workers")) 
{
  try {
      spark.sql("MSCK REPAIR TABLE employee.get_workers")
    }
    catch {
      case e: FileNotFoundException => println("Couldn't find that file.")
      case e: IOException => println("Had an IOException trying to read that file")
    }
}

// COMMAND ----------

val table_name_lower = table_name.map(a => a.toLowerCase())
val connection = getSQLconnection()
val stmt = connection.createStatement()
val timeoutSeconds=0

// COMMAND ----------

// DBTITLE 1,Load Histo Refined Workday Job
if(table_name_lower.contains("job") || table_name_lower.contains("all") )
{
  var query_insert = ""
  var res = false
  var result =""
  var l_date = spark.table("employee.get_workers").select("date_raw_load_file").where($"date_raw_load_file">=start_date and $"date_raw_load_file"<=end_date).distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 
  for (x_date <- l_date){

    //COMMON: job
    var result_job = dbutils.notebook.run("/DataInsights/3-Refined/Common/load_refined_job" , timeoutSeconds, Map("runid" -> "1", "load_date" -> x_date.toString))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_job_histo_workday','""" + x_date.toString + """','""" + result_job + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
  }
}

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Load Histo Refined Workday Location
if(table_name_lower.contains("location") || table_name_lower.contains("all") )
{
  var query_insert = ""
  var res = false
  var result =""
  var l_date = spark.table("employee.get_workers").select("date_raw_load_file").where($"date_raw_load_file">=start_date and $"date_raw_load_file"<=end_date).distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 
  for (x_date <- l_date){

    //COMMON: location
    var result_location = dbutils.notebook.run("/DataInsights/3-Refined/Common/load_refined_location" , timeoutSeconds, Map("runid" -> "1", "load_date" -> x_date.toString))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_location_histo_workday','""" + x_date.toString + """','""" + result_location + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
  }
}

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Load Histo Refined Workday Organization
if(table_name_lower.contains("organization") || table_name_lower.contains("all") )
{
  var query_insert = ""
  var res = false
  var result =""
  var l_date = spark.table("employee.get_workers").select("date_raw_load_file").where($"date_raw_load_file">=start_date and $"date_raw_load_file"<=end_date).distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 
  for (x_date <- l_date){

    //COMMON: Organization
    var result_orga = dbutils.notebook.run("/DataInsights/3-Refined/Common/load_refined_organization" , timeoutSeconds, Map("runid" -> "1", "load_date" -> x_date.toString, "system_source" -> system_source))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_organization_histo_workday','""" + x_date.toString + """','""" + result_orga + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
  }
}

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Load Histo Refined Ref Organization
if(table_name_lower.contains("ref_organization") || table_name_lower.contains("all") )
{
  var query_insert = ""
  var res = false
  var result =""
  var l_date = spark.table("organization.hra_ref_centrecout").select("date_raw_load_file").where($"date_raw_load_file">=start_date and $"date_raw_load_file"<=end_date).distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 
  for (x_date <- l_date){

    //COMMON: Organization
    var result_ref_orga = dbutils.notebook.run("/DataInsights/3-Refined/Common/load_refined_ref_organization" , timeoutSeconds, Map("runid" -> "1", "load_date" -> x_date.toString, "system_source" -> system_source))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_ref_organization_histo_workday','""" + x_date.toString + """','""" + result_ref_orga + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
  }
}

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Load Histo Refined Workday Contract Suspension
if(table_name_lower.contains("contract_suspension") || table_name_lower.contains("all") )
{
  var query_insert = ""
  var res = false
  var result =""
  var l_date = spark.table("employee.get_workers").select("date_raw_load_file").where($"date_raw_load_file">=start_date and $"date_raw_load_file"<=end_date).distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 
  for (x_date <- l_date){

      //HR: Contract Suspension
    var result_contract_susp = dbutils.notebook.run("/DataInsights/3-Refined/HR/load_refined_contract_suspension" , timeoutSeconds, Map("runid" -> "1", "load_date" -> x_date.toString, "system_source" -> system_source))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_contract_susp_histo_workday','""" + x_date.toString + """','""" + result_contract_susp + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
  }
}

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Load Histo Refined Workday Child
if(table_name_lower.contains("child") || table_name_lower.contains("all") )
{
  var query_insert = ""
  var res = false
  var result =""
  var l_date = spark.table("employee.get_workers").select("date_raw_load_file").where($"date_raw_load_file">=start_date and $"date_raw_load_file"<=end_date).distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 
  for (x_date <- l_date){

    //HR: Child
    var result_child = dbutils.notebook.run("/DataInsights/3-Refined/HR/load_refined_child" , timeoutSeconds, Map("runid" -> "1", "load_date" -> x_date.toString,"system_source" -> system_source))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_child_histo_workday','""" + x_date.toString + """','""" + result_child + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
  }
}

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Load Histo Refined Workday Employee HRA
if(table_name_lower.contains("employee_hra") || table_name_lower.contains("all") )
{
  var query_insert = ""
  var res = false
  var result =""
  var l_date = spark.table("employee.get_workers").select("date_raw_load_file").where($"date_raw_load_file">=start_date and $"date_raw_load_file"<=end_date).distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 
  for (x_date <- l_date){

      //HR: Employee_HRA
    var result_employee_hra = dbutils.notebook.run("/DataInsights/3-Refined/HR/load_refined_employee_hra" , timeoutSeconds, Map("runid" -> "1", "load_date" -> x_date.toString, "flux" -> "quotidien", "limit_date" -> "2999-12-31","system_source" -> system_source))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_employee_hra_histo_workday','""" + x_date.toString + """','""" + result_employee_hra + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
  }
}

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Load Histo Refined Workday Contract HRA
if(table_name_lower.contains("contract_hra") || table_name_lower.contains("all") )
{
  var query_insert = ""
  var res = false
  var result =""
  var l_date = spark.table("employee.get_workers").select("date_raw_load_file").where($"date_raw_load_file">=start_date and $"date_raw_load_file"<=end_date).distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 
  for (x_date <- l_date){

    //HR: Contract_HRA
     var result_contract_hra = dbutils.notebook.run("/DataInsights/3-Refined/HR/load_refined_contract_hra" , timeoutSeconds, Map("runid" -> "1", "load_date" -> x_date.toString, "flux" -> "quotidien", "limit_date" -> "2999-12-31", "system_source" -> system_source))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_contract_hra_histo_workday','""" + x_date.toString + """','""" + result_contract_hra + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
  }
}

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Load Histo Refined Workday Employee
if(table_name_lower.contains("employee") || table_name_lower.contains("all") )
{
  var query_insert = ""
  var res = false
  var result =""
  var l_date = spark.table("employee.get_workers").select("date_raw_load_file").where($"date_raw_load_file">=start_date and $"date_raw_load_file"<=end_date).distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 
  for (x_date <- l_date){

    //HR: employee
     var result_employee = dbutils.notebook.run("/DataInsights/3-Refined/HR/load_refined_employee" , timeoutSeconds, Map("runid" -> "1", "load_date" -> x_date.toString, "system_source" -> system_source))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_employee_histo_workday','""" + x_date.toString + """','""" + result_employee + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
  }
}

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Load Histo Refined Workday Contract
if(table_name_lower.contains("contract") || table_name_lower.contains("all") )
{
  var query_insert = ""
  var res = false
  var result =""
  var l_date = spark.table("employee.get_workers").select("date_raw_load_file").where($"date_raw_load_file">=start_date and $"date_raw_load_file"<=end_date).distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 
  for (x_date <- l_date){

    //HR:Contract
    var result_contract = dbutils.notebook.run("/DataInsights/3-Refined/HR/load_refined_contract" , timeoutSeconds, Map("runid" -> "1", "load_date" -> x_date.toString, "system_source" -> system_source))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_contract_histo_workday','""" + x_date.toString + """','""" + result_contract + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
  }
}

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Load Histo Refined Workday Career
if(table_name_lower.contains("career") || table_name_lower.contains("all") )
{
  var query_insert = ""
  var res = false
  var result =""
  var l_date = spark.table("employee.get_workers").select("date_raw_load_file").where($"date_raw_load_file">=start_date and $"date_raw_load_file"<=end_date).distinct.orderBy($"date_raw_load_file".asc).rdd.map(r => r(0)).collect.toList 
  for (x_date <- l_date){

    //HR:Contract
    var result_career = dbutils.notebook.run("/DataInsights/3-Refined/HR/load_refined_career" , timeoutSeconds, Map("runid" -> "1", "load_date" -> x_date.toString, "system_source" -> system_source))
    query_insert = """ insert into dbo.load_histo_follow_up values ('refined_career_histo_workday','""" + x_date.toString + """','""" + result_career + """','""" + DateTime.now() + """') """
    res = stmt.execute(query_insert)
  }
}

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0

// COMMAND ----------

dbutils.notebook.exit(return_value)