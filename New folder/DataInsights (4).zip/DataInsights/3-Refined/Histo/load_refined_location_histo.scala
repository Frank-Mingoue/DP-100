// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val last_load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include Notebook Containing Common Functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Get Last Partition File loaded
val partition_date = get_last_partition_file("/employee/workday/histo_site",last_load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Histo Site
if(spark.catalog.tableExists("employee.histo_site")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.histo_site")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Set Default Value
val defaultEndDate = LocalDate.parse("2999-12-31", DateTimeFormatter.ofPattern("yyyy-MM-dd"))   

// COMMAND ----------

// DBTITLE 1,Get data from histo site
 val window = Window.partitionBy("employee_id").orderBy($"effective_date_from_location_change".asc)

val df_histosite_read = spark.table("employee.histo_site").where($"date_raw_load_file"===partition_date)
                                                          .withColumnRenamed("business_site_summary_data_name","location")
                                                          .withColumn("end_effective_date_from_location_change", 
                                                                                when ($"effective_date_from_location_change".isNull
                                                                              ,lead($"effective_date_from_location_change"-1,1,defaultEndDate).over(window))
                                                                              .otherwise(defaultEndDate))
                                                          //.select("employee_id","location","effective_date_from_location_change","end_effective_date_from_location_change")
df_histosite_read.createOrReplaceTempView("vw_location")
//display(df_histosite_read)                                                     

// COMMAND ----------

// DBTITLE 1,Query Location
val query_source = """select distinct 
                            l.location as location_key
                            ,sha2(getconcatenedstring(array(l.location,'NC')), 256) as location_code
                            ,l.location
                            ,l.location_type           
                            ,'NC' as location_country
                            ,'NC' as location_reference
                            ,l.version
                            ,l.date_raw_load_file
                            ,l.filepath
                            ,'histo_file' as filename
                            ,l.curated_ingested_date
                            ,true as current_record
                            ,l.date_raw_load_file as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array( l.location
                                                        ,l.location_type           
                                                       ,'NC'
                                                       ,'NC'
                                                           )) as hashkey 
                           ,'""" + runid + """' as runid
                           ,lower(trim(split(l.filepath,"/")[3])) as system_source
               from    vw_location l
               where   1=1
                 and   l.location is not null"""

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source)
//display(df_results)

// COMMAND ----------

// DBTITLE 1,Refresh Common Location
if(spark.catalog.tableExists("common.location")) 
{ 
try {
    spark.sql("FSCK REPAIR TABLE common.location")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the table job after drop the table if exists and store data and table structure on job_table
val location_table = DeltaTable.forName("common.location")

// COMMAND ----------

// DBTITLE 1,Rows for job updated
val newlocation = df_results.as("location_updated")
  .join(location_table.toDF.as("location"), Seq("location_key"))
  .where("""location.current_record = true and (location_updated.hashkey <> location.hashkey) and location_updated.date_raw_load_file >= location.date_raw_load_file """)

// COMMAND ----------

// DBTITLE 1,Union of dataframes between jobs updated from existing employees and new jobs from new employees
// Stage the update by unioning two sets of rows
// 1. Rows that will be inserted in the `whenNotMatched` clause
// 2. Rows that will either UPDATE the current contracts of existing employees or insert the new contracts of new employees
val location_upsert = newlocation
  .selectExpr("null as mergekey", "location_updated.*")    // Rows for 1.
  .union(
    df_results.as("df_results").selectExpr("df_results.location_key as mergekey","*")  // Rows for 2.
  )
//remove duplicate
val location_upsert_distinct = location_upsert.distinct()

// COMMAND ----------

// DBTITLE 1,Merge on table Job
location_table.alias("t")
  .merge(
    location_upsert_distinct.alias("s"),
    """ t.location_key = s.mergekey """)

  .whenMatched("""t.current_record = true and (t.hashkey <> s.hashkey) and s.date_raw_load_file > t.date_raw_load_file """)
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "date_add(s.record_start_date,-1)",
    "record_modification_date" -> "s.record_modification_date",
    "runid" -> "s.runid")
  )
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE common.location")

// COMMAND ----------

// DBTITLE 1,Statistics
val inserted_records = location_upsert_distinct.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value ="inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update common.location 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)