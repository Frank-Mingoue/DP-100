// Databricks notebook source
// DBTITLE 1,Get Parameters
val load_date = dbutils.widgets.get("load_date")
val runid = dbutils.widgets.get("runid")
val load_mode = "delta"//dbutils.widgets.get("load_mode")
val load_year = "2018"//dbutils.widgets.get("load_year")

// COMMAND ----------

// DBTITLE 1,Import functions and librairies
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Configurations
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,SQL Config
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Training Table
if(spark.catalog.tableExists("training.formation")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE training.formation")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// MAGIC %md ### 1- Read Data

// COMMAND ----------

// DBTITLE 1,Last partition
val partition_training = get_last_partition_file("/training/cornerstone/cornerstone_formation",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Rename Columns
val df_training_read =  spark.table("training.formation").filter("date_raw_load_file = '" + partition_training + "'")
  // Rename Columns
  .withColumnRenamed("id_utilisateur","employee_id")
  .withColumnRenamed("fournisseur_formation","training_provider")
  .withColumnRenamed("perimetre_rh","hr_scope")
  .withColumnRenamed("titre_formation","training_label")
  .withColumnRenamed("organisme_formation","training_organization")
  .withColumnRenamed("action_formation","training_action")
  .withColumnRenamed("formation_obligatoire","mandatory_training")
  .withColumnRenamed("habilitation_certification_diplome","authorization_certification_diploma")
  .withColumnRenamed("matiere_formation_parent","parent_training_subject")
  .withColumnRenamed("matiere_formation","training_subject")
  .withColumnRenamed("axe","training_axis")
  .withColumnRenamed("id_objet_formation","training_object_id")
  .withColumnRenamed("numero_repere_formation","training_landmark_number")
  .withColumnRenamed("type_stage","trainingship_type")
  .withColumnRenamed("budget_developement_talents","talent_development_budget")
  .withColumnRenamed("interieur_parcours","inside_training_path")
  .withColumnRenamed("reconversion","reskilling")
  .withColumnRenamed("modalite","training_mode")
  .withColumnRenamed("type_conges_formation","training_leave_type")
  .withColumnRenamed("coaching","coaching")
  .withColumnRenamed("realisation","training_recap_working_hours")
  .withColumnRenamed("type_formation","training_type")
  .withColumnRenamed("statut_recapitulatif","training_recap_status")
  .withColumnRenamed("nombre_stagiaire_previsionnel","training_estimated_participants")
  .withColumnRenamed("budget_previsionnel","training_estimated_budget")
  .withColumnRenamed("heures_formation","training_hours")
  .withColumnRenamed("prix_formation","training_price")
  .withColumnRenamed("date_debut_formation","training_start_date")
  .withColumnRenamed("date_fin_formation","training_end_date")
  .withColumnRenamed("facture","invoice")
  .withColumnRenamed("feuille_emargement","training_presence_sheet")
  .withColumnRenamed("montant_abondement_cpf_entreprise","CPF_company_funding_amount")
  .withColumnRenamed("montant_salarie_cpf_autre","CPF_other_employee_amount")
  .withColumnRenamed("frais_reprographie_materiel_pedagogique","training_materials_fees")
  .withColumnRenamed("duree_partie","training_session_duration")
  .withColumnRenamed("duree_pause_partie","training_session_break_duration")
  .withColumnRenamed("utilisateur_assiste_partie","attended_to_training_session")
  .withColumnRenamed("frais_ingenierie","training_preparation_fees")
  .withColumnRenamed("frais_deplacement_hebergement_repas_formateur","trainer_fees")
  .withColumnRenamed("frais_deplacement_hebergement_repas_participant","trainee_fees")
  .withColumnRenamed("montant_charge_opca","OPCA_amount")
  .withColumnRenamed("date_creation_formation","training_creation_date")
  .withColumnRenamed("date_derniere_modification","training_modification_date")
  .withColumnRenamed("date_debut_partie","training_session_start_date")
  .withColumnRenamed("date_fin_partie","training_session_end_date")
  .withColumnRenamed("date_achevement_recapitulatif","recap_completion_date")
  .withColumnRenamed("date_inscription_recapitulatif","recap_registration_date")
  .withColumnRenamed("date_dernier_changement_statut_recapitulatif","last_recap_status_modification_date")
  .withColumnRenamed("supprime_recapitulatif","removed_from_recap")
  .withColumnRenamed("categorie_action","legal_category")

df_training_read.cache()  //put the dataframe ont he cache
df_training_read.createOrReplaceTempView("vw_training_curated") // create a temp view

// COMMAND ----------

// DBTITLE 1,Training Plan Date Parameters

val df_training_plan_date =  spark.read.jdbc(jdbcurl, "dbo.param_training_plan_date", connectionproperties)
df_training_plan_date.createOrReplaceTempView("vw_training_plan_date")

val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val year_id = date_value.getYear()

// COMMAND ----------

// DBTITLE 1,Format & calculated columns
val df_training = df_training_read
  //date columns
  .withColumn("training_start_date",to_timestamp($"training_start_date","dd/MM/yyyy HH:mm"))
  .withColumn("training_end_date",to_timestamp($"training_end_date","dd/MM/yyyy HH:mm"))
  .withColumn("training_creation_date",to_timestamp($"training_creation_date","dd/MM/yyyy HH:mm"))
  .withColumn("training_modification_date",to_timestamp($"training_modification_date","dd/MM/yyyy HH:mm"))
  .withColumn("training_session_start_date",to_timestamp($"training_session_start_date","dd/MM/yyyy HH:mm"))
  .withColumn("training_session_end_date",to_timestamp($"training_session_end_date","dd/MM/yyyy HH:mm"))
  .withColumn("recap_completion_date",to_timestamp($"recap_completion_date","dd/MM/yyyy HH:mm"))
  .withColumn("recap_registration_date",to_timestamp($"recap_registration_date","dd/MM/yyyy HH:mm"))
  .withColumn("last_recap_status_modification_date",to_timestamp($"last_recap_status_modification_date","dd/MM/yyyy HH:mm"))
  //number columns
  .withColumn("training_landmark_number",$"training_landmark_number".cast("int"))
  .withColumn("training_estimated_participants",$"training_estimated_participants".cast("int"))
  .withColumn("training_session_duration",$"training_session_duration".cast("int"))
  .withColumn("training_session_break_duration",$"training_session_break_duration".cast("int"))
  .withColumn("training_estimated_budget",$"training_estimated_budget".cast("double"))
  .withColumn("training_hours",$"training_hours".cast("double"))
  .withColumn("training_price",$"training_price".cast("double"))
  .withColumn("CPF_company_funding_amount",$"CPF_company_funding_amount".cast("double"))
  .withColumn("CPF_other_employee_amount",$"CPF_other_employee_amount".cast("double"))
  .withColumn("training_preparation_fees",$"training_preparation_fees".cast("double"))
  .withColumn("trainer_fees",$"trainer_fees".cast("double"))
  .withColumn("trainee_fees",$"trainee_fees".cast("double"))
  .withColumn("OPCA_amount",$"OPCA_amount".cast("double"))
  .withColumn("training_materials_fees",$"training_materials_fees".cast("double"))
  //boolean column
  .withColumn("training_action",when($"training_action".isNotNull,when(lower($"training_action") === "oui",true).otherwise(when(lower($"training_action") === "non",false))))
  .withColumn("talent_development_budget",when($"talent_development_budget".isNotNull,when(lower($"talent_development_budget") === "oui",true).otherwise(when(lower($"talent_development_budget") === "non",false))))
  .withColumn("inside_training_path",when($"inside_training_path".isNotNull,when(lower($"inside_training_path") === "oui",true).otherwise(when(lower($"inside_training_path") === "non",false))))
  .withColumn("reskilling",when($"reskilling".isNotNull,when(lower($"reskilling") === "oui",true).otherwise(when(lower($"reskilling") === "non",false))))
  .withColumn("invoice",when($"invoice".isNotNull,when(lower($"invoice") === "oui",true).otherwise(when(lower($"invoice") === "non",false))))
  .withColumn("training_presence_sheet",when($"training_presence_sheet".isNotNull,when(lower($"training_presence_sheet") === "oui",true).otherwise(when(lower($"training_presence_sheet") === "non",false))))
  .withColumn("attended_to_training_session",when($"attended_to_training_session".isNotNull,when(lower($"attended_to_training_session") === "oui",true).otherwise(when(lower($"attended_to_training_session") === "non",false))))
  .withColumn("removed_from_recap",when($"removed_from_recap".isNotNull,when(lower($"removed_from_recap") === "oui",true).otherwise(when(lower($"removed_from_recap") === "non",false))))
  //transco
  .withColumn("coaching",when(lower($"coaching") === "non" || lower($"coaching") === "-" || $"coaching".isNull,"NON").otherwise($"coaching"))
  .withColumn("training_leave_type",when(upper($"coaching") === "VAE" && upper($"training_leave_type") != "CPF","VAE").otherwise($"training_leave_type"))
  .withColumn("training_leave_type",when(upper($"coaching") === "BILAN" && upper($"training_leave_type") != "CPF","Bilan de Compétences").otherwise($"training_leave_type"))
  .withColumn("training_leave_type",when(upper($"training_leave_type") === "CPF" && upper($"coaching") === "VAE","CPF - VAE").otherwise($"training_leave_type"))
  .withColumn("training_leave_type",when(upper($"training_leave_type") === "CPF" && upper($"coaching") === "BILAN","CPF - BS").otherwise($"training_leave_type"))
  .withColumn("coaching",when(upper($"training_leave_type") === "CPF - VAE" && upper($"coaching") === "VAE","NON").otherwise($"coaching"))
  .withColumn("coaching",when(upper($"training_leave_type") === "CPF - BS" && upper($"coaching") === "BILAN","NON").otherwise($"coaching"))
  .withColumn("coaching",when(upper($"coaching") === "VAE" || upper($"coaching") === "BILAN","NON").otherwise($"coaching"))
  .withColumn("coaching",when(upper($"coaching") === "COACHING","OUI").otherwise($"coaching"))

df_training.createOrReplaceTempView("vw_training")

// COMMAND ----------

// DBTITLE 1,Define Training Plan Date
val df_training_results = df_training.as("t")
  // date parameters
  .join(df_training_plan_date.as("d"),trim(lower($"t.training_recap_status")) === trim(lower($"d.training_recap_status")) && trim(lower($"t.training_type")) === trim(lower($"d.training_type")),"left")
  // training plan date
  .withColumn("training_plan_date_id",
                when($"flag_recap_completion_date",$"recap_completion_date".cast("date"))
                when($"flag_training_start_date",$"training_start_date".cast("date"))
                when($"flag_training_end_date",$"training_end_date".cast("date"))
                when($"flag_recap_registration_date",$"recap_registration_date".cast("date"))
                when($"flag_last_recap_status_modification_date",$"last_recap_status_modification_date".cast("date"))
             )
  .filter($"training_plan_date_id".isNotNull && $"training_object_id".isNotNull)
  .drop($"d.training_recap_status").drop($"d.training_type")
  .withColumn("training_plan_year_id",year($"training_plan_date_id"))

df_training_results.createOrReplaceTempView("vw_training_results")

// COMMAND ----------

// DBTITLE 1,Retrieve years to load
var min_training_year = 0
var max_training_year = 0

try {
 min_training_year = df_training_results.agg(min("training_plan_year_id")).head().getInt(0)
 max_training_year = df_training_results.agg(max("training_plan_year_id")).head().getInt(0)
}
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
    case e: java.lang.NullPointerException => println("Dataframe is empty")
  }

val load_year_start = if (load_mode == "full")
  {
    min_training_year
  }
  else if(load_mode == "delta")
  {
    year_id - 1
  }
  else if(load_mode == "year"){
    load_year.toInt
  }
val load_year_end = if (load_mode == "full")
{
    
  max_training_year
}
else if(load_mode == "delta")
{
  max_training_year
}
else if(load_mode == "year"){
  load_year.toInt
}


// COMMAND ----------

// DBTITLE 1,Query Data
val query_source = """
  select 

    employee_id,
    training_provider,
    hr_scope,
    training_label,
    training_organization,
    training_action,
    mandatory_training,
    authorization_certification_diploma,
    parent_training_subject,
    training_subject,
    training_axis,
    training_object_id,
    training_landmark_number,
    trainingship_type,
    talent_development_budget,
    inside_training_path,
    reskilling,
    training_mode,
    training_leave_type,
    coaching,
    training_recap_working_hours,
    training_type,
    training_recap_status,
    training_estimated_participants,
    training_estimated_budget,
    training_hours,
    training_price,
    training_start_date,
    training_end_date,
    invoice,
    training_presence_sheet,
    CPF_company_funding_amount,
    CPF_other_employee_amount,
    training_materials_fees,
    training_session_duration,
    training_session_break_duration,
    attended_to_training_session,
    training_preparation_fees,
    trainer_fees,
    trainee_fees,
    OPCA_amount,
    training_creation_date,
    training_modification_date,
    training_session_start_date,
    training_session_end_date,
    recap_completion_date,
    recap_registration_date,
    last_recap_status_modification_date,
    removed_from_recap,
    legal_category,
    training_plan_date_id,
    training_plan_year_id


    -- technical codes

    ,getconcatenedstring(array(
      employee_id
      ,training_object_id
      ,training_plan_year_id
    )) as training_key 

    ,sha2(getconcatenedstring(array(
      training_type
    )),256) as training_type_code

    ,sha2(getconcatenedstring(array(
      training_recap_status
      ,training_type
    )),256) as training_status_code

    ,getconcatenedstring(array(
      training_provider,
      hr_scope,
      training_label,
      training_organization,
      authorization_certification_diploma,
      parent_training_subject,
      training_subject,
      training_axis,
      training_landmark_number,
      trainingship_type,
      training_mode,
      training_leave_type,
      training_recap_working_hours,
      training_type,
      training_recap_status,
      training_estimated_participants,
      training_estimated_budget,
      training_hours,
      training_price,
      training_start_date,
      training_end_date,
      CPF_company_funding_amount,
      CPF_other_employee_amount,
      training_materials_fees,
      training_session_duration,
      training_session_break_duration,
      training_preparation_fees,
      trainer_fees,
      trainee_fees,
      OPCA_amount,
      training_creation_date,
      training_modification_date,
      training_session_start_date,
      training_session_end_date,
      recap_completion_date,
      recap_registration_date,
      last_recap_status_modification_date,
      legal_category
    )) as hashkey

    -- metadata column
    ,version
    ,date_raw_load_file
    ,filepath
    ,filename
    ,to_date(curated_ingested_date) as curated_ingested_date
    ,true as current_record
    ,date_raw_load_file as record_start_date
    ,null as record_end_date
    ,current_timestamp() as record_creation_date
    ,current_timestamp() as record_modification_date
    ,'""" + runid + """' as runid 
    ,lower(trim(split(filepath,"/")[3])) as system_source 

  from vw_training_results
  
  where training_plan_year_id between """ + load_year_start + """ and """ + load_year_end

val df_results = spark.sql(query_source)

// COMMAND ----------

// MAGIC %md #### 3- Save Data

// COMMAND ----------

// DBTITLE 1,Delete existing data (Full load)
spark.sql("""
  delete from hr.training where training_plan_year_id between """ + load_year_start + """ and """ + load_year_end
)

// COMMAND ----------

// DBTITLE 1,Overwrite on table training
df_results.write.format("delta")
                .mode("append")
                .partitionBy("training_plan_year_id")
                .saveAsTable("hr.training")

// COMMAND ----------

// DBTITLE 1,Optimize table
spark.sql("OPTIMIZE hr.training")

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_training_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val inserted_records = df_results.count().toInt //count the number of records to upsert
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.training 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return Value
dbutils.notebook.exit(return_value)