// Databricks notebook source
// DBTITLE 1,Get Parameters: load_date, runid
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include notebooks
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Optimize Spark Query
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Read Data
if(spark.catalog.tableExists("recruitment.get_candidates")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_candidates")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the windowing function in order to get the last and first degree and the last degree information sent by grouping by employee_id and sort by filename desc. then create the temp view
val bydegree = Window.partitionBy("candidate_id", "degree_reference","first_year_attended").orderBy($"last_year_attended".desc, $"filename".desc, $"date_raw_load_file".desc, $"version".desc, $"school_name".asc)
val df_degree_read = spark.table("recruitment.get_candidates").withColumn("rank", rank().over(bydegree))
                                                              .where($"rank"===1)
                                                              .distinct

df_degree_read.createOrReplaceTempView("vw_df_degree_read")

// COMMAND ----------

// DBTITLE 1,Query to select only application data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """ select distinct 
                              getconcatenedstring(array(c.candidate_id,c.degree_reference,first_year_attended)) as degree_key
                             ,c.candidate_id
                             ,c.candidate_first_name as first_name
                             ,c.candidate_last_name as last_name
                             ,c.degree_reference
                             ,c.school_name
                             ,c.first_year_attended
                             ,c.last_year_attended
                             ,c.filename
                             ,c.date_raw_load_file
                             ,c.version
                             ,c.filepath
                             ,c.curated_ingested_date
                             ,true as current_record
                             ,c.date_raw_load_file as record_start_date
                             ,null as record_end_date
                             ,current_timestamp() as record_creation_date
                             ,current_timestamp() as record_modification_date
                             ,getconcatenedstring(array(c.school_name,
                                                        c.candidate_first_name,
                                                        c.candidate_last_name,
                                                        c.first_year_attended,
                                                        c.last_year_attended
                                                      )) as hashkey
                              ,'""" + runid + """' as runid
                              ,lower(trim(split(c.filepath,"/")[3])) as system_source
                              
                 from    vw_df_degree_read c

                 where   1 = 1
                   and   c.candidate_id is not null
                   and   c.degree_reference is not null
  """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source).cache()

// COMMAND ----------

// MAGIC %md ## 3- Save Data

// COMMAND ----------

// DBTITLE 1,Refresh table degree
try {
  spark.sql("FSCK REPAIR TABLE hr.degree")
}
catch {
  case e: FileNotFoundException => println("Couldn't find that file.")
  case e: IOException => println("Had an IOException trying to read that file")
}

// COMMAND ----------

// DBTITLE 1,Read the table hr degree
val recrutement_table_degree = DeltaTable.forName("hr.degree")

// COMMAND ----------

// DBTITLE 1,Rows for information updated of existing degree
val new_degree_table = df_results.as("a_updated")
                                      .join(recrutement_table_degree.toDF.as("a"), $"a.degree_key"===$"a_updated.degree_key")
                                      .where("""a.current_record = true and (a.hashkey <> a_updated.hashkey) 
                                      and a_updated.date_raw_load_file >= a.date_raw_load_file""")

// COMMAND ----------

// DBTITLE 1,Union of dataframes between degrees updated from existing information and new information from new degrees
val degree_upsert = new_degree_table.selectExpr("null as mergekey_1", "a_updated.*")
                                              .union(df_results.as("df_results").selectExpr("df_results.degree_key as mergekey_1", "*"))
val degree_upsert_distinct = degree_upsert.distinct()

// COMMAND ----------

// DBTITLE 1,Merge on table degree
recrutement_table_degree.alias("a")
  .merge(
    degree_upsert_distinct.alias("a_updated"),
    """a.degree_key = a_updated.mergekey_1""")
  .whenMatched("""a.current_record = true and a_updated.date_raw_load_file >= a.date_raw_load_file and (a.hashkey <> a_updated.hashkey)""")
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "case when date_add(a_updated.record_start_date,-1)<a.record_start_date then a.record_start_date else date_add(a_updated.record_start_date,-1) end ",
    "record_modification_date" -> "a_updated.record_modification_date",
    "runid" -> "a_updated.runid")
  )
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Script to optimize hr application
spark.sql("OPTIMIZE hr.degree")

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_degree_read.count().toInt //count the number of read records
val inserted_records = df_results.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0
df_results.unpersist()
df_degree_read.unpersist()

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.degree 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return value
dbutils.notebook.exit(return_value)