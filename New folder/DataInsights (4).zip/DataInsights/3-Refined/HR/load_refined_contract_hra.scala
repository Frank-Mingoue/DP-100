// Databricks notebook source
// DBTITLE 1,Get Parameters
val load_date = dbutils.widgets.get("load_date");
val limit_date = dbutils.widgets.get("limit_date")
val runid = dbutils.widgets.get("runid");
val flux = dbutils.widgets.get("flux")
val system_source = dbutils.widgets.get("system_source")

// COMMAND ----------

// DBTITLE 1,Import Functions and Librairies
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val dvalue = "2022-03-31"
val system_source = if (load_date <= dvalue) {"hra"} else {"adp"}

// COMMAND ----------

// DBTITLE 1,Set Up Config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")
//sc.getExecutorStorageStatus.length - 1

// COMMAND ----------

// DBTITLE 1,Set up Database Config Connections
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// MAGIC %md ##1- Read Data

// COMMAND ----------

// MAGIC %md ### HRA Contrat

// COMMAND ----------

// DBTITLE 1,Get Last partition Loaded for Contract
val path = "/employee/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + "_contrat"
val partition_date_2 = get_last_partition_file(path,load_date,"curated")
val partition_date = get_last_partition_file(path,load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Set Table contract
val table_contract = "employee." + system_source.toLowerCase() + "_contrat"

// COMMAND ----------

// DBTITLE 1,Update table Contract
if(spark.catalog.tableExists(table_contract)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_contract)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Contract data
val bycontrat = Window.partitionBy("matricule_wd","matricule_hr_access","date_deb_contrat").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_contracthra_read = spark.table(table_contract).filter($"date_raw_load_file"===partition_date)
                                                    .withColumn("rank",rank() over bycontrat)
                                                    .filter(col("rank")==="1")
                                                    .select("matricule_wd"
                                                           ,"matricule_hr_access"
                                                           ,"date_deb_contrat",
                                                            "date_fin_contrat",
                                                            "nature_contrat",
                                                            "libelle_nature_contrat",
                                                            "type_contrat",
                                                            "libelle_type_contrat",                                                                                                                                                                             "date_fin_previsionnelle",
                                                            "date_fin_periode_essai",
                                                            "motif_entree",
                                                            "libelle_motif_entree",
                                                            "motif_sortie",
                                                            "libelle_motif_sortie"
                                                            )
                                                       .withColumn("date_fin_contrat_initiale",$"date_fin_contrat")
                                                       .withColumn("date_fin_contrat", when($"date_fin_contrat".isNull,"2999-12-31").otherwise($"date_fin_contrat"))
                                                       .withColumn("date_fin_contrat",when (not ($"type_contrat" === "DI") && $"date_fin_contrat"==="2999-12-31" and not ($"date_fin_previsionnelle" === "0001-01-01"),$"date_fin_previsionnelle").otherwise($"date_fin_contrat"))
                                                                                                              .cache()


// COMMAND ----------

// MAGIC %md ### HRA SALARIE

// COMMAND ----------

// DBTITLE 1,Set table Salaries
val table_salaries = "employee." + system_source.toLowerCase() + "_salaries"

// COMMAND ----------

// DBTITLE 1,Refresh table salaries
if(spark.catalog.tableExists(table_salaries)) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE " + table_salaries)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Salaries data
val bysalarie = Window.partitionBy("matricule_wd","matricule_hr_access","population_particuliere").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_salariehra_read = spark.table(table_salaries).filter($"date_raw_load_file"===partition_date)
                                                    .withColumn("rank",rank() over bysalarie)
                                                    .filter(col("rank")==="1")
                                                    .select("matricule_wd","matricule_hr_access","population_particuliere","entree_groupe","anciennete_groupe") 

// COMMAND ----------

// MAGIC %md #### HRA TEMPS DE TRAVAIL

// COMMAND ----------

// DBTITLE 1,Set Table Temps Travail
val table_tempstravail = "employee." + system_source.toLowerCase() + "_tempstravail"

// COMMAND ----------

// DBTITLE 1,Refresh table temps travaim
if(spark.catalog.tableExists(table_tempstravail)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_tempstravail)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Data Temps travail
val bytempstravail = Window.partitionBy("matricule_wd","matricule_hr_access","date_effet_tps_contractuel").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_tempstravailhra_read = spark.table(table_tempstravail).filter($"date_raw_load_file"===partition_date).withColumn("date_fin_tps_contractuel_initiale",$"date_fin_tps_contractuel")
                                                                                                                   .withColumn("date_fin_tps_contractuel", when($"date_fin_tps_contractuel".isNull,"2999-12-31").otherwise($"date_fin_tps_contractuel"))
                                                                                                                   .withColumn("rank",rank() over bytempstravail)
                                                                                                                   .filter(col("rank")==="1")
                                                                                                                   .select("matricule_wd","matricule_hr_access"
                                                                                                                                     ,"date_effet_tps_contractuel",
                                                                                                                                      "date_fin_tps_contractuel",
                                                                                                                                      "type_temps_contractuel",
                                                                                                                                      "libelle_type_temps_contractuel",
                                                                                                                                      "code_modalite_horaire",
                                                                                                                                      "nb_heure_presence_sem",
                                                                                                                                      "nb_heure_presence_mois",
                                                                                                                                      "nb_heure_payes_sem",
                                                                                                                                      "nb_heure_payes_mois",
                                                                                                                                      "nb_jours_travailles_an",
                                                                                                                                      "taux_travail")


// COMMAND ----------

// MAGIC %md #### HRA CARRIERE

// COMMAND ----------

// DBTITLE 1,Set table Carriere
val table_carriere = "employee." + system_source.toLowerCase() + "_carriere"

// COMMAND ----------

// DBTITLE 1,Refresh table Carriere
if(spark.catalog.tableExists(table_carriere)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_carriere)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get data Carriere
val bycarriere = Window.partitionBy("matricule_wd","matricule_hr_access","date_deb_carriere").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_carrierehra_read = spark.table(table_carriere).filter($"date_raw_load_file"===partition_date).withColumn("date_fin_carriere_initiale",$"date_fin_carriere")
                                                                                                                   .withColumn("date_fin_carriere", when($"date_fin_carriere".isNull,"2999-12-31").otherwise($"date_fin_carriere"))
                                                                                                                   .withColumn("rank",rank() over bycarriere)
                                                                                                                   .filter(col("rank")==="1")
                                                                                                                   .select("matricule_wd","matricule_hr_access"
                                                                                                                                     ,"date_deb_carriere",
                                                                                                                                      "date_fin_carriere",
                                                                                                                                      "qualification",
                                                                                                                                      "libelle_qualification",
                                                                                                                                      "classification",
                                                                                                                                      "libelle_classification",
                                                                                                                                      "coefficient_base",
                                                                                                                                      "coefficient_spe",
                                                                                                                                      "regime_cotis_retraite",
                                                                                                                                     "convention_collective",
                                                                                                                                      "groupe_couture",
                                                                                                                                      "niveau_couture"
                                                                                                                                      )  //read parquet file
                                                                                                      .withColumn("convention_collective_2",$"convention_collective")

// COMMAND ----------

// MAGIC %md #### HRA TYPE D'HEURE

// COMMAND ----------

// DBTITLE 1,Set table Type Heure
val table_typeheure = "employee." + system_source.toLowerCase() + "_typeheure"

// COMMAND ----------

// DBTITLE 1,Refresh table Type Heure
if(spark.catalog.tableExists(table_typeheure)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_typeheure)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get table Type Heure
val bytypeheure = Window.partitionBy("matricule_wd","matricule_hr_access","date_deb_affection_cycle").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_typeheurehra_read = spark.table(table_typeheure).filter($"date_raw_load_file"===partition_date).withColumn("date_fin_affectation_cycle_initiale",$"date_fin_affectation_cycle")
                                                                                                                   .withColumn("date_fin_affectation_cycle", when($"date_fin_affectation_cycle".isNull,"2999-12-31").otherwise($"date_fin_affectation_cycle"))
                                                                                                                   .withColumn("rank",rank() over bytypeheure)
                                                                                                                   .filter(col("rank")==="1")
                                                                                                                   .select("matricule_wd","matricule_hr_access",
                                                                                                                                    "code_affection_cycle",
                                                                                                                                    "date_deb_affection_cycle",
                                                                                                                                    "date_fin_affectation_cycle",
                                                                                                                                    "libelle_type_heure") 

// COMMAND ----------

// MAGIC %md #### HRA SALAIRE 

// COMMAND ----------

// DBTITLE 1,Set table Salaire
val table_salaire = "employee." + system_source.toLowerCase() + "_salaire"

// COMMAND ----------

// DBTITLE 1,Refresh table Salaires
if(spark.catalog.tableExists(table_salaire)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_salaire)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get data Salaires
val bysalaire = Window.partitionBy("matricule_wd","matricule_hr_access","date_effet_remu").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_salairehra_read = spark.table(table_salaire).filter($"date_raw_load_file"===partition_date).withColumn("date_fin_remu_initiale",$"date_fin_remu")
                                                                                                                   .withColumn("date_fin_remu", when($"date_fin_remu".isNull,"2999-12-31").otherwise($"date_fin_remu"))
                                                                                                                   .withColumn("rank",rank() over bysalaire)
                                                                                                                   .filter(col("rank")==="1")
                                                                                                                   .select("matricule_wd","matricule_hr_access"
                                                                                           ,"montant_remu_base"
                                                                                            ,"date_effet_remu"
                                                                                           ,"date_fin_remu"
                                                                                            ,"montant_horaire"
                                                                                            , "montant_periode_paie"
                                                                                            ,"montant_annuel"
                                                                                             ) 


// COMMAND ----------

// MAGIC %md #### HRA ETP

// COMMAND ----------

// DBTITLE 1,Set table ETP
val table_etp = "employee." + system_source.toLowerCase() + "_etp"

// COMMAND ----------

// DBTITLE 1,Refresh table ETP
if(spark.catalog.tableExists(table_etp)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_etp)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Data ETP
val byetp = Window.partitionBy("matricule_wd","matricule_hr_access","date_deb_etp").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_ETPhra_read = spark.table(table_etp).filter($"date_raw_load_file"===partition_date).withColumn("date_fin_etp_initiale",$"date_fin_etp")
                                                                                                                   .withColumn("date_fin_etp", when($"date_fin_etp".isNull,"2999-12-31").otherwise($"date_fin_etp"))
                                                                                                                   .withColumn("rank",rank() over byetp)
                                                                                                                   .filter(col("rank")==="1")
                                                                                                                   .select("matricule_wd","matricule_hr_access"
                                                                                            ,"date_deb_etp"
                                                                                           ,"date_fin_etp"
                                                                                            ,"ETP"
                                                                                           ,"horaire_affectation"//ajout
                                                                                             )


// COMMAND ----------

// MAGIC %md #### HRA Emploi

// COMMAND ----------

// DBTITLE 1,Get Job Transco Data
val df_path = "dbfs:/mnt/raw_container/business/transco_job/*/*/*/*/"
val df_transco = spark.read.format("csv").option("sep",";").option("header",true).load(df_path)
                           .withColumn("ancien_libelle_poste", upper($"ancien_libelle_poste"))
                           .withColumn("nouveau_libelle_poste", upper($"nouveau_libelle_poste"))
                           .distinct

// COMMAND ----------

// DBTITLE 1,Set Table Emploi
val table_emploi = "employee." + system_source.toLowerCase() + "_emploi"

// COMMAND ----------

// DBTITLE 1,Refresh table Emploi
if(spark.catalog.tableExists(table_emploi)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_emploi)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Data Emploi
val byemploi = Window.partitionBy("j.matricule_wd","matricule_hr_access","date_effet_emploi").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_emploihra_read = spark.table(table_emploi).filter($"date_raw_load_file"===partition_date).as("j")
                                                          .join(df_transco.as("t"), $"j.matricule_wd" === $"t.matricule_wd" and lower($"j.libelle_emploi") === lower($"t.ancien_libelle_poste"), "left_outer")
                                                          .withColumn("libelle_emploi", when($"ancien_libelle_poste".isNotNull,$"nouveau_libelle_poste").otherwise($"libelle_emploi"))
                                                          .withColumn("date_fin_emploi_initiale",$"date_fin_emploi")
                                                                                                                   .withColumn("date_fin_emploi", when($"date_fin_emploi".isNull,"2999-12-31").otherwise($"date_fin_emploi"))
                                                                                                                   .withColumn("rank",rank() over byemploi)
                                                                                                                   .filter(col("rank")==="1")
                                                                                                                   .select("j.matricule_wd",
                                                                 "matricule_hr_access",
                                                                 "date_effet_emploi","date_fin_emploi","code_emploi","libelle_emploi","taux_emploi")


// COMMAND ----------

// MAGIC %md ##### Workday histo

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded for histo grade
val partition_date_grade = get_last_partition_file("/employee/workday/histo_grade",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Refresh table histo grade
if(spark.catalog.tableExists("employee.histo_grade")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.histo_grade")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Data histo grade
val defaultEndDate = LocalDate.parse("2999-12-31", DateTimeFormatter.ofPattern("yyyy-MM-dd"))     
val window = Window.partitionBy("employee_id").orderBy($"effective_date_from_comp".asc)
val df_histograde_read = spark.table("employee.histo_grade").where($"date_raw_load_file"===partition_date_grade)
                                                            .withColumnRenamed("compensation_grade_reference_label_2","grade")
                                                            .withColumnRenamed("compensation_grade_reference_label","grade_label")
                                                            .withColumn("end_effective_date_from_comp", 
                                                                        when ($"effective_date_from_comp".isNotNull
                                                                              ,lead($"effective_date_from_comp"-1,1,defaultEndDate).over(window))
                                                                       .otherwise(defaultEndDate))
                                                            .withColumn("grade",when($"grade".isNull , "NOT_GRADED").otherwise($"grade"))
                                                            .withColumn("matricule_hr_access",lit(null))
                                                           .select("employee_id","matricule_hr_access","grade","grade_label","effective_date_from_comp","end_effective_date_from_comp")

// COMMAND ----------

// DBTITLE 1,Get Last partition loaded for histo job
val partition_date_job = get_last_partition_file("/employee/workday/histo_job_profile",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Refresh table histo job profile
if(spark.catalog.tableExists("employee.histo_job_profile")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.histo_job_profile")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh table histo job profile
val defaultEndDate = LocalDate.parse("2999-12-31", DateTimeFormatter.ofPattern("yyyy-MM-dd"))     
val window = Window.partitionBy("employee_id").orderBy($"effective_date_from_job_change".asc)

val df_histojobprofile_read = spark.table("employee.histo_job_profile").where($"date_raw_load_file"===partition_date_job)
                                                                       .withColumn("end_effective_date_from_job_change", 
                                                                        when ($"effective_date_from_job_change".isNotNull
                                                                              ,lead($"effective_date_from_job_change"-1,1,defaultEndDate).over(window))
                                                                               .otherwise(defaultEndDate))
                                                                        .withColumn("matricule_hr_access",lit(null))
                                                                       .select("employee_id","matricule_hr_access","job_profile_name","job_profile_reference",
                                                                               "effective_date_from_job_change","end_effective_date_from_job_change")

// COMMAND ----------

// DBTITLE 1,Get Last partition loaded for histo management
val partition_date_management = get_last_partition_file("/employee/workday/histo_management_level",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Refresh table histo management
if(spark.catalog.tableExists("employee.histo_management_level")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.histo_management_level")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Data for histo management
val defaultEndDate = LocalDate.parse("2999-12-31", DateTimeFormatter.ofPattern("yyyy-MM-dd"))     
val window = Window.partitionBy("employee_id").orderBy($"effective_date_from_job_change".asc)

val df_histomanagement_read = spark.table("employee.histo_management_level").where($"date_raw_load_file"===partition_date_management)
                                                                            .withColumnRenamed("management_level_reference","management_level")
                                                                            .withColumn("end_effective_date_from_job_change", 
                                                                                when ($"effective_date_from_job_change".isNotNull
                                                                              ,lead($"effective_date_from_job_change"-1,1,defaultEndDate).over(window))
                                                                              .otherwise(defaultEndDate))
                                                                        .withColumn("effective_date_from_job_change", 
                                                                                when ($"effective_date_from_job_change".isNull
                                                                              ,lit("1999-01-01"))
                                                                              .otherwise($"effective_date_from_job_change"))
                                                                       .withColumn("matricule_hr_access",lit(null))
                                                                       .select("employee_id","matricule_hr_access","management_level","management_level_label",
                                                                               "effective_date_from_job_change","end_effective_date_from_job_change")

// COMMAND ----------

// MAGIC %md #####Powerapps

// COMMAND ----------

// DBTITLE 1,Get Data from PowerApps
spark.read.jdbc(jdbcurl, "powerapps.hra_employee", connectionproperties).select("hra_employee_id","matricule_hra","grade","band","compensation_bonus_plan","bonus_target").createOrReplaceTempView("vw_powerapps_hra_employee")
val df_powerapps = spark.table("vw_powerapps_hra_employee")


// COMMAND ----------

// MAGIC %md ##### Transco

// COMMAND ----------

// MAGIC %md ## 2-Build Datamart Contract

// COMMAND ----------

// MAGIC %md #### Union on date

// COMMAND ----------

// DBTITLE 1,Build each employee situation from different source by classifying date by order
val df_contract_situation =  df_contracthra_read.select("matricule_wd"
                                                  ,"matricule_hr_access"
                                                  ,"date_deb_contrat"                          
                                                      ).withColumnRenamed("date_deb_contrat", "record_start_date")
                                   .union(df_salairehra_read.select("matricule_wd"
                                                  ,"matricule_hr_access"
                                                  ,"date_effet_remu").withColumnRenamed("date_effet_remu",  "record_start_date")
                                       )
                                    .union(df_typeheurehra_read.select("matricule_wd"
                                             ,"matricule_hr_access"
                                             ,"date_deb_affection_cycle").withColumnRenamed("date_deb_affection_cycle",  "record_start_date")
                                       )
                                    .union(df_carrierehra_read.select("matricule_wd"
                                             ,"matricule_hr_access"
                                             ,"date_deb_carriere").withColumnRenamed("date_deb_carriere",  "record_start_date")
                                       )
                                    .union(df_tempstravailhra_read.select("matricule_wd"
                                             ,"matricule_hr_access"
                                             ,"date_effet_tps_contractuel").withColumnRenamed("date_effet_tps_contractuel",  "record_start_date")
                                       )
                                    .union(df_ETPhra_read.select("matricule_wd"
                                             ,"matricule_hr_access"
                                             ,"date_deb_etp").withColumnRenamed("date_deb_etp",  "record_start_date")
                                                                    )

                                      .union(df_emploihra_read.select("matricule_wd"
                                                                     ,"matricule_hr_access"
                                                                     ,"date_effet_emploi").withColumnRenamed("date_effet_emploi",  "record_start_date"))
                                             
                                       .union(df_histograde_read.select("employee_id","matricule_hr_access","effective_date_from_comp").
                                             withColumnRenamed("effective_date_from_comp","record_start_date").
                                             withColumnRenamed("employee_id","matricule_wd"))   
                                             
                                      .union(df_histojobprofile_read.select("employee_id","matricule_hr_access","effective_date_from_job_change").
                                             withColumnRenamed("effective_date_from_job_change","record_start_date").
                                             withColumnRenamed("employee_id","matricule_wd"))  

                                      .union(df_histomanagement_read.select("employee_id","matricule_hr_access","effective_date_from_job_change").
                                             withColumnRenamed("effective_date_from_job_change","record_start_date").
                                             withColumnRenamed("employee_id","matricule_wd"))  
                                       .distinct()
                                    

// COMMAND ----------

// DBTITLE 1,Get All matricule hra and workday from each source
val all_hra = df_contracthra_read.select("matricule_wd","matricule_hr_access")
                              .union(df_salariehra_read.select("matricule_wd","matricule_hr_access"))
                              .union(df_emploihra_read.select("matricule_wd","matricule_hr_access"))
                              .union(df_ETPhra_read.select("matricule_wd","matricule_hr_access"))
                              .union(df_salairehra_read.select("matricule_wd","matricule_hr_access"))
                              .union(df_typeheurehra_read.select("matricule_wd","matricule_hr_access"))
                              .union(df_carrierehra_read.select("matricule_wd","matricule_hr_access"))
                              .union(df_tempstravailhra_read.select("matricule_wd","matricule_hr_access")).distinct

// COMMAND ----------

// DBTITLE 1,Get matricule hra from matricule workay
val df_contract_situation_2 = df_contract_situation.as("c").join(all_hra.as("s"),$"c.matricule_wd"===$"s.matricule_wd","left")
                                                           .withColumn("matricule_hr_access_2",when($"c.matricule_hr_access".isNull,$"s.matricule_hr_access")
                                                                                             .otherwise($"c.matricule_hr_access"))
                                                            .select("c.matricule_wd","matricule_hr_access_2","record_start_date").distinct
                                                            .withColumnRenamed("matricule_hr_access_2","matricule_hr_access")

// COMMAND ----------

// DBTITLE 1,Order each date in order to build each situation
val thresholdDate = LocalDate.parse(if (flux=="quotidien") {load_date} else {limit_date}, DateTimeFormatter.ofPattern("yyyy-MM-dd"))       

val window = Window.partitionBy("matricule_wd","matricule_hr_access").orderBy($"record_start_date".desc)

val df_contract_situation_ordered = df_contract_situation_2.where($"record_start_date"<=thresholdDate).withColumn("record_end_date", lag($"record_start_date", 1, null).over(window) ).withColumn("record_end_date", to_date($"record_end_date" - expr("INTERVAL 1 DAYS"))).cache()

var df_contract_situation_ordered_2  = spark.emptyDataFrame
if (flux=="quotidien"){
    df_contract_situation_ordered_2 = df_contract_situation_ordered.where($"record_end_date".isNull)
}
else{
      df_contract_situation_ordered_2 = df_contract_situation_ordered
}

// COMMAND ----------

// MAGIC %md ##### Merge on contract

// COMMAND ----------

// DBTITLE 1,Build each situation for employee
 val df_contract = df_contract_situation_ordered_2.as("contract_situation").join(
                              df_contracthra_read.as("contract") , 
                               (($"contract_situation.matricule_wd"=== $"contract.matricule_wd"  
                                or $"contract_situation.matricule_hr_access"=== $"contract.matricule_hr_access")
                                and $"contract_situation.record_start_date" >=  $"contract.date_deb_contrat"
                                and $"contract_situation.record_start_date" <=  $"contract.date_fin_contrat"),"left"
                                 )
                               //salarie
                               .join(df_salariehra_read.as("salarie") , 
                                                     ($"contract_situation.matricule_wd"=== $"salarie.matricule_wd"  
                                                      or $"contract_situation.matricule_hr_access"=== $"salarie.matricule_hr_access"   ),"left")
                                //temps travail
                                .join(df_tempstravailhra_read.as("tempstravail") ,  
                                                      (($"contract_situation.matricule_wd"=== $"tempstravail.matricule_wd"  
                                                      or $"contract_situation.matricule_hr_access"=== $"tempstravail.matricule_hr_access"  ) 
                                                 and $"contract_situation.record_start_date" >= $"tempstravail.date_effet_tps_contractuel"
                                                 and $"contract_situation.record_start_date" <= $"tempstravail.date_fin_tps_contractuel")
                                                          , "left")
                                  //carriere
                                 .join(df_carrierehra_read.as("carriere") ,  
                                                  (($"contract_situation.matricule_wd"=== $"carriere.matricule_wd"  
                                                  or $"contract_situation.matricule_hr_access"=== $"carriere.matricule_hr_access"  ) 
                                                   and $"contract_situation.record_start_date" >= $"carriere.date_deb_carriere"
                                                   and $"contract_situation.record_start_date" <= $"carriere.date_fin_carriere" )     
                                                   , "left")
                                  //type heure
                                  .join(df_typeheurehra_read.as("typeheure") ,  
                                                   (($"contract_situation.matricule_wd"=== $"typeheure.matricule_wd"  
                                                        or $"contract_situation.matricule_hr_access"=== $"typeheure.matricule_hr_access"  ) 
                                                   and $"contract_situation.record_start_date" >= $"typeheure.date_deb_affection_cycle"
                                                   and $"contract_situation.record_start_date" <= $"typeheure.date_fin_affectation_cycle")
                                                          , "left")
                                  //salaire
                                  .join(df_salairehra_read.as("salaire") ,  
                                                   (($"contract_situation.matricule_wd"=== $"salaire.matricule_wd"  
                                                        or $"contract_situation.matricule_hr_access"=== $"salaire.matricule_hr_access"  )    
                                                   and $"contract_situation.record_start_date" >= $"salaire.date_effet_remu"
                                                   and $"contract_situation.record_start_date" <= $"salaire.date_fin_remu")
                                                          , "left")
                                //ETP
                                .join(df_ETPhra_read.as("etp") ,  
                                                   (($"contract_situation.matricule_wd"=== $"etp.matricule_wd"  
                                                        or $"contract_situation.matricule_hr_access"=== $"etp.matricule_hr_access"  )    
                                                   and $"contract_situation.record_start_date" >= $"etp.date_deb_etp"
                                                   and $"contract_situation.record_start_date" <= $"etp.date_fin_etp")
                                                          , "left")
                                 //emploie
                                  .join(df_emploihra_read.as("emploi") ,  
                                                   (($"contract_situation.matricule_wd"=== $"emploi.matricule_wd"  
                                                        or $"contract_situation.matricule_hr_access"=== $"emploi.matricule_hr_access"  )    
                                                   and $"contract_situation.record_start_date" >= $"emploi.date_effet_emploi"
                                                   and $"contract_situation.record_start_date" <= $"emploi.date_fin_emploi")
                                                          , "left")

                                  //histo grade
                                   .join(df_histograde_read.as("hg"),
                                                (($"contract_situation.matricule_wd" === $"hg.employee_id")
                                                and $"contract_situation.record_start_date" >= $"hg.effective_date_from_comp" 
                                                and $"contract_situation.record_start_date" <= $"hg.end_effective_date_from_comp")
                                                ,"left")

                                  //histo jobprofile
                                  .join(df_histojobprofile_read.as("jb"),
                                                (($"contract_situation.matricule_wd" === $"jb.employee_id" )
                                                and $"contract_situation.record_start_date" >= $"jb.effective_date_from_job_change" 
                                               and $"contract_situation.record_start_date" <= $"jb.end_effective_date_from_job_change")
                                                ,"left")


                                  //histo management
                                   .join(df_histomanagement_read.as("ml"),
                                                (($"contract_situation.matricule_wd" === $"ml.employee_id" )
                                                and $"contract_situation.record_start_date" >= $"ml.effective_date_from_job_change" 
                                                and $"contract_situation.record_start_date" <= $"ml.end_effective_date_from_job_change")
                                                ,"left")
                                //powerapps
                                .join(df_powerapps.as("powerapps")
                                      ,$"contract_situation.matricule_hr_access"=== $"powerapps.matricule_hra","left")
                                
                                //.withColumn("current_record", when($"record_end_date".isNull, true).otherwise(false))
                                
                                .withColumn("effective_job_change_date",  when(($"emploi.date_effet_emploi" >= $"jb.effective_date_from_job_change" 
                                                                                or $"jb.effective_date_from_job_change".isNull) //job_title
                                                                           and ($"emploi.date_effet_emploi" >= $"tempstravail.date_effet_tps_contractuel" 
                                                                                or $"tempstravail.date_effet_tps_contractuel".isNull)
                                                                           and ($"emploi.date_effet_emploi" >= $"carriere.date_deb_carriere" or $"carriere.date_deb_carriere".isNull)
                                                                           and ($"emploi.date_effet_emploi" >= $"ml.effective_date_from_job_change" 
                                                                                or $"ml.effective_date_from_job_change".isNull), $"emploi.date_effet_emploi")
                                                                         
                                                                          .when(($"tempstravail.date_effet_tps_contractuel" >= $"emploi.date_effet_emploi" 
                                                                                or $"emploi.date_effet_emploi".isNull) //fte
                                                                           and ($"tempstravail.date_effet_tps_contractuel" >= $"jb.effective_date_from_job_change" 
                                                                                or $"jb.effective_date_from_job_change".isNull)
                                                                           and ($"tempstravail.date_effet_tps_contractuel" >= $"carriere.date_deb_carriere" 
                                                                                or $"carriere.date_deb_carriere".isNull)
                                                                           and ($"tempstravail.date_effet_tps_contractuel" >= $"ml.effective_date_from_job_change" 
                                                                                or $"ml.effective_date_from_job_change".isNull), $"tempstravail.date_effet_tps_contractuel")
                                                                        
                                                                         .when(($"ml.effective_date_from_job_change" >= $"emploi.date_effet_emploi" 
                                                                                or $"emploi.date_effet_emploi".isNull) //band
                                                                           and ($"ml.effective_date_from_job_change" >= $"jb.effective_date_from_job_change" 
                                                                                or $"jb.effective_date_from_job_change".isNull)
                                                                           and ($"ml.effective_date_from_job_change" >= $"carriere.date_deb_carriere" 
                                                                                or $"carriere.date_deb_carriere".isNull)
                                                                           and ($"ml.effective_date_from_job_change" >= $"tempstravail.date_effet_tps_contractuel" 
                                                                                or $"tempstravail.date_effet_tps_contractuel".isNull), $"ml.effective_date_from_job_change")
                                                                        
                                                                        .when(($"carriere.date_deb_carriere" >= $"emploi.date_effet_emploi" or $"emploi.date_effet_emploi".isNull)//csp
                                                                          and ($"carriere.date_deb_carriere" >= $"jb.effective_date_from_job_change" 
                                                                               or $"jb.effective_date_from_job_change".isNull)
                                                                          and ($"carriere.date_deb_carriere" >= $"ml.effective_date_from_job_change" 
                                                                               or $"ml.effective_date_from_job_change".isNull)
                                                                          and ($"carriere.date_deb_carriere" >= $"tempstravail.date_effet_tps_contractuel"
                                                                               or $"tempstravail.date_effet_tps_contractuel".isNull), $"carriere.date_deb_carriere")
                                                                      
                                                                        .otherwise($"jb.effective_date_from_job_change"))  //job_profile

                                                                   .withColumn("effective_compensation_change_date",  
                                                                               when($"hg.effective_date_from_comp" > $"salaire.date_effet_remu" or $"salaire.date_effet_remu".isNull,
                                                                                    $"hg.effective_date_from_comp") //grade et salaire
                                                                               .otherwise($"salaire.date_effet_remu")) 
                                         // .where($"contract.matricule_hr_access".isNotNull)
                                  
df_contracthra_read.unpersist()
df_contract_situation_ordered.unpersist()

// COMMAND ----------

// DBTITLE 1,Get transco Values
spark.read.jdbc(jdbcurl, "dbo.param_transco_ref",connectionproperties).createOrReplaceTempView("vw_dbo_param_transco_ref")
val df_transco = spark.table("vw_dbo_param_transco_ref").na.fill("Nothing")

// COMMAND ----------

// DBTITLE 1,Get Transco Data
val df_contract_transco = gettransco2(df_transco,df_contract,system_source,"workday")

// COMMAND ----------

// DBTITLE 1,Filter Data based on loading type
val defaultEndDate = LocalDate.parse("2999-12-31", DateTimeFormatter.ofPattern("yyyy-MM-dd"))     
val daily_file = "daily_file_" + system_source.toLowerCase()

var df_contract_insert = spark.emptyDataFrame
if (flux=="quotidien"){
  df_contract_insert = df_contract_transco._1.withColumn("grade2",when($"powerapps.grade".isNull,$"hg.grade").otherwise($"powerapps.grade"))
                    .select("contract_situation.matricule_wd"
                     ,"contract_situation.matricule_hr_access"
                     ,"record_start_date"
                     ,"record_end_date"
                     ,"date_deb_contrat",
                    "date_fin_contrat",
                    "contract_type",
                    "contract_type_label",
                    "type_contrat",
                    "libelle_type_contrat",
                    "date_fin_previsionnelle",
                    "date_fin_periode_essai",
                    "motif_entree",
                    "event_classification_subcategory_label",
                    "motif_sortie",
                    "local_termination_reason",
                     "entree_groupe",
                      "population_particuliere",
                     "date_effet_tps_contractuel",
                      "date_fin_tps_contractuel",
                      "time_type",
                      "time_type_label",
                      "code_modalite_horaire",
                      "nb_heure_presence_sem",
                      "nb_heure_presence_mois",
                      "nb_heure_payes_sem",
                      "nb_heure_payes_mois",
                      "nb_jours_travailles_an",
                      "date_deb_carriere",
                      "date_fin_carriere",
                      "professional_category_reference",
                      "professional_category_name",
                      "classification",
                      "libelle_classification",
                      "coefficient_base",
                      "coefficient_spe",
                      "regime_cotis_retraite",
                     "collective_agreement_reference_label",
                     "collective_agreement_reference",
                      "groupe_couture",
                      "niveau_couture",
                      "code_affection_cycle",
                      "date_deb_affection_cycle",
                      "date_fin_affectation_cycle",
                      "libelle_type_heure",
                     "montant_remu_base"
                      ,"date_effet_remu"
                     ,"date_fin_remu"
                      ,"montant_horaire"
                      , "montant_periode_paie"
                      ,"montant_annuel",
                     "grade2",
                    "etp",
                    //emploi
                    "date_effet_emploi",
                    "date_fin_emploi",
                    "code_emploi",
                    "libelle_emploi",
                    "taux_travail",
                    //powerapps,
                    "band",
                    "compensation_bonus_plan",
                   "bonus_target",
                 //  "ADD"
                   "anciennete_groupe",
                   "management_level",
                   "job_profile_reference",  
                   "effective_job_change_date",
                   "effective_compensation_change_date"                                
                    )
              .withColumn("contract_end_date",when($"date_fin_contrat"===defaultEndDate,null).otherwise($"date_fin_contrat"))
              .withColumn("fte", col("taux_travail")/1)
              .withColumn("current_record", when($"record_end_date".isNull, true).otherwise(false))
              .withColumn("date_raw_load_file",lit(partition_date_2))
              .withColumn("record_start_date",to_date(lit(partition_date_2)))
              .withColumn("filename",lit(daily_file))
              .withColumnRenamed("grade2","grade")              
              .withColumn("anciennete_groupe", when($"anciennete_groupe".isNull or $"anciennete_groupe" > $"date_deb_contrat" or $"anciennete_groupe" === to_date(lit("0001-01-01")),$"date_deb_contrat" ).otherwise($"anciennete_groupe"))
              .distinct
}
else{
  df_contract_insert = df_contract_transco._1.select("contract_situation.matricule_wd"
                     ,"contract_situation.matricule_hr_access"
                     ,"record_start_date"
                     ,"record_end_date"
                     ,"date_deb_contrat",
                    "date_fin_contrat",
                    "contract_type",
                    "contract_type_label",
                    "type_contrat",
                    "libelle_type_contrat",
                    "date_fin_previsionnelle",
                    "date_fin_periode_essai",
                    "motif_entree",
                    "event_classification_subcategory_label",
                    "motif_sortie",
                    "local_termination_reason",
                     "entree_groupe",
                      "population_particuliere",
                     "date_effet_tps_contractuel",
                      "date_fin_tps_contractuel",
                      "time_type",
                      "time_type_label",
                      "code_modalite_horaire",
                      "nb_heure_presence_sem",
                      "nb_heure_presence_mois",
                      "nb_heure_payes_sem",
                      "nb_heure_payes_mois",
                      "nb_jours_travailles_an",
                      "date_deb_carriere",
                      "date_fin_carriere",
                      "professional_category_reference",
                      "professional_category_name",
                      "classification",
                      "libelle_classification",
                      "coefficient_base",
                      "coefficient_spe",
                      "regime_cotis_retraite",
                     "collective_agreement_reference_label",
                     "collective_agreement_reference",
                      "groupe_couture",
                      "niveau_couture",
                      "code_affection_cycle",
                      "date_deb_affection_cycle",
                      "date_fin_affectation_cycle",
                      "libelle_type_heure",
                     "montant_remu_base"
                      ,"date_effet_remu"
                     ,"date_fin_remu"
                      ,"montant_horaire"
                      , "montant_periode_paie"
                      ,"montant_annuel",
                     "hg.grade",
                    "etp",
                    //emploi
                    "date_effet_emploi",
                    "date_fin_emploi",
                    "code_emploi",
                    "libelle_emploi",
                    "taux_travail",
                    //powerapps,
                    "band",
                    "compensation_bonus_plan",
                   "bonus_target",
                   //"ADD"
                   "anciennete_groupe",
                    "management_level",
                   "job_profile_reference",     
                   "effective_job_change_date",
                   "effective_compensation_change_date"                            
                    )
              .withColumn("contract_end_date",when($"date_fin_contrat"===defaultEndDate,null).otherwise($"date_fin_contrat"))
              .withColumn("fte", col("taux_travail")/1)
              .withColumn("current_record", when($"record_end_date".isNull, true).otherwise(false))
              .withColumn("date_raw_load_file",to_date(lit("2021-01-01")))  
              .withColumn("filename",lit("histo_file"))
              .withColumn("anciennete_groupe", when($"anciennete_groupe".isNull or $"anciennete_groupe" > $"date_deb_contrat" or $"anciennete_groupe" === to_date(lit("0001-01-01")),$"date_deb_contrat" ).otherwise($"anciennete_groupe"))
             
              .distinct
       // .createOrReplaceTempView("vw_contract_insert")
}
df_contract_insert.createOrReplaceTempView("vw_contract_insert")

// COMMAND ----------

// DBTITLE 1,Build Contracts Query
val query_source = """select distinct                              
                             getconcatenedstring(array(c.matricule_wd,
                                                       c.matricule_hr_access
                                                       )) as contract_key
                            ,c.matricule_wd as employee_id
                            ,c.matricule_hr_access as france_payroll_id     
                            ,sha2(getconcatenedstring(array(c.matricule_wd, c.matricule_hr_access)),256) as employee_code
                            ,"Employee" as worker_type
                            ,c.date_effet_emploi as position_start_date
                            ,c.entree_groupe as hire_date
                            ,c.anciennete_groupe as continous_service_date
                            ,c.entree_groupe as original_hire_date
                            ,c.entree_groupe as effective_hire_date
                            ,c.effective_job_change_date 
                            ,null as first_contract_type
                            ,null as first_contract_type_label
                            ,c.collective_agreement_reference
                            ,c.collective_agreement_reference_label
                            ,c.groupe_couture as collective_agreement_group
                            ,c.niveau_couture as collective_agreement_level
                            ,c.date_deb_contrat as contract_start_date
                            ,c.contract_end_date
                            ,c.contract_type as contract_type
                            ,c.contract_type_label          
                            ,c.coefficient_base as coefficient 
                            ,c.coefficient_base as coefficient_label
                            ,c.motif_entree as event_classification_subcategory
                            ,c.event_classification_subcategory_label
                            ,c.local_termination_reason as local_termination_reason
                            ,c.fte
                            ,c.time_type
                            ,c.time_type_label
                            ,null/1 as paidfte
                            ,c.montant_annuel as total_base_pay 
                            ,null as primary_comp_basis_amount
                            ,null as period_salary
                            ,null as period_salary_label
                            ,c.montant_periode_paie as period_salary_amount
                            ,null as compensation_merit_plan
                            ,null as compensation_merit_plan_label
                            ,null as compensation_change_reason
                            ,null as compensation_change_subreason
                            ,c.compensation_bonus_plan
                            ,c.bonus_target
                            ,null as bonus_plan_name
                            ,null as additional_job_classifications
                            ,null as additional_job_classifications_label
                            ,null as compensation_currency
                            ,null as default_weekly_hours
                            ,null as scheduled_weekly_hours
                            ,c.effective_compensation_change_date 
                            ,null as foreign_travel_indemnity_percent
                            ,null as foreign_travel_indemnity_amount
                            ,null as effective_suporg_change_date
                            ,case when c.professional_category_reference IS NULL then "nothing" else professional_category_reference end as csp
                            ,upper(c.libelle_emploi) as job_title
                            ,c.grade
                            ,c.management_level
                            ,c.job_profile_reference
                            ,sha2(getconcatenedstring(array(
                                                             lower(c.libelle_emploi)
                                                            ,c.grade
                                                            ,c.management_level
                                                            ,c.job_profile_reference
                                                            )),256) as job_code
                                                            
                            ,sha2(c.professional_category_reference,256) as csp_code
                            
                            ,sha2(getconcatenedstring(array(c.contract_type  
                                                            ,"Employee"
                                                            ,c.collective_agreement_reference
                                                            ,c.groupe_couture
                                                            ,c.niveau_couture
                                                            ,c.coefficient_base
                                                            )),256) as contract_code 
                                                             
                             ,sha2(getconcatenedstring(array(
                                                             c.time_type
                                                            ,c.fte/1
                                                            ,null/1
                                                             )),256) as worker_rate_code
                                                             
                            ,sha2(c.motif_entree,256) as mobility_in_code 
                                                             
                            ,sha2(c.local_termination_reason,256) as mobility_out_code 
                                                              
                            
                            ,null as compensation_change_code
                            
                            ,null as compensation_merit_plan_code 
                            
                            ,null as compensation_bonus_plan_code 
                            
                            ,sha2(getconcatenedstring(array( 
                                                            c.date_effet_emploi
                                                            ,c.anciennete_groupe
                                                            ,c.date_deb_contrat
                                                            ,c.contract_end_date
                                                             ,c.contract_type)),256) as info_dates_code

                             ,sha2(getconcatenedstring(array(c.entree_groupe
                                                            ,c.contract_end_date)),256) as in_out_dates_code
                            
                            ,sha2(getconcatenedstring(array( 
                                                             c.date_deb_contrat
                                                            ,c.contract_end_date
                                                            ,c.contract_type)),256) as contract_dates_code
                            
                            ,sha2(getconcatenedstring(array( 
                                                             c.date_effet_emploi
                                                            ,c.anciennete_groupe)),256) as company_dates_code
                                                            
                            ,sha2(c.contract_type,256) as contract_type_code 
                            
                            ,sha2(getconcatenedstring(array( "Employee"
                                                            ,c.collective_agreement_reference
                                                            ,c.groupe_couture
                                                            ,c.niveau_couture
                                                            ,c.coefficient_base
                                                            )),256) as collective_agreement_code
                            
                            ,sha2(c.grade,256) as grade_code
                            
                            ,sha2(getconcatenedstring(array(
                                                             lower(c.libelle_emploi)
                                                            ,c.management_level
                                                            ,c.job_profile_reference
                                                            )),256) as job_title_code
                                                            
                            ,c.population_particuliere  as special_population                 
                            ,null as probation_start_date
                            ,null as probation_end_date
                            ,null as contract_reason
                            ,null as employee_visibility_date
                            ,null as prime_co_percent
                            ,null as prime_exp_percent
                            ,null as probation_dates_code
                            ,null as contract_reason_code             
                            ,1 as version
                            ,c.date_raw_load_file
                            ,"histo_file" as filepath
                            ,filename as filename
                            ,current_date() as curated_ingested_date
                            ,current_record
                            ,c.record_start_date
                            ,c.record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date                               
                            ,getconcatenedstring(array(    
                                                       "Employee"
                                                      ,c.date_effet_emploi
                                                      ,c.entree_groupe
                                                      ,c.anciennete_groupe
                                                      ,c.entree_groupe
                                                      ,c.entree_groupe
                                                      ,c.effective_job_change_date 
                                                      ,null
                                                      ,null
                                                      ,c.collective_agreement_reference
                                                      ,c.collective_agreement_reference_label
                                                      ,c.groupe_couture
                                                      ,c.niveau_couture
                                                      ,c.date_deb_contrat
                                                      ,c.contract_end_date
                                                      ,c.contract_type
                                                      ,c.contract_type_label          
                                                      ,c.coefficient_base
                                                      ,c.coefficient_base
                                                      ,c.motif_entree
                                                      ,c.event_classification_subcategory_label
                                                      ,c.local_termination_reason
                                                      ,c.fte
                                                      ,c.time_type
                                                      ,c.time_type_label
                                                      ,null
                                                      ,c.montant_annuel
                                                      ,null
                                                      ,null
                                                      ,null
                                                      ,c.montant_periode_paie
                                                      ,null
                                                      ,null
                                                      ,null
                                                      ,null
                                                      ,c.compensation_bonus_plan
                                                      ,c.bonus_target
                                                      ,null
                                                      ,null
                                                      ,null
                                                      ,null
                                                      ,null
                                                      ,null
                                                      ,c.effective_compensation_change_date
                                                      ,null
                                                      ,null
                                                      ,null
                                                      ,case when c.professional_category_reference IS NULL then "nothing" else professional_category_reference end
                                                      ,upper(c.libelle_emploi)
                                                      ,c.grade
                                                      ,c.management_level
                                                      ,c.job_profile_reference
                                                           )) as hashkey 
                           ,'""" + runid + """' as runid
                           ,'""" + system_source + """' as system_source
               from    vw_contract_insert c
                       
               where   1 = 1
                 and   (c.matricule_wd is not null or c.matricule_hr_access is not null)
              
                                                            
               """

// COMMAND ----------

// DBTITLE 1,Get Query results
val df_results_query = spark.sql(query_source).filter($"contract_start_date".isNotNull).cache()


// COMMAND ----------

// DBTITLE 1,Query to create the target table contracts
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }

// COMMAND ----------

// DBTITLE 1,Create the table contracts after drop the table if exists and store data and table structure on contracts_table
val contract_table = DeltaTable.forName("hr.contract")

// COMMAND ----------

// DBTITLE 1,Merge on table contracts
if (flux=="quotidien"){
  val df_results = df_results_query.where($"special_population"===1)
  val newcontract = df_results.as("contract_updated")
  .join(contract_table.toDF.as("contract"), $"contract.france_payroll_id"===$"contract_updated.france_payroll_id" or
                                          $"contract.employee_id"===$"contract_updated.employee_id")
  .where("""contract.current_record = true and (contract_updated.hashkey <> contract.hashkey) and contract_updated.date_raw_load_file >= contract.date_raw_load_file""")
  
  val contract_upsert = newcontract
  .selectExpr("null as mergekey_1","null as mergekey_2", "contract_updated.*")   // Rows for 1.
  .union(
    df_results.as("df_results").selectExpr("df_results.employee_id as mergekey_1",
                                           "df_results.france_payroll_id as mergekey_2",
                                           "*")  // Rows for 2.
  )
  //remove duplicate
  val contract_upsert_distinct = contract_upsert.distinct()
  
  contract_table.alias("t")
  .merge(
    contract_upsert_distinct.alias("s"),
    """t.employee_id = s.mergekey_1
    or t.france_payroll_id = s.mergekey_2 """)
  .whenMatched("""t.current_record = true and (t.hashkey <> s.hashkey) and s.date_raw_load_file > t.date_raw_load_file """)
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "date_add(s.record_start_date,-1)",
    "record_modification_date" -> "s.record_modification_date",
    "runid" -> "s.runid")
  )
  .whenNotMatched().insertAll()
  .execute()
}

else{
    
  contract_table.alias("t")
    .merge(
      df_results_query.alias("s"),
      """t.employee_id=s.employee_id or 
      s.france_payroll_id=t.france_payroll_id""")
    .whenNotMatched().insertAll()
    .execute()
}

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE hr.contract")

// COMMAND ----------

// DBTITLE 1,Get Statistics
val read_records = df_contracthra_read.count().toInt //count the number of read records
val inserted_records = df_results_query.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0
df_results_query.unpersist()

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.contract 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)