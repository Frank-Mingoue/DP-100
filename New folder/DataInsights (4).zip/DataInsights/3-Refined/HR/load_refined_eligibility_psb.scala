// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include Notebook Containing Common Functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760 ")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Test if the source path exists
if(spark.catalog.tableExists("pay.eligibilite_psb")) 
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.eligibilite_psb")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Set Last Load Partition Loaded
val partition_eligibilite_psb = get_last_partition_file("/pay/business/eligibilite_psb",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source after test if it exists and count number of read records
val byeligibility_psb = Window.partitionBy("matricule_hra","matricule_workday","year").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_eligibility_psb_read = spark.table("pay.eligibilite_psb")
                                        //.filter("date_raw_load_file = '" + partition_eligibilite_psb + "'")
                                        .withColumn("year", regexp_replace(col("periode"), "-","").substr(0, 4))   //read parquet file
                                        .withColumn("rank",rank() over byeligibility_psb).filter(col("rank")==="1") //path to read parquet files
                                        .withColumn("is_eligible",lit("oui"))

df_eligibility_psb_read.cache()  //put the dataframe on the cache
df_eligibility_psb_read.createOrReplaceTempView("vw_eligibility_psb") // create a temp view


// COMMAND ----------

// DBTITLE 1,Refresh table eligibility_psb
  try {
    spark.sql("FSCK REPAIR TABLE hr.eligibility_psb")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }

// COMMAND ----------

// DBTITLE 1,Get existing year and date_raw_load_file
val eligibility_psb_table = DeltaTable.forName("hr.eligibility_psb").toDF.select("year","date_raw_load_file").distinct
eligibility_psb_table.createOrReplaceTempView("vw_eligibility_psb_table")

// COMMAND ----------

// DBTITLE 1,Query to select only job data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column

val query_source = """select distinct
                            getconcatenedstring(array(ep.matricule_hra
                                                     ,ep.matricule_workday
                                                     ,ep.year
                                                           )) as eligibility_psb_key
                            ,ep.matricule_workday as employee_id
                            ,ep.matricule_hra as france_payroll_id
                            ,sha2(getconcatenedstring(array(ep.matricule_workday, ep.matricule_hra)),256) as employee_code
                            ,ep.nom as last_name
                            ,ep.prenom as first_name
                            ,to_date(ep.periode) as period
                            ,ep.year
                            ,ep.is_eligible
                            ,ep.filename
                            ,ep.date_raw_load_file
                            ,ep.version
                            ,ep.filepath
                            ,to_date(ep.curated_ingested_date) as curated_ingested_date
                            ,true as current_record
                            ,ep.date_raw_load_file as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(ep.nom,ep.prenom,ep.is_eligible)) as hashkey 
                           ,'""" + runid + """' as runid 
                           ,lower(trim(split(ep.filepath,"/")[3])) as system_source
               from    vw_eligibility_psb ep
                       left join vw_eligibility_psb_table at on at.year = ep.year
               where   1=1
                       and (ep.matricule_workday is not null or ep.matricule_hra is not null)
                       and (ep.date_raw_load_file > at.date_raw_load_file or at.date_raw_load_file is null)
            """

// COMMAND ----------

// DBTITLE 1,Get query data
val df_results = spark.sql(query_source).cache
df_results.createOrReplaceTempView("vw_eligibility_psb_source")
val inserted_records = df_results.count().toInt //count the number of records to upsert

// COMMAND ----------

// DBTITLE 1,Delete Old Data
spark.sql( """DELETE FROM hr.eligibility_psb as t
WHERE EXISTS(
SELECT 1 FROM vw_eligibility_psb_source
WHERE t.year = vw_eligibility_psb_source.year)""")

// COMMAND ----------

// DBTITLE 1,Inserted new data
df_results.write.format("delta")
                .mode("append")
                .partitionBy("year")
                .saveAsTable("hr.eligibility_psb")

// COMMAND ----------

// DBTITLE 1,Optimize table 
spark.sql("OPTIMIZE hr.eligibility_psb")

// COMMAND ----------

// DBTITLE 1,Statistics on rows read and inserted
val read_records = df_eligibility_psb_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_eligibility_psb_read.unpersist
df_results.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.eligibility_psb 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)