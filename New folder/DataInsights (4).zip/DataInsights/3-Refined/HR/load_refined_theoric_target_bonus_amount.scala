// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include Notebook Containing Common Functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Configurations
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760 ")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Test if the source path exists
if(spark.catalog.tableExists("pay.montant_prime_objectif_theorique")) 
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.montant_prime_objectif_theorique")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Last partition Date
val partition_montant_prime_objectif_theorique = get_last_partition_file("/pay/business/montant_prime_objectif_theorique",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source after test if it exists and count number of read records
val bymontant_prime_objectif_theorique = Window.partitionBy("matricule_hra","matricule_workday","period_month").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_montant_prime_objectif_theorique_read = spark.table("pay.montant_prime_objectif_theorique")
                                                          //.filter("date_raw_load_file = '" + partition_montant_prime_objectif_theorique + "'")
                                                          .withColumn("period_month", regexp_replace(col("periode"), "-","").substr(0, 6))   //read parquet file
                                                          .withColumn("rank",rank() over bymontant_prime_objectif_theorique).filter(col("rank")==="1") //path to read parquet files

df_montant_prime_objectif_theorique_read.cache()  //put the dataframe on the cache
df_montant_prime_objectif_theorique_read.createOrReplaceTempView("vw_theoric_target_bonus_amount") // create a temp view

// COMMAND ----------

// DBTITLE 1,Refresh Delta table hr.theoric_target_bonus_amount
try {
    spark.sql("FSCK REPAIR TABLE hr.theoric_target_bonus_amount")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }

// COMMAND ----------

// DBTITLE 1,Get the period_month and date_raw_load_file inserted
val theoric_target_bonus_amount_table = DeltaTable.forName("hr.theoric_target_bonus_amount").toDF.select("period_month","date_raw_load_file").distinct
theoric_target_bonus_amount_table.createOrReplaceTempView("vw_theoric_target_bonus_amount_table")

// COMMAND ----------

// DBTITLE 1,Query to select only job data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column

val query_source = """select distinct
                            getconcatenedstring(array(mp.matricule_hra
                                                     ,mp.matricule_workday
                                                     ,mp.period_month
                                                           )) as theoric_target_bonus_amount_key
                            ,mp.matricule_workday as employee_id
                            ,mp.matricule_hra as france_payroll_id
                            ,sha2(getconcatenedstring(array(mp.matricule_workday, mp.matricule_hra)),256) as employee_code
                            ,mp.nom as last_name
                            ,mp.prenom as first_name
                            ,mp.montant_prime_objectif_theorique as theoric_target_bonus_amount
                            ,to_date(mp.periode) as period
                            ,mp.period_month
                            ,mp.filename
                            ,mp.date_raw_load_file
                            ,mp.version as version
                            ,mp.filepath
                            ,to_date(mp.curated_ingested_date) as curated_ingested_date
                            ,true as current_record
                            ,mp.date_raw_load_file as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(mp.nom,mp.prenom,mp.montant_prime_objectif_theorique)) as hashkey 
                           ,'""" + runid + """' as runid
                           ,lower(trim(split(mp.filepath,"/")[3])) as system_source
               from    vw_theoric_target_bonus_amount mp
                       left join vw_theoric_target_bonus_amount_table at on at.period_month = mp.period_month
               where   1=1
                       and (mp.matricule_workday is not null or mp.matricule_hra is not null)
                       and (mp.date_raw_load_file > at.date_raw_load_file or at.date_raw_load_file is null)
            """

// COMMAND ----------

// DBTITLE 1,Read Query Data
val df_results = spark.sql(query_source).cache
df_results.createOrReplaceTempView("vw_theoric_target_bonus_amount_source")
val inserted_records = df_results.count().toInt //count the number of records to upsert

// COMMAND ----------

// DBTITLE 1,Delete from the target table data where the month exists
spark.sql( """DELETE FROM hr.theoric_target_bonus_amount as t
WHERE EXISTS(
SELECT 1 FROM vw_theoric_target_bonus_amount_source
WHERE t.period_month = vw_theoric_target_bonus_amount_source.period_month)""")

// COMMAND ----------

// DBTITLE 1,Insert into the target table
df_results.write.format("delta")
                .mode("append")
                .partitionBy("period_month")
                .saveAsTable("hr.theoric_target_bonus_amount")

// COMMAND ----------

// DBTITLE 1,Script to optimize storage and read of delta files
spark.sql("OPTIMIZE hr.theoric_target_bonus_amount")

// COMMAND ----------

// DBTITLE 1,Statistics on records read and inserted
val read_records = df_montant_prime_objectif_theorique_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_montant_prime_objectif_theorique_read.unpersist
df_results.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.theoric_target_bonus_amount 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)