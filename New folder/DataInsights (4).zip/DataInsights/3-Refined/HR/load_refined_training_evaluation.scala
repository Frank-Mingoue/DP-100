// Databricks notebook source
// DBTITLE 1,Get Parameters
val load_date = dbutils.widgets.get("load_date")
val runid = dbutils.widgets.get("runid")

// COMMAND ----------

// DBTITLE 1,Import functions and librairies
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set up configurations
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Training Evaluation Table
if(spark.catalog.tableExists("training.evaluation")) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE training.evaluation")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// MAGIC %md ### 1- Read Data

// COMMAND ----------

// DBTITLE 1,Last partition
val partition_training = get_last_partition_file("/training/cornerstone/cornerstone_evaluation_formation",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read Data from Curated
val df_training_read =  spark.table("training.evaluation").filter("date_raw_load_file = '" + partition_training + "'")
  // Rename Columns
  .withColumnRenamed("id_utilisateur","employee_id")
  .withColumnRenamed("type_formation","training_type")
  .withColumnRenamed("id_objet_formation","training_object_id")
  .withColumnRenamed("titre_formation","training_label")
  .withColumnRenamed("question","evaluation_question")
  .withColumnRenamed("reponse","evaluation_response")
  
df_training_read.cache()  //put the dataframe ont he cache
df_training_read.createOrReplaceTempView("vw_training_curated") // create a temp view

// COMMAND ----------

// DBTITLE 1,Get Data
val query_source = """
  select 

    employee_id,
    training_type,
    training_object_id,
    training_label,
    evaluation_question,
    evaluation_response



    -- technical codes

    ,getconcatenedstring(array(
      employee_id
      ,training_object_id
      ,evaluation_question
    )) as training_evaluation_key 

    ,getconcatenedstring(array(
      training_label,
      evaluation_response
    )) as hashkey

    -- metadata column
    ,version
    ,date_raw_load_file
    ,filepath
    ,filename
    ,to_date(curated_ingested_date) as curated_ingested_date
    ,true as current_record
    ,date_raw_load_file as record_start_date
    ,null as record_end_date
    ,current_timestamp() as record_creation_date
    ,current_timestamp() as record_modification_date
    ,'""" + runid + """' as runid 
    ,lower(trim(split(filepath,"/")[3])) as system_source 
    
  from vw_training_curated

"""
val df_results = spark.sql(query_source)
//display(df_results)

// COMMAND ----------

// MAGIC %md #### 3- Save Data

// COMMAND ----------

// DBTITLE 1,Delete existing data (Full load)
spark.sql("""
delete from hr.training_evaluation
""")

// COMMAND ----------

// DBTITLE 1,Overwrite on table training
df_results.write.format("delta")
                .mode("append")
                .partitionBy("training_object_id")
                .saveAsTable("hr.training_evaluation")

// COMMAND ----------

// DBTITLE 1,Optimize table
spark.sql("OPTIMIZE hr.training_evaluation")

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_training_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val inserted_records = df_results.count().toInt //count the number of records to upsert
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.training_evaluation 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return Statistics Values
dbutils.notebook.exit(return_value)