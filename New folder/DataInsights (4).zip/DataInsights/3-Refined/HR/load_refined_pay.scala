// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source system, entity, domain and subdomain
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val system_source = dbutils.widgets.get("system_source")

// COMMAND ----------

// DBTITLE 1,Include notebook containing common functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val dvalue = "2022-03-31"
val system_source = if (load_date <= dvalue) {"hra"} else {"adp"}

// COMMAND ----------

// DBTITLE 1,Set up Config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760 ")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "50") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Set up table paie
val table_paie = "pay." + system_source.toLowerCase() + "_paie"

// COMMAND ----------

// DBTITLE 1,Refresh table hra_paie
if(spark.catalog.tableExists(table_paie)) 
{
  try {
      spark.sql("MSCK REPAIR TABLE " + table_paie)
    }
    catch {
      case e: FileNotFoundException => println("Couldn't find that file.")
      case e: IOException => println("Had an IOException trying to read that file")
    }
}

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded
val path_paie = "/pay/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + "_paie"
val partition_hra_paie = get_last_partition_file(path_paie,load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source after test if it exists and count number of read records
val byhra_paie = Window.partitionBy("matricule_hr_access","matricule_wd","period_paie","num_pac").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_hrapaie_read = spark.table(table_paie).filter("date_raw_load_file = '" + partition_hra_paie + "'")
                                                 .withColumn("num_pac", when($"num_pac".isNull,"hra").otherwise($"num_pac"))
                                                 .withColumn("paiezad", when($"paiezad".isNull,lit(system_source)).otherwise($"paiezad"))
                                                 .withColumn("rank",rank() over byhra_paie).filter(col("rank")==="1") //path to read parquet files
                                                 .withColumn("period_paie_month", regexp_replace(col("period_paie"), "MT",""))

                                                  /*fix wrong matricule workday and hra*/
                                                 .withColumn("matricule_wd",when($"matricule_wd" === "W200094100",lit("W20094100")).otherwise($"matricule_wd"))
                                                 .withColumn("matricule_hr_access",when($"matricule_hr_access" === "019370019370",lit("019370")).otherwise($"matricule_hr_access"))
                                                 .selectExpr(
                                                          "matricule_hr_access"
                                                         ,"matricule_wd"
                                                         ,"period_paie"
                                                         ,"periode_valorisation"
                                                         ,"code_rubr"
                                                         ,"compte_comptable"
                                                         ,"base"
                                                         ,"montant_salarial"
                                                         ,"montant_patronal"
                                                         ,"paiezad"
                                                         ,"num_pac"
                                                         ,"period_paie_month"
                                                         ,"filepath"
                                                         ,"version"
                                                         ,"date_raw_load_file"
                                                         ,"filename"
                                                         ,"curated_ingested_date"
                                                 ).distinct   //read parquet file

df_hrapaie_read.createOrReplaceTempView("vw_hrapaie") // create a temp view
df_hrapaie_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,unpivot payroll code
val df_hrapaie_read_unpivot = df_hrapaie_read.selectExpr("matricule_hr_access",
                                                          "matricule_wd",
                                                         "period_paie",
                                                         "periode_valorisation",
                                                         "code_rubr",
                                                         "compte_comptable",
                                                         "base",
                                                         "montant_salarial",
                                                         "montant_patronal",
                                                         "paiezad as payzad",
                                                         "num_pac",
                                                         "period_paie_month",
                                                         "date_raw_load_file",
                                                         "filepath",
                                                         "version", 
                                                         "filename",
                                                         "curated_ingested_date",
                                                         "stack(2, 'montant_salarial',montant_salarial ,'montant_patronal', montant_patronal) as (type, montant)" )
                                                          .withColumn("code_rubr",  when($"type" === "montant_salarial", concat($"code_rubr",lit("S")))
                                                                      .when($"type" === "montant_patronal", concat($"code_rubr",lit("P"))))
                                                          .withColumn("montant_salarial", when($"type" === "montant_salarial", $"montant_salarial" ).otherwise(null))
                                                          .withColumn("montant_patronal", when($"type" === "montant_patronal", $"montant_patronal" ).otherwise(null))
                                                          .drop($"type")
                                                          .drop($"montant")
                                                          .distinct

df_hrapaie_read_unpivot.cache
df_hrapaie_read_unpivot.createOrReplaceTempView("vw_result")

// COMMAND ----------

// DBTITLE 1,Refresh table pay
if(spark.catalog.tableExists("hr.pay")) 
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.pay")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get the existing period_pay_month and date_raw_load_file
val pay_table = DeltaTable.forName("hr.pay").toDF.selectExpr("period_pay_month","coalesce(num_pac,'hra') as num_pac","date_raw_load_file").distinct
pay_table.createOrReplaceTempView("vw_pay_table")

// COMMAND ----------

// DBTITLE 1,Query to select only contracts data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """  select distinct                         
                                getconcatenedstring(array( p.matricule_wd
                                                          ,p.matricule_hr_access
                                                          ,p.period_paie
                                                          ,p.periode_valorisation
                                                          ,p.code_rubr
                                                          ,p.compte_comptable)) as pay_key
                                ,sha2(getconcatenedstring(array(p.matricule_wd, p.matricule_hr_access)),256) as employee_code
                                ,p.matricule_wd as employee_id
                                ,p.matricule_hr_access as france_payroll_id
                                ,p.period_paie as period_pay
                                ,p.periode_valorisation as period_valorisation
                                ,p.period_paie_month as period_pay_month
                                ,p.code_rubr 
                                ,p.compte_comptable as accounting_account
                                ,p.base
                                ,p.montant_salarial as salary_amount
                                ,p.montant_patronal as company_amount
                                ,p.payzad as payzad
                                ,p.num_pac
                                ,sha2(getconcatenedstring(array(p.code_rubr,p.compte_comptable)),256) as payroll_code
                                ,p.version
                                ,p.date_raw_load_file
                                ,p.filepath
                                ,p.filename
                                ,to_date(p.curated_ingested_date) as curated_ingested_date
                                ,true as current_record
                                ,p.date_raw_load_file as record_start_date
                                ,null as record_end_date
                                ,current_timestamp() as record_creation_date
                                ,current_timestamp() as record_modification_date
                                ,getconcatenedstring(array(
                                                             p.base
                                                            ,p.montant_salarial
                                                            ,p.montant_patronal)) as hashkey
                         , '""" + runid + """' as runid
                         , lower(trim(split(p.filepath,"/")[3])) as system_source
               from     vw_result p
                        left join vw_pay_table pt on pt.period_pay_month = p.period_paie_month 
                                                  and pt.num_pac = p.num_pac
               
               where   1 = 1
                 and   (p.matricule_wd is not null or p.matricule_hr_access is not null)
                 and   (p.date_raw_load_file >= pt.date_raw_load_file or pt.date_raw_load_file is null)
                       
                  """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source).distinct.cache
df_results.createOrReplaceTempView("vw_pay_source")
val inserted_records = df_results.count().toInt //count the number of records to upsert

// COMMAND ----------

// DBTITLE 1,Delete old data
spark.sql( """DELETE FROM hr.pay as p
WHERE EXISTS(
SELECT 1 FROM vw_pay_source
WHERE p.period_pay_month = vw_pay_source.period_pay_month and p.num_pac = vw_pay_source.num_pac)""")

// COMMAND ----------

// DBTITLE 1,Insert new data
df_results.write.format("delta")
                .mode("append")
                .partitionBy("period_pay_month")
                .saveAsTable("hr.pay")

// COMMAND ----------

// DBTITLE 1,Script to optimize storage and read of delta files
spark.sql("OPTIMIZE hr.pay")

// COMMAND ----------

// DBTITLE 1,Set the return value with the number of records reads and inserted

val read_records_hrapaie = df_hrapaie_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted

val return_value =  "read_records:" + read_records_hrapaie + ";inserted_records:" + inserted_records + ";rejected_records:" + 0
//val return_value =  "read_records:0;inserted_records:0;rejected_records:0"

// COMMAND ----------

// DBTITLE 1,Remove dataframes from cache
df_hrapaie_read.unpersist
df_results.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source and Numpac
spark.sql(""" 
update hr.pay 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

spark.sql(""" 
update hr.pay 
set num_pac = lower(trim(split(filepath,"/")[3]))
where 1=1
and (num_pac is null or num_pac = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)