// Databricks notebook source
// DBTITLE 1,Get Parameters: load_date, runid
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include notebooks
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Optimize Spark Query
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Read Data
if(spark.catalog.tableExists("recruitment.get_candidates")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_candidates")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val df_candidates_read = spark.table("recruitment.get_candidates").where($"date_raw_load_file"===load_date)

// COMMAND ----------

// DBTITLE 1,Create Refined Table
val window = Window.partitionBy("candidate_id","job_requisition_reference").orderBy($"first_year_attended".asc)
val df_application = df_candidates_read.withColumn("first_degree_reference",first($"degree_reference").over(window))
                                                  .withColumn("last_degree_reference",last($"degree_reference").over(window))
                                                  .withColumn("job_application_month",date_format($"job_application_date","MM"))

// COMMAND ----------

val window2 = Window.partitionBy("candidate_id","job_requisition_reference").orderBy($"first_year_attended".desc)
val df_application_filter = df_application.withColumn("rank", rank().over(window2))
                                                              .where($"rank"===1)
df_application_filter.createOrReplaceTempView("vw_application")

// COMMAND ----------

val query_source = """select distinct
                            getconcatenedstring(array(a.candidate_id,
                                                      a.job_requisition_reference,
                                                      a.job_application_date)) as application_key
                            ,a.candidate_id
                            ,a.candidate_first_name
                            ,a.candidate_last_name
                            ,a.job_requisition_reference
                            ,a.job_application_date
                            ,a.job_application_month
                            ,a.first_degree_reference
                            ,a.last_degree_reference
                            ,a.worker_reference
                            ,a.source_reference
                            ,a.stage_reference
                            ,a.disposition_reference
                            ,a.disposition_reference_id
                            ,a.filepath
                            ,a.version
                            ,a.filename
                            ,a.curated_ingested_date
                            ,a.date_raw_load_file
                            ,true as current_record
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(a.first_degree_reference,
                                                      a.last_degree_reference,
                                                      a.candidate_first_name,
                                                      a.candidate_last_name,
                                                      a.worker_reference,
                                                      a.source_reference,
                                                      a.stage_reference,
                                                      a.disposition_reference,
                                                      a.disposition_reference_id
                                                      )) as hashkey
                            ,'""" + runid + """' as runid

                            from vw_application a
                            """

// COMMAND ----------

val df_results = spark.sql(query_source).cache()

// COMMAND ----------

// DBTITLE 1,Save Data
try {
  spark.sql("FSCK REPAIR TABLE hr.application")
}
catch {
  case e: FileNotFoundException => println("Couldn't find that file.")
  case e: IOException => println("Had an IOException trying to read that file")
}

// COMMAND ----------

val application_table = DeltaTable.forName("hr.application")
application_table.toDF.count

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from recruitment.get_candidates

// COMMAND ----------

val new_application_table = df_results.as("a_updated")
                                      .join(application_table.toDF.as("a"), $"a.application_key"===$"a_updated.application_key")
                                      .where("""a.current_record = true and (a.hashkey <> a_updated.hashkey) 
                                      and a_updated.date_raw_load_file >= a.date_raw_load_file""")


// COMMAND ----------

val application_upsert = new_application_table.selectExpr("null as mergekey_1", "a_updated.*")
                                              .union(df_results.as("df_results").selectExpr("df_results.application_key as mergekey_1",
                                                                                           "*"))
val application_upsert_distinct = application_upsert.distinct()

// COMMAND ----------

application_table.alias("a")
  .merge(
    application_upsert_distinct.alias("a_updated"),
    """a.application_key = a_updated.mergekey_1""")
  .whenMatched("""a.current_record = true and (a.hashkey <> a_updated.hashkey) and a_updated.date_raw_load_file > a.date_raw_load_file """)
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_modification_date" -> "a_updated.record_modification_date",
    "runid" -> "a_updated.runid")
  )
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

val read_records = df_application.count().toInt //count the number of read records
val inserted_records = df_results.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0
df_results.unpersist()

// COMMAND ----------

dbutils.notebook.exit(return_value)

// COMMAND ----------

