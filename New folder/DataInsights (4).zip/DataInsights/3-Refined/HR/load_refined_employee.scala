// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source system, entity, domain and subdomain
//init widget
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val system_source = dbutils.widgets.get("system_source")

// COMMAND ----------

val dvalue = "2022-03-31"
val system_source = if (load_date <= dvalue) {"hra"} else {"adp"}

// COMMAND ----------

// DBTITLE 1,Include notebook containing common functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Notebook Configuration
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Set Up default values
val defaultStartDate = LocalDate.parse("2015-01-01", DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val defaultEndDate = LocalDate.parse("2999-12-31", DateTimeFormatter.ofPattern("yyyy-MM-dd"))

// COMMAND ----------

// DBTITLE 1,Set the table salaries
val table_salaries = "employee." + system_source.toLowerCase() + "_salaries"

// COMMAND ----------

// DBTITLE 1,Refresh table salaries
if(spark.catalog.tableExists(table_salaries)) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE " + table_salaries)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get specific population
val df_salariehra_read = spark.table("employee.adp_salaries").filter($"population_particuliere"===1).select("matricule_wd","matricule_hr_access").union(spark.table("employee.hra_salaries").filter($"population_particuliere"===1).select("matricule_wd","matricule_hr_access")).distinct
df_salariehra_read.createOrReplaceTempView("vw_salariehra") // create a temp view

// COMMAND ----------

// DBTITLE 1,Refresh table employee.get_workers
if(spark.catalog.tableExists("employee.get_workers")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.get_workers")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the windowing function in order to filter the last employee information sent by grouping by employee_id and sort by filename desc. then create the temp view
val byemployee_id = Window.partitionBy("employee_id","france_payroll_id").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_employee_read = spark.table("employee.get_workers").filter("date_raw_load_file = '" + load_date + "'")
                                                          .withColumn("rank",rank() over byemployee_id)
                                                          .filter(col("rank")==="1")
                                                          /*fix wrong matricule workday and hra*/
                                                          .withColumn("company_id", when($"company_id" === "82", "0082").otherwise($"company_id"))
                                                          .withColumn("employee_id",when($"employee_id" === "W200094100",lit("W20094100")).otherwise($"employee_id"))
                                                          .withColumn("france_payroll_id",when($"france_payroll_id" === "019370019370",lit("019370"))
                                                                                         .when($"france_payroll_id".isNull and $"employee_id" === "W20097563", lit("060144"))
                                                                                         .when($"france_payroll_id".isNotNull and $"company_id" === "0082", null)
                                                                                         .otherwise($"france_payroll_id"))
                                                          
                                                          .withColumn("employee_code",concat_ws("|",$"employee_id",$"france_payroll_id"))
                                                          .dropDuplicates("employee_code")
                                                          .filter("france_payroll_id is not null or (france_payroll_id is null and company_id = '0082')").as("e")
                                                          .join(df_salariehra_read.as("h"), $"e.employee_id" === $"h.matricule_wd" or $"e.france_payroll_id" === $"h.matricule_hr_access", "left_outer")
                                                          .filter(" h.matricule_wd is null or h.matricule_hr_access is null")
df_employee_read.createOrReplaceTempView("vw_employee") // create a temp view
df_employee_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// MAGIC %sql
// MAGIC select date_raw_load_file, * from employee.get_workers where employee_id = 'W20106087'

// COMMAND ----------

// DBTITLE 1,Get rows to reject where france_payroll_id is null and not in company 0082 or employees belong to specific population
val df_employee_reject = spark.table("employee.get_workers").filter("date_raw_load_file = '" + load_date + "'")                                                            
                                                            .withColumn("company_id", when($"company_id" === "82", "0082").otherwise($"company_id"))
                                                            .withColumn("employee_id",when($"employee_id" === "W200094100",lit("W20094100")).otherwise($"employee_id"))
                                                            .withColumn("france_payroll_id",when($"france_payroll_id" === "019370019370",lit("019370"))
                                                                                         .when($"france_payroll_id".isNull and $"employee_id" === "W20097563", lit("060144"))
                                                                                         .when($"france_payroll_id".isNotNull and $"company_id" === "0082", null)
                                                                                         .otherwise($"france_payroll_id")).as("e")
                                                            .join(df_salariehra_read.as("h"), $"e.employee_id" === $"h.matricule_wd" or $"e.france_payroll_id" === $"h.matricule_hr_access", "left_outer")
                                                            .withColumn("error_log", when($"france_payroll_id".isNull and $"company_id" =!= "0082","ERR-004: the mandatory column france_payroll_id is empty")
                                                                                    .when($"matricule_wd".isNotNull or $"matricule_hr_access".isNotNull,"ERR-007: The employee is part of special population")
                                                                                    .otherwise(null))
                                                            .filter("(france_payroll_id is null and company_id <> '0082') or h.matricule_wd is not null or h.matricule_hr_access is not null")
                                                            .drop("matricule_wd")
                                                            .drop("matricule_hr_access")
                                                            .distinct
                                                            
val df_write_reject = df_employee_reject.select(df_employee_reject.columns.map(c => col(c).cast(StringType)) : _*)        
                                        .withColumn("version",col("version").cast(IntegerType)) 
                                        .withColumn("date_raw_load_file",col("date_raw_load_file").cast(DateType)) 
                                        .withColumn("curated_ingested_date",col("curated_ingested_date").cast(TimestampType)) 
                                        .withColumn("year_file",col("year_file").cast(IntegerType)) 
                                        .withColumn("month_file",col("month_file").cast(IntegerType))
                                        .withColumn("day_file",col("day_file").cast(IntegerType))
                                      

// COMMAND ----------

// DBTITLE 1,Write rejected rows to specific curated partition
df_write_reject.write.partitionBy("date_raw_load_file").mode(SaveMode.Append).parquet(s"/mnt/curated_container/employee/workday/get_workers/rejected")

// COMMAND ----------

// DBTITLE 1,Set the table centrecout
val table_centrecout = "organization." + system_source.toLowerCase() + "_centrecout"

// COMMAND ----------

// DBTITLE 1,Refresh table hra_centrecout
if(spark.catalog.tableExists(table_centrecout)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_centrecout)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get last date file centre_cout loaded for the parameter load_date
val path_org = "/organization/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + "_centrecout"
val partition_centrecout = get_last_partition_file(path_org,load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Set the table ref_centrecout
val table_ref_centrecout = "organization." + system_source.toLowerCase() + "_ref_centrecout"

// COMMAND ----------

// DBTITLE 1,Refresh table organization ref_centrecout
if(spark.catalog.tableExists(table_ref_centrecout)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_ref_centrecout)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get last date file organization ref_centrecout loaded for the parameter load_date
val extension = if(system_source.toLowerCase() == "hra"){ "_ref_centrecout" } else { "_ref_centre_cout" }
val path_ref_org = "/organization/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + extension
val partition_ref_centrecout = get_last_partition_file(path_ref_org,load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Refresh table organisation_chanel_italie
if(spark.catalog.tableExists("organization.organisation_chanel_italie")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE organization.organisation_chanel_italie")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get last date file chanel_italy loaded for the parameter load_date
val partition_chanel_italy= get_last_partition_file("/organization/business/organisation_chanel_italie",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read Italy organizational hierarchy
val df_italy = spark.table("organization.organisation_chanel_italie").filter("date_raw_load_file = '" + partition_chanel_italy + "'")
                                                                                                .withColumnRenamed("cost_center_code","centre_cout")
                                                                                                .withColumnRenamed("cost_center_name","libelle_centre_cout")
                                                                                                .withColumnRenamed("niveau_5_departement","libelle_departement")
                                                                                                .withColumnRenamed("niveau_4_direction","libelle_direction")

val df_new_italy = df_italy.withColumn("matricule_hr_access",lit(null))
                           .withColumn("matricule_wd",lit(null))
                           .withColumn("date_deb_centre_cout",lit(partition_chanel_italy))
                           .withColumn("date_fin_centre_cout",lit(null))
                           .withColumn("sous_compte",lit(null))
                           .withColumn("taux_repartition",lit(null))
                           .withColumn("date_deb_etablissement",lit(partition_chanel_italy))
                           .withColumn("date_fin_etablissement",lit(null))
                           .withColumn("code_etablissement",lit(null))
                           .withColumn("libelle_etablissement",when(lower($"niveau_2_division_consolidee") === "camelia" ,lit("Etablissement - Camelia")).otherwise(lit("CHANEL COORDINATION S.R.L. ITALIE")))
                           .withColumn("date_deb_societe",lit(partition_chanel_italy))
                           .withColumn("date_fin_societe",lit(null))
                           .withColumn("code_societe",lit(null))
                           .withColumn("libelle_societe",lit(null))
                           .withColumn("motif_entree",lit(null))
                           .withColumn("date_deb_org",lit(partition_chanel_italy))
                           .withColumn("date_fin_org",lit(null))
                           .withColumn("code_direction",$"libelle_direction")
                           .withColumn("code_departement",$"libelle_departement")
                           .select(       "centre_cout"
                                         ,"libelle_centre_cout"
                                         ,"sous_compte"
                                         ,"taux_repartition"
                                         ,"code_etablissement"
                                         ,"libelle_etablissement"
                                         ,"code_societe"
                                         ,"libelle_societe"
                                         ,"code_direction"
                                         ,"libelle_direction"
                                         ,"code_departement"
                                         ,"libelle_departement"
                                         ,"date_deb_centre_cout"
                                         ,"date_fin_centre_cout"
                                         ,"date_deb_etablissement"
                                         ,"date_fin_etablissement"
                                         ,"date_deb_societe"
                                         ,"date_fin_societe"
                                         ,"date_deb_org"
                                         ,"date_fin_org")


// COMMAND ----------

// DBTITLE 1,Get the Cost Center Last Hierarchy
val bycostcenterhra = Window.partitionBy("centre_cout").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc, $"date_deb_centre_cout".desc, $"date_fin_centre_cout".desc,$"date_deb_etablissement".desc,$"date_deb_societe".desc,$"date_deb_org".desc)
val df_costcenterhra_read = spark.table(table_centrecout).filter("date_raw_load_file <= '" + partition_centrecout + "'")
                                                                      .withColumn("rank",rank() over bycostcenterhra).filter(col("rank")==="1")
                                                                      .withColumn("date_deb_centre_cout",lit(null))
                                                                      .withColumn("date_fin_centre_cout",lit(null))
                                                                      .withColumn("date_deb_etablissement",lit(null))
                                                                      .withColumn("date_fin_etablissement",lit(null))
                                                                      .withColumn("date_deb_societe",lit(null))
                                                                      .withColumn("date_fin_societe",lit(null))
                                                                      .withColumn("date_deb_org",lit(null))
                                                                      .withColumn("date_fin_org",lit(null))
                                                                      .select(        "centre_cout"
                                                                                     ,"libelle_centre_cout"
                                                                                     ,"sous_compte"
                                                                                     ,"taux_repartition"
                                                                                     ,"code_etablissement"
                                                                                     ,"libelle_etablissement"
                                                                                     ,"code_societe"
                                                                                     ,"libelle_societe"
                                                                                     ,"code_direction"
                                                                                     ,"libelle_direction"
                                                                                     ,"code_departement"
                                                                                     ,"libelle_departement"
                                                                                     ,"date_deb_centre_cout"
                                                                                     ,"date_fin_centre_cout"
                                                                                     ,"date_deb_etablissement"
                                                                                     ,"date_fin_etablissement"
                                                                                     ,"date_deb_societe"
                                                                                     ,"date_fin_societe"
                                                                                     ,"date_deb_org"
                                                                                     ,"date_fin_org").distinct //read parquet file

val df_new_hra_centre_cout = df_costcenterhra_read.union(df_new_italy)
df_new_hra_centre_cout.cache()  //put the dataframe ont he cache
df_new_hra_centre_cout.createOrReplaceTempView("vw_costcenterhra") // create a temp view

// COMMAND ----------

// DBTITLE 1,Read the organizational information of employees from hra
val bycostcenterhra_dates = Window.partitionBy("centre_cout","matricule_wd", "matricule_hr_access").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc, $"date_deb_centre_cout".desc, $"date_fin_centre_cout".desc,$"date_deb_etablissement".desc,$"date_deb_societe".desc,$"date_deb_org".desc)
val df_costcenterhra_read_dates = spark.table(table_centrecout).filter("date_raw_load_file <= '" + partition_centrecout + "'")

                         .withColumn("rank",rank() over bycostcenterhra_dates).filter(col("rank")==="1")
                         .select(         "matricule_hr_access"
                                         ,"matricule_wd"
                                         ,"centre_cout"
                                         ,"libelle_centre_cout"
                                         ,"sous_compte"
                                         ,"taux_repartition"
                                         ,"code_etablissement"
                                         ,"libelle_etablissement"
                                         ,"code_societe"
                                         ,"libelle_societe"
                                         ,"code_direction"
                                         ,"libelle_direction"
                                         ,"code_departement"
                                         ,"date_deb_centre_cout"
                                         ,"date_fin_centre_cout"
                                         ,"date_deb_etablissement"
                                         ,"date_fin_etablissement"
                                         ,"date_deb_societe"
                                         ,"date_fin_societe"
                                         ,"date_deb_org"
                                         ,"date_fin_org").distinct //read parquet file

df_costcenterhra_read_dates.cache()  //put the dataframe ont he cache
df_costcenterhra_read_dates.createOrReplaceTempView("vw_costcenterhra_dates") // create a temp view

// COMMAND ----------

// DBTITLE 1,Ref_Centre_Cout
val byrefcostcenterhra = Window.partitionBy("centre_cout").orderBy($"filename".desc,$"date_raw_load_file".desc, $"version".desc)

val df_ref_costcernterhra_readfirst = spark.table(table_ref_centrecout)


val df_ref_costcenterhra_read = df_ref_costcernterhra_readfirst
                                 .filter("date_raw_load_file <= '" + partition_ref_centrecout + "'")                                 
                                 .withColumn("rank",rank() over byrefcostcenterhra)
                                 .filter(col("rank")==="1")
                                 .withColumn("cost_center_key",lpad($"centre_cout",10,"0"))// add caracter
                                 .withColumn("current_hierarchy_ref", lit(true))
                                 .select(
                                          "centre_cout"
                                         ,"libelle_centre_cout"
                                         ,"code_etablissement"
                                         ,"libelle_etablissement"
                                         ,"code_societe"
                                         ,"libelle_societe"
                                         ,"code_direction"
                                         ,"libelle_direction"
                                         ,"code_departement"
                                         ,"libelle_departement"
                                         ,"cost_center_key"
                                         ,"filepath"
                                         ,"version"
                                         ,"date_raw_load_file"
                                         ,"filename"
                                         ,"curated_ingested_date"
                                         ,"current_hierarchy_ref").distinct //read parquet file


df_ref_costcenterhra_read.cache()  //put the dataframe ont he cache
df_ref_costcenterhra_read.createOrReplaceTempView("vw_ref_costcenterhra")  
//display(df_costcenterhra_read)

// COMMAND ----------

// DBTITLE 1,Get the organizational hierarchy of employees
val df_join = df_employee_read
              .select("employee_id", "france_payroll_id", "cost_center_code", "company_id", "date_raw_load_file", "effective_organization_change_date").distinct.as("e")
              .join(df_costcenterhra_read_dates.as("c"), $"e.france_payroll_id" === $"c.matricule_hr_access" and $"e.employee_id" === $"c.matricule_wd" and $"e.cost_center_code" === $"c.centre_cout", "left_outer")
              .join(df_new_hra_centre_cout.as("o"), $"e.cost_center_code" === $"o.centre_cout", "left_outer")
              .join(df_ref_costcenterhra_read.as("r"), $"e.cost_center_code" === $"r.centre_cout", "left_outer" )
              .selectExpr(                      
                      "e.employee_id"
                     ,"e.france_payroll_id"
                     ,"e.cost_center_code"
                     ,"e.effective_organization_change_date"
                     ,"coalesce(r.code_societe, e.company_id) as company_id"
                     ,"coalesce(r.code_etablissement, c.code_etablissement, o.code_etablissement) as code_etablissement"
                     ,"coalesce(r.code_direction, c.code_direction, o.code_direction) as code_direction"
                     ,"coalesce(r.code_departement, c.code_departement, o.code_departement) as code_departement"
                     ,"case when e.effective_organization_change_date < c.date_deb_centre_cout then c.date_deb_centre_cout else e.effective_organization_change_date end as date_deb_centre_cout"
                     ,"" + lit(defaultEndDate) + " as  date_fin_centre_cout"
                     ,"case when e.effective_organization_change_date < c.date_deb_centre_cout then c.date_deb_centre_cout else e.effective_organization_change_date end as date_deb_etablissement"
                     ,"" + lit(defaultEndDate) + " as  date_fin_etablissement"
                     ,"case when e.effective_organization_change_date < c.date_deb_centre_cout then c.date_deb_centre_cout else e.effective_organization_change_date end as date_deb_societe"
                     ,"" + lit(defaultEndDate) + " as  date_fin_societe"
                     ,"case when e.effective_organization_change_date < c.date_deb_centre_cout then c.date_deb_centre_cout else e.effective_organization_change_date end as date_deb_org"
                     ,"" + lit(defaultEndDate) + " as  date_fin_org"
                  )

              .distinct
              /*fix wrong matricule workday and hra*/
              .withColumn("employee_id",when($"employee_id" === "W200094100",lit("W20094100")).otherwise($"employee_id"))
              .withColumn("france_payroll_id",when($"france_payroll_id" === "019370019370",lit("019370")).otherwise($"france_payroll_id"))
              

df_join.createOrReplaceTempView("vw_emp_orga") 

// COMMAND ----------

// DBTITLE 1,Query to select only contracts data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select   distinct 
                               getconcatenedstring(array(e.employee_id,e.france_payroll_id )) as employee_key
                              ,sha2(getconcatenedstring(array(e.employee_id, e.france_payroll_id)),256) as employee_code
                              ,e.employee_id
                              ,e.france_payroll_id
                              ,e.last_name
                              ,e.first_name
                              ,e.birth_name
                              ,e.prefix
                              ,e.gender
                              ,e.birth_date
                              ,e.city_of_birth
                              ,e.department_of_birth
                              ,e.country_of_birth
                              ,e.primary_nationality
                              ,e.additional_nationalities
                              ,e.primary_work_email
                              ,e.primary_home_email
                              ,e.street_number
                              ,e.street_number_extension
                              ,e.street_name
                              ,e.additional_address
                              ,e.postal_code
                              ,e.city
                              ,e.marital_status
                              ,e.marital_status_label
                              ,e.national_identifier
                              ,e.user_name
                              ,e.igi_identification
                              ,e.spouse_first_name
                              ,e.spouse_last_name
                              ,e.manager_reference
                              ,e.manager_last_name
                              ,e.manager_first_name
                              ,e.cost_center_code 
                              ,c.company_id
                              ,c.code_etablissement as code_establishment
                              ,c.code_direction
                              ,c.code_departement as code_department
                              ,c.date_deb_centre_cout as cost_center_start_date
                              ,c.date_fin_centre_cout as cost_center_end_date
                              ,c.date_deb_etablissement as establishment_start_date
                              ,c.date_fin_etablissement as establishment_end_date
                              ,c.date_deb_societe as company_start_date
                              ,c.date_fin_societe as company_end_date
                              ,c.date_deb_org as organization_start_date
                              ,c.date_fin_org as organization_end_date
                              ,e.lt_leader_last_name_n_1
                              ,e.lt_leader_first_name_n_1 
                              ,e.lt_leader_reference_n_1 
                              ,e.lt_leader_last_name
                              ,e.lt_leader_first_name
                              ,e.lt_leader_reference
                              ,e.supervisory_organization_name
                              ,e.supervisory_organization_reference
                              ,e.effective_organization_change_date
                              ,c.date_deb_centre_cout as effective_organization_hierarchy_change_date
                              ,e.effective_suporg_change_date    
                              ,sha2(e.location,256) as location_code
                              ,sha2(getconcatenedstring(array(e.primary_nationality, e.additional_nationalities)),256) as nationality_code
                              ,sha2(getconcatenedstring(array(e.manager_reference, 
                                                              e.lt_leader_reference_n_1 , 
                                                              e.lt_leader_reference)),256) as manager_code
                              ,sha2(e.supervisory_organization_reference,256) as supervisory_organization_code
                              ,sha2(e.business_line_reference,256) as business_line_code
                              ,sha2(getconcatenedstring(array(e.cost_center_code, c.company_id, c.code_etablissement)),256) as legal_organization_code
                              ,sha2(getconcatenedstring(array(e.cost_center_code, c.code_direction, 
                                                              c.code_departement,e.business_line_reference,e.business_line_name)),256) as operational_organization_code
                                                              
                              ,sha2(getconcatenedstring(array(c.date_deb_etablissement
                                                             ,c.date_fin_etablissement
                                                             ,c.date_deb_societe
                                                             ,c.date_fin_societe)),256) as org_in_out_dates_code
                              ,e.local_pb_hierarchy_code
                              ,e.local_pb_hierarchy_name
                              ,0  as special_population
                              ,e.version
                              ,e.date_raw_load_file
                              ,e.filepath
                              ,e.filename
                              ,e.curated_ingested_date
                              ,true as current_record
                              ,e.date_raw_load_file as record_start_date
                              ,null as record_end_date
                              ,current_timestamp() as record_creation_date
                              ,current_timestamp() as record_modification_date
                              ,getconcatenedstring(array( e.last_name
                                                              ,e.first_name
                                                              ,e.birth_name
                                                              ,e.prefix
                                                              ,e.gender
                                                              ,e.birth_date
                                                              ,e.city_of_birth
                                                              ,e.department_of_birth
                                                              ,e.country_of_birth
                                                              ,e.primary_nationality
                                                              ,e.additional_nationalities
                                                              ,e.primary_work_email
                                                              ,e.primary_home_email
                                                              ,e.street_number
                                                              ,e.street_number_extension
                                                              ,e.street_name
                                                              ,e.additional_address
                                                              ,e.postal_code
                                                              ,e.city
                                                              ,e.marital_status
                                                              ,e.marital_status_label
                                                              ,e.national_identifier
                                                              ,e.user_name
                                                              ,e.igi_identification
                                                              ,e.spouse_first_name
                                                              ,e.spouse_last_name
                                                              ,e.manager_reference
                                                              ,e.manager_last_name
                                                              ,e.manager_first_name
                                                              ,e.location
                                                              ,e.location_type                                                              
                                                              ,e.cost_center_code 
                                                              ,c.company_id
                                                              ,c.code_etablissement
                                                              ,c.code_direction
                                                              ,c.code_departement
                                                              ,c.date_deb_centre_cout
                                                              ,c.date_fin_centre_cout
                                                              ,c.date_deb_etablissement
                                                              ,c.date_fin_etablissement
                                                              ,c.date_deb_societe
                                                              ,c.date_fin_societe
                                                              ,c.date_deb_org
                                                              ,c.date_fin_org
                                                              ,e.lt_leader_last_name_n_1
                                                              ,e.lt_leader_first_name_n_1
                                                              ,e.lt_leader_reference_n_1
                                                              ,e.lt_leader_last_name
                                                              ,e.lt_leader_first_name
                                                              ,e.lt_leader_reference
                                                              ,e.supervisory_organization_name
                                                              ,e.supervisory_organization_reference
                                                              ,e.effective_organization_change_date
                                                              ,e.effective_suporg_change_date
                                                              ,e.local_pb_hierarchy_code
                                                              ,e.local_pb_hierarchy_name
                                                              )) as hashkey 
                       , '""" + runid + """' as runid
                       ,lower(trim(split(e.filepath,"/")[3])) as system_source
               from    vw_employee e
                       left join vw_emp_orga c on e.cost_center_code = c.cost_center_code 
                                                    and ((e.employee_id = c.employee_id and e.france_payroll_id = c.france_payroll_id) 
                                                        or (e.employee_id = c.employee_id and e.france_payroll_id is null))
                   
               where   1 = 1
                 and   (e.employee_id is not null or e.france_payroll_id is not null)
     

              """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source)

// COMMAND ----------

// DBTITLE 1,Refresh table employee
 if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the table employee after drop the table if exists and store data and table structure on employees_table
val employee_table = DeltaTable.forName("hr.employee")

// COMMAND ----------

// DBTITLE 1,Rows for information updated of existing employees
val newemployee = df_results.as("employee_updated")
  .join(employee_table.toDF.where($"special_population"=!="1" or $"special_population".isNull).as("employee"),  ($"employee.france_payroll_id"===$"employee_updated.france_payroll_id" and
                                                                                    $"employee.employee_id"===$"employee_updated.employee_id") or ($"employee.employee_id"===$"employee_updated.employee_id" and $"employee_updated.france_payroll_id".isNull))
.where("""employee.current_record = true and (employee_updated.hashkey <> employee.hashkey) and employee_updated.date_raw_load_file >= employee.date_raw_load_file """)

// COMMAND ----------

// DBTITLE 1,Union of dataframes between contracts updated from existing information and new information from new employees
// Stage the update by unioning two sets of rows
// 1. Rows that will be inserted in the `whenNotMatched` clause
// 2. Rows that will either UPDATE the current employees of existing employees or insert the new employees of new employees
val employee_upsert = newemployee
  .selectExpr("null as mergekey_1","null as mergekey_2","employee_updated.*")   // Rows for 1.
  .union(
    df_results.as("df_results").selectExpr("df_results.france_payroll_id as mergekey_1",
                                           "df_results.employee_id as mergekey_2","*")  // Rows for 2.
  )
//remove duplicate
val employee_upsert_distinct = employee_upsert.distinct()

// COMMAND ----------

// DBTITLE 1,Merge on table employee
employee_table.alias("t")
  .merge(
    employee_upsert_distinct.alias("s"),
     """(t.france_payroll_id=s.mergekey_1 and
     t.employee_id=s.mergekey_2) or (t.france_payroll_id is Null and t.employee_id=s.mergekey_2)""")
  .whenMatched("""t.current_record = true and (t.hashkey <> s.hashkey) and s.date_raw_load_file >= t.date_raw_load_file """)
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "case when date_add(s.record_start_date,-1)<t.record_start_date then t.record_start_date else date_add(s.record_start_date,-1) end ",
    "record_modification_date" -> "s.record_modification_date",
    "runid" -> "s.runid")
  )
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Update employee_id where is null for old records and employee_id and france_payroll_id is not null for current record
spark.sql("""
merge into hr.employee e1
using hr.employee e2
on e1.france_payroll_id = e2.france_payroll_id
and e1.employee_id is null 
and e2.employee_id is not null
and e2.current_record = true
when matched then
  update set e1.employee_id = e2.employee_id,
             e1.current_record = false,
             e1.record_end_date = case when e1.record_end_date is null then date_add(e2.record_start_date,-1) end,
             e1.employee_code = e2.employee_code,
             e1.employee_key = e2.employee_key
""")

// COMMAND ----------

// DBTITLE 1,Build end date for hierarchy
val bycostcenter = Window.partitionBy("employee_id","france_payroll_id","cost_center_code","company_id","code_establishment","code_direction","cost_center_start_date").orderBy($"cost_center_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val bycostcenterdate =   Window.partitionBy("employee_code","employee_id","france_payroll_id").orderBy($"cost_center_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)

val df_employee_costcenter_read = spark.table("hr.employee").select("employee_code"
                                                             ,"employee_id"
                                                             ,"france_payroll_id"
                                                             ,"cost_center_code"
                                                             ,"cost_center_start_date"
                                                             ,"cost_center_end_date"
                                                             ,"company_id"
                                                             ,"company_start_date"
                                                             ,"company_end_date"
                                                             ,"code_direction"
                                                             ,"organization_start_date"
                                                             ,"organization_end_date"
                                                             ,"code_establishment"
                                                             ,"establishment_start_date"
                                                             ,"establishment_end_date"
                                                             ,"record_start_date"
                                                             ,"date_raw_load_file"
                                                             ,"record_modification_date").distinct
                                                      .withColumn("rank_start",rank() over bycostcenter)
                                                      .filter(col("rank_start")==="1")
                                                      .withColumn("next_cost_center_start_date",lag($"cost_center_start_date", 1, null).over(bycostcenterdate))
                                                      .withColumn("new_cost_center_end_date", coalesce(when($"cost_center_start_date" >= date_add($"next_cost_center_start_date", -1),$"cost_center_end_date").otherwise(date_add($"next_cost_center_start_date", -1)),lit("2999-12-31")))
                                                      
                                                      .distinct

df_employee_costcenter_read.createOrReplaceTempView("vw_employee_costcenter_dates")

val bycompanyid = Window.partitionBy("employee_id","france_payroll_id","company_id","company_start_date").orderBy($"company_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val bycompanydate =   Window.partitionBy("employee_code", "employee_id","france_payroll_id").orderBy($"company_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)

val df_employee_company_read = spark.table("hr.employee").select("employee_code"
                                                             ,"employee_id"
                                                             ,"france_payroll_id"
                                                             ,"company_id"
                                                             ,"company_start_date"
                                                             ,"company_end_date"
                                                             ,"record_start_date"
                                                             ,"date_raw_load_file"
                                                             ,"record_modification_date"
                                                      ).distinct
                                                      .withColumn("rank_start",rank() over bycompanyid)
                                                      .filter(col("rank_start")==="1")
                                                      .withColumn("next_company_start_date",lag($"company_start_date", 1, null).over(bycompanydate))
                                                      .withColumn("new_company_end_date", coalesce(when($"company_start_date" >= date_add($"next_company_start_date", -1),$"company_end_date").otherwise(date_add($"next_company_start_date", -1)),lit("2999-12-31")))
                                                      
                                                         
                                                      .distinct

df_employee_company_read.createOrReplaceTempView("vw_employee_company_dates")


val bydirectionid = Window.partitionBy("employee_id","france_payroll_id","code_direction","organization_start_date").orderBy($"organization_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val bydirectiondate =   Window.partitionBy("employee_code", "employee_id","france_payroll_id").orderBy($"organization_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)

val df_employee_direction_read = spark.table("hr.employee").select("employee_code"
                                                             ,"employee_id"
                                                             ,"france_payroll_id"
                                                             ,"code_direction"
                                                             ,"organization_start_date"
                                                             ,"organization_end_date"
                                                             ,"record_start_date"
                                                             ,"date_raw_load_file"
                                                             ,"record_modification_date"
                                                      ).distinct
                                                      .withColumn("rank_start",rank() over bydirectionid)
                                                      .filter(col("rank_start")==="1")
                                                      .withColumn("next_organization_start_date",lag($"organization_start_date", 1, null).over(bydirectiondate))
                                                      .withColumn("new_organization_end_date", coalesce(when($"organization_start_date" >= date_add($"next_organization_start_date", -1),$"organization_end_date").otherwise(date_add($"next_organization_start_date", -1)),lit("2999-12-31")))
                                                      
                                                      .distinct

df_employee_direction_read.createOrReplaceTempView("vw_employee_direction_dates")


val byestablishmentid = Window.partitionBy("employee_id","france_payroll_id","code_establishment","establishment_start_date").orderBy($"establishment_start_date".desc,$"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val byestablishmentdate =   Window.partitionBy("employee_code", "employee_id","france_payroll_id").orderBy($"establishment_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)

val df_employee_establishment_read = spark.table("hr.employee").select("employee_code"
                                                             ,"employee_id"
                                                             ,"france_payroll_id"
                                                             ,"code_establishment"
                                                             ,"establishment_start_date"
                                                             ,"establishment_end_date"
                                                             ,"record_start_date"
                                                             ,"date_raw_load_file"
                                                             ,"record_modification_date"
                                                      ).distinct
                                                      .withColumn("rank_start",rank() over byestablishmentid)
                                                      .filter(col("rank_start")==="1")
                                                      .withColumn("next_establishment_start_date",lag($"establishment_start_date", 1, null).over(byestablishmentdate))
                                                      .withColumn("new_establishment_end_date",  coalesce((when($"establishment_start_date" >= date_add($"next_establishment_start_date", -1),$"establishment_end_date").otherwise(date_add($"next_establishment_start_date", -1))),lit("2999-12-31")))
                                                      
                                                      .select("employee_code"
                                                             ,"employee_id"
                                                             ,"france_payroll_id"
                                                             ,"code_establishment"
                                                             ,"establishment_start_date"
                                                             ,"establishment_end_date"
                                                             ,"new_establishment_end_date"
                                                      )
                                                      .distinct

df_employee_establishment_read.createOrReplaceTempView("vw_employee_establishment_dates")

// COMMAND ----------

// DBTITLE 1,Query to use in order to calculate end date for hierarchy
spark.sql("""
select distinct 
       cc.employee_code
      ,cc.employee_id
      ,cc.france_payroll_id
      ,cc.cost_center_code
      ,cc.cost_center_start_date
      ,cc.cost_center_end_date
      ,cc.new_cost_center_end_date
      ,cc.company_id
      ,cc.company_start_date
      ,cc.company_end_date
      ,c.new_company_end_date
      ,cc.code_direction
      ,cc.organization_start_date
      ,cc.organization_end_date
      ,d.new_organization_end_date
      ,cc.code_establishment
      ,cc.establishment_start_date
      ,cc.establishment_end_date
      ,e.new_establishment_end_date
      
from  vw_employee_costcenter_dates  cc
      left join vw_employee_company_dates c on cc.employee_code = c.employee_code
                                            and cc.company_id = c.company_id
                                            and cc.company_start_date = c.company_start_date
                                            
      left join vw_employee_direction_dates d on cc.employee_code = d.employee_code
                                            and cc.code_direction = d.code_direction
                                            and cc.organization_start_date = d.organization_start_date
                                            
      left join vw_employee_establishment_dates e on cc.employee_code = e.employee_code
                                            and cc.code_establishment = e.code_establishment
                                            and cc.establishment_start_date = e.establishment_start_date
                                          
""").createOrReplaceTempView("vw_employee_orga_dates")

// COMMAND ----------

// DBTITLE 1,Update end date for hierarchy and for each employee
spark.sql("""
merge into hr.employee e1
using vw_employee_orga_dates e2
on e1.employee_code = e2.employee_code
and e1.cost_center_code = e2.cost_center_code
and e1.company_id = e2.company_id
and e1.code_direction = e2.code_direction
and e1.code_establishment = e2.code_establishment
and e1.cost_center_start_date = e2.cost_center_start_date

when matched then
  update set e1.cost_center_end_date = coalesce(e2.new_cost_center_end_date,"2999-12-31"),
             e1.company_end_date = coalesce(e2.new_company_end_date,"2999-12-31"),
             e1.organization_end_date = coalesce(e2.new_organization_end_date,"2999-12-31"),
             e1.establishment_end_date = coalesce(e2.new_establishment_end_date,"2999-12-31"),
             e1.org_in_out_dates_code = sha2(getconcatenedstring(array(e1.establishment_start_date
                                                             ,coalesce(e2.new_establishment_end_date,"2999-12-31")
                                                             ,e1.company_start_date
                                                             ,coalesce(e2.new_company_end_date,"2999-12-31"))),256),
             e1.record_modification_date = current_timestamp()
""")

// COMMAND ----------

// DBTITLE 1,Update effective_organization_hierarchy_change_date
spark.sql("""update hr.employee set effective_organization_hierarchy_change_date = case when effective_organization_change_date < cost_center_start_date or cost_center_start_date is null  then cost_center_start_date else effective_organization_change_date end where effective_organization_hierarchy_change_date is null """)

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE hr.employee")

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_employee_read.count().toInt //count the number of read records//set up the return value with the number of lines read, rejected and inserted
val inserted_records = employee_upsert_distinct.count().toInt //count the number of records to upsert
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove dataframes from cache
df_employee_read.unpersist
df_costcenterhra_read.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.employee 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)