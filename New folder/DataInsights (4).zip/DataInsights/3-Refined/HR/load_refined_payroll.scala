// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val system_source = dbutils.widgets.get("system_source")

// COMMAND ----------

// DBTITLE 1,Include Notebook Containing Common Functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val dvalue = "2022-03-31"
val system_source = if (load_date <= dvalue) {"hra"} else {"adp"}

// COMMAND ----------

// DBTITLE 1,Set up notebook config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760 ")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Set up table and path for pay
val table_paie = "pay." + system_source.toLowerCase() + "_paie"
val path_paie = "/pay/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + "_paie"

// COMMAND ----------

// DBTITLE 1,Refresh tale table pay
if(spark.catalog.tableExists(table_paie)) 
{
  try {
    spark.sql("MSCK REPAIR TABLE " +  table_paie)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Set up table and path for payroll
val table_rubr_paie = "pay." + system_source.toLowerCase() + "_rubr_paie"
val path_rubr_paie = "/pay/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + "_rubr_paie"

// COMMAND ----------

// DBTITLE 1,Refresh table payroll
if(spark.catalog.tableExists(table_rubr_paie)) 
{
  try {
    spark.sql("MSCK REPAIR TABLE " +  table_rubr_paie)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get the last hra_rubr_paie loaded
val partition_payroll = get_last_partition_file(path_rubr_paie,load_date,"curated")


// COMMAND ----------

// DBTITLE 1,Read data from curated payroll
val bypayroll_code = Window.partitionBy("code_rubr").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc )
val df_payroll_read = spark.table(table_rubr_paie).filter("date_raw_load_file = '" + partition_payroll + "'")   //read parquet file
                                                      .withColumn("rank",rank() over bypayroll_code).filter(col("rank")==="1")
                                                      .withColumn("code_rubrique_paie",concat($"code_rubr",$"flag_salarial"))
df_payroll_read.createOrReplaceTempView("vw_payroll") // create a temp view
df_payroll_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Read data from curated pay
//Retrieve all combination of code rubr and accounting account for ADP
val df_pay_read = spark.table(table_paie).filter("date_raw_load_file <= '" + partition_payroll + "'")  //read parquet file
                                                      .select("code_rubr","compte_comptable")
                                                      .distinct 
df_pay_read.createOrReplaceTempView("vw_pay") // create a temp view
df_pay_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

val df_refined_pay_read = spark.table("hr.payroll")
df_refined_pay_read.createOrReplaceTempView("vw_payroll_refined") // create a temp view
df_refined_pay_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Join data between payroll and pay in order to build the accounting_account
val df_payroll_join = df_payroll_read.as("pr")
                           .join(df_pay_read.as("py"), $"pr.code_rubr" === $"py.code_rubr" and ($"pr.compte_comptable".isNull or ($"pr.compte_comptable".isNotNull and $"pr.compte_comptable" === $"py.compte_comptable")), "left_outer" )
                           .selectExpr(                      
                              "pr.code_rubr"
                             ,"pr.libelle_rubr"
                             ,"pr.flag_salarial"
                             ,"pr.flag_debit"
                             ,"coalesce(pr.compte_comptable, py.compte_comptable) as compte_comptable"
                             ,"pr.filepath"
                             ,"pr.version"
                             ,"pr.date_raw_load_file"
                             ,"pr.filename"
                             ,"pr.curated_ingested_date"
                            )
                            .withColumn("source",lit(system_source))
                            .filter($"compte_comptable".isNotNull)
                            .distinct
                            .withColumn("code_rubrique_paie",concat($"code_rubr",$"flag_salarial"))
df_payroll_join.createOrReplaceTempView("vw_payroll_join")

// COMMAND ----------

// DBTITLE 1,Refresh table business payroll to get the payroll hierarchy
if(spark.catalog.tableExists("pay.rubriques_paie")) 
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.rubriques_paie")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get the last business payroll loaded
val partition_rubriques_paie = get_last_partition_file("/pay/business/rubriques_paie/",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read payroll data from business file
val byrubriques_paie = Window.partitionBy("code_rubrique_paie","nature_comptable").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_rubriques_paie = spark.table("pay.rubriques_paie").filter("date_raw_load_file = '" + partition_rubriques_paie + "'")
                                                         .withColumn("rank",rank() over byrubriques_paie).filter(col("rank")==="1")
                                                         .withColumn("is_payroll_di",lit(true))//path to read parquet files
df_rubriques_paie.createOrReplaceTempView("vw_rubriques_paie")

// COMMAND ----------

// DBTITLE 1,Query to select only Payroll data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
/*
business file as master and retrieve previous hierarchy value if empty
join for hra files on the first character of the accounting account and whole code for ADP
*/

val query_source = """select distinct 
                            getconcatenedstring(array(coalesce(r.code_rubrique_paie,s.code_rubrique_paie)
                                                     ,coalesce(r.nature_comptable,s.compte_comptable))) as payroll_key
                                                     
                            ,sha2(getconcatenedstring(array(coalesce(r.code_rubrique_paie,s.code_rubrique_paie),coalesce(r.nature_comptable,s.compte_comptable))),256) as payroll_code
                            ,coalesce(r.code_rubrique_paie,s.code_rubrique_paie) as code_rubr 
                            ,coalesce(r.libelle_rubrique_paie,s.libelle_rubr) as label_rubr
                            ,s.flag_salarial as flag_salary
                            ,s.flag_debit as flag_debit
                            ,coalesce(r.nature_comptable,s.compte_comptable) as accounting_account
                            ,coalesce(r.code_rubrique_paie_niveau_4, pr.code_payroll_level_4) as code_payroll_level_4
                            ,coalesce(r.libelle_rubrique_paie_niveau_4, pr.label_payroll_level_4) as label_payroll_level_4
                            ,coalesce(r.code_rubrique_paie_niveau_3, pr.code_payroll_level_3) as code_payroll_level_3
                            ,coalesce(r.libelle_rubrique_paie_niveau_3, pr.label_payroll_level_3) as label_payroll_level_3
                            ,coalesce(r.code_rubrique_paie_niveau_2, pr.code_payroll_level_2) as code_payroll_level_2
                            ,coalesce(r.libelle_rubrique_paie_niveau_2, pr.label_payroll_level_2) as label_payroll_level_2
                            ,coalesce(r.code_rubrique_paie_niveau_1, pr.code_payroll_level_1) as code_payroll_level_1
                            ,coalesce(r.libelle_rubrique_paie_niveau_1, pr.label_payroll_level_1) as label_payroll_level_1
                            ,coalesce(r.flag_montant_masse_salariale_brute, pr.flag_amount_wage_gross) as flag_amount_wage_gross
                            ,coalesce(r.flag_montant_aw4, pr.flag_amount_aw4) as flag_amount_aw4
                            ,coalesce(r.flag_montant_aw6, pr.flag_amount_aw6) as flag_amount_aw6
                            ,coalesce(r.flag_montant_rem_nao, pr.flag_amount_rem_nao) as flag_amount_rem_nao
                            ,coalesce(r.flag_montant_rem_bs, pr.flag_amount_rem_bs) as flag_amount_rem_bs
                            ,coalesce(r.flag_montant_rem_benchmark, pr.flag_amount_rem_benchmark) as flag_amount_rem_benchmark
                            ,coalesce(r.flag_montant_rem_cible, pr.flag_amount_rem_target) as flag_amount_rem_target
                            ,coalesce(r.flag_montant_rem_reelle, pr.flag_amount_rem_real) as flag_amount_rem_real
                            ,r.is_payroll_di
                            ,coalesce(r.filepath, s.filepath) as filepath
                            ,coalesce(r.version, s.version) as version
                            ,coalesce(r.date_raw_load_file, s.date_raw_load_file) as date_raw_load_file
                            ,coalesce(r.filename, s.filename) as filename
                            ,to_date(coalesce(r.curated_ingested_date, s.curated_ingested_date)) as curated_ingested_date
                            ,true as current_record
                            ,coalesce(r.date_raw_load_file, s.date_raw_load_file) as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array( coalesce(r.libelle_rubrique_paie,s.libelle_rubr)
                                                        ,s.flag_salarial
                                                        ,s.flag_debit
                                                        ,coalesce(r.nature_comptable,s.compte_comptable)
                                                        ,coalesce(r.code_rubrique_paie_niveau_4, pr.code_payroll_level_4)
                                                        ,coalesce(r.libelle_rubrique_paie_niveau_4, pr.label_payroll_level_4)
                                                        ,coalesce(r.code_rubrique_paie_niveau_3, pr.code_payroll_level_3)
                                                        ,coalesce(r.libelle_rubrique_paie_niveau_3, pr.label_payroll_level_3)
                                                        ,coalesce(r.code_rubrique_paie_niveau_2, pr.code_payroll_level_2)
                                                        ,coalesce(r.libelle_rubrique_paie_niveau_2, pr.label_payroll_level_2)
                                                        ,coalesce(r.code_rubrique_paie_niveau_1, pr.code_payroll_level_1)
                                                        ,coalesce(r.libelle_rubrique_paie_niveau_1, pr.label_payroll_level_1)
                                                        ,coalesce(r.flag_montant_masse_salariale_brute, pr.flag_amount_wage_gross)
                                                        ,coalesce(r.flag_montant_aw4, pr.flag_amount_aw4)
                                                        ,coalesce(r.flag_montant_aw6, pr.flag_amount_aw6)
                                                        ,coalesce(r.flag_montant_rem_nao, pr.flag_amount_rem_nao)
                                                        ,coalesce(r.flag_montant_rem_bs, pr.flag_amount_rem_bs)
                                                        ,coalesce(r.flag_montant_rem_benchmark, pr.flag_amount_rem_benchmark)
                                                        ,coalesce(r.flag_montant_rem_cible, pr.flag_amount_rem_target)
                                                        ,coalesce(r.flag_montant_rem_reelle, pr.flag_amount_rem_real)
                                                        )) as hashkey 
                           ,'""" + runid + """' as runid 
                           ,lower(trim(split(coalesce(r.filepath, s.filepath),"/")[3])) as system_source
               from    vw_rubriques_paie r
                       full outer join vw_payroll_join s on upper(concat(r.code_rubrique_paie,case when lower(s.source) = 'hra' then substr(r.nature_comptable,0,1) else r.nature_comptable end)) =  upper(concat(s.code_rubrique_paie,case when lower(s.source) = 'hra' then substr(s.compte_comptable,0,1) else s.compte_comptable end))
                       left join vw_payroll_refined pr on pr.payroll_code = sha2(getconcatenedstring(array(coalesce(r.code_rubrique_paie,s.code_rubrique_paie),coalesce(r.nature_comptable,s.compte_comptable))),256)
               where   1=1
                 and   (r.code_rubrique_paie is not null or s.code_rubrique_paie is not null)
             
                  """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source)
df_results.createOrReplaceTempView("vw_payroll_source")
df_results.cache()
val inserted_records = df_results.count().toInt //count the number of records to upsert
//display(df_results)

// COMMAND ----------

// DBTITLE 1,Remove empty accounting accounts
spark.sql( """DELETE from hr.payroll as p
WHERE p.accounting_account is null""")

// COMMAND ----------

// DBTITLE 1,Delete existing data
spark.sql( """DELETE from hr.payroll as p
WHERE EXISTS(
SELECT 1 FROM vw_payroll_source s
WHERE p.payroll_code = s.payroll_code)""")

// COMMAND ----------

// DBTITLE 1,Inserted new data
df_results.write.format("delta")
                .mode("append")
                .saveAsTable("hr.payroll")

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE hr.payroll")

// COMMAND ----------

// DBTITLE 1,Statistics on rows read and inserted
val read_records = df_payroll_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_payroll_read.unpersist
df_results.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.payroll 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)