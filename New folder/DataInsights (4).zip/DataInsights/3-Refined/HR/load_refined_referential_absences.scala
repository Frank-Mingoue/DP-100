// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include Notebook Containing Common Functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set up Configurations
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760 ")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Test if the source path exists
if(spark.catalog.tableExists("absenteism.referentiel_absences")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.referentiel_absences")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get the last partition file loaded
val partition_ref_absences = spark.table("absenteism.referentiel_absences").agg(max("date_raw_load_file") as "date_raw_load_file").select("date_raw_load_file").distinct.head().getDate(0).toString()

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source after test if it exists and count number of read records
val byref_abs = Window.partitionBy("code_absence").orderBy($"filename".desc)
val df_ref_abs_read =  spark.table("absenteism.referentiel_absences").filter("date_raw_load_file = '" + partition_ref_absences + "'")
                                                        .withColumn("rank",rank() over byref_abs).filter(col("rank")==="1")   //read parquet file
df_ref_abs_read.createOrReplaceTempView("vw_ref_abs") // create a temp view	
df_ref_abs_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Query to select only job data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select distinct 
                            getconcatenedstring(array(r.code_absence
                                                            ,lower(r.libelle_code_absence)
                                                           )) as ref_absences_key
                            ,periode as period
                            ,code_absence as absence_code
                            ,libelle_code_absence as absence_label_code
                            ,motif_absence as absence_reason
                            ,famille_absence as absence_family
                            ,absence_taux_absenteisme as absence_rate
                            ,absence_previsible_imprevisible as absence_predictable_unpredictable
                            ,flag_etp_productif as flag_productive_etp
                            ,flag_taux_absenteisme as flag_absence_rate
                            ,flag_prolongation as flag_prolongation
                            ,type_absence as absence_type
                            ,r.filepath
                            ,r.date_raw_load_file
                            ,r.version
                            ,r.filename
                            ,to_date(r.curated_ingested_date) as curated_ingested_date
                            ,true as current_record
                            ,r.date_raw_load_file as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(r.code_absence,r.libelle_code_absence)) as hashkey 
                            ,'""" + runid + """' as runid
                            ,lower(trim(split(r.filepath,"/")[3])) as system_source
               from    vw_ref_abs r
               where   1=1
            """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source).cache
val inserted_records = df_results.count().toInt //count the number of records to upsert

// COMMAND ----------

// DBTITLE 1,Insert new Data
df_results.write.format("delta")
                .mode("overwrite")
                .saveAsTable("hr.referential_absences")

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE hr.referential_absences")

// COMMAND ----------

// DBTITLE 1,Satistics
val read_records = df_ref_abs_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_ref_abs_read.unpersist
df_results.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.referential_absences 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)