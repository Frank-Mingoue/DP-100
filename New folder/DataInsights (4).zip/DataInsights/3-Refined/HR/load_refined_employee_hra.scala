// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source system, entity, domain and subdomain
//init widget
val load_date = dbutils.widgets.get("load_date");
val limit_date = dbutils.widgets.get("limit_date")
val runid = dbutils.widgets.get("runid");
val flux = dbutils.widgets.get("flux")
val system_source = dbutils.widgets.get("system_source")

// COMMAND ----------

// DBTITLE 1,Import Librairies and functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val dvalue = "2022-03-31"
val system_source = if (load_date <= dvalue) {"hra"} else {"adp"}

// COMMAND ----------

// DBTITLE 1,Set Up Config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Set Databases Connections
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// MAGIC %md ##1 - Read Data

// COMMAND ----------

// MAGIC %md ####HRA CENTRE DE COUT

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded
val path_org = "/organization/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + "_centrecout"
val partition_date_org = get_last_partition_file(path_org,load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Set table centre cout
val table_centrecout = "organization." + system_source.toLowerCase() + "_centrecout"

// COMMAND ----------

// DBTITLE 1,Refresh table Centre Cout
if(spark.catalog.tableExists(table_centrecout)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_centrecout)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Data Centre Cout
val bycentrecout = Window.partitionBy("matricule_wd","matricule_hr_access","date_deb_centre_cout").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val window = Window.partitionBy("matricule_wd","matricule_hr_access").orderBy($"date_deb_centre_cout".asc)

val df_costcenterhra_read = spark.table(table_centrecout).filter($"date_raw_load_file"===partition_date_org)
                                                         .withColumn("rank",rank() over bycentrecout)
                                                         .filter(col("rank")==="1")
                                                                    .select("matricule_wd","matricule_hr_access","centre_cout","libelle_centre_cout",
                                                                              "date_deb_centre_cout","date_fin_centre_cout").distinct												
                                                                    .withColumn("date_fin_centre_cout",lead(date_add($"date_deb_centre_cout",-1),1,"2999-12-31").over(window))


// COMMAND ----------

// DBTITLE 1,Get Data Societe
val bysociete = Window.partitionBy("matricule_wd","matricule_hr_access","date_deb_societe").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val window = Window.partitionBy("matricule_wd","matricule_hr_access").orderBy($"date_deb_societe".asc)

val df_societehra_read = spark.table(table_centrecout).filter($"date_raw_load_file"===partition_date_org)
                                                         .withColumn("rank",rank() over bysociete)
                                                         .filter(col("rank")==="1")
                                                                 .select("matricule_wd","matricule_hr_access", "date_deb_societe","date_fin_societe" ,"code_societe" , "libelle_societe" ).distinct //read parquet file
                                                                 .withColumn("date_fin_societe",lead(date_add($"date_deb_societe",-1),1,"2999-12-31").over(window))

// COMMAND ----------

// DBTITLE 1,Get Data Etablissement
val byetablissement = Window.partitionBy("matricule_wd","matricule_hr_access","date_deb_etablissement").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val window = Window.partitionBy("matricule_wd","matricule_hr_access").orderBy($"date_deb_etablissement".asc)

val df_etablissementhra_read = spark.table(table_centrecout).filter($"date_raw_load_file"===partition_date_org)
                                                            .withColumn("rank",rank() over byetablissement)
                                                            .filter(col("rank")==="1")
                                                                       .select("matricule_wd","matricule_hr_access","date_deb_etablissement","date_fin_etablissement","code_etablissement","libelle_etablissement" ).distinct
                                                                       .withColumn("date_fin_etablissement",lead(date_add($"date_deb_etablissement",-1),1,"2999-12-31").over(window))


// COMMAND ----------

// DBTITLE 1,Get Data Direction
val byorga = Window.partitionBy("matricule_wd","matricule_hr_access","date_deb_org").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val window = Window.partitionBy("matricule_wd","matricule_hr_access").orderBy($"date_deb_org".asc)

val df_organisationhra_read = spark.table(table_centrecout).filter($"date_raw_load_file"===partition_date_org)
                                                         .withColumn("rank",rank() over byorga)
                                                         .filter(col("rank")==="1")
                                                                      .select("matricule_wd","matricule_hr_access","date_deb_org","date_fin_org","code_direction","libelle_direction","code_departement","libelle_departement" ).distinct 
                                                                      .withColumn("date_fin_org",lead(date_add($"date_deb_org",-1),1,"2999-12-31").over(window))

// COMMAND ----------

// MAGIC %md ##HRA SALARIE

// COMMAND ----------

// DBTITLE 1,Set last partition file loaded
val path_sal = "/employee/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + "_salaries"

val partition_date_sal = get_last_partition_file(path_sal,load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Set Table Salaries
val table_salaries = "employee." + system_source.toLowerCase() + "_salaries"

// COMMAND ----------

// DBTITLE 1,Refresh table Salaries
if(spark.catalog.tableExists(table_salaries)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_salaries)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Data Salaries
val bysalarie = Window.partitionBy("matricule_wd","matricule_hr_access","population_particuliere").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_salariehra_read = spark.table(table_salaries).filter($"date_raw_load_file"===partition_date_sal)
                                                    .withColumn("rank",rank() over bysalarie)
                                                    .filter(col("rank")==="1").select("matricule_wd","matricule_hr_access")


// COMMAND ----------

// DBTITLE 1,Get Data Employees based on loading type
val bysalariehra = Window.partitionBy("matricule_wd","matricule_hr_access","population_particuliere").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
var df_salariehra_detail_read = spark.emptyDataFrame

if (flux=="quotidien")
{
       df_salariehra_detail_read = spark.table(table_salaries).filter($"date_raw_load_file"===partition_date_sal)
                                                    .withColumn("rank",rank() over bysalariehra)
                                                    .filter(col("rank")==="1")
      .select("matricule_wd","matricule_hr_access","qualite","population_particuliere",
      "nom_usuel",
      "prenom",
      "compte_ad",
      "date_naissance",
      "email_pro",
      "nom_patronymique",
      "complement_adresse",
      "no_adresse",
      "bis_ter_adresse",
      "nature_voie",
      "nom_voie",
      "code_postal",
      "commune",
      "code_insee_commune",
      "bureau_distributeur",
      "pays_adresse",
      "nir",
      "etat_civil",
      "libelle_etat_civil",
      "anciennete_poste",
      "ville_naissance",
      "anciennete_groupe",
      "sexe",
      "dept_naissance",
      "pays_naissance",
      "nationalite_princ",
      "derniere_embauche",
      "matricule_wd",
      "matricule_hr_access",
      "email_perso",
      "prenom_conjoint",
      "nom_conjoint",
      "entree_groupe",
      "date_raw_load_file",
      "filepath",
      "filename",
      "curated_ingested_date"
      )  //read parquet file
}
else
{
      df_salariehra_detail_read = spark.table(table_salaries).filter($"date_raw_load_file"===partition_date_sal)
                                                    .withColumn("rank",rank() over bysalariehra)
                                                    .filter(col("rank")==="1")
      .withColumn("filename",lit("histo_file"))
      .select("matricule_wd","matricule_hr_access","qualite","population_particuliere",
      "nom_usuel",
      "prenom",
      "compte_ad",
      "date_naissance",
      "email_pro",
      "nom_patronymique",
      "complement_adresse",
      "no_adresse",
      "bis_ter_adresse",
      "nature_voie",
      "nom_voie",
      "code_postal",
      "commune",
      "code_insee_commune",
      "bureau_distributeur",
      "pays_adresse",
      "nir",
      "etat_civil",
      "libelle_etat_civil",
      "anciennete_poste",
      "ville_naissance",
      "anciennete_groupe",
      "sexe",
      "dept_naissance",
      "pays_naissance",
      "nationalite_princ",
      "derniere_embauche",
      "matricule_wd",
      "matricule_hr_access",
      "email_perso",
      "prenom_conjoint",
      "nom_conjoint",
      "entree_groupe",
      "date_raw_load_file",
      "filepath",
      "filename",
      "curated_ingested_date"
      )  //read parquet file
}

// COMMAND ----------

// MAGIC %md #### HRA Nationnalite secondaire

// COMMAND ----------

// DBTITLE 1,Set table Natio Sec
val table_natio_sec = "employee." + system_source.toLowerCase() + "_natio_sec"

// COMMAND ----------

// DBTITLE 1,Refresh table natio sec
if(spark.catalog.tableExists(table_natio_sec)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_natio_sec)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Data Natio Sec
val bynatio = Window.partitionBy("matricule_wd","matricule_hr_access").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_nationalite_hra_read = spark.table(table_natio_sec).filter($"date_raw_load_file"===partition_date_sal)
                                                    .withColumn("rank",rank() over bynatio)
                                                    .filter(col("rank")==="1").select("matricule_wd","matricule_hr_access",
                                                                                                                     "nationalite_secondaire") 

// COMMAND ----------

// MAGIC %md ####  Workday Histo

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded for Histo Site
val partition_date_site = get_last_partition_file("/employee/workday/histo_site",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Refresh table Histo Site
if(spark.catalog.tableExists("employee.histo_site")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.histo_site")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Data Histo Site
val defaultEndDate = LocalDate.parse("2999-12-31", DateTimeFormatter.ofPattern("yyyy-MM-dd"))     
val window = Window.partitionBy("employee_id").orderBy($"effective_date_from_location_change".asc)

val df_histosite_read = spark.table("employee.histo_site").where($"date_raw_load_file"===partition_date_site)
                                                          .withColumnRenamed("business_site_summary_data_name","location")
                                                          .withColumn("end_effective_date_from_location_change", 
                                                                                when ($"effective_date_from_location_change".isNotNull
                                                                              ,lead($"effective_date_from_location_change"-1,1,defaultEndDate).over(window))
                                                                              .otherwise(defaultEndDate))
                                                          .select("employee_id","location","effective_date_from_location_change","end_effective_date_from_location_change")


// COMMAND ----------

// MAGIC %md #### PA Histograde

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded for Histo Grade
val partition_date_grade = get_last_partition_file("/employee/pa/pa_histograde",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Refresh Histo Grade
if(spark.catalog.tableExists("employee.pa_histograde")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.pa_histograde")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Data Histo Grade
val defaultEndDate = LocalDate.parse("2999-12-31", DateTimeFormatter.ofPattern("yyyy-MM-dd"))     
val window = Window.partitionBy("matricule_wd", "matricule_hr_access").orderBy($"effective_compensation_change_date".asc)

val df_PAhisto_read = spark.table("employee.pa_histograde").filter($"date_raw_load_file"===partition_date_grade).select("matricule_wd","matricule_hr_access",
                                                                  "manager_reference","manager_last_name",
                                                                  "manager_first_name", "effective_compensation_change_date","end_compensation_change_date")
                                                            .withColumn("end_compensation_change_date", 
                                                                        when ($"end_compensation_change_date".isNotNull
                                                                              ,lead($"effective_compensation_change_date"-1,1,defaultEndDate).over(window))
                                                                        .otherwise($"end_compensation_change_date"))
                                              

// COMMAND ----------

// MAGIC %md ##### PowerApps

// COMMAND ----------

// DBTITLE 1,Get Data from PowerApps table
spark.read.jdbc(jdbcurl, "powerapps.hra_employee", connectionproperties).select("hra_employee_id","matricule_hra","last_name","first_name","primary_work_email","band","location","business_line_reference","business_line","contractual_individual_variable").createOrReplaceTempView("vw_powerapps_hra_employee")
val df_powerapps = spark.table("vw_powerapps_hra_employee")

// COMMAND ----------

// MAGIC %md ##### transco

// COMMAND ----------

// DBTITLE 1,Get Transco Values
spark.read.jdbc(jdbcurl, "dbo.param_transco_ref",connectionproperties).createOrReplaceTempView("vw_dbo_param_transco_ref")
val df_transco = spark.table("vw_dbo_param_transco_ref").na.fill("Nothing")


// COMMAND ----------

// MAGIC %md ##2- Build Datamart Employee

// COMMAND ----------

// DBTITLE 1,Build Each Employee Situation
val df_employee_situations =  df_salariehra_read.join(df_costcenterhra_read,
                                                      (df_salariehra_read.col("matricule_wd") === df_costcenterhra_read.col("matricule_wd") 
                                                       or df_salariehra_read.col("matricule_hr_access") === df_costcenterhra_read.col("matricule_hr_access") ) ,"left")
                                               .select(df_salariehra_read.col("matricule_wd"),
                                                       df_salariehra_read.col("matricule_hr_access"),
                                                       df_costcenterhra_read.col("date_deb_centre_cout") as "record_start_date" )

                                   .union(df_salariehra_read.join(df_societehra_read,
                                                                  (df_salariehra_read.col("matricule_wd") === df_societehra_read.col("matricule_wd") or
                                                                   df_salariehra_read.col("matricule_hr_access") === df_societehra_read.col("matricule_hr_access") )               
                                                                  ,"left")
                                          .select(df_salariehra_read.col("matricule_wd"),
                                                  df_salariehra_read.col("matricule_hr_access"),
                                                  df_societehra_read.col("date_deb_societe") as "record_start_date" ))
                                          
                                    .union(df_salariehra_read.join(df_etablissementhra_read,
                                                                   (df_salariehra_read.col("matricule_wd") === df_etablissementhra_read.col("matricule_wd") or
                                                                    df_salariehra_read.col("matricule_hr_access") === df_etablissementhra_read.col("matricule_hr_access"))
                                                                   ,"left")
                                           .select(df_salariehra_read.col("matricule_wd")
                                                   ,df_salariehra_read.col("matricule_hr_access"),
                                                   df_etablissementhra_read.col("date_deb_etablissement") as "record_start_date" ))
                                          
                                    .union(df_salariehra_read.join(df_organisationhra_read,
                                                                   (df_salariehra_read.col("matricule_wd") === df_organisationhra_read.col("matricule_wd") or 
                                                                    df_salariehra_read.col("matricule_hr_access") === df_organisationhra_read.col("matricule_hr_access") )
                                                                   ,"left")
                                           .select(df_salariehra_read.col("matricule_wd"),
                                                   df_salariehra_read.col("matricule_hr_access"),
                                                   df_organisationhra_read.col("date_deb_org") as "record_start_date" ))
                                           
                                     .union(df_salariehra_read.join(df_PAhisto_read,
                                              (df_salariehra_read.col("matricule_wd") === df_PAhisto_read.col("matricule_wd") 
                                               or df_salariehra_read.col("matricule_hr_access") === df_PAhisto_read.col("matricule_hr_access") )
                                              ,"left")
                                            .select(df_salariehra_read.col("matricule_wd"),
                                                    df_salariehra_read.col("matricule_hr_access"),
                                                    df_PAhisto_read.col("effective_compensation_change_date") as "record_start_date" ))

                                      .union(df_salariehra_read.join(df_histosite_read,
                                              (df_salariehra_read.col("matricule_wd") === df_histosite_read.col("employee_id"))
                                              ,"left")
                                            .select(df_salariehra_read.col("matricule_wd"),
                                                    df_salariehra_read.col("matricule_hr_access"),
                                                    df_histosite_read.col("effective_date_from_location_change") as "record_start_date" ))

                                      .distinct()
                                  .filter("record_start_date is not null")
                                  .distinct()

// COMMAND ----------

// DBTITLE 1,Get All Matricule workday and hra from different sources
val all_hra = df_costcenterhra_read.select("matricule_wd","matricule_hr_access")
                              .union(df_societehra_read.select("matricule_wd","matricule_hr_access"))
                              .union(df_etablissementhra_read.select("matricule_wd","matricule_hr_access"))
                              .union(df_organisationhra_read.select("matricule_wd","matricule_hr_access"))
                              .union(df_nationalite_hra_read.select("matricule_wd","matricule_hr_access"))
                              .union(df_salariehra_read.select("matricule_wd","matricule_hr_access")).distinct

// COMMAND ----------

// DBTITLE 1,Build employee matricule hra from matricule workday
val df_employee_situations_2 = df_employee_situations.as("c").join(all_hra.as("s"),$"c.matricule_wd"===$"s.matricule_wd","left")
                                                           .withColumn("matricule_hr_access_2",when($"c.matricule_hr_access".isNull,$"s.matricule_hr_access")
                                                                                             .otherwise($"c.matricule_hr_access"))
                                                            .select("c.matricule_wd","matricule_hr_access_2","record_start_date").distinct
                                                            .withColumnRenamed("matricule_hr_access_2","matricule_hr_access")

// COMMAND ----------

// DBTITLE 1,Ordered each situation by date ascending
val thresholdDate = LocalDate.parse(if (flux=="quotidien") {load_date} else {limit_date}, DateTimeFormatter.ofPattern("yyyy-MM-dd"))     

//.where($"record_start_date"<thresholdDate)
val window = Window.partitionBy("matricule_wd", "matricule_hr_access").orderBy($"record_start_date".desc)
val resultSet_ordered = df_employee_situations_2.where($"record_start_date"<=thresholdDate).withColumn("record_end_date", lag($"record_start_date", 1, null).over(window) )
                                               .withColumn("record_end_date", $"record_end_date" - expr("INTERVAL 1 DAYS"))
                                              

var resultSet_ordered_2  = spark.emptyDataFrame
if (flux=="quotidien"){
  resultSet_ordered_2 = resultSet_ordered.where($"record_end_date".isNull).cache()
}
else{
  resultSet_ordered_2 = resultSet_ordered.cache()
}

// COMMAND ----------

// DBTITLE 1,Build different situations for each employee
val resultSet = resultSet_ordered_2.as("e")
                                  .join(df_salariehra_detail_read.as("d"),  
                                        ($"e.matricule_wd" === $"d.matricule_wd" 
                                    or $"e.matricule_hr_access" === $"d.matricule_hr_access" 
                                               ),"left" )

                                        .join(df_costcenterhra_read.as("cc"), 
                                              (($"e.matricule_wd" === $"cc.matricule_wd"
                                    or $"e.matricule_hr_access" === $"cc.matricule_hr_access" ) 
                                   and $"e.record_start_date" >= $"cc.date_deb_centre_cout" 
                                   and $"e.record_start_date" <= $"cc.date_fin_centre_cout" 
                                              ),"left")

                                         .join(df_organisationhra_read.as("org"), 
                                              (($"e.matricule_wd" === $"org.matricule_wd" 
                                    or $"e.matricule_hr_access" === $"org.matricule_hr_access" ) 
                                   and $"e.record_start_date" >= $"org.date_deb_org" 
                                   and $"e.record_start_date" <= $"org.date_fin_org" 
                                              ),"left")
                                  

                                  .join(df_etablissementhra_read.as("eta"), 
                                              (($"e.matricule_wd" === $"eta.matricule_wd" 
                                    or $"e.matricule_hr_access" === $"eta.matricule_hr_access"  ) 
                                   and $"e.record_start_date" >= $"eta.date_deb_etablissement" 
                                   and $"e.record_start_date" <= $"eta.date_fin_etablissement" 
                                              ),"left")

                                   .join(df_societehra_read.as("soc"), 
                                              (($"e.matricule_wd" === $"soc.matricule_wd" 
                                    or $"e.matricule_hr_access" === $"soc.matricule_hr_access" ) 
                                   and $"e.record_start_date" >= $"soc.date_deb_societe" 
                                   and $"e.record_start_date" <= $"soc.date_fin_societe" 
                                              ),"left")

                                    .join(df_PAhisto_read.as("PAh"),
                                                (($"e.matricule_wd" === $"PAh.matricule_wd" 
                                    or $"e.matricule_hr_access" === $"PAh.matricule_hr_access" )
                                                and $"e.record_start_date" >= $"PAh.effective_compensation_change_date" 
                                   and $"e.record_start_date" <= $"PAh.end_compensation_change_date")
                                                ,"left")
                                  
                                    .join(df_histosite_read.as("site"),
                                                (($"e.matricule_wd" === $"site.employee_id" )
                                                and $"e.record_start_date" >= $"site.effective_date_from_location_change" 
                                   and $"e.record_start_date" <= $"site.end_effective_date_from_location_change")
                                                ,"left")
                                 
                                   .join(df_nationalite_hra_read.as("nat_sec"),
                                        ($"e.matricule_wd" === $"nat_sec.matricule_wd" 
                                         or $"e.matricule_hr_access" === $"nat_sec.matricule_hr_access" 
                                            ),"left")

                                 //powerapps
                                .join(df_powerapps.as("powerapps")
                                      ,$"e.matricule_hr_access"=== $"powerapps.matricule_hra","left")
               
                            .withColumn("current_record", when($"record_end_date".isNull, true).otherwise(false))
                            
                            .withColumn("effective_organization_change_date",  when(($"site.effective_date_from_location_change" >= $"PAh.effective_compensation_change_date"  //Location
                                                                                or $"PAh.effective_compensation_change_date".isNull) 
                                                                           and ($"site.effective_date_from_location_change" >= $"cc.date_deb_centre_cout" 
                                                                                or $"cc.date_deb_centre_cout".isNull)
                                                                           and ($"site.effective_date_from_location_change" >= $"org.date_deb_org" 
                                                                                or $"org.date_deb_org".isNull)
                                                                           and ($"site.effective_date_from_location_change" >= $"eta.date_deb_etablissement" 
                                                                                or $"eta.date_deb_etablissement".isNull)
                                                                           and ($"site.effective_date_from_location_change" >= $"soc.date_deb_societe" 
                                                                                or $"soc.date_deb_societe".isNull), $"site.effective_date_from_location_change")
                                                                         
                                                                          .when(($"PAh.effective_compensation_change_date" >= $"site.effective_date_from_location_change" //Manager
                                                                                or $"site.effective_date_from_location_change".isNull) //fte
                                                                           and ($"PAh.effective_compensation_change_date" >= $"cc.date_deb_centre_cout" 
                                                                                or $"cc.date_deb_centre_cout".isNull)
                                                                           and ($"PAh.effective_compensation_change_date" >= $"org.date_deb_org" 
                                                                                or $"org.date_deb_org".isNull)
                                                                           and ($"PAh.effective_compensation_change_date" >= $"eta.date_deb_etablissement" 
                                                                                or $"eta.date_deb_etablissement".isNull)
                                                                           and ($"PAh.effective_compensation_change_date" >= $"soc.date_deb_societe" 
                                                                                or $"soc.date_deb_societe".isNull), $"PAh.effective_compensation_change_date")
                                                                        
                                                                        
                                                                         .when(($"cc.date_deb_centre_cout" >= $"site.effective_date_from_location_change"  //centre de cout
                                                                                or $"site.effective_date_from_location_change".isNull) 
                                                                           and ($"cc.date_deb_centre_cout" >= $"PAh.effective_compensation_change_date" 
                                                                                or $"PAh.effective_compensation_change_date".isNull)
                                                                           and ($"cc.date_deb_centre_cout" >= $"org.date_deb_org" 
                                                                                or $"org.date_deb_org".isNull)
                                                                           and ($"cc.date_deb_centre_cout" >= $"eta.date_deb_etablissement" 
                                                                                or $"eta.date_deb_etablissement".isNull)
                                                                           and ($"cc.date_deb_centre_cout" >= $"soc.date_deb_societe" 
                                                                                or $"soc.date_deb_societe".isNull), $"cc.date_deb_centre_cout")
                                        
                                        
                                                                        .when(($"org.date_deb_org" >= $"site.effective_date_from_location_change" 
                                                                               or $"site.effective_date_from_location_change".isNull) //Orga
                                                                          and ($"org.date_deb_org" >= $"PAh.effective_compensation_change_date" 
                                                                               or $"PAh.effective_compensation_change_date".isNull)
                                                                          and ($"org.date_deb_org" >= $"cc.date_deb_centre_cout" 
                                                                               or $"cc.date_deb_centre_cout".isNull)
                                                                          and ($"org.date_deb_org" >= $"eta.date_deb_etablissement"
                                                                               or $"eta.date_deb_etablissement".isNull)
                                                                           and ($"org.date_deb_org" >= $"soc.date_deb_societe" 
                                                                                or $"soc.date_deb_societe".isNull), $"org.date_deb_org")
                                        
                                        
                                                                      .when(($"eta.date_deb_etablissement" >= $"site.effective_date_from_location_change" 
                                                                             or $"site.effective_date_from_location_change".isNull)//etablissement
                                                                          and ($"eta.date_deb_etablissement" >= $"PAh.effective_compensation_change_date" 
                                                                               or $"PAh.effective_compensation_change_date".isNull)
                                                                          and ($"eta.date_deb_etablissement" >= $"cc.date_deb_centre_cout" 
                                                                               or $"cc.date_deb_centre_cout".isNull)
                                                                          and ($"eta.date_deb_etablissement" >= $"org.date_deb_org"
                                                                               or $"org.date_deb_org".isNull)
                                                                           and ($"eta.date_deb_etablissement" >= $"soc.date_deb_societe" 
                                                                                or $"soc.date_deb_societe".isNull), $"eta.date_deb_etablissement")                                    
                                                                      
                                                                        .otherwise($"soc.date_deb_societe"))  //societe

                                                                 

                                  .distinct()
resultSet_ordered_2.unpersist()

// COMMAND ----------

// DBTITLE 1,Get Transco Data from hra and workday
val df_employee_transco = gettransco2(df_transco,resultSet,system_source,"workday")


// COMMAND ----------

// DBTITLE 1,Select Data from transco
                
val df_employee_transco_new = df_employee_transco._1.select(
                  $"e.matricule_wd",
                  $"e.matricule_hr_access",
                  $"record_start_date",
                  $"record_end_date",
                  $"current_record",
                  $"compte_ad",
                  $"prefix",
                  $"nom_usuel",
                  $"population_particuliere",
                  $"d.prenom",
                  $"d.date_naissance",
                  $"email_pro",
                  $"nom_patronymique",
                  $"complement_adresse",
                  $"no_adresse",
                  $"bis_ter_adresse",
                  $"nature_voie",
                  $"nom_voie",
                  $"code_postal",
                  $"commune",
                  $"code_insee_commune",
                  $"bureau_distributeur",
                  $"pays_adresse",
                  $"nir",
                  $"etat_civil",
                  $"marital_status_label",
                  $"anciennete_poste",
                  $"ville_naissance",
                  $"gender",
                  $"department_of_birth",
                  $"pays_naissance",
                  $"nationalite_princ",
                  $"nationalite_secondaire",
                  $"email_perso",
                  $"prenom_conjoint",
                  $"nom_conjoint",
                  $"centre_cout",
                  $"libelle_centre_cout",
                  $"date_deb_centre_cout",
                  $"date_fin_centre_cout",
                  $"date_deb_org",
                  $"date_fin_org",
                  $"code_direction",
                  $"libelle_direction",
                  $"code_departement",
                  $"libelle_departement",
                  $"date_deb_etablissement",
                  $"date_fin_etablissement",
                  $"code_etablissement",
                  $"date_deb_societe",
                  $"date_fin_societe" ,
                  $"code_societe" , 
                  $"company" ,
                  $"manager_reference",
                  $"manager_last_name",
                  $"manager_first_name",
                  $"date_raw_load_file",
                  $"filepath",
                  $"filename",
                  $"curated_ingested_date",
                  $"last_name",
                  $"first_name",
                  $"primary_work_email",
                  $"site.location",
                  $"business_line_reference",
                  $"business_line",
                  $"contractual_individual_variable",
                  $"effective_organization_change_date"
)
df_employee_transco_new.createOrReplaceTempView("vw_employeeHisto")


// COMMAND ----------

// DBTITLE 1,Employee Query
val resultSet_query = spark.sql("""

  select distinct
     getconcatenedstring(array(matricule_wd,matricule_hr_access)) as employee_key
    ,sha2(getconcatenedstring(array(matricule_wd, matricule_hr_access)),256) as employee_code
    ,matricule_wd as employee_id
    ,matricule_hr_access as france_payroll_id
    ,nom_usuel as last_name
    ,prenom as first_name
    ,nom_patronymique as birth_name
    ,prefix
    ,gender
    ,date_naissance as birth_date
    ,ville_naissance as city_of_birth
    ,department_of_birth
    ,pays_naissance as country_of_birth
    ,nationalite_princ as primary_nationality
    ,nationalite_secondaire as additional_nationalities
    ,email_pro as primary_work_email
    ,email_perso as primary_home_email
    ,no_adresse as street_number
    ,bis_ter_adresse as street_number_extension
    ,nom_voie as street_name
    ,complement_adresse as additional_address
    ,code_postal as postal_code
    ,commune as city
    ,etat_civil as marital_status
    ,marital_status_label
    ,nir as national_identifier
    ,compte_ad as user_name
    ,null as igi_identification
    ,prenom_conjoint as spouse_first_name
    ,nom_conjoint as  spouse_last_name
    ,manager_reference
    ,manager_last_name
    ,manager_first_name
    ,centre_cout as cost_center_code 
    ,code_societe as company_id
    ,code_departement as code_department
    ,code_direction 
    ,code_etablissement as code_establishment
    ,date_deb_centre_cout as cost_center_start_date
    ,date_fin_centre_cout as cost_center_end_date
    ,date_deb_etablissement as establishment_start_date
    ,date_fin_etablissement as establishment_end_date
    ,date_deb_societe as company_start_date
    ,date_fin_societe as company_end_date
    ,date_deb_org as organization_start_date
    ,date_fin_org as organization_end_date
    ,null as lt_leader_last_name_n_1
    ,null as lt_leader_first_name_n_1 
    ,null as lt_leader_reference_n_1 
    ,null as lt_leader_last_name
    ,null as lt_leader_first_name
    ,null as lt_leader_reference
    ,null as supervisory_organization_name
    ,null as supervisory_organization_reference
    ,effective_organization_change_date
    ,date_deb_centre_cout as effective_organization_hierarchy_change_date
    ,null as effective_suporg_change_date    

    ,sha2(location,256) as location_code  

    ,sha2(getconcatenedstring(array(nationalite_princ, nationalite_secondaire)),256) as nationality_code
    ,sha2(getconcatenedstring(array(manager_reference,
                          null,
                          null)),256) as manager_code
    ,sha2(null,256) as supervisory_organization_code
    ,sha2(business_line_reference,256) as business_line_code
    ,sha2(getconcatenedstring(array(centre_cout, code_societe, code_etablissement)),256) as legal_organization_code
    ,sha2(getconcatenedstring(array(centre_cout, code_direction, code_departement,null,null)),256) as operational_organization_code
    ,sha2(getconcatenedstring(array(date_deb_etablissement, date_fin_etablissement, date_deb_societe,date_fin_societe)),256) as org_in_out_dates_code
    ,null as local_pb_hierarchy_code
    ,null as local_pb_hierarchy_name
    ,population_particuliere as special_population
    ,null as version
    ,date_raw_load_file
    ,filepath
    ,filename
    ,curated_ingested_date
    ,current_record
    ,record_start_date
    ,record_end_date
    ,current_timestamp() as record_creation_date
    ,current_timestamp() as record_modification_date
    ,getconcatenedstring(array(  nom_usuel
                                ,prenom
                                ,nom_patronymique
                                ,prefix
                                ,gender
                                ,date_naissance
                                ,ville_naissance
                                ,department_of_birth
                                ,pays_naissance
                                ,nationalite_princ
                                ,nationalite_secondaire
                                ,email_pro
                                ,email_perso
                                ,no_adresse
                                ,bis_ter_adresse
                                ,nom_voie
                                ,complement_adresse
                                ,code_postal
                                ,commune
                                ,etat_civil
                                ,marital_status_label
                                ,nir
                                ,compte_ad
                                ,null
                                ,prenom_conjoint
                                ,nom_conjoint
                                ,manager_reference
                                ,manager_last_name
                                ,manager_first_name
                                ,centre_cout
                                ,code_societe
                                ,code_departement
                                ,code_direction
                                ,code_etablissement
                                ,date_deb_centre_cout
                                ,date_fin_centre_cout
                                ,date_deb_etablissement
                                ,date_fin_etablissement
                                ,date_deb_societe
                                ,date_fin_societe
                                ,date_deb_org
                                ,date_fin_org
                                ,null
                                ,null
                                ,null
                                ,null
                                ,null
                                ,null
                                ,null
                                ,null
                                ,effective_organization_change_date
                                ,null )) as hashkey
    , '""" + runid + """' as runid
    , lower(trim(split(filepath,"/")[3])) as system_source
  from vw_employeeHisto

""").filter("cost_center_code is not null").cache()

// COMMAND ----------

// DBTITLE 1,Refresh table Employee
if(spark.catalog.tableExists("hr.employee")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Data from table hr employee
val employee_table = DeltaTable.forName("hr.employee")

// COMMAND ----------

// DBTITLE 1,Merge employees table
if (flux=="quotidien"){
  //Rows for information updated of existing employees
  val df_results = resultSet_query.where($"special_population"===1)
  val newemployee = df_results.as("employee_updated")
  .join(employee_table.toDF.as("employee"), $"employee.france_payroll_id"===$"employee_updated.france_payroll_id" or
                                          $"employee.employee_id"===$"employee_updated.employee_id")
  .where("""employee.current_record = true and (employee_updated.hashkey <> employee.hashkey) and employee_updated.date_raw_load_file >= employee.date_raw_load_file """)

  //Union of dataframes between contracts updated from existing information and new information from new employees
  val employee_upsert = newemployee
  .selectExpr("null as mergekey_1","null as mergekey_2","employee_updated.*")   // Rows for 1.
  .union(
    df_results.as("df_results").selectExpr("df_results.employee_id as mergekey_1",
                                           "df_results.france_payroll_id as mergekey_2",
                                           "*")  // Rows for 2.
  )

  //remove duplicate
  val employee_upsert_distinct = employee_upsert.distinct()

  //merge on table employee
  employee_table.alias("t")
  .merge(
    employee_upsert_distinct.alias("s"),
    """t.employee_id=s.mergekey_1 or
    t.france_payroll_id=s.mergekey_2  
    """)
  .whenMatched("""t.current_record = true and (t.hashkey <> s.hashkey) and s.date_raw_load_file > t.date_raw_load_file """)
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "date_add(s.record_start_date,-1)",
    "record_modification_date" -> "s.record_modification_date",
    "runid" -> "s.runid")
  )
  .whenNotMatched().insertAll()
  .execute()
}

else{
employee_table.alias("t")
  .merge(
    resultSet_query.alias("s"),
    """s.france_payroll_id=t.france_payroll_id or 
    s.employee_id=t.employee_id""")
  
  .whenNotMatched().insertAll()
  .execute()
}


// COMMAND ----------

// DBTITLE 1,Update effective_organization_hierarchy_change_date
spark.sql("""update hr.employee set effective_organization_hierarchy_change_date = case when effective_organization_change_date < cost_center_start_date or cost_center_start_date is null  then cost_center_start_date else effective_organization_change_date end where effective_organization_hierarchy_change_date is null """)

// COMMAND ----------

// DBTITLE 1,Optimize employee table
spark.sql("OPTIMIZE hr.employee")

// COMMAND ----------

// DBTITLE 1,Get Statistics
val read_records = df_salariehra_read.count().toInt //count the number of read records//set up the return value with the number of lines read, rejected and inserted
val inserted_records = resultSet_query.count().toInt //count the number of records to upsert
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0
resultSet_query.unpersist()

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.employee 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return Value
  dbutils.notebook.exit(return_value)