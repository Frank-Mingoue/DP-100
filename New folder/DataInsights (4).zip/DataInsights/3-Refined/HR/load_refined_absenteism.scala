// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include notebook containing functions to connect to adls container, get database url and properties
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Configuration
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "50") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Set Configuration to the database
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.absprev
if(spark.catalog.tableExists("absenteism.absprev")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.absprev")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.codeevt
if(spark.catalog.tableExists("absenteism.codeevt")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.codeevt")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Refresh table absenteism.referentiel_absences
if(spark.catalog.tableExists("absenteism.referentiel_absences")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE absenteism.referentiel_absences")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get all days off from database
val bydate = Window.orderBy("date")
val days_off =  spark.read.jdbc(jdbcurl, "dbo.d_date", connectionproperties).filter($"business_day_fr".isNull)
                                                                            .select("date")
                                                                            .withColumn("previous_date", lag($"date",1,null).over(bydate))
                                                                            .withColumn("previous_date_bis", lag($"date",2,null).over(bydate))
                                                                            .distinct
days_off.createOrReplaceTempView("vw_days_off")

// COMMAND ----------

// DBTITLE 1,Get the last absprev partition from the load_date
val partition_absprev = get_last_partition_file("/absenteism/gestor/absprev",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source  and Create the windowing function in order to filter the last employee information sent by grouping by employee_id and sort by filename desc. then create the temp view

val byabsenteism = Window.partitionBy("matricule","dateval_month").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_absenteism_read =  spark.table("absenteism.absprev").filter("date_raw_load_file = '" + partition_absprev + "'")
                                                           .withColumn("dateval_month",date_format($"dateval","yyyyMM"))
                                                           .withColumn("old_matricule", $"matricule")
                                                           .withColumn("matricule", substring_index($"matricule", "_", 1))
                                                           .withColumn("rank",rank() over byabsenteism)
                                                           .filter(col("rank")==="1") 
                                                           .distinct //path to read parquet files

df_absenteism_read.cache()  //put the dataframe ont he cache
df_absenteism_read.createOrReplaceTempView("vw_absenteism") // create a temp view

// COMMAND ----------

// DBTITLE 1,Get the last codeevt partition from the load_date
val partition_codeevt = get_last_partition_file("/absenteism/gestor/codeevt",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source  and Create the windowing function in order to filter the last code evt sent by grouping by code and sort by filename desc. then create the temp view
val bycodeevt = Window.partitionBy("code").orderBy($"filename".desc,$"date_raw_load_file".desc, $"version".desc)
val df_codeevt_read =  spark.table("absenteism.codeevt").filter("date_raw_load_file = '" + partition_codeevt + "'")
                                                        .withColumn("rank",rank() over bycodeevt).filter(col("rank")==="1")   //read parquet file
df_codeevt_read.createOrReplaceTempView("vw_codeevt") // create a temp view

// COMMAND ----------

// DBTITLE 1,Get the last referentiel_absences partition from the load_date
val partition_ref_absences = get_last_partition_file("/absenteism/business/referentiel_absences",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source  and Create the windowing function in order to filter the last code evt sent by grouping by code and sort by filename desc. then create the temp view
val byref_abs = Window.partitionBy("code_absence").orderBy($"filename".desc,$"date_raw_load_file".desc, $"version".desc)
val df_ref_abs_read =  spark.table("absenteism.referentiel_absences").filter("date_raw_load_file = '" + partition_ref_absences + "'")
                                                        .withColumn("rank",rank() over byref_abs)
                                                        .filter(col("rank")==="1")
                                                        .withColumn("absence_code",col("code_absence"))//read parquet file
df_ref_abs_read.createOrReplaceTempView("vw_ref_abs") // create a temp view	
df_ref_abs_read.cache()  //put the dataframe ont he cache


// COMMAND ----------

// DBTITLE 1,Get absence days that are week-ends or days off
spark.sql(""" select distinct 
                     dateval, 
                     matricule, 
                     code 
                     
              from   vw_absenteism  a 
                     inner join vw_ref_abs b on a.code = b.absence_code 
                     inner join vw_days_off o on o.date = a.dateval
                     
              where  1=1
          """).createOrReplaceTempView("vw_absenteism_we")

// COMMAND ----------

// DBTITLE 1,Refresh Table hr.absenteism 
  try {
    spark.sql("FSCK REPAIR TABLE hr.absenteism")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }

// COMMAND ----------

// DBTITLE 1,Get Existing partitions from table hr.absenteism
val absenteism_table = DeltaTable.forName("hr.absenteism").toDF.select("period_abs_month","date_raw_load_file").distinct
absenteism_table.createOrReplaceTempView("vw_absenteism_table")

// COMMAND ----------

// DBTITLE 1,Query to select only absenteism data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source_days_abs = """
                                      select distinct
                                             getconcatenedstring(array(
                                                                             a.dateval
                                                                            ,a.hdeb
                                                                            ,a.hfin
                                                                            ,a.duree
                                                                            ,a.code
                                                                            ,a.type
                                                                            ,a.matricule
                                                                           )) as abs_key 
                                            ,cast(a.nummat as string) as emp_num
                                            ,a.dateval as dateval
                                            ,a.hdeb as h_start
                                            ,a.hfin as h_end
                                            ,a.duree as duration_hours
                                            ,a.nbrvac as duration_days
                                            ,a.code as code
                                            ,c.libelle as label
                                            ,c.type_libelle as label_type_code
                                            ,c.famregroup_libelle as famregroup_label
                                            ,a.type as type
                                            ,a.signature as signature
                                            ,a.matricule as employee_hra
                                            ,a.type_libelle as label_type
                                            ,r.type_absence
                                            ,0 as is_added_day
                                            ,a.dateval_month as period_abs_month
                                            ,a.version
                                            ,a.date_raw_load_file
                                            ,a.filepath
                                            ,a.filename
                                            ,to_date(a.curated_ingested_date) as curated_ingested_date
                                            ,true as current_record
                                            ,a.date_raw_load_file as record_start_date
                                            ,null as record_end_date
                                            ,current_timestamp() as record_creation_date
                                            ,current_timestamp() as record_modification_date
                                            ,getconcatenedstring(array(
                                                                             a.nummat
                                                                            ,a.dateval
                                                                            ,a.hdeb
                                                                            ,a.hfin
                                                                            ,a.duree
                                                                            ,a.nbrvac
                                                                            ,a.code
                                                                            ,c.libelle
                                                                            ,c.type_libelle
                                                                            ,c.famregroup_libelle
                                                                            ,a.type
                                                                            ,a.signature
                                                                            ,a.matricule
                                                                            ,a.type_libelle
                                                                            ,r.type_absence
                                                                           )) as hashkey 
                                           ,'""" + runid + """' as runid
                                           ,lower(trim(split(a.filepath,"/")[3])) as system_source
                                   from    vw_absenteism a
                                          inner join vw_codeevt c on a.code = c.code
                                          left join vw_absenteism_table at on at.period_abs_month = a.dateval_month
                                          left join vw_ref_abs r on r.absence_code = a.code

                                  where   1 = 1
                                    and   a.matricule is not null
                                    and   (a.date_raw_load_file > at.date_raw_load_file or at.date_raw_load_file is null)
                                 """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results_days_abs = spark.sql(query_source_days_abs).cache


// COMMAND ----------

// DBTITLE 1,Query for week-end and days off to add
val query_source_days_off = """
                                select distinct
                                       getconcatenedstring(array(
                                                                       d.date
                                                                      ,coalesce(a.hdeb, 0)
                                                                      ,coalesce(a.hfin, 0)
                                                                      ,a.duree
                                                                      ,a.code
                                                                      ,a.type
                                                                      ,a.matricule
                                                                     )) as abs_key 
                                      ,cast(a.nummat as string) as emp_num
                                      ,d.date as dateval
                                      ,coalesce(a.hdeb, 0)
                                      ,coalesce(a.hfin, 0)
                                      ,a.duree as duration_hours
                                      ,case when upper(a.code) = 'MITT' then a.nbrvac else 1 end as duration_days
                                      ,a.code as code
                                      ,c.libelle as label
                                      ,c.type_libelle as label_type_code
                                      ,c.famregroup_libelle as famregroup_label
                                      ,a.type as type
                                      ,a.signature as signature
                                      ,a.matricule as employee_hra
                                      ,a.type_libelle as label_type
                                      ,r.type_absence
                                      ,1 as is_added_day
                                      ,date_format(d.date,'yyyyMM') as period_abs_month
                                      ,a.version
                                      ,a.date_raw_load_file
                                      ,a.filepath
                                      ,a.filename
                                      ,to_date(a.curated_ingested_date) as curated_ingested_date
                                      ,true as current_record
                                      ,a.date_raw_load_file as record_start_date
                                      ,null as record_end_date
                                      ,current_timestamp() as record_creation_date
                                      ,current_timestamp() as record_modification_date
                                      ,getconcatenedstring(array(
                                                                       a.nummat
                                                                      ,d.date
                                                                      ,coalesce(a.hdeb, 0)
                                                                      ,coalesce(a.hfin, 0)
                                                                      ,a.duree
                                                                      ,1
                                                                      ,a.code
                                                                      ,c.libelle
                                                                      ,c.type_libelle
                                                                      ,c.famregroup_libelle
                                                                      ,a.type
                                                                      ,a.signature
                                                                      ,a.matricule
                                                                      ,a.type_libelle
                                                                      ,r.type_absence
                                                                     )) as hashkey 
                                     ,'""" + runid + """' as runid
                                     ,lower(trim(split(a.filepath,"/")[3])) as system_source
                             from    vw_absenteism a
                                     inner join vw_codeevt c on a.code = c.code
                                     left join vw_absenteism_table at on at.period_abs_month = a.dateval_month
                                     inner join vw_ref_abs r on r.absence_code = a.code
                                     left join vw_absenteism_we w_sat on w_sat.matricule = a.matricule
                                                                  and date_add(a.dateval, 1) = w_sat.dateval
                                                                  
                                     left join vw_absenteism_we w_sun on w_sun.matricule = a.matricule
                                                                  and date_add(a.dateval, 2) = w_sun.dateval
                                                                  
                                     left join vw_absenteism_we w_day on w_day.matricule = a.matricule
                                                                  and date_add(a.dateval, 3) = w_day.dateval
                                                                  
                                     inner join vw_days_off d on   (  
                                                                   /***********date absence is friday and next day is saturday***********/
                                                                   (date_add(a.dateval, 1) = d.date 
                                                                     and lower(date_format(a.dateval,'EEEE')) = "friday"
                                                                     and lower(date_format(d.date,'EEEE')) = "saturday"
                                                                     and w_sat.dateval is null
                                                                   ) or        
                                                                   
                                                                   /***********date absence is friday and next two days is sunday***********/
                                                                   (date_add(a.dateval, 2) = d.date 
                                                                     and lower(date_format(a.dateval,'EEEE')) = "friday"
                                                                     and lower(date_format(d.date,'EEEE')) = "sunday"
                                                                     and w_sun.dateval is null
                                                                     and w_sat.dateval is null
                                                                   ) or
                                                                   
                                                                   /***********date absence is saturday and next day is sunday***********/
                                                                   (date_add(a.dateval, 1) = d.date 
                                                                     and lower(date_format(a.dateval,'EEEE')) = "saturday"
                                                                     and lower(date_format(d.date,'EEEE')) = "sunday"
                                                                     and w_sat.dateval is null
                                                                   ) or                                                                                                       
                                                                  
                                                                  /***********date absence is open day and next day is day off***********/
                                                                  (date_add(a.dateval, 1) = d.date 
                                                                     and lower(date_format(d.date,'EEEE')) not in ("saturday","sunday")
                                                                     and w_sat.dateval is null
                                                                     
                                                                  ) or                   
                                                                   
                                                                 /***********date absence is friday and the next monday is day off***********/
                                                                  (lower(date_format(date_add(a.dateval, 1),'EEEE')) = "saturday" 
                                                                     and date_add(a.dateval, 3) = d.date 
                                                                     and lower(date_format(d.date,'EEEE')) not in ("saturday","sunday")
                                                                     and w_sat.dateval is null
                                                                     and w_sun.dateval is null
                                                                     and w_day.dateval is null
                                                                  ) or  
                                                                 
                                                                 /***********date absence is saturday and the next monday is day off***********/
                                                                  (lower(date_format(date_add(a.dateval, 1),'EEEE')) = "sunday" 
                                                                     and date_add(a.dateval, 2) = d.date 
                                                                     and lower(date_format(d.date,'EEEE')) not in ("saturday","sunday")
                                                                     and w_sat.dateval is null
                                                                     and w_sun.dateval is null
                                                                  ) or 
                                                                
                                                                /***********date absence is thursday and day off is friday***********/
                                                                  (lower(date_format(date_add(a.dateval, 1),'EEEE')) not in ("saturday","sunday") 
                                                                     and lower(date_format(date_add(a.dateval, 1),'EEEE')) in ("friday") 
                                                                     and date_add(a.dateval, 1) = d.previous_date 
                                                                     and date_add(a.dateval, 2) = d.date
                                                                     and lower(date_format(d.date,'EEEE')) in ("saturday")
                                                                     and w_sun.dateval is null
                                                                     
                                                                  ) or
                                                                
                                                                /***********next day is sunday and the next open day is day off***********/
                                                                  (lower(date_format(date_add(a.dateval, 1),'EEEE')) not in ("saturday","sunday")  
                                                                     and lower(date_format(date_add(a.dateval, 1),'EEEE')) in ("friday") 
                                                                     and date_add(a.dateval, 1) = d.previous_date_bis
                                                                     and date_add(a.dateval, 2) = d.previous_date
                                                                     and date_add(a.dateval, 3) = d.date
                                                                     and lower(date_format(d.date,'EEEE')) in ("sunday")
                                                                     and w_day.dateval is null
                                                                    
                                                                   )
                                                                 )
                             where   1 = 1
                               and   a.matricule is not null
                               and   lower(r.type_absence) = 'ouvré'
                               and   a.nbrvac > 0
                               and   (a.date_raw_load_file > at.date_raw_load_file or at.date_raw_load_file is null)
                           """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results_days_off = spark.sql(query_source_days_off).cache


// COMMAND ----------

// DBTITLE 1,Union of two queries
val df_results = df_results_days_abs.union(df_results_days_off).distinct
df_results.cache()  //put the dataframe ont he cache
df_results.createOrReplaceTempView("vw_df_results")
//val inserted_records = df_results.count().toInt //count the number of records to upsert


// COMMAND ----------

// DBTITLE 1,Delete Data where partitions are present in the df_results dataframe
spark.sql("""
delete from hr.absenteism as t1
  where exists (select vw_df_results.period_abs_month from vw_df_results where t1.period_abs_month = vw_df_results.period_abs_month)
""")

// COMMAND ----------

// DBTITLE 1,Overwrite on table absenteism
df_results.write.format("delta")
                .mode("append")
                .partitionBy("period_abs_month")
                .saveAsTable("hr.absenteism")


// COMMAND ----------

// DBTITLE 1,Optimize for reading delta table
spark.sql("OPTIMIZE hr.absenteism")


// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_absenteism_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val inserted_records = df_absenteism_read.count().toInt //count the number of records to upsert
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_absenteism_read.unpersist
df_results.unpersist
df_results_days_off.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.absenteism 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)