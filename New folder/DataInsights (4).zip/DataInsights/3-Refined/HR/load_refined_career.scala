// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include notebook containing common functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")
//sc.getExecutorStorageStatus.length - 1

// COMMAND ----------

// DBTITLE 1,Refresh table get_workers
if(spark.catalog.tableExists("employee.get_workers")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE employee.get_workers")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source and count number of read records
val byemployee_career = Window.partitionBy("employee_id","france_payroll_id", "review_reference", "goal_id","goal_due_date").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc, $"goal_completion_date".desc)
val df_career_read =  spark.table("employee.get_workers").filter("date_raw_load_file = '" + load_date + "'")
                                                          .withColumn("rank",rank() over byemployee_career)
                                                          .filter(col("rank")==="1")                                                          
                                                          .withColumn("employee_code",concat_ws("|",$"employee_id",$"france_payroll_id"))
                                                          .filter("france_payroll_id is not null or (france_payroll_id is null and company_id = '0082')") //read parquet file

df_career_read.createOrReplaceTempView("vw_career") // create a temp view
df_career_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Query to select only career data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select distinct                              
                             sha2(getconcatenedstring(array(c.employee_id,
                                                            c.france_payroll_id,
                                                            c.review_reference,
                                                            c.goal_id,
                                                            c.goal_due_date
                                                            )),256) as career_key
                            ,c.employee_id
                            ,c.france_payroll_id     
                            ,sha2(getconcatenedstring(array(c.employee_id, c.france_payroll_id)),256) as employee_code                            
                            
                            ,c.review_type_reference
                            ,c.review_reference
                            ,c.review_initiated_date
                            ,c.review_end_date
                            ,c.review_period_start_date
                            ,c.review_period_end_date
                            ,c.review_status
                            ,c.goal_id
                            ,c.goal_due_date
                            ,c.goal_completion_date
                            ,c.relocation_long_term_area
                            ,c.relocation_long_term_willing
                            ,c.relocation_short_term_area
                            ,c.relocation_short_term_willing   
                            ,c.my_review_end_date
                            ,c.my_review_status
                            ,sha2(c.review_reference ,256) as review_code
                            ,sha2(c.review_status ,256) as review_status_code
                            ,sha2(c.my_review_status ,256) as my_review_status_code
                            ,sha2(getconcatenedstring(array(c.goal_id
                                                             ,c.goal_due_date
                                                             ,c.goal_completion_date
                                                             )),256) as career_goal_code
                                                             
                            ,sha2(getconcatenedstring(array( c.relocation_short_term_area
                                                            ,c.relocation_long_term_area
                                                            ,c.relocation_short_term_willing
                                                            ,c.relocation_long_term_willing
                                                            ,c.date_raw_load_file)),256) as career_mobility_code
                                                            
                            ,sha2(getconcatenedstring(array(c.review_period_start_date
                                                           ,c.review_period_end_date)),256) as career_campaign_code                               
                            ,c.version
                            ,c.date_raw_load_file
                            ,c.filepath
                            ,c.filename
                            ,c.curated_ingested_date
                            ,true as current_record
                            ,c.date_raw_load_file as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,sha2(getconcatenedstring(array(        
                                                       c.review_type_reference
                                                      ,c.review_initiated_date
                                                      ,c.review_end_date
                                                      ,c.review_period_start_date
                                                      ,c.review_period_end_date
                                                      ,c.review_status
                                                      ,c.goal_completion_date
                                                      ,c.relocation_long_term_area
                                                      ,c.relocation_long_term_willing
                                                      ,c.relocation_short_term_area
                                                      ,c.relocation_short_term_willing
                                                      ,c.my_review_end_date
                                                      ,c.my_review_status
                                                           )),256) as hashkey 
                           ,'""" + runid + """' as runid
                           ,lower(trim(split(c.filepath,"/")[3])) as system_source
               from    vw_career c
               
               where   1 = 1
                 and   (c.employee_id is not null or c.france_payroll_id is not null)
                 and   (c.goal_id is not null or c.review_reference is not null)
              
               """
              

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source).cache

// COMMAND ----------

// DBTITLE 1,Query to create the target table contracts
  try {
    spark.sql("FSCK REPAIR TABLE hr.career")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }

// COMMAND ----------

// DBTITLE 1,Create the table contracts after drop the table if exists and store data and table structure on contracts_table
val career_table = DeltaTable.forName("hr.career")

// COMMAND ----------

// DBTITLE 1,Rows for contracts updated of existing employees
  val newcareer = df_results.as("career_updated")
  .join(career_table.toDF.as("career"),($"career.career_key"===$"career_updated.career_key"))
  .where("""career.current_record = true and (career_updated.hashkey <> career.hashkey) and career_updated.date_raw_load_file >= career.date_raw_load_file"""
)

// COMMAND ----------

// DBTITLE 1,Union of dataframes between career updated from existing employees and new career from new employees
// Stage the update by unioning two sets of rows
// 1. Rows that will be inserted in the `whenNotMatched` clause
// 2. Rows that will either UPDATE the current contracts of existing employees or insert the new contracts of new employees
val career_upsert = newcareer
  .selectExpr("null as mergekey", "career_updated.*")   // Rows for 1.
  .union(
    df_results.as("df_results").selectExpr("df_results.career_key as mergekey_1",                                          
                                           "*")  // Rows for 2.
  )
//remove duplicate
val career_upsert_distinct = career_upsert.distinct()

// COMMAND ----------

// DBTITLE 1,Merge on table Career
career_table.alias("t")
  .merge(
    career_upsert_distinct.alias("s"),
    """ t.career_key = s.mergekey 
    """)
  .whenMatched("""t.current_record = true and (t.hashkey <> s.hashkey) and s.date_raw_load_file >= t.date_raw_load_file """)
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "case when date_add(s.record_start_date,-1)<t.record_start_date then t.record_start_date else date_add(s.record_start_date,-1) end ",
    "record_modification_date" -> "s.record_modification_date",
    "runid" -> "s.runid")
  )
  /*.whenMatched("""t.contract_end_date is null and s.date_raw_load_file > t.date_raw_load_file and s.contract_end_date is not null""")
    .updateExpr(Map(
     "contract_end_date" -> "s.contract_end_date"))*/
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Update employee_id where is null for old records and employee_id and france_payroll_id is not null for current record
spark.sql("""
merge into hr.career c1
using hr.career c2
on c1.france_payroll_id = c2.france_payroll_id
and c1.employee_id is null 
and c2.employee_id is not null
and c2.current_record = true
when matched then
  update set c1.employee_id = c2.employee_id,
             c1.current_record = false,
             c1.record_end_date = case when c1.record_end_date is null then date_add(c2.record_start_date,-1) end,
             c1.employee_code = c2.employee_code,
             c1.career_key = c2.career_key
""")

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE hr.career")

// COMMAND ----------

val read_records = df_career_read.count().toInt //count the number of read records
val inserted_records = career_upsert_distinct.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_career_read.unpersist

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.career 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)