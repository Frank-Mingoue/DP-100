// Databricks notebook source
// DBTITLE 1,Get Parameters
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val system_source = dbutils.widgets.get("system_source")

// COMMAND ----------

val dvalue = "2022-03-31"
val system_source = if (load_date <= dvalue) {"hra"} else {"adp"}

// COMMAND ----------

// DBTITLE 1,Import Functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// MAGIC %md ##1 - Read Data

// COMMAND ----------

// MAGIC %md ##### HRA Suspension

// COMMAND ----------

// DBTITLE 1,Get Last Partition File
val path_suspension = "/employee/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + "_suspension"
val partition_suspension = get_last_partition_file(path_suspension,load_date,"curated")
val table_suspension = "employee." + system_source.toLowerCase() + "_suspension"

// COMMAND ----------

// DBTITLE 1,Refresh Table Suspension
if(spark.catalog.tableExists(table_suspension)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_suspension)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Suspension Data
val bysuspens = Window.partitionBy("matricule_wd","matricule_hr_access","date_deb_situation").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc, $"date_fin_situation".desc)
val df_suspensionhra_read = spark.table(table_suspension).filter($"date_raw_load_file"===partition_suspension and ($"categorie"==="SUSPEN" or ($"categorie".isNull and lower($"filename").contains("adp")) ))
                                                         .withColumn("rank",rank() over bysuspens)
                                                         .filter(col("rank")==="1")

// COMMAND ----------

// DBTITLE 1,Build previous and next suspension dates
val window = Window.partitionBy("matricule_wd").orderBy($"date_deb_situation".asc)
//lag and lead
val defaultEndDate = LocalDate.parse("2999-12-31", DateTimeFormatter.ofPattern("yyyy-MM-dd"))  

val df_suspensionhra_read_ordered = df_suspensionhra_read.withColumn("start_date_situation_before_1", lag($"date_deb_situation", 1, null).over(window))
                                                         .withColumn("start_date_situation_after_1", lead($"date_deb_situation", 1, null).over(window))
                                                         .withColumn("end_date_situation_before_1", lag($"date_fin_situation", 1, null).over(window))

// COMMAND ----------

// MAGIC %md ##2- Transform Data

// COMMAND ----------

// DBTITLE 1,Ordering suspension dates by ascending for each employee
val df_suspensionhra_read_ordered_filter = df_suspensionhra_read_ordered.withColumn("flag",
                                                                                   when($"start_date_situation_before_1".isNull and
                                                                                       $"end_date_situation_before_1".isNull,
                                                                                       "start")
                                                                                   .when(date_add($"date_deb_situation",-1) === $"end_date_situation_before_1" and
                                                                                        date_add($"date_fin_situation",1) === $"start_date_situation_after_1",
                                                                                        "nothing")
                                                                                    .when(date_add($"date_deb_situation",-1) ===$"end_date_situation_before_1" and
                                                                                         (date_add($"date_fin_situation",1) =!= $"start_date_situation_after_1" or
                                                                                          $"start_date_situation_after_1".isNull),
                                                                                         "end")
                                                                                    .when(date_add($"date_deb_situation",-1) =!=$"end_date_situation_before_1",                                                                                                                  "start")
                                                                                   .otherwise("start"))

// COMMAND ----------

// DBTITLE 1,Calculate the beginning and the end of each suspension for employees
val window = Window.partitionBy("matricule_wd").orderBy($"date_deb_situation".asc)
val df_suspension_filter = df_suspensionhra_read_ordered_filter.where($"flag"=!="nothing").withColumn("flag_1", lead($"flag", 1, null).over(window))

df_suspension_filter.withColumn("end_date_situation_2",when ($"flag_1"==="end",lead($"date_fin_situation",1,null).over(window)).
                                                             otherwise($"date_fin_situation"))
                                   .where($"flag"==="start")
                                  .drop("date_fin_situation")
                                  .withColumnRenamed("end_date_situation_2","date_fin_situation")
                                  .withColumn("contract_suspension_key",sha2(concat_ws("|",$"matricule_wd",$"matricule_hr_access",$"date_deb_situation"),256))
                                  .select("contract_suspension_key","matricule_wd","matricule_hr_access","date_deb_situation","date_fin_situation",
                                                                            "categorie","libelle_categorie","motif"
                                                                           ,"libelle_motif","flag_conges","filepath","version","date_raw_load_file",
                                                                            "filename","curated_ingested_date","runid","year_file","month_file","day_file")
                                  .distinct
                                  .createOrReplaceTempView("vw_suspension_results")

// COMMAND ----------

// DBTITLE 1,Query suspension data
val query_source = """ select distinct 
                              getconcatenedstring(array(c.matricule_wd,
                                                        c.matricule_hr_access)) as contract_suspension_key
                              ,c.matricule_wd as employee_id
                              ,c.matricule_hr_access as france_payroll_id
                              ,sha2(getconcatenedstring(array(c.matricule_wd, c.matricule_hr_access)),256) as employee_code
                              ,c.contract_suspension_key as contract_suspension_key_sha
                              ,c.date_deb_situation as contract_suspension_start_date
                              ,c.date_fin_situation as contract_suspension_end_date
                              ,sha2(getconcatenedstring(array( c.date_deb_situation
                                                            ,c.date_fin_situation
                                                             )),256) as contract_suspension_dates_code
                              ,c.categorie as category
                              ,c.libelle_categorie as label_category
                              ,c.motif as reason
                              ,c.libelle_motif as label_reason
                              ,sha2(c.motif,256) as suspension_contrat_code 
                              ,c.flag_conges
                              ,1 as version
                              ,to_date('2020-01-01') as date_raw_load_file
                              ,c.filepath
                              ,c.filename
                              ,current_date() as curated_ingested_date
                              ,current_timestamp() as record_creation_date
                              ,current_timestamp() as record_modification_date                               
                              ,getconcatenedstring(array(    
                                                           c.date_deb_situation
                                                          ,c.categorie
                                                          ,c.libelle_categorie
                                                          ,c.motif
                                                          ,c.libelle_motif
                                                          ,c.flag_conges                                                         
                                                             )) as hashkey 
                             ,'""" + runid + """' as runid
                             ,lower(trim(split(c.filepath,"/")[3])) as system_source
                 from    vw_suspension_results c

                 where   1 = 1
                   and   (c.matricule_wd is not null or c.matricule_hr_access is not null)
  """

// COMMAND ----------

// DBTITLE 1,Get Query results
val df_results = spark.sql(query_source).cache()

// COMMAND ----------

// MAGIC %md ## 3- Save Data

// COMMAND ----------

// DBTITLE 1,Refresh table contract suspension
try {
  spark.sql("FSCK REPAIR TABLE hr.contract_suspension")
}
catch {
  case e: FileNotFoundException => println("Couldn't find that file.")
  case e: IOException => println("Had an IOException trying to read that file")
}

// COMMAND ----------

// DBTITLE 1,Get Data from table Contract Suspension
val contract_table_suspension = DeltaTable.forName("hr.contract_suspension")


// COMMAND ----------

// DBTITLE 1,Merge data to table Contract Suspension
//flux = quotidien
contract_table_suspension
  .as("c")
  .merge(
    df_results.as("updated"),
    "c.contract_suspension_key_sha = updated.contract_suspension_key_sha")
    .whenMatched
    .updateExpr(
     Map("c.contract_suspension_end_date" -> "updated.contract_suspension_end_date",
         "c.contract_suspension_dates_code" -> "updated.contract_suspension_dates_code",
         "c.suspension_contrat_code" -> "updated.suspension_contrat_code",
         "c.category" -> "updated.category",
         "c.label_category" -> "updated.label_category",
         "c.reason" -> "updated.reason",
         "c.label_reason" -> "updated.label_reason",
         "c.flag_conges" -> "updated.flag_conges"))
  .whenNotMatched
  .insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Optimize Table
spark.sql("OPTIMIZE hr.contract_suspension")

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_suspensionhra_read.count().toInt //count the number of read records
val inserted_records = df_results.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0
df_results.unpersist()
df_suspensionhra_read.unpersist()

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.contract_suspension 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Return Statistics values
dbutils.notebook.exit(return_value)