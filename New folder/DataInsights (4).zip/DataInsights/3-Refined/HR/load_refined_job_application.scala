// Databricks notebook source
// DBTITLE 1,Get Parameters: load_date, runid
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include notebooks
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Optimize Spark Query
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Refresh table recruitment.get_candidates
if(spark.catalog.tableExists("recruitment.get_candidates")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_candidates")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the windowing function in order to get the last and first degree and the last application information sent by grouping by employee_id and sort by filename desc. then create the temp view
val bydegree = Window.partitionBy("candidate_id", "job_application_date","job_requisition_reference").orderBy($"first_year_attended".asc, $"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val byapplication = Window.partitionBy("candidate_id", "source_reference", "job_requisition_reference", "job_application_date","stage_reference").orderBy($"status_timestamp".desc, $"first_year_attended".desc, $"filename".desc, $"date_raw_load_file".desc, $"version".desc)

val df_candidates_read = spark.table("recruitment.get_candidates").where($"date_raw_load_file"===load_date)
                                                                  .withColumn("first_degree_reference",first($"degree_reference").over(bydegree))
                                                                  .withColumn("last_degree_reference",last($"degree_reference").over(bydegree))
                                                                  .withColumn("job_application_month",date_format($"job_application_date","yyyyMM"))
                                                                  .withColumn("rank", rank().over(byapplication))
                                                                  .where($"rank"===1)
                                                                  .distinct

df_candidates_read.createOrReplaceTempView("vw_candidates_read")

// COMMAND ----------

// DBTITLE 1,Query to select only application data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select distinct
                            getconcatenedstring(array(a.candidate_id,
                                                      a.source_reference,
                                                      a.job_requisition_reference,
                                                      a.job_application_date,
                                                      a.stage_reference)) as application_key
                            ,a.candidate_id
                            ,a.candidate_first_name
                            ,a.candidate_last_name
                            ,a.job_requisition_reference
                            ,a.job_application_date
                            ,a.job_application_month
                            ,a.first_degree_reference
                            ,a.last_degree_reference
                            ,a.worker_reference
                            ,a.source_reference
                            ,a.stage_reference
                            ,a.status_timestamp
                            ,a.disposition_reference
                            ,a.disposition_reference_id
                            ,null as candidate_response_date
                            ,null as duration_trial_period
                            ,null as validation_trial_period
                            ,sha2(getconcatenedstring(array(a.source_reference)),256) as source_reference_code
                            ,sha2(getconcatenedstring(array(a.candidate_id,
                                                            a.job_requisition_reference,
                                                            a.job_application_date)),256) as job_application_code
                            ,a.filename
                            ,a.date_raw_load_file
                            ,a.version
                            ,a.filepath
                            ,a.curated_ingested_date
                            ,true as current_record
                            ,a.date_raw_load_file as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(a.first_degree_reference,
                                                       a.last_degree_reference,
                                                       a.candidate_first_name,
                                                       a.candidate_last_name,
                                                       a.worker_reference,
                                                       a.status_timestamp,
                                                       a.disposition_reference,
                                                       a.disposition_reference_id
                                                      )) as hashkey
                            ,'""" + runid + """' as runid
                            ,lower(trim(split(a.filepath,"/")[3])) as system_source

                            from vw_candidates_read a
                            where 1=1
                              and a.candidate_id is not null
                              and a.job_requisition_reference is not null
                              and a.job_application_date is not null
                            """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source).cache()

// COMMAND ----------

// DBTITLE 1,Refresh table job_application
try {
  spark.sql("FSCK REPAIR TABLE hr.job_application")
}
catch {
  case e: FileNotFoundException => println("Couldn't find that file.")
  case e: IOException => println("Had an IOException trying to read that file")
}

// COMMAND ----------

// DBTITLE 1,Read the table hr job application
val application_table = DeltaTable.forName("hr.job_application")

// COMMAND ----------

// DBTITLE 1,Rows for information updated of existing job application
val new_application_table = df_results.as("a_updated")
                                      .join(application_table.toDF.as("a"), $"a.application_key"===$"a_updated.application_key")
                                      .where("""a.current_record = true and (a.hashkey <> a_updated.hashkey) 
                                      and a_updated.date_raw_load_file >= a.date_raw_load_file""")


// COMMAND ----------

// DBTITLE 1,Union of dataframes between job applications updated from existing information and new information from new applications
val application_upsert = new_application_table.selectExpr("null as mergekey_1", "a_updated.*")
                                              .union(df_results.as("df_results").selectExpr("df_results.application_key as mergekey_1", "*"))
val application_upsert_distinct = application_upsert.distinct()

// COMMAND ----------

// DBTITLE 1,Merge on table job_application
application_table.alias("a")
  .merge(
    application_upsert_distinct.alias("a_updated"),
    """a.application_key = a_updated.mergekey_1""")
  .whenMatched("""a.current_record = true and (a.hashkey <> a_updated.hashkey) and a_updated.date_raw_load_file >= a.date_raw_load_file """)
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "case when date_add(a_updated.record_start_date,-1)<a.record_start_date then a.record_start_date else date_add(a_updated.record_start_date,-1) end ",
    "record_modification_date" -> "a_updated.record_modification_date",
    "runid" -> "a_updated.runid")
  )
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Script to optimize hr job_application
spark.sql("OPTIMIZE hr.job_application")

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_candidates_read.count().toInt //count the number of read records
val inserted_records = df_results.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0
df_results.unpersist()

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.job_application 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return Statistics Values
dbutils.notebook.exit(return_value)