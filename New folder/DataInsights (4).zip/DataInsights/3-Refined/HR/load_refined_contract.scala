// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val system_source = dbutils.widgets.get("system_source")

// COMMAND ----------

val dvalue = "2022-03-31"
val system_source = if (load_date <= dvalue) {"hra"} else {"adp"}

// COMMAND ----------

// DBTITLE 1,Include notebook containing common functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30")
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")
//sc.getExecutorStorageStatus.length - 1

// COMMAND ----------

// DBTITLE 1,Refresh table get_workers
if(spark.catalog.tableExists("employee.get_workers")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE employee.get_workers")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val date_value = LocalDate.parse(load_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
val year_id = date_value.getYear()
val date_from = LocalDate.parse(year_id + "-01-01", DateTimeFormatter.ofPattern("yyyy-MM-dd"))

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source and count number of read records
//TODO: ajouter les champs ci-dessous quand ils seront dispo;
  
	/*-Compensation Package
	  -Grade Profile
	  -Salary Plan Name
	  -Unit Salary
	  -Allowance
	  -Merit Percentage 
	  -Merit Amount
	 */


val df_contract_read_1 = spark.table("hr.contract").select(
                                                    col("employee_id").as("employee_id_refined")
                                                   ,col("france_payroll_id").as("france_payroll_id_refined")
                                                   ,col("coefficient").as("coefficient_refined")
                                                   ,col("coefficient_label").as("coefficient_label_refined")
                                                   ,col("collective_agreement_group").as("collective_agreement_group_refined")
                                                   ,col("collective_agreement_level").as("collective_agreement_level_refined")
                                                   ,col("collective_agreement_reference").as("collective_agreement_reference_refined")
                                                   ,col("collective_agreement_reference_label").as("collective_agreement_reference_label_refined")
                                                   ,col("total_base_pay").as("total_base_pay_refined")
                                                   ,col("primary_comp_basis_amount").as("primary_comp_basis_amount_refined")
                                                   ,col("grade").as("grade_refined")
                                                   ,col("period_salary_amount").as("period_salary_amount_refined")
                                                   ,col("bonus_plan_name").as("bonus_plan_name_refined")
                                                   ,col("compensation_merit_plan").as("compensation_merit_plan_refined")
                                                   ,col("compensation_merit_plan_label").as("compensation_merit_plan_label_refined")
                                                   ,col("foreign_travel_indemnity_amount").as("foreign_travel_indemnity_amount_refined")
                                                   ,col("foreign_travel_indemnity_percent").as("foreign_travel_indemnity_percent_refined")
                                                   ,col("bonus_target").as("bonus_target_refined")
                                                   ,col("prime_co_percent").as("prime_co_percent_refined")
                                                   ,col("prime_exp_percent").as("prime_exp_percent_refined"))
                                                   .filter($"current_record"==="true")

//val defaultStartDate = LocalDate.parse("1999-12-31", DateTimeFormatter.ofPattern("yyyy-MM-dd"))     
val bycontract = Window.partitionBy("employee_id","france_payroll_id","effective_compensation_change_date").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc,$"effective_compensation_change_date".desc)
val bycontract2 = Window.partitionBy("employee_id","france_payroll_id").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_contract_read =  spark.table("employee.get_workers").filter("date_raw_load_file between '" + date_from + "' and  '" + load_date + "'")/*.filter("date_raw_load_file = '" + load_date + "'")*/
                                                          .filter("effective_compensation_change_date >= '" + date_from + "'")
                                                          .withColumn("rank",rank() over bycontract)
                                                          .withColumn("rank2",rank() over bycontract2)
                                                          .filter(col("rank")==="1")     
                                                          /*fix wrong matricule workday and hra*/
                                                          .withColumn("company_id", when($"company_id" === "82", "0082").otherwise($"company_id"))
                                                          .withColumn("employee_id",when($"employee_id" === "W200094100",lit("W20094100")).otherwise($"employee_id"))
                                                          .withColumn("france_payroll_id",when($"france_payroll_id" === "019370019370",lit("019370"))
                                                                                         .when($"france_payroll_id".isNull and $"employee_id" === "W20097563", lit("060144"))
                                                                                         .when($"france_payroll_id".isNotNull and $"company_id" === "0082", null)
                                                                                         .otherwise($"france_payroll_id"))

                                                          .withColumn("employee_code",concat_ws("|",$"employee_id",$"france_payroll_id"))
                                                          .dropDuplicates("employee_code","effective_compensation_change_date")
                                                          .filter("france_payroll_id is not null or (france_payroll_id is null and company_id = '0082') ") //read parquet file
                                                          /*.withColumn("effective_job_change_date_old",$"effective_job_change_date")
                                                          .withColumn("effective_job_change_date", when($"effective_job_change_date">$"effective_organization_change_date" and $"effective_job_change_date".isNotNull ,$"effective_job_change_date").otherwise($"effective_organization_change_date"))*/
                                                          .withColumn("bonus_target_old", $"bonus_target")
                                                          .withColumn("bonus_target", when(($"bonus_target".isNull or $"bonus_target" === 0) and $"bonus_target_default".isNotNull and $"bonus_target_default">0,$"bonus_target_default").otherwise($"bonus_target"))
                                                          .withColumn("continous_service_date", when($"continous_service_date".isNull or $"continous_service_date" > $"contract_start_date" or $"continous_service_date" === to_date(lit("0001-01-01")),$"contract_start_date" ).otherwise($"continous_service_date"))
                                                          .withColumn("contract_type_label", when($"contract_type_label" like "%��%(CDD)" and $"contract_type" === "FRA08", "Contrat à durée déterminée (CDD)")
                                                                                            .when($"contract_type_label" like "%��%(CDI)" and $"contract_type" === "FRA15", "Contrat à durée indéterminée (CDI)")
                                                                                            .otherwise($"contract_type_label"))                                                         
                                                         .distinct
                                                         // .withColumn("contract_start_date", when($"contract_start_date".isNull, defaultStartDate).otherwise($"contract_start_date"))
                                                         .as("df")
                                                         .join(df_contract_read_1.as("df1"),($"df.employee_id" === $"df1.employee_id_refined" and $"df.france_payroll_id" === $"df1.france_payroll_id_refined") or ($"df.employee_id" === $"df1.employee_id_refined" and $"df.france_payroll_id".isNull),"leftouter")
 .withColumn("coefficient",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date ,$"df.coefficient").otherwise($"df1.coefficient_refined"))
 .withColumn("coefficient_label",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.coefficient_label").otherwise($"df1.coefficient_label_refined"))
 .withColumn("collective_agreement_group",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.collective_agreement_group").otherwise($"df1.collective_agreement_group_refined"))
 .withColumn("collective_agreement_level",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.collective_agreement_level").otherwise($"df1.collective_agreement_level_refined"))
 .withColumn("collective_agreement_reference",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.collective_agreement_reference").otherwise($"df1.collective_agreement_reference_refined"))
 .withColumn("collective_agreement_reference_label",when($"employee_visibility_date".isNull or $"employee_visibility_date" <=                    load_date,$"df.collective_agreement_reference_label").otherwise($"df1.collective_agreement_reference_label_refined"))
 .withColumn("total_base_pay",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.total_base_pay").otherwise($"df1.total_base_pay_refined"))
 .withColumn("primary_comp_basis_amount",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.primary_comp_basis_amount").otherwise($"df1.primary_comp_basis_amount_refined"))
 .withColumn("grade",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.grade").otherwise($"df1.grade_refined"))
 .withColumn("period_salary_amount",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.period_salary_amount").otherwise($"df1.period_salary_amount_refined"))
 .withColumn("bonus_plan_name",when( $"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.bonus_plan_name").otherwise($"df1.bonus_plan_name_refined"))
 .withColumn("compensation_merit_plan",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.compensation_merit_plan").otherwise($"df1.compensation_merit_plan_refined"))
 .withColumn("compensation_merit_plan_label",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.compensation_merit_plan_label").otherwise($"df1.compensation_merit_plan_label_refined"))
 .withColumn("bonus_target",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.bonus_target").otherwise($"df1.bonus_target_refined"))
 .withColumn("foreign_travel_indemnity_amount",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.foreign_travel_indemnity_amount").otherwise($"foreign_travel_indemnity_amount_refined"))
 .withColumn("foreign_travel_indemnity_percent",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.foreign_travel_indemnity_percent").otherwise($"df1.foreign_travel_indemnity_percent_refined"))
 .withColumn("prime_co_percent",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.prime_co_percent").otherwise($"df1.prime_co_percent_refined"))
 .withColumn("prime_exp_percent",when($"employee_visibility_date".isNull or $"employee_visibility_date" <= load_date,$"df.prime_exp_percent").otherwise($"df1.prime_exp_percent_refined"))
 .drop($"employee_id_refined")
 .drop($"france_payroll_id_refined")
 .drop($"coefficient_refined")
 .drop($"coefficient_label_refined")
 .drop($"collective_agreement_group_refined")
 .drop($"collective_agreement_level_refined")
 .drop($"collective_agreement_reference_refined")
 .drop($"collective_agreement_reference_label_refined")
 .drop($"total_base_pay_refined")
 .drop($"primary_comp_basis_amount_refined")
 .drop($"grade_refined")
 .drop($"period_salary_amount_refined")
 .drop($"bonus_plan_name_refined")
 .drop($"compensation_merit_plan_refined")
 .drop($"compensation_merit_plan_label_refined")
 .drop($"bonus_target_refined")
 .drop($"foreign_travel_indemnity_amount_refined")
 .drop($"foreign_travel_indemnity_percent_refined")
 .drop($"prime_co_percent_refined")
 .drop($"prime_exp_percent_refined")


df_contract_read.createOrReplaceTempView("vw_contract") // create a temp view
df_contract_read.cache()  //put the dataframe on the cache

// COMMAND ----------

// DBTITLE 1,Read Current Valid contracts
//val defaultStartDate = LocalDate.parse("1999-12-31", DateTimeFormatter.ofPattern("yyyy-MM-dd"))     
val df_contract_read_all = DeltaTable.forName("hr.contract").toDF
                                                            .where($"current_record"===true)
                                                           // .withColumn("contract_start_date", when($"contract_start_date".isNull, defaultStartDate).otherwise($"contract_start_date"))
                                                            .select("contract_key","employee_id","france_payroll_id","contract_start_date","contract_end_date","contract_type","contract_type_label","hashkey")
df_contract_read_all.createOrReplaceTempView("vw_contract_all")

// COMMAND ----------

// DBTITLE 1,Read Last Salary from Histo File
val bycontract_salary = Window.partitionBy("employee_id","france_payroll_id").orderBy($"effective_compensation_change_date".desc, $"record_start_date".desc, $"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_contract_read_salary_all = DeltaTable.forName("hr.contract").toDF
                                                            .where($"filename"==="histo_file")
                                                            .filter(col("fte")<"100")  
                                                            .withColumn("rank",rank() over bycontract_salary)
                                                            .filter(col("rank")==="1")   
                                                            .select("contract_key","employee_id","france_payroll_id","employee_code","contract_start_date","contract_end_date","contract_type","contract_type_label","hashkey","effective_compensation_change_date","fte","total_base_pay")
                                                            .distinct
df_contract_read_salary_all.createOrReplaceTempView("vw_contract_salary_all")

// COMMAND ----------

// DBTITLE 1,Set table salaries
val table_salaries = "employee." + system_source.toLowerCase() + "_salaries"

// COMMAND ----------

// DBTITLE 1,Refresh table hra_ salaries
if(spark.catalog.tableExists(table_salaries)) // test if path exists
{
  try {
    spark.sql("MSCK REPAIR TABLE " + table_salaries)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Connect to transco table
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val df_transco = spark.read.jdbc(jdbcurl, "dbo.vw_ref_transco",connectionproperties).na.fill("Nothing")
df_transco.createOrReplaceTempView("vw_dbo_param_transco_ref")

// COMMAND ----------

// DBTITLE 1,Read specific population
val df_salariehra_read = spark.table("employee.adp_salaries").filter($"population_particuliere"===1).select("matricule_wd","matricule_hr_access").union(spark.table("employee.hra_salaries").filter($"population_particuliere"===1).select("matricule_wd","matricule_hr_access")).distinct
df_salariehra_read.createOrReplaceTempView("vw_salariehra") // create a temp view

// COMMAND ----------

// DBTITLE 1,Manage difference contract_start_date between hra and workday to take the value from hra
val df_contract_join = df_contract_read.as("c")
                          .join(df_contract_read_all.as("a"), ($"c.employee_id" === $"a.employee_id" and $"c.france_payroll_id" === $"a.france_payroll_id") or ($"c.employee_id" === $"a.employee_id" and $"c.france_payroll_id".isNull), "left_outer")
                          .join(df_salariehra_read.as("h"), $"c.employee_id" === $"h.matricule_wd" or $"c.france_payroll_id" === $"h.matricule_hr_access", "left_outer")
                          .join(df_contract_read_salary_all.as("s"), ($"c.employee_id" === $"s.employee_id" and $"c.france_payroll_id" === $"s.france_payroll_id") or ($"c.employee_id" === $"s.employee_id" and $"c.france_payroll_id".isNull), "left_outer")
                          .join(df_transco.as("t"), lower($"t.source_value") === lower(concat($"c.contract_type_label", lit("-"), $"c.contract_reason")) and $"t.axe" === lit("NATURE_DE_CONTRAT"), "left_outer")

                      .filter($"h.matricule_wd".isNull and $"h.matricule_hr_access".isNull)
                      .withColumn("contract_start_date_old",$"c.contract_start_date")
                      .withColumn("contract_start_date_new",when($"a.contract_start_date".isNotNull and $"c.contract_end_date".isNull 
                                                                                                    and $"a.contract_end_date".isNull
                                                                                                    and ($"c.contract_start_date" <= to_date(lit("2021-01-01")) or $"a.contract_start_date".isNull)
                                                                                                    and (($"c.contract_type_label" === $"a.contract_type_label") or 
                                                                                                        (($"a.contract_type" === "DE" or $"a.contract_type" === "DI") and ($"c.contract_type" === "FRA15" or $"c.contract_type"==="JP01"))), $"a.contract_start_date")
                                                           .when($"a.contract_start_date".isNotNull and $"c.contract_end_date".isNotNull
                                                                                                    and $"a.contract_end_date".isNotNull 
                                                                                                    and $"c.contract_end_date" === $"a.contract_end_date" 
                                                                                                    and $"c.contract_type_label" === $"a.contract_type_label",$"a.contract_start_date")
                                                           .otherwise($"c.contract_start_date"))

                      .withColumn("total_base_pay_old",$"c.total_base_pay")
                      .withColumn("total_base_pay_new",when($"c.contract_start_date" === $"s.contract_start_date" and $"c.fte" === $"s.fte"
                                                                                                                  and $"c.fte" < 100
                                                                                                                  and ($"s.total_base_pay" - $"c.total_base_pay")>1,$"s.total_base_pay")
                                                      .otherwise($"c.total_base_pay"))

                      .select("c.*","contract_start_date_old","contract_start_date_new","total_base_pay_new","di_value")
                      .distinct
                      .withColumn("contract_start_date",$"contract_start_date_new")
                      .withColumn("total_base_pay",$"total_base_pay_new")
                      .withColumn("effective_job_change_date_old",$"effective_job_change_date")
                      .withColumn("effective_job_change_date", when($"effective_job_change_date".isNull, $"contract_start_date").otherwise($"effective_job_change_date"))
                      .withColumn("effective_compensation_change_date_old",$"effective_compensation_change_date")
                      .withColumn("effective_compensation_change_date", when($"effective_compensation_change_date".isNull, $"contract_start_date").otherwise($"effective_compensation_change_date"))
                      .withColumn("contract_type_old", $"contract_type")
                      .withColumn("contract_type", when(lower($"contract_type_label").contains("cdd") && lower($"di_value").contains("surcroît"),concat($"contract_type",lit("-SURCROIT")))
                                                  .when(lower($"contract_type_label").contains("cdd") && lower($"di_value").contains("cdd remplacement"),concat($"contract_type",lit("-REMPLACEMENT")))
                                                        .otherwise($"contract_type"))
                      .withColumn("contract_type_label_old", $"contract_type_label")
                      .withColumn("contract_type_label", when(lower($"contract_type_label").contains("cdd") && (lower($"di_value").contains("surcroît") || lower($"di_value").contains("cdd remplacement")),concat($"contract_type_label",lit("-"),$"contract_reason"))
                                                        .otherwise($"contract_type_label"))

df_contract_join.createOrReplaceTempView("vw_contract_join")

// COMMAND ----------

// DBTITLE 1,Query to select only contracts data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select distinct                              
                             getconcatenedstring(array(c.employee_id,
                                                      c.france_payroll_id
                                                            )) as contract_key
                            ,c.employee_id
                            ,c.france_payroll_id     
                            ,sha2(getconcatenedstring(array(c.employee_id, c.france_payroll_id)),256) as employee_code
                            ,c.worker_type
                            ,c.position_start_date
                            ,c.hire_date
                            ,c.continous_service_date
                            ,c.original_hire_date
                            ,c.effective_hire_date
                            ,c.effective_job_change_date
                            ,c.first_contract_type
                            ,c.first_contract_type_label
                            ,c.collective_agreement_reference
                            ,c.collective_agreement_reference_label
                            ,c.collective_agreement_group
                            ,c.collective_agreement_level
                            ,c.contract_start_date
                            ,c.contract_end_date
                            ,c.contract_type
                            ,c.contract_type_label
                            ,c.coefficient
                            ,c.coefficient_label
                            ,c.event_classification_subcategory
                            ,c.event_classification_subcategory_label
                            ,c.local_termination_reason
                            ,c.fte
                            ,c.time_type
                            ,c.time_type_label
                            ,c.paidfte
                            ,c.total_base_pay
                            ,c.primary_comp_basis_amount
                            ,c.period_salary
                            ,c.period_salary_label
                            ,c.period_salary_amount
                            ,c.compensation_merit_plan
                            ,c.compensation_merit_plan_label
                            ,c.compensation_change_reason
                            ,c.compensation_change_subreason
                            ,c.compensation_bonus_plan
                            ,c.bonus_target
                            ,c.bonus_plan_name
                            ,c.additional_job_classifications
                            ,c.additional_job_classifications_label
                            ,c.compensation_currency
                            ,c.default_weekly_hours
                            ,c.scheduled_weekly_hours
                            ,c.effective_compensation_change_date
                            ,c.foreign_travel_indemnity_percent
                            ,c.foreign_travel_indemnity_amount
                            ,c.effective_suporg_change_date
                            ,case when c.professional_category_reference IS NULL then "nothing" else c.professional_category_reference end as csp
                            ,upper(c.job_title) as job_title
                            ,c.grade 
                            ,c.management_level
                            ,c.job_profile_reference                            
                                                        
                            ,sha2(getconcatenedstring(array(
                                                             lower(c.job_title)
                                                            ,c.grade 
                                                            ,c.management_level
                                                            ,c.job_profile_reference)),256) as job_code
                            ,sha2(c.professional_category_reference,256) as csp_code
                            ,sha2(getconcatenedstring(array(c.contract_type               
                                                            ,c.worker_type
                                                            ,c.collective_agreement_reference
                                                            ,c.collective_agreement_group
                                                            ,c.collective_agreement_level
                                                            ,c.coefficient_label
                                                            )),256) as contract_code 
                                                             
                             ,sha2(getconcatenedstring(array(
                                                             c.time_type
                                                            ,c.fte
                                                            ,c.paidfte
                                                             )),256) as worker_rate_code 
                                                             
                            ,case when c.contract_reason is null then sha2(c.event_classification_subcategory,256) else sha2(getconcatenedstring(array(c.event_classification_subcategory,c.contract_reason)),256) end as mobility_in_code 
                                                             
                            ,sha2(c.local_termination_reason,256) as mobility_out_code 
                                                             
                            
                            ,sha2(getconcatenedstring(array(c.compensation_change_reason,c.compensation_change_subreason)),256) as compensation_change_code
                            
                            ,sha2(c.compensation_merit_plan,256) as compensation_merit_plan_code 
                            
                            ,sha2(c.compensation_bonus_plan,256) as compensation_bonus_plan_code 
                            
                            ,sha2(getconcatenedstring(array( c.position_start_date
                                                            ,c.continous_service_date
                                                            ,c.contract_start_date
                                                            ,c.contract_end_date
                                                            ,c.contract_type
                                                             )),256) as info_dates_code
                                                             
                             ,sha2(getconcatenedstring(array(c.original_hire_date
                                                            ,c.contract_end_date)),256) as in_out_dates_code
                            
                            ,sha2(getconcatenedstring(array( c.contract_start_date
                                                            ,c.contract_end_date
                                                            ,c.contract_type
                                                             )),256) as contract_dates_code
                                                             
                            ,sha2(getconcatenedstring(array( c.position_start_date
                                                            ,c.continous_service_date
                                                             )),256) as company_dates_code
                                                             
                            ,sha2(c.contract_type ,256) as contract_type_code 
                            
                            ,sha2(getconcatenedstring(array(c.worker_type
                                                            ,c.collective_agreement_reference
                                                            ,c.collective_agreement_group
                                                            ,c.collective_agreement_level
                                                            ,c.coefficient_label
                                                            )),256) as collective_agreement_code 
                                                        
                            ,sha2(c.grade ,256) as grade_code
                                                        
                            ,sha2(getconcatenedstring(array(
                                                             lower(c.job_title)
                                                            ,c.management_level
                                                            ,c.job_profile_reference)),256) as job_title_code
                            ,0 as special_population     
                            ,c.probation_start_date
                            ,c.probation_end_date
                            ,c.contract_reason
                            ,c.employee_visibility_date
                            ,c.prime_co_percent
                            ,c.prime_exp_percent
                            ,sha2(getconcatenedstring(array( c.probation_start_date
                                                            ,c.probation_end_date
                                                             )),256) as probation_dates_code
                            ,sha2(c.contract_reason ,256) as contract_reason_code 
                            ,c.version
                            ,c.date_raw_load_file
                            ,c.filepath
                            ,c.filename
                            ,c.curated_ingested_date
                            ,case when rank2 = 1 then true else false end as current_record
                            ,c.date_raw_load_file as record_start_date
                            ,case when rank2 = 1 then null else date_add(LEAD(c.date_raw_load_file, 1) over (partition by employee_code order by c.date_raw_load_file asc  ),-1) end as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(        
                                                             c.worker_type
                                                            ,c.position_start_date
                                                            ,c.hire_date
                                                            ,c.continous_service_date
                                                            ,c.original_hire_date
                                                            ,c.effective_hire_date
                                                            ,c.effective_job_change_date
                                                            ,c.first_contract_type
                                                            ,c.first_contract_type_label
                                                            ,c.collective_agreement_reference
                                                            ,c.collective_agreement_reference_label
                                                            ,c.collective_agreement_group
                                                            ,c.collective_agreement_level
                                                            ,c.contract_start_date
                                                            ,c.contract_end_date
                                                            ,c.contract_type
                                                            ,c.contract_type_label
                                                            ,c.coefficient
                                                            ,c.coefficient_label
                                                            ,c.event_classification_subcategory
                                                            ,c.event_classification_subcategory_label
                                                            ,c.local_termination_reason
                                                            ,c.fte
                                                            ,c.total_base_pay
                                                            ,c.primary_comp_basis_amount
                                                            ,c.period_salary
                                                            ,c.period_salary_label
                                                            ,c.period_salary_amount
                                                            ,c.compensation_merit_plan
                                                            ,c.compensation_merit_plan_label
                                                            ,c.compensation_change_reason
                                                            ,c.compensation_change_subreason
                                                            ,c.compensation_bonus_plan
                                                            ,c.bonus_target
                                                            ,c.bonus_plan_name
                                                            ,c.additional_job_classifications
                                                            ,c.additional_job_classifications_label
                                                            ,c.compensation_currency
                                                            ,c.default_weekly_hours
                                                            ,c.scheduled_weekly_hours
                                                            ,c.effective_compensation_change_date
                                                            ,c.foreign_travel_indemnity_percent
                                                            ,c.foreign_travel_indemnity_amount
                                                            ,c.effective_suporg_change_date
                                                            ,case when c.professional_category_reference IS NULL then "nothing" else c.professional_category_reference end
                                                            ,upper(c.job_title)
                                                            ,c.grade 
                                                            ,c.management_level
                                                            ,c.job_profile_reference
                                                            ,c.time_type
                                                            ,c.time_type_label
                                                            ,c.paidfte
                                                            ,c.probation_start_date
                                                            ,c.probation_end_date
                                                            ,c.contract_reason
                                                            ,c.employee_visibility_date
                                                            ,c.prime_co_percent
                                                            ,c.prime_exp_percent
                                                           )) as hashkey 
                           ,'""" + runid + """' as runid
                           ,lower(trim(split(c.filepath,"/")[3])) as system_source
               from    vw_contract_join c
               
               where   1 = 1
                 and   (c.employee_id is not null or c.france_payroll_id is not null)
              
               """
              

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source).cache

// COMMAND ----------

// DBTITLE 1,Query to create the target table contracts
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }

// COMMAND ----------

// DBTITLE 1,Create the table contracts after drop the table if exists and store data and table structure on contracts_table
val contract_table = DeltaTable.forName("hr.contract")

// COMMAND ----------

// DBTITLE 1,Rows for contracts updated of existing employees
  val newcontract = df_results.as("contract_updated")
  .join(contract_table.toDF.where($"special_population"=!="1" or $"special_population".isNull).as("contract"),($"contract.france_payroll_id"===$"contract_updated.france_payroll_id" and
                                          $"contract.employee_id"===$"contract_updated.employee_id" and $"contract.effective_compensation_change_date"===$"contract_updated.effective_compensation_change_date") or ($"contract.employee_id"===$"contract_updated.employee_id" and $"contract_updated.france_payroll_id".isNull and $"contract.effective_compensation_change_date"===$"contract_updated.effective_compensation_change_date"))
  .where("""contract.current_record = true and (contract_updated.hashkey <> contract.hashkey) and contract_updated.date_raw_load_file >= contract.date_raw_load_file"""
)

// COMMAND ----------

// DBTITLE 1,Union of dataframes between contracts updated from existing employees and new contracts from new employees
// Stage the update by unioning two sets of rows
// 1. Rows that will be inserted in the `whenNotMatched` clause
// 2. Rows that will either UPDATE the current contracts of existing employees or insert the new contracts of new employees
val contract_upsert = newcontract
  .selectExpr("null as mergekey_1","null as mergekey_2", "null as mergekey_3", "contract_updated.*")   // Rows for 1.
  .union(
    df_results.as("df_results").selectExpr("df_results.france_payroll_id as mergekey_1",
                                           "df_results.employee_id as mergekey_2",
                                           "df_results.effective_compensation_change_date as mergekey_3",
                                           "*")  // Rows for 2.
  )
//remove duplicate
val contract_upsert_distinct = contract_upsert.distinct()

// COMMAND ----------

// DBTITLE 1,Merge on table contracts
contract_table.alias("t")
  .merge(
    contract_upsert_distinct.alias("s"),
    """((t.france_payroll_id=s.mergekey_1 and
     t.employee_id=s.mergekey_2) or (t.france_payroll_id is Null and t.employee_id=s.mergekey_2)) and t.effective_compensation_change_date = s.mergekey_3 """)
  .whenMatched("""t.current_record = true and (t.hashkey <> s.hashkey) and s.date_raw_load_file >= t.date_raw_load_file """)
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "case when date_add(s.record_start_date,-1)<t.record_start_date then t.record_start_date else date_add(s.record_start_date,-1) end ",
    "record_modification_date" -> "s.record_modification_date",
    "runid" -> "s.runid")
  )
  /*.whenMatched("""t.contract_end_date is null and s.date_raw_load_file > t.date_raw_load_file and s.contract_end_date is not null""")
    .updateExpr(Map(
     "contract_end_date" -> "s.contract_end_date"))*/
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Update employee_id where is null for old records and employee_id and france_payroll_id is not null for current record
spark.sql("""
merge into hr.contract c1
using hr.contract c2
on c1.france_payroll_id = c2.france_payroll_id
and c1.employee_id is null 
and c2.employee_id is not null
and c2.current_record = true
when matched then
  update set c1.employee_id = c2.employee_id,
             c1.current_record = false,
             c1.record_end_date = case when c1.record_end_date is null then date_add(c2.record_start_date,-1) end,
             c1.employee_code = c2.employee_code,
             c1.contract_key = c2.contract_key
""")

// COMMAND ----------

// DBTITLE 1,Update Employee Contract for CDD Remplacement
spark.sql("""
update hr.contract set 
contract_type = concat(contract_type, "-REMPLACEMENT"),
contract_type_label = concat(contract_type_label, "-", contract_reason),
contract_code = sha2(getconcatenedstring(array(concat(contract_type, "-REMPLACEMENT")               
                                                     ,worker_type
                                                     ,collective_agreement_reference
                                                     ,collective_agreement_group
                                                     ,collective_agreement_level
                                                     ,coefficient_label
                                                     )),256),
                            
info_dates_code = sha2(getconcatenedstring(array(position_start_date
                                                ,continous_service_date
                                                ,contract_start_date
                                                ,contract_end_date
                                                ,concat(contract_type, "-REMPLACEMENT")
                                                 )),256),
                            
contract_dates_code = sha2(getconcatenedstring(array(contract_start_date
                                                    ,contract_end_date
                                                    ,concat(contract_type, "-REMPLACEMENT")
                                                  )),256),
                                                             
contract_type_code = sha2(concat(contract_type, "-REMPLACEMENT") ,256)

where 1=1
and exists (
            select 1
            from vw_dbo_param_transco_ref 
            where 1=1
              and lower(concat(contract_type_label, "-", contract_reason)) = lower(source_value) 
              and axe = "NATURE_DE_CONTRAT" 
              and lower(di_value) = "cdd remplacement" 
           )
""")

// COMMAND ----------

// DBTITLE 1,Update Employee Contract for CDD Surcroit
spark.sql("""
update hr.contract set 
contract_type = concat(contract_type, "-SURCROIT"),
contract_type_label = concat(contract_type_label, "-", contract_reason),
contract_code = sha2(getconcatenedstring(array(concat(contract_type, "-SURCROIT")               
                                                     ,worker_type
                                                     ,collective_agreement_reference
                                                     ,collective_agreement_group
                                                     ,collective_agreement_level
                                                     ,coefficient_label
                                                     )),256),
                            
info_dates_code = sha2(getconcatenedstring(array(position_start_date
                                                ,continous_service_date
                                                ,contract_start_date
                                                ,contract_end_date
                                                ,concat(contract_type, "-SURCROIT")
                                                 )),256),
                            
contract_dates_code = sha2(getconcatenedstring(array(contract_start_date
                                                    ,contract_end_date
                                                    ,concat(contract_type, "-SURCROIT")
                                                  )),256),
                                                             
contract_type_code = sha2(concat(contract_type, "-SURCROIT") ,256)

where 1=1
and exists (
            select 1
            from vw_dbo_param_transco_ref 
            where 1=1
              and lower(concat(contract_type_label, "-", contract_reason)) = lower(source_value) 
              and axe = "NATURE_DE_CONTRAT" 
              and lower(di_value) = "surcroît temporaire d'activité" 
           )
""")

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE hr.contract")

// COMMAND ----------

// DBTITLE 1,Get Statistics
val read_records = df_contract_read.count().toInt //count the number of read records
val inserted_records = contract_upsert_distinct.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_contract_read.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.contract 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Get Record Start Date for each employee record
val byrecord_start = Window.partitionBy("employee_id","france_payroll_id","record_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val bylastrecord =   Window.partitionBy("employee_id","france_payroll_id").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val df_recordstart_read = spark.table("hr.contract")
                                                .withColumn("rank_start",rank() over byrecord_start)
                                                .filter(col("rank_start")==="1")
                                                .withColumn("next_record_end_date",lag($"record_start_date", 1, null).over(bylastrecord))
                                                .withColumn("new_record_end_date", date_add($"next_record_end_date", -1))
                                                .distinct
df_recordstart_read.createOrReplaceTempView("vw_recordstart")

// COMMAND ----------

// DBTITLE 1,Get the new record end date for each employee record
spark.sql("""
select employee_code,
       employee_id,
       france_payroll_id,
       record_start_date,
       record_end_date,
       new_record_end_date
       
from vw_recordstart
where coalesce(record_end_date,'2999-12-31') <> coalesce(new_record_end_date,'2999-12-31')
""").createOrReplaceTempView("vw_recordUpdate")

// COMMAND ----------

// DBTITLE 1,Update Record End Date For Each whose record end date is different from new record end date
spark.sql("""
merge into hr.contract c1
using vw_recordUpdate c2
on c1.employee_code = c2.employee_code
and c1.record_start_date = c2.record_start_date
and c2.new_record_end_date is not null

when matched then
  update set c1.record_end_date = c2.new_record_end_date,
             c1.current_record = false,
             c1.record_modification_date = current_timestamp()
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)