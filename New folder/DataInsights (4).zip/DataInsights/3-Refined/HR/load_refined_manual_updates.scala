// Databricks notebook source
// DBTITLE 1,Include notebook containing common functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")
//sc.getExecutorStorageStatus.length - 1

// COMMAND ----------

// MAGIC %md ##1 - Employee Manual Updates

// COMMAND ----------

// DBTITLE 1,Delete employee W20105462 Employee
spark.sql("""
delete from hr.employee where employee_id = 'W20105462'
""")

spark.sql("""
delete from hr.contract where employee_id = 'W20105462'
""")

// COMMAND ----------

// DBTITLE 1,Delete employee W20101886 Employee
spark.sql("""
delete from hr.employee where employee_id = 'W20101886'
""")

spark.sql("""
delete from hr.contract where employee_id = 'W20101886'
""")

// COMMAND ----------

// DBTITLE 1,Delete employee W20102701 Employee
spark.sql("""
delete from hr.employee where employee_id = 'W20102701'
""")

spark.sql("""
delete from hr.contract where employee_id = 'W20102701'
""")

// COMMAND ----------

// DBTITLE 1,Delete employee W20081094 Employee
spark.sql("""
delete from hr.employee where employee_id = 'W20081094'
""")

// COMMAND ----------

// DBTITLE 1,Fix Wrong Matricule France Payroll Id  019370019370 Employee
spark.sql("""
update hr.employee set 
france_payroll_id = '019370',
employee_key = getconcatenedstring(array(employee_id,
                                         '019370')),
                        
employee_code = sha2(getconcatenedstring(array(employee_id, '019370')),256) 
                            
where france_payroll_id = '019370019370'

""")

// COMMAND ----------

// MAGIC %md ##2 - Pay Manual Updates

// COMMAND ----------

// DBTITLE 1,Fix Wrong Matricule WD Pay
spark.sql("""
update hr.pay set 
employee_id = 'W20094100',
pay_key = getconcatenedstring(array( 'W20094100'
                                                          ,france_payroll_id
                                                          ,period_pay
                                                          ,period_valorisation
                                                          ,code_rubr
                                                          ,accounting_account)) ,
employee_code = sha2(getconcatenedstring(array('W20094100', france_payroll_id)),256)
where employee_id = 'W200094100'

""")

// COMMAND ----------

// DBTITLE 1,Fix Wrong Matricule France Payroll Id 019370019370 Pay
spark.sql("""
update hr.pay set 
france_payroll_id = '019370',
pay_key = getconcatenedstring(array( employee_id
                                                          ,'019370'
                                                          ,period_pay
                                                          ,period_valorisation
                                                          ,code_rubr
                                                          ,accounting_account)) ,
employee_code = sha2(getconcatenedstring(array(employee_id, '019370')),256)
where france_payroll_id = '019370019370'

""")

// COMMAND ----------

// MAGIC %md ##3 - Contract Manual Updates

// COMMAND ----------

// DBTITLE 1,Update total_base_pay for employee W00005521
spark.sql("""
update hr.contract set total_base_pay = 205846.1538461538 where employee_id = 'W00005521' and total_base_pay = 0
""")

// COMMAND ----------

// DBTITLE 1,Update Contract type label for CDD
spark.sql("""
update hr.contract set contract_type_label = 'Contrat à durée déterminée (CDD)' where contract_type_label like '%��%(CDD)' and contract_type = 'FRA08'
""")

// COMMAND ----------

// DBTITLE 1,Update Contract type label for CDI
spark.sql("""
update hr.contract set contract_type_label = 'Contrat à durée indéterminée (CDI)' where contract_type_label like '%��%(CDI)' and contract_type = 'FRA15'
""")

// COMMAND ----------

// DBTITLE 1,Delete employee W20081094 and W00013665
spark.sql("""
delete from hr.contract where employee_id = 'W20081094'
""")


spark.sql(""" 
delete from hr.contract where employee_id = 'W00013665' and contract_start_date = '2022-03-01'
""")

// COMMAND ----------

// DBTITLE 1,Update Continous Service Date
spark.sql("""
update hr.contract set 
continous_service_date = contract_start_date,
info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,contract_start_date
                                                   ,contract_start_date
                                                   ,'2016-12-31'
                                                   ,contract_type)),256),
                                                   
company_dates_code = sha2(getconcatenedstring(array( position_start_date
                                                    ,contract_start_date
                                                             )),256)                                                           
where 1=1
and (continous_service_date is null or continous_service_date = '0001-01-01' or continous_service_date > contract_start_date)

""")

// COMMAND ----------

// DBTITLE 1,Delete Last contract for employee W20095680
spark.sql("""
delete from hr.contract where employee_id = 'W20095680' and contract_start_date = '2022-04-01'
and contract_end_date is null
""")

// COMMAND ----------

// DBTITLE 1,Delete Last contract for employee W00013471
spark.sql("""
delete from hr.contract where employee_id = 'W00013471' and contract_start_date = '2022-06-01'
and contract_end_date is null
""")

// COMMAND ----------

// DBTITLE 1,Delete Last contract for employee W00012428
spark.sql("""
delete from hr.contract where employee_id = 'W00012428' and contract_start_date = '2022-09-01'
and contract_end_date is null
""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W20074579
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-10-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-10-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-10-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-10-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20074579' 
and contract_start_date = '2020-01-01'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W02001046
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-10-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-10-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-10-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-10-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W02001046' 
and contract_start_date = '2020-01-01'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W00012318
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-07-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-07-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-07-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-07-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00012318' 
and contract_start_date = '2015-04-01'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W20074955
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-10-09'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-10-09'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-10-09')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-10-09'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20074955' 
and contract_start_date = '2018-05-28'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W00013874
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-08-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-08-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-08-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-08-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00013874' 
and contract_start_date = '2017-01-01'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W00013361
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-08-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-08-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-08-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-08-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00013361' 
and contract_start_date = '2014-11-01'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W00010781
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-09-30'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-09-30'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-09-30')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-09-30'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00010781' 
and contract_start_date = '2017-10-01'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W00006412
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-08-29'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-08-29'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-08-29')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-08-29'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00006412' 
and contract_start_date = '2018-07-23'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W20076649
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-06-30'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-30'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-30')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-30'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20076649' 
and contract_start_date = '2019-10-21'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W20080252
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-08-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-08-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-08-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-08-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20080252' 
and contract_start_date = '2019-01-14'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W20003793
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-08-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-08-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-08-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-08-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20003793' 
and contract_start_date = '2017-12-18'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W20101043
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-05-11'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-05-11'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-05-11')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-05-11'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20101043' 
and contract_start_date = '2022-04-21'
and contract_end_date = '2023-04-28'

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W20097373
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-04-28'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-04-28'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-04-28')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-04-28'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20097373' 
and contract_start_date = '2021-10-18'
and contract_end_date = '2023-08-11'

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W20096472
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-06-30'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-30'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-30')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-30'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20096472' 
and contract_start_date = '2021-09-01'
and contract_end_date = '2023-08-31'

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W00012709
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-06-30'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-30'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-30')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-30'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00012709' 
and contract_start_date = '2010-05-01'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W20001124
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-05-14'
,local_termination_reason = 'Départ mutation externe'
,mobility_out_code = sha2('Départ mutation externe',256)
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-05-14'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-05-14')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-05-14'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20001124' 
and contract_start_date = '2018-07-01'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W00012645
spark.sql("""
update hr.contract set 
contract_end_date = '2016-12-31'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2016-12-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2016-12-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2016-12-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00012645' 
and contract_start_date = '2009-12-01'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W00012397
spark.sql("""
update hr.contract set 
contract_end_date = '2018-01-31'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2018-01-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2018-01-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2018-01-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00012397' 
and contract_start_date = '2014-04-01'
and contract_end_date = '2021-04-30'

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W00014239
spark.sql("""
update hr.contract set 
contract_end_date = '2016-12-31'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2016-12-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2016-12-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2016-12-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00014239' 
and contract_start_date = '2015-01-02'
and contract_end_date is null

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W20084831
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-05-31'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-05-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-05-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-05-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20084831' 
and contract_start_date = '2021-02-08'

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W00014080
spark.sql("""
update hr.contract set 
 contract_end_date = '2016-12-31'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2016-12-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2016-12-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2016-12-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00014080' 
and contract_start_date = '2014-09-08'

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W00014055
spark.sql("""
update hr.contract set 
 contract_end_date = '2018-05-31'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2018-05-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2018-05-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2018-05-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00014055' 
and contract_start_date = '2016-12-08'

""")

// COMMAND ----------

// DBTITLE 1,Update contract end date for employee W00012599
spark.sql("""
update hr.contract set 
 contract_end_date = '2018-03-31'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2018-03-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2018-03-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2018-03-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00012599' 
and contract_start_date = '2013-06-22'

""")

// COMMAND ----------

// DBTITLE 1,Fix Wrong Matricule France Payroll Id  019370019370
spark.sql("""
update hr.contract set 
france_payroll_id = '019370'
,contract_key = getconcatenedstring(array(employee_id,
                                         '019370'))
                        
,employee_code = sha2(getconcatenedstring(array(employee_id, '019370')),256) 
                            
where france_payroll_id = '019370019370'

""")

// COMMAND ----------

// DBTITLE 1,Update Compensation Reason to MERIT and Compensation Sub Reason to 2021 Annual Review for 202102
spark.sql("""
update  hr.contract set
compensation_change_reason = 'MERIT',
compensation_change_subreason = '2021 Annual Review' ,
compensation_change_code = sha2(getconcatenedstring(array('MERIT','2021 Annual Review')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (compensation_change_reason <> 'MERIT' or compensation_change_reason is null)
and (compensation_change_subreason <> '2021 Annual Review' or compensation_change_subreason is null)
and employee_id in (
'W00011865',
'W00012260',
'W00012359',
'W00012690',
'W00012906',
'W00013037',
'W20075180',
'W00013530',
'W00013933',
'W00013951',
'W20000995',
'W00014123',
'W00014137',
'W00014385',
'W20073910',
'W00014421',
'W20072716',
'W00015247',
'W20000579',
'W2001036',
'W20001814',
'W20002462',
'W20002479',
'W00301598',
'W20079120',
'W20086555',
'W00012436',
'W00012592',
'W00014389',
'W00015094',
'W20000330'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Compensation Reason to MERIT and Compensation Sub Reason to 2021 Annual Review for 202102
spark.sql("""
update  hr.contract set
compensation_change_reason = 'MERIT',
compensation_change_subreason = '2021 Annual Review' ,
compensation_change_code = sha2(getconcatenedstring(array('MERIT','2021 Annual Review')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (compensation_change_reason <> 'MERIT' or compensation_change_reason is null)
and (compensation_change_subreason <> '2021 Annual Review' or compensation_change_subreason is null)
and employee_id = 'W00010483'
""")

// COMMAND ----------

// DBTITLE 1,Update Compensation Reason to Correction and Compensation Sub Reason to Corrective Adjustment for 202101
spark.sql("""
update  hr.contract set
compensation_change_reason = 'Correction',
compensation_change_subreason = 'Corrective Adjustment' ,
compensation_change_code = sha2(getconcatenedstring(array('Correction','Corrective Adjustment')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (compensation_change_reason <> 'Correction' or compensation_change_reason is null)
and (compensation_change_subreason <> 'Corrective Adjustment' or compensation_change_subreason is null)
and employee_id in ( 
'W2001015',
'W00012680'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Compensation Reason to Correction and Compensation Sub Reason to Corrective Adjustment for 202103
spark.sql("""
update  hr.contract set
compensation_change_reason = 'Correction',
compensation_change_subreason = 'Corrective Adjustment' ,
compensation_change_code = sha2(getconcatenedstring(array('Correction','Corrective Adjustment')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (compensation_change_reason <> 'Correction' or compensation_change_reason is null)
and (compensation_change_subreason <> 'Corrective Adjustment' or compensation_change_subreason is null)
and employee_id = 'W00013854'
""")

// COMMAND ----------

// DBTITLE 1,Update Compensation Reason to Correction and Compensation Sub Reason to Corrective Adjustment for 202103
spark.sql("""
update  hr.contract set
compensation_change_reason = 'Correction',
compensation_change_subreason = 'Corrective Adjustment' ,
compensation_change_code = sha2(getconcatenedstring(array('Correction','Corrective Adjustment')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202104'
and (compensation_change_reason <> 'Correction' or compensation_change_reason is null)
and (compensation_change_subreason <> 'Corrective Adjustment' or compensation_change_subreason is null)
and employee_id = 'W00013664'
""")

// COMMAND ----------

// DBTITLE 1,Update Compensation Reason to Transfer and Compensation Sub Reason to Move to Different Position for 202101
spark.sql("""
update  hr.contract set
compensation_change_reason = 'Transfer',
compensation_change_subreason = 'Move to Different Position' ,
compensation_change_code = sha2(getconcatenedstring(array('Transfer','Move to Different Position')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (compensation_change_reason <> 'Transfer' or compensation_change_reason is null)
and (compensation_change_subreason <> 'Move to Different Position' or compensation_change_subreason is null)
and employee_id in (
'W00011871',
'W00012278',
'W20001186',
'W00011176',
'W00018092'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Compensation Reason to Transfer and Compensation Sub Reason to Move to Different Position for 202103
spark.sql("""
update  hr.contract set
compensation_change_reason = 'Transfer',
compensation_change_subreason = 'Move to Different Position' ,
compensation_change_code = sha2(getconcatenedstring(array('Transfer','Move to Different Position')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (compensation_change_reason <> 'Transfer' or compensation_change_reason is null)
and (compensation_change_subreason <> 'Move to Different Position' or compensation_change_subreason is null)
and employee_id = 'W00014068'
""")

// COMMAND ----------

// DBTITLE 1,Update Compensation Reason to Transfer and Compensation Sub Reason to Move to Different Position for 202104
spark.sql("""
update  hr.contract set
compensation_change_reason = 'Transfer',
compensation_change_subreason = 'Move to Different Position',
compensation_change_code = sha2(getconcatenedstring(array('Transfer','Move to Different Position')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202104'
and (compensation_change_reason <> 'Transfer' or compensation_change_reason is null)
and (compensation_change_subreason <> 'Move to Different Position' or compensation_change_subreason is null)
and employee_id = 'W00012599'
""")

// COMMAND ----------

// DBTITLE 1,Update Compensation Reason to Transfer and Compensation Sub Reason to Change in Current Position for 202101
spark.sql("""
update  hr.contract set
compensation_change_reason = 'Transfer',
compensation_change_subreason = 'Change in Current Position' ,
compensation_change_code = sha2(getconcatenedstring(array('Transfer','Change in Current Position')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (compensation_change_reason <> 'Transfer' or compensation_change_reason is null)
and (compensation_change_subreason <> 'Change in Current Position' or compensation_change_subreason is null)
and employee_id in (
'W00012236',
'W00013357',
'W00013471',
'W20001428',
'W20002197'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Compensation Reason to Base Salary Change and Compensation Sub Reason to Correction for 202101
spark.sql("""
update  hr.contract set
compensation_change_reason = 'Base Salary Change',
compensation_change_subreason = 'Correction' ,
compensation_change_code = sha2(getconcatenedstring(array('Base Salary Change','Correction')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (compensation_change_reason <> 'Base Salary Change' or compensation_change_reason is null)
and (compensation_change_subreason <> 'Correction' or compensation_change_subreason is null)
and employee_id in (
'W00018135',
'W20081216',
'W20081239',
'W20087042'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Compensation Reason for historical Data on 20210131
spark.sql("""
update  hr.contract set
compensation_change_reason = 'Data Change',
compensation_change_subreason = 'Change in Current Position' ,
compensation_change_code = sha2(getconcatenedstring(array('Data Change','Change in Current Position')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202105'
and (compensation_change_reason is null)
and (compensation_change_subreason is null)
and employee_id in (
'W00013568'

)
""")

// COMMAND ----------

// DBTITLE 1,Update Compensation Reason to Base Salary Change and Compensation Sub Reason to Brought to a Minimum for 202101
spark.sql("""
update  hr.contract set
compensation_change_reason = 'Base Salary Change',
compensation_change_subreason = 'Brought to a Minimum' ,
compensation_change_code = sha2(getconcatenedstring(array('Base Salary Change','Brought to a Minimum')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (compensation_change_reason <> 'Base Salary Change' or compensation_change_reason is null)
and (compensation_change_subreason <> 'Brought to a Minimum' or compensation_change_subreason is null)
and employee_id in (
'W00014862',
'W20073243',
'W20075804',
'W20088102',
'W20076992',
'W20080425',
'W20082851',
'W20083920',
'W20084411',
'W20085088',
'W20084694',
'W20084483',
'W20088142',
'W20088895',
'W20084439',
'W20085059',
'W20002501'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Merit Plan to FRA Individual Increase only (MBT) for 202101
spark.sql("""
update  hr.contract set
compensation_merit_plan = 'MERIT_FRA_0002',
compensation_merit_plan_label = 'FRA Individual Increase only (MBT)' ,
compensation_merit_plan_code = sha2('MERIT_FRA_0002',256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (compensation_merit_plan <> 'MERIT_FRA_0002' or compensation_merit_plan is null)
and employee_id in (
'W00011176',
'W00011865',
'W00011871',
'W00012236',
'W00012260',
'W00012278',
'W00012359',
'W00012436',
'W00012592',
'W00012680',
'W00012690',
'W00012906',
'W00013037',
'W20075180',
'W00013357',
'W00013471',
'W00014389',
'W00015094',
'W00013530',
'W00013745',
'W00013933',
'W00013951',
'W20000995',
'W00014123',
'W00014137',
'W00014385',
'W00014421',
'W20072716',
'W00015247',
'W00018135',
'W20000579',
'W2001015',
'W20001186',
'W20001428',
'W20001814',
'W20002462',
'W20002479',
'W20002197',
'W00301598',
'W20073243',
'W20079120',
'W20080425',
'W20081216',
'W20081239',
'W20087042',
'W20000330',
'W20083594',
'W20083677',
'W00018092'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Merit Plan to FRA Individual Increase only (MBT) for 202102
spark.sql("""
update  hr.contract set
compensation_merit_plan = 'MERIT_FRA_0002',
compensation_merit_plan_label = 'FRA Individual Increase only (MBT)' ,
compensation_merit_plan_code = sha2('MERIT_FRA_0002',256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (compensation_merit_plan <> 'MERIT_FRA_0002' or compensation_merit_plan is null)
and employee_id = 'W00010483'
""")

// COMMAND ----------

// DBTITLE 1,Update Merit Plan to FRA Individual Increase only (MBT) for 202103
spark.sql("""
update  hr.contract set
compensation_merit_plan = 'MERIT_FRA_0002',
compensation_merit_plan_label = 'FRA Individual Increase only (MBT)' ,
compensation_merit_plan_code = sha2('MERIT_FRA_0002',256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (compensation_merit_plan <> 'MERIT_FRA_0002' or compensation_merit_plan is null)
and employee_id in (
'W00013854',
'W00014068'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Merit Plan to FRA Individual Increase only (MBT) for 202104
spark.sql("""
update  hr.contract set
compensation_merit_plan = 'MERIT_FRA_0002',
compensation_merit_plan_label = 'FRA Individual Increase only (MBT)' ,
compensation_merit_plan_code = sha2('MERIT_FRA_0002',256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202104'
and (compensation_merit_plan <> 'MERIT_FRA_0002' or compensation_merit_plan is null)
and employee_id in (
'W00012599',
'W00013664'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Merit Plan to FRA Individual Increase only (MBT) for 202105
spark.sql("""
update  hr.contract set
compensation_merit_plan = 'MERIT_FRA_0002',
compensation_merit_plan_label = 'FRA Individual Increase only (MBT)' ,
compensation_merit_plan_code = sha2('MERIT_FRA_0002',256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202105'
and (compensation_merit_plan <> 'MERIT_FRA_0002' or compensation_merit_plan is null)
and employee_id = 'W00013568'
""")

// COMMAND ----------

// DBTITLE 1,Update Merit Plan to FRA General + Individual Increase (MBT) for 202101
spark.sql("""
update  hr.contract set
compensation_merit_plan = 'MERIT_FRA_0001',
compensation_merit_plan_label = 'FRA General + Individual Increase (MBT)' ,
compensation_merit_plan_code = sha2('MERIT_FRA_0001',256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (compensation_merit_plan <> 'MERIT_FRA_0001' or compensation_merit_plan is null)
and employee_id in (
'W20073910',
'W2001036',
'W20086555',
'W20072202',
'W20073118',
'W20074230',
'W20082246',
'W20083710',
'W20083226',
'W20084606',
'W20084799',
'W20087641'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.005 for 202101
spark.sql("""
update  hr.contract set
bonus_target = '0.005'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (bonus_target <> '0.005' or bonus_target is null)
and employee_id in (
'W00010112',
'W00010229',
'W00010239',
'W00010423',
'W00010429',
'W00010901',
'W00011968',
'W00012019',
'W00012390',
'W00012828',
'W00012885',
'W00012971',
'W00013154',
'W00013224',
'W00013379',
'W00013819',
'W00014175',
'W00014178',
'W00014527',
'W00014618',
'W00015194',
'W00015197',
'W20000704',
'W20001780',
'W20002059',
'W20002611',
'W20002930',
'W20074795',
'W20076686',
'W20077525',
'W20079643',
'W20085708',
'W20086555',
'W20087357',
'W20090935'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.01 for 202101
spark.sql("""
update  hr.contract set
bonus_target = '0.01'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (bonus_target <> '0.01' or bonus_target is null)
and employee_id in (
'W00010787',
'W00011012',
'W00012166',
'W00012532',
'W00013110',
'W00014025'

)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.015 for 202101
spark.sql("""
update  hr.contract set
bonus_target = '0.015'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (bonus_target <> '0.015' or bonus_target is null)
and employee_id in (
'W00010198',
'W00010362',
'W00010368',
'W00010524',
'W00010554',
'W00010721',
'W00010731',
'W00010797',
'W00011141',
'W00011208',
'W00011713',
'W00011841',
'W00011865',
'W00012151',
'W00012260',
'W00012278',
'W00012359',
'W00012368',
'W00012495',
'W00012553',
'W00013046',
'W00013459',
'W00013854',
'W20000499',
'W2001036',
'W20073910',
'W20074779',
'W20076369'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.04 for 202101
spark.sql("""
update  hr.contract set
bonus_target = '0.04'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (bonus_target <> '0.04' or bonus_target is null)
and employee_id in (
'W00012122',
'W00012213',
'W00013323',
'W00013474',
'W00013613',
'W00013738',
'W00013758',
'W20002670',
'W20003582',
'W20073143',
'W20079117'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.05 for 202101
spark.sql("""
update  hr.contract set
bonus_target = '0.05'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (bonus_target <> '0.05' or bonus_target is null)
and employee_id in (
'W00006567',
'W00010770',
'W00011176',
'W00011454',
'W00011872',
'W00011904',
'W00012098',
'W00012522',
'W00012836',
'W00012876',
'W00013015',
'W00013272',
'W00013340',
'W00013471',
'W00013530',
'W00013666',
'W00013882',
'W00013911',
'W00014247',
'W00014299',
'W00014354',
'W00014370',
'W00014392',
'W00014498',
'W00014541',
'W00014590',
'W00014868',
'W00014983',
'W00018107',
'W20000730',
'W20001093',
'W20001428',
'W20001524',
'W20002197',
'W20002579',
'W20003651',
'W20072716',
'W20073228',
'W20073243',
'W20074516',
'W20075614',
'W20080144',
'W20080425',
'W20084840',
'W20086929',
'W20087776'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.07 for 202101
spark.sql("""
update  hr.contract set
bonus_target = '0.07'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (bonus_target <> '0.07' or bonus_target is null)
and employee_id in (
'W00010483',
'W00011871',
'W00011950',
'W00012317',
'W00012574',
'W00012778',
'W00013032',
'W00013119',
'W00013194',
'W00013620',
'W00013665',
'W00013933',
'W00014137',
'W00014421',
'W00015247',
'W00018092',
'W20000579',
'W20000995',
'W20002462',
'W20002479',
'W20078424',
'W20081360',
'W20081756',
'W20084351',
'W20090698'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.0746 for 202101
spark.sql("""
update  hr.contract set
bonus_target = '0.0746'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (bonus_target <> '0.0746' or bonus_target is null)
and employee_id in (
'W00012345',
'W00012680',
'W00012742',
'W00013239',
'W00013296',
'W00013570',
'W00014282',
'W20001972',
'W20002032',
'W20002992',
'W20074848',
'W20077599',
'W20080592'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.1 for 202101
spark.sql("""
update  hr.contract set
bonus_target = '0.1'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (bonus_target <> '0.1' or bonus_target is null)
and employee_id in (
'W00010003',
'W00011763',
'W00012327',
'W00012690',
'W00012869',
'W00013037',
'W00013304',
'W00013763',
'W00014123',
'W00014222',
'W00014385',
'W00014909',
'W00015074',
'W00018135',
'W20001186',
'W20001814',
'W20075180',
'W20075278',
'W20079120',
'W20081216',
'W20087042',
'W20091933'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.12 for 202101
spark.sql("""
update  hr.contract set
bonus_target = '0.12'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (bonus_target <> '0.12' or bonus_target is null)
and employee_id in (
'W00013357',
'W2001015'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.15 for 202101
spark.sql("""
update  hr.contract set
bonus_target = '0.15'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (bonus_target <> '0.15' or bonus_target is null)
and employee_id in (
'W00010662',
'W00010668',
'W00011524',
'W00011538',
'W00011570',
'W00011829',
'W00011894',
'W00012041',
'W00012061',
'W00012526',
'W00012906',
'W00012956',
'W00013253',
'W00013621',
'W00013644',
'W00013724',
'W00013736',
'W00013951',
'W00014389',
'W00015269',
'W00015341',
'W20002800',
'W20074487',
'W20076150',
'W20077958',
'W20081239'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.2 for 202101
spark.sql("""
update  hr.contract set
bonus_target = '0.2'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (bonus_target <> '0.2' or bonus_target is null)
and employee_id in (
'W00011458',
'W00012731',
'W00012928',
'W20002833'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.25 for 202101
spark.sql("""
update  hr.contract set
bonus_target = '0.25'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (bonus_target <> '0.25' or bonus_target is null)
and employee_id in (
'W00012878'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.3 for 202101
spark.sql("""
update  hr.contract set
bonus_target = '0.3'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (bonus_target <> '0.3' or bonus_target is null)
and employee_id in (
'W00011845',
'W00012236'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.005 for 202102
spark.sql("""
update  hr.contract set
bonus_target = '0.005'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (bonus_target <> '0.005' or bonus_target is null)
and employee_id in (
'W00010112',
'W00010229',
'W00010239',
'W00010429',
'W00010901',
'W00011968',
'W00012019',
'W00012828',
'W00013154',
'W00013224',
'W00013379',
'W00013819',
'W00014178',
'W00014527',
'W00014618',
'W00015194',
'W00015197',
'W20000704',
'W20001780',
'W20002059',
'W20002611',
'W20002930',
'W20074795',
'W20077525',
'W20085708',
'W20086555',
'W20087357',
'W20090935'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.01 for 202102
spark.sql("""
update  hr.contract set
bonus_target = '0.01'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (bonus_target <> '0.01' or bonus_target is null)
and employee_id in (
'W00010787',
'W00011012',
'W00013110'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.015 for 202102
spark.sql("""
update  hr.contract set
bonus_target = '0.015'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (bonus_target <> '0.015' or bonus_target is null)
and employee_id in (
'W00010198',
'W00010368',
'W00010524',
'W00010554',
'W00010721',
'W00010731',
'W00011141',
'W00011208',
'W00011713',
'W00011841',
'W00011865',
'W00012151',
'W00012260',
'W00012278',
'W00012359',
'W00012495',
'W00012553',
'W00013046',
'W00013459',
'W00013854',
'W20000499',
'W2001036',
'W20073910',
'W20074779',
'W20076369'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.04 for 202102
spark.sql("""
update  hr.contract set
bonus_target = '0.04'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (bonus_target <> '0.04' or bonus_target is null)
and employee_id in (
'W00012122',
'W00013323',
'W00013613',
'W00013738',
'W20002670',
'W20003582',
'W20073143'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.05 for 202102
spark.sql("""
update  hr.contract set
bonus_target = '0.05'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (bonus_target <> '0.05' or bonus_target is null)
and employee_id in (
'W00006567',
'W00010770',
'W00011176',
'W00011454',
'W00011872',
'W00011904',
'W00012098',
'W00012836',
'W00012876',
'W00013015',
'W00013530',
'W00013666',
'W00013911',
'W00014247',
'W00014354',
'W00014392',
'W00014498',
'W00014541',
'W00014983',
'W00018107',
'W20000730',
'W20001093',
'W20001428',
'W20001524',
'W20002197',
'W20002579',
'W20003651',
'W20072716',
'W20073228',
'W20074516',
'W20075614',
'W20080425',
'W20084840',
'W20086929',
'W20087776'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.07 for 202102
spark.sql("""
update  hr.contract set
bonus_target = '0.07'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (bonus_target <> '0.07' or bonus_target is null)
and employee_id in (
'W00011871',
'W00012574',
'W00012778',
'W00013032',
'W00013119',
'W00013194',
'W00013620',
'W00013933',
'W00014137',
'W00014421',
'W00015247',
'W00018092',
'W20000579',
'W20000995',
'W20002462',
'W20002479',
'W20078424',
'W20081360',
'W20084351',
'W20090698'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.0746 for 202102
spark.sql("""
update  hr.contract set
bonus_target = '0.0746'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (bonus_target <> '0.0746' or bonus_target is null)
and employee_id in (
'W00012345',
'W00012680',
'W00012742',
'W00013570',
'W00014282',
'W20001972',
'W20002032',
'W20074848'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.1 for 202102
spark.sql("""
update  hr.contract set
bonus_target = '0.1'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (bonus_target <> '0.1' or bonus_target is null)
and employee_id in (
'W00010003',
'W00010483',
'W00011763',
'W00012327',
'W00012690',
'W00013037',
'W00013272',
'W00013304',
'W00013763',
'W00014123',
'W00014385',
'W00018135',
'W20001186',
'W20001814',
'W20075180',
'W20079120',
'W20081216',
'W20087042',
'W20091933'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.12 for 202102
spark.sql("""
update  hr.contract set
bonus_target = '0.12'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (bonus_target <> '0.12' or bonus_target is null)
and employee_id in (
'W2001015'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.15 for 202102
spark.sql("""
update  hr.contract set
bonus_target = '0.15'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (bonus_target <> '0.15' or bonus_target is null)
and employee_id in (
'W00010662',
'W00010668',
'W00011524',
'W00011538',
'W00011570',
'W00011829',
'W00012041',
'W00012061',
'W00012906',
'W00012956',
'W00013253',
'W00013621',
'W00013644',
'W00013736',
'W00013951',
'W00014389',
'W00015269',
'W20002800',
'W20074487',
'W20076150',
'W20077958'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.2 for 202102
spark.sql("""
update  hr.contract set
bonus_target = '0.2'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (bonus_target <> '0.2' or bonus_target is null)
and employee_id in (
'W00011458',
'W00012731',
'W00012928',
'W20002833'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.3 for 202102
spark.sql("""
update  hr.contract set
bonus_target = '0.3'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202102'
and (bonus_target <> '0.3' or bonus_target is null)
and employee_id in (
'W00011845',
'W00012236'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.005 for 202103
spark.sql("""
update  hr.contract set
bonus_target = '0.005'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (bonus_target <> '0.005' or bonus_target is null)
and employee_id in (
'W00010429',
'W00012828',
'W00013154',
'W00013224',
'W00013819',
'W20074795',
'W20085708',
'W20090935'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.01 for 202103
spark.sql("""
update  hr.contract set
bonus_target = '0.01'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (bonus_target <> '0.01' or bonus_target is null)
and employee_id in (
'W00010787',
'W00011012',
'W00013110'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.015 for 202103
spark.sql("""
update  hr.contract set
bonus_target = '0.015'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (bonus_target <> '0.015' or bonus_target is null)
and employee_id in (
'W00010198',
'W00010524',
'W00012495',
'W00013459',
'W00013854',
'W20074779'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.04 for 202103
spark.sql("""
update  hr.contract set
bonus_target = '0.04'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (bonus_target <> '0.04' or bonus_target is null)
and employee_id in (
'W00012122',
'W20002670',
'W20073143'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.05 for 202103
spark.sql("""
update  hr.contract set
bonus_target = '0.05'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (bonus_target <> '0.05' or bonus_target is null)
and employee_id in (
'W00011176',
'W00012876',
'W00013530',
'W00013666',
'W00013911',
'W00014247',
'W00014354',
'W00014983',
'W20000730',
'W20001093',
'W20001428'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.07 for 202103
spark.sql("""
update  hr.contract set
bonus_target = '0.07'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (bonus_target <> '0.07' or bonus_target is null)
and employee_id in (
'W00013119',
'W00013620',
'W00014137',
'W00018092'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.0746 for 202103
spark.sql("""
update  hr.contract set
bonus_target = '0.0746'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (bonus_target <> '0.0746' or bonus_target is null)
and employee_id in (
'W00012345',
'W00012680',
'W00012742',
'W00014282',
'W20001972'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.1 for 202103
spark.sql("""
update  hr.contract set
bonus_target = '0.1'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (bonus_target <> '0.1' or bonus_target is null)
and employee_id in (
'W00012327',
'W00013272',
'W00013304',
'W00013763',
'W20079120'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.15 for 202103
spark.sql("""
update  hr.contract set
bonus_target = '0.15'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (bonus_target <> '0.15' or bonus_target is null)
and employee_id in (
'W00010668',
'W00011524',
'W00011538',
'W00012041',
'W00012906',
'W00012956',
'W00013253',
'W00013644',
'W00013736',
'W00015269',
'W20002800',
'W20074487',
'W20076150',
'W20077958'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.2 for 202103
spark.sql("""
update  hr.contract set
bonus_target = '0.2'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (bonus_target <> '0.2' or bonus_target is null)
and employee_id in (
'W00012928'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.3 for 202103
spark.sql("""
update  hr.contract set
bonus_target = '0.3'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202103'
and (bonus_target <> '0.3' or bonus_target is null)
and employee_id in (
'W00011845'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.05 for 202104
spark.sql("""
update  hr.contract set
bonus_target = '0.05'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202104'
and (bonus_target <> '0.05' or bonus_target is null)
and employee_id in (
'W00013530',
'W00013666'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.15 for 202104
spark.sql("""
update  hr.contract set
bonus_target = '0.15'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202104'
and (bonus_target <> '0.15' or bonus_target is null)
and employee_id in (
'W00013530',
'W00013666'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target 0.07 for 202104
spark.sql("""
update  hr.contract set
bonus_target = '0.07'
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202104'
and (bonus_target <> '0.07' or bonus_target is null)
and employee_id in (
'W00018092'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target and Bonus Plan name for Specific Population W00010544
spark.sql("""
update  hr.contract set
bonus_target = '0.35',
bonus_plan_name = 'Global LT Bonus Plan',
compensation_bonus_plan = 'BONUS_LT_0001',
compensation_bonus_plan_code = sha2('BONUS_LT_0001',256) 
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') >= '202001'
and (bonus_target <> '0.35' or bonus_target is null)
and employee_id in (
'W00010544'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target and Bonus Plan name for Specific Population W00011443
spark.sql("""
update  hr.contract set
bonus_target = '0.005',
bonus_plan_name = 'FRA Exceptional Premium Plan',
compensation_bonus_plan = 'BONUS_FRA_0003',
compensation_bonus_plan_code = sha2('BONUS_FRA_0003',256) 
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') >= '202001'
and (bonus_target <> '0.005' or bonus_target is null)
and employee_id  in (
'W00011443'
)
""")

// COMMAND ----------

// DBTITLE 1,Update Bonus Target and Bonus Plan name for Specific Population W00005521
spark.sql("""
update  hr.contract set
bonus_target = '0.5',
bonus_plan_name = 'Global LT Bonus Plan',
compensation_bonus_plan = 'BONUS_LT_0001',
compensation_bonus_plan_code = sha2('BONUS_LT_0001',256) 
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') >= '202001'
and (bonus_target <> '0.5' or bonus_target is null)
and employee_id in (
'W00005521'
)
""")

// COMMAND ----------

// DBTITLE 1,JIRA 170 - Set Contract End Date for W20077911 to 31/07/2021 for contract starting from 01/10/2020
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-07-31'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-07-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-07-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-07-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and france_payroll_id = '024655'
and contract_start_date = '2020-10-01'

""")

// COMMAND ----------

// DBTITLE 1,JIRA 170 - Set Contract End Date for W20093640 to 12/09/2021 for contract starting from 19/04/2021
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-09-12'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-09-12'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-09-12')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-09-12'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20093640' 
and contract_start_date = '2021-04-19'

""")

// COMMAND ----------

// DBTITLE 1,JIRA 171 - Delete employee cost center for Expat
//W00010711
spark.sql("""
delete from hr.employee where employee_id = 'W00010711' and cost_center_code = '02/4500'
""")

spark.sql("""
update hr.employee
set record_end_date = '2021-08-31'
where employee_id = 'W00010711' and cost_center_code = 'X390DINF' and cost_center_end_date = '2021-08-31'
""")

//W00013311
spark.sql("""
delete from hr.employee where employee_id = 'W00013311' and cost_center_code = '02/4510'
""")

spark.sql("""
update hr.employee
set record_end_date = '2021-08-31'
where employee_id = 'W00013311' and cost_center_code = 'X390DINF' and cost_center_end_date = '2021-08-31'
""")

//W00014039
spark.sql("""
delete from hr.employee where employee_id = 'W00014039' and cost_center_code = '02/4500'
""")

spark.sql("""
update hr.employee
set record_end_date = '2021-08-31'
where employee_id = 'W00014039' and cost_center_code = 'X390DINF' and cost_center_end_date = '2021-08-31'
""")

//W00014331
spark.sql("""
delete from hr.employee where employee_id = 'W00014331' and cost_center_code = '02/4510'
""")

spark.sql("""
update hr.employee
set record_end_date = '2021-08-31'
where employee_id = 'W00014331' and cost_center_code = 'X390DI17' and cost_center_end_date = '2021-08-31'
""")

//W20000605
spark.sql("""
delete from hr.employee where employee_id = 'W20000605' and cost_center_code = '02/4510'
""")

spark.sql("""
update hr.employee
set record_end_date = '2021-08-31'
where employee_id = 'W20000605' and cost_center_code = 'X390DI17' and cost_center_end_date = '2021-08-31'
""")

// COMMAND ----------

val sqlEmployeeCurrentRecord = """
select 
e1.*


from hr.employee e1

where current_record = false
and not exists (
select * from hr.employee e2 where e1.employee_code = e2.employee_code and e1.record_start_date < e2.record_start_date
)
and not exists (
select * from hr.employee e2 where e1.employee_code = e2.employee_code and e1.record_creation_date < e2.record_creation_date
)
  
"""
spark.sql(sqlEmployeeCurrentRecord).createOrReplaceTempView("vw_currentEmployee")

spark.sql("""
merge into hr.employee e1

using vw_currentEmployee e2
on e1.employee_code = e2.employee_code
and e1.record_start_date = e2.record_start_date
and e1.record_end_date = e2.record_end_date

when matched then
  update set e1.current_record = true,
             e1.record_modification_date = current_timestamp()
""")

// COMMAND ----------

// DBTITLE 1,JIRA 388 - Update record start date for Employee
val byemployee_start = Window.partitionBy("employee_id","france_payroll_id").orderBy($"record_creation_date".asc,$"record_start_date".asc,$"date_raw_load_file".asc)
val df_employee_read_start = spark.table("hr.employee").filter($"special_population" === 1).select("employee_code","employee_id","france_payroll_id","record_start_date","record_end_date", "date_raw_load_file", "record_creation_date", "record_modification_date","filename").distinct
                                                .withColumn("prev_start_date",lag($"record_start_date", 1, null).over(byemployee_start))
                                                .withColumn("new_record_start_date",when($"prev_start_date".isNull,$"record_start_date").otherwise(to_date($"record_creation_date")))

                                                .distinct
                                                .where($"filename" =!= "histo_file")

df_employee_read_start.createOrReplaceTempView("vw_employee_special_record_start")

spark.sql("""
merge into hr.employee e1

using vw_employee_special_record_start e2
on e1.employee_code = e2.employee_code
and e1.record_start_date = e2.record_start_date
and e1.record_creation_date = e2.record_creation_date

when matched then
  update set e1.record_start_date = e2.new_record_start_date,
             e1.record_modification_date = current_timestamp()
""")


// COMMAND ----------

// DBTITLE 1,Update Record end date for Employee
val byemployee_start = Window.partitionBy("employee_id","france_payroll_id","record_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_creation_date".desc,$"record_modification_date".desc)
val byemployee = Window.partitionBy("employee_id","france_payroll_id").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val df_employee_read = spark.table("hr.employee").select("employee_code","employee_id","france_payroll_id","record_start_date","record_end_date", "date_raw_load_file", "record_creation_date", "record_modification_date").distinct
                                                .withColumn("rank_start",rank() over byemployee_start)
                                                .filter(col("rank_start")==="1")
                                                .withColumn("next_record_end_date",lag($"record_start_date", 1, null).over(byemployee))
                                                .withColumn("new_record_end_date", date_add($"next_record_end_date", -1))
                                                .distinct
df_employee_read.createOrReplaceTempView("vw_employee")



spark.sql("""
select employee_code,
       employee_id,
       france_payroll_id,
       record_start_date,
       record_end_date,
       new_record_end_date,
       record_creation_date,
       record_modification_date
       
from vw_employee
where coalesce(record_end_date,"1999-01-01") <> new_record_end_date or new_record_end_date is null 
""").createOrReplaceTempView("vw_employee_update")


spark.sql("""
merge into hr.employee e1

using vw_employee_update e2
on e1.employee_code = e2.employee_code
and e1.record_start_date = e2.record_start_date

when matched then
  update set e1.record_end_date = e2.new_record_end_date,
             e1.record_modification_date = current_timestamp()
""")

// COMMAND ----------

// DBTITLE 1,JIRA 176 - Mise à jour date de fin de contrat
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-08-31'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-08-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-08-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-08-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20093497' 
and contract_start_date = '2021-04-06'

""")

// COMMAND ----------

// DBTITLE 1,Mise à jour date contrat - 2021-11-04 - HRA ID = 103427
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-09-30'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-09-30'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-09-30')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-09-30'
                                                      ,contract_type)),256)
                                                      
where 1=1
and france_payroll_id = '103427' 
and contract_start_date = '2021-05-10'
and contract_end_date = '2021-10-01'

""")

// COMMAND ----------

// DBTITLE 1,Mise à jour date contrat - 2021-11-04 - HRA ID = 060142
spark.sql("""
update hr.contract set 
 contract_start_date = '2021-10-01'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,'2021-10-01'
                                                   ,contract_end_date
                                                   ,contract_type)),256)
                                                             
,contract_dates_code = sha2(getconcatenedstring(array('2021-10-01'
                                                      ,contract_end_date
                                                      ,contract_type)),256)
                                                      
where 1=1
and france_payroll_id = '060142' 
and contract_start_date = '2015-11-02'


""")

// COMMAND ----------

// DBTITLE 1,Mise à jour contrat CDD/CDI - W20084036
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-09-12'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-09-12'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-09-12')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-09-12'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20084036' 
and contract_start_date = '2021-02-22'
and contract_end_date = '2022-02-28'
and contract_type in ('FRA11','SR')

""")


spark.sql("""
update hr.contract set 
 contract_start_date = '2021-09-13'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,'2021-09-13'
                                                   ,contract_end_date
                                                   ,contract_type)),256)
                                                             
,contract_dates_code = sha2(getconcatenedstring(array('2021-09-13'
                                                      ,contract_end_date
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20084036' 
and contract_start_date = '2021-02-22'
and contract_type in ('FRA15')


""")

// COMMAND ----------

// DBTITLE 1,Mise à jour salaire stage pour W20091219 
spark.sql("""
update hr.contract set 
total_base_pay = 18000  
where 1=1
and employee_id = 'W20091219' 
and total_base_pay = 1500
and contract_start_date = '2020-09-07'

""")

// COMMAND ----------

// DBTITLE 1,Gestion des cas 19M provenant de HRA - exclusion des montants
/* cas 011041 à exclure à partir de juillet 2021*/
spark.sql("""
delete from hr.pay
where france_payroll_id = '011041'
and period_pay_month >= '202107'
""")

// COMMAND ----------

/* cas 102129 à exclure à partir de novembre 2021 hors 2 rubriques correspondant à son ancien CC*/
spark.sql("""
delete from hr.pay
where france_payroll_id = '102129'
and period_pay_month = '202111'
and code_rubr not in ('BW7P','BW6S')
""")

// COMMAND ----------

spark.sql("""
delete from hr.pay
where france_payroll_id = '102129'
and period_pay_month >= '202112'
""")

// COMMAND ----------

/* matricules 19M à éxclure*/
spark.sql("""
delete from hr.pay
where france_payroll_id in (
  '060133'
  ,'060136'
  ,'060137'
  ,'060138'
)
""")
/*,'060140'*/

// COMMAND ----------

// DBTITLE 1,JIRA 155 - Update Compensation change reason
/*
select compensation_change_reason,compensation_change_subreason,effective_compensation_change_date,filename,total_base_pay,* from hr.contract where employee_id = 'W00012553' order by record_start_date desc*/

// COMMAND ----------

spark.sql("""
update  hr.contract set
compensation_change_reason = 'MERIT',
compensation_change_subreason = '2021 Annual Review' ,
compensation_change_code = sha2(getconcatenedstring(array('MERIT','2021 Annual Review')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (compensation_change_reason <> 'MERIT' or compensation_change_reason is null)
and (compensation_change_subreason <> '2021 Annual Review' or compensation_change_subreason is null)
and employee_id in ('W20001222','W20088630')
""")

// COMMAND ----------

spark.sql("""
update  hr.contract set
compensation_change_reason = 'Data Change',
compensation_change_subreason = 'Change in Current Position' ,
compensation_change_code = sha2(getconcatenedstring(array('Data Change','Change in Current Position')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (compensation_change_reason <> 'Data Change' or compensation_change_reason is null)
and (compensation_change_subreason <> 'Change in Current Position' or compensation_change_subreason is null)
and employee_id in ('W20076650')
""")

// COMMAND ----------

spark.sql("""
update  hr.contract set
compensation_change_reason = 'Base Salary Change',
compensation_change_subreason = 'Brought to a Minimum' ,
compensation_change_code = sha2(getconcatenedstring(array('Base Salary Change','Brought to a Minimum')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202101'
and (compensation_change_reason <> 'Base Salary Change' or compensation_change_reason is null)
and (compensation_change_subreason <> 'Brought to a Minimum' or compensation_change_subreason is null)
and employee_id in ('W00013018','W00013973','W20003660','W20082693','W20082345','W20088751','W20088342')
""")

// COMMAND ----------

spark.sql("""
update  hr.contract set
compensation_change_reason = 'Base Salary Change',
compensation_change_subreason = 'Brought to a Minimum' ,
compensation_change_code = sha2(getconcatenedstring(array('Base Salary Change','Brought to a Minimum')),256)
where 1=1
and date_format(effective_compensation_change_date,'yyyyMM') = '202105'
and (compensation_change_reason <> 'Base Salary Change' or compensation_change_reason is null)
and (compensation_change_subreason <> 'Brought to a Minimum' or compensation_change_subreason is null)
and employee_id in ('W00011104')
""")

// COMMAND ----------

spark.sql(""" 
update hr.employee set 
france_payroll_id = '060144',
employee_key = getconcatenedstring(array(employee_id,
                                          '060144')),
employee_code = sha2(getconcatenedstring(array(employee_id, '060144')),256)
where 1=1
and employee_id = 'W20097563'
and france_payroll_id is null
""")

// COMMAND ----------

// DBTITLE 1,Update Grade 00 for intership and alternance
spark.sql("""
update hr.contract set 
grade = 'GRADE_00',
grade_code = sha2('GRADE_00', 256),
job_code= sha2(getconcatenedstring(array(
                                                             lower(job_title)
                                                            ,'GRADE_00' 
                                                            ,management_level
                                                            ,job_profile_reference)),256)

where 1=1
and lower(grade) = 'not_graded'
and upper(contract_type) not in ('FRA08','DD','FRA15','DI','DE','FRA17','IT05','FRA16') 
and contract_type not in ('Contrat à durée déterminée (CDD)', 'Contrat à durée indéterminée (CDI)', 'Détachés (CDI)','Permanent')
and date_format(contract_start_date,'yyyy') <= 2021 
and (date_format(contract_end_date,'yyyy') >= 2021 or contract_end_date is null)
""")

// COMMAND ----------

spark.sql("""
update hr.contract set 
grade = 'NOT_GRADED',
grade_code = sha2('NOT_GRADED', 256),
job_code= sha2(getconcatenedstring(array(
                                                             lower(job_title)
                                                            ,'NOT_GRADED' 
                                                            ,management_level
                                                            ,job_profile_reference)),256)

where 1=1
and upper(grade) = 'GRADE_00'
and upper(contract_type) in ('FRA16','FRA15','FRA17') 
""")

// COMMAND ----------

// DBTITLE 1,Update date début contrat Expat
spark.sql("""
update hr.contract set 
 contract_start_date = '2022-01-01'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,'2022-01-01'
                                                   ,contract_end_date
                                                   ,contract_type)),256)
                                                             
,contract_dates_code = sha2(getconcatenedstring(array('2022-01-01'
                                                      ,contract_end_date
                                                      ,contract_type)),256)
                                                      
where 1=1
and france_payroll_id = '060152' 
and contract_start_date = '2018-05-23'


""")

spark.sql("""
update hr.contract set 
 contract_start_date = '2022-01-01'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,'2022-01-01'
                                                   ,contract_end_date
                                                   ,contract_type)),256)
                                                             
,contract_dates_code = sha2(getconcatenedstring(array('2022-01-01'
                                                      ,contract_end_date
                                                      ,contract_type)),256)
                                                      
where 1=1
and france_payroll_id = '060154' 
and contract_start_date = '2014-06-02'


""")

// COMMAND ----------

// DBTITLE 1,Update Contract End 20220131 Snapshot
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-01-07'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-01-07'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-01-07')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-01-07'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20093706' 
and contract_start_date = '2021-11-16'
""")

spark.sql("""
update hr.contract set 
 contract_end_date = '2022-01-24'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-01-24'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-01-24')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-01-24'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20094667' 
and contract_start_date = '2021-10-01'
""")


spark.sql("""
update hr.contract set 
 contract_end_date = '2021-12-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-12-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-12-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-12-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00012030' 
and contract_start_date = '2011-02-01'
""")


/**************W00011076***************/
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-08-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-08-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-08-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-08-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00011076' 
and contract_start_date = '1994-03-28'
""")

/**************W00013617***************/
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-01-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-01-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-01-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-01-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00013617' 
and contract_start_date = '2017-05-09'
""")

/**************W00013636***************/
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-01-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-01-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-01-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-01-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00013636' 
and contract_start_date = '2014-01-16'
""")

/**************W00013843***************/
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-12-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-12-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-12-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-12-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00013843' 
and contract_start_date = '2014-01-02'
""")

/**************W00014249***************/
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-06-30'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-06-30'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-06-30')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-06-30'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00014249' 
and contract_start_date = '2015-01-05'
""")


/**************W00014461***************/
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-12-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-12-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-12-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-12-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00014461' 
and contract_start_date = '2016-10-01'
""")


/**************W00014826***************/
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-11-30'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-11-30'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-11-30')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-11-30'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00014826' 
and contract_start_date = '2017-10-01'
""")

/**************W20001094***************/
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-06-14'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-06-14'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-06-14')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-06-14'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20001094' 
and contract_start_date = '2017-10-01'
""")

/**************W20073698***************/
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-10-30'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-10-30'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-10-30')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-10-30'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20073698' 
and contract_start_date = '2018-05-14'
""")

/**************W20088630***************/
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-08-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-08-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-08-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-08-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20088630' 
and contract_start_date = '2020-06-01'
""")

/**************W20091371***************/
spark.sql("""
update hr.contract set 
 contract_end_date = '2021-08-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2021-08-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2021-08-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2021-08-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20091371' 
and contract_start_date = '2020-10-01'
""")

/**************W20094232***************/
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-01-07'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-01-07'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-01-07')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-01-07'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20094232' 
and contract_start_date = '2021-07-12'
""")

// COMMAND ----------

// DBTITLE 1,Snapshot 30/04 - Remove wrong contracts that moved to UK_PERM
/* W00006412 */
/* update previous record to current record for correct contract*/
spark.sql("""
update hr.contract

set
contract_end_date = '2022-04-17'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-04-17'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-04-17')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-04-17'
                                                      ,contract_type)),256)
,record_end_date = null
,current_record = true

where employee_id = 'W00006412' and contract_type <> 'UK_PERM' and date_add(record_end_date,1) = (select max(c2.record_start_date) from hr.contract c2 where c2.employee_id = 'W00006412' and c2.contract_type = 'UK_PERM')
""")
/* delete wrong contract*/
spark.sql("""
delete from hr.contract
where employee_id = 'W00006412' and contract_type = 'UK_PERM'
""")

/* W20000141 */
/* update previous record to current record for correct contract*/
spark.sql("""
update hr.contract

set
contract_end_date = '2022-04-30'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-04-30'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-04-30')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-04-30'
                                                      ,contract_type)),256)
,record_end_date = null
,current_record = true

where employee_id = 'W20000141' and contract_type <> 'UK_PERM' and date_add(record_end_date,1) = (select max(c2.record_start_date) from hr.contract c2 where c2.employee_id = 'W20000141' and c2.contract_type = 'UK_PERM')
""")
/* delete wrong contract*/
spark.sql("""
delete from hr.contract
where employee_id = 'W20000141' and contract_type = 'UK_PERM'
""")


// COMMAND ----------

// DBTITLE 1,JIRA - 296
spark.sql("""
update hr.contract set 
total_base_pay = 70449.23  
where 1=1
and france_payroll_id = '101617'
and total_base_pay = 80000
and effective_compensation_change_date = '2020-01-01'
and contract_start_date = '2018-08-20'
""")

// COMMAND ----------

// DBTITLE 1,JIRA - 210
spark.sql("""
delete from hr.contract where employee_id = 'W20093808' and contract_start_date = '2021-06-28'
""")

spark.sql("""
delete from hr.employee where employee_id = 'W20093808' and effective_organization_change_date = '2021-06-28'
""")


// COMMAND ----------

// DBTITLE 1,JIRA - 234
/* change wrong contract start date*/
spark.sql("""
update hr.contract set 
 contract_start_date = '2021-01-04'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,'2021-01-04'
                                                   ,contract_end_date
                                                   ,contract_type)),256)
                                                             
,contract_dates_code = sha2(getconcatenedstring(array('2021-01-04'
                                                      ,contract_end_date
                                                      ,contract_type)),256)
                                                      
where 1=1
and france_payroll_id = '103121'
and contract_start_date = '2021-08-01'


""")

/* update latest end date */
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-03-31'
,info_dates_code =  sha2(getconcatenedstring(array( position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-03-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-03-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-03-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and france_payroll_id = '103121'
and contract_start_date = '2021-01-04'

""")

// COMMAND ----------

/* delete doublons */

spark.sql("""
delete from hr.employee
where france_payroll_id = '023253' 
and birth_name is null                                       
""")


// COMMAND ----------

/*update les doublons de hr.contract*/

val by_record_start_date_contract = Window.partitionBy("france_payroll_id").orderBy($"record_start_date".desc)
val by_record_and_payroll_contract = Window.partitionBy("france_payroll_id","record_start_date").orderBy($"record_creation_date".desc,$"record_modification_date".desc)


val double_records_contract = spark.sql("""select * from hr.contract
                                  where employee_id in(
'W2001001','W02001001',
'W2001003','W02001003',
'W2001005','W02001005',
'W2001007','W02001007',
'W2001013','W02001013',
'W2001014','W02001014',
'W2001015','W02001015',
'W2001017','W02001017',
'W2001021','W02001021',
'W2001023','W02001023',
'W2001024','W02001024',
'W2001026','W02001026',
'W2001032','W02001032',
'W2001033','W02001033',
'W2001035','W02001035',
'W2001036','W02001036',
'W2001042','W02001042',
'W2001046','W02001046',
'W2001048','W02001048',
'W2001051','W02001051',
'W20098592','W19014093')
                                  """)

                            .withColumn("double_records",rank() over by_record_and_payroll_contract)
                            .filter($"double_records" =!= "1")
                            .drop("double_records")

double_records_contract.createOrReplaceTempView("vw_double_records_contract")





val sub_hr_contract = spark.sql("""select * from hr.contract
                                  where employee_id in (
'W2001001','W02001001',
'W2001003','W02001003',
'W2001005','W02001005',
'W2001007','W02001007',
'W2001013','W02001013',
'W2001014','W02001014',
'W2001015','W02001015',
'W2001017','W02001017',
'W2001021','W02001021',
'W2001023','W02001023',
'W2001024','W02001024',
'W2001026','W02001026',
'W2001032','W02001032',
'W2001033','W02001033',
'W2001035','W02001035',
'W2001036','W02001036',
'W2001042','W02001042',
'W2001046','W02001046',
'W2001048','W02001048',
'W2001051','W02001051')
                                  """)
                            .withColumn("double_records",rank() over by_record_and_payroll_contract)
                            .filter($"double_records" === "1")
                            .drop("double_records")
                            .withColumn("version_number",rank() over by_record_start_date_contract)
                            .withColumn("contract_key",when(length($"employee_id") === 8,regexp_replace($"contract_key","W","W0")).otherwise($"contract_key"))
                            .withColumn("employee_id",when(length($"employee_id") === 8,regexp_replace($"employee_id","W","W0")).otherwise($"employee_id"))
                            .withColumn("employee_code",when(length($"employee_id") === 8,sha2(concat_ws("|",$"employee_id",$"france_payroll_id"),256)).otherwise($"employee_code"))
                            .withColumn("record_end_date",when($"record_end_date".isNull && $"version_number" =!= "1",lag($"record_start_date"-1,1) over by_record_start_date_contract).otherwise($"record_end_date"))
                            .withColumn("current_record",when($"record_end_date".isNotNull && $"current_record" === true, false).otherwise($"current_record"))
                            .drop("version_number")


sub_hr_contract.createOrReplaceTempView("vw_sub_hr_contract")


val sub_hr_contract_particulier = spark.sql("""select * from hr.contract
                                  where employee_id in ('W20098592','W19014093')
                                  """)
                            .withColumn("double_records",rank() over by_record_and_payroll_contract)
                            .filter($"double_records" === "1")
                            .drop("double_records")
                            .withColumn("version_number",rank() over by_record_start_date_contract)
                            .withColumn("contract_key",when($"version_number" =!= "1" && $"employee_id" =!= "W19014093",regexp_replace($"contract_key","W20098592","W19014093")).otherwise($"contract_key"))
                            .withColumn("employee_id",when($"version_number" =!= "1" && $"employee_id" =!= "W19014093",regexp_replace($"employee_id","W20098592","W19014093")).otherwise($"employee_id"))
                            .withColumn("employee_code",when($"version_number" =!= "1",sha2(concat_ws("|",$"employee_id",$"france_payroll_id"),256)).otherwise($"employee_code"))
                            .withColumn("record_end_date",when($"record_end_date".isNull && $"version_number" =!= "1",lag($"record_start_date"-1,1) over by_record_start_date_contract).otherwise($"record_end_date"))
                            .withColumn("current_record",when($"record_end_date".isNotNull && $"current_record" === true, false).otherwise($"current_record"))
                            .drop("version_number")


sub_hr_contract_particulier.createOrReplaceTempView("vw_sub_hr_contract_particulier")



val delete_doubles_hr_contract = spark.sql("""

  MERGE INTO hr.contract AS c
  USING vw_double_records_contract AS v
  ON c.france_payroll_id = v.france_payroll_id AND c.record_start_date = v.record_start_date AND c.record_modification_date = v.record_modification_date
                            
  WHEN MATCHED THEN
  DELETE 

""")




val id_corrected_hr_contract = spark.sql("""

  MERGE INTO hr.contract AS c
  USING vw_sub_hr_contract AS v
  ON c.france_payroll_id = v.france_payroll_id AND c.record_start_date = v.record_start_date AND c.record_modification_date = v.record_modification_date
                            
  WHEN MATCHED THEN
  UPDATE SET contract_key = v.contract_key,
             employee_code = v.employee_code,
             employee_id = v.employee_id,
             current_record = v.current_record,
             record_end_date = v.record_end_date

""")


val id_corrected_hr_contract_particulier = spark.sql("""

  MERGE INTO hr.contract AS c
  USING vw_sub_hr_contract_particulier AS v
  ON c.france_payroll_id = v.france_payroll_id AND c.record_start_date = v.record_start_date AND c.record_modification_date = v.record_modification_date
                            
  WHEN MATCHED THEN
  UPDATE SET contract_key = v.contract_key,
             employee_code = v.employee_code,
             employee_id = v.employee_id,
             current_record = v.current_record,
             record_end_date = v.record_end_date

""")



// COMMAND ----------


/*update les doublons de hr.employee*/

val by_record_start_date_emp = Window.partitionBy("france_payroll_id").orderBy($"record_start_date".desc)
val by_record_and_payroll_emp = Window.partitionBy("france_payroll_id","record_start_date").orderBy($"record_creation_date".desc,$"record_modification_date".desc)


val double_records_employee = spark.sql("""select * from hr.employee
                                  where employee_id in(
'W2001001','W02001001',
'W2001003','W02001003',
'W2001005','W02001005',
'W2001007','W02001007',
'W2001013','W02001013',
'W2001014','W02001014',
'W2001015','W02001015',
'W2001017','W02001017',
'W2001021','W02001021',
'W2001023','W02001023',
'W2001024','W02001024',
'W2001026','W02001026',
'W2001032','W02001032',
'W2001033','W02001033',
'W2001035','W02001035',
'W2001036','W02001036',
'W2001042','W02001042',
'W2001046','W02001046',
'W2001048','W02001048',
'W2001051','W02001051',
'W20098592','W19014093')
                                  """)
                            .withColumn("double_records",rank() over by_record_and_payroll_emp)
                            .filter($"double_records" =!= "1")
                            .drop("double_records")

double_records_employee.createOrReplaceTempView("vw_double_records_employee")





val sub_hr_employee = spark.sql("""select * from hr.employee
                                  where employee_id in (
'W2001001','W02001001',
'W2001003','W02001003',
'W2001005','W02001005',
'W2001007','W02001007',
'W2001013','W02001013',
'W2001014','W02001014',
'W2001015','W02001015',
'W2001017','W02001017',
'W2001021','W02001021',
'W2001023','W02001023',
'W2001024','W02001024',
'W2001026','W02001026',
'W2001032','W02001032',
'W2001033','W02001033',
'W2001035','W02001035',
'W2001036','W02001036',
'W2001042','W02001042',
'W2001046','W02001046',
'W2001048','W02001048',
'W2001051','W02001051')
                                  """)
                            .withColumn("double_records",rank() over by_record_and_payroll_emp)
                            .filter($"double_records" === "1")
                            .drop("double_records")
                            .withColumn("version_number",rank() over by_record_start_date_emp)
                            .withColumn("employee_key",when(length($"employee_id") === 8,regexp_replace($"employee_key","W","W0")).otherwise($"employee_key"))
                            .withColumn("employee_id",when(length($"employee_id") === 8,regexp_replace($"employee_id","W","W0")).otherwise($"employee_id"))
                            .withColumn("employee_code",sha2(concat_ws("|",$"employee_id",$"france_payroll_id"),256))
                            .withColumn("record_end_date",when($"record_end_date".isNull && $"version_number" =!= "1",lag($"record_start_date"-1,1) over by_record_start_date_emp).otherwise($"record_end_date"))
                            .withColumn("current_record",when($"record_end_date".isNotNull && $"current_record" === true, false).otherwise($"current_record"))
                            .drop("version_number")


sub_hr_employee.createOrReplaceTempView("vw_sub_hr_employee")


val sub_hr_employee_particulier = spark.sql("""select * from hr.employee
                                  where employee_id in ('W20098592','W19014093')
                                  """)
                            .withColumn("double_records",rank() over by_record_and_payroll_emp)
                            .filter($"double_records" === "1")
                            .drop("double_records")
                            .withColumn("version_number",rank() over by_record_start_date_emp)
                            .withColumn("employee_key",when($"employee_id" =!= "W19014093",regexp_replace($"employee_key","W20098592","W19014093")).otherwise($"employee_key"))
                            .withColumn("employee_id",when($"employee_id" =!= "W19014093",regexp_replace($"employee_id","W20098592","W19014093")).otherwise($"employee_id"))
                            .withColumn("employee_code",sha2(concat_ws("|",$"employee_id",$"france_payroll_id"),256))
                            .withColumn("record_end_date",when($"record_end_date".isNull && $"version_number" =!= "1",lag($"record_start_date"-1,1) over by_record_start_date_emp).otherwise($"record_end_date"))
                            .withColumn("current_record",when($"record_end_date".isNotNull && $"current_record" === true, false).otherwise($"current_record"))
                            .drop("version_number")


sub_hr_employee_particulier.createOrReplaceTempView("vw_sub_hr_employee_particulier")



val delete_doubles_hr_employee = spark.sql("""

  MERGE INTO hr.employee AS c
  USING vw_double_records_employee AS v
  ON c.france_payroll_id = v.france_payroll_id AND c.record_start_date = v.record_start_date AND c.record_modification_date = v.record_modification_date
                            
  WHEN MATCHED THEN
  DELETE

""")




val id_corrected_hr_employee = spark.sql("""

  MERGE INTO hr.employee AS c
  USING vw_sub_hr_employee AS v
  ON c.france_payroll_id = v.france_payroll_id AND c.record_start_date = v.record_start_date AND c.record_modification_date = v.record_modification_date
                            
  WHEN MATCHED THEN
  UPDATE SET employee_key = v.employee_key,
             employee_code = v.employee_code,
             employee_id = v.employee_id,
             current_record = v.current_record,
             record_end_date = v.record_end_date

""")


val id_corrected_hr_employee_particulier = spark.sql("""

  MERGE INTO hr.employee AS c
  USING vw_sub_hr_employee_particulier AS v
  ON c.france_payroll_id = v.france_payroll_id AND c.record_start_date = v.record_start_date AND c.record_modification_date = v.record_modification_date
                            
  WHEN MATCHED THEN
  UPDATE SET employee_key = v.employee_key,
             employee_code = v.employee_code,
             employee_id = v.employee_id,
             current_record = v.current_record,
             record_end_date = v.record_end_date

""")






// COMMAND ----------

// DBTITLE 1,20220608 - Update Contract End Date - Mutation Externe
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-04-30'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-04-30'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-04-30')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-04-30'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20074439' 
and contract_start_date = '2018-05-09'
""")

spark.sql("""
update hr.contract set 
 contract_end_date = '2022-04-30'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-04-30'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-04-30')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-04-30'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W02001015' 
and contract_start_date = '2018-10-08'
""")

spark.sql("""
update hr.contract set 
 contract_end_date = '2022-04-30'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-04-30'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-04-30')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-04-30'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20080887' 
and contract_start_date = '2019-04-01'
""")

spark.sql("""
update hr.contract set 
 contract_end_date = '2022-04-11'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-04-11'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-04-11')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-04-11'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00012650' 
and contract_start_date = '2010-09-01'
""")

spark.sql("""
update hr.contract set 
 contract_end_date = '2022-04-10'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-04-10'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-04-10')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-04-10'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20075074' 
and contract_start_date = '2018-05-24'
""")

spark.sql("""
update hr.contract set 
 contract_end_date = '2022-03-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-03-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-03-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-03-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20090056' 
and contract_start_date = '2020-05-04'
""")

spark.sql("""
update hr.contract set 
 contract_end_date = '2022-03-31'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-03-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-03-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-03-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20001814' 
and contract_start_date = '2018-04-01'
""")

// COMMAND ----------

// DBTITLE 1,20220608 - Update Cost Center
spark.sql("""
update hr.employee
set cost_center_code = 'X330E200'
  ,company_id = 'F03'
  ,code_establishment = 'FCHE'
  ,code_direction = 'DIR30'
  ,code_department = 'R081200'
  ,legal_organization_code = 'b4b0a99338578d505d2e38b2fbd357ed34c36eafe78e0e08b2161c8fe4fdd5a7'
  ,operational_organization_code = '92023aad09e0563237e28143f0a60220639cbb991cf20df219d95068d1260bcf'
  ,local_pb_hierarchy_name = null
                                                              
where employee_id = 'W00047557' and cost_center_code = '7041'
""")

// COMMAND ----------

// DBTITLE 1,20220608 - Update Contract Type - Expat
spark.sql("""
update hr.contract set 
contract_type = 'FRA17',
contract_code = sha2(getconcatenedstring(array('FRA17'               
                                                     ,worker_type
                                                     ,collective_agreement_reference
                                                     ,collective_agreement_group
                                                     ,collective_agreement_level
                                                     ,coefficient_label
                                                     )),256),
                            
info_dates_code = sha2(getconcatenedstring(array(position_start_date
                                                ,continous_service_date
                                                ,contract_start_date
                                                ,contract_end_date
                                                ,'FRA17'
                                                 )),256),
                            
contract_dates_code = sha2(getconcatenedstring(array(contract_start_date
                                                    ,contract_end_date
                                                    ,'FRA17'
                                                  )),256),
                                                             
contract_type_code = sha2('FRA17' ,256),
contract_type_label = 'Détaché à l''étranger (CDI)'



where 1=1
and employee_id in (
'W00011607'
,'W00014068'
,'W00014379'
,'W00014913'
,'W00015340'
,'W20000330'
,'W20001332'
)
and contract_type = 'FRA15'
""")


spark.sql("""
update hr.contract set 
contract_type = 'FRA15',
contract_code = sha2(getconcatenedstring(array('FRA15'               
                                                     ,worker_type
                                                     ,collective_agreement_reference
                                                     ,collective_agreement_group
                                                     ,collective_agreement_level
                                                     ,coefficient_label
                                                     )),256),
                            
info_dates_code = sha2(getconcatenedstring(array(position_start_date
                                                ,continous_service_date
                                                ,contract_start_date
                                                ,contract_end_date
                                                ,'FRA15'
                                                 )),256),
                            
contract_dates_code = sha2(getconcatenedstring(array(contract_start_date
                                                    ,contract_end_date
                                                    ,'FRA15'
                                                  )),256),
                                                             
contract_type_code = sha2('FRA15' ,256),
contract_type_label = 'Contrat à durée indéterminée (CDI)'



where 1=1
and employee_id in (
'W00012051'
,'W00012801'
)
and contract_type = 'FRA17'
""")

// COMMAND ----------

// DBTITLE 1,JIRA 412 - Mise a jour csp
// MAGIC %sql
// MAGIC 
// MAGIC update hr.contract 
// MAGIC set csp=upper(hr.contract.csp),csp_code=sha2(upper(hr.contract.csp),256)
// MAGIC where 
// MAGIC   csp in ('AMT','ASS','CAD','DMS','ENQ','EQU','ONQ','OQU','PEN','STA')

// COMMAND ----------

// DBTITLE 1,20220613 - Correction doublon chargement
spark.sql("""
update hr.contract
set
  date_raw_load_file = '2022-06-02'
  ,filename = 'getworkers_20220602_FULL_PROD_20220603_0123.csv'
  ,curated_ingested_date = '2022-06-02'
  ,record_start_date = '2022-06-02'
  ,record_creation_date = '2022-06-03T00:13:04.858+0000'
where
  employee_id = 'W20003132'
  and filename = 'getworkers_20220603_FULL_PROD_20220603_0123.csv'
""")



// COMMAND ----------

// DBTITLE 1,20220622 - Update Contract HRA ID - 1
/*update les doublons de hr.contract*/

val by_record_start_date_contractid = Window.partitionBy("employee_id").orderBy($"record_start_date".desc)
val by_record_and_payroll_contractid = Window.partitionBy("employee_id","record_start_date").orderBy($"record_creation_date".desc,$"record_modification_date".desc)



val sub_hr_contract_20220622 = spark.sql("""select * from hr.contract
                                  where employee_id in ('W00018057')
                                  """)
                            .withColumn("double_records",rank() over by_record_and_payroll_contractid)
                            .filter($"double_records" === "1")
                            .drop("double_records")
                            .withColumn("version_number",rank() over by_record_start_date_contractid)
                            .withColumn("france_payroll_id",substring($"employee_id",2,8))
                            .withColumn("contract_key",concat_ws("|",$"employee_id",$"france_payroll_id"))
                            .withColumn("employee_code",sha2(concat_ws("|",$"employee_id",$"france_payroll_id"),256))
                            .withColumn("record_end_date",when($"record_end_date".isNull && $"version_number" =!= "1",lag($"record_start_date"-1,1) over by_record_start_date_contractid).otherwise($"record_end_date"))
                            .withColumn("current_record",when($"record_end_date".isNotNull && $"current_record" === true, false).otherwise($"current_record"))
                            .drop("version_number")


sub_hr_contract_20220622.createOrReplaceTempView("vw_sub_hr_contract_20220622")




val id_corrected_hr_contract_20220622 = spark.sql("""

  MERGE INTO hr.contract AS c
  USING vw_sub_hr_contract_20220622 AS v
  ON c.employee_id = v.employee_id AND c.record_start_date = v.record_start_date AND c.record_modification_date = v.record_modification_date
                            
  WHEN MATCHED THEN
  UPDATE SET contract_key = v.contract_key,
             employee_code = v.employee_code,
             france_payroll_id = v.france_payroll_id,
             current_record = v.current_record,
             record_end_date = v.record_end_date

""")



// COMMAND ----------

// DBTITLE 1,20220622 - Update Employee HRA ID - 1
val by_record_start_date_empid = Window.partitionBy("employee_id").orderBy($"record_start_date".desc)
val by_record_and_payroll_empid = Window.partitionBy("employee_id","record_start_date").orderBy($"record_creation_date".desc,$"record_modification_date".desc)


val sub_hr_employee_20220622 = spark.sql("""select * from hr.employee
                                  where employee_id in ('W00018057')
                                  """)
                            .withColumn("double_records",rank() over by_record_and_payroll_empid)
                            .filter($"double_records" === "1")
                            .drop("double_records")
                            .withColumn("version_number",rank() over by_record_start_date_empid)
                            .withColumn("france_payroll_id",substring($"employee_id",2,8))
                            .withColumn("employee_key",concat_ws("|",$"employee_id",$"france_payroll_id"))
                            .withColumn("employee_code",sha2(concat_ws("|",$"employee_id",$"france_payroll_id"),256))
                            .withColumn("record_end_date",when($"record_end_date".isNull && $"version_number" =!= "1",lag($"record_start_date"-1,1) over by_record_start_date_empid).otherwise($"record_end_date"))
                            .withColumn("current_record",when($"record_end_date".isNotNull && $"current_record" === true, false).otherwise($"current_record"))
                            .drop("version_number")


sub_hr_employee_20220622.createOrReplaceTempView("vw_sub_hr_employee_20220622")

val id_corrected_hr_employee_20220622 = spark.sql("""

  MERGE INTO hr.employee AS c
  USING vw_sub_hr_employee_20220622 AS v
  ON c.employee_id = v.employee_id AND c.record_start_date = v.record_start_date AND c.record_modification_date = v.record_modification_date
                            
  WHEN MATCHED THEN
  UPDATE SET employee_key = v.employee_key,
             employee_code = v.employee_code,
             france_payroll_id = v.france_payroll_id,
             current_record = v.current_record,
             record_end_date = v.record_end_date

""")


// COMMAND ----------

// DBTITLE 1,20220622 - Delete duplicate employee id
spark.sql("""

delete from hr.employee where employee_id in (
'W20100310'
,'W20100394'
,'W20100395'
,'W20100424'
,'W20100480'
,'W20100516'
,'W20100520'
,'W20100521'
,'W20100530'
,'W20100541'
,'W20100573'
,'W20100574'
,'W20100579'
,'W20100581'
,'W20100653'
,'W20100679'
,'W20100702'
,'W20100726'
,'W20100751'
,'W20100752'
,'W20100758'
,'W20100773'
,'W20100804'
,'W20100893'
,'W20100911'
,'W20100913'
,'W20100925'
,'W20100926'
,'W20100956'
,'W20101001'
,'W20101006'
,'W20101039'
,'W20101040'
,'W20101042'
,'W20101043'
,'W20101111'
,'W20101125'
,'W20101126'
,'W20101127'
,'W20101128'
,'W20101129'
,'W20101133'
,'W20101168'
,'W20101175'
,'W20101184'
,'W20101187'
,'W20101252'
,'W20101256'
,'W20101261'
,'W20101299'
,'W20101365'
,'W20101388'
,'W20101406'
,'W20101409'
,'W20101410'
,'W20101440'
,'W20101467'
,'W20101472'
,'W20101512'
,'W20101513'
,'W20101515'
,'W20101518'
,'W20101519'
,'W20101540'
,'W20101545'
,'W20101547'
,'W20101634'
)
and france_payroll_id <> right(employee_id,8)
and record_creation_date >= '2022-04-01'
""")


spark.sql("""

delete from hr.contract where employee_id in (
'W20100310'
,'W20100394'
,'W20100395'
,'W20100424'
,'W20100480'
,'W20100516'
,'W20100520'
,'W20100521'
,'W20100530'
,'W20100541'
,'W20100573'
,'W20100574'
,'W20100579'
,'W20100581'
,'W20100653'
,'W20100679'
,'W20100702'
,'W20100726'
,'W20100751'
,'W20100752'
,'W20100758'
,'W20100773'
,'W20100804'
,'W20100893'
,'W20100911'
,'W20100913'
,'W20100925'
,'W20100926'
,'W20100956'
,'W20101001'
,'W20101006'
,'W20101039'
,'W20101040'
,'W20101042'
,'W20101043'
,'W20101111'
,'W20101125'
,'W20101126'
,'W20101127'
,'W20101128'
,'W20101129'
,'W20101133'
,'W20101168'
,'W20101175'
,'W20101184'
,'W20101187'
,'W20101252'
,'W20101256'
,'W20101261'
,'W20101299'
,'W20101365'
,'W20101388'
,'W20101406'
,'W20101409'
,'W20101410'
,'W20101440'
,'W20101467'
,'W20101472'
,'W20101512'
,'W20101513'
,'W20101515'
,'W20101518'
,'W20101519'
,'W20101540'
,'W20101545'
,'W20101547'
,'W20101634'
)
and france_payroll_id <> right(employee_id,8)
and record_creation_date >= '2022-04-01'
""")

// COMMAND ----------

// DBTITLE 1,20220705 - Duplicate ID
spark.sql("""

delete from hr.employee where
france_payroll_id in
(
'20003577'
,'20100703'
,'106854'
,'106921'
,'106910'
,'106902'
,'106905'
,'106935'
,'20101642024177'
)
and record_creation_date >= '2022-04-01'
""")


spark.sql("""

delete from hr.contract where
france_payroll_id in
(
'20003577'
,'20100703'
,'106854'
,'106921'
,'106910'
,'106902'
,'106905'
,'106935'
,'20101642024177'
)
and record_creation_date >= '2022-04-01'
""")

// COMMAND ----------

// DBTITLE 1,20220705 - Mise à jour date de fin de contrat

spark.sql("""
update hr.contract set 
 contract_end_date = '2022-06-14'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-14'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-14')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-14'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W00011729' 
and contract_start_date = '2012-01-01'
""")


spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-17'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-17'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-17')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-17'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W00012083'
and contract_start_date = '2006-04-03'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-03'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-03'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-03')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-03'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W00012900'
and contract_start_date = '2011-03-28'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-05'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-05'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-05')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-05'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W00012995'
and contract_start_date = '2011-07-25'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-12'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-12'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-12')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-12'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W00013242'
and contract_start_date = '2012-04-02'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-24'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-24'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-24')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-24'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20000751'
and contract_start_date = '2017-01-09'
""")


spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-03'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-03'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-03')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-03'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W00014951'
and contract_start_date = '2017-12-01'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-19'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-19'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-19')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-19'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20079507'
and contract_start_date = '2019-02-01'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-14'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-14'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-14')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-14'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20087520'
and contract_start_date = '2019-12-01'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-07'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-07'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-07')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-07'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20077697'
and contract_start_date = '2020-04-01'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-06'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-06'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-06')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-06'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20090402'
and contract_start_date = '2020-06-01'
""")


spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-09'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-09'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-09')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-09'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20002022'
and contract_start_date = '2020-02-17'
""")



spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-17'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-17'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-17')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-17'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W00014570'
and contract_start_date = '2018-09-01'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-15'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-15'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-15')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-15'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20091220'
and contract_start_date = '2018-09-01'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-13'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-13'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-13')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-13'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W00013067'
and contract_start_date = '2017-10-01'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-10'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-10'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-10')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-10'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20083380'
and contract_start_date = '2021-08-01'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-24'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-24'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-24')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-24'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20098547'
and contract_start_date = '2021-12-27'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-03'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-03'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-03')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-03'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20099921'
and contract_start_date = '2022-03-04'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-03'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-03'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-03')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-03'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20099993'
and contract_start_date = '2022-03-01'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-11'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-11'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-11')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-11'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20094344'
and contract_start_date = '2022-03-27'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-11'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-11'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-11')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-11'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20094344'
and contract_start_date = '2022-03-27'
""")

spark.sql("""
update hr.contract set
 contract_end_date = '2022-06-27'
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-06-27'
                                                   ,contract_type)),256)
                                                            
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-06-27')),256)
                                                 
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-06-27'
                                                      ,contract_type)),256)
                                                     
where 1=1
and employee_id = 'W20101827'
and contract_start_date = '2022-06-06'
""")

// COMMAND ----------

spark.sql("""

delete from hr.employee where
france_payroll_id in
(
'10550320100788'
)
and record_creation_date >= '2022-04-01'
""")


spark.sql("""

delete from hr.contract where
france_payroll_id in
(
'10550320100788'

)
and record_creation_date >= '2022-04-01'
""")

// COMMAND ----------

/*update les doublons de hr.contract*/

val by_record_start_date_contractid = Window.partitionBy("employee_id").orderBy($"record_start_date".desc)
val by_record_and_payroll_contractid = Window.partitionBy("employee_id","record_start_date").orderBy($"record_creation_date".desc,$"record_modification_date".desc)



val sub_hr_contract_20220715 = spark.sql("""select * from hr.contract
                                  where employee_id in ('W00014158')
                                  """)
                            .withColumn("double_records",rank() over by_record_and_payroll_contractid)
                            .filter($"double_records" === "1")
                            .drop("double_records")
                            .withColumn("version_number",rank() over by_record_start_date_contractid)
                            .withColumn("france_payroll_id",lit("021198"))
                            .withColumn("contract_key",concat_ws("|",$"employee_id",$"france_payroll_id"))
                            .withColumn("employee_code",sha2(concat_ws("|",$"employee_id",$"france_payroll_id"),256))
                            .withColumn("record_end_date",when($"record_end_date".isNull && $"version_number" =!= "1",lag($"record_start_date"-1,1) over by_record_start_date_contractid).otherwise($"record_end_date"))
                            .withColumn("current_record",when($"record_end_date".isNotNull && $"current_record" === true, false).otherwise($"current_record"))
                            .drop("version_number")


sub_hr_contract_20220715.createOrReplaceTempView("vw_sub_hr_contract_20220715")




val id_corrected_hr_contract_20220715 = spark.sql("""

  MERGE INTO hr.contract AS c
  USING vw_sub_hr_contract_20220715 AS v
  ON c.employee_id = v.employee_id AND c.record_start_date = v.record_start_date AND c.record_modification_date = v.record_modification_date
                            
  WHEN MATCHED THEN
  UPDATE SET contract_key = v.contract_key,
             employee_code = v.employee_code,
             france_payroll_id = v.france_payroll_id,
             current_record = v.current_record,
             record_end_date = v.record_end_date

""")


// COMMAND ----------

val by_record_start_date_empid = Window.partitionBy("employee_id").orderBy($"record_start_date".desc)
val by_record_and_payroll_empid = Window.partitionBy("employee_id","record_start_date").orderBy($"record_creation_date".desc,$"record_modification_date".desc)


val sub_hr_employee_20220715 = spark.sql("""select * from hr.employee
                                  where employee_id in ('W00014158')
                                  """)
                            .withColumn("double_records",rank() over by_record_and_payroll_empid)
                            .filter($"double_records" === "1")
                            .drop("double_records")
                            .withColumn("version_number",rank() over by_record_start_date_empid)
                            .withColumn("france_payroll_id",lit("021198"))
                            .withColumn("employee_key",concat_ws("|",$"employee_id",$"france_payroll_id"))
                            .withColumn("employee_code",sha2(concat_ws("|",$"employee_id",$"france_payroll_id"),256))
                            .withColumn("record_end_date",when($"record_end_date".isNull && $"version_number" =!= "1",lag($"record_start_date"-1,1) over by_record_start_date_empid).otherwise($"record_end_date"))
                            .withColumn("current_record",when($"record_end_date".isNotNull && $"current_record" === true, false).otherwise($"current_record"))
                            .drop("version_number")


sub_hr_employee_20220715.createOrReplaceTempView("vw_sub_hr_employee_20220715")

val id_corrected_hr_employee_20220715 = spark.sql("""

  MERGE INTO hr.employee AS c
  USING vw_sub_hr_employee_20220715 AS v
  ON c.employee_id = v.employee_id AND c.record_start_date = v.record_start_date AND c.record_modification_date = v.record_modification_date
                            
  WHEN MATCHED THEN
  UPDATE SET employee_key = v.employee_key,
             employee_code = v.employee_code,
             france_payroll_id = v.france_payroll_id,
             current_record = v.current_record,
             record_end_date = v.record_end_date

""")


// COMMAND ----------

// DBTITLE 1,Photo 20220902 - suppression doublon
spark.sql("""

delete from hr.employee
where employee_id = 'W00018206' and france_payroll_id = '23303'
""")


spark.sql("""

delete from hr.contract
where employee_id = 'W00018206' and france_payroll_id = '23303'
""")


// COMMAND ----------

spark.sql("""
update hr.employee
set cost_center_code = 'X390ERH0'
  ,company_id = 'F03'
  ,code_establishment = 'FCHE'
  ,code_direction = 'DIR90EUR'
  ,code_department = 'R010100'
  ,legal_organization_code = '8c719ead9581c76ace3eee8b8f238c6946360cce5f54e7d7a546e3ee2340cdae'
  ,operational_organization_code = 'cf53b092ffaaf5ee88110f21c4ff6704175c3a4831b68f4ab4cabfef67324781'
  ,local_pb_hierarchy_name = 'DIRECTION EUROPE'
                                                              
where employee_id = 'W20079792' and cost_center_code = 'X235C530' and (effective_organization_change_date = '2022-07-04' or effective_organization_change_date = '2022-07-07')
""")

// COMMAND ----------

spark.sql("""
update hr.contract
set job_profile_reference = '09036'
  ,job_code = '168184aaec12672d36ccda40d63e0daa24a59db32022266a4d799e36ae8a8baf'
  ,job_title_code = 'aedb0ff795e8852498af565aed02d47b24726e1f52b047182349426a70476e42'
                                                              
where employee_id = 'W00011607' and job_profile_reference = '9036'
""")

// COMMAND ----------

// DBTITLE 1,2022-09-07 - Wrong Contract
spark.sql("""
update hr.contract set 
 contract_end_date = '2022-08-31'
,local_termination_reason = 'Départ mutation externe'
,mobility_out_code = sha2('Départ mutation externe',256)
,info_dates_code =  sha2(getconcatenedstring(array(position_start_date
                                                   ,continous_service_date
                                                   ,contract_start_date
                                                   ,'2022-08-31'
                                                   ,contract_type)),256)
                                                             
,in_out_dates_code = sha2(getconcatenedstring(array(original_hire_date
                                                  ,'2022-08-31')),256)
                                                  
,contract_dates_code = sha2(getconcatenedstring(array( contract_start_date
                                                      ,'2022-08-31'
                                                      ,contract_type)),256)
                                                      
where 1=1
and employee_id = 'W20095658' 
and contract_start_date = '2021-08-01'
and contract_end_date = '2021-07-31'

""")

// COMMAND ----------

// DBTITLE 1,JIRA - 479 - Correction Employee Code
spark.sql("""
update hr.contract set 
employee_code = sha2(getconcatenedstring(array(employee_id            
                                                     ,france_payroll_id
                                                     )),256)                          
where 1=1
and employee_id in (select distinct c1.employee_id from hr.contract c1 inner join hr.contract c2 on c1.employee_id = c2.employee_id and c1.france_payroll_id = c2.france_payroll_id
where c1.employee_code <> c2.employee_code)
""")

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
  spark.sql("OPTIMIZE hr.contract")

// COMMAND ----------

spark.sql("OPTIMIZE hr.employee")

// COMMAND ----------

spark.sql("OPTIMIZE hr.pay")

// COMMAND ----------

val read_records = 0 //count the number of read records
val inserted_records = 0 //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)