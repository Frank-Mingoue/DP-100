// Databricks notebook source
// DBTITLE 1,Include notebook containing common functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")
//sc.getExecutorStorageStatus.length - 1

// COMMAND ----------

// DBTITLE 1,Refresh delta table contract
if(spark.catalog.tableExists("hr.contract")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.contract")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Read Contract Data
// last version of each contract without retroactivity
val bycontract_start = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
  val df_contractstart_read = spark.table("hr.contract")
                                                .withColumn("rank_start",rank() over bycontract_start)
                                                .withColumn("contract_end_date",when($"contract_end_date".isNull ,to_date(lit("2999-12-31"))).otherwise($"contract_end_date"))
                                                .filter(col("rank_start")==="1")
                                                .distinct
df_contractstart_read.createOrReplaceTempView("vw_contractstart")

// COMMAND ----------

// DBTITLE 1,Retrieve new contract
val sqllastcontract = """
  select

    c.employee_code,c.employee_id,c.france_payroll_id,
    c.contract_start_date,c.contract_end_date,
    c.position_start_date,c.continous_service_date,c.contract_type,c.original_hire_date,

    c.date_raw_load_file,c.filepath,c.filename,c.curated_ingested_date

  from vw_contractstart c

  where exists (
    select 1 from vw_contractstart c2
    where c2.employee_code = c.employee_code
    and c2.contract_end_date > c.contract_start_date and c2.contract_end_date <= c.contract_end_date and c2.contract_start_date < c.contract_start_date
  )
"""
spark.sql(sqllastcontract).createOrReplaceTempView("vw_newcontract")

// COMMAND ----------

// DBTITLE 1,Retrieve previous contract to update
val sqlcontractold = """
  select

    c.employee_code,c.employee_id,c.france_payroll_id,
    c.contract_start_date,c.contract_end_date,
    c.position_start_date,c.continous_service_date,c.contract_type,c.original_hire_date,

    c.date_raw_load_file,c.filepath,c.filename,c.curated_ingested_date

  from vw_contractstart c

  where exists (
    select 1 from vw_contractstart c2
    where c2.employee_code = c.employee_code
    and c.contract_end_date > c2.contract_start_date and c.contract_end_date <= c2.contract_end_date and c.contract_start_date < c2.contract_start_date
  )
"""
spark.sql(sqlcontractold).createOrReplaceTempView("vw_oldcontract")

// COMMAND ----------

// DBTITLE 1,Build new contract data to update
val sqlcontractUpdate = """
  select

      c.employee_code,c.employee_id,c.france_payroll_id,
      c.contract_start_date,
      c.contract_end_date,
      date_sub(c2.contract_start_date,1) as new_contract_end_date,

      sha2(getconcatenedstring(array( c.position_start_date
          ,c.continous_service_date
          ,c.contract_start_date
          ,date_sub(c2.contract_start_date,1)
          ,c.contract_type
      )),256) as new_info_dates_code,

      sha2(getconcatenedstring(array(c.original_hire_date
        ,date_sub(c2.contract_start_date,1)
      )),256) as new_in_out_dates_code,

      sha2(getconcatenedstring(array( c.contract_start_date
        ,date_sub(c2.contract_start_date,1)
        ,c.contract_type
      )),256) as new_contract_dates_code,

      c.date_raw_load_file,c.filepath,c.filename,c.curated_ingested_date

  from vw_oldcontract c

  inner join vw_newcontract c2
  on c.employee_code = c2.employee_code
"""
val df_contract_update = spark.sql(sqlcontractUpdate)
df_contract_update.createOrReplaceTempView("vw_contractUpdate")

// COMMAND ----------

// DBTITLE 1,Add log to reject table in monitoring db
val jdbcurl = getMonitoringSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Build Logs to write on Monitoring Database
val sqlMonitoring = """
  select 
             'HR' as functional_domain
             ,'load_refined_contract_update' as pipeline_name
             ,current_timestamp() as event_date_time
             ,'FN_Contract_End_Date' as rejects_code
             ,concat('Udpate contract end date to ',date_format(new_contract_end_date,'yyyy-MM-dd'),' for employee = ',employee_id,' and contract start date = ',date_format(contract_start_date,'yyyy-MM-dd')) as message
  from vw_contractUpdate
"""
val df_monitoringLog = spark.sql(sqlMonitoring)

// COMMAND ----------

// DBTITLE 1,Write logs to monitoring database
//df_monitoringLog.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","1000").jdbc(jdbcurl, "monitoring.rejects_logs", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Update previous contract end date to avoid multiple active contracts
/*spark.sql("""
merge into hr.contract c1

using vw_contractUpdate c2
on c1.employee_code = c2.employee_code
and C1.contract_start_date = c2.contract_start_date

when matched then
  update set c1.contract_end_date = c2.new_contract_end_date,
             c1.info_dates_code = c2.new_info_dates_code,
             c1.in_out_dates_code = c2.new_in_out_dates_code,
             c1.contract_dates_code = c2.new_contract_dates_code,
             c1.record_modification_date = current_timestamp()
""")*/

// COMMAND ----------

// DBTITLE 1,Get last version for employees' contracts
val bycontract_start = Window.partitionBy("employee_id","france_payroll_id","contract_start_date").orderBy($"record_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val bylastcontract =   Window.partitionBy("employee_id","france_payroll_id").orderBy($"contract_start_date".desc,$"date_raw_load_file".desc,$"record_modification_date".desc)
val df_contractstart_bis_read = spark.table("hr.contract")
                                                .withColumn("rank_start",rank() over bycontract_start)
                                                .withColumn("contract_end_date",when($"contract_end_date".isNull ,to_date(lit("2999-12-31"))).otherwise($"contract_end_date"))
                                                .filter(col("rank_start")==="1")
                                                .withColumn("next_contract_start",lag($"contract_start_date", 1, null).over(bylastcontract))
                                                .withColumn("new_contract_end_date", date_add($"next_contract_start", -1))
                                                .distinct
df_contractstart_bis_read.createOrReplaceTempView("vw_contractstart_bis")

// COMMAND ----------

// DBTITLE 1,Employees and contracts to update for contract end date
spark.sql("""
select employee_code,
       employee_id,
       france_payroll_id,
       contract_start_date,
       contract_end_date,
       new_contract_end_date,
       
        sha2(getconcatenedstring(array(position_start_date
                                      ,continous_service_date
                                      ,contract_start_date
                                      ,new_contract_end_date
                                      ,contract_type
                                  )),256) as new_info_dates_code,

      sha2(getconcatenedstring(array(original_hire_date
                                    ,new_contract_end_date
                                     )),256) as new_in_out_dates_code,

      sha2(getconcatenedstring(array( contract_start_date
                                     ,new_contract_end_date
                                     ,contract_type
      )),256) as new_contract_dates_code
       
from vw_contractstart_bis
where contract_end_date>new_contract_end_date
""").createOrReplaceTempView("vw_contractUpdateBis")

// COMMAND ----------

// DBTITLE 1,Build Logs to write on Monitoring Database
val sqlMonitoring_Bis = """
  select 
             'HR' as functional_domain
             ,'load_refined_contract_update' as pipeline_name
             ,current_timestamp() as event_date_time
             ,'FN_Contract_End_Date' as rejects_code
             ,concat('Udpate contract end date to ',date_format(new_contract_end_date,'yyyy-MM-dd'),' for employee = ',employee_id,' and contract start date = ',date_format(contract_start_date,'yyyy-MM-dd')) as message
  from vw_contractUpdateBis
"""
val df_monitoringLogBis = spark.sql(sqlMonitoring_Bis)

// COMMAND ----------

// DBTITLE 1,Write logs to monitoring database
df_monitoringLogBis.coalesce(1).write.mode(SaveMode.Append).option("tablock","true").option("batchsize","1000").jdbc(jdbcurl, "monitoring.rejects_logs", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Update Contracts with the new Contract End Date
spark.sql("""
merge into hr.contract c1

using vw_contractUpdateBis c2
on c1.employee_code = c2.employee_code
and C1.contract_start_date = c2.contract_start_date

when matched then
  update set c1.contract_end_date = c2.new_contract_end_date,
             c1.info_dates_code = c2.new_info_dates_code,
             c1.in_out_dates_code = c2.new_in_out_dates_code,
             c1.contract_dates_code = c2.new_contract_dates_code,
             c1.record_modification_date = current_timestamp()
""")

// COMMAND ----------

// DBTITLE 1,Script to optimize delta file storage
spark.sql("OPTIMIZE hr.contract")

// COMMAND ----------

val read_records = 0 //count the number of read records
val inserted_records = 0 //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

spark.sql("clear cache")

// COMMAND ----------

dbutils.notebook.exit(return_value)