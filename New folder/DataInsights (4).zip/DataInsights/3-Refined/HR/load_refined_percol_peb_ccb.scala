// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include Notebook Containing Common Functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Configurations
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760 ")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Test if the source path exists
if(spark.catalog.tableExists("pay.percol_peb_ccb")) 
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.percol_peb_ccb")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get Last Partition File loaded
val partition_percol_peb_ccb = get_last_partition_file("/pay/business/percol_peb_ccb",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source after test if it exists and count number of read records
val bypercol_peb_ccb = Window.partitionBy("matricule_hra","matricule_workday","year").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_percol_peb_ccb_read = spark.table("pay.percol_peb_ccb")
                                       // .filter("date_raw_load_file = '" + partition_percol_peb_ccb + "'")
                                        .withColumn("year", regexp_replace(col("periode"), "-","").substr(0, 4))   //read parquet file
                                        .withColumn("rank",rank() over bypercol_peb_ccb).filter(col("rank")==="1") //path to read parquet files

df_percol_peb_ccb_read.cache()  //put the dataframe on the cache
df_percol_peb_ccb_read.createOrReplaceTempView("vw_percol_peb_ccb") // create a temp view

// COMMAND ----------

// DBTITLE 1,Refresh table percol_peb_ccb
try {
    spark.sql("FSCK REPAIR TABLE hr.percol_peb_ccb")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }

// COMMAND ----------

// DBTITLE 1,Get existing year and date_raw_load_file
val percol_peb_ccb_table = DeltaTable.forName("hr.percol_peb_ccb").toDF.select("year","date_raw_load_file").distinct
percol_peb_ccb_table.createOrReplaceTempView("vw_percol_peb_ccb_table")

// COMMAND ----------

// DBTITLE 1,Query to select only job data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column

val query_source = """select distinct 
                            getconcatenedstring(array(pc.matricule_hra
                                                     ,pc.matricule_workday
                                                     ,pc.year
                                                           )) as percol_peb_ccb_key
                            ,pc.matricule_workday as employee_id
                            ,pc.matricule_hra as france_payroll_id
                            ,sha2(getconcatenedstring(array(pc.matricule_workday, pc.matricule_hra)),256) as employee_code
                            ,pc.nom as last_name
                            ,pc.prenom as first_name
                            ,pc.flag_amundi_per_col
                            ,pc.flag_amundi_peg
                            ,pc.flag_amundi_ccb
                            ,to_date(pc.periode) as period
                            ,pc.year
                            ,pc.filename
                            ,pc.date_raw_load_file
                            ,pc.version as version
                            ,pc.filepath
                            ,to_date(pc.curated_ingested_date) as curated_ingested_date
                            ,true as current_record
                            ,pc.date_raw_load_file as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(pc.nom,pc.prenom,pc.flag_amundi_per_col,pc.flag_amundi_peg,pc.flag_amundi_ccb)) as hashkey 
                           ,'""" + runid + """' as runid
                           ,lower(trim(split(pc.filepath,"/")[3])) as system_source
               from    vw_percol_peb_ccb pc
                       left join vw_percol_peb_ccb_table at on at.year = pc.year
               where   1=1
                       and     (pc.matricule_workday is not null or pc.matricule_hra is not null)
                       and     (pc.date_raw_load_file > at.date_raw_load_file or at.date_raw_load_file is null)
            """

// COMMAND ----------

// DBTITLE 1,Get query data
val df_results = spark.sql(query_source).cache
df_results.createOrReplaceTempView("vw_percol_peb_ccb_source")
val inserted_records = df_results.count().toInt //count the number of records to upsert

// COMMAND ----------

// DBTITLE 1,Delete old data
spark.sql( """DELETE FROM hr.percol_peb_ccb as t
WHERE EXISTS(
SELECT 1 FROM vw_percol_peb_ccb_source
WHERE t.year = vw_percol_peb_ccb_source.year)""")

// COMMAND ----------

// DBTITLE 1,Add new data
df_results.write.format("delta")
                .mode("append")
                .partitionBy("year")
                .saveAsTable("hr.percol_peb_ccb")

// COMMAND ----------

// DBTITLE 1,Script to optmize storage and read of delta files
spark.sql("OPTIMIZE hr.percol_peb_ccb")

// COMMAND ----------

// DBTITLE 1,Statistics on rows read and inserted
val read_records = df_percol_peb_ccb_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_percol_peb_ccb_read.unpersist
df_results.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.percol_peb_ccb 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)