// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include Notebook Containing Common Functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760 ")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Test if the source path exists
if(spark.catalog.tableExists("pay.politique_voiture_mobilite")) 
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.politique_voiture_mobilite")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get the last partition file loaded from Curated
val partition_politique_voiture_mobilite = get_last_partition_file("/pay/business/politique_voiture_mobilite",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source after test if it exists and count number of read records
val bypolitique_voiture_mobilite = Window.partitionBy("matricule_hra","periode").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_politique_voiture_mobilite_read = spark.table("pay.politique_voiture_mobilite")
                                                    //.filter("date_raw_load_file = '" + partition_politique_voiture_mobilite + "'")
                                                    .withColumn("period_month", regexp_replace(col("periode"), "-","").substr(0, 6))   //read parquet file
                                                    .withColumn("rank",rank() over bypolitique_voiture_mobilite).filter(col("rank")==="1") //path to read parquet files

df_politique_voiture_mobilite_read.cache()  //put the dataframe on the cache
df_politique_voiture_mobilite_read.createOrReplaceTempView("vw_car_mobility_policy") // create a temp view

// COMMAND ----------

// DBTITLE 1,Refresh table car_mobility_policy
try {
    spark.sql("FSCK REPAIR TABLE hr.car_mobility_policy")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }

// COMMAND ----------

// DBTITLE 1,Get Existing period_month and date_raw_load_file
val car_mobility_policy_table = DeltaTable.forName("hr.car_mobility_policy").toDF.select("period_month","date_raw_load_file").distinct
car_mobility_policy_table.createOrReplaceTempView("vw_car_mobility_policy_table")

// COMMAND ----------

// DBTITLE 1,Query to select only job data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column

val query_source = """select distinct
                             getconcatenedstring(array(cm.matricule_hra
                                                     ,cm.period_month
                                                           )) as car_mobility_policy_key
                            ,cm.matricule_hra as france_payroll_id
                            ,cm.nom as last_name
                            ,cm.prenom as first_name
                            ,cm.date_debut_avantage as benefits_start_date
                            ,cm.date_fin_avantage as benefits_end_date
                            ,cm.categorie_avantage as benefits_category
                            ,cm.type_avantage as benefits_type
                            ,to_date(cm.periode) as period
                            ,cm.period_month
                            ,cm.filename
                            ,cm.date_raw_load_file
                            ,cm.version as version
                            ,cm.filepath
                            ,to_date(cm.curated_ingested_date) as curated_ingested_date
                            ,true as current_record
                            ,cm.date_raw_load_file as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(cm.nom,cm.prenom,cm.date_debut_avantage,cm.date_fin_avantage,cm.categorie_avantage,cm.type_avantage)) as hashkey 
                           ,'""" + runid + """' as runid
                           ,lower(trim(split(cm.filepath,"/")[3])) as system_source
               from    vw_car_mobility_policy cm
                       left join vw_car_mobility_policy_table at on at.period_month = cm.period_month
               where   1=1
                       and      cm.matricule_hra is not null
                       and     (cm.date_raw_load_file > at.date_raw_load_file or at.date_raw_load_file is null)
            """

// COMMAND ----------

// DBTITLE 1,Read query data
val df_results = spark.sql(query_source).cache
df_results.createOrReplaceTempView("vw_car_mobility_policy_source")
val inserted_records = df_results.count().toInt //count the number of records to upsert

// COMMAND ----------

// DBTITLE 1,Delete old data
spark.sql( """DELETE FROM hr.car_mobility_policy as t
WHERE EXISTS(
SELECT 1 FROM vw_car_mobility_policy_source
WHERE t.period_month = vw_car_mobility_policy_source.period_month)""")

// COMMAND ----------

// DBTITLE 1,Add new data
df_results.write.format("delta")
                .mode("append")
                .partitionBy("period_month")
                .saveAsTable("hr.car_mobility_policy")

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE hr.car_mobility_policy")

// COMMAND ----------

// DBTITLE 1,Statistics on new data
val read_records = df_politique_voiture_mobilite_read.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_politique_voiture_mobilite_read.unpersist
df_results.unpersist

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.car_mobility_policy 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)