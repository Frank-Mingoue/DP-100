// Databricks notebook source
// DBTITLE 1,Get Parameters: load_date, runid
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include notebooks
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Optimize Spark Query
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
spark.conf.set("spark.databricks.delta.merge.repartitionBeforeWrite.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "30") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Refresh table recruitment.get_jobrequisitions
if(spark.catalog.tableExists("recruitment.get_jobrequisitions")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_jobrequisitions")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the windowing function in order to get the last job requisition sent by grouping by employee_id and sort by filename desc. then create the temp view
val byjob_req = Window.partitionBy("job_requisition_reference").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_job_req_read = spark.table("recruitment.get_jobrequisitions").where($"date_raw_load_file"===load_date)
                                                                    .withColumn("rank", rank().over(byjob_req))
                                                                    .where($"rank"===1)
                                                                    .distinct
df_job_req_read.createOrReplaceTempView("vw_job_req")


// COMMAND ----------

// DBTITLE 1,Refresh table recruitment.get_jobpostings
if(spark.catalog.tableExists("recruitment.get_jobpostings")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_jobpostings")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded
val partition_get_jobpostings = get_last_partition_file("/recruitment/workday/get_jobpostings",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Create the windowing function in order to get the last job posting sent by grouping by employee_id and sort by filename desc. then create the temp view
val byjob_postings = Window.partitionBy("job_requisition_reference", "job_posting_start_date","job_posting_site_reference").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_job_postings_read = spark.table("recruitment.get_jobpostings").where($"date_raw_load_file"===partition_get_jobpostings)
                                                                     .withColumn("rank", rank().over(byjob_postings))
                                                                     .where($"rank"===1)
                                                                     .distinct
df_job_postings_read.createOrReplaceTempView("vw_job_postings")

// COMMAND ----------

// DBTITLE 1,Refresh table recruitment.get_postings
if(spark.catalog.tableExists("recruitment.get_positions")) 
{ 
  try {
    spark.sql("MSCK REPAIR TABLE recruitment.get_positions")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded
val partition_get_positions = get_last_partition_file("/recruitment/workday/get_positions",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Create the windowing function in order to get the last job posting sent by grouping by employee_id and sort by filename desc. then create the temp view
val by_positions = Window.partitionBy("position_reference", "cost_center_reference").orderBy($"effective_date".desc, $"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_positions_read = spark.table("recruitment.get_positions").where($"date_raw_load_file"===partition_get_positions)
                                                                     .withColumn("rank", rank().over(by_positions))
                                                                     .withColumn("cost_center_reference_old",$"cost_center_reference")
                                                                     .withColumn("cost_center_reference",when(lower(substring($"cost_center_reference", 0, 2)) === "fr", expr("substring(cost_center_reference, 3, length(cost_center_reference))")))
                                                                    // .withColumn("cost_center_reference",when(lower(substring($"cost_center_reference",0,2)) === "fr",substring($"cost_center_reference",3,length($"cost_center_reference"))))
                                                                     .where($"rank"===1)
                                                                     .distinct
df_positions_read.createOrReplaceTempView("vw_positions")


// COMMAND ----------

// DBTITLE 1,Query to select only job requisition data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select distinct
                             getconcatenedstring(array(a.job_requisition_reference
                                                      ,a.recruiting_start_date
                                                      ,a.position_reference
                                                      ,a.primary_recruiter
                                                      ,b.job_posting_start_date
                                                      ,b.job_posting_site_reference
                                                      )) as job_requisition_key
                            ,sha2(getconcatenedstring(array(a.job_requisition_reference
                                                      ,a.recruiting_start_date
                                                      ,a.position_reference
                                                      )), 256) as job_requisition_code
                            ,a.job_requisition_reference
                            ,a.job_requisition_status
                            ,a.job_posting_title
                            ,a.recruiting_instruction_data
                            ,a.recruiting_start_date
                            ,a.target_hire_date
                            ,a.target_end_date
                            ,a.worker_type_reference
                            ,a.position_worker_type_reference
                            ,a.primary_location_reference
                            ,a.primary_location_label
                            ,a.primary_job_posting_location_reference
                            ,a.primary_job_posting_location_label
                            ,a.time_type_reference
                            ,a.position_reference
                            ,a.position_label
                            ,a.primary_recruiter
                            ,a.hiring_manager
                            ,a.effective_date
                            ,b.job_posting_start_date
                            ,b.job_posting_site_reference
                            ,null as job_contract_nature
                            ,p.earliest_hire_date
                            ,p.job_profile
                            ,p.job_category
                            ,p.job_family
                            ,p.cost_center_reference
                            ,p.cost_center
                            ,p.effective_date as effective_date_posting
                            ,a.filename
                            ,a.date_raw_load_file
                            ,a.version
                            ,a.filepath
                            ,a.curated_ingested_date
                            ,true as current_record
                            ,a.date_raw_load_file as record_start_date
                            ,null as record_end_date
                            ,current_timestamp() as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(a.job_requisition_status
                                                      ,a.job_posting_title
                                                      ,a.recruiting_instruction_data
                                                      ,a.target_hire_date
                                                      ,a.target_end_date
                                                      ,a.worker_type_reference
                                                      ,a.position_worker_type_reference
                                                      ,a.primary_location_reference
                                                      ,a.primary_location_label
                                                      ,a.primary_job_posting_location_reference
                                                      ,a.primary_job_posting_location_label
                                                      ,a.time_type_reference
                                                      ,a.position_label
                                                      ,a.hiring_manager
                                                      ,p.earliest_hire_date
                                                      ,p.job_profile
                                                      ,p.job_category
                                                      ,p.job_family
                                                      ,p.cost_center_reference
                                                      ,p.cost_center
                                                      ,p.effective_date
                                                      )) as hashkey
                            ,'""" + runid + """' as runid
                            ,lower(trim(split(a.filepath,"/")[3])) as system_source

                            from vw_job_req a
                            left join vw_job_postings b on (a.job_requisition_reference = b.job_requisition_reference)
                            left join vw_positions p on (p.position_reference = a.position_reference)
                            """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source).cache()

// COMMAND ----------

// DBTITLE 1,Refresh table Job Requisition
try {
  spark.sql("FSCK REPAIR TABLE hr.job_requisition")
}
catch {
  case e: FileNotFoundException => println("Couldn't find that file.")
  case e: IOException => println("Had an IOException trying to read that file")
}

// COMMAND ----------

// DBTITLE 1,Read the table hr job requisition
val job_req_table = DeltaTable.forName("hr.job_requisition")


// COMMAND ----------

// DBTITLE 1,Rows for information updated of existing Job Requisition
val new_job_req_table = df_results.as("a_updated")
                                      .join(job_req_table.toDF.as("a"), $"a.job_requisition_key"===$"a_updated.job_requisition_key")
                                      .where("""a.current_record = true and (a.hashkey <> a_updated.hashkey) 
                                      and a_updated.date_raw_load_file >= a.date_raw_load_file""")


// COMMAND ----------

// DBTITLE 1,Union of dataframes between job requisitions updated from existing information and new information from new job requisitions
val job_req_upsert = new_job_req_table.selectExpr("null as mergekey_1", "a_updated.*")
                                              .union(df_results.as("df_results").selectExpr("df_results.job_requisition_key as mergekey_1",
                                                                                           "*"))
val job_req_upsert_distinct = job_req_upsert.distinct().dropDuplicates("mergekey_1","job_requisition_key")

// COMMAND ----------

// DBTITLE 1,Merge on table Job Requisition
job_req_table.alias("a")
  .merge(
    job_req_upsert_distinct.alias("a_updated"),
    """a.job_requisition_key = a_updated.mergekey_1""")
  .whenMatched("""a.current_record = true and (a.hashkey <> a_updated.hashkey) and a_updated.date_raw_load_file >= a.date_raw_load_file """)
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "case when date_add(a_updated.record_start_date,-1)<a.record_start_date then a.record_start_date else date_add(a_updated.record_start_date,-1) end ",
    "record_modification_date" -> "a_updated.record_modification_date",
    "runid" -> "a_updated.runid")
  )
  .whenNotMatched().insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Script to optimize hr job requisition
spark.sql("OPTIMIZE hr.job_requisition")

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_job_req_read.count().toInt //count the number of read records
val inserted_records = df_results.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0
df_results.unpersist()

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.job_requisition 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return Statistics Values
dbutils.notebook.exit(return_value)