// Databricks notebook source
// DBTITLE 1,Get Parameters
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val system_source = dbutils.widgets.get("system_source")

// COMMAND ----------

// DBTITLE 1,Import Librairies and Functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

val dvalue = "2022-03-31"
val system_source = if (load_date <= dvalue) {"hra"} else {"adp"}

// COMMAND ----------

// MAGIC %md ### 1- Read Data

// COMMAND ----------

// DBTITLE 1,Get last partition file loaded
val path_cet = "/employee/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + "_cet"
val partition_cet = get_last_partition_file(path_cet,load_date,"curated")
val table_cet = "employee." + system_source.toLowerCase() + "_cet"

// COMMAND ----------

// DBTITLE 1,Refresh table CET
if(spark.catalog.tableExists(table_cet)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_cet)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// MAGIC %md #### 2- Create KPIs

// COMMAND ----------

// DBTITLE 1,Read CET Data
val byemployeecet = Window.partitionBy("matricule_hr_access","matricule_wd","date_operation","type_operation","compte_operation").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val df_hracet_read = spark.table(table_cet)
                                                    .filter($"date_raw_load_file"===partition_cet)
                                                    .withColumn("rank",rank() over byemployeecet)
                                                    .filter(col("rank")==="1")
                                                    .withColumn("date_operation_2",last_day($"date_operation"))
                                                    .withColumn("flag_cet",when($"jour">0,"taken").otherwise("consumed"))
                                                    .withColumn("hashkey",concat_ws("|",$"matricule_hr_access",$"matricule_wd",$"date_operation_2"))

// COMMAND ----------

// DBTITLE 1,Get Last Operation days and nb solded days
val window = Window.partitionBy("matricule_hr_access","matricule_wd","date_operation_2").orderBy($"date_operation".asc)

//NOMBRE DE JOURS COMPTE EPARGNE-TEMPS (CET) SODLES
val df_hracet_read_kpi = df_hracet_read.withColumn("nb_cet_solded_days", sum($"jour").over(window))

// COMMAND ----------

// DBTITLE 1,Get nd cet days
val window = Window.partitionBy("matricule_hr_access","matricule_wd","date_operation_2","flag_cet").orderBy($"date_operation".asc)
val window2 = Window.partitionBy("matricule_hr_access","matricule_wd","date_operation_2").orderBy($"date_operation_2".asc)
val window3 = Window.partitionBy("matricule_hr_access","matricule_wd").orderBy($"date_operation_2".asc)

//NOMBRE DE JOURS COMPTE EPARGNE-TEMPS (CET) PLACES 
val df_hracet_read_kpi2 = df_hracet_read_kpi.withColumn("nb_cet_taken_days",when ($"flag_cet"==="taken",sum($"jour").over(window)).otherwise(0))
                                        //NOMBRE DE JOURS COMPTE EPARGNE-TEMPS (CET) CONSOMMES 
                                        .withColumn("nb_cet_consumed_days", when($"flag_cet"==="consumed",sum($"jour").over(window)).otherwise(0))
                                        .withColumn("nb_cet_consumed_days",abs($"nb_cet_consumed_days"))
                                        
                                    //one row by matricule, get max value = sum
val df_results = df_hracet_read_kpi2.withColumn("nb_cet_taken_days",max($"nb_cet_taken_days").over(window2))
                                        .withColumn("nb_cet_consumed_days",max($"nb_cet_consumed_days").over(window2))
                                        //NOMBRE DE JOURS COMPTE EPARGNE-TEMPS (CET) SODLES
                                        .withColumn("nb_cet_solded_days",when ($"nb_cet_solded_days">0,max($"nb_cet_solded_days").over(window2)).
                                                                          otherwise(-max(abs($"nb_cet_solded_days")).over(window2)))
                                        .dropDuplicates("matricule_hr_access","matricule_wd","date_operation_2")
                                        .withColumn("nb_cet_solded_days",sum($"nb_cet_solded_days").over(window3))
                                        //NOMBRE DE BENEFICIAIRES CET
                                        .withColumn("nb_cet_beneficiary_days",when($"nb_cet_solded_days">0,1).otherwise(0))
                                       //TAUX REMPLISSAGE CET
                                        .withColumn("percent_cet",when($"nb_cet_solded_days">30,100).otherwise(($"nb_cet_solded_days"/30)*100))                                     
                                        .withColumn("employee_code",sha2(concat_ws("|",$"matricule_wd",$"matricule_hr_access"),256))
                                      //date_operation_month
                                        .withColumn("date_operation_month", date_format($"date_operation","yyyyMM"))
                                        .withColumn("runid",lit(runid))
                                      //Select columns
                                        .selectExpr(
                                          "employee_code"
                                         ,"matricule_hr_access"
                                         ,"matricule_wd"
                                         ,"date_operation"
                                         ,"date_operation_2"
                                         ,"date_operation_month"
                                         ,"nb_cet_solded_days"
                                         ,"nb_cet_taken_days"
                                         ,"nb_cet_consumed_days"
                                         ,"nb_cet_beneficiary_days"
                                         ,"percent_cet"
                                         ,"filepath"
                                         ,"version"
                                         ,"date_raw_load_file"
                                         ,"filename"
                                         ,"curated_ingested_date"
                                         ,"true as current_record"
                                         ,"date_raw_load_file as record_start_date"
                                         ,"null as record_end_date"
                                         ,"current_timestamp() as record_creation_date"
                                         ,"current_timestamp() as record_modification_date"
                                         ,"hashkey"
                                         ,"runid"
                                         ,"lower(trim(split(filepath,'/')[3])) as  system_source"
                                        ).distinct


// COMMAND ----------

// MAGIC %md #### 3- Save Data

// COMMAND ----------

// DBTITLE 1,Refresh table CET
try {
  spark.sql("FSCK REPAIR TABLE hr.cet")
}
catch {
  case e: FileNotFoundException => println("Couldn't find that file.")
  case e: IOException => println("Had an IOException trying to read that file")
}

// COMMAND ----------

// DBTITLE 1,Get Data from table CET
val cet_table = DeltaTable.forName("hr.cet")

// COMMAND ----------

// DBTITLE 1,Merge data on table CET
//flux = quotidien
cet_table
  .as("c")
  .merge(
    df_results.as("updated"),
    "c.hashkey = updated.hashkey")
    .whenMatched
    .updateExpr(
     Map("c.nb_cet_solded_days" -> "updated.nb_cet_solded_days",
        "c.nb_cet_taken_days" -> "updated.nb_cet_taken_days",
        "c.nb_cet_consumed_days" -> "updated.nb_cet_consumed_days",
        "c.nb_cet_beneficiary_days" -> "updated.nb_cet_beneficiary_days",
        "c.percent_cet" -> "updated.percent_cet"))
  .whenNotMatched
  .insertAll()
  .execute()

// COMMAND ----------

// DBTITLE 1,Optimize CET
spark.sql("OPTIMIZE hr.cet")

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_results.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records 

// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.cet 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
and (system_source is null or system_source = '')
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return Statistics Values
dbutils.notebook.exit(return_value)