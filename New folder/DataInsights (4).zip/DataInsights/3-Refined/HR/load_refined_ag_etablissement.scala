// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source folder, dest_folder
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");

// COMMAND ----------

// DBTITLE 1,Include Notebook Containing Common Functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760 ")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Test if the source path exists
if(spark.catalog.tableExists("pay.ag_etablissement")) 
{
  try {
    spark.sql("MSCK REPAIR TABLE pay.ag_etablissement")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

val partition_payroll = get_last_partition_file("/pay/business/ag_etablissement",load_date,"curated")

// COMMAND ----------

// DBTITLE 1,Read Parquet file from source after test if it exists and count number of read records
val df_ag_etablissement_read = spark.table("pay.ag_etablissement").filter("date_raw_load_file = '" + partition_payroll + "'") 
                                                                   .withColumn("pourcentage_ag_clean", (regexp_replace($"pourcentage_ag" , "%", "" ))/100)
//read parquet file

df_ag_etablissement_read.createOrReplaceTempView("vw_ag_etablissement") // create a temp view
df_ag_etablissement_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

// DBTITLE 1,Query to select only job data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select distinct 
                            getconcatenedstring(array(lower(r.libelle_etablissement)
                                                            ,lower(r.code_etablissement)
                                                           )) as ag_etablissement_key
                            ,r.periode                               
                            ,r.libelle_etablissement
                            ,r.code_etablissement
                            ,r.pourcentage_ag_clean as pourcentage_ag
                            ,r.filepath
                            ,r.date_raw_load_file
                            ,r.version
                            ,r.filename
                            ,r.curated_ingested_date
                            ,true as current_record
                            ,current_timestamp() as record_start_date
                            ,null as record_end_date
                            ,r.date_raw_load_file as record_creation_date
                            ,current_timestamp() as record_modification_date
                            ,getconcatenedstring(array(r.libelle_etablissement,r.code_etablissement)) as hashkey 
                           ,'""" + runid + """' as runid
               from    vw_ag_etablissement r
               where   1=1
            """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source)

// COMMAND ----------

if(spark.catalog.tableExists("hr.ag_etablissement")) 
{
  try {
    spark.sql("FSCK REPAIR TABLE hr.ag_etablissement")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the table job after drop the table if exists and store data and table structure on job_table
val ag_etablissement_table = DeltaTable.forName("hr.ag_etablissement")
ag_etablissement_table.toDF.count

// COMMAND ----------

// DBTITLE 1,Rows for job updated
val new_ag_etablissement = df_results.as("ag_etablissement_updated")
  .join(ag_etablissement_table.toDF.as("ag_etablissement"), Seq("ag_etablissement_key"))
  .where("""ag_etablissement.current_record = true and 
  ag_etablissement_updated.hashkey <> ag_etablissement.hashkey and ag_etablissement_updated.date_raw_load_file >= ag_etablissement.date_raw_load_file """)


// COMMAND ----------

// DBTITLE 1,Union of dataframes between jobs updated from existing employees and new jobs from new employees
// Stage the update by unioning two sets of rows
// 1. Rows that will be inserted in the `whenNotMatched` clause
// 2. Rows that will either UPDATE the current contracts of existing employees or insert the new contracts of new employees
val ag_etablissement_upsert = new_ag_etablissement
  .selectExpr("null as mergekey",  "ag_etablissement_updated.*")   // Rows for 1.
  .union(
    df_results.as("df_results").selectExpr("df_results.ag_etablissement_key as mergekey", "*")  // Rows for 2.
  )
//remove duplicate
val ag_etablissement_upsert_distinct = ag_etablissement_upsert.distinct()

// COMMAND ----------

// DBTITLE 1,Merge on table Job
ag_etablissement_table.alias("t")
  .merge(
   ag_etablissement_upsert_distinct.alias("s"),
    """ t.ag_etablissement_key = s.mergekey""")
  .whenMatched("t.current_record = true and t.hashkey <> s.hashkey and s.date_raw_load_file > t.date_raw_load_file")
    .updateExpr(Map(
    "current_record" -> "false", 
    "record_end_date" -> "date_add(s.record_start_date,-1)",
    "record_modification_date" -> "s.record_modification_date",
    "runid" -> "s.runid")
  )
  .whenNotMatched().insertAll()
  .execute()
//display(spark.sql("select * from contracts"))

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE hr.ag_etablissement")

// COMMAND ----------

val read_records = df_ag_etablissement_read.count().toInt //count the number of read records
val inserted_records = ag_etablissement_upsert_distinct.count().toInt //count the number of records to upsert
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Clear dataframe from Cache
df_ag_etablissement_read.unpersist

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)