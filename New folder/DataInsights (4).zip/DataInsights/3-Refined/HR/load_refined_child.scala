// Databricks notebook source
// DBTITLE 1,Get Parameters: storage account, source system, entity, domain and subdomain
val load_date = dbutils.widgets.get("load_date");
val runid = dbutils.widgets.get("runid");
val system_source = dbutils.widgets.get("system_source")

// COMMAND ----------

val dvalue = "2022-03-31"
val system_source = if (load_date <= dvalue) {"hra"} else {"adp"}

// COMMAND ----------

// DBTITLE 1,Include notebook containing common functions
// MAGIC %run /DataInsights/Include/read_write_parse_file

// COMMAND ----------

// DBTITLE 1,Set Up Config
spark.conf.get("spark.sql.autoBroadcastJoinThreshold", "1000485760")
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
sqlContext.setConf("spark.sql.shuffle.partitions", "1") 
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled ","true")
spark.sql("set spark.databricks.delta.autoCompact.enabled = true")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

// COMMAND ----------

// DBTITLE 1,Set Up Database Connection
val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,Refresh table Get_Workers
if(spark.catalog.tableExists("employee.get_workers")) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE employee.get_workers")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Create the windowing function in order to filter the last employee information sent by grouping by employee_id and sort by filename desc. then create the temp view

val byemployee_id = Window.partitionBy("employee_id","france_payroll_id").orderBy($"filename".desc, $"date_raw_load_file".desc, $"version".desc)
val rankorder = Window.partitionBy("employee_id","france_payroll_id").orderBy($"children_date_of_birth")
val df_employee_read = spark.table("employee.get_workers").filter("date_raw_load_file = '" + load_date + "'")
                                                          .withColumn("rank",rank() over byemployee_id).filter(col("rank")==="1")  
                                                           .withColumn("employee_key_wd",concat_ws("|",$"employee_id",stringNormalizer(lower($"children_first_name"))
                                                          ,$"children_date_of_birth",stringNormalizer(lower($"children_last_name"))))
                                                           .withColumn("employee_key_hra",concat_ws("|",$"france_payroll_id",stringNormalizer(lower($"children_first_name"))
                                                          ,$"children_date_of_birth",stringNormalizer(lower($"children_last_name"))))
                                                          .where($"children_date_of_birth".isNotNull)
                                                          .dropDuplicates("employee_key_wd")
                                                          .withColumn("children_order", rank() over rankorder).withColumn("children_order",concat(lit("0"),$"children_order"))
                                                          .filter("france_payroll_id is not null or (france_payroll_id is null and company_id = '0082')")                      
df_employee_read.createOrReplaceTempView("vw_employee") // create a temp view
df_employee_read.cache()  //put the dataframe on the cache
//display(df_employee_read)

// COMMAND ----------

// DBTITLE 1,Get Last partition file loaded
val path_children = "/employee/" + system_source.toLowerCase() + "/" + system_source.toLowerCase() + "_enfants"
val partition_children = get_last_partition_file(path_children,load_date,"curated")
val table_children = "employee." + system_source.toLowerCase() + "_enfants"

// COMMAND ----------

// DBTITLE 1,Refresh table employee children
if(spark.catalog.tableExists(table_children)) 
{ 
try {
    spark.sql("MSCK REPAIR TABLE " + table_children)
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Read employee children file
val df_enfanthra_read = spark.table(table_children).filter($"date_raw_load_file"===partition_children)
  .withColumnRenamed("date_naissance","date_naissance_enfant")
  .withColumnRenamed("sexe","sexe_enfant")
  .withColumnRenamed("nom","nom_enfant")           

//display(df_enfanthra_read)

// COMMAND ----------

// DBTITLE 1,Get Transco dataframe
spark.read.jdbc(jdbcurl, "dbo.param_transco_ref",connectionproperties).createOrReplaceTempView("vw_dbo_param_transco_ref")
val df_transco = spark.table("vw_dbo_param_transco_ref").na.fill("Nothing")
//display(df_transco)

// COMMAND ----------

// DBTITLE 1,Transco
//transco
val df_enfanthra_read_transco = gettransco2(df_transco,df_enfanthra_read,"hra","workday")
val df_enfanthra_read_transco_new = df_enfanthra_read_transco._1.withColumn("employee_key_wd",concat_ws("|",$"matricule_wd",stringNormalizer(lower($"prenom"))
                                                          ,$"date_naissance_enfant",stringNormalizer(lower($"nom_enfant"))))
                                                           .withColumn("employee_key_hra",concat_ws("|",$"matricule_hr_access",stringNormalizer(lower($"prenom"))
                                                          ,$"date_naissance_enfant",stringNormalizer(lower($"nom_enfant"))))
df_enfanthra_read_transco_new.createOrReplaceTempView("vw_enfant") // create a temp view

// COMMAND ----------

// DBTITLE 1,Refresh table hr.employee_children
 if(spark.catalog.tableExists("hr.employee_children")) 
{ 
  try {
    spark.sql("FSCK REPAIR TABLE hr.employee_children")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}

// COMMAND ----------

// DBTITLE 1,Get employee children data
val employee_child_table = DeltaTable.forName("hr.employee_children").toDF.as("employee").select("employee_id","france_payroll_id","date_raw_load_file").distinct
employee_child_table.createOrReplaceTempView("vw_employee_child_table")

// COMMAND ----------

// DBTITLE 1,Query to select only employee children data, cast columns to the target type, add current_record,record_start_date and record_end_date columns and build the hashkey column
val query_source = """select   distinct 
                               getconcatenedstring(array(e.employee_id
                                                        ,e.france_payroll_id 
                                                              )) as employee_key
                               ,e.employee_key_wd
                              ,e.employee_key_hra
                              ,sha2(getconcatenedstring(array(e.employee_id, e.france_payroll_id)),256) as employee_code
                              ,e.employee_id
                              ,e.france_payroll_id
                              ,e.children_order as children_order_number
                              ,e.children_gender
                              ,e.children_date_of_birth
                              ,stringNormalizer(upper(e.children_first_name)) as children_first_name
                              ,stringNormalizer(upper(e.children_last_name)) as children_last_name
                              ,e.children_dependent
                              ,e.children_date_of_death
                              ,e.version
                              ,e.date_raw_load_file
                              ,e.filepath
                              ,e.filename
                              ,to_date(e.curated_ingested_date) as curated_ingested_date
                              ,true as current_record
                              ,e.date_raw_load_file as record_start_date
                              ,null as record_end_date
                              ,current_timestamp() as record_creation_date
                              ,current_timestamp() as record_modification_date
                              ,getconcatenedstring(array( e.children_last_name
                                                          ,e.children_first_name
                                                          ,e.children_date_of_birth
                                                          ,e.children_gender
                                                             )) as hashkey 
                       , '""" + runid + """' as runid
                       , lower(trim(split(e.filepath,"/")[3])) as system_source
               from    vw_employee e
                       left join vw_enfant c on (e.employee_key_wd = c.employee_key_wd and e.employee_key_hra = c.employee_key_hra) or (e.employee_key_wd = c.employee_key_wd and e.employee_key_hra is null)
                       left join vw_employee_child_table ct on (e.employee_key_wd = ct.employee_id and e.employee_key_hra = ct.france_payroll_id) or (e.employee_key_wd = ct.employee_id and e.employee_key_hra is null)
                       
               where   1 = 1
                 and   (e.employee_id is not null or e.france_payroll_id is not null)
                 and   (e.children_first_name is not null)
                 and   (e.date_raw_load_file > ct.date_raw_load_file or ct.date_raw_load_file is null)

              """

// COMMAND ----------

// DBTITLE 1,Run the previous query and store results in dataframe
val df_results = spark.sql(query_source)
df_results.createOrReplaceTempView("vw_results")

// COMMAND ----------

// DBTITLE 1,Delete employee that are present in both table
spark.sql(""" 
delete from hr.employee_children a
  where exists (select b.employee_code from vw_results b where  a.employee_code =  b.employee_code) 
  """)

// COMMAND ----------

// DBTITLE 1,Insert new data
df_results.write.format("delta")
                .mode("append")
                .saveAsTable("hr.employee_children")

// COMMAND ----------

// DBTITLE 1,Update employee_id where is null for old records and employee_id and france_payroll_id is not null for current record
spark.sql("""
merge into hr.employee_children e1
using hr.employee_children e2
on e1.france_payroll_id = e2.france_payroll_id
and e1.employee_id is null 
and e2.employee_id is not null
and e2.current_record = true
when matched then
  update set e1.employee_id = e2.employee_id,
             e1.current_record = false,
             e1.record_end_date = case when e1.record_end_date is null then date_add(e2.record_start_date,-1) end,
             e1.employee_code = e2.employee_code,
             e1.employee_key = e2.employee_key
""")

// COMMAND ----------

// DBTITLE 1,Script pour optimiser le stockage et la lecture des fichiers delta
spark.sql("OPTIMIZE hr.employee_children")

// COMMAND ----------

// DBTITLE 1,Statistics
val read_records = df_employee_read.count().toInt //count the number of read records//set up the return value with the number of lines read, rejected and inserted
val inserted_records = df_results.count().toInt //count the number of records to upsert
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0

// COMMAND ----------

// DBTITLE 1,Remove dataframes from cache
df_employee_read.unpersist
df_results.unpersist


// COMMAND ----------

// DBTITLE 1,Update System Source
spark.sql(""" 
update hr.employee_children 
set system_source = lower(trim(split(filepath,"/")[3]))
where 1=1
""")

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)