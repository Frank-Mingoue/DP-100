// Databricks notebook source
// MAGIC %python
// MAGIC 
// MAGIC # dbutils.secrets.listScopes()
// MAGIC dbutils.secrets.list("hra_backup")

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_career.zy38

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_career.zy3b

// COMMAND ----------

(b.DTEF00 >= a.DTEF00 and b.DTEN00 <= a.DTEN00) 
OR (b.DTEF00 < a.DTEF00 and b.DTEN00 <= a.DTEN00 and b.DTEN00  > a.DTEF00) 
OR (b.DTEF00 >= a.DTEF00 and b.DTEN00 > a.DTEN00 and b.DTEF00 < a.DTEN00)
OR (b.DTEF00 <= a.DTEF00 and b.DTEN00 >= a.DTEN00 ) 

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * 
// MAGIC from hrabackup_career.zy38 a
// MAGIC anti join hrabackup_career.zy3b b on b.NUDOSS = a.NUDOSS 
// MAGIC and b.DTEF00 >= a.DTEF00 and b.DTEN00 <= a.DTEN00

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * 
// MAGIC from hrabackup_career.zy38 a
// MAGIC join hrabackup_career.zy3b b on b.NUDOSS = a.NUDOSS 
// MAGIC and b.DTEF00 < a.DTEF00 and b.DTEN00 <= a.DTEN00 and b.DTEN00  > a.DTEF00

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from 
// MAGIC hrabackup_career.zy38
// MAGIC where NUDOSS = 717

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from 
// MAGIC hrabackup_career.zy3b
// MAGIC where NUDOSS = 717

// COMMAND ----------

