// Databricks notebook source
// DBTITLE 1,Include notebook containing functions to read directory and process files inside the directory
// MAGIC %run ../HRA_Backup/Include/read_write_parse_file

// COMMAND ----------

// MAGIC %run ../HRA_Backup/1-Raw/get_file_structure

// COMMAND ----------

// MAGIC %run ../HRA_Backup/1-Raw/get_file_columns

// COMMAND ----------

spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

// COMMAND ----------

// DBTITLE 1,Define variables to read csv files from source and write parquet files to destination


//build the path to read raw data
val source_path = get_container("raw") + "/backup_hra"

//define vaaiable for file extension to read
val extension = "txt"

// define variable for file format 
val format = "text"

//define variable for row separator
val delimiter = "\\n"

//build the folder to write on curated data
val dest_path = get_container("curated") + "/backup_hra"


// temp file path
val temp_file_path = "/tmp/temp_file.csv"





// COMMAND ----------

val folder = "career"
val f= "/mnt/raw_container/backup_hra/" +folder+"/table_ZYES_2207.txt"
dbutils.fs.head(f)

// COMMAND ----------

//val source_folder_list = List("absences")
val folder = "pay"
var log_file = ""
val f= "/mnt/raw_container/backup_hra/" +folder+"/table_ZX6B_1411/table_ZX6B_1411.txt"

var filenameDF = spark.read.format(format) 
                  .option("sep", delimiter)
                  .option("header", "false")
                  .option("quote", "\"")
                  .option("escape", "\"")
                  .option("multiline",true)
                  .load(f)

                  

// COMMAND ----------

// filenameDF.cache()
// filenameDF.unpersist()

// COMMAND ----------

filenameDF.count()

// COMMAND ----------

display(filenameDF)

// COMMAND ----------

//Remove first ligne  
val CleanDF = filenameDF.filter(!col("value").contains("||trim("))
// display(CleanDF)

// COMMAND ----------



// COMMAND ----------

CleanDF.count()

// COMMAND ----------

//split
CleanDF.write.mode("overwrite").format("text").save(temp_file_path) // save in temp file
val df_splitted = spark.read.option("delimiter", ";").csv(temp_file_path).select("_c27","_c6", "_c23", "_c34") //read temp file adding delimiter to split and drop the first 2 columns
display(df_splitted)      

// COMMAND ----------

df_splitted.count()

// COMMAND ----------

//Trim
var TrimDf = df_splitted
for(col <- df_splitted.columns){
TrimDf = TrimDf.withColumn(col,trim(df_splitted(col)))
}

display(TrimDf)

// COMMAND ----------

TrimDf.count()

// COMMAND ----------

// filter out null values for column NUDOSS
val FilterDF = TrimDf.filter(col("_c27").isNotNull)


// COMMAND ----------

FilterDF.count()

// COMMAND ----------

val df_null = FilterDF.filter(col("_c2").isNull)

// COMMAND ----------

df_null.count()

// COMMAND ----------

//delete duplicate value
val df_source = FilterDF.distinct()
//display(df_source)

// COMMAND ----------

df_source.count()

// COMMAND ----------

//df_source.schema

// COMMAND ----------

  //val df_target = spark.table(tablename)
  val object_name = getvalueposition (getvalueposition(f, 5, "/"), 1, "_")

  // schema
  val file_schema = get_file_structure(object_name)

  val file_columns = get_file_columns(object_name)


// COMMAND ----------

val schema_target_size = file_schema.fields.map(f => (f.name)).size
val schema_source_size = df_source.schema.fields.map(f => (f.name)).size

// COMMAND ----------

val schema_target_size = file_schema.fields.map(f => (f.name)).size
val schema_source_size = df_source.schema.fields.map(f => (f.name)).size

//Compare schema by checking if number of columns in schema_source and schema_target are equals
val diff_schema_size=schema_source_size == schema_target_size

var res =""

if(diff_schema_size == false) {
  
  res = "ERR-001| The number of columns between source and target does'nt match: | " + schema_source_size + " vs " + schema_target_size
  var newDf = df_source.withColumn("error_log",lit(res))
  
   display(newDf) 
   
}

else{
  
  
  var df_columns_named = infer_schema(df_source, temp_file_path, file_columns, false )
  //df_source.write.mode("overwrite").option("header", false).format("csv").save(temp_file_path)
  //var df_columns_named = spark.read.schema(file_schema).option("sep", ";").option("header", false).csv(temp_file_path)
  
  val schema_source_fields=df_columns_named.schema.fields.map(f => (f.name, f.dataType, f.nullable)).map(x => x._1) 
  val schema_target_dtype=file_schema.fields.map(f => (f.name, f.dataType, f.nullable)).map(x => x._2.simpleString) 
  val not_nullable_columns=file_schema.fields.map(f => (f.name, f.dataType, f.nullable)).filter(x => x._3 == true).map(x => x._1)
  
  
  //schema_source_fields=newdf.schema.fields.map(f => (f.name, f.dataType, f.nullable)).map(x => x._1) 
  val final_struc = StructType(file_columns.fields).add(StructField("error_log", StringType, true))
  //val final_struc2 = StructType(file_schema.fields).add(StructField("error_log", StringType, true))
  
  
  val newRdd = df_columns_named.rdd.map(row => getrow(row,schema_source_fields,not_nullable_columns,schema_target_dtype))
  var newDf = spark.createDataFrame(newRdd,final_struc)
  //newDf.write.mode("overwrite").option("header", true).format("csv").save(temp_file_path)
  //var df_final = spark.read.schema(final_struc2).option(delimiter, ";").option("header", true).csv(temp_file_path)
  
  display(newDf) 
  
  
}


// COMMAND ----------

val schema_source_fields=df_source.schema.fields.map(f => (f.name, f.dataType, f.nullable)).map(x => x._1) 
  val schema_target_dtype=file_schema.fields.map(f => (f.name, f.dataType, f.nullable)).map(x => x._2.simpleString) 
  val not_nullable_columns=file_schema.fields.map(f => (f.name, f.dataType, f.nullable)).filter(x => x._3 == true).map(x => x._1)

var row = Row("9508", "2", "FRP", "0", "CEC", "0001-01-01-00.00.00", "0001-01-01-00.00.00", "2", "4", "0", "0001-01-01-00.00.00", "0001-01-01-00.00.00" )
  var values = Seq[Any]()
  var error = ""
  var row_value = ""
   var i = 0
  while(i<(schema_source_fields.length)-1)
  {    
    //println(row(i))
     if( row(i) != null && (row(schema_source_fields(i))).toString.isEmpty==false)
     {       
       row_value = getWellFormat((row(schema_source_fields(i))).toString, schema_target_dtype(i))
       values = values :+ coalesceString(row_value,(row(schema_source_fields(i))).toString)
      
       if(row_value == null || row_value == "" || row_value.isEmpty) 
       {
          error = error.concat("|") + "ERR-003: the value of column " + schema_source_fields(i) + " is not a " + schema_target_dtype(i) + " "
       }
     }
    
     else
     {
        values = values :+ row.getAs(schema_source_fields(i))
     }
    
     
     i = i+1
  }
  values = values :+ row(schema_source_fields((schema_source_fields.length-1)))
  //values = values :+ error
  println(values)
  // temprow=Row(row.getDouble(0),row.getString(1),row.getString(2),row.getString(3),row.getString(4),row.getDouble(5),row.getInt(6),row.getDouble(7),row.getDouble(8),row.getDouble(9))
  //temprow=Row(row.getAs("carat"),row(1),row(2),row(3),row(4),row(5),row(6),row(7),row(8),row(9))
  //temprow=Row.fromSeq(values)
  

// COMMAND ----------

//Calculate the size of file
      var size = calcRDDSize(filenameDF.rdd.map(_.toString()))

      //Define the number of partitions to write
      var num_partitions = scala.math.round(size*(9.31*scala.math.pow(10, -10))).toString

      if(num_partitions < "1") { num_partitions="1" } //if the variable num_paritions is 0 => we should write one partiton

      //specify the shuffle of partitions
      sqlContext.setConf("spark.sql.shuffle.partitions", num_partitions)

// COMMAND ----------

var  df_final =  parse_file(filenameDF,delimiter,extension,file_schema,file_columns,temp_file_path)
//display(df_final)

// COMMAND ----------

df_final.count()

// COMMAND ----------

display(df_final.orderBy("NUDOSS"))

// COMMAND ----------

display(df_final.where(col("NUDOSS").isNull))

// COMMAND ----------

var df_rejected_records = df_final.filter(df_final("error_log") =!= "") 

df_rejected_records.count()

// COMMAND ----------

display(df_rejected_records)

// COMMAND ----------

var df_inserted_records = df_final.filter(df_final("error_log") === "")
                          .drop("error_log")
val df_inserted_records_final = infer_schema(df_inserted_records, temp_file_path, file_schema, true)
df_inserted_records_final.count()

// COMMAND ----------

df_inserted_records_final.filter(col("NUDOSS").isNull).count

// COMMAND ----------

display(df_inserted_records_final.filter(col("NUDOSS").isNotNull))

// COMMAND ----------

val dest_folder_path =   dest_path + "/" + folder

// COMMAND ----------

df_inserted_records.cache()

// COMMAND ----------

val  partition_column = Seq("PERPAI")

// COMMAND ----------

writeadls(df_inserted_records_final,dest_folder_path,object_name,"parquet","overwrite", partition_column, folder)

// COMMAND ----------

/**************Filter on rows to insert and add some metadata columns**********************/
      var df_inserted_records = df_final.filter(df_final("error_log") === null)
                          .drop("error_log") //drop the error_log column created during the file parsing
      /**************write the file in the destination filet**********************/
      if (df_inserted_records.count().toInt > 0) {
      
      df_inserted_records.cache() // put the dataframe in the cache       
        
        //wrie into adls  #load file in curated
      val dest_folder_path =   dest_path + "/" + folder    
      writeadls_nopartition(df_inserted_records,dest_folder_path,object_name,"parquet","overwrite")
        
      }
        
      
       /**************Filter on rows to reject and add some metadata columns**********************/
      var df_rejected_records = df_final.filter(df_final("error_log") =!= "") 

      if (df_rejected_records.count().toInt > 0)
      {
        
      df_rejected_records.cache() // put the dataframe in the cache
      
      val dest_folder_path =   dest_path + "/" + folder + "/rejected"  
      writeadls_nopartition(df_rejected_records,dest_folder_path,object_name,"parquet","overwrite")
        
      log_file = log_file + "failed to load in curated :" + object_name 
      }

// COMMAND ----------

println(log_file)

// COMMAND ----------

// DBTITLE 1,Clear Cache
spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
dbutils.notebook.exit(return_value)