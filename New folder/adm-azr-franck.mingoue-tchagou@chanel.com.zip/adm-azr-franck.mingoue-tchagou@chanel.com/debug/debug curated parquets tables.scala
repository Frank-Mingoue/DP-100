// Databricks notebook source
val df = spark.table("hrabackup_pay.zxmm")

// COMMAND ----------

val df_filter = df.filter("NUDOSS == 2474847")
display(df_filter)

// COMMAND ----------

