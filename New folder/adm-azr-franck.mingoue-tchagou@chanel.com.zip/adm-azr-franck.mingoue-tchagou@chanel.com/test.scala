// Databricks notebook source
// MAGIC %python
// MAGIC dbutils.secrets.listScopes()

// COMMAND ----------

// MAGIC %python
// MAGIC dbutils.secrets.list(scope="hra_backup")

// COMMAND ----------



// COMMAND ----------


def get_table_structure(tablename: String, domain: String) : String = {

var struct: String = null
  
struct = tablename  match {
  
  
  
  //------------ZY00 
    case "ZY00" => 
        s"""create table if not exists hrabackup_${domain}.ZY00 (
        NUDOSS int,                                                                                         
        MATCLE string,                                                                    
        NOMPAT string,                                                                                 
        N05TRI string,                                                                                                      
        VALID5 string,                                                                                                      
        PRENOM string,                                                                                                      
        PRENO2 string,                                                                                    
        QUALIT string,                                                                                                      
        NOMUSE string,                                                                                                      
        PARTUS string,                                                                                     
        N07TRI string,                                                                                    
        VALIDE string)
        USING PARQUET
        LOCATION "/mnt/curated_container/backup_hra/${domain}/ZY00/";"""


    //------------ZYWO 
    case "ZYWO" => 
        s"""create table if not exists hrabackup_${domain}.ZYWO (
        NUDOSS int,
        MATWOR string)
        USING PARQUET
        LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYWO/";"""

  
    case default => null
    }
  
   return struct
}

// COMMAND ----------

val test = Map(
  "Toy Story" -> ("test", "testss"),
  "Forrest Gump" -> 8.8,
  "Cloud Atlas" -> 7.4
)

// COMMAND ----------

