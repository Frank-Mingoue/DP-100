# Databricks notebook source
# MAGIC %run /DataInsights/Include/read_write_parse_file

# COMMAND ----------

# MAGIC %scala
# MAGIC val dest_path = get_container("raw") + "/backup_hra"
# MAGIC val source_path = get_container("curated") + "/backup_hra"
# MAGIC spark.conf.set("sp", source_path)
# MAGIC spark.conf.set("dp", dest_path)

# COMMAND ----------

pip install xlsxwriter pandas_profiling 

# COMMAND ----------

from pandas_profiling import ProfileReport
from datetime import datetime
import numpy as np
import pandas as pd
import os
import xlsxwriter
import shutil

# COMMAND ----------

def domain(file_name) :
  
  leave = ["ZYDV", "ZYAG", "ZYDA", "ZYE4", "ZYE6"]
  payroll = ["ZXMJ", "ZXMM", "ZX0M", "ZX31", "ZX33", "ZX35", "ZX37", "ZX38", "ZX3B", "ZX40", "ZX4K", "ZX5V", "ZX6A", "ZX6C", "ZX6P", "ZX8K", "ZXM7", "ZXMI", "ZX00"]
  career = ["ZYCO", "ZYRG", "ZYCU", "ZYPR", "ZYEL", "ZY35", "ZY4K", "ZYTL", "ZYCA", "ZY38", "ZY3B", "ZYAF", "ZY19", "ZYWV", "ZYAU", "ZYWB", "ZYWW", "ZY5G", "ZYES", "ZY1M", "ZYHB", "ZYCS", "ZY24", "ZYAR", "ZY1S","ZY00","ZYWO"]
  
  if file_name in leave :
    return "absences"
  elif file_name in payroll : 
    return "paie"
  elif file_name in career :
    return "carrière"
  else :
    return "common"
  

# COMMAND ----------

source_dir = "/dbfs" + spark.conf.get("sp")
source_path = spark.conf.get("sp")
dest_folder = spark.conf.get("dp")
stat_path = dest_folder + "/hra_stats/"
tmp_path = source_path + "/tmp/"
log_file = ""
folder_list = ["pay","career","absences"]
file_list_toload = ["ZX6P"]

# COMMAND ----------

for folder in folder_list :
  folder_path = source_dir + "/" + folder
  if os.path.isdir(folder_path) :
    file_list = os.listdir(folder_path) 
    writer = pd.ExcelWriter("/tmp/" + folder + ".xlsx", engine = "xlsxwriter")
      
    for file in file_list : 
        
        if file not in  ["rejected", "ZX8K", "ZXMM"] :
        
          print(file)
          df = spark.read.parquet(source_path + "/" + folder + "/" + file)
          df_pd = df.toPandas()
          profile = ProfileReport(df_pd, minimal = True)
          #profile.to_file(dest_path + "/" + folder + "_" + file + ".html")    
          file_df = pd.DataFrame(profile.get_description()["variables"]).loc[["n","n_missing","p_missing", "n_distinct"]].transpose()
          file_df.columns = ["Nbre de lignes", "Nbre de lignes Manquantes", "% lignes Manquantes", "Nbre de valuers distinctes"]
          file_df.to_excel(writer, file)
          
                 
          
          
    writer.save()

# COMMAND ----------

# from pyspark.sql.functions import col
# for folder in folder_list :
#   folder_path = source_dir + "/" + folder
#   if os.path.isdir(folder_path) :
#     file_list = os.listdir(folder_path) 
#     writer = pd.ExcelWriter("/tmp/" + folder + ".xlsx", engine = "xlsxwriter")
      
#     for file in file_list : 
        
#         if file == "ZX8K" :
#           for annee in ["2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022"] :
            
# #             if annee == "2022" :
# #               df = spark.read.parquet(source_path + "/" + folder + "/" + file).filter(col("PERPAI").isin ("MT202201" ,"MT202202", "MT202203"))
# #             else :
#             df = spark.read.parquet(source_path + "/" + folder + "/" + file).filter(col("PERPAI").contains(annee))
              
#             df_pd = df.toPandas()
#             profile = ProfileReport(df_pd, minimal = True)
#             file_df = pd.DataFrame(profile.get_description()["variables"]).loc[["n","n_missing","p_missing", "n_distinct"]].transpose()
#             file_df.columns = ["Nbre de lignes", "Nbre de lignes Manquantes", "% lignes Manquantes", "Nbre de valuers distinctes"]
#             file_df.to_excel(writer, file + "_" + annee)    
              
                            
                     
          
          
#     writer.save()

# COMMAND ----------

for file in os.listdir("/tmp/") :
   if file in ["absences.xlsx" , "career.xlsx", "pay.xlsx"] :
      shutil.copy("/tmp/" + file, "/dbfs" + stat_path + file )
      #dbutils.fs.cp("/tmp/" + file, stat_path + file )
      dbutils.fs.rm("/tmp/" + file , recurse = True)

# COMMAND ----------



# COMMAND ----------

source_dir = "/dbfs" + spark.conf.get("sp")
source_path = spark.conf.get("sp")
folder_list = os.listdir(source_dir)

for folder in folder_list :
  folder_path = source_dir + "/" + folder  
  if os.path.isdir(folder_path) and folder == "table_zy" :
    
    file_list = os.listdir(folder_path)
    
    for file in file_list :          
      file_path = source_dir + "/" + folder + "/" + file
      file_name = file.split("_")[1]
      domain_name = domain(file_name)
      shutil.copy(file_path, source_dir + "/" + domain_name + "/" + file )
      #dbutils.fs.cp("/tmp/" + file, stat_path + file )
      
      #print(source_dir + "/" + domain_name + "/" + file)

# COMMAND ----------

# DBTITLE 1,check successful table in curated
# MAGIC %scala 
# MAGIC val df = spark.read.parquet("/mnt/curated_container/backup_hra/career/ZYRG").filter(col("NUDOSS") === 15808)
# MAGIC display(df)

# COMMAND ----------

df = spark.read.parquet("/mnt/curated_container/backup_hra/career/ZYRG")
#display(df)

# COMMAND ----------

display(df)

# COMMAND ----------

# DBTITLE 1,check rejected table in curated
df = spark.read.parquet("/mnt/curated_container/backup_hra/career/rejected/ZYRG")
display(df)

# COMMAND ----------

df = spark.read.parquet("/mnt/curated_container/backup_hra/career/rejected/ZYAU")
display(df)

# COMMAND ----------

df = spark.read.parquet("/mnt/curated_container/backup_hra/career/ZYAU")
display(df)

# COMMAND ----------

from pyspark.sql.functions import col

display(df.filter(col("NUDOSS").isNull()))

# COMMAND ----------

df.filter(df.NUDOSS.isNotNull()).count()

# COMMAND ----------

