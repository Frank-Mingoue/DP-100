# Databricks notebook source
# MAGIC %run /DataInsights/Include/config_connection

# COMMAND ----------

# MAGIC %run ./get_file_structure

# COMMAND ----------

# MAGIC %scala
# MAGIC val source_path = get_container("raw") + "/backup_hra"
# MAGIC spark.conf.set("sp", source_path)

# COMMAND ----------

dbutils.fs.ls('/mnt/raw_container/backup_hra/table_zy/')

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.functions import split
from pyspark.sql.functions import trim
from pyspark.sql.types import *

temp_file_path = "/tmp/test.csv"

# COMMAND ----------

# DBTITLE 1,Read the file
df = spark.read.option("delimiter", "\t").csv("/mnt/raw_container/backup_hra/table_zy/table_ZYAR_2207.txt") #read the file
df = df.filter(~col("_c0").startswith("SQL> select")) #delete the first line (filter out)
display(df)

# COMMAND ----------

filenameDF = (spark.read.format("text") 
                  .option("sep", "\t")
                  .option("header", "false")
                  .option("quote", "\"")
                  .option("escape", "\"")
                  .option("multiline",True)
                  .load("/mnt/raw_container/backup_hra/table_zy/table_ZYCO_2207.txt"))

filenameDF = filenameDF.filter(~col("value").startswith("SQL> select")) #delete the first line (filter out)
display(filenameDF)

# COMMAND ----------

filenameDF.write.mode("overwrite").format("text").save("/tmp/test.txt")
df_split = spark.read.option("delimiter", ";").csv("/tmp/test.txt")
display(df_split)

# COMMAND ----------

df.write.csv(temp_file_path, mode="overwrite") #temp file
df_split = spark.read.option("delimiter", ";").csv(temp_file_path)
display(df_split)

# COMMAND ----------

# DBTITLE 1,Save file to a temp file and read by splitting 
df.write.csv(temp_file_path, mode="overwrite") #temp file
df_split = spark.read.option("delimiter", ";").csv(temp_file_path) #read temp file adding delimiter to split
df_split = df_split.drop("_c0", "_c1") # drop the first 2 columns

#Trim
for column in df_split.columns :
    df_split = df_split.withColumn(column, trim(col(column)))
    
display(df_split)


# COMMAND ----------

# DBTITLE 1,define Schema
schema = get_file_structure("ZYCO")

# COMMAND ----------

  df_split.write.csv(temp_file_path, mode="overwrite", header = True)
  finaldf = spark.read.option("delimiter", ",").option("header", True).schema(schema).csv(temp_file_path)

# COMMAND ----------

display(finaldf)

# COMMAND ----------

finaldf.printSchema()

# COMMAND ----------

# DBTITLE 1,Create Dataframe by adding schema and columns name
finaldf = spark.createDataFrame(df_split.rdd, schema, True)
finaldf.printSchema()

# COMMAND ----------

display(finaldf)

# COMMAND ----------

pip install xlsxwriter pandas_profiling 

# COMMAND ----------

from pandas_profiling import ProfileReport
import numpy as np
import pandas as pd
import os
import xlsxwriter
import shutil

# COMMAND ----------

pd_df = df_split.toPandas()

# COMMAND ----------

source_path = "/dbfs" + spark.conf.get("sp")
dest_path = source_path + "/hra_stats/"
folder_list = os.listdir(source_path)

for folder in folder_list :
  folder_path = source_path + "/" + folder
  file_list = os.listdir(folder_path)
  if os.path.isdir(folder_path) and folder != "hra_stats" :      
      writer = pd.ExcelWriter("/tmp/" + folder + ".xlsx", engine = "xlsxwriter")
      for file in file_list : 
                  file_path = folder_path + "/" + file
                  df = pd.read_csv(file_path) 
                  profile = ProfileReport(df, minimal = True)
                  #profile.to_file(dest_path + "/" + folder + "_" + file + ".html")    
                  file_df = pd.DataFrame(profile.get_description()["variables"]).loc[["n","n_missing","p_missing", "n_distinct"]].transpose()
                  file_df.to_excel(writer, file)
      writer.save()

# COMMAND ----------

for file in os.listdir("/tmp/") :
   if file in ["absences.xlsx", "carrière.xlsx", "paie.xlsx" ] :
      #shutil.copy("/tmp/" + file, dest_path + file )
      dbutils.fs.cp("/tmp/" + file, dest_path + file )
   

# COMMAND ----------

source_path = "/dbfs" + spark.conf.get("sp")
stat_path = source_path + "/hra_stats/"
dest_path = ""
folder_list = os.listdir(source_path)

for folder in folder_list :
  folder_path = source_path + "/" + folder  
  if os.path.isdir(folder_path) and folder == "table_zy" :
      file_list = os.listdir(folder_path)
      writer = pd.ExcelWriter("/tmp/" + folder + ".xlsx", engine = "xlsxwriter")
      for file in file_list : 
        file_path = folder_path + "/" + file
        file_name = file.split("_")[1]
        
        #read the file
        df = spark.read.text(file_path) #read the file
        df = df.filter(~col("_c0").startswith("SQL> select")) #delete the first line (filter out) 
        
        #split the file and drop first two columns 
        temp_file_path = "/tmp/" + file + "csv"
        df.write.csv(temp_file_path, mode="overwrite") #temp file
        df_split = spark.read.option("delimiter", ";").csv(temp_file_path) #read temp file adding delimiter to split
        df_split = df_split.drop("_c0", "_c1") # drop the first 2 columns
        
        #Trim
        for column in df_split.columns :
        df_trim = df_split.withColumn(column, trim(col(column)))
        
        #save file in tmp  and read by applying the Structtypes and columns names
        df_trim.write.csv(temp_file_path, mode="overwrite", header = True)
        schema = get_file_structure(file_name) 
        finaldf = spark.read.option("delimiter", ",").option("header", True).schema(schema).csv(temp_file_path)
        
        #delete tmp file
        dbutils.rm(temp_file_path)
        
        profile = ProfileReport(df, minimal = True)
        #profile.to_file(dest_path + "/" + folder + "_" + file + ".html")    
        file_df = pd.DataFrame(profile.get_description()["variables"]).loc[["n","n_missing","p_missing", "n_distinct"]].transpose()
        file_df.to_excel(writer, file_name)
                  
      writer.save()

# COMMAND ----------

for file in os.listdir("/tmp/") :
   if file == "table_zy.xlsx" :
      #shutil.copy("/tmp/" + file, dest_path + file )
      dbutils.fs.cp("/tmp/" + file, stat_path + file )

# COMMAND ----------

