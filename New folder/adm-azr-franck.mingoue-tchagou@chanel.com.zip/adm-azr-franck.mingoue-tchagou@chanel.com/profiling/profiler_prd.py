# Databricks notebook source
# MAGIC %run /DataInsights/Include/config_connection

# COMMAND ----------

# MAGIC %run ./get_file_structure

# COMMAND ----------

# MAGIC %scala
# MAGIC val source_path = get_container("raw") + "/backup_hra"
# MAGIC val dest_path = get_container("curated") + "/backup_hra"
# MAGIC spark.conf.set("sp", source_path)
# MAGIC spark.conf.set("dp", dest_path)

# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.functions import split
from pyspark.sql.functions import trim
from pyspark.sql.types import *

# COMMAND ----------

pip install xlsxwriter pandas_profiling 

# COMMAND ----------

from pandas_profiling import ProfileReport
from datetime import datetime
import numpy as np
import pandas as pd
import os
import xlsxwriter
import shutil

# COMMAND ----------

def domain(file_name) :
  
  leave = ["ZYDV", "ZYAG", "ZYDA", "ZYE4", "ZYE6"]
  payroll = ["ZXMJ", "ZXMM", "ZX0M", "ZX35", "ZX37", "ZX38", "ZX3B", "ZX40", "ZX5V", "ZX6A", "ZX6C", "ZX6P", "ZX8K", "ZXM7", "ZXMI", "ZX00"]
  career = ["ZYCO", "ZYRG", "ZYCU", "ZYPR", "ZYEL", "ZY35", "ZY4K", "ZYTL", "ZYCA", "ZY38", "ZY3B", "ZYAF", "ZY19", "ZYWV", "ZYAU", "ZYWB", "ZYWW", "ZY5G", "ZYES", "ZY1M", "ZYHB", "ZYCS", "ZY24", "ZYAR", "ZY1S","ZY00","ZYWO"]
  
  if file_name in leave :
    return "absences"
  elif file_name in payroll : 
    return "paie"
  elif file_name in career :
    return "carrière"
  else :
    return "common"
  

# COMMAND ----------

def writeadls(df, dest_folder, file_name, format_type, mode, partition_column) :

  dest_path = dest_folder + "/" + file_name + "/"

  #df.write.format(format).mode(mode).partitionBy(partition_column).save(dest_path)
  df.write.format(format_type).mode(mode).save(dest_path)
  

# COMMAND ----------

source_dir = "/dbfs" + spark.conf.get("sp")
source_path = spark.conf.get("sp")
stat_path = source_dir + "/hra_stats/"
tmp_path = source_path + "/tmp/"
dest_folder = spark.conf.get("dp")
log_file = ""
folder_list = os.listdir(source_dir)

for folder in folder_list :
  folder_path = source_dir + "/" + folder  
  if os.path.isdir(folder_path) and folder in ["absences" , "carrière"] :
    
      file_list = os.listdir(folder_path)     
      
      #writer = pd.ExcelWriter("/tmp/" + folder + ".xlsx", engine = "xlsxwriter")
      
      for file in file_list : 
        
         #if file in ["table_ZY00_2207.txt"]  : 
        
            file_path = source_path + "/" + folder + "/" + file
            file_name = file.split("_")[1]
            temp_file_path = tmp_path + file_name + ".csv"
            domain_name = domain(file_name)
                
           
            try : 
              #read the file
              df = spark.read.text(file_path) #read the file
              df = df.filter(~col("value").startswith("SQL> select")) #delete the first line (filter out) 

              #split the file and drop first two columns 
              df.write.csv(temp_file_path, mode="overwrite") #temp file
              df_split = spark.read.option("delimiter", ";").csv(temp_file_path) #read temp file adding delimiter to split
              df_split = df_split.drop("_c0", "_c1") # drop the first 2 columns

              #Trim
              for column in df_split.columns :
                df_trim = df_split.withColumn(column, trim(col(column)))

              #save file in tmp  and read by applying the Structtypes and columns names
              df_trim.write.csv(temp_file_path, mode="overwrite", header = True)
              schema = get_file_structure(file_name) 
              finaldf = spark.read.option("delimiter", ",").option("header", True).schema(schema).csv(temp_file_path) 
              
              #load file in curated
              writeadls(finaldf, dest_folder + "/" + domain_name, file_name, "parquet", "overwrite", "")
              
              #generate profile report 
              
             
                
            except : 
              log_file = log_file + str(datetime.now()) + f" : failed to generate cleaned dataframe for {domain_name}/{file_name} \n" 
              
            #delete temp file 
            if os.path.exists("/dbfs" + temp_file_path):
              shutil.rmtree("/dbfs" + temp_file_path)
          
       
                  
      #writer.save()
        
        

# COMMAND ----------

for file in os.listdir("/tmp/") :
   if file in ["absences.xlsx" , "carrière.xlsx", "tbale_zx.xlsx"] :
      shutil.copy("/tmp/" + file, stat_path + file )
      #dbutils.fs.cp("/tmp/" + file, stat_path + file )

# COMMAND ----------

source_dir = "/dbfs" + spark.conf.get("sp")
source_path = spark.conf.get("sp")
folder_list = os.listdir(source_dir)

for folder in folder_list :
  folder_path = source_dir + "/" + folder  
  if os.path.isdir(folder_path) and folder == "table_zy" :
    
    file_list = os.listdir(folder_path)
    
    for file in file_list :          
      file_path = source_dir + "/" + folder + "/" + file
      file_name = file.split("_")[1]
      domain_name = domain(file_name)
      shutil.copy(file_path, source_dir + "/" + domain_name + "/" + file )
      #dbutils.fs.cp("/tmp/" + file, stat_path + file )
      
      #print(source_dir + "/" + domain_name + "/" + file)

# COMMAND ----------

print(log_file)

# COMMAND ----------

              try : 
                pd_df = finaldf.toPandas()
                profile = ProfileReport(pd_df, minimal = True)
                #profile.to_file(stat_path + folder + "_" + file_name + ".html")    
                file_df = pd.DataFrame(profile.get_description()["variables"]).loc[["n","n_missing","p_missing", "n_distinct"]].transpose()
                file_df.to_excel(writer, domain_name+"_"+file_name)
              except :
                log_file = log_file + file_name + str(datetime.now()) + f" : failed to generate profiling for {domain_name}/{file_name} \n"