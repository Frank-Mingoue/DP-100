// Databricks notebook source
// MAGIC %run ../Include/config_connection

// COMMAND ----------

// MAGIC %run ../1-Raw/get_file_structure

// COMMAND ----------

// MAGIC %run ./get_table_structure

// COMMAND ----------

val table = "ZXMM"
val domain = "pay"
val database = "hrabackup_" + domain

// COMMAND ----------

// DBTITLE 1,Create database 
spark.sql(s""" create database if not exists ${database}; """)

// COMMAND ----------

// DBTITLE 1,get table creation script 
val table_sql = get_table_structure(table, domain)

// COMMAND ----------

spark.sql(s""" drop table if exists ${database}.${table}; """)

// COMMAND ----------

spark.sql(table_sql)

// COMMAND ----------

// DBTITLE 1,Create parquet table
spark.sql(s"""create table if not exists hrabackup_${domain}.ZYWO (
        NUDOSS int,
        MATWOR string)
        USING PARQUET
        LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYWO/";""")

// COMMAND ----------

val df_read = spark.table("hrabackup_career.ZYWO")
                                                      
df_read.createOrReplaceTempView("vw_table")

// COMMAND ----------

display(df_read)

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZYWW

// COMMAND ----------

// DBTITLE 1,Refresh table 
/* if(spark.catalog.tableExists(s"${database}.${table}")) 
{ 
  try {
    spark.sql(s"FSCK REPAIR TABLE ${database}.${table}")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}*/

// COMMAND ----------

