// Databricks notebook source
// MAGIC %run ../Include/config_connection

// COMMAND ----------

// MAGIC %run ./get_table_structure

// COMMAND ----------

val table = dbutils.widgets.get("table")
val domain = dbutils.widgets.get("domain")
val database = "hrabackup_" + domain

// COMMAND ----------

// DBTITLE 1,Create database 
spark.sql(s""" create database if not exists ${database}; """)

// COMMAND ----------

// DBTITLE 1,get table creation script 
val table_sql = get_table_structure(table, domain)

// COMMAND ----------

// DBTITLE 1,Create parquet table
spark.sql(s""" drop table if exists ${database}.${table}; """)
spark.sql(table_sql)

// COMMAND ----------

// DBTITLE 1,Refresh table 
/* if(spark.catalog.tableExists(s"${database}.${table}")) 
{ 
  try {
    spark.sql(s"FSCK REPAIR TABLE ${database}.${table}")
  }
  catch {
    case e: FileNotFoundException => println("Couldn't find that file.")
    case e: IOException => println("Had an IOException trying to read that file")
  }
}*/

// COMMAND ----------

