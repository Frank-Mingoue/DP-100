// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

//val jdbcurl = getSQLurl()
//val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,dim_zy38_affectation_etablissement
// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zy38_affectation_etablissement
// MAGIC where numero_dossier = 3421
// MAGIC order by date_debut

// COMMAND ----------

// DBTITLE 1,dim_zy3b_affectation
// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zy3b_affectation
// MAGIC where numero_dossier = 3421
// MAGIC order by date_effet

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * --distinct a.unite_organisationnelle, b.etablissement
// MAGIC from hrabackup_dmt_career.dim_zy3b_affectation a 
// MAGIC left join hrabackup_dmt_career.dim_zy38_affectation_etablissement b 
// MAGIC on a.numero_dossier = b.numero_dossier and a.date_effet >= b.date_debut and  a.date_effet <= b.date_fin
// MAGIC --where a.numero_dossier is null
// MAGIC order by 1

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from hrabackup_dmt_career.dim_zy38_affectation_etablissement
// MAGIC where numero_dossier = 5831

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from hrabackup_dmt_career.dim_zy3b_affectation 
// MAGIC where numero_dossier = 5831

// COMMAND ----------

// DBTITLE 1,dim_zyca_carriere
// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zyca_carriere
// MAGIC where numero_dossier = 3421
// MAGIC order by date_debut

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zyco_contrat
// MAGIC where numero_dossier = 3421
// MAGIC order by date_debut_contrat

// COMMAND ----------

// DBTITLE 1,dim_zyes_entrees_departs
// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zyes_entrees_departs
// MAGIC where numero_dossier = 252
// MAGIC order by date_entree

// COMMAND ----------

// DBTITLE 1,dim_zyco_contrat
// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zyco_contrat
// MAGIC where numero_dossier = 3421
// MAGIC order by date_debut_contrat

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC -- select qualification , classification , code_convention_collective , etablissement , type_contrat, nature_contrat, unite_organisationnelle, date_d_es, date_f_es , min(date_min), max(date_min)
// MAGIC -- from (
// MAGIC select
// MAGIC   a.qualification 
// MAGIC   ,a.classification 
// MAGIC   ,a.code_convention_collective 
// MAGIC   ,a.date_debut AS date_debut_carriere
// MAGIC   ,a.date_fin AS date_fin_carriere
// MAGIC   ,b.date_entree  as date_d_es                 
// MAGIC   ,b.date_sortie_administrative as date_f_es
// MAGIC   ,c.etablissement 
// MAGIC   ,c.date_debut as date_etab
// MAGIC   ,c.date_fin as date_f_etab
// MAGIC   ,d.date_debut_contrat
// MAGIC   ,d.date_fin_contrat
// MAGIC   ,d.type_contrat
// MAGIC   ,d.nature as nature_contrat
// MAGIC   ,e.unite_organisationnelle 
// MAGIC   ,e.date_effet as  date_d_uo
// MAGIC   ,e.date_fin as date_f_uo
// MAGIC   , case WHEN a.date_debut >= e.date_effet THEN a.date_debut
// MAGIC      WHEN e.date_effet >= c.date_debut THEN  e.date_effet
// MAGIC      WHEN c.date_debut >= d.date_debut_contrat THEN  d.date_debut_contrat
// MAGIC     END as date_min
// MAGIC     ,case WHEN a.date_fin <=  e.date_fin THEN a.date_fin
// MAGIC     WHEN e.date_fin <= c.date_fin THEN e.date_fin
// MAGIC     WHEN c.date_fin  <= d.date_fin_contrat THEN  c.date_fin
// MAGIC     END as date_maxi
// MAGIC from hrabackup_dmt_career.dim_zyes_entrees_departs b 
// MAGIC full join hrabackup_dmt_career.dim_zyco_contrat d on b.numero_dossier = d.numero_dossier and d.date_debut_contrat >= b.date_entree and  d.date_fin_contrat  <= b.date_sortie_administrative
// MAGIC full join hrabackup_dmt_career.dim_zy38_affectation_etablissement c on d.numero_dossier = c.numero_dossier and c.date_debut >= d.date_debut_contrat and c.date_fin <= d.date_fin_contrat
// MAGIC full join hrabackup_dmt_career.dim_zy3b_affectation e on c.numero_dossier = e.numero_dossier and e.date_effet >= c.date_debut   and  e.date_fin <=  c.date_fin
// MAGIC full join hrabackup_dmt_career.dim_zyca_carriere a on a.numero_dossier = c.numero_dossier AND a.date_debut >= c.date_debut and a.date_fin <= c.date_fin
// MAGIC 
// MAGIC where b.numero_dossier = 3421 --and d.numero_dossier is null 
// MAGIC order by b.date_entree, d.date_debut_contrat, c.date_debut, e.date_effet, a.date_debut
// MAGIC -- )
// MAGIC -- group by qualification , classification , code_convention_collective , etablissement , type_contrat, nature_contrat, unite_organisationnelle, date_d_es, date_f_es 

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select numero_dossier, qualification , classification , code_convention_collective , etablissement , type_contrat, nature_contrat, unite_organisationnelle , date_d_es, date_f_es, min(date_min) as date_debut, max(date_max) as date_fin
// MAGIC from (
// MAGIC select
// MAGIC   case  WHEN a.numero_dossier is not null  THEN a.numero_dossier
// MAGIC         WHEN b.numero_dossier is not null  THEN b.numero_dossier
// MAGIC         WHEN c.numero_dossier is not null  THEN c.numero_dossier
// MAGIC         WHEN d.numero_dossier is not null  THEN d.numero_dossier
// MAGIC         WHEN e.numero_dossier is not null  THEN e.numero_dossier    
// MAGIC   END as numero_dossier
// MAGIC   ,a.qualification 
// MAGIC   ,a.classification 
// MAGIC   ,a.code_convention_collective 
// MAGIC   ,a.date_debut AS date_debut_carriere
// MAGIC   ,a.date_fin AS date_fin_carriere
// MAGIC   ,b.date_entree  as date_d_es                 
// MAGIC   ,b.date_sortie_administrative as date_f_es
// MAGIC   ,c.etablissement 
// MAGIC   ,c.date_debut as date_etab
// MAGIC   ,c.date_fin as date_f_etab
// MAGIC   ,d.date_debut_contrat
// MAGIC   ,d.date_fin_contrat
// MAGIC   ,d.type_contrat
// MAGIC   ,d.nature as nature_contrat
// MAGIC   ,e.unite_organisationnelle 
// MAGIC   ,e.date_effet as  date_d_uo
// MAGIC   ,e.date_fin as date_f_uo
// MAGIC   , case WHEN a.date_debut >= e.date_effet THEN  e.date_effet 
// MAGIC      ELSE  a.date_debut
// MAGIC      END as date_min
// MAGIC   ,case WHEN a.date_fin <=  e.date_fin THEN a.date_fin
// MAGIC     ELSE e.date_fin
// MAGIC     END as date_max
// MAGIC from hrabackup_dmt_career.dim_zyes_entrees_departs b 
// MAGIC full join hrabackup_dmt_career.dim_zyco_contrat d on b.numero_dossier = d.numero_dossier and d.date_debut_contrat >= b.date_entree and  d.date_fin_contrat  <= b.date_sortie_administrative
// MAGIC full join hrabackup_dmt_career.dim_zy38_affectation_etablissement c on d.numero_dossier = c.numero_dossier and c.date_debut >= d.date_debut_contrat and c.date_fin <= d.date_fin_contrat
// MAGIC full join hrabackup_dmt_career.dim_zy3b_affectation e on c.numero_dossier = e.numero_dossier and e.date_effet >= c.date_debut   and  e.date_fin <=  c.date_fin
// MAGIC full join hrabackup_dmt_career.dim_zyca_carriere a on a.numero_dossier = c.numero_dossier AND a.date_debut >= c.date_debut and a.date_fin <= c.date_fin
// MAGIC 
// MAGIC where b.numero_dossier = 3421 --and d.numero_dossier is null 
// MAGIC --order by b.date_entree, d.date_debut_contrat, c.date_debut, e.date_effet, a.date_debut
// MAGIC )
// MAGIC group by numero_dossier, qualification , classification , code_convention_collective , etablissement , type_contrat, nature_contrat, unite_organisationnelle, date_d_es, date_f_es 
// MAGIC order by numero_dossier , date_debut

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from hrabackup_dmt_career.dim_zyco_contrat where numero_dossier in (
// MAGIC select
// MAGIC --   a.qualification 
// MAGIC --   ,a.classification 
// MAGIC --   ,a.code_convention_collective 
// MAGIC --   ,a.date_debut AS date_debut_carriere
// MAGIC --   ,a.date_fin AS date_fin_carriere
// MAGIC    b.numero_dossier 
// MAGIC --   ,b.date_entree  as date_d_es                 
// MAGIC --   ,b.date_sortie_administrative as date_f_es
// MAGIC --   ,c.etablissement 
// MAGIC --   ,c.date_debut as date_etab
// MAGIC --   ,c.date_fin as date_f_etab
// MAGIC --   ,d.date_debut_contrat
// MAGIC --   ,d.date_fin_contrat
// MAGIC --   ,d.type_contrat
// MAGIC --   ,d.nature as nature_contrat
// MAGIC --   ,e.unite_organisationnelle 
// MAGIC --   ,e.date_effet as  date_d_uo
// MAGIC --   ,e.date_fin as date_f_uo
// MAGIC 
// MAGIC from hrabackup_dmt_career.dim_zyes_entrees_departs b 
// MAGIC full join hrabackup_dmt_career.dim_zyco_contrat d on b.numero_dossier = d.numero_dossier and d.date_debut_contrat >= b.date_entree and  d.date_fin_contrat  <= b.date_sortie_administrative
// MAGIC -- full join hrabackup_dmt_career.dim_zy38_affectation_etablissement c on d.numero_dossier = c.numero_dossier and c.date_debut >= d.date_debut_contrat and c.date_fin <= d.date_fin_contrat
// MAGIC -- full join hrabackup_dmt_career.dim_zy3b_affectation e on c.numero_dossier = e.numero_dossier and e.date_effet >= c.date_debut   and  e.date_fin <=  c.date_fin
// MAGIC -- full join hrabackup_dmt_career.dim_zyca_carriere a on a.numero_dossier = c.numero_dossier AND a.date_debut >= c.date_debut and a.date_fin <= c.date_fin
// MAGIC 
// MAGIC where d.numero_dossier is null )

// COMMAND ----------

// MAGIC %sql
// MAGIC select * 
// MAGIC from  hrabackup_dmt_career.dim_zyes_entrees_departs 
// MAGIC where numero_dossier = 16685
// MAGIC order by 2

// COMMAND ----------

// MAGIC %sql
// MAGIC select * 
// MAGIC from  hrabackup_dmt_career.dim_zyco_contrat
// MAGIC where numero_dossier = 16685
// MAGIC order by 2

// COMMAND ----------

// MAGIC %sql
// MAGIC select * 
// MAGIC from  hrabackup_dmt_career.dim_zy38_affectation_etablissement 
// MAGIC where numero_dossier = 16685
// MAGIC order by 2

// COMMAND ----------

// MAGIC %sql
// MAGIC select * 
// MAGIC from  hrabackup_dmt_career.dim_zy3b_affectation 
// MAGIC where numero_dossier = 16685
// MAGIC order by 2

// COMMAND ----------

// MAGIC %sql
// MAGIC select * 
// MAGIC from  hrabackup_dmt_career.dim_zyca_carriere 
// MAGIC where numero_dossier = 16685
// MAGIC order by 2

// COMMAND ----------

// MAGIC %sql
// MAGIC drop table if exists hrabackup_dmt_career.common_fields

// COMMAND ----------

// MAGIC %sql
// MAGIC --CREATE TABLE hrabackup_dmt_career.common_fields as 
// MAGIC select 
// MAGIC    a.numero_dossier
// MAGIC   ,a.qualification 
// MAGIC   ,a.classification 
// MAGIC   ,a.code_convention_collective 
// MAGIC   ,a.date_debut as date_debut_carriere
// MAGIC   ,a.date_fin as date_fin_carriere
// MAGIC   ,b.date_entree                   
// MAGIC   ,b.date_sortie_administrative
// MAGIC   ,c.etablissement 
// MAGIC   ,c.date_debut as date_debut_etablissment
// MAGIC   ,c.date_fin as date_fin_etablissement
// MAGIC   ,d.date_debut_contrat
// MAGIC   ,d.date_fin_contrat
// MAGIC   ,d.type_contrat
// MAGIC   ,d.nature as nature_contrat
// MAGIC   ,e.unite_organisationnelle
// MAGIC   ,e.date_effet as date_effet_unite_org
// MAGIC   ,e.date_fin   as date_fin_unite_org 
// MAGIC   
// MAGIC from hrabackup_dmt_career.dim_zyca_carriere a 
// MAGIC full join hrabackup_dmt_career.dim_zyes_entrees_departs b on a.numero_dossier = b.numero_dossier AND a.date_debut >= b.date_entree and a.date_fin <= b.date_sortie_administrative
// MAGIC full join hrabackup_dmt_career.dim_zy38_affectation_etablissement c on a.numero_dossier = c.numero_dossier and a.date_debut >= c.date_debut and a.date_fin <= c.date_fin
// MAGIC full join hrabackup_dmt_career.dim_zyco_contrat d on a.numero_dossier = d.numero_dossier and a.date_debut >= d.date_debut_contrat and a.date_fin <= d.date_fin_contrat
// MAGIC full join hrabackup_dmt_career.dim_zy3b_affectation e on c.numero_dossier = e.numero_dossier and e.date_effet >= c.date_debut   and  e.date_fin <=  c.date_fin
// MAGIC where a.numero_dossier = 3421 -- is null or b.numero_dossier is null or c.numero_dossier is null or d.numero_dossier is null or e.numero_dossier is null
// MAGIC --order by a.date_debut

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select
// MAGIC    count( *)
// MAGIC from hrabackup_dmt_career.dim_zyca_carriere a 
// MAGIC full join hrabackup_dmt_career.dim_zyes_entrees_departs b on a.numero_dossier = b.numero_dossier AND a.date_debut >= b.date_entree and a.date_fin <= b.date_sortie_administrative
// MAGIC full join hrabackup_dmt_career.dim_zy38_affectation_etablissement c on a.numero_dossier = c.numero_dossier and a.date_debut >= c.date_debut and a.date_fin <= c.date_fin
// MAGIC full join hrabackup_dmt_career.dim_zyco_contrat d on a.numero_dossier = d.numero_dossier and a.date_debut >= d.date_debut_contrat and a.date_fin <= d.date_fin_contrat
// MAGIC full join hrabackup_dmt_career.dim_zy3b_affectation e on a.numero_dossier = e.numero_dossier and e.date_effet >= a.date_debut   and  e.date_fin <=  a.date_fin
// MAGIC where a.numero_dossier is null --or b.numero_dossier is null or c.numero_dossier is null or d.numero_dossier is null or e.numero_dossier is null

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select  *
// MAGIC from hrabackup_dmt_absences.compte_epargne a
// MAGIC left join hrabackup_dmt_career.common_fields b on a.numero_dossier = b.numero_dossier and a.date_operation >= b.date_debut_carriere and a.date_operation <= b.date_fin_carriere
// MAGIC where a.numero_dossier = 3421
// MAGIC order by a.date_operation

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.common_fields

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select count(*) 
// MAGIC from hrabackup_dmt_absences.compte_epargne a
// MAGIC left join hrabackup_dmt_career.common_fields b on a.numero_dossier = b.numero_dossier 
// MAGIC and a.date_operation >= b.date_debut_carriere 
// MAGIC and a.date_operation <= b.date_fin_carriere

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select  COUNT(*)
// MAGIC from hrabackup_dmt_absences.compte_epargne z
// MAGIC left join hrabackup_dmt_career.dim_zyca_carriere a on z.numero_dossier = a.numero_dossier and z.date_operation >= a.date_debut and z.date_operation <= a.date_fin
// MAGIC left join hrabackup_dmt_career.dim_zyes_entrees_departs b on a.numero_dossier = b.numero_dossier AND a.date_debut >= b.date_entree and a.date_fin <= b.date_sortie_administrative
// MAGIC left join hrabackup_dmt_career.dim_zy38_affectation_etablissement c on a.numero_dossier = c.numero_dossier and a.date_debut >= c.date_debut and a.date_fin <= c.date_fin
// MAGIC left join hrabackup_dmt_career.dim_zyco_contrat d on a.numero_dossier = d.numero_dossier and a.date_debut >= d.date_debut_contrat and a.date_fin <= d.date_fin_contrat
// MAGIC left join hrabackup_dmt_career.dim_zy3b_affectation e on a.numero_dossier = e.numero_dossier and e.date_effet >= a.date_debut   and  e.date_fin <=  a.date_fin
// MAGIC 
// MAGIC --where a.date_operation is not null and b.numero_dossier is null
// MAGIC --order by a.numero_dossier , a.date_operation

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select count(*) from hrabackup_dmt_career.common_fields

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from hrabackup_dmt_career.dim_zyca_carriere 
// MAGIC where numero_dossier = 21
// MAGIC order by date_debut

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from hrabackup_dmt_career.dim_zyco_contrat 
// MAGIC where numero_dossier = 21
// MAGIC order by date_debut_contrat

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zyes_entrees_departs
// MAGIC where numero_dossier = 21
// MAGIC order by date_entree

// COMMAND ----------

hrabackup_dmt_career.dim_zy38_affectation_etablissement

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zy3b_affectation a
// MAGIC full join hrabackup_dmt_career.dim_zy38_affectation_etablissement b
// MAGIC on 
// MAGIC 
// MAGIC 
// MAGIC where numero_dossier = 3421
// MAGIC order by date_effet
// MAGIC 
// MAGIC 
// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zy38_affectation_etablissement
// MAGIC where numero_dossier = 3421
// MAGIC order by date_debut