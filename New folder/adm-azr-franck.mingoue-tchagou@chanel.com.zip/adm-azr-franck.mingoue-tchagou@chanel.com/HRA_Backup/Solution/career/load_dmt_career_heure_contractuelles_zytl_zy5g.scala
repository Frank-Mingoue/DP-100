// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zytl  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZYTL_read = spark.table("hrabackup_career.ZYTL")

//find and get column labels
df_ZYTL_read = gettranscoHRA(df_ZYTL_read, df_ref_read, "ZYTL")
                                                      
df_ZYTL_read.createOrReplaceTempView("vw_ZYTL")
df_ZYTL_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zy5g  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZY5G_read = spark.table("hrabackup_career.ZY5G")

//find and get column labels
df_ZY5G_read = gettranscoHRA(df_ZY5G_read, df_ref_read, "ZY5G")
                                                      
df_ZY5G_read.createOrReplaceTempView("vw_ZY5G")
df_ZY5G_read.cache()  //cache the dataframe

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.filtres", connectionproperties).createOrReplaceTempView("filtres")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.identification", connectionproperties).createOrReplaceTempView("identification")


// COMMAND ----------

// %sql

// select * from vw_ZYTL
// -- where NUDOSS = 687
// order by NUDOSS

// COMMAND ----------

// %sql

// select * from vw_ZY5G
// -- where NUDOSS = 687
// order by NUDOSS , DATDEB

// COMMAND ----------



// COMMAND ----------

// DBTITLE 1,JOIN TABLE ZYTL AND ZY5G
// MAGIC %sql
// MAGIC create or replace temporary view T1 as 
// MAGIC WITH zytl as (
// MAGIC select * , coalesce (Lead(date_add (DATEFF, -1)) over (partition by NUDOSS order by DATEFF), '2999-12-31') as DATFIN   
// MAGIC from vw_ZYTL
// MAGIC     
// MAGIC     )
// MAGIC     
// MAGIC select 
// MAGIC     case 
// MAGIC      when a.NUDOSS is not null then a.NUDOSS 
// MAGIC      else b.NUDOSS 
// MAGIC     end as numero_dossier
// MAGIC 	,a.DATEFF as zytl_date_effet
// MAGIC     ,a.DATFIN as zytl_date_fin 
// MAGIC  	,a.CODTRA as zytl_type_temps_contractuel 
// MAGIC  	,a.NBSTHW as zytl_heures_presencesemaine 
// MAGIC  	,a.NBSTHM as zytl_heures_presencemois 
// MAGIC  	,a.RTSTHR as zytl_pourc_h_presencetemps_plein 
// MAGIC  	,a.NBPDHW as zytl_heures_payeessemaine 
// MAGIC  	,a.NBPDHM as zytl_heures_payeesmois 
// MAGIC  	,a.FORANU as zytl_forfait_annuel_en_jours 
// MAGIC  	,a.MODHOR as zytl_modalite_horaire 
// MAGIC  	,a.NBSTHD as zytl_heures_presencejour 
// MAGIC  	,a.RTPDHR as zytl_pourc_h_payeestemps_plein  	
// MAGIC     ,b.DATDEB as zy5g_date_debut 
// MAGIC  	,b.DATFIN as zy5g_date_fin
// MAGIC  	,b.CODE as zy5g_code 
// MAGIC  	,b.INDCYC as zy5g_index 
// MAGIC     ,get_dateHRA(a.DATEFF, a.DATFIN, a.NUDOSS, b.DATDEB, b.DATFIN, b.NUDOSS, "start" ) as date_debut
// MAGIC     ,get_dateHRA(a.DATEFF, a.DATFIN, a.NUDOSS, b.DATDEB, b.DATFIN, b.NUDOSS, "end" ) as date_fin
// MAGIC     
// MAGIC     from zytl a
// MAGIC     full join vw_ZY5G b on a.NUDOSS = b.NUDOSS
// MAGIC     and join_conditionHRA(a.DATEFF, a.DATFIN, b.DATDEB, b.DATFIN)
// MAGIC     
// MAGIC    
// MAGIC   
// MAGIC     

// COMMAND ----------

// DBTITLE 1,ADD FILTERS AND IDENTIFICATION
val query = """create or replace temporary view T2 as SELECT 

         T1.numero_dossier
        ,T1.zytl_date_effet
        ,T1.zytl_date_fin 
        ,T1.zytl_type_temps_contractuel 
        ,T1.zytl_heures_presencesemaine 
        ,T1.zytl_heures_presencemois 
        ,T1.zytl_pourc_h_presencetemps_plein 
        ,T1.zytl_heures_payeessemaine 
        ,T1.zytl_heures_payeesmois 
        ,T1.zytl_forfait_annuel_en_jours 
        ,T1.zytl_modalite_horaire 
        ,T1.zytl_heures_presencejour 
        ,T1.zytl_pourc_h_payeestemps_plein  	
        ,T1.zy5g_date_debut 
        ,T1.zy5g_date_fin
        ,T1.zy5g_code 
        ,T1.zy5g_index 
        
        ,identification.matricule_hra
        ,identification.matricule_workday
        ,identification.prenom_employe
        ,identification.nom_employe
        ,filtres.date_entree
        ,filtres.date_sortie_administrative  
        ,filtres.type_contrat
        ,filtres.nature
        ,filtres.etablissement
        ,filtres.unite_organisationnelle
        ,filtres.classification
        ,filtres.qualification 
        ,filtres.code_convention_collective
        ,filtres.type_temps_contractuel
        ,filtres.heures_presencemois
        ,filtres.societe
        
        ,get_dateHRA(T1.date_debut, T1.date_fin, T1.numero_dossier, filtres.date_debut_filtre, filtres.date_fin_filtre, filtres.numero_dossier, "start" ) as date_debut_filtre
        ,get_dateHRA(T1.date_debut, T1.date_fin, T1.numero_dossier, filtres.date_debut_filtre, filtres.date_fin_filtre, filtres.numero_dossier, "end" ) as date_fin_filtre


        FROM  T1
        left join identification on identification.numero_dossier = T1.numero_dossier
        left join filtres  on filtres.numero_dossier = T1.numero_dossier 
        and join_conditionHRA(T1.date_debut, T1.date_fin, filtres.date_debut_filtre, filtres.date_fin_filtre)
        
        order by numero_dossier, date_debut_filtre
        """

spark.sql(query)

// COMMAND ----------

val query_record = """

  select * 
  from T2   
  order by numero_dossier, date_debut_filtre
  
  
 """ 

// COMMAND ----------

val table_inserted = spark.sql(query_record)
table_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.heures_contractuelles """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

table_inserted.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.heures_contractuelles", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
table_inserted.unpersist
df_table_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)