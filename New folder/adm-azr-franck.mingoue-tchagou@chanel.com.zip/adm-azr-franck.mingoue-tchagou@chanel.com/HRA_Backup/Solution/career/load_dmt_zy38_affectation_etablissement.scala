// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read ZY38 table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZY38", "domain" -> "career"))

val df_ZY38_read = spark.table("hrabackup_career.ZY38")
                                                      
df_ZY38_read.createOrReplaceTempView("vw_ZY38")
df_ZY38_read.cache()  //cache the dataframe

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC         select 
// MAGIC         
// MAGIC         zy38.NUDOSS as numero_dossier,
// MAGIC         zy38.DTEF00 as date_debut, 
// MAGIC         zy38.DTEN00 as date_fin, 
// MAGIC         --zy38.IDESTA as etablissement, 
// MAGIC         --zy38.RSTRAN as motif_la_mutation, 
// MAGIC         zy38.DTTRAN as date_effet_la_mutation,
// MAGIC         CONCAT (zy38.IDESTA , " - ", ref.libelle_long) as etablissement,
// MAGIC         CONCAT (zy38.RSTRAN , " - ", ref2.libelle_long) as motif_la_mutation
// MAGIC         
// MAGIC         FROM vw_ZY38 zy38
// MAGIC         left join vw_ref ref on ref.nom_colonne = "IDESTA" and zy38.IDESTA = ref.code
// MAGIC         left join vw_ref ref2 on ref2.nom_colonne = "RSTRAN" and zy38.RSTRAN = ref2.code

// COMMAND ----------

val query_record = """ select 
        
                      zy38.NUDOSS as numero_dossier,
                      zy38.DTEF00 as date_debut, 
                      zy38.DTEN00 as date_fin, 
                      --zy38.IDESTA as etablissement, 
                      --zy38.RSTRAN as motif_la_mutation, 
                      zy38.DTTRAN as date_effet_la_mutation,
                      CONCAT (zy38.IDESTA , " - ", ref.libelle_long) as etablissement,
                      CONCAT (zy38.RSTRAN , " - ", ref2.libelle_long) as motif_la_mutation

                      FROM vw_ZY38 zy38
                      left join vw_ref ref on ref.nom_colonne = "IDESTA" and zy38.IDESTA = ref.code
                      left join vw_ref ref2 on ref2.nom_colonne = "RSTRAN" and zy38.RSTRAN = ref2.code
                      """ 

// COMMAND ----------

val zy38_affectation_etablissement = spark.sql(query_record)
zy38_affectation_etablissement.cache()  //put the dataframe ont he cache 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.zy38_affectation_etablissement """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

zy38_affectation_etablissement.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.zy38_affectation_etablissement", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
zy38_affectation_etablissement.unpersist
df_ZY38_read.unpersist
df_ref_read.unpersist

// COMMAND ----------

/*dbutils.notebook.exit(return_value)