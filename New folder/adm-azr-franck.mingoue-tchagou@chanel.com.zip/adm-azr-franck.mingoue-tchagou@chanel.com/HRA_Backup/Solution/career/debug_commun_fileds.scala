// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

//val jdbcurl = getSQLurl()
//val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,dim_zyes_entrees_departs
// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zyes_entrees_departs
// MAGIC order by date_entree

// COMMAND ----------

// DBTITLE 1,dim_zyco_contrat
// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zyco_contrat
// MAGIC order by date_debut_contrat

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select 
// MAGIC case 
// MAGIC  when zyes.numero_dossier is not null then zyes.numero_dossier 
// MAGIC  else zyco.numero_dossier 
// MAGIC  end as numero_dossier
// MAGIC  ,zyes.date_entree
// MAGIC  ,zyes.date_sortie_administrative
// MAGIC  ,zyco.date_debut_contrat
// MAGIC  ,zyco.date_fin_contrat
// MAGIC  ,zyco.type_contrat
// MAGIC  ,zyco.nature
// MAGIC  from hrabackup_dmt_career.dim_zyes_entrees_departs zyes
// MAGIC full join hrabackup_dmt_career.dim_zyco_contrat zyco on zyes.numero_dossier = zyco.numero_dossier 
// MAGIC and ((zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative) 
// MAGIC OR (zyco.date_debut_contrat < zyes.date_entree and zyco.date_fin_contrat <= zyes.date_sortie_administrative and zyco.date_fin_contrat  > zyes.date_entree  ) 
// MAGIC OR (zyco.date_debut_contrat >= zyes.date_entree and zyco.date_fin_contrat > zyes.date_sortie_administrative and zyco.date_debut_contrat <zyes.date_sortie_administrative))

// COMMAND ----------

// DBTITLE 1,dim_zy38_affectation_etablissement
// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zy38_affectation_etablissement
// MAGIC where numero_dossier = 3421
// MAGIC order by date_debut

// COMMAND ----------

// DBTITLE 1,dim_zy3b_affectation
// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zy3b_affectation
// MAGIC where numero_dossier = 3421
// MAGIC order by date_effet

// COMMAND ----------

// DBTITLE 1,dim_zyca_carriere
// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.dim_zyca_carriere
// MAGIC where numero_dossier = 3421
// MAGIC order by date_debut

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select
// MAGIC    a.qualification 
// MAGIC   ,a.classification 
// MAGIC   ,a.code_convention_collective 
// MAGIC   ,a.date_debut
// MAGIC   ,a.date_fin
// MAGIC   ,b.date_entree                   
// MAGIC   ,b.date_sortie_administrative
// MAGIC   --,c.etablissement 
// MAGIC   --,c.date_debut
// MAGIC   --,c.date_fin 
// MAGIC   ,d.date_debut_contrat
// MAGIC   ,d.date_fin_contrat
// MAGIC   ,d.type_contrat
// MAGIC   ,d.nature as natur_contrat
// MAGIC  -- ,e.unite_organisationnelle
// MAGIC from hrabackup_dmt_career.dim_zyca_carriere a 
// MAGIC full join hrabackup_dmt_career.dim_zyes_entrees_departs b on a.numero_dossier = b.numero_dossier AND a.date_debut >= b.date_entree and a.date_fin <= b.date_sortie_administrative
// MAGIC --left join hrabackup_dmt_career.dim_zy38_affectation_etablissement c on a.numero_dossier = c.numero_dossier and a.date_debut >= c.date_debut and a.date_fin <= c.date_fin
// MAGIC left join hrabackup_dmt_career.dim_zyco_contrat d on a.numero_dossier = d.numero_dossier and a.date_debut >= d.date_debut_contrat and a.date_fin <= d.date_fin_contrat
// MAGIC --left join hrabackup_dmt_career.dim_zy3b_affectation e on a.numero_dossier = e.numero_dossier and e.date_effet >= a.date_debut   and  e.date_fin <=  a.date_fin
// MAGIC where a.numero_dossier = 3421
// MAGIC order by a.date_debut

// COMMAND ----------

// MAGIC %sql
// MAGIC drop table if exists hrabackup_dmt_career.common_fields

// COMMAND ----------

// MAGIC %sql
// MAGIC --CREATE TABLE hrabackup_dmt_career.common_fields as 
// MAGIC select 
// MAGIC    a.numero_dossier
// MAGIC   ,a.qualification 
// MAGIC   ,a.classification 
// MAGIC   ,a.code_convention_collective 
// MAGIC   ,a.date_debut as date_debut_carriere
// MAGIC   ,a.date_fin as date_fin_carriere
// MAGIC   ,b.date_entree                   
// MAGIC   ,b.date_sortie_administrative
// MAGIC   ,c.etablissement 
// MAGIC   ,c.date_debut as date_debut_etablissment
// MAGIC   ,c.date_fin as date_fin_etablissement
// MAGIC   ,d.date_debut_contrat
// MAGIC   ,d.date_fin_contrat
// MAGIC   ,d.type_contrat
// MAGIC   ,d.nature as nature_contrat
// MAGIC   ,e.unite_organisationnelle
// MAGIC   ,e.date_effet as date_effet_unite_org
// MAGIC   ,e.date_fin   as date_fin_unite_org 
// MAGIC   
// MAGIC from hrabackup_dmt_career.dim_zyca_carriere a 
// MAGIC full join hrabackup_dmt_career.dim_zyes_entrees_departs b on a.numero_dossier = b.numero_dossier AND a.date_debut >= b.date_entree and a.date_fin <= b.date_sortie_administrative
// MAGIC full join hrabackup_dmt_career.dim_zy38_affectation_etablissement c on a.numero_dossier = c.numero_dossier and a.date_debut >= c.date_debut and a.date_fin <= c.date_fin
// MAGIC full join hrabackup_dmt_career.dim_zyco_contrat d on a.numero_dossier = d.numero_dossier and a.date_debut >= d.date_debut_contrat and a.date_fin <= d.date_fin_contrat
// MAGIC full join hrabackup_dmt_career.dim_zy3b_affectation e on c.numero_dossier = e.numero_dossier and e.date_effet >= c.date_debut   and  e.date_fin <=  c.date_fin
// MAGIC where a.numero_dossier = 3421 -- is null or b.numero_dossier is null or c.numero_dossier is null or d.numero_dossier is null or e.numero_dossier is null
// MAGIC --order by a.date_debut

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select
// MAGIC    count( *)
// MAGIC from hrabackup_dmt_career.dim_zyca_carriere a 
// MAGIC full join hrabackup_dmt_career.dim_zyes_entrees_departs b on a.numero_dossier = b.numero_dossier AND a.date_debut >= b.date_entree and a.date_fin <= b.date_sortie_administrative
// MAGIC full join hrabackup_dmt_career.dim_zy38_affectation_etablissement c on a.numero_dossier = c.numero_dossier and a.date_debut >= c.date_debut and a.date_fin <= c.date_fin
// MAGIC full join hrabackup_dmt_career.dim_zyco_contrat d on a.numero_dossier = d.numero_dossier and a.date_debut >= d.date_debut_contrat and a.date_fin <= d.date_fin_contrat
// MAGIC full join hrabackup_dmt_career.dim_zy3b_affectation e on a.numero_dossier = e.numero_dossier and e.date_effet >= a.date_debut   and  e.date_fin <=  a.date_fin
// MAGIC where a.numero_dossier is null --or b.numero_dossier is null or c.numero_dossier is null or d.numero_dossier is null or e.numero_dossier is null

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select  *
// MAGIC from hrabackup_dmt_absences.compte_epargne a
// MAGIC left join hrabackup_dmt_career.common_fields b on a.numero_dossier = b.numero_dossier and a.date_operation >= b.date_debut_carriere and a.date_operation <= b.date_fin_carriere
// MAGIC where a.numero_dossier = 3421
// MAGIC order by a.date_operation

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from hrabackup_dmt_career.common_fields

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select count(*) 
// MAGIC from hrabackup_dmt_absences.compte_epargne a
// MAGIC left join hrabackup_dmt_career.common_fields b on a.numero_dossier = b.numero_dossier 
// MAGIC and a.date_operation >= b.date_debut_carriere 
// MAGIC and a.date_operation <= b.date_fin_carriere

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select  COUNT(*)
// MAGIC from hrabackup_dmt_absences.compte_epargne z
// MAGIC left join hrabackup_dmt_career.dim_zyca_carriere a on z.numero_dossier = a.numero_dossier and z.date_operation >= a.date_debut and z.date_operation <= a.date_fin
// MAGIC left join hrabackup_dmt_career.dim_zyes_entrees_departs b on a.numero_dossier = b.numero_dossier AND a.date_debut >= b.date_entree and a.date_fin <= b.date_sortie_administrative
// MAGIC left join hrabackup_dmt_career.dim_zy38_affectation_etablissement c on a.numero_dossier = c.numero_dossier and a.date_debut >= c.date_debut and a.date_fin <= c.date_fin
// MAGIC left join hrabackup_dmt_career.dim_zyco_contrat d on a.numero_dossier = d.numero_dossier and a.date_debut >= d.date_debut_contrat and a.date_fin <= d.date_fin_contrat
// MAGIC left join hrabackup_dmt_career.dim_zy3b_affectation e on a.numero_dossier = e.numero_dossier and e.date_effet >= a.date_debut   and  e.date_fin <=  a.date_fin
// MAGIC 
// MAGIC --where a.date_operation is not null and b.numero_dossier is null
// MAGIC --order by a.numero_dossier , a.date_operation

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select count(*) 
// MAGIC from hrabackup_dmt_absences.compte_epargne a
// MAGIC where id_zy3b_unite_organisationelle is null and id_zy38_etablissement is null

// COMMAND ----------

