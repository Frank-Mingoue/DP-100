// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read ZY38 table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYTL", "domain" -> "career"))

var df_ZYTL_read = spark.table("hrabackup_career.ZYTL")

df_ZYTL_read = gettranscoHRA(df_ZYTL_read, df_ref_read, "ZYTL")

                                                      
df_ZYTL_read.createOrReplaceTempView("vw_ZYTL")
df_ZYTL_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC drop table if exists hrabackup_dmt_career.dim_zytl_heures_contractuelles;
// MAGIC create table  hrabackup_dmt_career.dim_zytl_heures_contractuelles as
// MAGIC         select 
// MAGIC         
// MAGIC         NUDOSS as numero_dossier,
// MAGIC         DATEFF as date_effet, 
// MAGIC         CODTRA as type_temps_contractuel,  
// MAGIC         NBSTHM as heures_presencemois
// MAGIC     
// MAGIC         
// MAGIC         FROM vw_ZYTL 
// MAGIC       

// COMMAND ----------

val query_record = """ select 
        
        zytl.NUDOSS as numero_dossier,
        zytl.DATEFF as date_effet, 
        --zytl.CODTRA as type_temps_contractuel,  
        zytl.NBSTHM as heures_presencemois, 
        CONCAT (zytl.CODTRA , " - ", ref.libelle_long) as type_temps_contractuel
        
        FROM vw_ZYTL zytl
        left join vw_ref ref on ref.nom_colonne = "CODTRA" and zytl.CODTRA = ref.code
                      """ 

// COMMAND ----------

val zytl_heures_contractuelles = spark.sql(query_record)
zytl_heures_contractuelles.cache()  //put the dataframe ont he cache 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.commun_zytl_heures_contractuelles """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

zytl_heures_contractuelles.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.commun_zytl_heures_contractuelles", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
zytl_heures_contractuelles.unpersist
df_ZYTL_read.unpersist
df_ref_read.unpersist

// COMMAND ----------

/*dbutils.notebook.exit(return_value)