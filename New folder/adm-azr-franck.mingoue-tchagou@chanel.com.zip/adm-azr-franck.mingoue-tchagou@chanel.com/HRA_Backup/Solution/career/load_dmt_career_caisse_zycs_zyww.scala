// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zycs  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZYCS_read = spark.table("hrabackup_career.ZYCS")

//find and get column labels
df_ZYCS_read = gettranscoHRA(df_ZYCS_read, df_ref_read, "ZYCS")
                                                      
df_ZYCS_read.createOrReplaceTempView("vw_ZYCS")
df_ZYCS_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zyww  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZYWW_read = spark.table("hrabackup_career.ZYWW")

//find and get column labels
df_ZYWW_read = gettranscoHRA(df_ZYWW_read, df_ref_read, "ZYWW")
                                                      
df_ZYWW_read.createOrReplaceTempView("vw_ZYWW")
df_ZYWW_read.cache()  //cache the dataframe

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.filtres", connectionproperties).createOrReplaceTempView("filtres")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.identification", connectionproperties).createOrReplaceTempView("identification")


// COMMAND ----------

// %sql

// WITH caisse as (
// select 
//     case 
//      when a.NUDOSS is not null then a.NUDOSS 
//      else b.NUDOSS 
//     end as numero_dossier
// 	,a.NUDOSP as identifiant_dossier_paie 
//  	,a.CODCAI as code_caisse 
//  	,a.REGIME as regime_retraite 
//  	,a.DEBCAI as date_debut_caisse 
//  	,a.FINCAI as date_fin_caisse
//  	,a.NUMCAI as numero_inscription 
//  	,a.IDCONT as identifiant_contrat 
//  	,a.MOTRUP as motif_rupture_contrat 
//  	,a.MOTSOR as motif_sortie 
//  	,a.FLMAJC as temoin_mise_a_jour_manuelle 
//     ,b.CODREG as code_regime_cotisations 
//  	,b.DATDEB as date_debut_reg_cot 
//  	,b.DATFIN as date_fin_reg_cot 
//  	,b.REPART as repartition_salariale_patronale
    
//     from vw_ZYCS a
//     full join vw_ZYWW b on a.NUDOSS = b.NUDOSS
//     and join_conditionHRA(a.DEBCAI, a.FINCAI, b.DATDEB, b.DATFIN)
    
//   ) 
//   select * from caisse 
//   where date_debut_reg_cot is NOT null   
//   order by numero_dossier ,  date_debut_caisse, date_fin_caisse, regime_retraite
    

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from vw_ZYCS
// MAGIC where NUDOSS = 687
// MAGIC order by NUDOSS, DEBCAI

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from vw_ZYCS
// MAGIC where NUDOSS is null

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from vw_ZYWW
// MAGIC where NUDOSS = 687
// MAGIC order by NUDOSS, DATDEB

// COMMAND ----------

val query = """create or replace temporary view T1 as SELECT 
    case 
     when a.NUDOSS is not null then a.NUDOSS 
     else b.NUDOSS 
    end as numero_dossier
	,a.NUDOSP as zycs_identifiant_dossier_paie 
 	,a.CODCAI as zycs_code_caisse 
 	,a.REGIME as zycs_regime_retraite 
 	,a.DEBCAI as zycs_date_debut
 	,a.FINCAI as zycs_date_fin
 	,a.NUMCAI as zycs_numero_inscription 
 	,a.IDCONT as zycs_identifiant_contrat 
 	,a.MOTRUP as zycs_motif_rupture_contrat 
 	,a.MOTSOR as zycs_motif_sortie 
 	,a.FLMAJC as zycs_temoin_mise_a_jour_manuelle 
    ,b.CODREG as zyww_code_regime_cotisations 
    ,b.DATDEB as zyww_date_debut
 	,b.DATFIN as zyww_date_fin
 	,b.REPART as zyww_repartition_salariale_patronale
    
    from vw_ZYCS a
    full join vw_ZYWW b on a.NUDOSS = b.NUDOSS
    and join_conditionHRA(a.DEBCAI, a.FINCAI, b.DATDEB, b.DATFIN) 
    
"""

spark.sql(query)

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from T1
// MAGIC where zycs_date_debut is null

// COMMAND ----------

// MAGIC %sql
// MAGIC select 
// MAGIC      a.numero_dossier
// MAGIC     ,a.zycs_identifiant_dossier_paie 
// MAGIC     ,a.zycs_code_caisse 
// MAGIC     ,a.zycs_regime_retraite 
// MAGIC     ,a.zycs_date_debut 
// MAGIC     ,a.zycs_date_fin
// MAGIC     ,a.zycs_numero_inscription 
// MAGIC     ,a.zycs_identifiant_contrat 
// MAGIC     ,a.zycs_motif_rupture_contrat 
// MAGIC     ,a.zycs_motif_sortie 
// MAGIC     ,a.zycs_temoin_mise_a_jour_manuelle 
// MAGIC     ,a.zyww_date_debut 
// MAGIC     ,a.zyww_date_fin 
// MAGIC     ,a.zyww_code_regime_cotisations 
// MAGIC     ,a.zyww_repartition_salariale_patronale 
// MAGIC     ,b.date_entree
// MAGIC     ,b.date_sortie_administrative  
// MAGIC     ,b.type_contrat
// MAGIC     ,b.nature
// MAGIC     ,b.etablissement
// MAGIC     ,b.unite_organisationnelle
// MAGIC     ,b.classification
// MAGIC     ,b.qualification 
// MAGIC     ,b.code_convention_collective
// MAGIC     ,b.type_temps_contractuel
// MAGIC     ,b.heures_presencemois
// MAGIC     ,identification.matricule_hra
// MAGIC     ,identification.matricule_workday
// MAGIC     ,identification.prenom_employe
// MAGIC     ,identification.nom_employe
// MAGIC     ,get_dateHRA(a.zycs_date_debut, a.zycs_date_fin, a.numero_dossier, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
// MAGIC     ,get_dateHRA(a.zycs_date_debut, a.zycs_date_fin, a.numero_dossier, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre  
// MAGIC    
// MAGIC   from T1 a
// MAGIC   left join identification on identification.numero_dossier = a.numero_dossier
// MAGIC   left join filtres b on b.numero_dossier = a.numero_dossier 
// MAGIC   and join_conditionHRA(a.zycs_date_debut, a.zycs_date_fin, b.date_debut_filtre, b.date_fin_filtre)  
// MAGIC   
// MAGIC   order by numero_dossier, date_debut_filtre
// MAGIC   

// COMMAND ----------

val query_record = """

  select   
   a.NUDOSS as numero_dossier
  ,a.DATEFF as date_effet 
  ,a.RUBAUG as rubrique
  ,a.MTSAL as montant_salaire 
  ,a.CMOTIF as motif_augmentation 
  ,a.MTAUG as montant_augmentation
  ,a.DATFIN as date_fin 
  ,b.date_entree
  ,b.date_sortie_administrative  
  ,b.type_contrat
  ,b.nature
  ,b.etablissement
  ,b.unite_organisationnelle
  ,b.classification
  ,b.qualification 
  ,b.code_convention_collective
  ,b.type_temps_contractuel
  ,b.heures_presencemois
  ,get_dateHRA(a.DATEFF, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "start" ) as date_debut_filtre 
  ,get_dateHRA(a.DATEFF, a.DATFIN, a.NUDOSS, b.date_debut_filtre, b.date_fin_filtre, b.numero_dossier, "end" ) as date_fin_filtre
  
  
  
  from vw_table a
  
  left join filtres b on b.numero_dossier = a.NUDOSS 
  and join_conditionHRA(a.DATEFF, a.DATFIN, b.date_debut_filtre, b.date_fin_filtre)  
  
  order by numero_dossier, date_debut_filtre
  
  
 """ 

// COMMAND ----------

val table_inserted = spark.sql(query_record)
table_inserted.cache() 

// COMMAND ----------

// val connection = getSQLconnection()
// val stmt = connection.createStatement()
// val query_delete = """ truncate table career.zyau_salaires """
// val res = stmt.execute(query_delete)

// connection.close()

// COMMAND ----------

// table_inserted.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.zyau_salaires", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
table_inserted.unpersist
df_table_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)