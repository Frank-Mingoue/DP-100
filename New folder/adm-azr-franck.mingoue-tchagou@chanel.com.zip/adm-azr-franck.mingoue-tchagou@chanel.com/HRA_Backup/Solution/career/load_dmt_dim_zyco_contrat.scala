// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe


// COMMAND ----------

// DBTITLE 1,init and read dim_zyco_contrat  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYCO", "domain" -> "career"))

var df_ZYCO_read = spark.table("hrabackup_career.ZYCO")

df_ZYCO_read = gettranscoHRA(df_ZYCO_read, df_ref_read, "ZYCO")

                                                      
df_ZYCO_read.createOrReplaceTempView("vw_ZYCO")
df_ZYCO_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC drop table if exists hrabackup_dmt_career.dim_zyco_contrat;
// MAGIC create table  hrabackup_dmt_career.dim_zyco_contrat as
// MAGIC select 
// MAGIC NUDOSS as numero_dossier,
// MAGIC DATCON as date_debut_contrat, 
// MAGIC DATFIN as date_fin_contrat, 
// MAGIC TYPCON as type_contrat, 
// MAGIC NATCON as nature
// MAGIC FROM vw_ZYCO 

// COMMAND ----------

val query_record = """ select 
                        zyco.NUDOSS as numero_dossier,
                        zyco.DATCON as date_debut_contrat, 
                        zyco.DATFIN as date_fin_contrat, 
                        --TYPCON as type_contrat, 
                        --NATCON as nature,
                        CONCAT (zyco.TYPCON , " - ", ref.libelle_long) as type_contrat,
                        CONCAT (zyco.NATCON , " - ", ref2.libelle_long) as nature
                        FROM vw_ZYCO zyco
                        left join vw_ref ref on ref.nom_colonne = "TYPCON" and zyco.TYPCON = ref.code
                        left join vw_ref ref2 on ref2.nom_colonne = "NATCON" and zyco.NATCON = ref2.code
                      """ 

// COMMAND ----------

val zyco_contrat_inserted = spark.sql(query_record)
zyco_contrat_inserted.cache()  //put the dataframe ont he cache */

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.commun_zyco_contrat """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

zyco_contrat_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.commun_zyco_contrat", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_ZYCO_read.unpersist
zyco_contrat_inserted.unpersist
df_ref_read.unpersist

// COMMAND ----------

/*dbutils.notebook.exit(return_value)