// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zy38  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZY38_read = spark.table("hrabackup_career.ZY38")

//find and get column labels
df_ZY38_read = gettranscoHRA(df_ZY38_read, df_ref_read, "ZY38")
                                                      
df_ZY38_read.createOrReplaceTempView("vw_ZY38")
df_ZY38_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.zy3b  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZY3B_read = spark.table("hrabackup_career.ZY3B")

//find and get column labels
df_ZY3B_read = gettranscoHRA(df_ZY3B_read, df_ref_read, "ZY3B")
                                                      
df_ZY3B_read.createOrReplaceTempView("vw_ZY3B")
df_ZY3B_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,JOIN ZY38 AND ZY3B
val query = """create or replace temporary view T1 as SELECT 
        case 
          when zy38.NUDOSS is not null then zy38.NUDOSS 
          else zy3b.NUDOSS 
        end as T1_numero_dossier
        
        ,zy38.DTEF00 as zy38_date_debut
        ,zy38.DTEN00 as zy38_date_fin
        ,zy38.IDESTA as zy38_etablissement
        ,zy38.RSTRAN as zy38_motif_la_mutation
        ,zy38.DTTRAN as zy38_date_effet_la_mutation
        ,zy3b.DTEF00 as zy3b_date_effet
        ,zy3b.DTEN00 as zy3b_date_fin
        ,zy3b.NBASHR as zy3b_horaires_affectation
        ,zy3b.NBFTES as zy3b_equivalences_temps_plein
        ,zy3b.DTPSSE as zy3b_date_arrivee_dans_le_poste
        ,zy3b.IDPS00 as zy3b_code_poste
        ,zy3b.IDJB00 as zy3b_identifiant_emploi
        ,zy3b.IDOU00 as zy3b_unite_organisationnelle
        ,zy3b.RTASSI as zy3b_pourcentage_affectation 
        
        ,get_dateHRA(zy38.DTEF00, zy38.DTEN00, zy38.NUDOSS, zy3b.DTEF00, zy3b.DTEN00, zy3b.NUDOSS, "start" ) as T1_date_debut
        ,get_dateHRA(zy38.DTEF00, zy38.DTEN00, zy38.NUDOSS, zy3b.DTEF00, zy3b.DTEN00, zy3b.NUDOSS, "end" ) as T1_date_fin


        FROM  vw_ZY38 zy38 
        full join vw_ZY3B zy3b on zy38.NUDOSS = zy3b.NUDOSS 
        and join_conditionHRA(zy38.DTEF00, zy38.DTEN00, zy3b.DTEF00, zy3b.DTEN00)
        """

spark.sql(query)

// COMMAND ----------

// DBTITLE 1,init and read career.zy35  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZY35_read = spark.table("hrabackup_career.ZY35")

//find and get column labels
df_ZY35_read = gettranscoHRA(df_ZY35_read, df_ref_read, "ZY35")
                                                      
df_ZY35_read.createOrReplaceTempView("ZY35")

spark.sql(""" create or replace temporary view vw_ZY35 as select *,             
                        coalesce (Lead(date_add (DTEF00, -1)) over (partition by NUDOSS order by DTEF00), '2999-12-31') as DATFIN
                        FROM ZY35
                      """ )
df_ZY35_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,ADD ZY35
val query = """create or replace temporary view T2 as SELECT 
        case 
          when T1.T1_numero_dossier is not null then T1.T1_numero_dossier 
          else zy35.NUDOSS 
        end as T2_numero_dossier
        ,T1.*
        ,zy35.DTEF00 as zy35_date_effet
        ,zy35.IDJB00 as zy35_emploi
        ,zy35.RTASSI as zy35_pourcentage_affectation
        ,zy35.LBEMLG as zy35_libelle_long_reel
        ,zy35.IDPS00 as zy35_poste
        ,zy35.IDOU00 as zy35_unite_organisation
        ,zy35.LBEMSH as zy35_libelle_court_reel
        ,get_dateHRA(T1.T1_date_debut, T1.T1_date_fin, T1.T1_numero_dossier, zy35.DTEF00, zy35.DATFIN, zy35.NUDOSS, "start" ) as T2_date_debut
        ,get_dateHRA(T1.T1_date_debut, T1.T1_date_fin, T1.T1_numero_dossier, zy35.DTEF00, zy35.DATFIN, zy35.NUDOSS, "end" ) as T2_date_fin


        FROM  T1
        full join vw_ZY35 zy35 on zy35.NUDOSS = T1.T1_numero_dossier 
        and join_conditionHRA(T1.T1_date_debut, T1.T1_date_fin, zy35.DTEF00, zy35.DATFIN)
        """

spark.sql(query)

// COMMAND ----------

// DBTITLE 1,init and read career.zy4k  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZY4K_read = spark.table("hrabackup_career.ZY4K")

//find and get column labels
df_ZY4K_read = gettranscoHRA(df_ZY4K_read, df_ref_read, "ZY4K")
                                                      
df_ZY4K_read.createOrReplaceTempView("vw_ZY4K")
df_ZY4K_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,ADD TABLE ZY4K
val query = """create or replace temporary view T3 as SELECT 
        case 
          when T2.T2_numero_dossier is not null then T2.T2_numero_dossier 
          else zy4k.NUDOSS 
        end as T3_numero_dossier
        ,T2.*
        ,zy4k.IDPOCR as  zy4k_centre_cout_1 
        ,zy4k.IDSUAR as  zy4k_souscompte_1 
        ,zy4k.DTEF00 as  zy4k_date_effet 
        ,zy4k.DTEN00 as  zy4k_date_fin 
        ,zy4k.RTDIST as  zy4k_pourcentage_repartition        
        ,get_dateHRA(T2.T2_date_debut, T2.T2_date_fin, T2.T2_numero_dossier, zy4k.DTEF00, zy4k.DTEN00, zy4k.NUDOSS, "start" ) as T3_date_debut
        ,get_dateHRA(T2.T2_date_debut, T2.T2_date_fin, T2.T2_numero_dossier, zy4k.DTEF00, zy4k.DTEN00, zy4k.NUDOSS, "end" ) as T3_date_fin


        FROM  T2
        full join vw_ZY4K zy4k on zy4k.NUDOSS = T2.T2_numero_dossier 
        and join_conditionHRA(T2.T2_date_debut, T2.T2_date_fin, zy4k.DTEF00, zy4k.DTEN00)
        """

spark.sql(query)

// COMMAND ----------

// %sql

// select * from vw_ZY4K 
// -- WHERE NUDOSS = 1
// ORDER BY NUDOSS , DTEF00

// COMMAND ----------

// %sql

// select * from vw_ZY35 
// -- WHERE NUDOSS = 1
// ORDER BY NUDOSS , DTEF00

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.filtres", connectionproperties).createOrReplaceTempView("filtres")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.identification", connectionproperties).createOrReplaceTempView("identification")


// COMMAND ----------

// DBTITLE 1,add filtres, identification
val query = """create or replace temporary view T4 as SELECT 

        T3.T3_numero_dossier as numero_dossier
        ,T3.zy38_date_debut
        ,T3.zy38_date_fin
        ,T3.zy38_etablissement
        ,T3.zy38_motif_la_mutation
        ,T3.zy38_date_effet_la_mutation
        ,T3.zy3b_date_effet
        ,T3.zy3b_date_fin
        ,T3.zy3b_horaires_affectation
        ,T3.zy3b_equivalences_temps_plein
        ,T3.zy3b_date_arrivee_dans_le_poste
        ,T3.zy3b_code_poste
        ,T3.zy3b_identifiant_emploi
        ,T3.zy3b_unite_organisationnelle
        ,T3.zy3b_pourcentage_affectation 
        ,T3.zy35_date_effet
        ,T3.zy35_emploi
        ,T3.zy35_pourcentage_affectation
        ,T3.zy35_libelle_long_reel
        ,T3.zy35_poste
        ,T3.zy35_unite_organisation
        ,T3.zy35_libelle_court_reel
        ,T3.zy4k_centre_cout_1 
        ,T3.zy4k_souscompte_1 
        ,T3.zy4k_date_effet 
        ,T3.zy4k_date_fin 
        ,T3.zy4k_pourcentage_repartition
        ,identification.matricule_hra
        ,identification.matricule_workday
        ,identification.prenom_employe
        ,identification.nom_employe
        ,filtres.date_entree
        ,filtres.date_sortie_administrative  
        ,filtres.type_contrat
        ,filtres.nature
        ,filtres.etablissement
        ,filtres.unite_organisationnelle
        ,filtres.classification
        ,filtres.qualification 
        ,filtres.code_convention_collective
        ,filtres.type_temps_contractuel
        ,filtres.heures_presencemois
        ,filtres.societe
        
        ,get_dateHRA(T3.T3_date_debut, T3.T3_date_fin, T3.T3_numero_dossier, filtres.date_debut_filtre, filtres.date_fin_filtre, filtres.numero_dossier, "start" ) as date_debut_filtre
        ,get_dateHRA(T3.T3_date_debut, T3.T3_date_fin, T3.T3_numero_dossier, filtres.date_debut_filtre, filtres.date_fin_filtre, filtres.numero_dossier, "end" ) as date_fin_filtre


        FROM  T3
        left join identification on identification.numero_dossier = T3.T3_numero_dossier
        left join filtres  on filtres.numero_dossier = T3.T3_numero_dossier 
        and join_conditionHRA(T3.T3_date_debut, T3.T3_date_fin, filtres.date_debut_filtre, filtres.date_fin_filtre)
        
        order by T3_numero_dossier, date_debut_filtre
        """

spark.sql(query)

// COMMAND ----------

// %sql

// select * from T3
// ORDER BY T3_numero_dossier

// COMMAND ----------

// %sql

// select * from T4

// COMMAND ----------

val query_record = """

  select * 
  from T4   
  order by numero_dossier, date_debut_filtre
  
  
 """ 

// COMMAND ----------

val table_inserted = spark.sql(query_record)
table_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.affectation """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

table_inserted.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.affectation", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
table_inserted.unpersist
df_table_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)