// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read ZY38 table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZY38", "domain" -> "career"))

var df_ZY38_read = spark.table("hrabackup_career.ZY38")

df_ZY38_read = gettranscoHRA(df_ZY38_read, df_ref_read, "ZY38")
                                                      
df_ZY38_read.createOrReplaceTempView("vw_ZY38")
df_ZY38_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from vw_ZY38

// COMMAND ----------

// MAGIC %sql
// MAGIC drop table if exists hrabackup_dmt_career.dim_zy38_affectation_etablissement 

// COMMAND ----------

// MAGIC %sql
// MAGIC CREATE TABLE hrabackup_dmt_career.dim_zy38_affectation_etablissement AS
// MAGIC select 
// MAGIC              
// MAGIC NUDOSS as numero_dossier,
// MAGIC DTEF00 as date_debut, 
// MAGIC DTEN00 as date_fin, 
// MAGIC --IDESTA as etablissement 
// MAGIC IDESTA as etablissement
// MAGIC FROM vw_ZY38

// COMMAND ----------

val query_record = """ select 
                        zy38.NUDOSS as numero_dossier,
                        zy38.DTEF00 as date_debut, 
                        zy38.DTEN00 as date_fin, 
                        --IDESTA as etablissement 
                        CONCAT (zy38.IDESTA , " - ", ref.libelle_long) as etablissement
                        FROM vw_ZY38 zy38
                        left join vw_ref ref on ref.nom_colonne = "IDESTA" and zy38.IDESTA = ref.code
                      """ 

// COMMAND ----------

val zy38_affectation_etablissement = spark.sql(query_record)
zy38_affectation_etablissement.cache()  //put the dataframe ont he cache 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.commun_zy38_affectation_etablissement """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

zy38_affectation_etablissement.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.commun_zy38_affectation_etablissement", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
zy38_affectation_etablissement.unpersist
df_ZY38_read.unpersist
df_ref_read.unpersist

// COMMAND ----------

/*dbutils.notebook.exit(return_value)