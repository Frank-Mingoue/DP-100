// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
// df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

var df_zyes_read = spark.sql(" select NUDOSS as numero_dossier, DATENT, DATSOR FROM hrabackup_career.zyes")
 
df_zyes_read = gettranscoHRA(df_zyes_read, df_ref_read, "ZYES")
df_zyes_read.createOrReplaceTempView("zyes")

// COMMAND ----------

// MAGIC %sql 
// MAGIC 
// MAGIC select * from zyes

// COMMAND ----------

