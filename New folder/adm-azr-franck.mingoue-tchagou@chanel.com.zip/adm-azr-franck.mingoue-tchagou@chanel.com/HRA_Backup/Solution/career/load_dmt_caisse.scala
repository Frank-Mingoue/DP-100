// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

//val jdbcurl = getSQLurl()
//val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read ZYWW table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYWW", "domain" -> "career"))

val df_ZYWW_read = spark.table("hrabackup_career.ZYWW")
                                                      
df_ZYWW_read.createOrReplaceTempView("vw_ZYWW")
df_ZYWW_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read ZYCS table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYCS", "domain" -> "career"))

val df_ZYCS_read = spark.table("hrabackup_career.ZYCS")
                                                      
df_ZYCS_read.createOrReplaceTempView("vw_ZYCS")
df_ZYCS_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZYWW 
// MAGIC WHERE NUDOSS = 7674 --and CODREG = 'CFEOPTIJDE'
// MAGIC and DATDEB <= "2019-01-01"  and DATFIN >= '2013-01-31'

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select CODREG , NUDOSS , COUNT(CODREG)
// MAGIC FROM vw_ZYWW
// MAGIC GROUP BY CODREG , NUDOSS
// MAGIC --HAVING COUNT(CODREG) >= 2

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZYCS
// MAGIC WHERE NUDOSS = 7674

// COMMAND ----------

//spark.read.jdbc(jdbcurl, "dbo.vw_ref_degree_level", connectionproperties).createOrReplaceTempView("vw_ref_degree_level")

// COMMAND ----------

val query_record = """ select 
	a.NUDOSS as numero_dossier,
	a.NUDOSP as identifiant_dossier_paie, 
 	a.CODCAI as code_caisse, 
 	a.REGIME as regime_retraite, 
 	a.DEBCAI as date_debut, 
 	a.FINCAI as date_fin, 
 	a.NUMCAI as numero_inscription, 
 	a.IDCONT as identifiant_contrat, 
 	a.MOTRUP as motif_rupture_contrat, 
 	a.MOTSOR as motif_sortie, 
 	a.FLMAJC as temoin_mise_à_jour_manuelle, 
    b.CODREG as code_regime_cotisations,
    from vw_ZYCS a join vw_ZYWW b on a.NUDOSS = b.NUDOSS and and b.DATDEB <= a.DEBCAI  and b.DATFIN >= a.FINCAI
                      """ 

// COMMAND ----------

// MAGIC %sql
// MAGIC --create database hrabackup_dmt_career

// COMMAND ----------

// MAGIC %sql
// MAGIC DROP TABLE IF EXISTS hrabackup_dmt_career.caisse

// COMMAND ----------

// MAGIC %sql
// MAGIC --CREATE TABLE hrabackup_dmt_career.caisse as 
// MAGIC select 
// MAGIC 	a.NUDOSS as numero_dossier,
// MAGIC 	a.NUDOSP as identifiant_dossier_paie, 
// MAGIC  	a.CODCAI as code_caisse, 
// MAGIC  	a.REGIME as regime_retraite, 
// MAGIC  	a.DEBCAI as date_debut, 
// MAGIC  	a.FINCAI as date_fin, 
// MAGIC  	a.NUMCAI as numero_inscription, 
// MAGIC  	a.IDCONT as identifiant_contrat, 
// MAGIC  	a.MOTRUP as motif_rupture_contrat, 
// MAGIC  	a.MOTSOR as motif_sortie, 
// MAGIC  	a.FLMAJC as temoin_mise_a_jour_manuelle, 
// MAGIC     b.CODREG as code_regime_cotisations
// MAGIC     from vw_ZYCS a left join vw_ZYWW b on a.NUDOSS = b.NUDOSS  and b.DATDEB <= a.DEBCAI  and b.DATFIN >= a.FINCAI
// MAGIC     where a.NUDOSS = 7674

// COMMAND ----------



// COMMAND ----------



// COMMAND ----------



// COMMAND ----------

/*val identification_inserted = spark.sql(query_record)
identification_inserted.cache()  //put the dataframe ont he cache */

// COMMAND ----------

/*val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table common.identification """
val res = stmt.execute(query_delete)

connection.close()*/

// COMMAND ----------

/*identification_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "common.identification", connectionproperties)*/

// COMMAND ----------

/*val read_records = df_candidates_read.count().toInt //count the number of read records
val inserted_records = candidates_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0*/

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
/*df_candidates_read.unpersist
candidates_inserted.unpersist*/

// COMMAND ----------

/*dbutils.notebook.exit(return_value)