// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read ZY38 table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYTL", "domain" -> "career"))

val df_ZYTL_read = spark.table("hrabackup_career.ZYTL")
                                                      
df_ZYTL_read.createOrReplaceTempView("vw_ZYTL")
df_ZYTL_read.cache()  //cache the dataframe

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC         select 
// MAGIC         
// MAGIC         zytl.NUDOSS as numero_dossier,
// MAGIC         zytl.DATEFF as date_effet, 
// MAGIC         --zytl.CODTRA as type_temps_contractuel, 
// MAGIC         zytl.NBSTHW as heures_presencesemaine, 
// MAGIC         zytl.NBSTHM as heures_presencemois, 
// MAGIC         zytl.RTSTHR as pourc_h_presencetemps_plein, 
// MAGIC         zytl.NBPDHW as heures_payeessemaine, 
// MAGIC         zytl.NBPDHM as heures_payeesmois, 
// MAGIC         zytl.FORANU as forfait_annuel_en_jours, 
// MAGIC         --zytl.MODHOR as modalite_horaire, 
// MAGIC         zytl.NBSTHD as heures_presencejour, 
// MAGIC         zytl.RTPDHR as pourc_h_payeestemps_plein,
// MAGIC         CONCAT (zytl.CODTRA , " - ", ref.libelle_long) as type_temps_contractuel,
// MAGIC         CONCAT (zytl.MODHOR , " - ", ref2.libelle_long) as modalite_horaire
// MAGIC         
// MAGIC         FROM vw_ZYTL zytl
// MAGIC         left join vw_ref ref on ref.nom_colonne = "CODTRA" and zytl.CODTRA = ref.code
// MAGIC         left join vw_ref ref2 on ref2.nom_colonne = "MODHOR" and zytl.MODHOR = ref2.code

// COMMAND ----------

val query_record = """ select 
        
                        zytl.NUDOSS as numero_dossier,
                        zytl.DATEFF as date_effet, 
                        --zytl.CODTRA as type_temps_contractuel, 
                        zytl.NBSTHW as heures_presencesemaine, 
                        zytl.NBSTHM as heures_presencemois, 
                        zytl.RTSTHR as pourc_h_presencetemps_plein, 
                        zytl.NBPDHW as heures_payeessemaine, 
                        zytl.NBPDHM as heures_payeesmois, 
                        zytl.FORANU as forfait_annuel_en_jours, 
                        --zytl.MODHOR as modalite_horaire, 
                        zytl.NBSTHD as heures_presencejour, 
                        zytl.RTPDHR as pourc_h_payeestemps_plein,
                        CONCAT (zytl.CODTRA , " - ", ref.libelle_long) as type_temps_contractuel,
                        CONCAT (zytl.MODHOR , " - ", ref2.libelle_long) as modalite_horaire

                        FROM vw_ZYTL zytl
                        left join vw_ref ref on ref.nom_colonne = "CODTRA" and zytl.CODTRA = ref.code
                        left join vw_ref ref2 on ref2.nom_colonne = "MODHOR" and zytl.MODHOR = ref2.code
                      """ 

// COMMAND ----------

val zytl_heures_contractuelles = spark.sql(query_record)
zytl_heures_contractuelles.cache()  //put the dataframe ont he cache 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.zytl_heures_contractuelles """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

zytl_heures_contractuelles.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.ZYTL_heures_contractuelles", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
zytl_heures_contractuelles.unpersist
df_ZYTL_read.unpersist
df_ref_read.unpersist

// COMMAND ----------

/*dbutils.notebook.exit(return_value)