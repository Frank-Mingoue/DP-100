// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read career.ZYAF table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZYAF_read = spark.table("hrabackup_career.ZYAF")

//find and get column labels
df_ZYAF_read = gettranscoHRA(df_ZYAF_read, df_ref_read, "ZYAF")
                                                      
df_ZYAF_read.createOrReplaceTempView("vw_ZYAF")
df_ZYAF_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZYAF
// MAGIC --where NBHEUR != 0

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zy3b_affectation", connectionproperties).createOrReplaceTempView("vw_zy3b")


// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zy38_affectation_etablissement", connectionproperties).createOrReplaceTempView("vw_zy38")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zyca_carriere", connectionproperties).createOrReplaceTempView("vw_zyca")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zyco_contrat", connectionproperties).createOrReplaceTempView("vw_zyco")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zyes_entrees_departs", connectionproperties).createOrReplaceTempView("vw_zyes")

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select 
// MAGIC    a.NUDOSS as numero_dossier
// MAGIC   ,a.DATAFF as date_effet
// MAGIC   ,a.DATFIN as date_fin 
// MAGIC   ,a.LEVEL5 as niveau_5 
// MAGIC   ,a.LEVEL7 as niveau_7
// MAGIC   
// MAGIC   ,c.id as id_zyca_carriere
// MAGIC --   ,c.date_debut as date_debut_carriere
// MAGIC --   ,c.date_fin as date_fin_carriere
// MAGIC 
// MAGIC   ,d.id as id_zy3b_unite_organisationelle
// MAGIC --   ,d.date_effet as as date_effet_unite_org
// MAGIC --   ,d.date_fin   as date_fin_unite_org 
// MAGIC 
// MAGIC   ,e.id as id_zy38_etablissement
// MAGIC --   ,e.date_debut as date_debut_etablissment
// MAGIC --   ,e.date_fin as date_fin_etablissement
// MAGIC 
// MAGIC   ,f.id as id_zyes_entrees_departs
// MAGIC --   ,f.date_entree                    
// MAGIC --   ,f.date_sortie_administrative
// MAGIC 
// MAGIC   ,g.id as id_zyco_contrat
// MAGIC --   ,g.date_debut_contrat
// MAGIC --   ,g.date_fin_contrat
// MAGIC 
// MAGIC   --,h.id as id_zytl_heures_contractuelles 
// MAGIC   
// MAGIC   from vw_ZYAF a
// MAGIC   left join vw_zyca c on c.numero_dossier = a.NUDOSS and  a.DATAFF >= c.date_debut  and a.DATAFF <= c.date_fin
// MAGIC   left join vw_zyco g on g.numero_dossier = a.NUDOSS and  a.DATAFF >= g.date_debut_contrat  and a.DATAFF <= g.date_fin_contrat 
// MAGIC   left join vw_zy38 e on e.numero_dossier = a.NUDOSS and  a.DATAFF >= e.date_debut  and a.DATAFF <= e.date_fin
// MAGIC   left join vw_zy3b d on d.numero_dossier = a.NUDOSS and  a.DATAFF >= d.date_effet and a.DATAFF <= d.date_fin
// MAGIC   left join vw_zyes f on f.numero_dossier = a.NUDOSS and  a.DATAFF >= f.date_entree and a.DATAFF <= f.date_sortie_administrative
// MAGIC   --left join vw_zytl h on h.numero_dossier = a.NUDOSS and  a.DATAFF >= h. and a.DATAFF <= h.
// MAGIC   
// MAGIC   
// MAGIC   --where f.id is  null
// MAGIC   order by a.NUDOSS , a.DATAFF 
// MAGIC   

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZYAF 
// MAGIC where NUDOSS = 10580
// MAGIC order by DATAFF

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_zy38 
// MAGIC where numero_dossier = 10580
// MAGIC --order by date_debut

// COMMAND ----------

val query_record = """select 
  a.NUDOSS as numero_dossier
  ,a.DATAFF as date_effet
  ,a.DATFIN as date_fin 
  ,a.LEVEL5 as niveau_5 
  ,a.LEVEL7 as niveau_7
  ,c.id as id_zyca_carriere
  ,d.id as id_zy3b_unite_organisationelle
  ,e.id as id_zy38_etablissement
  ,f.id as id_zyes_entrees_departs
  ,g.id as id_zyco_contrat
  --,h.id as id_zytl_heures_contractuelles 
  
  from vw_ZYAF a
  left join vw_zyca c on c.numero_dossier = a.NUDOSS and  a.DATAFF >= c.date_debut  and a.DATAFF <= c.date_fin
  left join vw_zyco g on g.numero_dossier = a.NUDOSS and  a.DATAFF >= g.date_debut_contrat  and a.DATAFF <= g.date_fin_contrat 
  left join vw_zy38 e on e.numero_dossier = a.NUDOSS and  a.DATAFF >= e.date_debut  and a.DATAFF <= e.date_fin
  left join vw_zy3b d on d.numero_dossier = a.NUDOSS and  a.DATAFF >= d.date_effet and a.DATAFF <= d.date_fin
  left join vw_zyes f on f.numero_dossier = a.NUDOSS and  a.DATAFF >= f.date_entree and a.DATAFF <= f.date_sortie_administrative
  --left join vw_zytl h on h.numero_dossier = a.NUDOSS and  a.DATAFF >= h. and a.DATAFF <= h.
  
 """ 

// COMMAND ----------

val ZYAF_inserted = spark.sql(query_record)
ZYAF_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.ZYAF_affectation_consolidee """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

ZYAF_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.ZYAF_affectation_consolidee", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
ZYAF_inserted.unpersist
df_ZYAF_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)