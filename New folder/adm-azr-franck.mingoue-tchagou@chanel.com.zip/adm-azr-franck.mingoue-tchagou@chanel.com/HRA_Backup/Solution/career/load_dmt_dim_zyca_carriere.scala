// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read dim_zyca_carriere  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYCA", "domain" -> "career"))

var df_ZYCA_read = spark.table("hrabackup_career.ZYCA")

df_ZYCA_read = gettranscoHRA(df_ZYCA_read, df_ref_read, "ZYCA")

                                                      
df_ZYCA_read.createOrReplaceTempView("vw_ZYCA")
df_ZYCA_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC drop table if exists hrabackup_dmt_career.dim_zyca_carriere;
// MAGIC create table  hrabackup_dmt_career.dim_zyca_carriere as 
// MAGIC select 
// MAGIC zyca.NUDOSS as numero_dossier,
// MAGIC zyca.DATEFF as date_debut, 
// MAGIC zyca.DATFIN as date_fin,
// MAGIC QUALIF as qualification, 
// MAGIC CLASSI as classification, 
// MAGIC COCONV as code_convention_collective
// MAGIC FROM vw_ZYCA zyca

// COMMAND ----------

val query_record = """ select 
                        zyca.NUDOSS as numero_dossier,
                        zyca.DATEFF as date_debut, 
                        zyca.DATFIN as date_fin,
                        --QUALIF as qualification, 
                        --CLASSI as classification, 
                        --COCONV as code_convention_collective,
                        CONCAT (zyca.QUALIF , " - ", ref.libelle_long) as qualification,
                        CONCAT (zyca.CLASSI , " - ", ref2.libelle_long) as classification,
                        CONCAT (zyca.COCONV , " - ", ref3.libelle_long) as code_convention_collective
                        FROM vw_ZYCA zyca
                        left join vw_ref ref on ref.nom_colonne = "QUALIF" and zyca.QUALIF = ref.code
                        left join vw_ref ref2 on ref2.nom_colonne = "CLASSI" and zyca.CLASSI = ref2.code
                        left join vw_ref ref3 on ref3.nom_colonne = "COCONV" and zyca.COCONV = ref3.code
                      """ 

// COMMAND ----------

val zyca_carriere_inserted = spark.sql(query_record)
zyca_carriere_inserted.cache()  //put the dataframe ont he cache */

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.commun_zyca_carriere """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

zyca_carriere_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.commun_zyca_carriere", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
zyca_carriere_inserted.unpersist
df_ZYCA_read.unpersist
df_ref_read.unpersist

// COMMAND ----------

/*dbutils.notebook.exit(return_value)