// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

// DBTITLE 1,identification
display(spark.read.jdbc(jdbcurl, "career.identification", connectionproperties))

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.identification", connectionproperties).count()

// COMMAND ----------

// DBTITLE 1,ZYDA_absences_decoupees_droits
display(spark.read.jdbc(jdbcurl, "absences.ZYDA_absences_decoupees_droits", connectionproperties))

// COMMAND ----------

// DBTITLE 1,ZYAF_affectation_consolidee
display(spark.read.jdbc(jdbcurl, "career.ZYAF_affectation_consolidee", connectionproperties))

// COMMAND ----------

// DBTITLE 1,absences.ZYDV_conges_payes
display(spark.read.jdbc(jdbcurl, "absences.ZYDV_conges_payes", connectionproperties))

// COMMAND ----------

// DBTITLE 1,absences.ZYAG_absences
display(spark.read.jdbc(jdbcurl, "absences.ZYAG_absences", connectionproperties))

// COMMAND ----------

// DBTITLE 1,absences.ZYDV_conges_payes
display(spark.read.jdbc(jdbcurl, "absences.ZYDV_conges_payes", connectionproperties))

// COMMAND ----------

// DBTITLE 1,absences.compte_epargne
display(spark.read.jdbc(jdbcurl, "absences.compte_epargne", connectionproperties))

// COMMAND ----------

spark.read.jdbc(jdbcurl, "absences.compte_epargne", connectionproperties).count()

// COMMAND ----------

display(spark.read.jdbc(jdbcurl, "career.commun_zy38_affectation_etablissement", connectionproperties))

// COMMAND ----------

display(spark.read.jdbc(jdbcurl, "career.commun_zy3b_affectation", connectionproperties))

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zyca_carriere", connectionproperties).count()

// COMMAND ----------

display(spark.read.jdbc(jdbcurl, "absences.ZYDA_absences_decoupees_droits", connectionproperties))

// COMMAND ----------

display(spark.read.jdbc(jdbcurl, "absences.ZYAG_absences", connectionproperties))

// COMMAND ----------

