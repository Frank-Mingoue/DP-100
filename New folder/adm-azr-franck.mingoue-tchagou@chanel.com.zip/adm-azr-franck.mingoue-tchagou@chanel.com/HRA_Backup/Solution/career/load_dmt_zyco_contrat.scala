// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read dim_zyco_contrat  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYCO", "domain" -> "career"))

val df_ZYCO_read = spark.table("hrabackup_career.ZYCO")
                                                      
df_ZYCO_read.createOrReplaceTempView("vw_ZYCO")
df_ZYCO_read.cache()  //cache the dataframe

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select 
// MAGIC 	zyco.NUDOSS as numero_dossier,
// MAGIC 	zyco.DATCON as date_debut_contrat, 
// MAGIC  	zyco.DATFIN as date_fin_contrat, 
// MAGIC  	--zyco.TYPCON as type_contrat, 
// MAGIC  	--zyco.NATCON as nature, 
// MAGIC  	zyco.DATPRE as date_fin_presumee, 
// MAGIC  	zyco.FINESS as fin_periode_essai, 
// MAGIC  	zyco.NBHEUC as nombre_heures_contrat, 
// MAGIC  	zyco.MOISCL as duree_clause_en_mois, 
// MAGIC  	zyco.MONTAN as montant_mensuel, 
// MAGIC  	zyco.POURCE as pourcentage_mensuel, 
// MAGIC  	--zyco.CONTRA as clause_contractuelle, 
// MAGIC  	--zyco.CLLEVE as clause_levee,
// MAGIC     CONCAT (zyco.TYPCON , " - ", ref.libelle_long) as type_contrat,
// MAGIC     CONCAT (zyco.NATCON , " - ", ref2.libelle_long) as nature,
// MAGIC     CONCAT (zyco.CONTRA , " - ", ref3.libelle_long) as clause_contractuelle,
// MAGIC     CONCAT (zyco.CLLEVE , " - ", ref4.libelle_long) as clause_levee
// MAGIC     FROM vw_ZYCO zyco
// MAGIC     left join vw_ref ref on ref.nom_colonne = "TYPCON" and zyco.TYPCON = ref.code
// MAGIC     left join vw_ref ref2 on ref2.nom_colonne = "NATCON" and zyco.NATCON = ref2.code
// MAGIC     left join vw_ref ref3 on ref3.nom_colonne = "CONTRA" and zyco.CONTRA = ref3.code
// MAGIC     left join vw_ref ref4 on ref4.nom_colonne = "CLLEVE" and zyco.CLLEVE = ref4.code

// COMMAND ----------

val query_record = """select 
                        zyco.NUDOSS as numero_dossier,
                        zyco.DATCON as date_debut_contrat, 
                        zyco.DATFIN as date_fin_contrat, 
                        --zyco.TYPCON as type_contrat, 
                        --zyco.NATCON as nature, 
                        zyco.DATPRE as date_fin_presumee, 
                        zyco.FINESS as fin_periode_essai, 
                        zyco.NBHEUC as nombre_heures_contrat, 
                        zyco.MOISCL as duree_clause_en_mois, 
                        zyco.MONTAN as montant_mensuel, 
                        zyco.POURCE as pourcentage_mensuel, 
                        --zyco.CONTRA as clause_contractuelle, 
                        --zyco.CLLEVE as clause_levee,
                        CONCAT (zyco.TYPCON , " - ", ref.libelle_long) as type_contrat,
                        CONCAT (zyco.NATCON , " - ", ref2.libelle_long) as nature,
                        CONCAT (zyco.CONTRA , " - ", ref3.libelle_long) as clause_contractuelle,
                        CONCAT (zyco.CLLEVE , " - ", ref4.libelle_long) as clause_levee
                        FROM vw_ZYCO zyco
                        left join vw_ref ref on ref.nom_colonne = "TYPCON" and zyco.TYPCON = ref.code
                        left join vw_ref ref2 on ref2.nom_colonne = "NATCON" and zyco.NATCON = ref2.code
                        left join vw_ref ref3 on ref3.nom_colonne = "CONTRA" and zyco.CONTRA = ref3.code
                        left join vw_ref ref4 on ref4.nom_colonne = "CLLEVE" and zyco.CLLEVE = ref4.code
                      """ 

// COMMAND ----------

val zyco_contrat_inserted = spark.sql(query_record)
zyco_contrat_inserted.cache()  //put the dataframe ont he cache */

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.zyco_contrat """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

zyco_contrat_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.zyco_contrat", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_ZYCO_read.unpersist
zyco_contrat_inserted.unpersist
df_ref_read.unpersist

// COMMAND ----------

/*dbutils.notebook.exit(return_value)