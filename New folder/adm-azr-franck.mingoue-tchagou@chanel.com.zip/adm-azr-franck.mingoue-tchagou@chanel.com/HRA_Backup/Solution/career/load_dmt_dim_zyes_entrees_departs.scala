// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read ZYES table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYES", "domain" -> "career"))

val df_ZYES_read = spark.table("hrabackup_career.ZYES")
                                                      
df_ZYES_read.createOrReplaceTempView("vw_ZYES")
df_ZYES_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZYES

// COMMAND ----------

//spark.read.jdbc(jdbcurl, "dbo.vw_ref_degree_level", connectionproperties).createOrReplaceTempView("vw_ref_degree_level")

// COMMAND ----------

val query_record = """ select 
                        NUDOSS as numero_dossier, 
                        DATENT as date_entree,                   
                        DATSOR as date_sortie_administrative
                        --PHYSOR as date_sortie_physique, 
                        FROM vw_ZYES
                      """ 

// COMMAND ----------

// MAGIC %sql
// MAGIC --create database hrabackup_dmt_career

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC drop table if exists hrabackup_dmt_career.dim_zyes_entrees_departs

// COMMAND ----------

// MAGIC %sql
// MAGIC CREATE TABLE hrabackup_dmt_career.dim_zyes_entrees_departs as 
// MAGIC select 
// MAGIC NUDOSS as numero_dossier, 
// MAGIC DATENT as date_entree,                   
// MAGIC DATSOR as date_sortie_administrative 
// MAGIC --PHYSOR as date_sortie_physique, 
// MAGIC FROM vw_ZYES

// COMMAND ----------

val zyes_entrees_departs_inserted = spark.sql(query_record)
zyes_entrees_departs_inserted.cache()  //put the dataframe ont he cache */

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.commun_zyes_entrees_departs """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

zyes_entrees_departs_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.commun_zyes_entrees_departs", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_ZYES_read.unpersist
zyes_entrees_departs_inserted.unpersist

// COMMAND ----------

/*dbutils.notebook.exit(return_value)