// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read dim_zyco_contrat  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZY3B", "domain" -> "career"))

var df_ZY3B_read = spark.table("hrabackup_career.ZY3B")

df_ZY3B_read = gettranscoHRA(df_ZY3B_read, df_ref_read, "ZY3B")

                                                      
df_ZY3B_read.createOrReplaceTempView("vw_ZY3B")
df_ZY3B_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZY3B

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT NUDOSS , DTEF00 , DTEN00 , 

// COMMAND ----------

//spark.read.jdbc(jdbcurl, "dbo.vw_ref_degree_level", connectionproperties).createOrReplaceTempView("vw_ref_degree_level")

// COMMAND ----------

val query_record = """ select 
                    a.NUDOSS as numero_dossier,
                    a.DTEF00 as date_effet, 
                    a.DTEN00 as date_fin,                     
                    a.IDOU00 as unite_organisationnelle,
                    b.id as id_zy38_etablissement
                    FROM vw_ZY3B a
                    left join vw_zy38 b 
                    on a.NUDOSS = b.numero_dossier and a.DTEF00 >= b.date_debut and  a.DTEF00 <= b.date_fin
                    where a.NUDOSS is not null
                      """ 

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zy38_affectation_etablissement", connectionproperties).createOrReplaceTempView("vw_zy38")

// COMMAND ----------

// MAGIC %sql
// MAGIC --create database hrabackup_dmt_career

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC drop table if exists hrabackup_dmt_career.dim_zy3b_affectation

// COMMAND ----------

// MAGIC %sql
// MAGIC CREATE TABLE hrabackup_dmt_career.dim_zy3b_affectation as 
// MAGIC select 
// MAGIC a.NUDOSS as numero_dossier,
// MAGIC a.DTEF00 as date_effet, 
// MAGIC a.DTEN00 as date_fin,                     
// MAGIC a.IDOU00 as unite_organisationnelle,
// MAGIC b.id as id_zy38_etablissement
// MAGIC FROM vw_ZY3B a
// MAGIC left join vw_zy38 b 
// MAGIC on a.NUDOSS = b.numero_dossier and a.DTEF00 >= b.date_debut and  a.DTEF00 <= b.date_fin
// MAGIC where a.NUDOSS is not null
// MAGIC --order by 1

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from hrabackup_dmt_career.dim_zy3b_affectation
// MAGIC where numero_dossier is null

// COMMAND ----------

val zy3b_affectation_inserted = spark.sql(query_record)
zy3b_affectation_inserted.cache()  //put the dataframe ont he cache */

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.commun_zy3b_affectation """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

zy3b_affectation_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.commun_zy3b_affectation", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
zy3b_affectation_inserted.unpersist
df_ZY3B_read.unpersist

// COMMAND ----------

/*dbutils.notebook.exit(return_value)