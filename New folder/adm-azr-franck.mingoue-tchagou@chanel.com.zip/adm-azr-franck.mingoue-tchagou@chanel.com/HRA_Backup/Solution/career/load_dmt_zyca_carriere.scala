// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read dim_zyca_carriere  table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYCA", "domain" -> "career"))

val df_ZYCA_read = spark.table("hrabackup_career.ZYCA")
                                                      
df_ZYCA_read.createOrReplaceTempView("vw_ZYCA")
df_ZYCA_read.cache()  //cache the dataframe

// COMMAND ----------

val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZYCA

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ref
// MAGIC order by nom_colonne, code desc

// COMMAND ----------

//spark.read.jdbc(jdbcurl, "dbo.vw_ref_degree_level", connectionproperties).createOrReplaceTempView("vw_ref_degree_level")

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select 
// MAGIC zyca.NUDOSS as numero_dossier,
// MAGIC zyca.DATEFF as date_debut, 
// MAGIC zyca.DATFIN as date_fin, 
// MAGIC --zyca.QUALIF as qualification, 
// MAGIC --zyca.CLASSI as classification, 
// MAGIC --zyca.COCONV as code_convention_collective, 
// MAGIC --zyca.TYPREG as type_regime_cotisation_retraite, 
// MAGIC zyca.CHBASE as coefficient_base_chimie, 
// MAGIC zyca.CHSPEC as coefficient_specialite_chimie, 
// MAGIC zyca.COGRPE as groupe_couture, 
// MAGIC zyca.CONIVE as niveau_couture, 
// MAGIC --zyca.EXTCF1 as temoin_1, 
// MAGIC zyca.CHPERS as coefficient_personnel_chimie, 
// MAGIC zyca.CHNIVE as niveau_chimie, 
// MAGIC zyca.CHECHL as echelon_chimie,
// MAGIC CONCAT (zyca.QUALIF , " - ", ref.libelle_long) as qualification,
// MAGIC CONCAT (zyca.CLASSI , " - ", ref2.libelle_long) as classification,
// MAGIC CONCAT (zyca.COCONV , " - ", ref3.libelle_long) as code_convention_collective,
// MAGIC CONCAT (zyca.TYPREG , " - ", ref4.libelle_long) as type_regime_cotisation_retraite,
// MAGIC CONCAT (zyca.EXTCF1 , " - ", ref5.libelle_long) as temoin_1
// MAGIC 
// MAGIC FROM vw_ZYCA zyca 
// MAGIC left join vw_ref ref on ref.nom_colonne = "QUALIF" and zyca.QUALIF = ref.code
// MAGIC left join vw_ref ref2 on ref2.nom_colonne = "CLASSI" and zyca.CLASSI = ref2.code
// MAGIC left join vw_ref ref3 on ref3.nom_colonne = "COCONV" and zyca.COCONV = ref3.code
// MAGIC left join vw_ref ref4 on ref4.nom_colonne = "TYPREG" and zyca.TYPREG = ref4.code
// MAGIC left join vw_ref ref5 on ref5.nom_colonne = "EXTCF1" and zyca.EXTCF1 = ref5.code

// COMMAND ----------

val query_record = """ 

                select 
                zyca.NUDOSS as numero_dossier,
                zyca.DATEFF as date_debut, 
                zyca.DATFIN as date_fin, 
                --zyca.QUALIF as qualification, 
                --zyca.CLASSI as classification, 
                --zyca.COCONV as code_convention_collective, 
                --zyca.TYPREG as type_regime_cotisation_retraite, 
                zyca.CHBASE as coefficient_base_chimie, 
                zyca.CHSPEC as coefficient_specialite_chimie, 
                zyca.COGRPE as groupe_couture, 
                zyca.CONIVE as niveau_couture, 
                --zyca.EXTCF1 as temoin_1, 
                zyca.CHPERS as coefficient_personnel_chimie, 
                zyca.CHNIVE as niveau_chimie, 
                zyca.CHECHL as echelon_chimie,
                CONCAT (zyca.QUALIF , " - ", ref.libelle_long) as qualification,
                CONCAT (zyca.CLASSI , " - ", ref2.libelle_long) as classification,
                CONCAT (zyca.COCONV , " - ", ref3.libelle_long) as code_convention_collective,
                CONCAT (zyca.TYPREG , " - ", ref4.libelle_long) as type_regime_cotisation_retraite,
                CONCAT (zyca.EXTCF1 , " - ", ref5.libelle_long) as temoin_1

                FROM vw_ZYCA zyca 
                left join vw_ref ref on ref.nom_colonne = "QUALIF" and zyca.QUALIF = ref.code
                left join vw_ref ref2 on ref2.nom_colonne = "CLASSI" and zyca.CLASSI = ref2.code
                left join vw_ref ref3 on ref3.nom_colonne = "COCONV" and zyca.COCONV = ref3.code
                left join vw_ref ref4 on ref4.nom_colonne = "TYPREG" and zyca.TYPREG = ref4.code
                left join vw_ref ref5 on ref5.nom_colonne = "EXTCF1" and zyca.EXTCF1 = ref5.code
                      """ 

// COMMAND ----------

val zyca_carriere_inserted = spark.sql(query_record)
zyca_carriere_inserted.cache()  //put the dataframe ont he cache */

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table career.zyca_carriere """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

zyca_carriere_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "career.zyca_carriere", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
zyca_carriere_inserted.unpersist
df_ZYCA_read.unpersist
df_ref_read.unpersist

// COMMAND ----------

/*dbutils.notebook.exit(return_value)