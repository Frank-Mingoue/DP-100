// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

val table = dbutils.widgets.get("table")
val domain =  dbutils.widgets.get("doamin")

// COMMAND ----------

// DBTITLE 1,init and read absences.ZYE6 table
// dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> table, "domain" -> domain))

var df_table_read = spark.table(s"hrabackup_${domain}.${table}")
                                                      
df_table_read.createOrReplaceTempView("vw_table")
df_table_read.cache()  //cache the dataframe


// COMMAND ----------

display(df_table_read)

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC -- select  * from vw_table where CODSOC = "F17"

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC -- select distinct CODSOC from vw_table --WHERE CODSOC = "F17"

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC -- select distinct CODSOC, LIBSOC from vw_table order by CODSOC

// COMMAND ----------

// dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "referentiel", "domain" -> "common"))
var df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

val df_labelled = gettranscoHRA(df_table_read, df_ref_read, table)
display(df_labelled.orderBy("NUDOSS"))

// COMMAND ----------

display(df_labelled.select("CLASSI").distinct())

// COMMAND ----------

display(df_ref_read)

// COMMAND ----------

val df_filter = df_table_read.filter("NUDOSS == 2474847")
display(df_filter)

// COMMAND ----------

val df_labelled = gettranscoHRA(df_filter, df_ref_read, table)
display(df_labelled.orderBy("NUDOSS"))

// val list_ref_columns = df_ref_read.select(col("nom_colonne")).distinct.collect().map(_(0)).toList
// for (column <- df_table_read.columns.toList ){
//     if (list_ref_columns.contains(column)){
//     val df_ref_filtered = df_ref_read.filter(col("nom_colonne") === column).select("libelle_long", "code")
      
//       df_table_read = df_table_read.join(df_ref_filtered, df_table_read.col(column) === df_ref_filtered.col("code"), "left")
//       .withColumn(column, when(col(column).isNull, col(column)).otherwise(concat (col(column) ,lit(" - "), col("libelle_long"))))
//       .drop("libelle_long", "code")  
    
//     } 
// }

//  display(df_table_read)