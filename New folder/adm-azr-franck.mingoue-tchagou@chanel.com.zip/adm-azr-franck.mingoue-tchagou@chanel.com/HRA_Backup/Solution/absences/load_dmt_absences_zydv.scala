// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read common.referentiel table
val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read absences.ZYDV table
///dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE6", "domain" -> "absences"))

var df_ZYDV_read = spark.table("hrabackup_absences.ZYDV")

//find and get column labels
df_ZYDV_read = gettranscoHRA(df_ZYDV_read, df_ref_read, "ZYDV")
                                                      
df_ZYDV_read.createOrReplaceTempView("vw_ZYDV")
df_ZYDV_read.cache()  //cache the dataframe


// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zy3b_affectation", connectionproperties).createOrReplaceTempView("vw_zy3b")


// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zy38_affectation_etablissement", connectionproperties).createOrReplaceTempView("vw_zy38")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zyca_carriere", connectionproperties).createOrReplaceTempView("vw_zyca")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zyco_contrat", connectionproperties).createOrReplaceTempView("vw_zyco")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zyes_entrees_departs", connectionproperties).createOrReplaceTempView("vw_zyes")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zytl_heures_contractuelles", connectionproperties).createOrReplaceTempView("vw_zytl")

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select 
// MAGIC    
// MAGIC   a.NUDOSS as numero_dossier,
// MAGIC   a.CODCON as code_conge, 
// MAGIC   a.ANNEES as annee_reference, 
// MAGIC   a.IDZYES as identifiant_entreesortie, 
// MAGIC   a.DATDEB as date_debut_consommation, 
// MAGIC   a.DATFIN as date_fin_consommation, 
// MAGIC   a.DEBACQ as date_debut_acquisition, 
// MAGIC   a.FINACQ as date_fin_acquisition, 
// MAGIC   a.ACQUIA as droits_acquis, 
// MAGIC   a.REPPRE as report_annee_precedente, 
// MAGIC   a.REPECR as droits_ecretes, 
// MAGIC   a.REPSUI as report_annee_suivante, 
// MAGIC   a.PAYESS as droits_payes, 
// MAGIC   a.DRTPRI as droits_pris, 
// MAGIC   a.PRICH1 as pris_pendant_chevauchement_1, 
// MAGIC   a.PRICH2 as pris_pendant_chevauchement_2, 
// MAGIC   a.RESTAN as droits_restants, 
// MAGIC   a.AJUST1 as ajustement_manuel_1, 
// MAGIC   a.MOTIF1 as motif_ajustement_1, 
// MAGIC   a.AJUST2 as ajustement_manuel_2, 
// MAGIC   a.MOTIF2 as motif_ajustement_2, 
// MAGIC   a.AJUST3 as ajustement_manuel_3, 
// MAGIC   a.MOTIF3 as motif_ajustement_manuel_3, 
// MAGIC   a.AJUST4 as ajustement_manuel_4, 
// MAGIC   a.MOTIF4 as motif_ajustement_manuel_4,
// MAGIC   c.id as id_zyca_carriere,
// MAGIC   d.id as id_zy3b_unite_organisationelle,
// MAGIC   e.id as id_zy38_etablissement,
// MAGIC   f.id as id_zyes_entrees_departs,
// MAGIC   g.id as id_zyco_contrat,
// MAGIC   h.id as id_zytl_heures_contractuelles 
// MAGIC   
// MAGIC   from vw_ZYDV a
// MAGIC   left join vw_zyca c on c.numero_dossier = a.NUDOSS and  a.DATDEB >= c.date_debut and a.DATFIN <= c.date_fin 
// MAGIC   left join vw_zyco g on g.numero_dossier = a.NUDOSS and  a.DATDEB >= g.date_debut_contrat and a.DATFIN <= g.date_fin_contrat 
// MAGIC   left join vw_zy38 e on e.numero_dossier = a.NUDOSS and  a.DATDEB >= e.date_debut and a.DATFIN <= e.date_fin
// MAGIC   left join vw_zy3b d on d.numero_dossier = a.NUDOSS and  a.DATDEB >= d.date_effet and a.DATFIN <= d.date_fin
// MAGIC   left join vw_zyes f on f.numero_dossier = a.NUDOSS and  a.DATDEB >= f.date_entree and a.DATFIN <= f.date_sortie_administrative
// MAGIC    left join vw_zytl h on h.numero_dossier = g.numero_dossier and  h.date_effet >= g.date_debut_contrat and h.date_effet <= g.date_debut_contrat
// MAGIC   
// MAGIC   
// MAGIC   --where c.id is null
// MAGIC   --order by b.NUDOSS , b.TYPCPT, b.DTOPER 
// MAGIC   

// COMMAND ----------

val query_record = """select 
  a.NUDOSS as numero_dossier,
  a.CODCON as code_conge, 
  a.ANNEES as annee_reference, 
  a.IDZYES as identifiant_entreesortie, 
  a.DATDEB as date_debut_consommation, 
  a.DATFIN as date_fin_consommation, 
  a.DEBACQ as date_debut_acquisition, 
  a.FINACQ as date_fin_acquisition, 
  a.ACQUIA as droits_acquis, 
  a.REPPRE as report_annee_precedente, 
  a.REPECR as droits_ecretes, 
  a.REPSUI as report_annee_suivante, 
  a.PAYESS as droits_payes, 
  a.DRTPRI as droits_pris, 
  a.PRICH1 as pris_pendant_chevauchement_1, 
  a.PRICH2 as pris_pendant_chevauchement_2, 
  a.RESTAN as droits_restants, 
  a.AJUST1 as ajustement_manuel_1, 
  a.MOTIF1 as motif_ajustement_1, 
  a.AJUST2 as ajustement_manuel_2, 
  a.MOTIF2 as motif_ajustement_2, 
  a.AJUST3 as ajustement_manuel_3, 
  a.MOTIF3 as motif_ajustement_manuel_3, 
  a.AJUST4 as ajustement_manuel_4, 
  a.MOTIF4 as motif_ajustement_manuel_4,
  c.id as id_zyca_carriere,
  d.id as id_zy3b_unite_organisationelle,
  e.id as id_zy38_etablissement,
  f.id as id_zyes_entrees_departs,
  g.id as id_zyco_contrat,
  h.id as id_zytl_heures_contractuelles 
  
  from vw_ZYDV a
  left join vw_zyca c on c.numero_dossier = a.NUDOSS and  a.DATDEB >= c.date_debut and a.DATFIN <= c.date_fin 
  left join vw_zyco g on g.numero_dossier = a.NUDOSS and  a.DATDEB >= g.date_debut_contrat and a.DATFIN <= g.date_fin_contrat 
  left join vw_zy38 e on e.numero_dossier = a.NUDOSS and  a.DATDEB >= e.date_debut and a.DATFIN <= e.date_fin
  left join vw_zy3b d on d.numero_dossier = a.NUDOSS and  a.DATDEB >= d.date_effet and a.DATFIN <= d.date_fin
  left join vw_zyes f on f.numero_dossier = a.NUDOSS and  a.DATDEB >= f.date_entree and a.DATFIN <= f.date_sortie_administrative
   left join vw_zytl h on h.numero_dossier = g.numero_dossier and  h.date_effet >= g.date_debut_contrat and h.date_effet <= g.date_debut_contrat
  
 """ 

// COMMAND ----------

val ZYDV_inserted = spark.sql(query_record)
ZYDV_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table absences.ZYDV_conges_payes """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

ZYDV_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "absences.ZYDV_conges_payes", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
ZYDV_inserted.unpersist
df_ZYDV_read.unpersist
df_ref_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)

// COMMAND ----------

