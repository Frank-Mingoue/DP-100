// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read common.referentiel table
val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read absences.ZYAG table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

var df_ZYAG_read = spark.table("hrabackup_absences.ZYAG")

//find and get column labels
df_ZYAG_read = gettranscoHRA(df_ZYAG_read, df_ref_read, "ZYAG")
                                                      
df_ZYAG_read.createOrReplaceTempView("vw_ZYAG")
df_ZYAG_read.cache()  //cache the dataframe

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zy3b_affectation", connectionproperties).createOrReplaceTempView("vw_zy3b")


// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zy38_affectation_etablissement", connectionproperties).createOrReplaceTempView("vw_zy38")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zyca_carriere", connectionproperties).createOrReplaceTempView("vw_zyca")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zyco_contrat", connectionproperties).createOrReplaceTempView("vw_zyco")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zyes_entrees_departs", connectionproperties).createOrReplaceTempView("vw_zyes")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zytl_heures_contractuelles", connectionproperties).createOrReplaceTempView("vw_zytl")

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select 
// MAGIC   a.NUDOSS as numero_dossier,
// MAGIC   a.DATDEB as date_debut, 
// MAGIC   a.MOTIFA as motif, 
// MAGIC   a.HRSDEB as heure_debut, 
// MAGIC   a.DATFIN as date_fin, 
// MAGIC   a.HRSFIN as heure_fin, 
// MAGIC   a.TEMDEB as temoin_midi_debut, 
// MAGIC   a.TEMFIN as temoin_midi_fin, 
// MAGIC   a.GESTIO as temoin_gestion, 
// MAGIC   a.PROLON as temoin_prolongation, 
// MAGIC   a.NBHEUR as nombre_heures, 
// MAGIC   a.IDLVSR as motif_situation_resultant, 
// MAGIC   a.IDRTST as situation_au_retour, 
// MAGIC   a.IDRTSC as categorie_situation_au_retour, 
// MAGIC   a.GPRTSC as cat_situation_au_retour_redefiniee, 
// MAGIC   a.IDRTSR as motif_situation_au_retour, 
// MAGIC   a.NAABPD as payenon_paye,
// MAGIC   c.id as id_zyca_carriere,
// MAGIC   d.id as id_zy3b_unite_organisationelle,
// MAGIC   e.id as id_zy38_etablissement,
// MAGIC   f.id as id_zyes_entrees_departs,
// MAGIC   g.id as id_zyco_contrat,
// MAGIC   h.id as id_zytl_heures_contractuelles 
// MAGIC   
// MAGIC   from vw_ZYAG a
// MAGIC   left join vw_zyca c on c.numero_dossier = a.NUDOSS and  a.DATDEB >= c.date_debut and a.DATFIN <= c.date_fin 
// MAGIC   left join vw_zyco g on g.numero_dossier = a.NUDOSS and  a.DATDEB >= g.date_debut_contrat and a.DATFIN <= g.date_fin_contrat 
// MAGIC   left join vw_zy38 e on e.numero_dossier = a.NUDOSS and  a.DATDEB >= e.date_debut and a.DATFIN <= e.date_fin
// MAGIC   left join vw_zy3b d on d.numero_dossier = a.NUDOSS and  a.DATDEB >= d.date_effet and a.DATFIN <= d.date_fin
// MAGIC   left join vw_zyes f on f.numero_dossier = a.NUDOSS and  a.DATDEB >= f.date_entree and a.DATFIN <= f.date_sortie_administrative
// MAGIC   left join vw_zytl h on h.numero_dossier = g.numero_dossier and  h.date_effet >= g.date_debut_contrat and h.date_effet <= g.date_debut_contrat
// MAGIC   
// MAGIC   
// MAGIC   --where c.id is null
// MAGIC   --order by b.NUDOSS , b.TYPCPT, b.DTOPER 
// MAGIC   

// COMMAND ----------

val query_record = """select 
  a.NUDOSS as numero_dossier,
  a.DATDEB as date_debut, 
  a.MOTIFA as motif, 
  a.HRSDEB as heure_debut, 
  a.DATFIN as date_fin, 
  a.HRSFIN as heure_fin, 
  a.TEMDEB as temoin_midi_debut, 
  a.TEMFIN as temoin_midi_fin, 
  a.GESTIO as temoin_gestion, 
  a.PROLON as temoin_prolongation, 
  a.NBHEUR as nombre_heures, 
  a.IDLVSR as motif_situation_resultant, 
  a.IDRTST as situation_au_retour, 
  a.IDRTSC as categorie_situation_au_retour, 
  a.GPRTSC as cat_situation_au_retour_redefiniee, 
  a.IDRTSR as motif_situation_au_retour, 
  a.NAABPD as payenon_paye,
  c.id as id_zyca_carriere,
  d.id as id_zy3b_unite_organisationelle,
  e.id as id_zy38_etablissement,
  f.id as id_zyes_entrees_departs,
  g.id as id_zyco_contrat,
  h.id as id_zytl_heures_contractuelles 
  
  from vw_ZYAG a
  left join vw_zyca c on c.numero_dossier = a.NUDOSS and  a.DATDEB >= c.date_debut and a.DATFIN <= c.date_fin 
  left join vw_zyco g on g.numero_dossier = a.NUDOSS and  a.DATDEB >= g.date_debut_contrat and a.DATFIN <= g.date_fin_contrat 
  left join vw_zy38 e on e.numero_dossier = a.NUDOSS and  a.DATDEB >= e.date_debut and a.DATFIN <= e.date_fin
  left join vw_zy3b d on d.numero_dossier = a.NUDOSS and  a.DATDEB >= d.date_effet and a.DATFIN <= d.date_fin
  left join vw_zyes f on f.numero_dossier = a.NUDOSS and  a.DATDEB >= f.date_entree and a.DATFIN <= f.date_sortie_administrative
  left join vw_zytl h on h.numero_dossier = g.numero_dossier and  h.date_effet >= g.date_debut_contrat and h.date_effet <= g.date_debut_contrat
  
 """ 

// COMMAND ----------

val ZYAG_inserted = spark.sql(query_record)
ZYAG_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table absences.ZYAG_absences """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

ZYAG_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "absences.ZYAG_absences", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
ZYAG_inserted.unpersist
df_ZYAG_read.unpersist
df_ref_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)