// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read common.referentiel table
val df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read absences.ZYDA table
///dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE6", "domain" -> "absences"))

var df_ZYDA_read = spark.table("hrabackup_absences.ZYDA")

//find and get column labels
df_ZYDA_read = gettranscoHRA(df_ZYDA_read, df_ref_read, "ZYDA")
                                                      
df_ZYDA_read.createOrReplaceTempView("vw_ZYDA")
df_ZYDA_read.cache()  //cache the dataframe

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zy3b_affectation", connectionproperties).createOrReplaceTempView("vw_zy3b")


// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zy38_affectation_etablissement", connectionproperties).createOrReplaceTempView("vw_zy38")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zyca_carriere", connectionproperties).createOrReplaceTempView("vw_zyca")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zyco_contrat", connectionproperties).createOrReplaceTempView("vw_zyco")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zyes_entrees_departs", connectionproperties).createOrReplaceTempView("vw_zyes")

// COMMAND ----------

spark.read.jdbc(jdbcurl, "career.commun_zytl_heures_contractuelles", connectionproperties).createOrReplaceTempView("vw_zytl")

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select 
// MAGIC   a.NUDOSS as numero_dossier,
// MAGIC   a.DATABS as date_debut_absence_ac, 
// MAGIC   a.MOTABS as motif_absence, 
// MAGIC   a.HRSDEB as heure_debut, 
// MAGIC   a.NUMDRO as numero_droit, 
// MAGIC   a.DATDEB as date_debuttranche, 
// MAGIC   a.NUMTRA as numero_tranche, 
// MAGIC   a.DATFIN as date_fin_tranche, 
// MAGIC   a.HRSFIN as heure_fin, 
// MAGIC   a.TEMDEB as temoin_midi_debut, 
// MAGIC   a.TEMFIN as temoin_midi_fin, 
// MAGIC   a.UNITE1 as duree_1, 
// MAGIC   a.UNITE2 as duree_2, 
// MAGIC   a.NBRJOU as nombre_jours, 
// MAGIC   a.DATEAG as date_debut_absence_gestion,
// MAGIC   c.id as id_zyca_carriere,
// MAGIC   d.id as id_zy3b_unite_organisationelle,
// MAGIC   e.id as id_zy38_etablissement,
// MAGIC   f.id as id_zyes_entrees_departs,
// MAGIC   g.id as id_zyco_contrat,
// MAGIC   h.id as id_zytl_heures_contractuelles 
// MAGIC   
// MAGIC   from vw_ZYDA a
// MAGIC   left join vw_zyca c on c.numero_dossier = a.NUDOSS and  a.DATDEB >= c.date_debut and a.DATFIN <= c.date_fin 
// MAGIC   left join vw_zyco g on g.numero_dossier = a.NUDOSS and  a.DATDEB >= g.date_debut_contrat and a.DATFIN <= g.date_fin_contrat 
// MAGIC   left join vw_zy38 e on e.numero_dossier = a.NUDOSS and  a.DATDEB >= e.date_debut and a.DATFIN <= e.date_fin
// MAGIC   left join vw_zy3b d on d.numero_dossier = a.NUDOSS and  a.DATDEB >= d.date_effet and a.DATFIN <= d.date_fin
// MAGIC   left join vw_zyes f on f.numero_dossier = a.NUDOSS and  a.DATDEB >= f.date_entree and a.DATFIN <= f.date_sortie_administrative
// MAGIC   left join vw_zytl h on h.numero_dossier = g.numero_dossier and  h.date_effet >= g.date_debut_contrat and h.date_effet <= g.date_debut_contrat
// MAGIC   
// MAGIC 
// MAGIC   where f.numero_dossier is null 

// COMMAND ----------

val query_record = """
  select 
  a.NUDOSS as numero_dossier,
  a.DATABS as date_debut_absence_ac, 
  a.MOTABS as motif_absence, 
  a.HRSDEB as heure_debut, 
  a.NUMDRO as numero_droit, 
  a.DATDEB as date_debuttranche, 
  a.NUMTRA as numero_tranche, 
  a.DATFIN as date_fin_tranche, 
  a.HRSFIN as heure_fin, 
  a.TEMDEB as temoin_midi_debut, 
  a.TEMFIN as temoin_midi_fin, 
  a.UNITE1 as duree_1, 
  a.UNITE2 as duree_2, 
  a.NBRJOU as nombre_jours, 
  a.DATEAG as date_debut_absence_gestion,
  c.id as id_zyca_carriere,
  d.id as id_zy3b_unite_organisationelle,
  e.id as id_zy38_etablissement,
  f.id as id_zyes_entrees_departs,
  g.id as id_zyco_contrat,
  h.id as id_zytl_heures_contractuelles 
  
  from vw_ZYDA a
  left join vw_zyca c on c.numero_dossier = a.NUDOSS and  a.DATDEB >= c.date_debut and a.DATFIN <= c.date_fin 
  left join vw_zyco g on g.numero_dossier = a.NUDOSS and  a.DATDEB >= g.date_debut_contrat and a.DATFIN <= g.date_fin_contrat 
  left join vw_zy38 e on e.numero_dossier = a.NUDOSS and  a.DATDEB >= e.date_debut and a.DATFIN <= e.date_fin
  left join vw_zy3b d on d.numero_dossier = a.NUDOSS and  a.DATDEB >= d.date_effet and a.DATFIN <= d.date_fin
  left join vw_zyes f on f.numero_dossier = a.NUDOSS and  a.DATDEB >= f.date_entree and a.DATFIN <= f.date_sortie_administrative
  left join vw_zytl h on h.numero_dossier = g.numero_dossier and  h.date_effet >= g.date_debut_contrat and h.date_effet <= g.date_debut_contrat
  """ 

// COMMAND ----------

val ZYDA_inserted = spark.sql(query_record)
ZYDA_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table absences.ZYDA_absences_decoupees_droits """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

ZYDA_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "absences.ZYDA_absences_decoupees_droits", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
ZYDA_inserted.unpersist
df_ZYDA_read.unpersist
df_ref_read.unpersist

// COMMAND ----------

//dbutils.notebook.exit(return_value)

// COMMAND ----------

