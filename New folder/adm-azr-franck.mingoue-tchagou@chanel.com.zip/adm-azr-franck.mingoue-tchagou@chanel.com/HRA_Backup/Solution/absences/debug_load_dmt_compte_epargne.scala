// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read absences.ZYE4 table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE4", "domain" -> "absences"))

val df_ZYE4_read = spark.table("hrabackup_absences.ZYE4")
                                                      
df_ZYE4_read.createOrReplaceTempView("vw_ZYE4")
df_ZYE4_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read absences.ZYE6 table
///dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYE6", "domain" -> "absences"))

val df_ZYE6_read = spark.table("hrabackup_absences.ZYE6")
                                                      
df_ZYE6_read.createOrReplaceTempView("vw_ZYE6")
df_ZYE6_read.cache()  //cache the dataframe


// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZYE4

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZYE6

// COMMAND ----------

// MAGIC %sql
// MAGIC select count(distinct *) from vw_ZYE6

// COMMAND ----------

// MAGIC %sql
// MAGIC select NUDOSS, DTOPER, TYPOPE, TYPCPT, NBJOTH, NUMORD, NBJOUR, NBJOUV, NBHEUR, AMNUM, SOLCHE, CDORIG, count(*)
// MAGIC from vw_ZYE6 
// MAGIC group by NUDOSS, DTOPER, TYPOPE, TYPCPT, NBJOTH, NUMORD, NBJOUR, NBJOUV, NBHEUR, AMNUM, SOLCHE, CDORIG
// MAGIC having count(*) > 1

// COMMAND ----------

//spark.read.jdbc(jdbcurl, "dbo.vw_ref_degree_level", connectionproperties).createOrReplaceTempView("vw_ref_degree_level")

// COMMAND ----------

// MAGIC %sql
// MAGIC --create database hrabackup_dmt_absences

// COMMAND ----------

// MAGIC %sql
// MAGIC select NUDOSS, count(*) from vw_ZYE4
// MAGIC group by NUDOSS
// MAGIC having count(*) > 2 

// COMMAND ----------

// MAGIC %sql
// MAGIC select NUDOSS, count(distinct(TYPCPT)) from vw_ZYE4
// MAGIC group by NUDOSS
// MAGIC having count(*) != 2 

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZYE4 
// MAGIC where NUDOSS = "829"

// COMMAND ----------

// MAGIC %sql
// MAGIC drop table if exists hrabackup_dmt_absences.compte_epargne

// COMMAND ----------

// MAGIC %sql
// MAGIC --CREATE TABLE hrabackup_dmt_absences.compte_epargne as 
// MAGIC select 
// MAGIC   CASE
// MAGIC     WHEN b.NUDOSS IS NULL THEN a.NUDOSS
// MAGIC     ELSE b.NUDOSS
// MAGIC   END as numero_dossier,
// MAGIC   --b.NUDOSS as numero_dossier, 
// MAGIC   b.DTOPER as date_operation,
// MAGIC   CASE
// MAGIC     WHEN b.TYPCPT IS NULL THEN a.TYPCPT
// MAGIC     ELSE b.TYPCPT
// MAGIC   END as type_compte,
// MAGIC   b.TYPOPE as type_operation, 
// MAGIC   --b.TYPCPT as type_compte, 
// MAGIC   b.NBJOTH as nombre_jours_temps_plein, 
// MAGIC   b.NUMORD as numero_ordre, 
// MAGIC   b.NBJOUR as nombre_jours_epargnes, 
// MAGIC   b.NBJOUV as nombre_jours_ouvres_epargnes, 
// MAGIC   b.NBHEUR as nombre_heures_epargnees, 
// MAGIC   b.AMNUM as montant_epargne, 
// MAGIC   b.SOLCHE as solde_compte_en_heures_tps_plein_oce, 
// MAGIC   b.CDORIG as code_origine,
// MAGIC   --a.NUDOSS as numero_dossier, 
// MAGIC   --a.TYPCPT as type_compte, 
// MAGIC   a.DTOUV as date_ouverture_compte, 
// MAGIC   a.DTFERM as date_fermeture_compte, 
// MAGIC   a.SOLCPT as solde_compte_en_jours_ouvres, 
// MAGIC   a.SOLCTH as solde_compte_theor_tps_pleine, 
// MAGIC   a.SOLCHE as solde_compte_en_heures_tps_plein_ce
// MAGIC   
// MAGIC   from vw_ZYE6 b full join vw_ZYE4 a ON a.NUDOSS = b.NUDOSS 
// MAGIC   and b.TYPCPT = a.TYPCPT
// MAGIC   and  b.DTOPER <= a.DTFERM
// MAGIC   
// MAGIC   
// MAGIC   --where b.NUDOSS is null
// MAGIC   --order by b.NUDOSS , b.TYPCPT, b.DTOPER 
// MAGIC   

// COMMAND ----------

// MAGIC %sql
// MAGIC --CREATE TABLE hrabackup_dmt_absences.compte_epargne as 
// MAGIC select count(*)
// MAGIC   
// MAGIC   from vw_ZYE6 b full join vw_ZYE4 a ON a.NUDOSS = b.NUDOSS 
// MAGIC   and b.TYPCPT = a.TYPCPT
// MAGIC  and   b.DTOPER >= a.DTOUV AND  (b.DTOPER <=  a.DTFERM OR b.DTOPER > a.DTFERM)
// MAGIC  where a.NUDOSS is null

// COMMAND ----------



// COMMAND ----------

val query_record = """select 
  CASE
    WHEN b.NUDOSS IS NULL THEN a.NUDOSS
    ELSE b.NUDOSS
  END as numero_dossier,
  --b.NUDOSS as numero_dossier, 
  b.DTOPER as date_operation,
  CASE
    WHEN b.TYPCPT IS NULL THEN a.TYPCPT
    ELSE b.TYPCPT
  END as type_compte,
  b.TYPOPE as type_operation, 
  --b.TYPCPT as type_compte, 
  b.NBJOTH as nombre_jours_temps_plein, 
  b.NUMORD as numero_ordre, 
  b.NBJOUR as nombre_jours_epargnes, 
  b.NBJOUV as nombre_jours_ouvres_epargnes, 
  b.NBHEUR as nombre_heures_epargnees, 
  b.AMNUM as montant_epargne, 
  b.SOLCHE as solde_compte_en_heures_tps_plein_oce, 
  b.CDORIG as code_origine,
  --a.NUDOSS as numero_dossier, 
  --a.TYPCPT as type_compte, 
  a.DTOUV as date_ouverture_compte, 
  a.DTFERM as date_fermeture_compte, 
  a.SOLCPT as solde_compte_en_jours_ouvres, 
  a.SOLCTH as solde_compte_theor_tps_pleine, 
  a.SOLCHE as solde_compte_en_heures_tps_plein_ce 
  
  from vw_ZYE6 b full join vw_ZYE4 a ON a.NUDOSS = b.NUDOSS 
  and b.TYPCPT = a.TYPCPT
  and  b.DTOPER <= a.DTFERM""" 

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZYE4 
// MAGIC where NUDOSS = "4164690"

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZYE6 
// MAGIC where NUDOSS = "4164"

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from hrabackup_dmt_absences.compte_epargne
// MAGIC --where numero_dossier = "1973"
// MAGIC order by numero_dossier, type_compte, date_operation

// COMMAND ----------

val compte_epargne_inserted = spark.sql(query_record)
compte_epargne_inserted.cache() 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table absences.compte_epargne """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

compte_epargne_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "absences.compte_epargne", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
compte_epargne_inserted.unpersist
df_ZYE4_read.unpersist
df_ZYE6_read.unpersist

// COMMAND ----------

dbutils.notebook.exit(return_value)