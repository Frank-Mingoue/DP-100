// Databricks notebook source
// MAGIC %run ../Include/read_write_parse_file

// COMMAND ----------

// MAGIC %run ./get_table_query

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

//build the path to read curated data
val source_path = get_container("curated") + "/backup_hra/"

// source folders
val domain_list = List("pay")

// generic table list 
val generic_table_list = List( "ZX6C")

// "ZX00", "ZX0M", "ZX35", "ZX37", "ZX38", "ZX3B", "ZX40", "ZX4K", "ZX5V", "ZX6A", "ZX6C", "ZX6P", "ZX8K", "ZXM7", "ZXMM"

val timeoutSeconds = 0 
  

// COMMAND ----------

val domain = "pay"
val table = "ZX6C"

// COMMAND ----------

val query = s"""
select * , INT (ROW_NUMBER() OVER (order by PERPAI ASC)/5000000) AS RN
from hrabackup_${domain}.${table}
"""

// COMMAND ----------

val query2 = s"""
select DISTINCT * , INT (ROW_NUMBER() OVER (order by PERPAI ASC)/5000000) AS RN
from hrabackup_${domain}.${table}
"""

// COMMAND ----------

val df_table = spark.sql(query)
df_table.count()

// COMMAND ----------

val df_table2 = spark.sql(query2)
df_table2.count()

// COMMAND ----------

display(df_table2)

// COMMAND ----------

val df_table = spark.sql(query)
df_table.createOrReplaceTempView("vw_table")
df_table.cache()

// COMMAND ----------

val partitionlist = df_table.select("RN").distinct.collect().map(_(0)).toList

// COMMAND ----------

val table_query = get_table_query(table)
val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table """ + table_query("table_name")
val res = stmt.execute(query_delete)
connection.close()

// COMMAND ----------

for (partition <- partitionlist ){
      
    println(partition)
     val df_table_read = df_table.filter(col("RN") === partition)
     df_table_read.createOrReplaceTempView("vw_table") 
     df_table_read.cache()
  
     val table_query = get_table_query(table)
     val query_record = table_query("query_record")
     val df_table_inserted = spark.sql(query_record)
     df_table_inserted.cache()
  
      // insert table in dmt
     df_table_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, table_query("table_name"), connectionproperties)

     //log

     //remove dataframe from cache
     df_table_read.unpersist
     df_table_inserted.unpersist
}

// COMMAND ----------

df_table.distinct.count()

// COMMAND ----------

for(domain <- domain_list) {
  
   val folder_path = source_path  + domain
  
   val tablelist = getcuratedtables(folder_path)
  
   if(!tablelist.isEmpty){
     
     for(table <- tablelist){
       
       if (generic_table_list.contains(table)) {
         
       //init database 
//        dbutils.notebook.run("../Init/init_curated_databases",timeoutSeconds, Map("table" -> table, "domain" -> domain))
       
         val query = s"select * , ROUND (ROW_NUMBER() OVER (order by PERPAI ASC)/5000000) AS RN from hrabackup_${domain}.${table}"
         
       //load table in dmt 
         println(table)
       //read table in df
       val df_table = spark.sql(query)
         
         //distinct partitions       
       val partitionlist = df_table.select("RN").distinct
       
       val connection = getSQLconnection()
       val stmt = connection.createStatement()
       val query_delete = """ truncate table """ + table_query("table_name")
       val res = stmt.execute(query_delete)
       connection.close()
         
         //loop
         for (partition <- partitionlist ){
           
           df_table_read = df_table.filter("RN" == partition)
       
       
       // create a temp view
       df_table_read.createOrReplaceTempView("vw_table") 
       df_table_read.cache()  //put the dataframe ont he cache
       
       //read table with columns name
       val table_query = get_table_query(table)
       val query_record = table_query("query_record")
       val df_table_inserted = spark.sql(query_record)
       df_table_inserted.cache()  //put the dataframe ont he cache
       
       //truncate table in dmt
       val connection = getSQLconnection()
       val stmt = connection.createStatement()
       val query_delete = """ truncate table """ + table_query("table_name")
       val res = stmt.execute(query_delete)
       connection.close()
         
         
       // insert table in dmt
       df_table_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, table_query("table_name"), connectionproperties)
         
       //log
         
       //remove dataframe from cache
       df_table_read.unpersist
       df_table_inserted.unpersist
         
       }
       }
     }
   }  
  
  
}

// COMMAND ----------

//val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0 + ";message: Init database"

// COMMAND ----------

//dbutils.notebook.exit(return_value)