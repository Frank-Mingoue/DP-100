// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

// DBTITLE 1,init and read ZYCA table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZX00", "domain" -> "pay"))

val df_ZYCA_read = spark.table("hrabackup_career.zyca")
                                                      
df_ZYCA_read.createOrReplaceTempView("vw_ZYCA")
// df_ZYCA_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from vw_ZYCA

// COMMAND ----------


val new_df = df_ZYCA_read.withColumnRenamed("QUALIF","QUALIFICATION")
display(new_df)

// COMMAND ----------

spark.read.jdbc(jdbcurl, "dbo.param_transco_ref",connectionproperties).createOrReplaceTempView("vw_dbo_param_transco_ref")
val df_transco = spark.table("vw_dbo_param_transco_ref").na.fill("Nothing")

// COMMAND ----------

val df_carriere_transco = gettransco2(df_transco,new_df, "hra","workday")

// COMMAND ----------

display(df_carriere_transco._1)

// COMMAND ----------

df_carriere_transco._3

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select * from vw_ZX00
// MAGIC -- order by PERPAI

// COMMAND ----------

//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYWO", "domain" -> "career"))

val df_ZYWO_read = spark.table("hrabackup_career.ZYWO")
                                                      
df_ZYWO_read.createOrReplaceTempView("vw_ZYWO")
df_ZYWO_read.cache()  //cache the dataframe

// COMMAND ----------

//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYWO", "domain" -> "career"))

val df_ZY00_read = spark.table("hrabackup_career.ZY00")
                                                      
df_ZY00_read.createOrReplaceTempView("vw_ZY00")
df_ZY00_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql 
// MAGIC select * from vw_ZY00

// COMMAND ----------


val df_ZX38_read = spark.table("hrabackup_pay.ZX38")
                                                      
df_ZX38_read.createOrReplaceTempView("vw_ZX38")
df_ZX38_read.cache()  //cache the dataframe

// COMMAND ----------


val df_ZX37_read = spark.table("hrabackup_pay.ZX37")
                                                      
df_ZX38_read.createOrReplaceTempView("vw_ZX37")
df_ZX38_read.cache()  //cache the dataframe

// COMMAND ----------

val df_ZX35_read = spark.table("hrabackup_pay.ZX35")
                                                      
df_ZX35_read.createOrReplaceTempView("vw_ZX35")
df_ZX35_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql 
// MAGIC 
// MAGIC select * from vw_ZX35

// COMMAND ----------

val df_ZX33_read = spark.table("hrabackup_pay.ZX33")
                                                      
df_ZX33_read.createOrReplaceTempView("vw_ZX33")
df_ZX33_read.cache()  //cache the dataframe

// COMMAND ----------

val df_ZX31_read = spark.table("hrabackup_pay.ZX31")
                                                      
df_ZX31_read.createOrReplaceTempView("vw_ZX31")
df_ZX31_read.cache()  //cache the dataframe

// COMMAND ----------

val df_ZX0M_read = spark.table("hrabackup_pay.ZX0M")
                                                      
df_ZX0M_read.createOrReplaceTempView("vw_ZX0M")
df_ZX0M_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZX0M
// MAGIC -- order by NUDOSS

// COMMAND ----------

// MAGIC %sql 
// MAGIC 
// MAGIC select 
// MAGIC -- count(*)
// MAGIC  vw_ZX00.NUDOSS AS numero_dossier
// MAGIC ,vw_ZX00.MATRIC AS matricule_hra
// MAGIC ,vw_ZYWO.MATWOR AS matricule_WD
// MAGIC ,vw_ZX31.NOMUSE AS nom_salarie
// MAGIC ,vw_ZX33.PRENOM AS prenom_salarie
// MAGIC ,vw_ZX35.DATENT AS date_entree
// MAGIC ,vw_ZX35.DATSOR AS date_sortie
// MAGIC ,vw_ZX0M.IDESTA AS etablissement
// MAGIC ,vw_ZX38.COCONV AS code_convention_CCN
// MAGIC ,vw_ZX35.ANCIE5 AS date_anciennete
// MAGIC ,CASE
// MAGIC     WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 < 6 THEN "Moins de 6 mois"
// MAGIC     WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 6 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 12  THEN "Entre 6 mois et 1 an"
// MAGIC     WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 12 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 36  THEN "1 à 3 ans"
// MAGIC     WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 36 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 60  THEN "3 à 5 ans"
// MAGIC     WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 60 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 120  THEN "5 à 10 ans"
// MAGIC     WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 120 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 240  THEN "10 à 20 ans"
// MAGIC     ELSE "Plus de 20 ans"
// MAGIC  END as anciennete 
// MAGIC ,vw_ZX38.QUALIF AS qualification
// MAGIC ,vw_ZX38.CLASSI AS classification
// MAGIC ,vw_ZX0M.TYPCON AS type_contrat
// MAGIC ,vw_ZX0M.NATCON AS nature_contrat
// MAGIC ,vw_ZX0M.CODTRA AS type_temps_contractuel
// MAGIC ,vw_ZX0M.NBSTHM AS heures_presence_mois
// MAGIC ,vw_ZX00.PERPAI AS periode_paie
// MAGIC 
// MAGIC FROM vw_ZX00 
// MAGIC JOIN vw_ZX31 ON vw_ZX31.NUDOSS = vw_ZX00.NUDOSS
// MAGIC JOIN vw_ZX33 ON vw_ZX33.NUDOSS = vw_ZX00.NUDOSS
// MAGIC JOIN vw_ZX35 ON vw_ZX35.NUDOSS = vw_ZX00.NUDOSS
// MAGIC JOIN vw_ZX38 ON vw_ZX38.NUDOSS = vw_ZX00.NUDOSS
// MAGIC JOIN vw_ZX0M ON vw_ZX0M.NUDOSS = vw_ZX00.NUDOSS
// MAGIC LEFT JOIN vw_ZY00 ON vw_ZY00.MATCLE = vw_ZX00.MATRIC
// MAGIC LEFT JOIN vw_ZYWO ON vw_ZYWO.NUDOSS = vw_ZY00.NUDOSS
// MAGIC 
// MAGIC order by vw_ZX00.NUDOSS
// MAGIC 
// MAGIC   

// COMMAND ----------

// MAGIC %sql
// MAGIC select DATEDIFF("2022-06-30", ANCIE5) / 30 as anciennete 
// MAGIC from vw_ZX35

// COMMAND ----------

// MAGIC %sql
// MAGIC select CASE
// MAGIC     WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 < 6 THEN "Moins de 6 mois"
// MAGIC     WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 6 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 12  THEN "Entre 6 mois et 1 an"
// MAGIC     WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 12 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 36  THEN "1 à 3 ans"
// MAGIC     WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 36 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 60  THEN "3 à 5 ans"
// MAGIC     WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 60 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 120  THEN "5 à 10 ans"
// MAGIC     WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 120 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 240  THEN "10 à 20 ans"
// MAGIC     ELSE "Plus de 20 ans"
// MAGIC   END as anciennete 
// MAGIC from vw_ZX35

// COMMAND ----------

//spark.read.jdbc(jdbcurl, "dbo.vw_ref_degree_level", connectionproperties).createOrReplaceTempView("vw_ref_degree_level")

// COMMAND ----------

val query_record = """ 
                    select 
                     vw_ZX00.NUDOSS AS numero_dossier
                    ,vw_ZX00.MATRIC AS matricule_hra
                    ,vw_ZYWO.MATWOR AS matricule_WD
                    ,vw_ZX31.NOMUSE AS nom_salarie
                    ,vw_ZX33.PRENOM AS prenom_salarie
                    ,vw_ZX35.DATENT AS date_entree
                    ,vw_ZX35.DATSOR AS date_sortie
                    ,vw_ZX0M.IDESTA AS etablissement
                    ,vw_ZX38.COCONV AS code_convention_CCN
                    ,vw_ZX35.ANCIE5 AS date_anciennete
                    ,CASE
                        WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 < 6 THEN "Moins de 6 mois"
                        WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 6 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 12  THEN "Entre 6 mois et 1 an"
                        WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 12 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 36  THEN "1 à 3 ans"
                        WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 36 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 60  THEN "3 à 5 ans"
                        WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 60 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 120  THEN "5 à 10 ans"
                        WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 120 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 240  THEN "10 à 20 ans"
                        ELSE "Plus de 20 ans"
                     END as anciennete 
                    ,vw_ZX38.QUALIF AS qualification
                    ,vw_ZX38.CLASSI AS classification
                    ,vw_ZX0M.TYPCON AS type_contrat
                    ,vw_ZX0M.NATCON AS nature_contrat
                    ,vw_ZX0M.CODTRA AS type_temps_contractuel
                    ,vw_ZX0M.NBSTHM AS heures_presence_mois
                    ,vw_ZX00.PERPAI AS periode_paie

                    FROM vw_ZX00 
                    JOIN vw_ZX31 ON vw_ZX31.NUDOSS = vw_ZX00.NUDOSS
                    JOIN vw_ZX33 ON vw_ZX33.NUDOSS = vw_ZX00.NUDOSS
                    JOIN vw_ZX35 ON vw_ZX35.NUDOSS = vw_ZX00.NUDOSS
                    JOIN vw_ZX38 ON vw_ZX38.NUDOSS = vw_ZX00.NUDOSS
                    JOIN vw_ZX0M ON vw_ZX0M.NUDOSS = vw_ZX00.NUDOSS
                    LEFT JOIN vw_ZY00 ON vw_ZY00.MATCLE = vw_ZX00.MATRIC
                    LEFT JOIN vw_ZYWO ON vw_ZYWO.NUDOSS = vw_ZY00.NUDOSS              
                      """ 

// COMMAND ----------

val filtres_inserted = spark.sql(query_record)
filtres_inserted.cache()  //put the dataframe ont he cache 

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table pay.filtres """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

filtres_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "pay.filtres", connectionproperties)

// COMMAND ----------

/*val read_records = df_candidates_read.count().toInt //count the number of read records
val inserted_records = candidates_inserted.count().toInt //count the number of read records
//set up the return value with the number of lines read, rejected and inserted
val return_value = "read_records:" + read_records + ";inserted_records:" + inserted_records + ";rejected_records:" + 0*/

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_ZY00_read.unpersist
df_ZYWO_read.unpersist
df_ZY19_read.unpersist
identification_inserted.unpersist

// COMMAND ----------

/*dbutils.notebook.exit(return_value)