// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

// MAGIC 
// MAGIC %sql
// MAGIC 
// MAGIC select  nudoss, COUNT(*) from hrabackup_pay.zx8k
// MAGIC group by nudoss

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select  COUNT(distinct nudoss) from hrabackup_pay.zx8k
// MAGIC -- group by nudoss

// COMMAND ----------

// MAGIC 
// MAGIC %sql
// MAGIC 
// MAGIC select max(length(CODRUB)) from hrabackup_pay.zx8k

// COMMAND ----------

// MAGIC 
// MAGIC %sql
// MAGIC 
// MAGIC select COUNT(distinct IDCY00) from hrabackup_career.zyes

// COMMAND ----------

val df_ref = spark.table("hrabackup_common.referentiel")
                                                      
df_ref.createOrReplaceTempView("vw_ref")
df_ref.cache()  //cache the dataframe

// COMMAND ----------

var table = spark.sql("select distinct CODRUB from hrabackup_pay.zx8k"  )

var table_transco = gettranscoHRA(table, df_ref, "ZX8K")

table_transco.createOrReplaceTempView("vw_zx8k")

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select max(length(CODRUB)) from vw_zx8k

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select PERPAI, count(*) from hrabackup_pay.zx6c
// MAGIC group by PERPAI

// COMMAND ----------

