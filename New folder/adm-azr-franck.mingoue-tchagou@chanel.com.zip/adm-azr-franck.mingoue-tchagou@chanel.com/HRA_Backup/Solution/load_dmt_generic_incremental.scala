// Databricks notebook source
// MAGIC %python
// MAGIC dbutils.widgets.dropdown("file","",["","ZXMM", "ZX6C", "ZX8K", "ZX3B"])

// COMMAND ----------

// MAGIC %run ../Include/read_write_parse_file

// COMMAND ----------

// MAGIC %run ./get_table_query

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

//build the path to read curated data
val source_path = get_container("curated") + "/backup_hra/"

// source folders
val domain_list = dbutils.widgets.get("domain").split(",").toList


// generic table list 
var incremental_table_list = List("ZXMM", "ZX6C", "ZX8K", "ZX3B")

val file = dbutils.widgets.get("file")

val nber_partition_rows = 5000000
 
  

// COMMAND ----------

for(domain <- domain_list) {
  
   val folder_path = source_path  + domain
  
   val tablelist = getcuratedtables(folder_path)
  
   if(!tablelist.isEmpty){
     
     //read referentiel
     val df_ref_read = spark.table("hrabackup_common.referentiel")                                                      
     df_ref_read.createOrReplaceTempView("vw_ref")
     df_ref_read.cache()
     
     for(table <- tablelist){
       
          if (!file.isEmpty){
           incremental_table_list = List(file)
         }
       
       
       if (incremental_table_list.contains(table)) {
         
      
       //load table in dmt 
         
         println(table)
         
       //query to partition table 
       val query = s"""
              select  * , INT (ROW_NUMBER() OVER (order by PERPAI ASC)/${nber_partition_rows}) AS RN
              from hrabackup_${domain}.${table}
              """
         
       // read table and create view
        val df_table = spark.sql(query)
        df_table.createOrReplaceTempView("vw_table")
        df_table.cache()
         
        val partitionlist = df_table.select("RN").distinct.collect().map(_(0)).toList
         
         // truncate the destination table 
         val table_query = get_table_query(table)
         val connection = getSQLconnection()
         val stmt = connection.createStatement()
         val query_delete = """ truncate table """ + table_query("table_name")
         val res = stmt.execute(query_delete)
          connection.close()
         
          for (partition <- partitionlist ){
      
              println(partition)
              var df_table_read = df_table.filter(col("RN") === partition)
               println(df_table_read.count())
              
              df_table_read = gettranscoHRA(df_table_read, df_ref_read, table)  //find and get column labels
            
//                println(df_table_read.count())

              df_table_read.createOrReplaceTempView("vw_table") 
              df_table_read.cache()

              val table_query = get_table_query(table)
              val query_record = table_query("query_record")
              val df_table_inserted = spark.sql(query_record)
              df_table_inserted.cache()

                // insert table in dmt
               df_table_inserted.write.mode(SaveMode.Append).jdbc(jdbcurl, table_query("table_name"), connectionproperties)

               //log

               //remove dataframe from cache
               df_table_read.unpersist
               df_table_inserted.unpersist
          } 
         
         df_table.unpersist
         
       }
     }
      df_ref_read.unpersist
   }  
  
  
}

// COMMAND ----------

//val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0 + ";message: Init database"

// COMMAND ----------

//dbutils.notebook.exit(return_value)