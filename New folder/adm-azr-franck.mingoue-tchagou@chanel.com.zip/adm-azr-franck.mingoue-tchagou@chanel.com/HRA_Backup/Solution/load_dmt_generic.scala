// Databricks notebook source
// MAGIC %run ../Include/read_write_parse_file

// COMMAND ----------

// MAGIC %run ./get_table_query

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

//build the path to read curated data
val source_path = get_container("curated") + "/backup_hra/"

// source folders
val domain_list = dbutils.widgets.get("domain").split(",").toList

// table list to not load
val generic_table_list = List("ZYWO", "ZY00", "ZX33", "ZX31", "ZY1M", "ZYAF", "ZXMM", "ZX6C", "ZX8K", "ZX3B")

val file = dbutils.widgets.get("file")
  

// COMMAND ----------

var final_list = List("")

for(domain <- domain_list) {
  
   val folder_path = source_path  + domain
  
   val tablelist = getcuratedtables(folder_path)
  
   if(!tablelist.isEmpty){
     
     //read referentiel
     val df_ref_read = spark.table("hrabackup_common.referentiel")                                                      
     df_ref_read.createOrReplaceTempView("vw_ref")
     df_ref_read.cache()
     
     for(table <- tablelist){
       
       if (file.isEmpty){
           final_list = List(table)
         }
       else {      
          final_list = List(file)
         }
       
       if (!generic_table_list.contains(table) && final_list.contains(table)) {
         
       
         
       //load table in dmt 
         println(table)
       //read table in df
       var df_table_read = spark.table(s"hrabackup_${domain}.${table}")
       

       df_table_read = gettranscoHRA(df_table_read, df_ref_read,table)  //find and get column labels
       
         
       // create a temp view
       df_table_read.createOrReplaceTempView("vw_table") 
       df_table_read.cache()  //put the dataframe ont he cache
       
       //read table with columns name
       val table_query = get_table_query(table)
       val query_record = table_query("query_record")
       val df_table_inserted = spark.sql(query_record)
       df_table_inserted.cache()  //put the dataframe ont he cache
       
       //truncate table in dmt
       val connection = getSQLconnection()
       val stmt = connection.createStatement()
       val query_delete = """ truncate table """ + table_query("table_name")
       val res = stmt.execute(query_delete)
       connection.close()
         
         
       // insert table in dmt
       df_table_inserted.coalesce(1).write.mode(SaveMode.Append).jdbc(jdbcurl, table_query("table_name"), connectionproperties)
         
       //log
         
       //remove dataframe from cache
       df_table_read.unpersist
       df_table_inserted.unpersist
         
       }
     }
      df_ref_read.unpersist
   }  
   
  
}

// COMMAND ----------

//val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0 + ";message: Init database"

// COMMAND ----------

//dbutils.notebook.exit(return_value)