// Databricks notebook source
// MAGIC %run ../Include/read_write_parse_file

// COMMAND ----------

// MAGIC %run ./get_table_query

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()

// COMMAND ----------

//build the path to read curated data
val source_path = get_container("curated") + "/backup_hra/"

// source folders
val domain_list = List("absences", "career")

// generic table list 
val generic_table_list = List("ZYDA", "ZYAF", "ZYCU", "ZYWB", "ZYAR", "ZYEL")

val domain = "career"

val table = "ZYCU"
  

// COMMAND ----------

//read table in df
val df_table_read = spark.table(s"hrabackup_${domain}.${table}")

// COMMAND ----------

// create a temp view
df_table_read.createOrReplaceTempView("vw_table") 
df_table_read.cache()  //put the dataframe ont he cache

// COMMAND ----------

//read table with columns name
val table_query = get_table_query(table)
val query_record = table_query("query_record")


// COMMAND ----------

val df_table_inserted = spark.sql(query_record)
df_table_inserted.cache()

// COMMAND ----------

//truncate table in dmt
val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table """ + table_query("table_name")
val res = stmt.execute(query_delete)
connection.close()

// COMMAND ----------

// insert table in dmt
df_table_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, table_query("table_name"), connectionproperties)

// COMMAND ----------

//remove dataframe from cache
df_table_read.unpersist
df_table_inserted.unpersist       
       

// COMMAND ----------

//val return_value = "read_records:" + 0 + ";inserted_records:" + 0 + ";rejected_records:" + 0 + ";message: Init database"

// COMMAND ----------

//dbutils.notebook.exit(return_value)