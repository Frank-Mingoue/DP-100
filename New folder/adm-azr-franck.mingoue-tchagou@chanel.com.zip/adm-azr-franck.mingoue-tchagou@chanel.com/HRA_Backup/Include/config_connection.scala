// Databricks notebook source
// DBTITLE 1,Include notebook containing common functions
// MAGIC %run ./common_functions

// COMMAND ----------

// DBTITLE 1,Set up parameters to connect to ADLS and databases
val secret_scope = "sp-cluster-dif-w01"; //secret scope where key from keyvault are stored
val adls_key = "adls-services-login"; // key for the storage account in the keyvault
val storage_account_key = "adls-services-storage-account" //get the storage account name

val sp_client_id= "sp-client-id" //service principal id
val sp_client_secret_id= "sp-client-secret-id" //service principal secret id
val tenant_id= "tenant-id" //tenand id or directory id

val db_login_key = "mssql-services-login" // key for the database login in the keyvault
val db_pwd_key = "mssql-services-password" // key for the database password in the keyvault
val db_server_key = "mssql-services-server" //get the database server name
val db_key = "mssql-services-dbhrabackup" //get the database name
//val dbmonitoring_key = "mssql-services-dbmonitoring" //get the database name
val jdbcport = 1433 //port

// COMMAND ----------

// DBTITLE 1,Function which allows to  connect to ADLS container by creating a mount point. It takes in parameter the storage account and the container name
def connectADLS(storage_account: String, container_name: String) : String = {
  
  val container = getvalueposition(container_name,0,"_")
  val container_mount = "/mnt/" + container_name + "_container" //mountpoint to create
  val container_source = "abfss://" + container + "@" + storage_account + ".blob.core.windows.net/"  //url to access to the container
  val config = Map("fs.azure.account.key." + storage_account + ".blob.core.windows.net" -> dbutils.secrets.get(scope = secret_scope, key = adls_key))  //setup config to access to the container
  
  /**if the mountpoint doesn't exist create it. then return the mount point ****/
   if (!dbutils.fs.mounts.map(mnt => mnt.mountPoint).contains(container_mount))
   {
     dbutils.fs.mount(
       source =container_source,
       mountPoint = container_mount,
       extraConfigs = config
     )
     
   }
   return container_mount
  
}

// COMMAND ----------

// DBTITLE 1,Function to disconnect from ADLS container by unmounting point
def disconnectADLS(container_name: String)  {
  
  
  val container_mount = "/mnt/" + container_name + "_container" //mountpoint created
  
  /**if the mountpoint exists. unmount it ****/
   if (dbutils.fs.mounts.map(mnt => mnt.mountPoint).contains(container_mount))
   {
     dbutils.fs.unmount(container_name)     
   }
   
  if (dbutils.fs.mounts.map(mnt => mnt.mountPoint).contains(container_name))
   {
     dbutils.fs.unmount(container_name)     
   }
  
}

// COMMAND ----------

// DBTITLE 1,Function to get url to connect to the database. It takes as parameters the server, the port and the database name
def getSQLurl() : String = {
  
  val jdbcserver = dbutils.secrets.get(scope = secret_scope, key = db_server_key) //get the database server
  val jdbcdatabase = dbutils.secrets.get(scope = secret_scope, key = db_key) //get the the database name
  
// Create the JDBC URL without passing in the user and password parameters.
  val jdbcurl = s"jdbc:sqlserver://${jdbcserver}:${jdbcport};database=${jdbcdatabase}"
 // val jdbcurl = s"jdbc:sqlserver://sqlsrv-dif-we1-dev.database.windows.net:1433;database=sqldb-dif-we1-dev"
  
  return jdbcurl
}


// COMMAND ----------

// DBTITLE 1,Function to return the properties to connect to databases
def getSQLproperties() : Properties = {
  
    val jdbcusername = dbutils.secrets.get(scope = secret_scope, key = db_login_key) //get the database login
    val jdbcpassword = dbutils.secrets.get(scope = secret_scope, key = db_pwd_key) //get the the database password
  
  // Create a Properties() object to hold the parameters.
    val connectionProperties = new Properties()

    connectionProperties.put("user", s"${jdbcusername}")    //add database login
    connectionProperties.put("password", s"${jdbcpassword}") // add database password
  
    val driverClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
    connectionProperties.setProperty("Driver", driverClass)  // add driver class
  
  return connectionProperties
}

// COMMAND ----------

// DBTITLE 1,Function to return the sql connection to the databases. It takes as parameters the server, the port and the database name
def getSQLconnection() : java.sql.Connection = {
  
  val jdbcserver = dbutils.secrets.get(scope = secret_scope, key = db_server_key) //get the database server
  val jdbcdatabase = dbutils.secrets.get(scope = secret_scope, key = db_key) //get the the database name
  
  val jdbcusername = dbutils.secrets.get(scope = secret_scope, key = db_login_key) //get the database login
  val jdbcpassword = dbutils.secrets.get(scope = secret_scope, key = db_pwd_key) //get the the database password
  val jdbcurl = s"jdbc:sqlserver://${jdbcserver}:${jdbcport};database=${jdbcdatabase};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;" //get the database url
  val driverClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

 return DriverManager.getConnection(jdbcurl, jdbcusername, jdbcpassword)
}

// COMMAND ----------

def get_container(container_name: String) : String = {
  
  val storage_account = dbutils.secrets.get(scope = secret_scope, key = storage_account_key)
  val container_mount = "/mnt/" + container_name + "_container" //mountpoint to create
  val container_source = "wasbs://" + container_name + "@" + storage_account + ".blob.core.windows.net/"  //url to access to the container
  val config = Map("fs.azure.account.key." + storage_account + ".blob.core.windows.net" -> dbutils.secrets.get(scope = secret_scope, key = adls_key))  //setup config to access to the container
  
  /**if the mountpoint doesn't exist create it. then return the mount point ****/
   if (!dbutils.fs.mounts.map(mnt => mnt.mountPoint).contains(container_mount))
   {
     dbutils.fs.mount(
       source =container_source,
       mountPoint = container_mount,
       extraConfigs = config
     )
     
   }
   return container_mount
  
}

// COMMAND ----------

def get_container_sp(container_name: String) : String = {
  
  val storage_account = dbutils.secrets.get(scope = secret_scope, key = storage_account_key)
  val container_mount = "/mnt/" + container_name + "_container" //mountpoint to create
  val container_source = "abfss://" + container_name + "@" + storage_account + ".dfs.core.windows.net/"  //url to access to the container
  val endpoint = "https://login.microsoftonline.com/" + dbutils.secrets.get(scope = secret_scope, key = tenant_id) + "/oauth2/token"
  //setup config to access to the container
  val config = Map(
  "fs.azure.account.auth.type" -> "OAuth",
  "fs.azure.account.oauth.provider.type" -> "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
  "fs.azure.account.oauth2.client.id" -> dbutils.secrets.get(scope = secret_scope, key = sp_client_id),
  "fs.azure.account.oauth2.client.secret" -> dbutils.secrets.get(scope = secret_scope, key = sp_client_secret_id),
  "fs.azure.account.oauth2.client.endpoint" -> endpoint
    )

 
  /**if the mountpoint doesn't exist create it. then return the mount point ****/
   if (!dbutils.fs.mounts.map(mnt => mnt.mountPoint).contains(container_mount))
   {
     dbutils.fs.mount(
       source =container_source,
       mountPoint = container_mount,
       extraConfigs = config
     )
     
   }
   return container_mount
  
}

// COMMAND ----------

get_container_sp("raw")
get_container_sp("curated")
get_container_sp("refined")