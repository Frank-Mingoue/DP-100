// Databricks notebook source
// DBTITLE 1,Include notebook containing functions to read directory and process files inside the directory
// MAGIC %run ../Include/read_write_parse_file

// COMMAND ----------

// MAGIC %run ../1-Raw/get_file_structure

// COMMAND ----------

// MAGIC %run ../1-Raw/get_file_columns

// COMMAND ----------

spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

// COMMAND ----------

// DBTITLE 1,Define variables to read csv files from source and write parquet files to destination


//build the path to read raw data
val source_path = get_container("raw") + "/backup_hra"

//define vaaiable for file extension to read
val extension = "txt"

// define variable for file format 
val format = "text"

//define variable for row separator
val delimiter = "\\n"

//build the folder to write on curated data
val dest_path = get_container("curated") + "/backup_hra"


// temp file path
val temp_file_path = "/tmp/temp_file.csv"

// source folders
val source_folder_list = dbutils.widgets.get("domain").split(",").toList

val file = dbutils.widgets.get("file")

val  partition_column = Seq("PERPAI")




// COMMAND ----------

// DBTITLE 1,Read all the files in the list parse each row in each file, insert file in the curated layer and set a summary for read, inserted and rejected records
var read_records  =  0 //init number of read records
var message="" //init message to return
var num_partitions=""
var log_file = ""
var final_list = List("")

for(folder <- source_folder_list) {
  
  val folder_path = source_path + "/" + folder
  
  // get the list of files in each folder source
  var listfiles = List[String]() //Set an empty list of string to store the files list
  listfiles = getdirectoryfiles(folder_path, extension, listfiles)

  message =  "INF-00 scanning the directory raw/backup_hra/" + folder + "\n"
  log_file = log_file + message
  
  if(listfiles.isEmpty)  {
    //last_load_file = last_load_date
    message = "WAR-10 - the directory raw/backup_hra/" + folder + " is empty or doesn't exist or the files extension is not txt \n"
    log_file = log_file + message

  }
  
  
  
  for(f <- listfiles) {
    
    //object name
    val object_name = getvalueposition(getvalueposition(f, 5, "/"), 1, "_")
     
    
    
     if (file.isEmpty){
       final_list = List(object_name)
     }
    else {      
      final_list = List(file)
    }
    
    
    if (final_list.contains(object_name)) {
    
    // schema
    val file_schema = get_file_structure(object_name)
    
    //columns
    val file_columns = get_file_columns(object_name)
    
    if (object_name != null){
      message =  "INF-00 loading the file " + folder + "/" + object_name + "\n"
      log_file = log_file + message
    }
    
    //Test if the schema of object name is empty
    if(file_schema==null )
    {
        if (object_name != null){
        message =  "ERR-11 the schema of the file " + object_name + " is not defined \n\n"
        log_file = log_file + message
        }
    
    }
    
    else{
      
      println(f)
      var filenameDF = spark.read.format(format) 
                  .option("sep", delimiter)
                  .option("header", "false")
                  .option("quote", "\"")
                  .option("escape", "\"")
                  .option("multiline",true)
                  .load(f)
                  
    
      //Test if dataframe contains data
      if(filenameDF.isEmpty)
      {
        message = "ERR-12 the file" + f + " is empty \n"
         log_file = log_file + message
      }
    
    
      else
      {
        
      filenameDF.cache() // put the dataframe in the cache
      read_records = filenameDF.count().toInt //the number of read data 
      message =  "INF-00 The file " + object_name + " has :" + read_records + "\n"
      log_file = log_file + message
      

      //Calculate the size of file
      var size = calcRDDSize(filenameDF.rdd.map(_.toString()))

      //Define the number of partitions to write
      num_partitions = scala.math.round(size*(9.31*scala.math.pow(10, -10))).toString

      if(num_partitions < "1") { num_partitions="1" } //if the variable num_paritions is 0 => we should write one partiton

      //specify the shuffle of partitions
      //sqlContext.setConf("spark.sql.shuffle.partitions", num_partitions)
    
  
      //parse each row in the file by skipping the column filepath on header check        
      var  df_final =  parse_file_zx6b(filenameDF,delimiter,extension,file_schema,file_columns,temp_file_path)
        
        
      /**************Filter on rows to reject and add some metadata columns**********************/
      var df_rejected_records = df_final.filter(df_final("error_log") =!= "" ) 
        
      val rejected_records = df_rejected_records.count()  
      message =  "WAR-00 Rejected records :  " + rejected_records + "\n"
      log_file = log_file + message

      if (df_rejected_records.count().toInt > 0)
      {
      
      df_rejected_records.cache() // put the dataframe in the cache
      
      val dest_folder_path =   dest_path + "/" + folder + "/rejected"  
      writeadls_nopartition(df_rejected_records,dest_folder_path,object_name,"parquet","overwrite")
        
      }
      
        
      /**************Filter on rows to insert and add some metadata columns**********************/
      var df_inserted_records = df_final.filter(df_final("error_log") === "")
                          .drop("error_log") //drop the error_log column created during the file parsing
        
      val df_inserted_records_final = infer_schema(df_inserted_records, temp_file_path, file_schema, true)
      
      val inserted_records = df_inserted_records_final.count()
      message =  "INF-00 Inserted records :  " + inserted_records + "\n"
      log_file = log_file + message
        
      /**************write the file in the destination filet**********************/
      if (df_inserted_records_final.count().toInt > 0) {
        
      df_inserted_records_final.cache() // put the dataframe in the cache       
        
        //wrie into adls  #load file in curated
      val dest_folder_path =   dest_path + "/" + folder    
      writeadls(df_inserted_records_final,dest_folder_path,object_name,"parquet","overwrite", partition_column, folder)
      
      df_inserted_records_final.unpersist
      }
        
      

      
      message =  "INF-00 End of loading for  " + folder + "/" + object_name + "\n\n"
      log_file = log_file + message        
        
      df_final.unpersist
      df_rejected_records.unpersist
     
      filenameDF.unpersist
      
         
      }  
        
      
    }
  }  //end if filelist.contains
  }
  
  
}

// COMMAND ----------

println(log_file)

// COMMAND ----------

register_log_file(log_file, dest_path)

// COMMAND ----------

// DBTITLE 1,Clear Cache
 spark.sql("clear cache")

// COMMAND ----------

// DBTITLE 1,Return read, inserted and rejected records
//dbutils.notebook.exit(return_value)