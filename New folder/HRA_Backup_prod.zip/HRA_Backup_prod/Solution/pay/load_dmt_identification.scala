// Databricks notebook source
// MAGIC %run ../../Include/read_write_parse_file

// COMMAND ----------

val jdbcurl = getSQLurl()
val connectionproperties = getSQLproperties()
//val default_hierarchy_value="Non affecté"

// COMMAND ----------

// dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "referentiel", "domain" -> "common"))
var df_ref_read = spark.table("hrabackup_common.referentiel")
                                                      
df_ref_read.createOrReplaceTempView("vw_ref")
df_ref_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read ZX00 table
//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZX00", "domain" -> "pay"))

var df_ZX00_read = spark.table("hrabackup_pay.ZX00")

//find and get column labels
df_ZX00_read = gettranscoHRA(df_ZX00_read, df_ref_read, "ZX00")
                                                      
df_ZX00_read.createOrReplaceTempView("vw_ZX00")
df_ZX00_read.cache()  //cache the dataframe

// COMMAND ----------

// DBTITLE 1,init and read ZX6B table
var df_ZX6B_read = spark.table("hrabackup_pay.ZX6B")

//find and get column labels
df_ZX6B_read = gettranscoHRA(df_ZX6B_read, df_ref_read, "ZX6B")
                                                      
df_ZX6B_read.createOrReplaceTempView("vw_ZX6B")
df_ZX6B_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC select DISTINCT PERPAI from vw_ZX00
// MAGIC -- WHERE PERPAI IS NULL
// MAGIC order by PERPAI

// COMMAND ----------

// dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYWO", "domain" -> "career"))

val df_ZYWO_read = spark.table("hrabackup_career.ZYWO")
                                                      
df_ZYWO_read.createOrReplaceTempView("vw_ZYWO")
df_ZYWO_read.cache()  //cache the dataframe

// COMMAND ----------

//dbutils.notebook.run(" ../../../../Init/init_curated_databases",0, Map("table" -> "ZYWO", "domain" -> "career"))

val df_ZY00_read = spark.table("hrabackup_career.ZY00")
                                                      
df_ZY00_read.createOrReplaceTempView("vw_ZY00")
df_ZY00_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql 
// MAGIC select * from vw_ZY00

// COMMAND ----------


var df_ZX38_read = spark.table("hrabackup_pay.ZX38")

//find and get column labels
df_ZX38_read = gettranscoHRA(df_ZX38_read, df_ref_read, "ZX38")
                                                      
df_ZX38_read.createOrReplaceTempView("vw_ZX38")
df_ZX38_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql 
// MAGIC 
// MAGIC select * from vw_ZX38

// COMMAND ----------


var df_ZX37_read = spark.table("hrabackup_pay.ZX37")

//find and get column labels
df_ZX37_read = gettranscoHRA(df_ZX37_read, df_ref_read, "ZX37")
                                                      
df_ZX38_read.createOrReplaceTempView("vw_ZX37")
df_ZX38_read.cache()  //cache the dataframe

// COMMAND ----------

val df_ZX35_read = spark.table("hrabackup_pay.ZX35")
                                                      
df_ZX35_read.createOrReplaceTempView("vw_ZX35")
df_ZX35_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql 
// MAGIC 
// MAGIC select * from vw_ZX35

// COMMAND ----------

val df_ZX33_read = spark.table("hrabackup_pay.ZX33")
                                                      
df_ZX33_read.createOrReplaceTempView("vw_ZX33")
df_ZX33_read.cache()  //cache the dataframe

// COMMAND ----------

val df_ZX31_read = spark.table("hrabackup_pay.ZX31")
                                                      
df_ZX31_read.createOrReplaceTempView("vw_ZX31")
df_ZX31_read.cache()  //cache the dataframe

// COMMAND ----------

var df_ZX0M_read = spark.table("hrabackup_pay.ZX0M")

//find and get column labels
df_ZX0M_read = gettranscoHRA(df_ZX0M_read, df_ref_read, "ZX0M")
                                                      
df_ZX0M_read.createOrReplaceTempView("vw_ZX0M")
df_ZX0M_read.cache()  //cache the dataframe

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from vw_ZX0M
// MAGIC -- order by NUDOSS

// COMMAND ----------

//spark.read.jdbc(jdbcurl, "dbo.vw_ref_degree_level", connectionproperties).createOrReplaceTempView("vw_ref_degree_level")

// COMMAND ----------

val query_record = """ 
                   select 
                     vw_ZX00.NUDOSS AS numero_dossier
                    ,vw_ZX00.MATRIC AS matricule_hra
                    ,vw_ZYWO.MATWOR AS matricule_WD
                    ,vw_ZX31.NOMUSE AS nom_salarie
                    ,vw_ZX33.PRENOM AS prenom_salarie
                    ,vw_ZX35.DATENT AS date_entree
                    ,vw_ZX35.DATSOR AS date_sortie
                    ,vw_ZX0M.IDESTA AS etablissement
                    ,vw_ZX38.COCONV AS code_convention_CCN
                    ,vw_ZX6B.CODSOC AS societe
                    ,vw_ZX35.ANCIE5 AS date_anciennete
                    ,CASE
                        WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 < 6 THEN "Moins de 6 mois"
                        WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 6 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 12  THEN "Entre 6 mois et 1 an"
                        WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 12 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 36  THEN "1 à 3 ans"
                        WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 36 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 60  THEN "3 à 5 ans"
                        WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 60 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 120  THEN "5 à 10 ans"
                        WHEN DATEDIFF("2022-06-30", ANCIE5) / 30 >= 120 and  DATEDIFF("2022-06-30", ANCIE5) / 30 < 240  THEN "10 à 20 ans"
                        ELSE "Plus de 20 ans"
                     END as anciennete 
                    ,vw_ZX38.QUALIF AS qualification
                    ,vw_ZX38.CLASSI AS classification
                    ,vw_ZX0M.TYPCON AS type_contrat
                    ,vw_ZX0M.NATCON AS nature_contrat
                    ,vw_ZX0M.CODTRA AS type_temps_contractuel
                    ,vw_ZX0M.NBSTHM AS heures_presence_mois
                    ,vw_ZX00.PERPAI AS periode_paie
                    ,vw_ZX00.NUDOSP AS identifiant_dossier_paie
                    ,vw_ZX00.NUMBUL AS numero_bulletin
                    ,vw_ZX00.TYPAIE AS type_paie


                    FROM vw_ZX00 
                    JOIN vw_ZX31 ON vw_ZX31.NUDOSS = vw_ZX00.NUDOSS
                    JOIN vw_ZX33 ON vw_ZX33.NUDOSS = vw_ZX00.NUDOSS
                    JOIN vw_ZX35 ON vw_ZX35.NUDOSS = vw_ZX00.NUDOSS
                    JOIN vw_ZX38 ON vw_ZX38.NUDOSS = vw_ZX00.NUDOSS
                    JOIN vw_ZX0M ON vw_ZX0M.NUDOSS = vw_ZX00.NUDOSS
                    JOIN vw_ZX6B ON vw_ZX6B.NUDOSS = vw_ZX00.NUDOSS
                    LEFT JOIN vw_ZY00 ON vw_ZY00.MATCLE = vw_ZX00.MATRIC
                    LEFT JOIN vw_ZYWO ON vw_ZYWO.NUDOSS = vw_ZY00.NUDOSS 
                    WHERE vw_ZX00.PERPAI NOT IN ("MT202204", "MT202205", "MT202206")
                      """ 

// COMMAND ----------

val filtres_inserted = spark.sql(query_record)
filtres_inserted.cache()  //put the dataframe ont he cache 

// COMMAND ----------

display(filtres_inserted)

// COMMAND ----------

val connection = getSQLconnection()
val stmt = connection.createStatement()
val query_delete = """ truncate table pay.filtres """
val res = stmt.execute(query_delete)

connection.close()

// COMMAND ----------

filtres_inserted.distinct.write.mode(SaveMode.Append).jdbc(jdbcurl, "pay.filtres", connectionproperties)

// COMMAND ----------

// DBTITLE 1,Remove Dataframes from cache
df_ZX0M_read.unpersist
df_ZX00_read.unpersist
df_ZY00_read.unpersist
df_ZYWO_read.unpersist
df_ZX38_read.unpersist
df_ZX31_read.unpersist
df_ZX33_read.unpersist
df_ZX35_read.unpersist
df_ZX37_read.unpersist
df_ZX6B_read.unpersist
filtres_inserted.unpersist

// COMMAND ----------

/*dbutils.notebook.exit(return_value)