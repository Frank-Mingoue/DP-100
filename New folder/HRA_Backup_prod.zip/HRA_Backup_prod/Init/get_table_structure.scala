// Databricks notebook source

def get_table_structure(tablename: String, domain: String) : String = {

var struct: String = null
  
struct = tablename  match {   


//------------ZX00 
case "ZX00" =>
	s"""create table if not exists hrabackup_${domain}.ZX00(
	NUDOSS int,
	SOCCLE string, 
 	MATRIC string, 
 	NUDOSP int, 
 	PERPAI string, 
 	NUMBUL string, 
 	TYPAIE string, 
 	NOMSAL string, 
 	TILOAD date,
    NUGEST int)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX00/";"""


//------------ZX0M 
case "ZX0M" =>
	s"""create table if not exists hrabackup_${domain}.ZX0M(
	NUDOSS int,
	IDCONT string, 
 	DATDEB date, 
 	DATFIN date, 
 	TYPCON string, 
 	LIBTYC string, 
 	NATCON string, 
 	LIBNAC string, 
 	DURANN int, 
 	DURMOI int, 
 	DURJOU int, 
 	DEBESS date, 
 	FINESS date, 
 	QUALIF string, 
 	LIBEMP string, 
 	CLASSI string, 
 	LIBCLA string, 
 	POSITI string, 
 	LIBPOS string, 
 	INDICE string, 
 	LIBIND string, 
 	COEFFI string, 
 	LIBCOE string, 
 	NIVEAU string, 
 	ECHELO string, 
 	CONCOV string, 
 	LIBCOC string, 
 	IDESTA string, 
 	LIBETA string, 
 	CODTRA string, 
 	LIBTRA string, 
 	NBSTHD double, 
 	NBSTHW double, 
 	NBSTHM double, 
 	RTSTHR double, 
 	NBPDHD double, 
 	NBPDHW double, 
 	NBPDHM double, 
 	RTPDHR double, 
 	DESCAU string, 
 	RUBAUG string, 
 	LIBRUB string, 
 	MTSAL int, 
 	AMHRL int, 
 	AMPYP int, 
 	CHBASE string, 
 	CHPERS string, 
 	CHSPEC string, 
 	CHNIVE string, 
 	CHECHL string, 
 	COGRPE string, 
 	CONIVE string, 
 	FORANU int,
    PERPAI string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX0M/";"""


//------------ZX35 
case "ZX35" =>
	s"""create table if not exists hrabackup_${domain}.ZX35(
	NUDOSS int,
	DATENT date, 
 	DATSOR date, 
 	PHYSOR date, 
 	CODENT string, 
 	LIBENT string, 
 	CODSOR string, 
 	LIBSOR string, 
 	CGSTHI string, 
 	LIBCGS string, 
 	RSSTHI string, 
 	LIBRSS string, 
 	CGSTAT string, 
 	LIBCST string, 
 	RSSTAT string, 
 	LIBRST string, 
 	ANCIEN date, 
 	DATEUT date, 
 	ANCIE3 date, 
 	ANCIE4 date, 
 	ANCIE5 date, 
 	ANCIE6 date,
    PERPAI string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX35/";"""


//------------ZX37 
case "ZX37" =>
	s"""create table if not exists hrabackup_${domain}.ZX37(
	NUDOSS int,
	ETABLI string, 
 	LIBETA string, 
 	DIRECT string, 
 	SERVIC string, 
 	SECTIO string, 
 	SOUSEC string,
    PERPAI string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX37/";"""


//------------ZX38 
case "ZX38" =>
	s"""create table if not exists hrabackup_${domain}.ZX38(
	NUDOSS int,
	QUALIF string, 
 	CLASSI string, 
 	LIBQUA string, 
 	LIBCLA string, 
 	COCONV string, 
 	REGSPE string, 
 	LIBCOC string,
    PERPAI string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX38/";"""


//------------ZX3B 
case "ZX3B" =>
	s"""create table if not exists hrabackup_${domain}.ZX3B(
	NUDOSS int,
	CODCON string, 
 	ANNEES date, 
 	IDZYES int, 
 	DATDEB date, 
 	DATFIN date, 
 	DEBACQ date, 
 	FINACQ date, 
 	ACQUIA double, 
 	DRTPRI double, 
 	RESTAN double,
    PERPAI string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX3B/";"""


//------------ZX40 
case "ZX40" =>
	s"""create table if not exists hrabackup_${domain}.ZX40(
	NUDOSS int,
	DATEFF date, 
 	CODTRA string, 
 	LIBTRA string, 
 	NBSTHD double, 
 	NBSTHW double, 
 	NBSTHM double, 
 	RTSTHR double, 
 	NBPDHD double, 
 	NBPDHW double, 
 	NBPDHM double, 
 	RTPDHR double, 
 	FORANU int, 
 	FORANH double,
    PERPAI string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX40/";"""


//------------ZX5V 
case "ZX5V" =>
	s"""create table if not exists hrabackup_${domain}.ZX5V(
	NUDOSS int,
	VALIDT string, 
 	TIMVAL date,
    PERPAI string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX5V/";"""


//------------ZX6A 
case "ZX6A" =>
	s"""create table if not exists hrabackup_${domain}.ZX6A(
	NUDOSS int,
	DEBABS date, 
 	IDEREM string, 
 	CODABS string, 
 	SOURCE string, 
 	LIBELL string, 
 	FINABS date,
    PERPAI string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX6A/";"""


//------------ZX6C 
case "ZX6C" =>
	s"""create table if not exists hrabackup_${domain}.ZX6C(
	NUDOSS int,
	NUMCUM string, 
 	PERDEB string, 
 	LIBCUM string, 
 	MONCUM double,
    PERPAI string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX6C/";"""


//------------ZX6P 
case "ZX6P" =>
	s"""create table if not exists hrabackup_${domain}.ZX6P(
	NUDOSS int,
	RUBPRE string, 
 	ORDPRE int, 
 	NUMPRE string, 
 	LIBPRE string, 
 	MONPR int, 
 	DEBPRE date, 
 	FINPRE date, 
 	ECHPRE int, 
 	MENPR int, 
 	SOLPR int, 
 	TXIPRE double, 
 	MTINT int, 
 	DTCONC date, 
 	DTVIRC date, 
 	CAPNA int, 
 	SOLAV int,
    PERPAI string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX6P/";"""


//------------ZX8K 
case "ZX8K" =>
	s"""create table if not exists hrabackup_${domain}.ZX8K(
	NUDOSS int,
	CODRUB string, 
 	PERVAL int, 
 	DATRUB date, 
 	CODRAP string, 
 	SOURCE string, 
 	CALCUL string, 
 	LIBELL string, 
 	NBRBAS double, 
 	TAUSAL double, 
 	MONSAL double, 
 	TAUPAT double, 
 	MONPAT double, 
 	IMPUTA string, 
 	ZONEUT string, 
 	CODABS string, 
 	DEBABS date, 
 	FINABS date, 
 	MEMO01 string, 
 	MEMO02 string, 
 	MEMO03 string, 
 	MEMO04 string, 
 	MEMO05 string, 
 	MEMO06 string, 
 	MEMO07 string, 
 	MEMO08 string, 
 	MEMO09 string, 
 	MEMO10 string, 
 	MEMO11 string, 
 	CODORG string, 
 	LIBORG string, 
 	QLPRW1 string, 
 	QLPRW2 string, 
 	QLPRW3 string, 
 	QLPRW4 string, 
 	QLPRW5 string, 
 	QLPRW6 string, 
 	QLPRW7 string, 
 	QLPRW8 string, 
 	TEJOU7 string, 
 	RGPOSJ string, 
 	TEBULQ string, 
 	TEBULD int, 
 	TEBULT string, 
 	TEBULM string, 
 	RGPOSB string, 
 	RGPOSA string, 
 	RGPOSE string,
    PERPAI string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX8K/";"""


//------------ZXM7 
case "ZXM7" =>
	s"""create table if not exists hrabackup_${domain}.ZXM7(
	NUDOSS int,
	TYPCPT string, 
 	DATOUV date, 
 	DTFERM date, 
 	SOLCPT double, 
 	SOLCTH double, 
 	SOLCHE int, 
 	DTUTIL date, 
 	DTFIN date,
    PERPAI string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZXM7/";"""


//------------ZXMM 
case "ZXMM" =>
	s"""create table if not exists hrabackup_${domain}.ZXMM(
	NUDOSS int,
	CPTDSN string, 
 	CODRUB string, 
 	SOURCE string, 
 	TYPPAR string, 
 	CATEGO string, 
 	TYPCOD string, 
 	MONTA1 double, 
 	MONTA2 double, 
 	MONTA3 double, 
 	DATE01 date, 
 	DATE02 date, 
 	DTDEBO date, 
 	DTFINO date, 
 	IDOPSD string, 
 	TYPORG string, 
 	V23002 string, 
 	CDINSE string, 
 	TAUEFF double, 
 	CODDEC string, 
 	PERPAI string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZXMM/";"""


//------------ZY19 
case "ZY19" =>
	s"""create table if not exists hrabackup_${domain}.ZY19(
	NUDOSS int,
	DATAN1 date, 
 	DATAN2 date, 
 	DATAN3 date, 
 	DATAN4 date, 
 	DATAN5 date, 
 	DATAN6 date)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZY19/";"""


//------------ZY1M 
case "ZY1M" =>
	s"""create table if not exists hrabackup_${domain}.ZY1M(
	NUDOSS int,
	IMMAT string, 
 	IDCTRY string, 
 	DATDEB date, 
 	DATFIN date, 
 	DATIMM date, 
 	PUISVH int, 
 	TYPEVH string, 
 	CONSTR string, 
 	MODELE string, 
 	CYLIND int, 
 	FUELTY string, 
 	VALUE int)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZY1M/";"""


//------------ZY1S 
case "ZY1S" =>
	s"""create table if not exists hrabackup_${domain}.ZY1S(
	NUDOSS int,
	DTEF1S date, 
 	STEMPL string, 
 	CGSTAT string, 
 	RSSTAT string, 
 	FLABGN string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZY1S/";"""


//------------ZY24 
case "ZY24" =>
	s"""create table if not exists hrabackup_${domain}.ZY24(
	NUDOSS int,
	NUDOSP int, 
 	TRANST string, 
 	DATEFF date, 
 	ENDDAT date, 
 	IDCONT string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZY24/";"""


//------------ZY35 
case "ZY35" =>
	s"""create table if not exists hrabackup_${domain}.ZY35(
	NUDOSS int,
	DTEF00 date, 
 	IDJB00 string, 
 	RTASSI string, 
 	LBEMLG string, 
 	IDPS00 string, 
 	IDOU00 string, 
 	LBEMSH string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZY35/";"""


//------------ZY38 
case "ZY38" =>
	s"""create table if not exists hrabackup_${domain}.ZY38(
	NUDOSS int,
	DTEF00 date, 
 	DTEN00 date, 
 	IDESTA string, 
 	RSTRAN string, 
 	DTTRAN date)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZY38/";"""


//------------ZY3B 
case "ZY3B" =>
	s"""create table if not exists hrabackup_${domain}.ZY3B(
	NUDOSS int,
	DTEF00 date, 
 	DTEN00 date, 
 	NBASHR double, 
 	NBFTES double, 
 	DTPSSE date, 
 	IDPS00 string, 
 	IDJB00 string, 
 	IDOU00 string, 
 	RTASSI int)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZY3B/";"""


//------------ZY4K 
case "ZY4K" =>
	s"""create table if not exists hrabackup_${domain}.ZY4K(
	NUDOSS int,
	IDPOCR string, 
 	IDSUAR string, 
 	DTEF00 date, 
 	DTEN00 date, 
 	RTDIST double)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZY4K/";"""


//------------ZY5G 
case "ZY5G" =>
	s"""create table if not exists hrabackup_${domain}.ZY5G(
	NUDOSS int,
	IDCONT string, 
 	DATDEB date, 
 	DATFIN date, 
 	CODE string, 
 	INDCYC int)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZY5G/";"""


//------------ZYAF 
case "ZYAF" =>
	s"""create table if not exists hrabackup_${domain}.ZYAF(
	NUDOSS int,
	DATAFF date, 
 	DATFIN date, 
 	LEVEL5 string, 
 	LEVEL7 string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYAF/";"""


//------------ZYAG 
case "ZYAG" =>
	s"""create table if not exists hrabackup_${domain}.ZYAG(
	NUDOSS int,
	DATDEB date, 
 	MOTIFA string, 
 	HRSDEB int, 
 	DATFIN date, 
 	HRSFIN int, 
 	TEMDEB string, 
 	TEMFIN string, 
 	GESTIO string, 
 	PROLON string, 
 	NBHEUR int, 
 	IDLVSR string, 
 	IDRTST string, 
 	IDRTSC string,
 	IDRTSR string, 
 	NAABPD string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYAG/";"""


//------------ZYAR 
case "ZYAR" =>
	s"""create table if not exists hrabackup_${domain}.ZYAR(
	NUDOSS int,
	DATCRM date, 
 	REFCRM string, 
 	DATDEB date, 
 	DTFNJR date, 
 	TAUPAS string, 
 	TYPBAR string, 
 	TEMBCH string, 
 	TEMENR string, 
 	DATDIS date)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYAR/";"""


//------------ZYAU 
case "ZYAU" =>
	s"""create table if not exists hrabackup_${domain}.ZYAU(
	NUDOSS int,
	DATEFF date, 
 	RUBAUG string, 
 	MTSAL int, 
 	CMOTIF string, 
 	MTAUG int, 
 	DATFIN date)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYAU/";"""


//------------ZYCA 
case "ZYCA" =>
	s"""create table if not exists hrabackup_${domain}.ZYCA(
	NUDOSS int,
	DATEFF date, 
 	DATFIN date, 
 	QUALIF string, 
 	CLASSI string, 
 	COCONV string, 
 	TYPREG string, 
 	CHBASE string, 
 	CHSPEC string, 
 	COGRPE string, 
 	CONIVE string, 
 	EXTCF1 string, 
 	CHPERS string, 
 	CHNIVE string, 
 	CHECHL string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYCA/";"""


//------------ZYCO 
case "ZYCO" =>
	s"""create table if not exists hrabackup_${domain}.ZYCO(
	NUDOSS int,
	DATCON date, 
 	DATFIN date, 
 	TYPCON string, 
 	NATCON string, 
 	DATPRE date, 
 	FINESS date, 
 	NBHEUC double, 
 	MOISCL int, 
 	MONTAN double, 
 	POURCE double, 
 	CONTRA string, 
 	CLLEVE string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYCO/";"""


//------------ZYCS 
case "ZYCS" =>
	s"""create table if not exists hrabackup_${domain}.ZYCS(
	NUDOSS int,
	NUDOSP int, 
 	CODCAI string, 
 	REGIME string, 
 	DEBCAI date, 
 	FINCAI date, 
 	NUMCAI string, 
 	IDCONT string, 
 	MOTRUP string, 
 	MOTSOR string, 
 	FLMAJC string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYCS/";"""


//------------ZYCU 
case "ZYCU" =>
	s"""create table if not exists hrabackup_${domain}.ZYCU(
	NUDOSS int,
	NUDOSP int, 
 	NUMCUM string, 
 	IDCY00 string, 
 	PCUMSS string, 
 	CUMANN string, 
 	CUMPER string, 
 	MONCUM double)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYCU/";"""


//------------ZYDA 
case "ZYDA" =>
	s"""create table if not exists hrabackup_${domain}.ZYDA(
	NUDOSS int,
	DATABS date, 
 	MOTABS string, 
 	HRSDEB int, 
 	NUMDRO string, 
 	DATDEB date, 
 	NUMTRA string, 
 	DATFIN date, 
 	HRSFIN int, 
 	TEMDEB string, 
 	TEMFIN string, 
 	UNITE1 double, 
 	UNITE2 double, 
 	NBRJOU double, 
 	DATEAG date)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYDA/";"""


//------------ZYDV 
case "ZYDV" =>
	s"""create table if not exists hrabackup_${domain}.ZYDV(
	NUDOSS int,
	CODCON string, 
 	ANNEES date, 
 	IDZYES int, 
 	DATDEB date, 
 	DATFIN date, 
 	DEBACQ date, 
 	FINACQ date, 
 	ACQUIA double, 
 	REPPRE double, 
 	REPECR double, 
 	REPSUI double, 
 	PAYESS double, 
 	DRTPRI double, 
 	PRICH1 double, 
 	PRICH2 double, 
 	RESTAN double, 
 	AJUST1 double, 
 	MOTIF1 string, 
 	AJUST2 double, 
 	MOTIF2 string, 
 	AJUST3 double, 
 	MOTIF3 string, 
 	AJUST4 double, 
 	MOTIF4 string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYDV/";"""


//------------ZYE4 
case "ZYE4" =>
	s"""create table if not exists hrabackup_${domain}.ZYE4(
	NUDOSS int,
	TYPCPT string, 
 	DTOUV date, 
 	DTFERM date, 
 	SOLCPT double, 
 	SOLCTH double, 
 	SOLCHE int, 
 	DTUTIL date, 
 	DTFIN date)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYE4/";"""


//------------ZYE6 
case "ZYE6" =>
	s"""create table if not exists hrabackup_${domain}.ZYE6(
	NUDOSS int,
	DTOPER date, 
 	TYPOPE string, 
 	TYPCPT string, 
 	NBJOTH double, 
 	NUMORD int, 
 	NBJOUR double, 
 	NBJOUV double, 
 	NBHEUR int, 
 	AMNUM int, 
 	SOLCHE int, 
 	CDORIG string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYE6/";"""


//------------ZYEL 
case "ZYEL" =>
	s"""create table if not exists hrabackup_${domain}.ZYEL(
	NUDOSS int,
	NUDOSP int, 
 	CODFIX string, 
 	DEBFIX date, 
 	FINFIX date, 
 	CFORMA string, 
 	NBRBAS double, 
 	SALFIX double, 
 	PATFIX double, 
 	TESELE string, 
 	IMPUTA string, 
 	MEMO01 string, 
 	MEMO02 string, 
 	DATE01 date, 
 	DATE02 date)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYEL/";"""


//------------ZYES 
case "ZYES" =>
	s"""create table if not exists hrabackup_${domain}.ZYES(
	NUDOSS int,
	DATENT date, 
 	CODENT string, 
 	IDZYES int, 
 	DATSOR date, 
 	CODSOR string, 
 	PHYSOR date, 
 	IDCY00 string, 
 	CGSTAT string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYES/";"""


//------------ZYHB 
case "ZYHB" =>
	s"""create table if not exists hrabackup_${domain}.ZYHB(
	NUDOSS int,
	DATDEB date, 
 	DTDECI date, 
 	DATFIN date, 
 	FLDUR1 string, 
 	FLCHAU string, 
 	FLCOTO string, 
 	FLEA00 int, 
 	FLESTA int, 
 	FLCDTD int, 
 	FLINVP int, 
 	FLSAPO int, 
 	FLASMU int, 
 	TEMAVI int, 
 	FLMUTG int, 
 	FLALLO int, 
 	TEMCAR int, 
 	TEMHAN int, 
 	FLHPLD string, 
 	POUHAN double, 
 	DATPEN date, 
 	CATPEN string, 
 	TXINCA double, 
 	TEMHAT int, 
 	FL5212 int, 
 	IDMCAT string, 
 	FLMADE string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYHB/";"""


//------------ZYPR 
case "ZYPR" =>
	s"""create table if not exists hrabackup_${domain}.ZYPR(
	NUDOSS int,
	NUDOSP int, 
 	RUBPRE string, 
 	ORDPRE int, 
 	NUMPRE string, 
 	MONPR int, 
 	DEBPRE date, 
 	FINPRE date, 
 	ECHPRE int, 
 	MENPR int, 
 	SOLPR int, 
 	TXINTE double, 
 	MTINT int, 
 	DTCONC date)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYPR/";"""


//------------ZYRG 
case "ZYRG" =>
	s"""create table if not exists hrabackup_${domain}.ZYRG(
	NUDOSS int,
    RUBREG string,
	MONT1 int, 
 	MONT2 long, 
 	MONT3 int, 
 	MONT4 int, 
 	MONT5 int, 
 	RESUL int)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYRG/";"""


//------------ZYTL 
case "ZYTL" =>
	s"""create table if not exists hrabackup_${domain}.ZYTL(
	NUDOSS int,
	DATEFF date, 
 	CODTRA string, 
 	NBSTHW double, 
 	NBSTHM double, 
 	RTSTHR double, 
 	NBPDHW double, 
 	NBPDHM double, 
 	FORANU int, 
 	MODHOR string, 
 	NBSTHD double, 
 	RTPDHR double)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYTL/";"""


//------------ZYWB 
case "ZYWB" =>
	s"""create table if not exists hrabackup_${domain}.ZYWB(
	NUDOSS int,
	DATNOT date, 
 	PREEFF string, 
 	DADEB1 date, 
 	DAFIN1 date, 
 	PREPAY string, 
 	DADEB2 date, 
 	DAFIN2 date, 
 	DAPHYS date, 
 	PRENPA string, 
 	DADEB3 date, 
 	DAFIN3 date, 
 	PRENEF string, 
 	MOTIFS string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYWB/";"""


//------------ZYWV 
case "ZYWV" =>
	s"""create table if not exists hrabackup_${domain}.ZYWV(
	NUDOSS int,
	DATDEB date, 
 	DATFIN date, 
 	TYPDET string, 
 	PAYDET string, 
 	SITFAM string, 
 	RESFIS string, 
 	NUMORD string)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYWV/";"""


//------------ZYWW 
case "ZYWW" =>
	s"""create table if not exists hrabackup_${domain}.ZYWW(
	NUDOSS int,
	CODREG string, 
 	DATDEB date, 
 	DATFIN date, 
 	REPART int)
 	USING PARQUET 
 	LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYWW/";"""

  
  
  //------------ZY00 
    case "ZY00" => 
        s"""create table if not exists hrabackup_${domain}.ZY00 (
        NUDOSS int,                                                                                         
        MATCLE string,                                                                    
        NOMPAT string,                                                                                 
        N05TRI string,                                                                                                      
        VALID5 string,                                                                                                      
        PRENOM string,                                                                                                      
        PRENO2 string,                                                                                    
        QUALIT string,                                                                                                      
        NOMUSE string,                                                                                                      
        PARTUS string,                                                                                     
        N07TRI string,                                                                                    
        VALIDE string)
        USING PARQUET
        LOCATION "/mnt/curated_container/backup_hra/${domain}/ZY00/";"""


    //------------ZYWO 
    case "ZYWO" => 
        s"""create table if not exists hrabackup_${domain}.ZYWO (
        NUDOSS int,
        MATWOR string)
        USING PARQUET
        LOCATION "/mnt/curated_container/backup_hra/${domain}/ZYWO/";"""
  
    //------------ZX33 
  case "ZX33" =>
      s"""create table if not exists hrabackup_${domain}.ZX33(
      NUDOSS int, 
      SOCDOS string, 
      PGPDOS int, 
      PRENOM string, 
      PRENO2 string, 
      IDGPRG int, 
      SOCCLE string, 
      MATRIC string, 
      NUDOSP int, 
      IDSITU string, 
      PERPAI string, 
      USAGEP string, 
      NUMTRT string, 
      NUMBUL string, 
      TIMEST date)
      USING PARQUET 
      LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX33/";"""
  
    //------------ZX31 
  case "ZX31" =>
      s"""create table if not exists hrabackup_${domain}.ZX31(
      NUDOSS int, 
      NULIGN int, 
      SOCDOS string, 
      PGPDOS int, 
      CODLAN string, 
      NOMUSE string, 
      QUALIT string, 
      LIBQUA string, 
      PARTUS string, 
      INITUS string, 
      N07TRI string, 
      MODSIT string, 
      SITFAM string, 
      REPSIT string, 
      LIBSIT string, 
      ZONEUT string, 
      IDGPRG int, 
      SOCCLE string, 
      MATRIC string, 
      NUDOSP int, 
      IDSITU string, 
      PERPAI string, 
      USAGEP string, 
      NUMTRT string, 
      NUMBUL string, 
      TIMEST date)
      USING PARQUET 
      LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX31/";"""
  
    //------------ZX4K 
    case "ZX4K" =>
        s"""create table if not exists hrabackup_${domain}.ZX4K(
        NUDOSS int, 
        NULIGN int, 
        SOCDOS string, 
        PGPDOS int, 
        IDGLCY string, 
        IDPOCR string, 
        IDPOCF string, 
        IDGLAR string, 
        IDGLAF string, 
        IDSUBR string, 
        IDSUBF string, 
        CODRUB string, 
        IDCONT string, 
        DEBCRE string, 
        CDSIGN string, 
        AMOUNT double, 
        CURCY string, 
        CURCYX string, 
        IDGPRG int, 
        SOCCLE string, 
        MATRIC string, 
        NUDOSP int, 
        IDSITU string, 
        PERPAI string, 
        USAGEP string, 
        NUMTRT string, 
        NUMBUL string, 
        TIMEST date, 
        NBRBAS double, 
        TAUXXX double)
        USING PARQUET 
        LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX4K/";"""
  
  
   //------------referentiel 
  
    case "referentiel" =>
        s"""create table if not exists hrabackup_${domain}.referentiel(
         code_repertoire string,
         libelle_long string,
         libelle_court string,
         code string,
         libelle_repertoire string,
         nom_colonne string,
         nom_table string)
        USING PARQUET 
        LOCATION "/mnt/curated_container/backup_hra/${domain}/referentiel/";"""

  
  //------------ZX6B 
  
    case "ZX6B" =>
        s"""create table if not exists hrabackup_${domain}.ZX6B(
         NUDOSS int,
         CODSOC string,
         LIBSOC string,
         PERPAI string)
        USING PARQUET 
        LOCATION "/mnt/curated_container/backup_hra/${domain}/ZX6B/";"""
    case default => null
    }
  
   return struct
}

// COMMAND ----------

