USE [SIEBEL_OLTP_DEV14_25Nov2021]
GO

/****** Object:  StoredProcedure [dbo].[sp_CLEANSE_OLTP_StagingDB]    Script Date: 12/7/2021 10:02:35 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE	procedure [dbo].[sp_CLEANSE_OLTP_StagingDB]

AS
BEGIN

DECLARE

@NAME NVARCHAR (50);

BEGIN

	IF NOT EXISTS (SELECT 1 FROM StagingDB.sys.tables WHERE name='TABLES_DROPPED_AUTO')
		BEGIN
			CREATE TABLE StagingDB.dbo.TABLES_DROPPED_AUTO 
				(
				ROW_WID int IDENTITY(1,1) PRIMARY KEY,
				TABLE_NAME NVARCHAR(50),
				DATE_DROP DATE
				)
		PRINT ' TABLE CREATED: TABLES_DROPPED_AUTO'
END

		DECLARE TABLE_NAME_TO_DEL CURSOR FOR 
		SELECT DISTINCT o.name
		from StagingDB.dbo.sysobjects o
		where xtype = 'U'
		and (
				o.name like '%BKP_%'
			or	o.name like '%BACKUP_%'
			or	o.name like '%BCKUP_%'
			or	o.name like '%bkp_%'
			) 
			and convert(NVARCHAR (10),o.crdate,112)<convert(NVARCHAR (10),getdate()-90,112) -- 3  months policy
		
		OPEN TABLE_NAME_TO_DEL

		FETCH NEXT FROM TABLE_NAME_TO_DEL INTO @NAME
			WHILE @@FETCH_STATUS = 0
				BEGIN
					DECLARE @stmt nvarchar(200);

					IF EXISTS ( SELECT 1 FROM StagingDB.sys.tables WHERE name=@NAME)
						BEGIN
							SET @stmt = N'DROP TABLE StagingDB.[dbo].[' + @NAME +']';
							print @stmt
							EXEC sp_executesql @stmt
							INSERT INTO StagingDB.dbo.TABLES_DROPPED_AUTO (TABLE_NAME,DATE_DROP) VALUES (@NAME,GETDATE())
							DELETE FROM StagingDB.dbo.TABLES_DROPPED_AUTO WHERE DATE_DROP < (GETDATE()-90) -- 3 months policy
						END

		FETCH NEXT FROM TABLE_NAME_TO_DEL INTO @NAME
	END

		CLOSE TABLE_NAME_TO_DEL

		DEALLOCATE TABLE_NAME_TO_DEL
END
END
GO


