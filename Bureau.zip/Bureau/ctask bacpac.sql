SELECT referencing_schema_name, referencing_entity_name, referencing_id, referencing_class_desc, is_caller_dependent
FROM sys.dm_sql_referencing_entities ('dbo.sp_cleanse_segment_ch_sd_denorm', 'OBJECT');


DROP PROCEDURE sp_Cleanse_OLTP_StagingDB

drop function tbl_GetIndexSpace

SELECT * FROM S_ETL_R_IMG_66

StagingDB.dbo

tempdb.sys