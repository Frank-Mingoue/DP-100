USE [SIEBEL_OLTP_DEV14_25Nov2021]
GO

/****** Object:  StoredProcedure [dbo].[Sp_ANALYSIS_IRM]    Script Date: 12/7/2021 10:09:48 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE  PROCEDURE [dbo].[Sp_ANALYSIS_IRM] 

AS
/*******************************************************************************
Name: Sp_ANALYSIS_IRM
Description:Analysis of SP identify tables n columns for upgrade
Author: Gulraaz Usmani
Date :21/05/2015

*******************************************************************************/

BEGIN
	DECLARE @TABLE  NVARCHAR (50)
TRUNCATE TABLE ANALYSIS_RESULT_PER_SP
					
BEGIN
DECLARE TABLE_CURSOR CURSOR FOR 
	
			SELECT distinct  NAME FROM  StagingDB.dbo.OLTP_LIST_ALL_TABLES 
						
		

		OPEN TABLE_CURSOR

		FETCH NEXT FROM TABLE_CURSOR 
		INTO @TABLE
		
		WHILE @@FETCH_STATUS = 0
		BEGIN 
		
		INSERT INTO StagingDB.dbo.OLTP_LIST_SP_TABLES SELECT @TABLE AS TABLENAME FROM ANALYSIS_IRM_TEMP_TABLE WHERE SP like '%'+@TABLE+'%'

		FETCH NEXT FROM TABLE_CURSOR INTO @TABLE
		END
	
		CLOSE TABLE_CURSOR
		DEALLOCATE TABLE_CURSOR
END

end







GO


