USE [SIEBEL_OLTP_DEV14_25Nov2021]
GO

/****** Object:  StoredProcedure [dbo].[sp_Backup_Cleansing_5weeks]    Script Date: 12/7/2021 10:05:59 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--#################################################################################################################################
--	Procedure Name	:sp_Backup_Cleansing_5weeks
--	Description		:This procedure is used to drop backup EIM tables
--	Author			:Rajeshwaree
--	Version			:1.0
--	Process ID		:Change Log:159	ODC Housekeeping - Remove Truncate Table Option
--  Modified by     :Rhishna
--#################################################################################################################################
CREATE PROCEDURE [dbo].[sp_Backup_Cleansing_5weeks]
AS
DECLARE @v_table AS NVARCHAR(250);

DECLARE @v_table_bkp AS NVARCHAR(250);
DECLARE @v_table_prev AS NVARCHAR(250);

DECLARE @STMT_CRE AS NVARCHAR(250);
DECLARE @STMT_REN AS NVARCHAR(250);
DECLARE @STMT_DRO AS NVARCHAR(250);
DECLARE @OLD AS NVARCHAR(250);


DECLARE db_cursor CURSOR
FOR
SELECT  t.NAME
FROM sys.tables t
WHERE t.NAME IN (
		'EIM_ACCNTROUTE'
		)

OPEN db_cursor

FETCH NEXT
FROM db_cursor
INTO @v_table

BEGIN
	SET @v_table_bkp = @v_table + '_CH159_BKP_WK5';
	SET @STMT_DRO = 'DROP TABLE StagingDB.dbo.' + @v_table_bkp;
	
	IF EXISTS (SELECT 1 FROM StagingDB.sys.tables WHERE name = @v_table_bkp)
	begin
	print @STMT_DRO;
	EXECUTE sp_executesql @STMT_DRO;
	end

	--
	SET @v_table_bkp = 'StagingDB.dbo.'+@v_table + '_CH159_BKP_WK4';
	SET @v_table_prev =  'StagingDB.dbo.'+@v_table + '_CH159_BKP_WK5';
	exec sp_rename @v_table_bkp, @v_table_prev;
	
	IF EXISTS (SELECT 1 FROM StagingDB.sys.tables WHERE name = @v_table+ '_CH159_BKP_WK4')
	exec  sp_rename @v_table_bkp, @v_table_prev;

	--
	SET @v_table_bkp = 'StagingDB.dbo.'+@v_table + '_CH159_BKP_WK3';
	SET @v_table_prev = 'StagingDB.dbo.'+@v_table + '_CH159_BKP_WK4';
	
	IF EXISTS (SELECT 1 FROM StagingDB.sys.tables WHERE name = @v_table+ '_CH159_BKP_WK3')
	exec  sp_rename @v_table_bkp, @v_table_prev;

	--
	--
	SET @v_table_bkp = 'StagingDB.dbo.'+@v_table + '_CH159_BKP_WK2';
	SET @v_table_prev = 'StagingDB.dbo.'+@v_table + '_CH159_BKP_WK3';
	
	IF EXISTS (SELECT 1 FROM StagingDB.sys.tables WHERE name = @v_table+ '_CH159_BKP_WK2')
	exec  sp_rename @v_table_bkp, @v_table_prev;

	--
	SET @v_table_bkp = 'StagingDB.dbo.'+@v_table + '_CH159_BKP_WK1';
	SET @v_table_prev = 'StagingDB.dbo.'+@v_table + '_CH159_BKP_WK2';

	
	IF EXISTS (SELECT 1 FROM StagingDB.sys.tables WHERE name = @v_table+ '_CH159_BKP_WK1')
	exec sp_rename @v_table_bkp, @v_table_prev;

	--
	SET @STMT_CRE = 'SELECT * INTO ' + @v_table_bkp + ' FROM ' + @v_table + ' (NOLOCK)';

	EXECUTE sp_executesql @STMT_CRE;

	FETCH NEXT
	FROM db_cursor
	INTO @v_table

	CLOSE db_cursor

	DEALLOCATE db_cursor
END

GO


