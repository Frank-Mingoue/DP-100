USE [SIEBEL_OLTP_DEV14_25Nov2021]
GO

/****** Object:  StoredProcedure [dbo].[sp_Upd_Asset_Component]    Script Date: 12/7/2021 10:14:20 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[sp_Upd_Asset_Component]

AS

BEGIN

/* ******************************************************************************
Name: sp_Upd_Asset_Component

Execution: Session sp_Upd_Asset_Component in SIL_Weekly_Aggregates

Description:Asset and component not linked to same account in OBIEE

Author   : Riteswaree

Change :INC0944976

Release date :Nov 2014

Development Team:TME-DATA-INTERFACE

Versions Change History:1.0 [Initial]
****************************************************************************** */

----------------
--PERFORM BACKUP
----------------

INSERT INTO StagingDB.dbo.S_ASSET_INC0944976
SELECT par.ROW_ID
	,par.ASSET_NUM
	,a.ROW_ID
	,a.ASSET_NUM
	,acca.NAME
	,accpar.NAME
	,a.OWNER_ACCNT_ID
	,par.OWNER_ACCNT_ID
	,GETDATE()
FROM S_ASSET a
INNER JOIN S_ASSET par ON a.PAR_ASSET_ID = par.ROW_ID
LEFT OUTER JOIN S_ORG_EXT acca ON a.OWNER_ACCNT_ID = acca.ROW_ID
LEFT OUTER JOIN S_ORG_EXT accpar ON par.OWNER_ACCNT_ID = accpar.ROW_ID
WHERE isnull(a.OWNER_ACCNT_ID, 'a') <> isnull(par.OWNER_ACCNT_ID, 'b')

-----------------
--CLEAR EIM BATCH	
-----------------

DELETE
FROM EIM_STORE_COND
WHERE IF_ROW_BATCH_NUM BETWEEN 990000
		AND 990999


--------------------------------------------
--DELETE FROM BACKUP RECS OLDER THAN 3 MONTHS
---------------------------------------------

DELETE
FROM StagingDB.dbo.S_ASSET_INC0944976
WHERE TIMESTAMP <= (getdate() - 90)

	-----------------
	--EIM INSERT
	-----------------

INSERT INTO EIM_ASSET (
	IF_ROW_BATCH_NUM
	,IF_ROW_STAT
	,ROW_ID
	,AST_ASSET_NUM
	,AST_PROD_BU
	,AST_PROD_NAME
	,AST_PROD_VEN_BU
	,AST_PROD_VEN_LOC
	,AST_PROD_VEN_NAME
	,AST_REV_NUM
	,AST_BU
	,OWNER_ACCNT_BU
	,OWNER_ACCNT_LOC
	,OWNER_ACCNT_NAME
	)
SELECT 990000
	,'FOR_UPDATE'
	,a.ROW_ID
	,a.ASSET_NUM
	,bup.NAME
	,pr.NAME
	,buv.NAME
	,ven.LOC
	,ven.NAME
	,a.REV_NUM
	,bua.NAME
	,buaccpar.NAME
	,accpar.LOC
	,accpar.NAME
FROM S_ASSET a
INNER JOIN S_BU bua ON bua.ROW_ID = a.BU_ID
INNER JOIN S_ASSET par ON a.PAR_ASSET_ID = par.ROW_ID
LEFT OUTER JOIN S_ORG_EXT acca ON a.OWNER_ACCNT_ID = acca.ROW_ID
LEFT OUTER JOIN S_ORG_EXT accpar ON par.OWNER_ACCNT_ID = accpar.ROW_ID
LEFT OUTER JOIN S_BU buaccpar ON buaccpar.ROW_ID = accpar.BU_ID
LEFT JOIN S_PROD_INT pr ON pr.ROW_ID = a.PROD_ID
LEFT JOIN S_BU bup ON bup.ROW_ID = pr.BU_ID
LEFT JOIN S_ORG_EXT ven ON ven.ROW_ID = pr.VENDR_OU_ID
LEFT JOIN S_BU buv ON buv.ROW_ID = ven.BU_ID
WHERE isnull(a.OWNER_ACCNT_ID, 'a') <> isnull(par.OWNER_ACCNT_ID, 'b')





--SEGMENT batches in table--------------			

UPDATE EIM_STORE_COND
SET IF_ROW_BATCH_NUM = IF_ROW_BATCH_NUM + FLOOR(MS_IDENT / 1000) - (
		SELECT FLOOR(MIN(MS_IDENT) / 1000)
		FROM EIM_STORE_COND
		WHERE IF_ROW_BATCH_NUM = 990000
		)
WHERE IF_ROW_BATCH_NUM = 990000



END




GO


