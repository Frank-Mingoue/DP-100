IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_STATUSSHEET_TMEC]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_STATUSSHEET_TMEC]
GO
 
CREATE    PROCEDURE [dbo].[sp_STATUSSHEET_TMEC] @entity NVARCHAR(10) AS  
/*
Name: [sp_STATUSSHEET_TMEC]
Execution: re-usable session Update_STATUS_SHEET_TMEC
Description: INSERT new TMEC flat file loaded in WC_LOAD_STATUS_G

*/


---- Logging parameters  
DECLARE @OBJECT_TYPE      NVARCHAR(30)    ,  
        @PROCESS_OBJECTS  NVARCHAR(30)    ,  
        @PROCESS_TASKS    NVARCHAR(30)    ,    
        @PROCESS_DESCRIPTION NVARCHAR(100),  
        @DEBUG_VALUE      NVARCHAR(150)   ,  
        @TASK_STATUS      NVARCHAR(30)    ,  
        @COUNTRY_CODE     NVARCHAR(30)    ,  
 @ETL_PROC_WID     NUMERIC(10,0)   ,  
 @ROW_COUNT        NUMERIC(10,0)   ,
 @ROW_CNT          NVARCHAR(30)    ,  
 @ERROR_COD        NVARCHAR(10)     
  
BEGIN  
    -- Logging parameters Assignment  
    SET @OBJECT_TYPE         = 'STORED_PROCEDURE'   
    SET @PROCESS_OBJECTS     = 'sp_STATUSSHEET_TMEC'  
    SET @PROCESS_TASKS       = 'PROCESS Status sheet'  
    SET @PROCESS_DESCRIPTION = 'START of Status sheet'  
    SET @COUNTRY_CODE        = 'ALL'  
    SELECT @ETL_PROC_WID     = MAX(ETL_PROC_WID) FROM W_PARAM_G (NOLOCK)  
  
    EXEC INSERT_WC_PROCESS_EXECUTION_LOG @OBJECT_TYPE        ,  
                                         @PROCESS_OBJECTS    ,  
                                         @PROCESS_TASKS      ,  
                                         @PROCESS_DESCRIPTION,  
                                         '1 : START'        ,  
                                         'STARTED'           ,  
                                         @COUNTRY_CODE       ,  
                                         @ETL_PROC_WID   
  
  
INSERT INTO WC_LOAD_STATUS_G ( BU_NAME           ,   
                               ENTITY            ,   
                               VERSION           ,   
                               FILENAME          ,   
                               FILESIZE          ,  
                               RECORDCOUNT       ,   
                               ERRORCOUNT        ,   
                               WARNINGCOUNT      ,   
                               ETL_PROC_WID      ,   
                               LOAD_DT_WID       ,  
                               LOAD_START_TIME   ,  
                               LOAD_END_TIME     ,  
                               LOAD_DURATION_TIME,  
                               FILE_DT_WID       ,       
                               DB_SOURCE 
                             )  
SELECT  SUBSTRING(a.[FILENAME], 1,2), --Extract the market name from FILENAME  
            SUBSTRING(a.[FILENAME], 3,6), --Extract the Entity from FILENAME  
            SUBSTRING(a.[FILENAME], 9,2), --Extract the version from FILENAME  
            a.[FILENAME],  
          a.FILESIZE,  
            a.RECORDCOUNT,  
            NULL, -- Records that fell in error (to be updated later)  
            NULL, -- Records that fell in warning (to be updated later)  
            a.ETL_PROC_WID,  
            b.ROW_WID, -- The DATE_WID of the load  
           DATENAME(hour,a.LOAD_START_TIME) + ':' + CASE WHEN DATENAME(minute,a.LOAD_START_TIME) < 10   
                                                                 THEN '0' + DATENAME(minute,a.LOAD_START_TIME)  
                                                                      ELSE DATENAME(minute,a.LOAD_START_TIME)  
                                                                         END , -- The start time of the load  
         DATENAME(HOUR,a.LOAD_END_TIME) + ':' + CASE WHEN DATENAME(MINUTE,a.LOAD_END_TIME) < 10   
                                                              THEN '0' + DATENAME(MINUTE,a.LOAD_END_TIME)  
                                                                       ELSE DATENAME(MINUTE,a.LOAD_END_TIME)  
                                                                     END, -- The end time of the load  
         (CASE WHEN ((DATEDIFF(MI,a.LOAD_START_TIME,a.LOAD_END_TIME) - (DATEDIFF(MI,a.LOAD_START_TIME,a.LOAD_END_TIME) % 60))/60) < 10  
                                THEN '0' + CAST(((DATEDIFF(MI,a.LOAD_START_TIME,a.LOAD_END_TIME) -   (DATEDIFF(MI,a.LOAD_START_TIME,a.LOAD_END_TIME) % 60))/60) AS CHAR(1))  
                              ELSE CAST(((DATEDIFF(MI,a.LOAD_START_TIME,a.LOAD_END_TIME) - (DATEDIFF(MI,a.LOAD_START_TIME,a.LOAD_END_TIME) %     60))/60) AS CHAR(2))  
                                 END) +  
                             ':' +   
                        (CASE WHEN (DATEDIFF(MI,a.LOAD_START_TIME,a.LOAD_END_TIME) % 60) < 10  
                               THEN '0' + CAST((DATEDIFF(MI,a.LOAD_START_TIME,a.LOAD_END_TIME) % 60) AS CHAR(1))  
                             ELSE CAST((DATEDIFF(MI,a.LOAD_START_TIME,a.LOAD_END_TIME) % 60) AS CHAR(2))   
           END), -- The duration of the load  
           CAST(SUBSTRING(FILENAME, 14,8) as numeric(10)), -- The date of the file  
           'OLTP' --DB SOURCE
      FROM  WC_ETL_FILES_G a (NOLOCK),   
            W_DAY_D b(NOLOCK)  
     --WHERE  ETL_PROC_WID = (SELECT MAX(ROW_WID) FROM W_ETL_RUN_S)   
       WHERE  ETL_PROC_WID = (SELECT MAX(ETL_PROC_WID) FROM W_PARAM_G)   
--FOLLOWING CONDITION ADDED so as to ignore all SO entities  
    and LEN(a.[FILENAME])=28  
       AND  year(a.PICK_UP_DATE)  = year(b.CALENDAR_DATE)  
       AND  month(a.PICK_UP_DATE) = month(b.CALENDAR_DATE)  
       AND  day(a.PICK_UP_DATE)   = day(b.CALENDAR_DATE)  
       AND  NOT EXISTS ( SELECT 1 FROM WC_LOAD_STATUS_G G  (NOLOCK)  
       WHERE G.ETL_PROC_WID = (SELECT MAX(ETL_PROC_WID) FROM W_PARAM_G)   
       AND G.FILENAME = a.FILENAME)  
       AND (SUBSTRING(a.FILENAME,3,2) =@entity  or @entity='ALL')--INC0843554  



            SET @ROW_CNT   = CAST(@@ROWCOUNT AS NVARCHAR(10))  
            SET @ERROR_COD = CAST(@@ERROR AS NVARCHAR(10))  
  
            SET @PROCESS_DESCRIPTION = 'Insert into WC_LOAD_STATUS_G for current run - Done'   
            SET @DEBUG_VALUE = '2 :Insert into WC_LOAD_STATUS_G for current run'+' Rows DELETED='+@ROW_CNT  
                                                                                +' Error Code='+@ERROR_COD  
            EXEC INSERT_WC_PROCESS_EXECUTION_LOG @OBJECT_TYPE               ,  
                                                 @PROCESS_OBJECTS           ,  
                                                 @PROCESS_TASKS             ,  
                                                 @PROCESS_DESCRIPTION       ,  
                                                 @DEBUG_VALUE               ,  
                                                 'DEBUG_INFO'               ,  
                                                 @COUNTRY_CODE              ,  
                                                 @ETL_PROC_WID    

  
UPDATE WC_LOAD_STATUS_G  
   SET ERRORCOUNT = ( SELECT COUNT(DISTINCT E.LINE_NUMBER)  
                  FROM WC_ERRORS_G E  
                   WHERE E.ETL_PROC_WID = WC_LOAD_STATUS_G.ETL_PROC_WID  
                    AND E.ERROR_TYPE = 'ERROR'  
                         --AND UPPER(E.[FILE_NAME]) = UPPER(WC_LOAD_STATUS_G.[FILENAME])  
						 AND SUBSTRING(UPPER(E.[FILE_NAME]),1,28) = UPPER(WC_LOAD_STATUS_G.[FILENAME])
              )  
 WHERE ERRORCOUNT IS NULL   
  
            SET @ROW_CNT   = CAST(@@ROWCOUNT AS NVARCHAR(10))  
            SET @ERROR_COD = CAST(@@ERROR AS NVARCHAR(10))  
            SET @PROCESS_DESCRIPTION = 'Update WC_LOAD_STATUS_G : ERRORCOUNT - Done'   
            SET @DEBUG_VALUE = '6 :Update WC_LOAD_STATUS_G : ERRORCOUNT'+' Rows UPDATE='+@ROW_CNT  
                                                                             +' Error Code='+@ERROR_COD  
  
            EXEC INSERT_WC_PROCESS_EXECUTION_LOG @OBJECT_TYPE               ,  
                                                 @PROCESS_OBJECTS           ,  
                                                 @PROCESS_TASKS             ,  
                                                 @PROCESS_DESCRIPTION       ,  
                                                 @DEBUG_VALUE               ,  
                                                 'DEBUG_INFO'             ,  
                                                 @COUNTRY_CODE              ,  
                                                 @ETL_PROC_WID    
  
--Update the load status table with the number of warnings  
  
UPDATE WC_LOAD_STATUS_G  
   SET WARNINGCOUNT =   
 (SELECT COUNT(DISTINCT E.LINE_NUMBER)  
 FROM WC_ERRORS_G E  
 WHERE E.ETL_PROC_WID = WC_LOAD_STATUS_G.ETL_PROC_WID  
 AND E.ERROR_TYPE = 'WARNING'  
 --AND UPPER(E.[FILE_NAME]) = UPPER(WC_LOAD_STATUS_G.[FILENAME])  
 AND SUBSTRING(UPPER(E.[FILE_NAME]),1,28) = UPPER(WC_LOAD_STATUS_G.[FILENAME])
 )  
WHERE WARNINGCOUNT IS NULL   
  
            SET @ROW_CNT   = CAST(@@ROWCOUNT AS NVARCHAR(10))  
            SET @ERROR_COD = CAST(@@ERROR AS NVARCHAR(10))  
            SET @PROCESS_DESCRIPTION = 'Update WC_LOAD_STATUS_G : WARNINGCOUNT - Done'   
            SET @DEBUG_VALUE = '7 :Update WC_LOAD_STATUS_G : WARNINGCOUNT'+' Rows UPDATE='+@ROW_CNT  
                                                                             +' Error Code='+@ERROR_COD  
  
            EXEC INSERT_WC_PROCESS_EXECUTION_LOG @OBJECT_TYPE               ,  
                                                 @PROCESS_OBJECTS           ,  
                                                 @PROCESS_TASKS             ,  
                                                 @PROCESS_DESCRIPTION       ,  
                                                 @DEBUG_VALUE               ,  
                                                 'DEBUG_INFO'               ,  
                                                 @COUNTRY_CODE              ,  
                                                 @ETL_PROC_WID   
  

-- INC0995863 - Populate start and end time where they are NULL.

SET @ROW_COUNT  = (SELECT count(1) from WC_LOAD_STATUS_G where ETL_PROC_WID = @ETL_PROC_WID and (LOAD_START_TIME is NULL or LOAD_END_TIME is NULL or LOAD_START_TIME = '' or LOAD_END_TIME = ''))

IF (@ROW_COUNT > 0)--Perform Update if there are null values 
BEGIN
UPDATE WC_LOAD_STATUS_G  
   SET LOAD_START_TIME =   
 (
 SELECT LOAD_START_TIME FROM	   
	   (SELECT    a.[FILENAME] as FILES,  
            a.ETL_PROC_WID AS ETL_PROC_WID,  
            MAX(DATENAME(hour,a.LOAD_START_TIME) + ':' + CASE WHEN DATENAME(minute,a.LOAD_START_TIME) < 10   
                                                                 THEN '0' + DATENAME(minute,a.LOAD_START_TIME)  
                                                                      ELSE DATENAME(minute,a.LOAD_START_TIME)  
                                                                         END) AS LOAD_START_TIME, -- The start time of the load  
            MAX(DATENAME(HOUR,a.LOAD_END_TIME) + ':' + CASE WHEN DATENAME(MINUTE,a.LOAD_END_TIME) < 10   
                                                              THEN '0' + DATENAME(MINUTE,a.LOAD_END_TIME)  
                                                                       ELSE DATENAME(MINUTE,a.LOAD_END_TIME)  
                                                                     END) AS LOAD_END_TIME -- The end time of the load  

       FROM  WC_ETL_FILES_G a (NOLOCK)
       WHERE  ETL_PROC_WID = @ETL_PROC_WID 
	   GROUP BY [FILENAME], ETL_PROC_WID
	   ) SUB
 WHERE SUB.ETL_PROC_WID = WC_LOAD_STATUS_G.ETL_PROC_WID
 AND   UPPER(SUB.FILES) = UPPER(WC_LOAD_STATUS_G.[FILENAME])
 ),
 
LOAD_END_TIME =   
 (
 SELECT LOAD_END_TIME FROM	   
	   (SELECT    a.[FILENAME] as FILES,  
            a.ETL_PROC_WID AS ETL_PROC_WID,  
            MAX(DATENAME(hour,a.LOAD_START_TIME) + ':' + CASE WHEN DATENAME(minute,a.LOAD_START_TIME) < 10   
                                                                 THEN '0' + DATENAME(minute,a.LOAD_START_TIME)  
                                                                      ELSE DATENAME(minute,a.LOAD_START_TIME)  
                                                                         END) AS LOAD_START_TIME, -- The start time of the load  
            MAX(DATENAME(HOUR,a.LOAD_END_TIME) + ':' + CASE WHEN DATENAME(MINUTE,a.LOAD_END_TIME) < 10   
                                                              THEN '0' + DATENAME(MINUTE,a.LOAD_END_TIME)  
                                                                       ELSE DATENAME(MINUTE,a.LOAD_END_TIME)  
                                                                     END) AS LOAD_END_TIME -- The end time of the load  

       FROM  WC_ETL_FILES_G a (NOLOCK)
       WHERE  ETL_PROC_WID = @ETL_PROC_WID 
	   GROUP BY [FILENAME], ETL_PROC_WID
	   ) SUB2
 WHERE SUB2.ETL_PROC_WID = WC_LOAD_STATUS_G.ETL_PROC_WID
 AND   UPPER(SUB2.FILES) = UPPER(WC_LOAD_STATUS_G.[FILENAME])

 )
 
 WHERE WC_LOAD_STATUS_G.ETL_PROC_WID = @ETL_PROC_WID  and (LOAD_START_TIME is NULL or LOAD_END_TIME is NULL or LOAD_START_TIME = '' or LOAD_END_TIME = '')
END

  
--Set the load duration  
UPDATE WC_LOAD_STATUS_G  
   SET LOAD_DURATION_TIME = (SELECT (CASE WHEN ((DATEDIFF(MI,ACTUAL_START_TS,ACTUAL_END_TS) - (DATEDIFF(MI,ACTUAL_START_TS,ACTUAL_END_TS) % 60))/60) < 10  
                                THEN '0' + CAST(((DATEDIFF(MI,ACTUAL_START_TS,ACTUAL_END_TS) - (DATEDIFF(MI,ACTUAL_START_TS,ACTUAL_END_TS) % 60))/60) AS CHAR(1))  
                              ELSE CAST(((DATEDIFF(MI,ACTUAL_START_TS,ACTUAL_END_TS) - (DATEDIFF(MI,ACTUAL_START_TS,ACTUAL_END_TS) % 60))/60) AS CHAR(2))  
                                 END) +  
                             ':' +   
                        (CASE WHEN (DATEDIFF(MI,ACTUAL_START_TS,ACTUAL_END_TS) % 60) < 10  
                               THEN '0' + CAST((DATEDIFF(MI,ACTUAL_START_TS,ACTUAL_END_TS) % 60) AS CHAR(1))  
                             ELSE CAST((DATEDIFF(MI,ACTUAL_START_TS,ACTUAL_END_TS) % 60) AS CHAR(2))   
                            END)  
                          FROM W_ETL_RUN_S R  
                            WHERE WC_LOAD_STATUS_G.ETL_PROC_WID = R.ROW_WID)  
 WHERE (LOAD_DURATION_TIME IS NULL or LOAD_START_TIME is NULL or LOAD_END_TIME is NULL or LOAD_START_TIME = '' or LOAD_END_TIME = '') 



-- Set bu id  
UPDATE WC_LOAD_STATUS_G  
SET BU_ID = (SELECT D.INTEGRATION_ID   
               FROM WC_BU_D D  
              WHERE SUBSTRING(WC_LOAD_STATUS_G.FILENAME,1,2) = COUNTRY_CODE )   
WHERE BU_ID IS NULL  
  
UPDATE WC_LOAD_STATUS_G  
SET BU_ID = (SELECT D.INTEGRATION_ID   
               FROM WC_BU_D D  
              WHERE BU_NAME = COUNTRY_CODE )   
WHERE BU_ID IS NULL  
 
  
            SET @ROW_CNT   = CAST(@@ROWCOUNT AS NVARCHAR(10))  
            SET @ERROR_COD = CAST(@@ERROR AS NVARCHAR(10))  
            SET @PROCESS_DESCRIPTION = 'Update WC_LOAD_STATUS_G : BU_ID - Done'   
            SET @DEBUG_VALUE = '8 :Update WC_LOAD_STATUS_G : BU_ID'+' Rows UPDATE='+@ROW_CNT  
                                                                             +' Error Code='+@ERROR_COD  
  
            EXEC INSERT_WC_PROCESS_EXECUTION_LOG @OBJECT_TYPE               ,  
                                                 @PROCESS_OBJECTS           ,  
                                                 @PROCESS_TASKS             ,  
                                                 @PROCESS_DESCRIPTION       ,  
                                                 @DEBUG_VALUE               ,  
                                                 'DEBUG_INFO'               ,  
                                                 @COUNTRY_CODE              ,  
                                                 @ETL_PROC_WID  


  
           
  
            SET @PROCESS_DESCRIPTION = 'END of Status sheet'  
            SET @DEBUG_VALUE = '1 : START => 10 : END '  
            EXEC INSERT_WC_PROCESS_EXECUTION_LOG @OBJECT_TYPE               ,  
                                                 @PROCESS_OBJECTS           ,  
                                                 @PROCESS_TASKS             ,  
                                                 @PROCESS_DESCRIPTION       ,  
                                                 @DEBUG_VALUE               ,  
                                                 'ENDED'                  ,  
                                                 @COUNTRY_CODE              ,  
                                                 @ETL_PROC_WID    
  
/*** end **/  
END
GO
